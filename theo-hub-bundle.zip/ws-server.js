'use strict';

const crypto = require('crypto');

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_MESSAGE_BYTES = 16 * 1024 * 1024;
const MAX_BACKPRESSURE_BYTES = 4 * 1024 * 1024;

function encodeWsFrame(opcode, payloadBuf) {
  const body = Buffer.isBuffer(payloadBuf)
    ? payloadBuf
    : Buffer.from(String(payloadBuf || ''), 'utf8');
  const len = body.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x80 | (opcode & 0x0f);
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | (opcode & 0x0f);
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | (opcode & 0x0f);
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, body]);
}

class MinimalWsConnection {
  constructor(socket, req) {
    this.socket = socket;
    this.req = req;
    this.url = req?.url || '/ws';
    this.closed = false;
    this.buffer = Buffer.alloc(0);
    this.fragOpcode = 0;
    this.fragChunks = [];
    this.fragBytes = 0;
    this.lastActivityAt = Date.now();
    this.authTimer = null;
    this.onMessage = null;
    this.onClose = null;
    this.meta = { authenticated: false };

    socket.setNoDelay(true);
    socket.on('data', (chunk) => this._handleData(chunk));
    socket.on('close', () => this._markClosed());
    socket.on('end', () => this._markClosed());
    socket.on('error', () => this._markClosed());
  }

  sendJson(obj) {
    if (this.closed) return false;
    if (this.socket.writableLength > MAX_BACKPRESSURE_BYTES) {
      this.close(1008);
      return false;
    }
    try {
      const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
      this.socket.write(encodeWsFrame(0x01, Buffer.from(text, 'utf8')));
      return true;
    } catch {
      this.close(1011);
      return false;
    }
  }

  ping() {
    if (this.closed) return;
    try {
      this.socket.write(encodeWsFrame(0x09, Buffer.alloc(0)));
    } catch {
      this.close(1011);
    }
  }

  close(code = 1000) {
    if (this.closed) return;
    this.closed = true;
    if (this.authTimer) {
      clearTimeout(this.authTimer);
      this.authTimer = null;
    }
    this.fragChunks = [];
    this.fragBytes = 0;
    this.buffer = Buffer.alloc(0);
    try {
      const codeBuf = Buffer.alloc(2);
      codeBuf.writeUInt16BE(Number(code) || 1000, 0);
      this.socket.end(encodeWsFrame(0x08, codeBuf));
      const killTimer = setTimeout(() => {
        try {
          if (!this.socket.destroyed) this.socket.destroy();
        } catch {}
      }, 400);
      if (typeof killTimer.unref === 'function') killTimer.unref();
    } catch {
      try {
        this.socket.destroy();
      } catch {}
    }
    if (typeof this.onClose === 'function') {
      try {
        this.onClose(this);
      } catch {}
    }
  }

  _markClosed() {
    if (this.closed) return;
    this.closed = true;
    if (this.authTimer) {
      clearTimeout(this.authTimer);
      this.authTimer = null;
    }
    this.fragChunks = [];
    this.fragBytes = 0;
    this.buffer = Buffer.alloc(0);
    if (typeof this.onClose === 'function') {
      try {
        this.onClose(this);
      } catch {}
    }
  }

  _handleData(chunk) {
    if (this.closed || !chunk || !chunk.length) return;
    this.lastActivityAt = Date.now();
    if (this.buffer.length + chunk.length > MAX_MESSAGE_BYTES + 65536) {
      this.close(1009);
      return;
    }
    this.buffer = this.buffer.length ? Buffer.concat([this.buffer, chunk]) : chunk;

    while (this.buffer.length >= 2) {
      const b0 = this.buffer[0];
      const b1 = this.buffer[1];
      // RFC 6455 §5.2: RSV1-3 must be 0 when no extension was negotiated
      if ((b0 & 0x70) !== 0) {
        this.close(1002);
        return;
      }
      const fin = (b0 & 0x80) !== 0;
      const opcode = b0 & 0x0f;
      const masked = (b1 & 0x80) !== 0;
      // RFC 6455 §5.1: All client-to-server frames MUST be masked
      if (!masked) {
        this.close(1002);
        return;
      }
      let payloadLen = b1 & 0x7f;
      let offset = 2;

      // RFC 6455 §5.5: Control frames MUST NOT be fragmented and MUST have payload <= 125 bytes
      if (opcode >= 0x08 && (!fin || payloadLen > 125)) {
        this.close(1002);
        return;
      }

      if (payloadLen === 126) {
        if (this.buffer.length < 4) return;
        payloadLen = this.buffer.readUInt16BE(2);
        offset = 4;
      } else if (payloadLen === 127) {
        if (this.buffer.length < 10) return;
        const bigLen = this.buffer.readBigUInt64BE(2);
        if ((bigLen >> 63n) !== 0n || bigLen > BigInt(MAX_MESSAGE_BYTES)) {
          this.close(1009);
          return;
        }
        payloadLen = Number(bigLen);
        offset = 10;
      }

      const maskLen = 4;
      const totalFrameLen = offset + maskLen + payloadLen;
      if (this.buffer.length < totalFrameLen) {
        return;
      }

      const payload = Buffer.from(this.buffer.subarray(offset + maskLen, totalFrameLen));
      const maskKey = this.buffer.subarray(offset, offset + 4);
      for (let i = 0; i < payload.length; i++) {
        payload[i] ^= maskKey[i & 3];
      }
      this.buffer = this.buffer.subarray(totalFrameLen);

      if (opcode === 0x08) {
        this.close(1000);
        return;
      }
      if (opcode === 0x09) {
        try {
          this.socket.write(encodeWsFrame(0x0a, payload));
        } catch {}
        continue;
      }
      if (opcode === 0x0a) {
        this.lastActivityAt = Date.now();
        continue;
      }

      if (opcode === 0x01 || opcode === 0x02) {
        // RFC 6455 §5.4: Cannot start a new data message while a fragmented message is in flight
        if (this.fragOpcode !== 0) {
          this.close(1002);
          return;
        }
        if (fin) {
          this._emitPayload(opcode, payload);
        } else {
          this.fragOpcode = opcode;
          this.fragChunks = [payload];
          this.fragBytes = payload.length;
        }
      } else if (opcode === 0x00) {
        if (this.fragOpcode === 0) {
          this.close(1002);
          return;
        }
        if (this.fragBytes + payload.length > MAX_MESSAGE_BYTES) {
          this.close(1009);
          return;
        }
        this.fragChunks.push(payload);
        this.fragBytes += payload.length;
        if (fin) {
          const full = Buffer.concat(this.fragChunks, this.fragBytes);
          const origOp = this.fragOpcode;
          this.fragOpcode = 0;
          this.fragChunks = [];
          this.fragBytes = 0;
          this._emitPayload(origOp, full);
        }
      } else {
        this.close(1002);
        return;
      }
    }
  }

  _emitPayload(opcode, buf) {
    if (opcode !== 0x01 || typeof this.onMessage !== 'function') return;
    try {
      const text = buf.toString('utf8');
      const parsed = JSON.parse(text);
      this.onMessage(parsed, this);
    } catch {}
  }
}

function attachWebSocketServer(httpServer, options = {}) {
  const clients = new Set();
  const pathPrefix = options.path || '/ws';
  const requireAuth = typeof options.verifyToken === 'function';

  const pingInterval = setInterval(() => {
    const now = Date.now();
    for (const c of Array.from(clients)) {
      if (c.closed) {
        clients.delete(c);
      } else if (now - c.lastActivityAt > 65000) {
        c.close(1001);
        clients.delete(c);
      } else {
        c.ping();
      }
    }
  }, 25000);
  if (typeof pingInterval.unref === 'function') {
    pingInterval.unref();
  }

  httpServer.on('upgrade', (req, socket, head) => {
    try {
      const parsedUrl = new URL(req.url || '/', 'http://localhost');
      if (parsedUrl.pathname !== pathPrefix && !parsedUrl.pathname.startsWith(`${pathPrefix}/`)) {
        socket.destroy();
        return;
      }

      let preAuthed = !requireAuth;
      if (typeof options.verifyUpgrade === 'function') {
        const check = options.verifyUpgrade(req, parsedUrl);
        if (!check || check.ok === false) {
          try {
            socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');
          } catch {
            socket.destroy();
          }
          return;
        }
        if (check.authenticated === true) {
          preAuthed = true;
        }
      }

      const key = String(req.headers['sec-websocket-key'] || '').trim();
      if (!key) {
        socket.destroy();
        return;
      }
      const accept = crypto
        .createHash('sha1')
        .update(key + WS_GUID, 'binary')
        .digest('base64');

      const headers = [
        'HTTP/1.1 101 Switching Protocols',
        'Upgrade: websocket',
        'Connection: Upgrade',
        `Sec-WebSocket-Accept: ${accept}`,
        '\r\n'
      ].join('\r\n');
      socket.write(headers);

      const conn = new MinimalWsConnection(socket, req);
      conn.meta.query = Object.fromEntries(parsedUrl.searchParams.entries());
      conn.meta.authenticated = preAuthed;

      if (!preAuthed && requireAuth) {
        conn.authTimer = setTimeout(() => {
          if (!conn.meta.authenticated && !conn.closed) {
            conn.sendJson({ type: 'auth_err', error: 'Authentication timeout' });
            conn.close(4001);
          }
        }, 8000);
        if (typeof conn.authTimer.unref === 'function') conn.authTimer.unref();
      }

      conn.onClose = () => {
        clients.delete(conn);
        if (typeof options.onDisconnect === 'function') {
          try {
            options.onDisconnect(conn);
          } catch {}
        }
      };

      conn.onMessage = (msg) => {
        if (!msg || typeof msg !== 'object') return;
        if (msg.type === 'auth' || msg.type === 'auth_client') {
          if (!requireAuth || options.verifyToken(msg.token, req)) {
            conn.meta.authenticated = true;
            if (conn.authTimer) {
              clearTimeout(conn.authTimer);
              conn.authTimer = null;
            }
            conn.sendJson({ type: 'auth_ok', ts: Date.now() });
            const authCb = options.onAuthenticated || options.onConnect;
            if (typeof authCb === 'function') {
              try {
                authCb(conn);
              } catch {}
            }
          } else {
            conn.sendJson({ type: 'auth_err', error: 'Invalid bridge token' });
            conn.close(4001);
          }
          return;
        }

        if (!conn.meta.authenticated) {
          conn.sendJson({ type: 'auth_err', error: 'Authenticate first' });
          conn.close(4001);
          return;
        }

        if (msg.type === 'ping') {
          conn.sendJson({ type: 'pong', ts: Date.now(), echoTs: msg.ts || 0 });
          return;
        }

        if (typeof options.onMessage === 'function') {
          Promise.resolve(options.onMessage(msg, conn)).catch((err) => {
            if (msg?.reqId) {
              conn.sendJson({
                type: 'rpc_res',
                reqId: msg.reqId,
                ok: false,
                error: String(err?.message || err)
              });
            }
          });
        }
      };

      clients.add(conn);
      if (head && head.length) {
        conn._handleData(head);
      }
      if (preAuthed && typeof options.onConnect === 'function') {
        try {
          options.onConnect(conn);
        } catch {}
      }
    } catch {
      try {
        socket.destroy();
      } catch {}
    }
  });

  return {
    clients,
    broadcast(obj, filterFn = null) {
      if (clients.size === 0) return 0;
      let sent = 0;
      const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
      for (const c of Array.from(clients)) {
        if (c.closed) {
          clients.delete(c);
          continue;
        }
        if (!c.meta.authenticated) continue;
        if (filterFn && !filterFn(c)) continue;
        if (c.sendJson(text)) sent += 1;
      }
      return sent;
    },
    closeAll() {
      clearInterval(pingInterval);
      for (const c of Array.from(clients)) {
        c.close(1001);
      }
      clients.clear();
    }
  };
}

module.exports = {
  attachWebSocketServer,
  encodeWsFrame
};
