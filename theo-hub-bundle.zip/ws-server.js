'use strict';

const crypto = require('crypto');

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

function encodeWsFrame(opcode, payloadBuf) {
  const body = Buffer.isBuffer(payloadBuf)
    ? payloadBuf
    : Buffer.from(String(payloadBuf || ''), 'utf8');
  const len = body.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x80 | (opcode & 0x0f);
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | (opcode & 0x0f);
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | (opcode & 0x0f);
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, body]);
}

class MinimalWsConnection {
  constructor(socket, req) {
    this.socket = socket;
    this.req = req;
    this.url = req?.url || '/ws';
    this.closed = false;
    this.buffer = Buffer.alloc(0);
    this.fragOpcode = 0;
    this.fragChunks = [];
    this.onMessage = null;
    this.onClose = null;
    this.meta = {};

    socket.setNoDelay(true);
    socket.on('data', (chunk) => this._handleData(chunk));
    socket.on('close', () => this._markClosed());
    socket.on('end', () => this._markClosed());
    socket.on('error', () => this._markClosed());
  }

  sendJson(obj) {
    if (this.closed) return false;
    try {
      const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
      this.socket.write(encodeWsFrame(0x01, Buffer.from(text, 'utf8')));
      return true;
    } catch {
      this.close();
      return false;
    }
  }

  ping() {
    if (this.closed) return;
    try {
      this.socket.write(encodeWsFrame(0x09, Buffer.alloc(0)));
    } catch {
      this.close();
    }
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    try {
      this.socket.write(encodeWsFrame(0x08, Buffer.alloc(0)));
    } catch {}
    try {
      this.socket.destroy();
    } catch {}
    if (typeof this.onClose === 'function') {
      try {
        this.onClose(this);
      } catch {}
    }
  }

  _markClosed() {
    if (this.closed) return;
    this.closed = true;
    if (typeof this.onClose === 'function') {
      try {
        this.onClose(this);
      } catch {}
    }
  }

  _handleData(chunk) {
    if (this.closed || !chunk || !chunk.length) return;
    this.buffer = this.buffer.length ? Buffer.concat([this.buffer, chunk]) : chunk;

    while (this.buffer.length >= 2) {
      const b0 = this.buffer[0];
      const b1 = this.buffer[1];
      const fin = (b0 & 0x80) !== 0;
      const opcode = b0 & 0x0f;
      const masked = (b1 & 0x80) !== 0;
      let payloadLen = b1 & 0x7f;
      let offset = 2;

      if (payloadLen === 126) {
        if (this.buffer.length < 4) return;
        payloadLen = this.buffer.readUInt16BE(2);
        offset = 4;
      } else if (payloadLen === 127) {
        if (this.buffer.length < 10) return;
        const bigLen = this.buffer.readBigUInt64BE(2);
        if (bigLen > BigInt(16 * 1024 * 1024)) {
          this.close();
          return;
        }
        payloadLen = Number(bigLen);
        offset = 10;
      }

      const maskLen = masked ? 4 : 0;
      const totalFrameLen = offset + maskLen + payloadLen;
      if (this.buffer.length < totalFrameLen) {
        return;
      }

      let payload = Buffer.from(this.buffer.subarray(offset + maskLen, totalFrameLen));
      if (masked) {
        const maskKey = this.buffer.subarray(offset, offset + 4);
        for (let i = 0; i < payload.length; i++) {
          payload[i] ^= maskKey[i & 3];
        }
      }
      this.buffer = this.buffer.subarray(totalFrameLen);

      if (opcode === 0x08) {
        // Close
        this.close();
        return;
      }
      if (opcode === 0x09) {
        // Ping -> Pong
        try {
          this.socket.write(encodeWsFrame(0x0a, payload));
        } catch {}
        continue;
      }
      if (opcode === 0x0a) {
        // Pong
        continue;
      }

      if (opcode === 0x01 || opcode === 0x02) {
        if (fin) {
          this._emitPayload(opcode, payload);
        } else {
          this.fragOpcode = opcode;
          this.fragChunks = [payload];
        }
      } else if (opcode === 0x00 && this.fragOpcode) {
        this.fragChunks.push(payload);
        if (fin) {
          const full = Buffer.concat(this.fragChunks);
          const origOp = this.fragOpcode;
          this.fragOpcode = 0;
          this.fragChunks = [];
          this._emitPayload(origOp, full);
        }
      }
    }
  }

  _emitPayload(opcode, buf) {
    if (opcode !== 0x01 || typeof this.onMessage !== 'function') return;
    try {
      const text = buf.toString('utf8');
      const parsed = JSON.parse(text);
      this.onMessage(parsed, this);
    } catch {}
  }
}

function attachWebSocketServer(httpServer, options = {}) {
  const clients = new Set();
  const pathPrefix = options.path || '/ws';

  const pingInterval = setInterval(() => {
    for (const c of Array.from(clients)) {
      if (c.closed) {
        clients.delete(c);
      } else {
        c.ping();
      }
    }
  }, 25000);
  if (typeof pingInterval.unref === 'function') {
    pingInterval.unref();
  }

  httpServer.on('upgrade', (req, socket, head) => {
    try {
      const parsedUrl = new URL(req.url || '/', 'http://localhost');
      if (parsedUrl.pathname !== pathPrefix && !parsedUrl.pathname.startsWith(`${pathPrefix}/`)) {
        socket.destroy();
        return;
      }
      const key = String(req.headers['sec-websocket-key'] || '').trim();
      if (!key) {
        socket.destroy();
        return;
      }
      const accept = crypto
        .createHash('sha1')
        .update(key + WS_GUID, 'binary')
        .digest('base64');

      const headers = [
        'HTTP/1.1 101 Switching Protocols',
        'Upgrade: websocket',
        'Connection: Upgrade',
        `Sec-WebSocket-Accept: ${accept}`,
        '\r\n'
      ].join('\r\n');
      socket.write(headers);

      const conn = new MinimalWsConnection(socket, req);
      conn.meta.query = Object.fromEntries(parsedUrl.searchParams.entries());
      conn.onClose = () => {
        clients.delete(conn);
        if (typeof options.onDisconnect === 'function') {
          try {
            options.onDisconnect(conn);
          } catch {}
        }
      };
      conn.onMessage = (msg) => {
        if (msg && msg.type === 'ping') {
          conn.sendJson({ type: 'pong', ts: Date.now(), echoTs: msg.ts || 0 });
          return;
        }
        if (typeof options.onMessage === 'function') {
          Promise.resolve(options.onMessage(msg, conn)).catch((err) => {
            if (msg?.reqId) {
              conn.sendJson({
                type: 'rpc_res',
                reqId: msg.reqId,
                ok: false,
                error: String(err?.message || err)
              });
            }
          });
        }
      };

      clients.add(conn);
      if (head && head.length) {
        conn._handleData(head);
      }
      if (typeof options.onConnect === 'function') {
        try {
          options.onConnect(conn);
        } catch {}
      }
    } catch {
      try {
        socket.destroy();
      } catch {}
    }
  });

  return {
    clients,
    broadcast(obj, filterFn = null) {
      if (clients.size === 0) return 0;
      let sent = 0;
      const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
      for (const c of Array.from(clients)) {
        if (c.closed) {
          clients.delete(c);
          continue;
        }
        if (filterFn && !filterFn(c)) continue;
        if (c.sendJson(text)) sent += 1;
      }
      return sent;
    },
    closeAll() {
      clearInterval(pingInterval);
      for (const c of Array.from(clients)) {
        c.close();
      }
      clients.clear();
    }
  };
}

module.exports = {
  attachWebSocketServer,
  encodeWsFrame
};
