const vscode = require('vscode');
const {
  SESSION_TAB_SCHEME,
  SESSION_TAB_VIEW_TYPE,
  buildNewSessionUriString,
  buildThreadUriString,
  parseSessionUri,
  normalizeUriKey
} = require('./compat/antigravity-tab-state.cjs');
const { CLAUDE_DRAFT_SCHEME } = require('./compat/claude-hub-bridge.cjs');

const AUTO_PARK_STATE_SYMBOL = Symbol.for('bhfirms.theoHub.autoParkTabState');
const DEFAULT_AUTO_PARK_IDLE_MINUTES = 30;
const DEFAULT_AUTO_PARK_KEEP_RECENT = 5;
const AUTO_PARK_ABSENT_PRUNE_MS = 15000;

function getAutoParkStateStore() {
  let st = globalThis[AUTO_PARK_STATE_SYMBOL];
  if (!st || !(st.byKey instanceof Map)) {
    st = { byKey: new Map(), lastSweepAt: 0 };
    globalThis[AUTO_PARK_STATE_SYMBOL] = st;
  }
  return st;
}

function makeAutoParkTabKey(tab) {
  if (!tab || typeof tab !== 'object') return '';
  const provider = tab.provider === 'claude' ? 'claude' : 'antigravity';
  const id = String(tab.id || '').trim();
  if (id) return `${provider}:${id}`;
  const rawUri = String(tab.uri || '').trim();
  if (!rawUri) return '';
  return `${provider}:${provider === 'antigravity' ? normalizeUriKey(rawUri) : rawUri}`;
}

function collectTabGroupsProtectionSnapshot(vscodeApi = vscode) {
  const visibleUris = new Set();
  const nativePinnedUris = new Set();
  const nativePinnedLabels = new Set();
  const visibleLabels = new Set();
  const groups = Array.isArray(vscodeApi?.window?.tabGroups?.all) ? vscodeApi.window.tabGroups.all : [];
  for (const group of groups) {
    const activeTab = group?.activeTab || null;
    for (const tab of group?.tabs || []) {
      const uri = tab?.input?.uri;
      const viewType = String(tab?.input?.viewType || '');
      const label = String(tab?.label || '').trim();
      const isVisibleInCol = Boolean(tab?.isActive || (activeTab && tab === activeTab));
      const isNativePinned = Boolean(tab?.isPinned);
      if (uri) {
        const uriStr = uri.toString();
        const norm = uri.scheme === SESSION_TAB_SCHEME ? normalizeUriKey(uriStr) : uriStr;
        if (isVisibleInCol && norm) visibleUris.add(norm);
        if (isNativePinned && norm) nativePinnedUris.add(norm);
      }
      if (viewType.includes('claudeVSCodePanel') && label) {
        if (isVisibleInCol) visibleLabels.add(label);
        if (isNativePinned) nativePinnedLabels.add(label);
      }
    }
  }
  return { visibleUris, nativePinnedUris, nativePinnedLabels, visibleLabels };
}

function isTabProtectedInLiveTabGroups(cand, vscodeApi = vscode) {
  if (!cand || typeof cand !== 'object') return false;
  const snap = collectTabGroupsProtectionSnapshot(vscodeApi);
  const normUri =
    cand.uri && cand.provider !== 'claude'
      ? normalizeUriKey(cand.uri)
      : String(cand.uri || '').trim();
  if (normUri && (snap.visibleUris.has(normUri) || snap.nativePinnedUris.has(normUri))) {
    return true;
  }
  if (cand.provider === 'claude' && cand.title) {
    const title = String(cand.title).trim();
    if (title && (snap.visibleLabels.has(title) || snap.nativePinnedLabels.has(title))) {
      return true;
    }
  }
  return false;
}

// Pure evaluator for auto-parking idle, read, unpinned conversation tabs.
// Protects active/visible tabs, split-column visible tabs, running/waiting/pendingQuestion/bg-task/scheduled
// sessions, unread/THEO-pinned/VS-Code-pinned tabs, blank drafts, unsent composer text (fail-closed when a
// hydrated webview has not reported), pending approvals, and the N most recently active tabs.
function evaluateAutoParkTabCandidates({
  openTabs = [],
  threadsById = new Map(),
  activityByKey = new Map(),
  unreadIds = new Set(),
  pinnedIds = new Set(),
  visibleUris = new Set(),
  visibleLabels = new Set(),
  nativePinnedUris = new Set(),
  nativePinnedLabels = new Set(),
  draftProtectedIds = new Set(),
  pendingApprovalIds = new Set(),
  blockAllClaudeAutoPark = false,
  blockAllAgyHydratedAutoPark = false,
  idleMs = DEFAULT_AUTO_PARK_IDLE_MINUTES * 60 * 1000,
  keepRecentCount = DEFAULT_AUTO_PARK_KEEP_RECENT,
  maxClosePerPass = 4,
  nowMs = Date.now()
} = {}) {
  if (!(idleMs > 0) || !Array.isArray(openTabs) || openTabs.length === 0) {
    return [];
  }
  const keepN = Math.max(0, Math.floor(Number(keepRecentCount) || 0));
  if (openTabs.length <= keepN) {
    return [];
  }
  const cap = Math.max(1, Math.floor(Number(maxClosePerPass) || 4));
  const getThread = (id) =>
    threadsById instanceof Map ? threadsById.get(id) : threadsById ? threadsById[id] : null;

  const ranked = openTabs.map((tab, index) => {
    const key = makeAutoParkTabKey(tab);
    const act = key && activityByKey instanceof Map ? activityByKey.get(key) : null;
    const recencyMs = Math.max(Number(act?.lastActiveAt || 0), Number(act?.openedAt || 0));
    const isVisible = Boolean(tab?.active || tab?.visible);
    return { tab, key, recencyMs, isVisible, index };
  });

  ranked.sort(
    (a, b) =>
      Number(Boolean(b.tab?.active)) - Number(Boolean(a.tab?.active)) ||
      Number(b.isVisible) - Number(a.isVisible) ||
      b.recencyMs - a.recencyMs ||
      a.index - b.index
  );

  const recentProtectedKeys = new Set();
  for (let i = 0; i < Math.min(keepN, ranked.length); i += 1) {
    if (ranked[i].key) recentProtectedKeys.add(ranked[i].key);
  }

  const candidates = [];
  for (const item of ranked) {
    const { tab, key, recencyMs } = item;
    if (!tab || !tab.id || !key) continue;
    const provider = tab.provider === 'claude' ? 'claude' : 'antigravity';
    if (tab.active || tab.visible) continue;
    if (recentProtectedKeys.has(key)) continue;

    const normUri =
      tab.uri && provider !== 'claude'
        ? normalizeUriKey(tab.uri)
        : String(tab.uri || '').trim();
    if (normUri && (visibleUris.has(normUri) || nativePinnedUris.has(normUri))) continue;
    if (provider === 'claude' && tab.title) {
      const title = String(tab.title).trim();
      if (title && (visibleLabels.has(title) || nativePinnedLabels.has(title))) continue;
    }

    if (unreadIds.has(tab.id) || pinnedIds.has(tab.id)) continue;
    if (pendingApprovalIds.has(tab.id) || draftProtectedIds.has(tab.id)) continue;
    if (provider === 'claude' && tab.hydrated !== false && blockAllClaudeAutoPark) continue;
    if (provider !== 'claude' && tab.hydrated !== false && blockAllAgyHydratedAutoPark) continue;

    const thread = getThread(tab.id);
    if (!thread) continue;
    const classified = String(thread.classifiedState || '').toLowerCase();
    const rawStatus = String(thread.status || '').toLowerCase();
    if (
      classified === 'thinking' ||
      classified === 'waiting' ||
      rawStatus === 'working' ||
      rawStatus === 'waiting' ||
      rawStatus.includes('running') ||
      Boolean(thread.notFullyIdle) ||
      Boolean(thread.pendingQuestion) ||
      Boolean(thread.elsewhere) ||
      Number(thread.bgRunningCount || 0) > 0 ||
      (provider === 'claude' && Number(thread.scheduledWorkUntilMs || 0) > nowMs)
    ) {
      continue;
    }

    if (!(recencyMs > 0) || nowMs - recencyMs < idleMs) continue;
    const threadUpdatedMs = Number(thread.updatedAtMs || 0);
    if (threadUpdatedMs > 0 && nowMs - threadUpdatedMs < idleMs) continue;

    candidates.push({
      id: tab.id,
      uri: tab.uri || '',
      provider,
      title: tab.title || '',
      key,
      recencyMs,
      idleMs: nowMs - recencyMs
    });
  }

  candidates.sort((a, b) => a.recencyMs - b.recencyMs);
  return candidates.slice(0, cap);
}

function getDirectAgyBridge() {
  try {
    const mod = require('./compat/antigravity-hub-bridge.cjs');
    const st = mod?.getBridgeState?.();
    if (st && (st.attached || st.context || st.apiImpl) && st.vscode === vscode) {
      return mod;
    }
  } catch {}
  return null;
}

function getDirectClaudeBridge() {
  try {
    const mod = require('./compat/claude-hub-bridge.cjs');
    const st = mod?.getBridgeState?.();
    if (st && st.attached && st.vscode === vscode) {
      return mod;
    }
  } catch {}
  return null;
}

// One warning per session per few seconds, so a double click does not stack two toasts.
const CLAUDE_OPEN_FAILURE_COOLDOWN_MS = 4000;
const claudeOpenFailureShownAt = new Map();

function describeClaudeOpenFailure(title, failure) {
  const name = String(title || '').trim();
  const what = name ? `"${name.length > 60 ? `${name.slice(0, 57)}...` : name}"` : 'this Claude session';
  return failure === 'bridge-unavailable'
    ? `THEO could not open ${what}: its connection to Claude Code is not active, so the click had nothing to talk to. ` +
        `The notice at the top of the THEO sidebar gives the cause when THEO knows it: a Claude Code update THEO does not support yet, or a Claude Code folder THEO cannot write to.`
    : `THEO could not open ${what}: ${failure}`;
}

function reportClaudeOpenFailure(sessionId, title, failure) {
  const now = Date.now();
  const last = Number(claudeOpenFailureShownAt.get(sessionId) || 0);
  if (now - last < CLAUDE_OPEN_FAILURE_COOLDOWN_MS) {
    return false;
  }
  claudeOpenFailureShownAt.set(sessionId, now);
  if (claudeOpenFailureShownAt.size > 200) {
    claudeOpenFailureShownAt.clear();
    claudeOpenFailureShownAt.set(sessionId, now);
  }
  try {
    vscode.window
      .showWarningMessage(describeClaudeOpenFailure(title, failure))
      .then(
        () => {},
        () => {}
      );
  } catch {}
  return true;
}

async function ensureClaudeExtensionActivated() {
  try {
    const claudeExt = vscode.extensions?.getExtension?.('anthropic.claude-code');
    if (claudeExt && !claudeExt.isActive && typeof claudeExt.activate === 'function') {
      await claudeExt.activate();
    }
  } catch {}
}

class SessionTabManager {
  async getOpenAntigravityTabs() {
    try {
      const directAgy = getDirectAgyBridge();
      const bridgeTabs = directAgy?.getOpenTabsSnapshot
        ? directAgy.getOpenTabsSnapshot()
        : await vscode.commands.executeCommand('antigravityHub.getOpenTabs');
      if (Array.isArray(bridgeTabs)) {
        return bridgeTabs.map((t) => ({ ...t, provider: 'antigravity' }));
      }
    } catch {}

    const tabs = [];
    const groups = vscode.window.tabGroups?.all || [];
    for (const group of groups) {
      for (const tab of group.tabs || []) {
        const uri = tab?.input?.uri;
        if (!uri || uri.scheme !== SESSION_TAB_SCHEME) {
          continue;
        }
        const uriKey = normalizeUriKey(uri);
        const parsed = parseSessionUri(uriKey);
        tabs.push({
          uri: uriKey,
          id: parsed.kind === 'thread' ? parsed.threadId : '',
          provider: 'antigravity',
          title: tab.label || 'Antigravity',
          active: Boolean(tab.isActive && group.isActive),
          visible: Boolean(tab.isActive),
          viewColumn: group.viewColumn || 1
        });
      }
    }
    return tabs;
  }

  async getOpenClaudeTabs() {
    try {
      const directClaude = getDirectClaudeBridge();
      if (directClaude?.getOpenClaudeTabsSnapshot) {
        const directTabs = directClaude.getOpenClaudeTabsSnapshot();
        if (Array.isArray(directTabs)) {
          return directTabs.map((t) => ({ ...t, provider: 'claude' }));
        }
      }
      const status = await vscode.commands.executeCommand('antigravityHub.claudeBridgeStatus');
      if (status && Array.isArray(status.openTabs)) {
        return status.openTabs.map((t) => ({ ...t, provider: 'claude' }));
      }
    } catch {}

    const tabs = [];
    const groups = vscode.window.tabGroups?.all || [];
    let idx = 0;
    for (const group of groups) {
      for (const tab of group.tabs || []) {
        const viewType = String(tab?.input?.viewType || '');
        if (!viewType.includes('claudeVSCodePanel')) {
          continue;
        }
        idx += 1;
        tabs.push({
          uri: `${CLAUDE_DRAFT_SCHEME}://fallback/${idx}`,
          id: '',
          provider: 'claude',
          title: tab.label || 'Claude Code',
          active: Boolean(tab.isActive && group.isActive),
          visible: Boolean(tab.isActive),
          viewColumn: group.viewColumn || 1
        });
      }
    }
    return tabs;
  }

  async getOpenTabs() {
    const [agyTabs, claudeTabs] = await Promise.all([
      this.getOpenAntigravityTabs(),
      this.getOpenClaudeTabs()
    ]);
    const combined = [...agyTabs, ...claudeTabs];
    const groups = Array.isArray(vscode?.window?.tabGroups?.all)
      ? vscode.window.tabGroups.all
      : [];
    if (groups.length > 0) {
      const activeGroup =
        vscode?.window?.tabGroups?.activeTabGroup ||
        groups.find((g) => Boolean(g?.isActive)) ||
        (groups.length === 1 ? groups[0] : null);
      const activeTabs = Array.isArray(activeGroup?.tabs) ? activeGroup.tabs : [];
      const activeTab =
        activeGroup?.activeTab || activeTabs.find((t) => Boolean(t?.isActive)) || null;
      if (activeGroup && activeTab) {
        const activeCol = activeGroup.viewColumn || 1;
        const scheme = activeTab?.input?.uri?.scheme || '';
        const viewType = String(activeTab?.input?.viewType || '');
        if (scheme === SESSION_TAB_SCHEME) {
          const activeUriKey = normalizeUriKey(activeTab.input.uri);
          const hasMatchingItem = Boolean(
            activeUriKey &&
              combined.some(
                (item) =>
                  item &&
                  item.provider !== 'claude' &&
                  item.uri &&
                  normalizeUriKey(item.uri) === activeUriKey
              )
          );
          if (hasMatchingItem) {
            let assigned = false;
            for (const item of combined) {
              if (!item) continue;
              const isMatch =
                !assigned &&
                item.provider !== 'claude' &&
                Boolean(item.uri) &&
                normalizeUriKey(item.uri) === activeUriKey;
              item.active = isMatch;
              if (isMatch) {
                item.visible = true;
                assigned = true;
              }
            }
          } else {
            for (const item of combined) {
              if (item) item.active = false;
            }
          }
        } else if (viewType.includes('claudeVSCodePanel')) {
          for (const item of combined) {
            if (item && item.provider !== 'claude') {
              item.active = false;
            }
          }
          const claudeItems = combined.filter((item) => item && item.provider === 'claude');
          const activeClaudeItems = claudeItems.filter((item) => Boolean(item.active));
          const activeLabel = String(activeTab.label || '');
          if (activeClaudeItems.length !== 1) {
            const visibleInCol = claudeItems.filter(
              (item) => Boolean(item.visible) && (item.viewColumn || 1) === activeCol
            );
            const chosen =
              (activeLabel &&
                (visibleInCol.find((item) => item.title === activeLabel) ||
                  claudeItems.find(
                    (item) => (item.viewColumn || 1) === activeCol && item.title === activeLabel
                  ))) ||
              (visibleInCol.length === 1 ? visibleInCol[0] : activeClaudeItems[0] || null);
            for (const item of claudeItems) {
              item.active = Boolean(chosen && item === chosen);
              if (chosen && item === chosen) {
                item.visible = true;
              }
            }
          }
        } else {
          // A regular editor (code file, diff, settings) is active in the active editor group
          for (const item of combined) {
            if (item) item.active = false;
          }
        }
      }
    }
    return combined;
  }

  async openNewSession(options = {}) {
    const provider = options.provider === 'claude' ? 'claude' : 'antigravity';
    const defaultLoc = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('defaultOpenLocation', 'editor');
    const beside = Boolean(options.beside || defaultLoc === 'beside');

    if (provider === 'claude') {
      await ensureClaudeExtensionActivated();
      try {
        const directClaude = getDirectClaudeBridge();
        const openOpts = {
          newSession: true,
          beside,
          preserveFocus: Boolean(options.preserveFocus)
        };
        const res = directClaude?.openClaudeTab
          ? await directClaude.openClaudeTab(openOpts)
          : await vscode.commands.executeCommand('antigravityHub.claudeOpenTab', openOpts);
        if (res) {
          return { ...res, provider: 'claude' };
        }
      } catch {}

      try {
        await vscode.commands.executeCommand('claude-vscode.editor.open');
      } catch {}
      return { uri: `${CLAUDE_DRAFT_SCHEME}://draft/${Date.now()}`, provider: 'claude' };
    }

    try {
      const directAgy = getDirectAgyBridge();
      const openOpts = {
        newSession: true,
        beside
      };
      const res = directAgy?.openNewSessionTab
        ? await directAgy.openNewSessionTab(openOpts)
        : await vscode.commands.executeCommand('antigravityHub.openTab', openOpts);
      if (res) {
        return { ...res, provider: 'antigravity' };
      }
    } catch {}

    const uri = vscode.Uri.parse(buildNewSessionUriString(`${Date.now()}`));
    await vscode.commands.executeCommand('vscode.openWith', uri, SESSION_TAB_VIEW_TYPE, {
      viewColumn: beside ? vscode.ViewColumn.Beside : vscode.ViewColumn.Active || vscode.ViewColumn.One,
      preview: false
    });
    return { uri: uri.toString(), provider: 'antigravity' };
  }

  async openThread(threadId, options = {}) {
    const cleanId = String(threadId || '').trim();
    const provider = options.provider === 'claude' ? 'claude' : 'antigravity';
    if (!cleanId) {
      return this.openNewSession({ ...options, provider });
    }
    this.touchTabActivity({ id: cleanId, provider });

    const defaultLoc = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('defaultOpenLocation', 'editor');
    const beside = Boolean(options.beside || defaultLoc === 'beside');

    if (provider === 'claude') {
      await ensureClaudeExtensionActivated();
      // A null result means the Claude Code bridge is not attached (no controller), and when it never
      // attached the fallback command is not even registered. The click used to vanish without a trace
      // (Claude Code 2.1.327, 2026-11-18), so both are reported as the same plain cause.
      let failure = 'bridge-unavailable';
      try {
        const directClaude = getDirectClaudeBridge();
        const openOpts = {
          id: cleanId,
          title: options.title || '',
          beside,
          preserveFocus: Boolean(options.preserveFocus)
        };
        const res = directClaude?.openClaudeTab
          ? await directClaude.openClaudeTab(openOpts)
          : await vscode.commands.executeCommand('antigravityHub.claudeOpenTab', openOpts);
        if (res) {
          return { ...res, provider: 'claude' };
        }
      } catch (err) {
        const msg = String(err?.message || err || 'unknown error');
        failure = /command '[^']*' not found/i.test(msg) ? 'bridge-unavailable' : msg;
        console.error('[THEO] Opening Claude session failed:', err);
      }
      if (!options.automatic) {
        reportClaudeOpenFailure(cleanId, options.title || '', failure);
      }
      return { id: cleanId, provider: 'claude', failed: true, reason: failure };
    }

    try {
      const directAgy = getDirectAgyBridge();
      const openOpts = {
        id: cleanId,
        title: options.title || '',
        beside,
        preserveFocus: Boolean(options.preserveFocus)
      };
      const res = directAgy?.openConversationTab
        ? await directAgy.openConversationTab(openOpts)
        : await vscode.commands.executeCommand('antigravityHub.openTab', openOpts);
      if (res) {
        return { ...res, provider: 'antigravity' };
      }
    } catch {}

    const uri = vscode.Uri.parse(buildThreadUriString(cleanId));
    await vscode.commands.executeCommand('vscode.openWith', uri, SESSION_TAB_VIEW_TYPE, {
      viewColumn: beside ? vscode.ViewColumn.Beside : vscode.ViewColumn.Active || vscode.ViewColumn.One,
      preview: false,
      preserveFocus: Boolean(options.preserveFocus)
    });
    return { uri: uri.toString(), id: cleanId, provider: 'antigravity' };
  }

  async focusDraftTab(uriKey, options = {}) {
    const key = String(uriKey || '').trim();
    if (!key) {
      return false;
    }
    if (key.startsWith(`${CLAUDE_DRAFT_SCHEME}://`)) {
      try {
        const directClaude = getDirectClaudeBridge();
        const openOpts = {
          draftUri: key,
          beside: Boolean(options.beside)
        };
        if (directClaude?.openClaudeTab) {
          await directClaude.openClaudeTab(openOpts);
        } else {
          await vscode.commands.executeCommand('antigravityHub.claudeOpenTab', openOpts);
        }
        return true;
      } catch {
        return false;
      }
    }
    try {
      const directAgy = getDirectAgyBridge();
      if (directAgy?.findEntryByUriKey && directAgy?.getBridgeState) {
        const agyState = directAgy.getBridgeState();
        const existingDraft = directAgy.findEntryByUriKey(agyState, key);
        if (existingDraft?.panel) {
          if (typeof directAgy.setOpeningTarget === 'function') {
            directAgy.setOpeningTarget(agyState, {
              threadId: existingDraft.conversationId || '',
              uriKey: existingDraft.uriKey || key
            });
          }
          existingDraft.panel.reveal(
            options.beside
              ? vscode.ViewColumn.Beside
              : existingDraft.panel.viewColumn || vscode.ViewColumn.One,
            false
          );
          return true;
        }
      }
      const uri = vscode.Uri.parse(key);
      await vscode.commands.executeCommand('vscode.openWith', uri, SESSION_TAB_VIEW_TYPE, {
        viewColumn: options.beside
          ? vscode.ViewColumn.Beside
          : vscode.window.tabGroups?.activeTabGroup?.viewColumn || vscode.ViewColumn.One,
        preview: false
      });
      return true;
    } catch {
      return false;
    }
  }

  async syncTabTitle(threadId, title, provider = '') {
    let ok = false;
    if (!provider || provider === 'antigravity') {
      try {
        ok = Boolean(
          await vscode.commands.executeCommand('antigravityHub.syncTabTitle', {
            id: threadId,
            title
          })
        );
      } catch {}
    }
    if (!provider || provider === 'claude') {
      try {
        const cOk = await vscode.commands.executeCommand('antigravityHub.claudeRenameSession', {
          id: threadId,
          title,
          skipCli: true
        });
        ok = ok || Boolean(cOk);
      } catch {}
    }
    return ok;
  }

  async syncTabBadges(badgesById) {
    try {
      const directAgy = getDirectAgyBridge();
      const directClaude = getDirectClaudeBridge();
      const tasks = [];
      if (directAgy?.syncTabBadges) {
        directAgy.syncTabBadges(badgesById);
      } else {
        tasks.push(vscode.commands.executeCommand('antigravityHub.syncTabBadges', badgesById));
      }
      if (directClaude?.syncClaudeTabBadges) {
        directClaude.syncClaudeTabBadges(badgesById);
      } else {
        tasks.push(vscode.commands.executeCommand('antigravityHub.claudeSyncTabBadges', badgesById));
      }
      if (tasks.length > 0) {
        await Promise.allSettled(tasks);
      }
      return true;
    } catch {
      return false;
    }
  }

  async closeThreadTab(threadId, options = {}) {
    const cleanId = String(threadId || '').trim();
    const key = String(options.key || options.uri || '').trim();
    const provider = options.provider === 'claude' || options.provider === 'antigravity' ? options.provider : '';
    let closed = false;

    if ((!provider || provider === 'claude') && (cleanId || key.startsWith(`${CLAUDE_DRAFT_SCHEME}://`))) {
      try {
        const cClosed = await vscode.commands.executeCommand('antigravityHub.claudeCloseTab', {
          id: cleanId,
          uri: key
        });
        closed = closed || Boolean(cClosed);
      } catch {}
    }

    if ((!provider || provider === 'antigravity') && (cleanId || key.startsWith(`${SESSION_TAB_SCHEME}://`))) {
      try {
        const aClosed = await vscode.commands.executeCommand('antigravityHub.closeTab', {
          id: cleanId,
          uri: key
        });
        closed = closed || Boolean(aClosed);
      } catch {}
    }

    if (!closed && key) {
      const normKey = normalizeUriKey(key);
      for (const group of vscode.window.tabGroups?.all || []) {
        for (const tab of group.tabs || []) {
          const tabUri = tab?.input?.uri;
          if (
            tabUri?.toString() === key ||
            (normKey && normalizeUriKey(tabUri) === normKey)
          ) {
            await vscode.window.tabGroups.close(tab);
            closed = true;
          }
        }
      }
    }

    return closed;
  }

  async getPrewarmedTabs() {
    const items = [];
    try {
      const directAgy = getDirectAgyBridge();
      const agyWarm = directAgy?.getPrewarmedTabsSnapshot
        ? directAgy.getPrewarmedTabsSnapshot()
        : await vscode.commands.executeCommand('antigravityHub.getPrewarmedTabs');
      if (Array.isArray(agyWarm)) {
        for (const t of agyWarm) {
          if (t && t.id) items.push({ ...t, provider: 'antigravity' });
        }
      }
    } catch {}
    try {
      const directClaude = getDirectClaudeBridge();
      const claudeWarm = directClaude?.getPrewarmedClaudeTabsSnapshot
        ? directClaude.getPrewarmedClaudeTabsSnapshot()
        : await vscode.commands.executeCommand('antigravityHub.claudeGetPrewarmedTabs');
      if (Array.isArray(claudeWarm)) {
        for (const t of claudeWarm) {
          if (t && t.id) items.push({ ...t, provider: 'claude' });
        }
      }
    } catch {}
    return items;
  }

  async prewarmThread(threadId, options = {}) {
    const cleanId = String(threadId || '').trim();
    if (!cleanId) return null;
    const provider = options.provider === 'claude' ? 'claude' : 'antigravity';
    if (provider === 'claude') {
      try {
        const directClaude = getDirectClaudeBridge();
        const openOpts = {
          id: cleanId,
          title: options.title || '',
          preserveFocus: true,
          prewarm: true
        };
        if (options.viewColumn != null) openOpts.viewColumn = options.viewColumn;
        const res = directClaude?.openClaudeTab
          ? await directClaude.openClaudeTab(openOpts)
          : await vscode.commands.executeCommand('antigravityHub.claudeOpenTab', openOpts);
        return res ? { ...res, provider: 'claude' } : null;
      } catch {
        return null;
      }
    }
    try {
      const directAgy = getDirectAgyBridge();
      const openOpts = {
        id: cleanId,
        title: options.title || '',
        preserveFocus: true,
        prewarm: true
      };
      if (options.viewColumn != null) openOpts.viewColumn = options.viewColumn;
      const res = directAgy?.openConversationTab
        ? await directAgy.openConversationTab(openOpts)
        : await vscode.commands.executeCommand('antigravityHub.openTab', openOpts);
      return res ? { ...res, provider: 'antigravity' } : null;
    } catch {
      return null;
    }
  }

  async closePrewarmedTab(threadId, options = {}) {
    const cleanId = String(threadId || '').trim();
    const provider = options.provider || '';
    let closed = false;
    if (!provider || provider === 'claude') {
      try {
        const directClaude = getDirectClaudeBridge();
        const cClosed = directClaude?.closeClaudeTab
          ? await directClaude.closeClaudeTab({ id: cleanId, uri: options.uri || '', onlyPrewarmed: true })
          : await vscode.commands.executeCommand('antigravityHub.claudeCloseTab', {
              id: cleanId,
              uri: options.uri || '',
              onlyPrewarmed: true
            });
        closed = closed || Boolean(cClosed);
      } catch {}
    }
    if (!provider || provider === 'antigravity') {
      try {
        const directAgy = getDirectAgyBridge();
        const aClosed = directAgy?.closeConversationTab
          ? await directAgy.closeConversationTab({ id: cleanId, uri: options.uri || '', onlyPrewarmed: true })
          : await vscode.commands.executeCommand('antigravityHub.closeTab', {
              id: cleanId,
              uri: options.uri || '',
              onlyPrewarmed: true
            });
        closed = closed || Boolean(aClosed);
      } catch {}
    }
    return closed;
  }

  async warmRecentSessions(threadIds = [], options = {}) {
    try {
      const directAgy = getDirectAgyBridge();
      const opts = { threadIds: Array.isArray(threadIds) ? threadIds : [], ...options };
      if (directAgy?.warmRecentAntigravitySessions) {
        return await directAgy.warmRecentAntigravitySessions(opts);
      }
      return await vscode.commands.executeCommand('antigravityHub.warmRecentSessions', opts);
    } catch {
      return { ok: false };
    }
  }

  async getLastConversationId() {
    try {
      return (await vscode.commands.executeCommand('antigravityHub.getLastConversationId')) || '';
    } catch {
      return '';
    }
  }

  getAutoParkActivityMap() {
    return getAutoParkStateStore().byKey;
  }

  touchTabActivity(tabOrRef, nowMs = Date.now()) {
    const key =
      typeof tabOrRef === 'string' ? tabOrRef : makeAutoParkTabKey(tabOrRef);
    if (!key) return;
    const byKey = this.getAutoParkActivityMap();
    const existing = byKey.get(key);
    const ts = Number(nowMs) || Date.now();
    if (existing) {
      existing.lastActiveAt = Math.max(Number(existing.lastActiveAt || 0), ts);
      existing.lastSeenAt = ts;
    } else {
      byKey.set(key, { openedAt: ts, lastActiveAt: ts, lastSeenAt: ts });
    }
  }

  recordOpenTabsActivity(openTabs = [], nowMs = Date.now()) {
    const byKey = this.getAutoParkActivityMap();
    const ts = Number(nowMs) || Date.now();
    const liveKeys = new Set();
    for (const tab of Array.isArray(openTabs) ? openTabs : []) {
      const key = makeAutoParkTabKey(tab);
      if (!key) continue;
      liveKeys.add(key);
      const existing = byKey.get(key);
      if (!existing) {
        byKey.set(key, { openedAt: ts, lastActiveAt: ts, lastSeenAt: ts });
      } else {
        existing.lastSeenAt = ts;
        if (tab.active || tab.visible) {
          existing.lastActiveAt = Math.max(Number(existing.lastActiveAt || 0), ts);
        }
      }
    }
    for (const [key, rec] of byKey.entries()) {
      if (!liveKeys.has(key) && ts - Number(rec?.lastSeenAt || 0) > AUTO_PARK_ABSENT_PRUNE_MS) {
        byKey.delete(key);
      }
    }
    return byKey;
  }
}

module.exports = {
  SessionTabManager,
  describeClaudeOpenFailure,
  reportClaudeOpenFailure,
  makeAutoParkTabKey,
  collectTabGroupsProtectionSnapshot,
  isTabProtectedInLiveTabGroups,
  evaluateAutoParkTabCandidates,
  DEFAULT_AUTO_PARK_IDLE_MINUTES,
  DEFAULT_AUTO_PARK_KEEP_RECENT
};
