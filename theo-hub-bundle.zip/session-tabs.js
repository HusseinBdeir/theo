const vscode = require('vscode');
const {
  SESSION_TAB_SCHEME,
  SESSION_TAB_VIEW_TYPE,
  buildNewSessionUriString,
  buildThreadUriString,
  parseSessionUri,
  normalizeUriKey
} = require('./compat/antigravity-tab-state.cjs');
const { CLAUDE_DRAFT_SCHEME } = require('./compat/claude-hub-bridge.cjs');

function getDirectAgyBridge() {
  try {
    const mod = require('./compat/antigravity-hub-bridge.cjs');
    const st = mod?.getBridgeState?.();
    if (st && (st.attached || st.context || st.apiImpl) && st.vscode === vscode) {
      return mod;
    }
  } catch {}
  return null;
}

function getDirectClaudeBridge() {
  try {
    const mod = require('./compat/claude-hub-bridge.cjs');
    const st = mod?.getBridgeState?.();
    if (st && st.attached && st.vscode === vscode) {
      return mod;
    }
  } catch {}
  return null;
}

async function ensureClaudeExtensionActivated() {
  try {
    const claudeExt = vscode.extensions?.getExtension?.('anthropic.claude-code');
    if (claudeExt && !claudeExt.isActive && typeof claudeExt.activate === 'function') {
      await claudeExt.activate();
    }
  } catch {}
}

class SessionTabManager {
  async getOpenAntigravityTabs() {
    try {
      const directAgy = getDirectAgyBridge();
      const bridgeTabs = directAgy?.getOpenTabsSnapshot
        ? directAgy.getOpenTabsSnapshot()
        : await vscode.commands.executeCommand('antigravityHub.getOpenTabs');
      if (Array.isArray(bridgeTabs)) {
        return bridgeTabs.map((t) => ({ ...t, provider: 'antigravity' }));
      }
    } catch {}

    const tabs = [];
    const groups = vscode.window.tabGroups?.all || [];
    for (const group of groups) {
      for (const tab of group.tabs || []) {
        const uri = tab?.input?.uri;
        if (!uri || uri.scheme !== SESSION_TAB_SCHEME) {
          continue;
        }
        const uriKey = normalizeUriKey(uri);
        const parsed = parseSessionUri(uriKey);
        tabs.push({
          uri: uriKey,
          id: parsed.kind === 'thread' ? parsed.threadId : '',
          provider: 'antigravity',
          title: tab.label || 'Antigravity',
          active: Boolean(tab.isActive && group.isActive),
          visible: Boolean(tab.isActive),
          viewColumn: group.viewColumn || 1
        });
      }
    }
    return tabs;
  }

  async getOpenClaudeTabs() {
    try {
      const directClaude = getDirectClaudeBridge();
      if (directClaude?.getOpenClaudeTabsSnapshot) {
        const directTabs = directClaude.getOpenClaudeTabsSnapshot();
        if (Array.isArray(directTabs)) {
          return directTabs.map((t) => ({ ...t, provider: 'claude' }));
        }
      }
      const status = await vscode.commands.executeCommand('antigravityHub.claudeBridgeStatus');
      if (status && Array.isArray(status.openTabs)) {
        return status.openTabs.map((t) => ({ ...t, provider: 'claude' }));
      }
    } catch {}

    const tabs = [];
    const groups = vscode.window.tabGroups?.all || [];
    let idx = 0;
    for (const group of groups) {
      for (const tab of group.tabs || []) {
        const viewType = String(tab?.input?.viewType || '');
        if (!viewType.includes('claudeVSCodePanel')) {
          continue;
        }
        idx += 1;
        tabs.push({
          uri: `${CLAUDE_DRAFT_SCHEME}://fallback/${idx}`,
          id: '',
          provider: 'claude',
          title: tab.label || 'Claude Code',
          active: Boolean(tab.isActive && group.isActive),
          visible: Boolean(tab.isActive),
          viewColumn: group.viewColumn || 1
        });
      }
    }
    return tabs;
  }

  async getOpenTabs() {
    const [agyTabs, claudeTabs] = await Promise.all([
      this.getOpenAntigravityTabs(),
      this.getOpenClaudeTabs()
    ]);
    const combined = [...agyTabs, ...claudeTabs];
    const groups = vscode?.window?.tabGroups?.all || [];
    if (groups.length > 0 && combined.filter((t) => Boolean(t?.active)).length > 1) {
      const activeByCol = new Map();
      for (const group of groups) {
        const tabs = Array.isArray(group?.tabs) ? group.tabs : [];
        const activeTab = tabs.find((t) => Boolean(t?.isActive)) || group?.activeTab || null;
        if (!activeTab) continue;
        const col = group.viewColumn || 1;
        const scheme = activeTab?.input?.uri?.scheme || '';
        const viewType = String(activeTab?.input?.viewType || '');
        activeByCol.set(col, {
          groupActive: Boolean(group.isActive),
          provider:
            scheme === SESSION_TAB_SCHEME
              ? 'antigravity'
              : viewType.includes('claudeVSCodePanel')
                ? 'claude'
                : 'other',
          uriKey: scheme === SESSION_TAB_SCHEME ? normalizeUriKey(activeTab.input.uri) : ''
        });
      }
      for (const item of combined) {
        if (!item?.active) continue;
        const colInfo = activeByCol.get(item.viewColumn || 1);
        if (!colInfo) continue;
        const itemProvider = item.provider === 'claude' ? 'claude' : 'antigravity';
        if (
          !colInfo.groupActive ||
          colInfo.provider !== itemProvider ||
          (itemProvider === 'antigravity' &&
            colInfo.uriKey &&
            item.uri &&
            normalizeUriKey(item.uri) !== colInfo.uriKey)
        ) {
          item.active = false;
        }
      }
    }
    return combined;
  }

  async openNewSession(options = {}) {
    const provider = options.provider === 'claude' ? 'claude' : 'antigravity';
    const defaultLoc = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('defaultOpenLocation', 'editor');
    const beside = Boolean(options.beside || defaultLoc === 'beside');

    if (provider === 'claude') {
      await ensureClaudeExtensionActivated();
      try {
        const directClaude = getDirectClaudeBridge();
        const openOpts = {
          newSession: true,
          beside,
          preserveFocus: Boolean(options.preserveFocus)
        };
        const res = directClaude?.openClaudeTab
          ? await directClaude.openClaudeTab(openOpts)
          : await vscode.commands.executeCommand('antigravityHub.claudeOpenTab', openOpts);
        if (res) {
          return { ...res, provider: 'claude' };
        }
      } catch {}

      try {
        await vscode.commands.executeCommand('claude-vscode.editor.open');
      } catch {}
      return { uri: `${CLAUDE_DRAFT_SCHEME}://draft/${Date.now()}`, provider: 'claude' };
    }

    try {
      const directAgy = getDirectAgyBridge();
      const openOpts = {
        newSession: true,
        beside
      };
      const res = directAgy?.openNewSessionTab
        ? await directAgy.openNewSessionTab(openOpts)
        : await vscode.commands.executeCommand('antigravityHub.openTab', openOpts);
      if (res) {
        return { ...res, provider: 'antigravity' };
      }
    } catch {}

    const uri = vscode.Uri.parse(buildNewSessionUriString(`${Date.now()}`));
    await vscode.commands.executeCommand('vscode.openWith', uri, SESSION_TAB_VIEW_TYPE, {
      viewColumn: beside ? vscode.ViewColumn.Beside : vscode.ViewColumn.Active || vscode.ViewColumn.One,
      preview: false
    });
    return { uri: uri.toString(), provider: 'antigravity' };
  }

  async openThread(threadId, options = {}) {
    const cleanId = String(threadId || '').trim();
    const provider = options.provider === 'claude' ? 'claude' : 'antigravity';
    if (!cleanId) {
      return this.openNewSession({ ...options, provider });
    }

    const defaultLoc = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('defaultOpenLocation', 'editor');
    const beside = Boolean(options.beside || defaultLoc === 'beside');

    if (provider === 'claude') {
      await ensureClaudeExtensionActivated();
      try {
        const directClaude = getDirectClaudeBridge();
        const openOpts = {
          id: cleanId,
          title: options.title || '',
          beside,
          preserveFocus: Boolean(options.preserveFocus)
        };
        const res = directClaude?.openClaudeTab
          ? await directClaude.openClaudeTab(openOpts)
          : await vscode.commands.executeCommand('antigravityHub.claudeOpenTab', openOpts);
        if (res) {
          return { ...res, provider: 'claude' };
        }
      } catch {}
      return { id: cleanId, provider: 'claude' };
    }

    try {
      const directAgy = getDirectAgyBridge();
      const openOpts = {
        id: cleanId,
        title: options.title || '',
        beside,
        preserveFocus: Boolean(options.preserveFocus)
      };
      const res = directAgy?.openConversationTab
        ? await directAgy.openConversationTab(openOpts)
        : await vscode.commands.executeCommand('antigravityHub.openTab', openOpts);
      if (res) {
        return { ...res, provider: 'antigravity' };
      }
    } catch {}

    const uri = vscode.Uri.parse(buildThreadUriString(cleanId));
    await vscode.commands.executeCommand('vscode.openWith', uri, SESSION_TAB_VIEW_TYPE, {
      viewColumn: beside ? vscode.ViewColumn.Beside : vscode.ViewColumn.Active || vscode.ViewColumn.One,
      preview: false,
      preserveFocus: Boolean(options.preserveFocus)
    });
    return { uri: uri.toString(), id: cleanId, provider: 'antigravity' };
  }

  async focusDraftTab(uriKey, options = {}) {
    const key = String(uriKey || '').trim();
    if (!key) {
      return false;
    }
    if (key.startsWith(`${CLAUDE_DRAFT_SCHEME}://`)) {
      try {
        const directClaude = getDirectClaudeBridge();
        const openOpts = {
          draftUri: key,
          beside: Boolean(options.beside)
        };
        if (directClaude?.openClaudeTab) {
          await directClaude.openClaudeTab(openOpts);
        } else {
          await vscode.commands.executeCommand('antigravityHub.claudeOpenTab', openOpts);
        }
        return true;
      } catch {
        return false;
      }
    }
    try {
      const directAgy = getDirectAgyBridge();
      if (directAgy?.findEntryByUriKey && directAgy?.getBridgeState) {
        const agyState = directAgy.getBridgeState();
        const existingDraft = directAgy.findEntryByUriKey(agyState, key);
        if (existingDraft?.panel) {
          if (typeof directAgy.setOpeningTarget === 'function') {
            directAgy.setOpeningTarget(agyState, {
              threadId: existingDraft.conversationId || '',
              uriKey: existingDraft.uriKey || key
            });
          }
          existingDraft.panel.reveal(
            options.beside
              ? vscode.ViewColumn.Beside
              : existingDraft.panel.viewColumn || vscode.ViewColumn.One,
            false
          );
          return true;
        }
      }
      const uri = vscode.Uri.parse(key);
      await vscode.commands.executeCommand('vscode.openWith', uri, SESSION_TAB_VIEW_TYPE, {
        viewColumn: options.beside
          ? vscode.ViewColumn.Beside
          : vscode.window.tabGroups?.activeTabGroup?.viewColumn || vscode.ViewColumn.One,
        preview: false
      });
      return true;
    } catch {
      return false;
    }
  }

  async syncTabTitle(threadId, title, provider = '') {
    let ok = false;
    if (!provider || provider === 'antigravity') {
      try {
        ok = Boolean(
          await vscode.commands.executeCommand('antigravityHub.syncTabTitle', {
            id: threadId,
            title
          })
        );
      } catch {}
    }
    if (!provider || provider === 'claude') {
      try {
        const cOk = await vscode.commands.executeCommand('antigravityHub.claudeRenameSession', {
          id: threadId,
          title,
          skipCli: true
        });
        ok = ok || Boolean(cOk);
      } catch {}
    }
    return ok;
  }

  async syncTabBadges(badgesById) {
    try {
      const directAgy = getDirectAgyBridge();
      const directClaude = getDirectClaudeBridge();
      const tasks = [];
      if (directAgy?.syncTabBadges) {
        directAgy.syncTabBadges(badgesById);
      } else {
        tasks.push(vscode.commands.executeCommand('antigravityHub.syncTabBadges', badgesById));
      }
      if (directClaude?.syncClaudeTabBadges) {
        directClaude.syncClaudeTabBadges(badgesById);
      } else {
        tasks.push(vscode.commands.executeCommand('antigravityHub.claudeSyncTabBadges', badgesById));
      }
      if (tasks.length > 0) {
        await Promise.allSettled(tasks);
      }
      return true;
    } catch {
      return false;
    }
  }

  async closeThreadTab(threadId, options = {}) {
    const cleanId = String(threadId || '').trim();
    const key = String(options.key || options.uri || '').trim();
    let closed = false;

    if (cleanId || key.startsWith(`${CLAUDE_DRAFT_SCHEME}://`)) {
      try {
        const cClosed = await vscode.commands.executeCommand('antigravityHub.claudeCloseTab', {
          id: cleanId,
          uri: key
        });
        closed = closed || Boolean(cClosed);
      } catch {}
    }

    if (cleanId || key.startsWith(`${SESSION_TAB_SCHEME}://`)) {
      try {
        const aClosed = await vscode.commands.executeCommand('antigravityHub.closeTab', {
          id: cleanId,
          uri: key
        });
        closed = closed || Boolean(aClosed);
      } catch {}
    }

    if (!closed && key) {
      const normKey = normalizeUriKey(key);
      for (const group of vscode.window.tabGroups?.all || []) {
        for (const tab of group.tabs || []) {
          const tabUri = tab?.input?.uri;
          if (
            tabUri?.toString() === key ||
            (normKey && normalizeUriKey(tabUri) === normKey)
          ) {
            await vscode.window.tabGroups.close(tab);
            closed = true;
          }
        }
      }
    }

    return closed;
  }

  async getLastConversationId() {
    try {
      return (await vscode.commands.executeCommand('antigravityHub.getLastConversationId')) || '';
    } catch {
      return '';
    }
  }
}

module.exports = {
  SessionTabManager
};
