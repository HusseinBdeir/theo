# THEO — Unified Antigravity & Claude Code Hub (`bhfirms.theo-hub`)

**THEO** is the unified VS Code companion extension for **Google Antigravity** (`google.google-antigravity`) and **Claude Code** (`anthropic.claude-code`) that brings both AI coding assistants into one single, cohesive **THEO** sidebar and middle-editor workflow:

- **Unified Account & Usage** in the left sidebar:
  - Live account cards for both **Antigravity** (`Google AI Pro`) and **Claude Code** (`Claude Max (20x)`)
  - Live quota bars (`Session (5hr)`, `Weekly (7 day)`, `Argon limit` for Antigravity; `Session (5hr)`, `Weekly (7 day)`, `Fable limit` for Claude Code) with reset countdowns
  - `View details` modal with full quota buckets (`Claude & GPT`, `Extra usage ($0 / $100)`), local token activity (`Combined` / `Antigravity` / `Claude Code`, `Today` / `Last 7 days`, daily chart, input/cached/output token breakdown), Activity Bar icon mode toggle, and live dual-bridge status
- **Unified Session Manager**:
  - Dual `+ Antigravity` and `+ Claude Code` new-session bar (and per-group new-session menu)
  - Provider filter pill bar (`All`, `Antigravity`, `Claude`) with live session counts
  - Search, status/tab filters (`Needs input`, `Working`, `Completed`, `Open`, `Closed`), `Active · N` toggle
  - Crisp provider badges (`Antigravity` vs `Claude Code`), custom groups, inline rename (synced to both Antigravity conversation annotations and Claude Code `.jsonl` + open tabs), archive/unarchive, unread badges, and desktop completion alerts
- **Multi-Tab Middle Editor & Bundled Tweaks**:
  - Clicking any Antigravity or Claude Code session opens or reveals its conversation tab in the middle editor (`ViewColumn.One`), allowing sessions from both providers to sit side by side as standard editor tabs
  - Automatically maintains both the Antigravity bridge (`compat/antigravity-hub-bridge.cjs`, `compat/antigravity-context-window.cjs`) and the Claude Code bridge + webview patches (`compat/claude-hub-bridge.cjs`, `compat/claude-webview-patches.cjs`: middle-editor tab pinning, live Context Window pill & breakdown popover beside the model selector, suppressed yellow usage warning banner, suppressed browser-connected banner).

## Known traps

- `compat/antigravity-context-window.cjs` proxies the Antigravity UI and rewrites `/main.js` (exposes the router as `window.__bhfRouter`, flips `trajectoryDebugTools`). The router call argument list changes with Antigravity updates (2026-10-18: `context` + `basepath` appeared); the rewrite must wrap the balanced call, never a fixed shape, or every conversation tab shows "Couldn't load this view". `node test/smoke.test.cjs` covers it; after any compat edit run `python install_local.py`, then Developer: Reload Window (the extension host caches the patched bundle per upstream origin).
- `compat/claude-webview-patches.cjs` uses `.orig` backups (`extension.js.orig` and `webview/index.js.orig`) and the exact markers (`/*bhf-pin*/`, `/*bhf-nowarn*/`, `/*bhf-nobrowserbanner*/`, `/*bhf-context-window*/`) so `~/.claude/hooks/claude-panel-pin.sh` recognizes the bundle as already patched and never triggers duplicate reload toasts.
- `extension.js` `activate()` must never await Claude Code's activation or the bridge file maintenance before attaching the sidebar and running the first refresh (2026-10-20: Claude Code took 102 s to activate after a cold boot and THEO stayed empty that long). Phase timings of every start go to `~/.claude/.theo-hub-activation.log`.
- `compat/antigravity-hub-bridge.cjs` reuses a saved `agy --hub` only when it answers `GetUserStatus` (`decideSavedHubReuse`): after a reboot the saved pid can belong to another process, and reusing the dead port shows "Couldn't load this view" in every Antigravity tab.
