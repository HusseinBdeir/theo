const os = require('os');
const path = require('path');
const { SESSION_TAB_SCHEME, normalizeUriKey } = require('./compat/antigravity-tab-state.cjs');

function lookupDraftGroup(draftGroups, uri, validGroupIds) {
  if (!draftGroups || typeof draftGroups.get !== 'function' || !uri) {
    return null;
  }
  const raw = String(uri).trim();
  if (!raw) {
    return null;
  }
  let gid = draftGroups.get(raw);
  if (!gid && raw.startsWith(`${SESSION_TAB_SCHEME}://`)) {
    const norm = normalizeUriKey(raw);
    if (norm && norm !== raw) {
      gid = draftGroups.get(norm);
    }
  }
  const cleanGid = String(gid || '').trim();
  if (!cleanGid || cleanGid === 'ungrouped') {
    return null;
  }
  if (validGroupIds instanceof Set && !validGroupIds.has(cleanGid)) {
    return null;
  }
  return cleanGid;
}

function getDefaultAntigravityHome() {
  return path.join(os.homedir(), '.gemini', 'antigravity');
}

function getDefaultClaudeHome() {
  return path.join(os.homedir(), '.claude');
}

function getDefaultClaudeConfigPath() {
  return path.join(os.homedir(), '.claude.json');
}

function cleanText(value, maxLength = 200) {
  const clean = String(value || '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!clean) {
    return '';
  }
  return clean.length > maxLength ? `${clean.slice(0, maxLength - 1)}…` : clean;
}

function parseIsoToEpochSeconds(value) {
  if (!value) {
    return 0;
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value > 1e11 ? Math.floor(value / 1000) : Math.floor(value);
  }
  const ms = Date.parse(String(value));
  return Number.isFinite(ms) ? Math.floor(ms / 1000) : 0;
}

function fileUriToPath(uriString) {
  const raw = String(uriString || '').trim();
  if (!raw) {
    return '';
  }
  if (!raw.startsWith('file://')) {
    return raw;
  }
  try {
    const parsed = new URL(raw);
    let pathname = decodeURIComponent(parsed.pathname || '');
    if (/^\/[a-zA-Z]:/.test(pathname)) {
      pathname = pathname.slice(1);
    }
    return pathname.replace(/\//g, path.sep);
  } catch {
    return raw.replace(/^file:\/\/\/?/, '');
  }
}

function normalizePathForCompare(inputPath) {
  const clean = fileUriToPath(inputPath);
  if (!clean) {
    return '';
  }
  return clean
    .replace(/^\\\\\?\\/, '')
    .replace(/\\/g, '/')
    .replace(/\/+$/, '')
    .toLowerCase()
    .replace(/\/system\/system\/claude(?=\/|$)/, '/system/system/theo');
}

function isClaudeDesktopScratchPath(inputPath) {
  const raw = fileUriToPath(inputPath).replace(/^\\\\\?\\/, '').trim();
  if (!raw) {
    return false;
  }
  const normalized = raw.replace(/\\/g, '/').toLowerCase();
  return (
    normalized.includes('/scratch-workspaces/') ||
    normalized.includes('/appdata/local/claude-data/') ||
    normalized.includes('-scratch-workspaces-') ||
    normalized.includes('-appdata-local-claude-data-') ||
    normalized.endsWith('/scratch-workspaces') ||
    normalized.endsWith('-scratch-workspaces')
  );
}

function formatWorkspaceLabel(cwd) {
  const clean = fileUriToPath(cwd).replace(/^\\\\\?\\/, '');
  if (!clean) {
    return 'No workspace';
  }
  if (isClaudeDesktopScratchPath(clean)) {
    return 'Claude Desktop';
  }
  const parts = clean.split(/[\\/]/).filter(Boolean);
  if (parts.length === 0) {
    return clean;
  }
  const last = parts[parts.length - 1];
  if (last.toLowerCase() === 'claude') {
    return 'THEO';
  }
  if (last.toLowerCase() === 'antigravity-hub') {
    return 'theo-hub';
  }
  return last;
}

function isSameOrChildPath(candidatePath, workspacePath) {
  const candidate = normalizePathForCompare(candidatePath);
  const workspace = normalizePathForCompare(workspacePath);
  if (!candidate || !workspace) {
    return false;
  }
  return (
    candidate === workspace ||
    candidate.startsWith(`${workspace}/`) ||
    workspace.startsWith(`${candidate}/`)
  );
}

function formatRelativeAge(epochSeconds, nowMs = Date.now()) {
  const seconds = Number(epochSeconds || 0);
  if (!seconds) {
    return '';
  }
  const diffSec = Math.max(0, Math.floor(nowMs / 1000) - seconds);
  if (diffSec < 45) {
    return 'now';
  }
  const mins = Math.floor(diffSec / 60);
  if (mins < 60) {
    return `${mins}m`;
  }
  const hours = Math.floor(mins / 60);
  if (hours < 24) {
    return `${hours}h`;
  }
  const days = Math.floor(hours / 24);
  if (days < 30) {
    return `${days}d`;
  }
  const months = Math.floor(days / 30);
  return `${months}mo`;
}

function formatResetCountdown(resetTimeIsoOrSeconds, nowMs = Date.now()) {
  const resetSec = parseIsoToEpochSeconds(resetTimeIsoOrSeconds);
  if (!resetSec) {
    return 'Linear reset window';
  }
  const diffSec = resetSec - Math.floor(nowMs / 1000);
  if (diffSec <= 0) {
    return 'Window idle';
  }
  const totalMinutes = Math.ceil(diffSec / 60);
  const days = Math.floor(totalMinutes / (60 * 24));
  const hours = Math.floor((totalMinutes % (60 * 24)) / 60);
  const minutes = totalMinutes % 60;

  if (days > 0) {
    return hours > 0
      ? `Resets in ${days} day${days === 1 ? '' : 's'} ${hours} hr`
      : `Resets in ${days} day${days === 1 ? '' : 's'}`;
  }
  if (hours > 0) {
    return minutes > 0
      ? `Resets in ${hours} hr ${minutes} min`
      : `Resets in ${hours} hr`;
  }
  return `Resets in ${Math.max(1, minutes)} min`;
}

function normalizeQuotaBucket(bucket, groupName = '', customLabel = '', nowMs = Date.now()) {
  if (!bucket || typeof bucket !== 'object') {
    return null;
  }
  const rawResetAt = parseIsoToEpochSeconds(bucket.resetTime);
  const nowSec = Math.floor(nowMs / 1000);
  const windowExpired = rawResetAt > 0 && rawResetAt <= nowSec;
  const rem = windowExpired
    ? 1
    : typeof bucket.remainingFraction === 'number'
      ? bucket.remainingFraction
      : 1;
  const clampedRem = Math.max(0, Math.min(1, rem));
  const usedPercent = windowExpired
    ? 0
    : Math.max(0, Math.min(100, Math.round((1 - clampedRem) * 100)));
  const remainingPercent = 100 - usedPercent;
  const resetAt = windowExpired ? 0 : rawResetAt;
  const resetText = windowExpired
    ? 'Window idle'
    : bucket.resetTime
      ? formatResetCountdown(bucket.resetTime, nowMs)
      : usedPercent === 0
        ? 'Window idle'
        : 'Linear reset window';

  const isThirdPartyGroup =
    /^3p-/i.test(String(bucket.bucketId || '')) ||
    /claude|gpt|third[- ]party/i.test(`${bucket.bucketId || ''} ${groupName || ''}`);

  let label = customLabel;
  if (!label) {
    if (bucket.bucketId === 'gemini-5h') {
      label = 'Session (5hr)';
    } else if (bucket.bucketId === 'gemini-weekly') {
      label = 'Weekly (7 day)';
    } else if (bucket.bucketId === 'gemini-argon-wtu-weekly' || /argon/i.test(groupName)) {
      label = 'Argon limit';
    } else if (bucket.bucketId === '3p-5h' || (bucket.window === '5h' && isThirdPartyGroup)) {
      label = 'Claude & GPT (5hr)';
    } else if (bucket.bucketId === '3p-weekly' || (bucket.window === 'weekly' && isThirdPartyGroup)) {
      label = 'Claude & GPT (7 day)';
    } else {
      label = `${groupName || 'Quota'} (${bucket.window || bucket.bucketId || 'limit'})`;
    }
  }

  return {
    bucketId: bucket.bucketId || '',
    groupName: groupName || '',
    window: bucket.window || '',
    pool: isThirdPartyGroup ? '3p' : 'gemini',
    label,
    usedPercent,
    remainingPercent,
    remainingFraction: clampedRem,
    resetTime: windowExpired ? '' : bucket.resetTime || '',
    resetAt,
    resetText,
    windowExpired
  };
}

function parseAntigravityQuotaSummary(quotaResponse, nowMs = Date.now()) {
  const rawGroups =
    quotaResponse?.response?.groups ||
    quotaResponse?.quotaSummary?.groups ||
    quotaResponse?.groups;
  const groups = Array.isArray(rawGroups) ? rawGroups : [];
  const allBuckets = [];
  const byId = new Map();

  for (const group of groups) {
    const groupName = String(group?.displayName || group?.groupName || '').trim();
    const buckets = Array.isArray(group?.buckets) ? group.buckets : [];
    for (const rawBucket of buckets) {
      const normalized = normalizeQuotaBucket(rawBucket, groupName, '', nowMs);
      if (normalized) {
        allBuckets.push(normalized);
        if (normalized.bucketId) {
          byId.set(normalized.bucketId, normalized);
        }
      }
    }
  }

  const isThirdPartyBucket = (b) =>
    /^3p-/i.test(b.bucketId) || /claude|gpt|third[- ]party/i.test(`${b.bucketId} ${b.groupName}`);
  const isArgonBucket = (b) => /argon/i.test(b.bucketId) || /argon/i.test(b.groupName);

  const session =
    byId.get('gemini-5h') ||
    allBuckets.find((b) => b.window === '5h' && /gemini/i.test(b.groupName) && !isArgonBucket(b)) ||
    allBuckets.find((b) => b.window === '5h' && !isThirdPartyBucket(b) && !isArgonBucket(b)) ||
    null;

  const weekly =
    byId.get('gemini-weekly') ||
    allBuckets.find((b) => b.window === 'weekly' && /gemini models/i.test(b.groupName) && !isArgonBucket(b)) ||
    allBuckets.find((b) => b.window === 'weekly' && !isThirdPartyBucket(b) && !isArgonBucket(b)) ||
    null;

  const argon =
    byId.get('gemini-argon-wtu-weekly') ||
    allBuckets.find((b) => isArgonBucket(b)) ||
    null;

  const thirdPartySession =
    byId.get('3p-5h') ||
    allBuckets.find((b) => b.window === '5h' && isThirdPartyBucket(b)) ||
    null;

  const thirdPartyWeekly =
    byId.get('3p-weekly') ||
    allBuckets.find((b) => b.window === 'weekly' && isThirdPartyBucket(b)) ||
    null;

  const primaryBars = [];
  if (session) {
    primaryBars.push({ ...session, key: 'session', pool: 'gemini', label: 'Session (5hr)' });
  }
  if (weekly) {
    primaryBars.push({ ...weekly, key: 'weekly', pool: 'gemini', label: 'Weekly (7 day)' });
  }
  if (argon) {
    primaryBars.push({ ...argon, key: 'argon', pool: 'gemini', label: 'Argon limit' });
  }
  if (thirdPartySession) {
    primaryBars.push({ ...thirdPartySession, key: '3p-session', pool: '3p', label: 'Claude & GPT (5hr)' });
  }
  if (thirdPartyWeekly) {
    primaryBars.push({ ...thirdPartyWeekly, key: '3p-weekly', pool: '3p', label: 'Claude & GPT (7 day)' });
  }

  const seenBuckets = new Set(
    [session, weekly, argon, thirdPartySession, thirdPartyWeekly].filter(Boolean)
  );
  const orderedAllBuckets = [
    ...primaryBars.map(({ key: _key, ...rest }) => rest),
    ...allBuckets.filter((b) => !seenBuckets.has(b))
  ];

  const hasResponseEnvelope = Boolean(
    quotaResponse &&
      typeof quotaResponse === 'object' &&
      ('response' in quotaResponse || 'quotaSummary' in quotaResponse || 'groups' in quotaResponse)
  );
  const emptyEnvelopeError =
    primaryBars.length === 0 && hasResponseEnvelope
      ? allBuckets.length > 0
        ? 'No primary quota windows reported for this account tier.'
        : 'No subscription quota windows reported for this account.'
      : undefined;

  const result = {
    available: primaryBars.length > 0,
    source: primaryBars.length > 0 ? 'antigravity-rpc' : 'unavailable',
    session,
    weekly,
    argon,
    thirdPartySession,
    thirdPartyWeekly,
    primaryBars,
    allBuckets: orderedAllBuckets
  };
  if (emptyEnvelopeError) {
    result.error = emptyEnvelopeError;
  }
  return result;
}

function formatAntigravityPlanName(tierName = '', tierId = '', upgradeUri = '') {
  const cleanName = cleanText(tierName, 80) || 'Google AI';
  const id = String(tierId || '').trim().toLowerCase();
  if (/\(\d+x\)/i.test(cleanName)) {
    return cleanName;
  }
  if (id === 'g1-ultra-tier') {
    return `${cleanName} (20x)`;
  }
  if (id === 'g1-ultra-lite-tier') {
    return `${cleanName} (5x)`;
  }
  if (/ultra/i.test(cleanName)) {
    return upgradeUri ? `${cleanName} (5x)` : `${cleanName} (20x)`;
  }
  return cleanName;
}

function parseAntigravityAccountStatus(userStatusResponse) {
  const status = userStatusResponse?.userStatus || userStatusResponse || {};
  const email = cleanText(status.email || '', 120);
  const name = cleanText(status.name || '', 120);
  const tierId = cleanText(status?.userTier?.id || '', 80);
  const upgradeUri = cleanText(status?.userTier?.upgradeSubscriptionUri || '', 200);
  const tierName = cleanText(
    status?.userTier?.name ||
      status?.planStatus?.planInfo?.planName ||
      status?.userTier?.description ||
      '',
    80
  );

  return {
    email: email || 'Local Antigravity Profile',
    name: name || '',
    plan: formatAntigravityPlanName(tierName, tierId, upgradeUri),
    tierId
  };
}

function formatClaudePlanName(subscriptionType = '', rateLimitTier = '') {
  const sub = String(subscriptionType || '').trim().toLowerCase();
  const tier = String(rateLimitTier || '').trim().toLowerCase();
  const multMatch = tier.match(/(\d+x)/i);
  const mult = multMatch ? multMatch[1].toLowerCase() : '';
  const multSuffix = mult ? ` (${mult})` : '';

  // Anthropic renamed the plans on 2026-10-30: Max 20x -> Ultra, Max 5x -> Max. The OAuth
  // credential fields kept the old ids (subscriptionType "max", tier "..._max_20x"), so map them.
  // Ultra's weekly cap is 10x Pro (its 5-hour limit is gone for verified accounts), hence "(10x)".
  if (sub === 'ultra' || tier.includes('ultra') || ((sub === 'max' || tier.includes('max')) && mult === '20x')) {
    return 'Claude Ultra (10x)';
  }
  if (sub === 'max' || tier.includes('max')) {
    return 'Claude Max (5x)';
  }
  if (sub === 'pro' || tier.includes('pro')) {
    return `Claude Pro${multSuffix}`;
  }
  if (sub === 'team' || tier.includes('team')) {
    return 'Claude Team';
  }
  if (sub === 'enterprise' || tier.includes('enterprise')) {
    return 'Claude Enterprise';
  }
  if (sub) {
    return `Claude ${sub.charAt(0).toUpperCase()}${sub.slice(1)}${multSuffix}`;
  }
  return 'Claude Code';
}

function parseClaudeAccountStatus(claudeConfig = {}, credentials = {}) {
  const oauthAccount = claudeConfig?.oauthAccount || {};
  const claudeAiOauth = credentials?.claudeAiOauth || {};

  const email = cleanText(oauthAccount.emailAddress || oauthAccount.email || '', 120);
  const name = cleanText(oauthAccount.displayName || oauthAccount.name || '', 120);
  const subscriptionType =
    claudeAiOauth.subscriptionType || oauthAccount.subscriptionType || '';
  const rateLimitTier = claudeAiOauth.rateLimitTier || oauthAccount.rateLimitTier || '';
  const plan = formatClaudePlanName(subscriptionType, rateLimitTier);
  const hasToken = Boolean(claudeAiOauth.accessToken);

  return {
    email: email || (name ? `${name} (Claude)` : 'Claude Code Profile'),
    name: name || '',
    plan,
    subscriptionType,
    rateLimitTier,
    available: Boolean(email || name || hasToken),
    signedOut: !email && !name && !hasToken
  };
}

function makeClaudeBar(bucketId, label, utilizationPercent, resetsAt, nowMs = Date.now()) {
  const rawResetAt = parseIsoToEpochSeconds(resetsAt);
  const nowSec = Math.floor(nowMs / 1000);
  const windowExpired = rawResetAt > 0 && rawResetAt <= nowSec;
  const pct = windowExpired
    ? 0
    : Math.max(0, Math.min(100, Math.round(Number(utilizationPercent || 0))));
  const remainingPercent = 100 - pct;
  const resetAt = windowExpired ? 0 : rawResetAt;
  const resetText = windowExpired
    ? 'Window idle'
    : resetsAt
      ? formatResetCountdown(resetsAt, nowMs)
      : pct === 0
        ? 'Window idle'
        : '';
  return {
    bucketId,
    groupName: 'Claude Code',
    window: bucketId,
    label,
    usedPercent: pct,
    remainingPercent,
    remainingFraction: remainingPercent / 100,
    resetTime: windowExpired ? '' : resetsAt || '',
    resetAt,
    resetText,
    windowExpired
  };
}

function normalizeRelayEntry(entry, defaultKey = '') {
  if (!entry || typeof entry !== 'object') {
    return null;
  }
  const key = String(entry.rateLimitType || defaultKey || '').trim();
  const rawUtil = Number(entry.utilization ?? entry.percent ?? 0);
  if (!Number.isFinite(rawUtil)) {
    return null;
  }
  // In Claude Code's panelUsageRelay, utilization is 0..1 (e.g. 0.72 or 1) and reset is `resetsAt` (epoch sec)
  const isFraction =
    (entry.resetsAt !== undefined && entry.resets_at === undefined && rawUtil <= 1) ||
    (rawUtil > 0 && rawUtil < 1);
  const utilPct = isFraction ? Math.round(rawUtil * 100) : Math.round(rawUtil);
  const resetsAt = entry.resetsAt ?? entry.resets_at ?? null;
  return {
    key,
    label: entry.label || '',
    utilization: utilPct,
    resets_at: resetsAt
  };
}

function extractRelayWindowsMap(relayWindows) {
  const map = new Map();
  if (!relayWindows || typeof relayWindows !== 'object') {
    return map;
  }
  if (Array.isArray(relayWindows)) {
    for (const item of relayWindows) {
      const norm = normalizeRelayEntry(item);
      if (norm && norm.key) {
        map.set(norm.key, norm);
      }
    }
    return map;
  }
  if (Array.isArray(relayWindows.windows)) {
    for (const item of relayWindows.windows) {
      const norm = normalizeRelayEntry(item);
      if (norm && norm.key) {
        map.set(norm.key, norm);
      }
    }
    return map;
  }
  for (const [k, val] of Object.entries(relayWindows)) {
    const norm = normalizeRelayEntry(val, k);
    if (norm) {
      map.set(norm.key || k, norm);
    }
  }
  return map;
}

function pickFresherClaudeWindow(oauthWin, relayWin) {
  if (!oauthWin && !relayWin) {
    return null;
  }
  if (!oauthWin) {
    return relayWin;
  }
  if (!relayWin) {
    return oauthWin;
  }
  const oauthReset = parseIsoToEpochSeconds(oauthWin.resets_at ?? oauthWin.resetsAt);
  const relayReset = parseIsoToEpochSeconds(relayWin.resets_at ?? relayWin.resetsAt);
  if (relayReset > oauthReset + 30) {
    return relayWin;
  }
  if (oauthReset > relayReset + 30) {
    return oauthWin;
  }
  const oauthUtil = Number(oauthWin.utilization ?? oauthWin.percent ?? 0);
  const relayUtil = Number(relayWin.utilization ?? relayWin.percent ?? 0);
  return relayUtil > oauthUtil ? relayWin : oauthWin;
}

function parseClaudeQuotaSummary(oauthUsageResponse, relayWindows = null, nowMs = Date.now()) {
  const raw = oauthUsageResponse && typeof oauthUsageResponse === 'object' ? oauthUsageResponse : null;
  const relayMap = extractRelayWindowsMap(relayWindows);
  const primaryBars = [];
  const allBuckets = [];
  let session = null;
  let weekly = null;
  let fable = null;
  let extraUsage = null;

  // Anthropic reports `five_hour: null` next to a weekly window when the account has no session
  // limit (verified Ultra). Mirror Claude Code's own usage view: no Session (5hr) bar for it.
  const noSessionLimit = Boolean(
    raw &&
      raw.five_hour === null &&
      raw.seven_day &&
      typeof raw.seven_day === 'object' &&
      !Array.isArray(raw.seven_day)
  );
  if (noSessionLimit) {
    // A relay window with no future reset is a leftover from before the limit was lifted.
    const relayFiveHour = relayMap.get('five_hour');
    if (
      relayFiveHour &&
      parseIsoToEpochSeconds(relayFiveHour.resets_at) <= Math.floor(nowMs / 1000)
    ) {
      relayMap.delete('five_hour');
    }
  }

  const fiveHourWin = pickFresherClaudeWindow(raw?.five_hour, relayMap.get('five_hour'));
  if (fiveHourWin && typeof fiveHourWin === 'object') {
    session = makeClaudeBar(
      'claude-5h',
      'Session (5hr)',
      fiveHourWin.utilization ?? fiveHourWin.percent ?? 0,
      fiveHourWin.resets_at ?? fiveHourWin.resetsAt,
      nowMs
    );
    primaryBars.push({ ...session, key: 'session' });
    allBuckets.push(session);
    relayMap.delete('five_hour');
  }

  const sevenDayWin = pickFresherClaudeWindow(raw?.seven_day, relayMap.get('seven_day'));
  if (sevenDayWin && typeof sevenDayWin === 'object') {
    weekly = makeClaudeBar(
      'claude-weekly',
      'Weekly (7 day)',
      sevenDayWin.utilization ?? sevenDayWin.percent ?? 0,
      sevenDayWin.resets_at ?? sevenDayWin.resetsAt,
      nowMs
    );
    primaryBars.push({ ...weekly, key: 'weekly' });
    allBuckets.push(weekly);
    relayMap.delete('seven_day');
  }

  if (raw) {
    if (Array.isArray(raw.limits)) {
      for (const lim of raw.limits) {
        if (!lim || typeof lim !== 'object') {
          continue;
        }
        const rawModelName = lim?.scope?.model?.display_name || lim?.scope?.model?.id || '';
        const modelName = cleanText(rawModelName, 40);
        if (!modelName) {
          continue;
        }
        const isFable = /fable/i.test(modelName);
        const mergedLim = isFable
          ? pickFresherClaudeWindow(lim, relayMap.get('seven_day_overage_included'))
          : lim;
        if (isFable) {
          relayMap.delete('seven_day_overage_included');
        }
        const label = /limit$/i.test(modelName) ? modelName : `${modelName} limit`;
        const bar = makeClaudeBar(
          `claude-${modelName.toLowerCase().replace(/\s+/g, '-')}`,
          label,
          mergedLim.percent ?? mergedLim.utilization ?? 0,
          mergedLim.resets_at ?? mergedLim.resetsAt,
          nowMs
        );
        if (!fable && isFable) {
          fable = bar;
        }
        primaryBars.push({ ...bar, key: modelName.toLowerCase() });
        allBuckets.push(bar);
      }
    } else if (Array.isArray(raw.model_scoped)) {
      for (const lim of raw.model_scoped) {
        if (!lim || typeof lim !== 'object') {
          continue;
        }
        const modelName = cleanText(lim.display_name || lim.id || '', 40);
        if (!modelName) {
          continue;
        }
        const isFable = /fable/i.test(modelName);
        const mergedLim = isFable
          ? pickFresherClaudeWindow(lim, relayMap.get('seven_day_overage_included'))
          : lim;
        if (isFable) {
          relayMap.delete('seven_day_overage_included');
        }
        const label = /limit$/i.test(modelName) ? modelName : `${modelName} limit`;
        const bar = makeClaudeBar(
          `claude-${modelName.toLowerCase().replace(/\s+/g, '-')}`,
          label,
          mergedLim.utilization ?? mergedLim.percent ?? 0,
          mergedLim.resets_at ?? mergedLim.resetsAt,
          nowMs
        );
        if (!fable && isFable) {
          fable = bar;
        }
        primaryBars.push({ ...bar, key: modelName.toLowerCase() });
        allBuckets.push(bar);
      }
    }
  }

  if (!fable && relayMap.has('seven_day_overage_included')) {
    const entry = relayMap.get('seven_day_overage_included');
    relayMap.delete('seven_day_overage_included');
    fable = makeClaudeBar(
      'claude-fable',
      entry.label || 'Fable limit',
      entry.utilization,
      entry.resets_at,
      nowMs
    );
    primaryBars.push({ ...fable, key: 'fable' });
    allBuckets.push(fable);
  }

  for (const [k, entry] of relayMap.entries()) {
    const label =
      entry.label ||
      (k === 'five_hour'
        ? 'Session (5hr)'
        : k === 'seven_day'
          ? 'Weekly (7 day)'
          : k === 'seven_day_sonnet'
            ? 'Weekly Sonnet'
            : k === 'seven_day_overage_included'
              ? 'Fable limit'
              : 'Usage limit');
    const bar = makeClaudeBar(
      k || 'claude-window',
      label,
      entry.utilization,
      entry.resets_at,
      nowMs
    );
    primaryBars.push(bar);
    allBuckets.push(bar);
  }

  if (primaryBars.length > 0) {
    if (!session && !noSessionLimit) {
      session = makeClaudeBar('claude-5h', 'Session (5hr)', 0, null, nowMs);
      primaryBars.unshift({ ...session, key: 'session' });
      allBuckets.unshift(session);
    }
    if (!weekly) {
      weekly = makeClaudeBar('claude-weekly', 'Weekly (7 day)', 0, null, nowMs);
      const sessIdx = primaryBars.findIndex((b) => b.bucketId === 'claude-5h');
      primaryBars.splice(sessIdx + 1, 0, { ...weekly, key: 'weekly' });
      allBuckets.splice(sessIdx + 1, 0, weekly);
    }
    if (!fable) {
      fable = makeClaudeBar('claude-fable', 'Fable limit', 0, null, nowMs);
      const wkIdx = primaryBars.findIndex((b) => b.bucketId === 'claude-weekly');
      const insertAt = wkIdx >= 0 ? wkIdx + 1 : primaryBars.length;
      primaryBars.splice(insertAt, 0, { ...fable, key: 'fable' });
      allBuckets.splice(insertAt, 0, fable);
    }
  }

  if (raw) {
    const spend = raw.spend || raw.extra_usage;
    if (spend && (spend.enabled || spend.is_enabled)) {
      const usedMinor =
        typeof spend.used?.amount_minor === 'number'
          ? spend.used.amount_minor
          : Number(spend.used_credits || 0);
      const limitMinor =
        typeof spend.limit?.amount_minor === 'number'
          ? spend.limit.amount_minor
          : Number(spend.monthly_limit || 0);
      const usedDollars = Math.round(usedMinor / 100);
      const limitDollars = Math.round(limitMinor / 100);
      const pct = Number(spend.percent ?? spend.utilization ?? 0);
      extraUsage = {
        enabled: true,
        usedDollars,
        limitDollars,
        usedPercent: Math.max(0, Math.min(100, Math.round(pct)))
      };
      allBuckets.push(
        makeClaudeBar(
          'claude-extra-usage',
          `Extra usage ($${usedDollars} / $${limitDollars})`,
          pct,
          null,
          nowMs
        )
      );
    }
  }

  return {
    available: primaryBars.length > 0,
    source: raw && primaryBars.length > 0 ? 'claude-oauth' : primaryBars.length > 0 ? 'claude-relay' : 'unavailable',
    session,
    weekly,
    fable,
    extraUsage,
    primaryBars,
    allBuckets
  };
}

function formatClaudeModelLabel(rawModel) {
  const m = String(rawModel || '').trim();
  if (!m) {
    return 'Claude';
  }
  const lower = m.toLowerCase();
  if (lower.includes('fable')) {
    const ver = lower.match(/(\d+)[.-](\d+)/);
    return ver ? `Fable ${ver[1]}.${ver[2]}` : 'Fable';
  }
  if (lower.includes('opus')) {
    const ver = lower.match(/opus[- ](\d+)[.-](\d+)/);
    return ver ? `Opus ${ver[1]}.${ver[2]}` : 'Opus';
  }
  if (lower.includes('sonnet')) {
    const ver = lower.match(/sonnet[- ](\d+)[.-](\d+)/);
    return ver ? `Sonnet ${ver[1]}.${ver[2]}` : 'Sonnet';
  }
  if (lower.includes('haiku')) {
    const ver = lower.match(/haiku[- ](\d+)[.-](\d+)/);
    return ver ? `Haiku ${ver[1]}.${ver[2]}` : 'Haiku';
  }
  return cleanText(m, 28);
}

function toEpochSeconds(val) {
  const num = Number(val || 0);
  if (!Number.isFinite(num) || num <= 0) return 0;
  return num > 1e11 ? Math.floor(num / 1000) : num;
}

function toIdSet(listOrSet) {
  if (listOrSet instanceof Set) return listOrSet;
  const set = new Set();
  if (Array.isArray(listOrSet)) {
    for (const item of listOrSet) {
      if (item) set.add(item);
    }
  }
  return set;
}

/**
 * Pure unread check shared by VS Code sidebar (state.js) and background service (scripts/relay_keepalive.cjs).
 */
function isSessionThreadUnread(persisted, thread, classifiedState, isActive = false) {
  if (!thread || !thread.id || isActive) {
    return false;
  }
  const id = thread.id;
  const archivedSet = toIdSet(persisted?.archivedIds);
  const legacyArchivedSet = toIdSet(persisted?.archived);
  if (
    archivedSet.has(id) ||
    legacyArchivedSet.has(id) ||
    (thread.archived && !persisted?.unarchivedAt?.[id])
  ) {
    return false;
  }
  const unreadSet = toIdSet(persisted?.unreadIds);
  if (unreadSet.has(id)) {
    return true;
  }
  const seenMap =
    persisted?.seenTurnTimestamps && typeof persisted.seenTurnTimestamps === 'object'
      ? persisted.seenTurnTimestamps
      : persisted?.seenAt || {};
  const seenSec = Math.max(
    toEpochSeconds(seenMap[id]),
    toEpochSeconds(persisted?.baseline),
    toEpochSeconds(thread.lastUserViewAt)
  );
  const updatedSec = toEpochSeconds(thread.updatedAt);
  if (thread.claudeUnread && updatedSec > seenSec) {
    return true;
  }
  if (classifiedState !== 'completed' && classifiedState !== 'errored') {
    return false;
  }
  return updatedSec > seenSec + 2;
}

function mapClassifiedStatus(classifiedState) {
  if (classifiedState === 'waiting') return 'waiting';
  if (classifiedState === 'thinking') return 'working';
  if (classifiedState === 'errored') return 'failed';
  if (classifiedState === 'completed') return 'completed';
  return 'idle';
}

/**
 * Pure session-row projection shared by HubProvider.render() (hub.js) and buildStandaloneState() (relay_keepalive.cjs).
 */
function projectSessionRows(options = {}) {
  const {
    threads = [],
    openTabs = [],
    openIds = null,
    activeId = '',
    persisted = {},
    groupIds: explicitGroupIds = null,
    activity = null,
    hasAttachedUi = true,
    hideClaudeDesktop = false,
    resolvePinState = null,
    resolveSoftLimitTokens = null,
    isScratchSession = null,
    formatModel = null,
    includeTabUri = false,
    includeEffort = false,
    includeDraftTabs = false,
    draftCreatedAt = null,
    draftGroups = null,
    sortOpenFirst = false,
    collectFallbackApprovals = false
  } = options;

  const pinResolver =
    typeof resolvePinState === 'function'
      ? resolvePinState
      : require('./device-identity').resolveRowPinState;
  const customTitles =
    persisted?.customTitles && typeof persisted.customTitles === 'object'
      ? persisted.customTitles
      : {};
  const threadGroups =
    persisted?.threadGroups && typeof persisted.threadGroups === 'object'
      ? persisted.threadGroups
      : {};
  const unarchivedAtMap =
    persisted?.unarchivedAt && typeof persisted.unarchivedAt === 'object'
      ? persisted.unarchivedAt
      : {};
  const archivedSet = new Set([
    ...(Array.isArray(persisted?.archivedIds) ? persisted.archivedIds : []),
    ...(Array.isArray(persisted?.archived) ? persisted.archived : [])
  ]);
  const unreadSet = new Set(Array.isArray(persisted?.unreadIds) ? persisted.unreadIds : []);
  const seenAtMap =
    persisted?.seenTurnTimestamps && typeof persisted.seenTurnTimestamps === 'object'
      ? persisted.seenTurnTimestamps
      : persisted?.seenAt || {};
  const baselineSec = toEpochSeconds(persisted?.baseline);
  const pinnedMap =
    persisted?.pinnedThreads && typeof persisted.pinnedThreads === 'object'
      ? persisted.pinnedThreads
      : {};
  const unpinnedMap =
    persisted?.unpinnedThreads && typeof persisted.unpinnedThreads === 'object'
      ? persisted.unpinnedThreads
      : {};
  const validGroupIds =
    explicitGroupIds instanceof Set
      ? explicitGroupIds
      : new Set(
          (Array.isArray(persisted?.groups) ? persisted.groups : [])
            .map((g) => g?.id)
            .filter(Boolean)
        );
  const unreadStateView = {
    archivedIds: archivedSet,
    unarchivedAt: unarchivedAtMap,
    unreadIds: unreadSet,
    seenTurnTimestamps: seenAtMap,
    baseline: baselineSec
  };

  const openById = new Map();
  for (const tab of Array.isArray(openTabs) ? openTabs : []) {
    if (tab && tab.id && (!openById.has(tab.id) || tab.active)) {
      openById.set(tab.id, tab);
    }
  }
  const openIdSet = new Set(openById.keys());
  if (openIds) {
    for (const oid of openIds) {
      if (oid) openIdSet.add(oid);
    }
  }

  const rows = [];
  const seenIds = new Set();
  const rowFallbackApprovals = [];

  for (const thread of Array.isArray(threads) ? threads : []) {
    if (!thread || !thread.id) continue;
    seenIds.add(thread.id);
    const provider = thread.provider === 'claude' ? 'claude' : 'antigravity';
    const tab = openById.get(thread.id);
    const classified =
      activity && typeof activity.classifyThread === 'function'
        ? activity.classifyThread(thread, { recordTransition: false })
        : { state: 'idle', reason: null };
    const status = mapClassifiedStatus(classified.state);
    const isOpen = openIdSet.has(thread.id);
    const isActive = Boolean(tab?.active || (activeId && thread.id === activeId));
    const isArchived =
      archivedSet.has(thread.id) || Boolean(thread.archived && !unarchivedAtMap[thread.id]);
    const rawUnread = isSessionThreadUnread(
      unreadStateView,
      thread,
      classified.state,
      isActive
    );
    // A session with no open tab on an attached host (or an archived session) shows no unread mark.
    const isUnread = hasAttachedUi ? isOpen && rawUnread : rawUnread;

    const dot =
      status === 'waiting'
        ? 'waiting'
        : status === 'working'
          ? 'running'
          : thread.bgTask?.state === 'interrupted'
            ? 'failed'
            : isUnread
              ? status === 'failed'
                ? 'failed'
                : 'unread'
              : isOpen
                ? 'idle'
                : null;
    const category =
      status === 'waiting'
        ? 'needs_input'
        : status === 'working'
          ? 'working'
          : 'completed';

    const rawBgTasks = Array.isArray(thread.backgroundTasks) ? thread.backgroundTasks : [];
    const bgRunningCount = rawBgTasks.filter((t) => t && t.state === 'running').length;
    const bgTotalCount = rawBgTasks.length;
    const includeBgList =
      !isArchived ||
      isOpen ||
      bgRunningCount > 0 ||
      thread.bgTask?.state === 'interrupted' ||
      Boolean(thread.bgTask?.stalled);
    const bgTasks = includeBgList
      ? rawBgTasks.slice(-12).map((t) => ({
          id: t.id,
          fullId: t.fullId || t.id,
          subagentConversationId: t.subagentConversationId || '',
          kind: t.kind || 'task',
          subagentType: t.subagentType || '',
          summary: t.summary || '',
          command: String(t.command || '').slice(0, 320),
          state: t.state || 'completed',
          isDaemon: Boolean(t.isDaemon),
          startedAt: Number(t.startedAt || 0) * 1000,
          completedAt: t.completedAt ? Number(t.completedAt) * 1000 : 0,
          stepIndex: typeof t.stepIndex === 'number' ? t.stepIndex : -1
        }))
      : [];

    const pinState = pinResolver(
      {
        id: thread.id,
        archived: isArchived,
        pinned: thread.pinned,
        pinnedAt: thread.pinnedAt,
        pinUpdatedAt: thread.pinUpdatedAt
      },
      pinnedMap,
      unpinnedMap
    );

    const rowUsedTokens = Number(thread.usedTokens || thread.estTokens || 0) || 0;
    const rowLimFallback =
      provider === 'antigravity' && typeof resolveSoftLimitTokens === 'function'
        ? Number(resolveSoftLimitTokens(provider, thread.model || '') || 0)
        : 0;
    const rowLimitTokens = Number(thread.limitTokens || rowLimFallback || 0) || 0;

    const rawModel = thread.model || (provider === 'claude' ? 'Claude' : 'Gemini');
    const model =
      typeof formatModel === 'function'
        ? formatModel(rawModel, provider, thread.effort || '')
        : rawModel;

    const title = customTitles[thread.id] || thread.title || 'Untitled session';
    const stepCount = Number(thread.stepCount || 0);
    const pendingQuestion = thread.pendingQuestion || null;
    const lastAssistantText = !isArchived ? String(thread.lastAssistantText || '').slice(0, 220) : '';
    const updatedMs = Number(thread.updatedAt || 0) * 1000;
    const claudeDesktopScratch = Boolean(
      thread.claudeDesktopScratch ||
        (provider === 'claude' &&
          (isClaudeDesktopScratchPath(thread.cwd || thread.filePath || '') ||
            (typeof isScratchSession === 'function' && isScratchSession(thread.id, provider, thread))))
    );
    const claudeDesktop = Boolean(thread.claudeDesktop || claudeDesktopScratch);

    rows.push({
      key: thread.id,
      id: thread.id,
      ...(includeTabUri ? { uri: tab?.uri || null } : {}),
      provider,
      claudeDesktop,
      claudeDesktopScratch,
      draft: false,
      title,
      at: updatedMs,
      open: isOpen,
      active: isActive,
      group:
        threadGroups[thread.id] && validGroupIds.has(threadGroups[thread.id])
          ? threadGroups[thread.id]
          : tab?.uri
            ? lookupDraftGroup(draftGroups, tab.uri, validGroupIds)
            : null,
      archived: isArchived,
      pinned: pinState.pinned,
      pinnedAt: pinState.pinnedAt,
      pinUpdatedAt: pinState.pinUpdatedAt,
      cwd: thread.cwd || '',
      folder: thread.workspaceLabel || '',
      branch: thread.branch || '',
      deviceId: thread.deviceId || '',
      deviceName: thread.deviceName || '',
      source: thread.source || '',
      usedTokens: rowUsedTokens,
      limitTokens: rowLimitTokens,
      remotePeer: Boolean(thread.remotePeer || thread.source === 'cloud-relay'),
      model,
      ...(includeEffort ? { effort: thread.effort || undefined } : {}),
      logged: true,
      status,
      dot,
      category,
      unread: isUnread,
      elsewhere: Boolean((status === 'working' || thread.elsewhere) && !isOpen),
      reason: classified.reason || null,
      stepCount,
      turnComplete: thread.turnComplete !== false,
      lastAssistantText,
      pendingQuestion,
      bgTasks,
      bgRunningCount,
      bgTotalCount
    });

    if (
      collectFallbackApprovals &&
      (pendingQuestion || status === 'waiting') &&
      !claudeDesktopScratch &&
      !(hideClaudeDesktop && claudeDesktop)
    ) {
      const isQ = Boolean(pendingQuestion);
      const stepKey = pendingQuestion?.stepIndex || stepCount || 0;
      const normQs =
        Array.isArray(pendingQuestion?.questions) && pendingQuestion.questions.length
          ? pendingQuestion.questions
          : [];
      const itemId =
        pendingQuestion?.approvalId ||
        (isQ
          ? `question-${thread.id}-${stepKey}`
          : stepKey
            ? `waiting-${thread.id}-${stepKey}`
            : `waiting-${thread.id}`);
      rowFallbackApprovals.push({
        id: itemId,
        approvalId: itemId,
        provider,
        claudeDesktop,
        claudeDesktopScratch,
        sessionId: thread.id,
        title,
        toolName:
          pendingQuestion?.toolName ||
          (isQ ? 'Question' : classified.reason || 'Waiting on user input'),
        detail:
          pendingQuestion?.questionText ||
          lastAssistantText ||
          `${thread.workspaceLabel || 'Workspace'} · ${thread.model || ''}`.trim(),
        codePreview: pendingQuestion?.codePreview || '',
        description: pendingQuestion?.description || '',
        isToolPermission: Boolean(pendingQuestion?.isToolPermission),
        writeInPlaceholder: pendingQuestion?.writeInPlaceholder || '',
        isMultiSelect: Boolean(pendingQuestion?.isMultiSelect || normQs[0]?.isMultiSelect),
        options: pendingQuestion?.options || [],
        questions: normQs,
        stepIndex: stepKey,
        kind: isQ ? 'question' : 'waiting_session',
        createdAt: (pendingQuestion?.at ? pendingQuestion.at * 1000 : updatedMs) || Date.now()
      });
    }
  }

  const openDraftUris = new Set();
  for (const tab of Array.isArray(openTabs) ? openTabs : []) {
    if (!tab) continue;
    const provider = tab.provider === 'claude' ? 'claude' : 'antigravity';
    const defaultModel = provider === 'claude' ? 'Claude' : 'Gemini';
    if (tab.id && !seenIds.has(tab.id)) {
      seenIds.add(tab.id);
      const liveEntry = activity?.liveByThreadId?.get?.(tab.id);
      const syntheticThread = {
        id: tab.id,
        provider,
        title: customTitles[tab.id] || tab.title || 'Untitled session',
        updatedAt: Number(liveEntry?.updatedAt || Math.floor(Date.now() / 1000)),
        stepCount: Number(liveEntry?.stepCount || 0),
        notFullyIdle: Boolean(liveEntry?.notFullyIdle),
        status: liveEntry?.notFullyIdle ? 'CASCADE_RUN_STATUS_RUNNING' : 'CASCADE_RUN_STATUS_IDLE'
      };
      const classified =
        activity && typeof activity.classifyThread === 'function'
          ? activity.classifyThread(syntheticThread, { recordTransition: false })
          : { state: 'idle', reason: null };
      const fallbackStatus = mapClassifiedStatus(classified.state);
      const fallbackDot =
        fallbackStatus === 'waiting'
          ? 'waiting'
          : fallbackStatus === 'working'
            ? 'running'
            : 'idle';
      const fallbackCategory =
        fallbackStatus === 'waiting'
          ? 'needs_input'
          : fallbackStatus === 'working'
            ? 'working'
            : 'completed';
      const synthScratch =
        provider === 'claude' &&
        typeof isScratchSession === 'function' &&
        Boolean(isScratchSession(tab.id, provider, null));
      const isSynthArchived = archivedSet.has(tab.id);
      const synthPinState = pinResolver(
        { id: tab.id, archived: isSynthArchived },
        pinnedMap,
        unpinnedMap
      );
      const synthLim =
        provider === 'antigravity' && typeof resolveSoftLimitTokens === 'function'
          ? Number(resolveSoftLimitTokens(provider, syntheticThread.model || defaultModel) || 0)
          : 0;
      const synthModel =
        typeof formatModel === 'function'
          ? formatModel(defaultModel, provider, '')
          : defaultModel;
      rows.push({
        key: tab.id,
        id: tab.id,
        ...(includeTabUri ? { uri: tab.uri || null } : {}),
        provider,
        claudeDesktop: synthScratch,
        claudeDesktopScratch: synthScratch,
        draft: false,
        title: syntheticThread.title,
        at: Number(syntheticThread.updatedAt) * 1000,
        open: true,
        active: Boolean(tab.active || (activeId && tab.id === activeId)),
        group:
          threadGroups[tab.id] && validGroupIds.has(threadGroups[tab.id])
            ? threadGroups[tab.id]
            : tab.uri
              ? lookupDraftGroup(draftGroups, tab.uri, validGroupIds)
              : null,
        archived: isSynthArchived,
        pinned: synthPinState.pinned,
        pinnedAt: synthPinState.pinnedAt,
        pinUpdatedAt: synthPinState.pinUpdatedAt,
        cwd: '',
        folder: synthScratch ? 'Claude Desktop' : '',
        branch: '',
        ...(includeEffort ? { deviceId: '', deviceName: '', source: '' } : {}),
        model: synthModel,
        logged: true,
        status: fallbackStatus,
        dot: fallbackDot,
        category: fallbackCategory,
        unread: false,
        elsewhere: false,
        reason: classified.reason || null,
        stepCount: syntheticThread.stepCount,
        turnComplete: !syntheticThread.notFullyIdle,
        lastAssistantText: '',
        pendingQuestion: null,
        bgTasks: [],
        bgRunningCount: 0,
        bgTotalCount: 0,
        usedTokens: Number(syntheticThread.usedTokens || syntheticThread.estTokens || 0) || 0,
        limitTokens: Number(syntheticThread.limitTokens || synthLim || 0) || 0
      });
    } else if (includeDraftTabs && !tab.id) {
      const defaultDraftTitle =
        provider === 'claude' ? 'New Claude session' : 'New Antigravity session';
      const draftKey = tab.uri || `draft:${provider}`;
      openDraftUris.add(draftKey);
      let draftAt = Date.now();
      if (draftCreatedAt instanceof Map) {
        if (!draftCreatedAt.has(draftKey)) {
          const initialDraftAt = Number(tab.createdAt || 0);
          draftCreatedAt.set(
            draftKey,
            Number.isFinite(initialDraftAt) && initialDraftAt > 0 ? initialDraftAt : draftAt
          );
        }
        draftAt = draftCreatedAt.get(draftKey) || draftAt;
      }
      const draftModel =
        typeof formatModel === 'function'
          ? formatModel(defaultModel, provider, '')
          : defaultModel;
      rows.push({
        key: tab.uri,
        id: null,
        uri: tab.uri || null,
        provider,
        draft: true,
        title:
          !tab.title || tab.title === 'Antigravity' || tab.title === 'Claude Code'
            ? defaultDraftTitle
            : tab.title,
        at: draftAt,
        open: true,
        active: Boolean(tab.active),
        group: lookupDraftGroup(draftGroups, tab.uri, validGroupIds),
        archived: false,
        pinned: false,
        pinnedAt: 0,
        pinUpdatedAt: 0,
        cwd: '',
        folder: '',
        branch: '',
        model: draftModel,
        logged: false,
        status: 'idle',
        dot: 'idle',
        category: 'completed',
        unread: false,
        elsewhere: false,
        reason: null
      });
    }
  }

  if (includeDraftTabs && draftCreatedAt instanceof Map && draftCreatedAt.size > openDraftUris.size) {
    for (const k of Array.from(draftCreatedAt.keys())) {
      if (!openDraftUris.has(k)) {
        draftCreatedAt.delete(k);
      }
    }
  }

  rows.sort(
    sortOpenFirst
      ? (a, b) =>
          Number(Boolean(b?.pinned && !b?.archived)) - Number(Boolean(a?.pinned && !a?.archived)) ||
          Number(Boolean(b?.open)) - Number(Boolean(a?.open)) ||
          Number(Boolean(b?.draft)) - Number(Boolean(a?.draft)) ||
          Number(b?.at || 0) - Number(a?.at || 0) ||
          Number(b?.pinnedAt || 0) - Number(a?.pinnedAt || 0)
      : (a, b) =>
          Number(Boolean(b?.pinned && !b?.archived)) - Number(Boolean(a?.pinned && !a?.archived)) ||
          Number(b?.at || 0) - Number(a?.at || 0) ||
          Number(b?.pinnedAt || 0) - Number(a?.pinnedAt || 0)
  );

  return { rows, rowFallbackApprovals };
}

module.exports = {
  getDefaultAntigravityHome,
  getDefaultClaudeHome,
  getDefaultClaudeConfigPath,
  cleanText,
  parseIsoToEpochSeconds,
  fileUriToPath,
  normalizePathForCompare,
  isClaudeDesktopScratchPath,
  formatWorkspaceLabel,
  isSameOrChildPath,
  formatRelativeAge,
  formatResetCountdown,
  parseAntigravityQuotaSummary,
  formatAntigravityPlanName,
  parseAntigravityAccountStatus,
  formatClaudePlanName,
  parseClaudeAccountStatus,
  parseClaudeQuotaSummary,
  formatClaudeModelLabel,
  isSessionThreadUnread,
  projectSessionRows
};
