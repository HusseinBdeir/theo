const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const { randomBytes } = require('crypto');
const { isSameOrChildPath } = require('./data');
const { notifySessionTransition } = require('./desktop-notify');
const { AccountVaultManager } = require('./accounts');

class HubProvider {
  constructor(context, deps) {
    this.context = context;
    this.store = deps.store;
    this.stateStore = deps.stateStore;
    this.activity = deps.activity;
    this.tabs = deps.tabs;
    this.ensureBridge = deps.ensureBridge;
    this.accountVault =
      deps.accountVault ||
      new AccountVaultManager({
        onStateChange: () => {
          this.refresh({ forceQuota: false });
        }
      });
    this.accountsView = {
      antigravity: [],
      claude: [],
      pendingAccountLogin: null
    };

    this.view = null;
    this.views = new Set();
    this.snapshot = null;
    this.openTabsList = [];
    this.bridgeStatus = {
      active: false,
      antigravityActive: false,
      claudeActive: false,
      hideDuplicateIcon: true,
      reload: false,
      message: ''
    };
    this.bridgeInstallReport = null;
    this.loading = true;
    this.lastPosted = null;
    this.editGroup = null;
    this.renderTimer = null;
    this.refreshInFlight = null;
    this.pendingRefresh = null;
    this._scheduledRefreshTimer = null;
    this._scheduledRefreshOpts = null;
    this._tabSwitchCooldownUntil = 0;
    this._pendingActiveTarget = null;
    this.baselineInitialized = false;
    this.draftGroups = new Map();
  }

  setPendingActiveTarget({
    id = '',
    key = '',
    provider = 'antigravity',
    title = '',
    durationMs = 2200
  } = {}) {
    const cleanId = String(id || '').trim();
    const cleanKey = String(key || '').trim();
    if (!cleanId && !cleanKey) {
      this._pendingActiveTarget = null;
      return null;
    }
    const now = Date.now();
    const prev = this._pendingActiveTarget;
    const sameAsPrev = Boolean(
      prev &&
        now < Number(prev.until || 0) &&
        ((cleanId && prev.id === cleanId) || (cleanKey && prev.key === cleanKey))
    );
    const outgoingIds = new Set(sameAsPrev && prev.outgoingIds ? prev.outgoingIds : []);
    const outgoingKeys = new Set(sameAsPrev && prev.outgoingKeys ? prev.outgoingKeys : []);
    if (Array.isArray(this.openTabsList)) {
      for (const tab of this.openTabsList) {
        if (!tab?.active) continue;
        const tabMatchesTarget =
          (cleanId && tab.id === cleanId) || (cleanKey && tab.uri === cleanKey);
        if (!tabMatchesTarget) {
          if (tab.id) outgoingIds.add(String(tab.id).trim());
          if (tab.uri) outgoingKeys.add(String(tab.uri).trim());
        }
      }
    }
    this._pendingActiveTarget = {
      id: cleanId,
      key: cleanKey,
      provider: provider === 'claude' ? 'claude' : 'antigravity',
      title: String(title || ''),
      outgoingIds,
      outgoingKeys,
      setAt: now,
      until: now + Math.max(250, Number(durationMs) || 2200),
      confirmedInTabs: false
    };
    if (Array.isArray(this.openTabsList)) {
      this.openTabsList = this.applyPendingActiveTargetToTabs(this.openTabsList);
    }
    return this._pendingActiveTarget;
  }

  clearPendingActiveTargetIfMatches({ id = '', key = '' } = {}) {
    const cur = this._pendingActiveTarget;
    if (!cur) {
      return;
    }
    const cleanId = String(id || '').trim();
    const cleanKey = String(key || '').trim();
    if (
      (!cleanId && !cleanKey) ||
      (cleanId && cur.id === cleanId) ||
      (cleanKey && cur.key === cleanKey)
    ) {
      this._pendingActiveTarget = null;
    }
  }

  getPendingActiveTarget(now = Date.now()) {
    const cur = this._pendingActiveTarget;
    if (!cur || now >= Number(cur.until || 0)) {
      this._pendingActiveTarget = null;
      return null;
    }
    return cur;
  }

  applyPendingActiveTargetToTabs(openTabs, explicitTarget = null) {
    const tabs = Array.isArray(openTabs)
      ? openTabs.map((t) => (t && typeof t === 'object' ? { ...t } : t))
      : [];
    const now = Date.now();
    const pending = this.getPendingActiveTarget(now);
    const matchesTarget = (tab, target) =>
      Boolean(
        tab &&
          target &&
          ((target.id && tab.id === target.id) || (target.key && tab.uri === target.key))
      );

    if (pending) {
      const rawTargetActive = tabs.some((t) => Boolean(t?.active) && matchesTarget(t, pending));
      const rawOtherActive = tabs.some((t) => Boolean(t?.active) && !matchesTarget(t, pending));

      if (rawTargetActive && !rawOtherActive) {
        pending.confirmedInTabs = true;
        return tabs;
      }

      // Never allow an explicitTarget (e.g. a late focus RPC from an outgoing panel) to clear _pendingActiveTarget;
      // only release early when VS Code's own openTabs snapshot genuinely moved active state off target to another tab.
      if (
        pending.confirmedInTabs &&
        !rawTargetActive &&
        rawOtherActive &&
        now - pending.setAt > 220
      ) {
        this._pendingActiveTarget = null;
      } else {
        const matched = tabs.some((t) => matchesTarget(t, pending));
        if (matched) {
          for (const t of tabs) {
            const isTarget = matchesTarget(t, pending);
            t.active = isTarget;
            if (isTarget) {
              t.visible = true;
            }
          }
        } else if (pending.id) {
          for (const t of tabs) {
            if (t) t.active = false;
          }
          const thread = (this.snapshot?.threads || []).find((th) => th.id === pending.id);
          tabs.push({
            uri: pending.key || '',
            id: pending.id,
            provider: thread?.provider || pending.provider || 'antigravity',
            title: thread?.title || pending.title || '',
            active: true,
            visible: true,
            viewColumn: 1
          });
        }
        return tabs;
      }
    }

    const cleanId = String(explicitTarget?.id || '').trim();
    const cleanKey = String(explicitTarget?.key || '').trim();
    const forceExplicit = Boolean(explicitTarget?.force);
    if (cleanId || cleanKey) {
      const target = { id: cleanId, key: cleanKey };
      const matched = tabs.some((t) => matchesTarget(t, target));
      if (matched) {
        const targetAlreadyInactive = tabs.some((t) => matchesTarget(t, target) && !t.active);
        const anotherTabAlreadyActive = tabs.some(
          (t) => Boolean(t?.active) && !matchesTarget(t, target)
        );
        // Never allow an unforced background/focus event on an already-inactive tab to steal active state from the live active tab
        if (!forceExplicit && targetAlreadyInactive && anotherTabAlreadyActive) {
          return tabs;
        }
        for (const t of tabs) {
          const isTarget = matchesTarget(t, target);
          t.active = isTarget;
          if (isTarget) {
            t.visible = true;
          }
        }
      } else if (cleanId && (forceExplicit || !tabs.some((t) => Boolean(t?.active)))) {
        for (const t of tabs) {
          if (t) t.active = false;
        }
        const thread = (this.snapshot?.threads || []).find((th) => th.id === cleanId);
        tabs.push({
          uri: cleanKey,
          id: cleanId,
          provider: thread?.provider || 'antigravity',
          title: thread?.title || '',
          active: true,
          visible: true,
          viewColumn: 1
        });
      }
    }
    return tabs;
  }

  get visible() {
    for (const v of this.views) {
      if (v && v.visible) {
        return true;
      }
    }
    return Boolean(this.view?.visible);
  }

  async markThreadSeen(threadId, seenAt = 0) {
    const id = String(threadId || '').trim();
    if (!id) {
      return;
    }
    const thread = (this.snapshot?.threads || []).find((t) => t.id === id);
    const effectiveSeenAt = Math.max(
      Number(seenAt) || 0,
      Number(thread?.updatedAt) || 0,
      Math.floor(Date.now() / 1000)
    );
    await this.stateStore.markSeen(id, effectiveSeenAt, { clearUnread: true });
    if (thread?.provider === 'claude') {
      try {
        vscode.commands
          .executeCommand('antigravityHub.claudeSetUnread', {
            id,
            unread: false
          })
          .then(
            () => {},
            () => {}
          );
      } catch {}
    }
    if (Array.isArray(this.openTabsList)) {
      this.openTabsList = this.applyPendingActiveTargetToTabs(this.openTabsList);
    }
    this.syncOpenTabBadges();
    this.requestRender();
  }

  scheduleRefresh(delayMs = 280, options = {}) {
    this._scheduledRefreshOpts = {
      force: Boolean(this._scheduledRefreshOpts?.force || options.force),
      forceQuota: Boolean(this._scheduledRefreshOpts?.forceQuota || options.forceQuota)
    };
    if (this._scheduledRefreshTimer) {
      return;
    }
    this._scheduledRefreshTimer = setTimeout(() => {
      const opts = this._scheduledRefreshOpts || {};
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
      this.refresh(opts).catch(() => {});
    }, Math.max(40, Number(delayMs) || 280));
    if (typeof this._scheduledRefreshTimer?.unref === 'function') {
      this._scheduledRefreshTimer.unref();
    }
  }

  async refreshTabStateFast({
    optimisticActiveId = '',
    optimisticActiveKey = '',
    forceOptimistic = false,
    scheduleFullRefreshMs = 0
  } = {}) {
    try {
      const openTabs = await this.tabs.getOpenTabs();
      if (Array.isArray(openTabs)) {
        const cleanId = String(optimisticActiveId || '').trim();
        const cleanKey = String(optimisticActiveKey || '').trim();
        const adjustedTabs = this.applyPendingActiveTargetToTabs(openTabs, {
          id: cleanId,
          key: cleanKey,
          force: Boolean(forceOptimistic)
        });
        this.openTabsList = adjustedTabs;
        const nowSec = Math.floor(Date.now() / 1000);
        for (const tab of adjustedTabs) {
          if (tab?.active && tab?.id) {
            const activeThread = (this.snapshot?.threads || []).find((t) => t.id === tab.id);
            await this.stateStore.markSeen(
              tab.id,
              Math.max(nowSec, Number(activeThread?.updatedAt) || 0),
              { clearUnread: true }
            );
          }
        }
      }
    } catch {}
    this.syncOpenTabBadges();
    this.render();
    if (scheduleFullRefreshMs > 0) {
      this.scheduleRefresh(scheduleFullRefreshMs);
    }
  }

  async touchActiveTabs() {
    try {
      const openTabs = await this.tabs.getOpenTabs();
      if (Array.isArray(openTabs)) {
        const adjustedTabs = this.applyPendingActiveTargetToTabs(openTabs);
        this.openTabsList = adjustedTabs;
        for (const tab of adjustedTabs) {
          if (tab?.active && tab?.id) {
            await this.markThreadSeen(tab.id);
          }
        }
      }
    } catch {}
  }

  syncOpenTabBadges(persisted = null) {
    if (!Array.isArray(this.openTabsList) || this.openTabsList.length === 0) {
      return;
    }
    const state = persisted || this.stateStore.read();
    const threadsById = new Map(
      (this.snapshot?.threads || []).map((thread) => [thread.id, thread])
    );
    const badgesById = {};

    for (const tab of this.openTabsList) {
      if (!tab?.id) {
        continue;
      }
      const isActive = Boolean(tab.active);
      const thread = threadsById.get(tab.id);
      if (!thread) {
        badgesById[tab.id] = 'plain';
        continue;
      }
      if (
        tab.provider !== 'claude' &&
        thread.title &&
        thread.title !== 'Antigravity' &&
        (!tab.title || tab.title === 'new' || tab.title === 'Antigravity')
      ) {
        tab.title = thread.title;
        this.tabs.syncTabTitle(tab.id, thread.title, 'antigravity').catch(() => {});
      }
      const classified = this.activity.classifyThread(thread, { recordTransition: false });
      const isUnread = this.stateStore.isThreadUnread(state, thread, classified.state, isActive);
      let badge = 'plain';
      if (classified.state === 'waiting') {
        badge = 'pending';
      } else if (!isActive && isUnread && classified.state !== 'thinking') {
        badge = 'done';
      }
      if (badgesById[tab.id] === undefined || isActive || badge === 'pending') {
        badgesById[tab.id] = isActive && badge === 'done' ? 'plain' : badge;
      }
    }

    this.tabs.syncTabBadges(badgesById).catch(() => {});
  }

  resolveWebviewView(view) {
    this.view = view;
    this.views.add(view);
    this.lastPosted = null;
    if (Array.isArray(view.__bhfListeners)) {
      for (const l of view.__bhfListeners) {
        try {
          l?.dispose?.();
        } catch {}
      }
      view.__bhfListeners = [];
    }
    try {
      view.title = 'THEO';
    } catch {}
    const webview = view.webview;
    webview.options = {
      enableScripts: true,
      localResourceRoots: [vscode.Uri.joinPath(this.context.extensionUri, 'resources')]
    };

    this.applyWebviewHtml(webview);

    const listeners = [
      webview.onDidReceiveMessage(async (message) => {
        try {
          await this.handleMessage(message);
        } catch (err) {
          vscode.window.showErrorMessage(`THEO: ${err?.message || err}`);
        }
      }),
      view.onDidChangeVisibility(() => {
        if (view.visible) {
          this.refresh({ forceQuota: false });
        }
      }),
      view.onDidDispose(() => {
        listeners.forEach((l) => l.dispose());
        view.__bhfListeners = [];
        this.views.delete(view);
        if (this.view === view) {
          this.view = this.views.values().next().value || null;
        }
      })
    ];
    view.__bhfListeners = listeners;

    this.render();
    this.refresh({ forceQuota: true });
  }

  applyWebviewHtml(webview) {
    if (!webview) return;
    const nonce = randomBytes(18).toString('hex');
    const resUri = (file) => {
      let ver = '';
      try {
        ver = `?v=${Math.floor(fs.statSync(path.join(this.context.extensionPath, 'resources', file)).mtimeMs)}`;
      } catch {}
      return (
        webview
          .asWebviewUri(vscode.Uri.joinPath(this.context.extensionUri, 'resources', file))
          .toString() + ver
      );
    };
    webview.html = fs
      .readFileSync(path.join(this.context.extensionPath, 'resources', 'hub.html'), 'utf8')
      .replaceAll('{{cspSource}}', webview.cspSource)
      .replaceAll('{{nonce}}', nonce)
      .replaceAll('{{css}}', resUri('hub.css'))
      .replaceAll('{{js}}', resUri('hub.js'));
  }

  reloadAllWebviews() {
    this.lastPosted = null;
    for (const v of this.views) {
      try {
        this.applyWebviewHtml(v.webview);
      } catch {}
    }
    this.render();
  }

  setBridgeInstallReport(report) {
    this.bridgeInstallReport = report || null;
    const agyActive = Boolean(this.bridgeStatus?.antigravityActive);
    const claudeActive = Boolean(this.bridgeStatus?.claudeActive);
    const claudeSignedIn =
      typeof this.accountVault?.hasSignedInProvider === 'function'
        ? this.accountVault.hasSignedInProvider('claude')
        : report?.claudeSignedIn !== false;
    const needsAgy = Boolean(
      report?.needsAgyReload && (report?.agyHostUpdated || !agyActive)
    );
    const needsClaude = Boolean(
      claudeSignedIn && report?.needsClaudeReload && (report?.claudeHostUpdated || !claudeActive)
    );
    const reload = Boolean(needsAgy || needsClaude);
    this.bridgeStatus = {
      ...this.bridgeStatus,
      reload,
      message: !reload
        ? ''
        : needsAgy && needsClaude
          ? 'Reload VS Code once to activate the Antigravity & Claude Code bridges.'
          : needsClaude
            ? 'Reload VS Code once to activate the Claude Code bridge.'
            : 'Reload VS Code once to activate the Antigravity bridge.'
    };
    this.requestRender();
  }

  requestRender() {
    if (this.renderTimer) {
      return;
    }
    this.renderTimer = setTimeout(() => {
      this.renderTimer = null;
      this.render();
    }, 45);
  }

  getAutoArchiveInactiveDays(persisted = null, claudeLive = null) {
    const validDays = [0, 1, 2, 7, 14];
    const state = persisted || this.stateStore.read();
    const prefDays = state?.preferences?.autoArchiveInactiveDays;
    if (typeof prefDays === 'number' && validDays.includes(prefDays)) {
      return prefDays;
    }
    try {
      const hubCfgDays = vscode.workspace
        .getConfiguration('antigravityHub')
        .get('autoArchiveInactiveDays');
      if (typeof hubCfgDays === 'number' && validDays.includes(hubCfgDays)) {
        return hubCfgDays;
      }
      const claudeCfgDays = vscode.workspace
        .getConfiguration('claudeCode')
        .get('archiveInactiveSessions');
      if (typeof claudeCfgDays === 'number' && validDays.includes(claudeCfgDays)) {
        return claudeCfgDays;
      }
    } catch {}
    if (
      typeof claudeLive?.autoArchiveDays === 'number' &&
      validDays.includes(claudeLive.autoArchiveDays)
    ) {
      return claudeLive.autoArchiveDays;
    }
    return 14;
  }

  async sweepAutoArchiveInactive(snap, explicitDays = null) {
    const allThreads = snap?.threads || [];
    if (allThreads.length === 0) {
      return 0;
    }
    const state = this.stateStore.read();
    const days =
      typeof explicitDays === 'number'
        ? explicitDays
        : this.getAutoArchiveInactiveDays(state, snap?.claudeLive);
    if (!days || days <= 0) {
      return 0;
    }

    const nowSec = Math.floor(Date.now() / 1000);
    const cutoffSec = nowSec - days * 86400;
    const archivedSet = new Set(state.archivedIds || []);
    const groupIds = new Set((state.groups || []).map((g) => g.id));
    const openTabIds = new Set(
      (this.openTabsList || []).map((t) => t?.id).filter(Boolean)
    );

    const toArchive = [];
    const claudeToArchive = [];

    for (const thread of allThreads) {
      if (!thread?.id || archivedSet.has(thread.id) || openTabIds.has(thread.id)) {
        continue;
      }
      const hasGroup =
        Boolean(state.threadGroups?.[thread.id]) &&
        groupIds.has(state.threadGroups[thread.id]);
      if (hasGroup) {
        continue;
      }
      const classified = this.activity.classifyThread(thread, { recordTransition: false });
      if (
        classified.state === 'thinking' ||
        classified.state === 'waiting' ||
        thread.elsewhere
      ) {
        continue;
      }
      const isUnread = this.stateStore.isThreadUnread(
        state,
        thread,
        classified.state,
        false
      );
      if (isUnread) {
        continue;
      }
      const unarchivedAtSec = Number(state.unarchivedAt?.[thread.id] || 0);
      const unassignedAtSec = Number(state.unassignedGroupThreads?.[thread.id] || 0);
      const effectiveActivitySec = Math.max(
        Number(thread.updatedAt || 0),
        unarchivedAtSec,
        unassignedAtSec
      );
      if (effectiveActivitySec > 0 && effectiveActivitySec < cutoffSec) {
        toArchive.push(thread.id);
        if (thread.provider === 'claude') {
          claudeToArchive.push(thread.id);
        }
      }
    }

    if (toArchive.length > 0) {
      await this.stateStore.setArchivedMany(toArchive, true);
      if (claudeToArchive.length > 0) {
        vscode.commands
          .executeCommand('antigravityHub.claudeSetArchived', {
            ids: claudeToArchive,
            archived: true
          })
          .then(
            () => {},
            () => {}
          );
      }
    }
    return toArchive.length;
  }

  hotReloadUpdatedModules() {
    const now = Date.now();
    if (now - Number(this._lastHotReloadCheckAt || 0) < 5000) {
      return;
    }
    this._lastHotReloadCheckAt = now;
    if (!this._moduleMtimes) {
      this._moduleMtimes = new Map();
    }
    const relPaths = [
      './compat/antigravity-context-window.cjs',
      './compat/antigravity-hub-bridge.cjs',
      './compat/claude-hub-bridge.cjs',
      './accounts.js',
      './state.js',
      './store.js'
    ];
    let changed = false;
    for (const rel of relPaths) {
      try {
        const resolved = require.resolve(rel);
        const stat = fs.statSync(resolved);
        const mtime = Math.floor(stat.mtimeMs);
        const prev = this._moduleMtimes.get(resolved);
        this._moduleMtimes.set(resolved, mtime);
        if (prev !== undefined && prev !== mtime) {
          delete require.cache[resolved];
          changed = true;
        }
      } catch {}
    }
    if (changed) {
      try {
        const freshAccounts = require('./accounts.js');
        if (this.accountVault && freshAccounts?.AccountVaultManager?.prototype) {
          Object.setPrototypeOf(this.accountVault, freshAccounts.AccountVaultManager.prototype);
        }
      } catch {}
      try {
        const freshState = require('./state.js');
        if (this.stateStore && freshState?.HubStateStore?.prototype) {
          Object.setPrototypeOf(this.stateStore, freshState.HubStateStore.prototype);
        }
      } catch {}
      try {
        const freshStore = require('./store.js');
        if (this.store && freshStore?.AntigravityDataStore?.prototype) {
          Object.setPrototypeOf(this.store, freshStore.AntigravityDataStore.prototype);
        }
      } catch {}
      try {
        const freshClaudeBridge = require('./compat/claude-hub-bridge.cjs');
        freshClaudeBridge?.hotUpgradeLiveState?.();
      } catch {}
      try {
        const freshBridge = require('./compat/antigravity-hub-bridge.cjs');
        freshBridge?.hotUpgradeLiveState?.(freshBridge.getBridgeState(), vscode, this);
      } catch {}
    }
  }

  async refresh(options = {}) {
    if (
      !options.force &&
      !options.forceQuota &&
      this.snapshot &&
      Date.now() < Number(this._tabSwitchCooldownUntil || 0) &&
      Date.now() - Number(this.activity?.lastConversationEventAt || 0) > 250
    ) {
      const remainingMs = Math.max(120, Number(this._tabSwitchCooldownUntil || 0) - Date.now() + 40);
      await this.refreshTabStateFast({ scheduleFullRefreshMs: remainingMs });
      return;
    }
    if (this._scheduledRefreshTimer) {
      clearTimeout(this._scheduledRefreshTimer);
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
    }
    if (this.refreshInFlight) {
      this.pendingRefresh = {
        force: Boolean(this.pendingRefresh?.force || options.force),
        forceQuota: Boolean(this.pendingRefresh?.forceQuota || options.forceQuota)
      };
      return this.refreshInFlight;
    }
    this.refreshInFlight = (async () => {
      try {
        if (!this.baselineInitialized) {
          this.baselineInitialized = true;
          await this.stateStore.ensureBaseline();
        }
        try {
          this.hotReloadUpdatedModules();
          const directAgyBridge = require('./compat/antigravity-hub-bridge.cjs');
          directAgyBridge?.tickLiveBridgeHealth?.(this);
        } catch {}
        const persisted = this.stateStore.read();
        const [snap, openTabs, agyBridgeLive, claudeBridgeLive] = await Promise.all([
          this.store.loadSnapshot({
            customTitles: persisted.customTitles,
            archivedIds: persisted.archivedIds,
            unarchivedAt: persisted.unarchivedAt,
            threadGroups: persisted.threadGroups,
            forceRefreshQuota: Boolean(options.forceQuota)
          }),
          this.tabs.getOpenTabs(),
          vscode.commands.executeCommand('antigravityHub.bridgeStatus').then(
            (res) => res || { active: false },
            () => ({ active: false })
          ),
          vscode.commands.executeCommand('antigravityHub.claudeBridgeStatus').then(
            (res) => res || { active: false },
            () => ({ active: false })
          )
        ]);

        this.snapshot = snap;
        this.activity?.reconcileSnapshot?.(snap?.threads || [], snap?.loadedAt || Date.now());
        this.openTabsList = this.applyPendingActiveTargetToTabs(
          Array.isArray(openTabs) ? openTabs : []
        );

        if (this.accountVault) {
          try {
            this.accountVault.syncActiveClaudeFromDisk(
              snap?.claudeConfigObj,
              snap?.claudeCredsObj,
              snap?.rawClaudeQuota,
              snap?.loadedAt
            );
            const curPrefs = this.stateStore.read()?.preferences || {};
            this.accountsView = await this.accountVault.resolveAccountsSnapshot({
              nowMs: Date.now(),
              forceQuota: Boolean(options.forceQuota),
              antigravityAccount: snap?.account,
              antigravityLimits: snap?.rateLimits,
              rawAntigravityQuota: snap?.rawAntigravityQuota,
              claudeAccount: snap?.claudeAccount,
              claudeLimits: snap?.claudeRateLimits,
              rawClaudeQuota: snap?.rawClaudeQuota,
              claudeRelayMerged: snap?.claudeLive?.rateLimitWindows,
              collapsedProviders: {
                antigravity: Boolean(curPrefs.antigravityUsageCollapsed),
                claude: Boolean(curPrefs.claudeUsageCollapsed),
                ...(curPrefs.collapsedAccounts || {})
              }
            });
          } catch {}
        }
        const agyActive = Boolean(agyBridgeLive?.active);
        const claudeActive = Boolean(claudeBridgeLive?.active);
        const anyActive = agyActive || claudeActive;
        const hideDuplicateIcon =
          typeof claudeBridgeLive?.hideDuplicateIcon === 'boolean'
            ? claudeBridgeLive.hideDuplicateIcon
            : Boolean(
                vscode.workspace
                  .getConfiguration('antigravityHub')
                  .get('hideDuplicateActivityBarIcon', true)
              );

        const report = this.bridgeInstallReport;
        const claudeSignedIn =
          typeof this.accountVault?.hasSignedInProvider === 'function'
            ? this.accountVault.hasSignedInProvider('claude')
            : report?.claudeSignedIn !== false;
        const needsAgy = Boolean(
          report?.needsAgyReload && (report?.agyHostUpdated || !agyActive)
        );
        const needsClaude = Boolean(
          claudeSignedIn &&
            report?.needsClaudeReload &&
            (report?.claudeHostUpdated || !claudeActive)
        );
        const showReloadBanner = Boolean(needsAgy || needsClaude);

        this.bridgeStatus = {
          active: anyActive,
          antigravityActive: agyActive,
          claudeActive,
          hideDuplicateIcon,
          reload: showReloadBanner,
          message: !showReloadBanner
            ? ''
            : needsAgy && needsClaude
              ? 'Reload VS Code once to activate the Antigravity & Claude Code bridges.'
              : needsClaude
                ? 'Reload VS Code once to activate the Claude Code bridge.'
                : 'Reload VS Code once to activate the Antigravity bridge.'
        };
        this.loading = false;

        // Sync Claude Code native archived sessions & groups
        if (snap?.claudeLive) {
          await this.stateStore.syncClaudeNativeState(snap.claudeLive);
        }

        // Adopt draft group assignments once a draft tab binds to a conversation ID
        for (const tab of this.openTabsList) {
          if (tab.id && tab.uri && this.draftGroups.has(tab.uri)) {
            const gid = this.draftGroups.get(tab.uri);
            this.draftGroups.delete(tab.uri);
            await this.stateStore.assignThreadGroup(tab.id, gid);
          }
        }

        // Check active tab & transitions
        const activeTabs = this.openTabsList.filter((t) => t.active && t.id);
        const activeTabIds = new Set(activeTabs.map((t) => t.id));
        const nowSec = Math.floor(Date.now() / 1000);
        for (const activeTab of activeTabs) {
          const activeThread = (snap.threads || []).find((t) => t.id === activeTab.id);
          await this.stateStore.markSeen(
            activeTab.id,
            Math.max(nowSec, Number(activeThread?.updatedAt) || 0),
            { clearUnread: true }
          );
        }

        const latestState = this.stateStore.read();
        for (const thread of snap.threads || []) {
          const classified = this.activity.classifyThread(thread);
          const isOpenActive = activeTabIds.has(thread.id);
          if (classified.transitionedFromWorking) {
            if (isOpenActive && vscode.window.state.focused) {
              await this.stateStore.markSeen(
                thread.id,
                Math.max(nowSec, Number(thread.updatedAt) || 0),
                { clearUnread: true }
              );
            } else {
              await this.stateStore.setUnread(thread.id, true);
            }
            notifySessionTransition({
              thread,
              state: classified.state,
              preferences: latestState.preferences,
              isActiveTab: isOpenActive,
              onOpenThread: (id) =>
                this.tabs.openThread(id, {
                  provider: thread.provider || 'antigravity',
                  title: thread.title
                })
            }).catch(() => {});
          }
        }

        // Auto-archive inactive sessions (skips open, working, waiting, unread, and grouped sessions)
        await this.sweepAutoArchiveInactive(snap);
      } finally {
        this.refreshInFlight = null;
        this.syncOpenTabBadges();
        this.render();
        if (this.pendingRefresh) {
          const nextOpts = this.pendingRefresh;
          this.pendingRefresh = null;
          this.refresh(nextOpts);
        }
      }
    })();
    return this.refreshInFlight;
  }

  buildSummaryForWindows(windowsObj) {
    const win5h = windowsObj?.['5h'] || {};
    const win7d = windowsObj?.['7d'] || {};
    const days = Array.isArray(win7d.daily)
      ? win7d.daily.map((d) => ({
          key: d.date,
          label: d.label,
          tokens: Number(d.totalTokens || 0),
          turns: Number(d.turns || 0)
        }))
      : [];

    const todayBar = days[days.length - 1] || { tokens: 0, turns: 0 };
    return {
      today: {
        sessions: Number(win5h.sessions || 0),
        turns: Math.max(Number(win5h.turns || 0), Number(todayBar.turns || 0)),
        tokens: Math.max(Number(win5h.totalTokens || 0), Number(todayBar.tokens || 0)),
        input: Number(win5h.inputTokens || 0),
        cached: Number(win5h.cachedInputTokens || 0),
        output: Number(win5h.outputTokens || 0)
      },
      week: {
        sessions: Number(win7d.sessions || 0),
        turns: Number(win7d.turns || 0),
        tokens: Number(win7d.totalTokens || 0),
        input: Number(win7d.inputTokens || 0),
        cached: Number(win7d.cachedInputTokens || 0),
        output: Number(win7d.outputTokens || 0)
      },
      days: days.length
        ? days
        : [{ key: 'Today', label: 'Today', tokens: 0, turns: 0 }]
    };
  }

  buildSummary(usage) {
    return this.buildSummaryForWindows(usage?.windows || {});
  }

  render() {
    if (this.views.size === 0 && !this.view && !this.remote) {
      return;
    }

    const persisted = this.stateStore.read();
    const prefs = persisted.preferences || {};
    const scope = prefs.scope === 'workspace' ? 'workspace' : 'all';
    const providerFilter = ['all', 'antigravity', 'claude'].includes(prefs.providerFilter)
      ? prefs.providerFilter
      : 'all';
    const collapsed = {
      usage: Boolean(prefs.accountSectionCollapsed),
      antigravityUsage: Boolean(prefs.antigravityUsageCollapsed),
      claudeUsage: Boolean(prefs.claudeUsageCollapsed),
      accounts: prefs.collapsedAccounts && typeof prefs.collapsedAccounts === 'object'
        ? { ...prefs.collapsedAccounts }
        : {},
      questions: Boolean(prefs.questionsSectionCollapsed),
      bgTasks: Boolean(prefs.bgTasksSectionCollapsed),
      sessions: Boolean(prefs.sessionSectionCollapsed),
      ungrouped: Boolean(prefs.ungroupedCollapsed),
      archived: prefs.archivedCollapsed !== undefined ? Boolean(prefs.archivedCollapsed) : true
    };
    const rawFilterStatuses = Array.isArray(prefs.filterStatuses) ? prefs.filterStatuses : [];
    const normalizedFilterStatuses =
      rawFilterStatuses.length >= 3 ||
      (rawFilterStatuses.length === 2 &&
        rawFilterStatuses.includes('completed') &&
        rawFilterStatuses.includes('working') &&
        !rawFilterStatuses.includes('needs_input'))
        ? []
        : rawFilterStatuses;
    if (normalizedFilterStatuses.length !== rawFilterStatuses.length) {
      this.stateStore.updatePreferences({ filterStatuses: normalizedFilterStatuses }).catch(() => {});
    }
    const filter = {
      statuses: normalizedFilterStatuses,
      tabStates: Array.isArray(prefs.filterTabStates) ? prefs.filterTabStates : [],
      activeOnly: Boolean(prefs.filterActiveOnly)
    };

    const snap = this.snapshot;
    const allThreads = snap?.threads || [];
    const workspaceRoots = (vscode.workspace.workspaceFolders || []).map((f) => f.uri.fsPath);

    const inScope = (thread) => {
      if (scope !== 'workspace' || workspaceRoots.length === 0) {
        return true;
      }
      if (!thread.cwd) {
        return false;
      }
      return workspaceRoots.some((root) => isSameOrChildPath(thread.cwd, root));
    };

    const openById = new Map();
    for (const tab of this.openTabsList) {
      if (tab.id && (!openById.has(tab.id) || tab.active)) {
        openById.set(tab.id, tab);
      }
    }

    const archivedSet = new Set(persisted.archivedIds || []);
    const groupIds = new Set((persisted.groups || []).map((g) => g.id));

    const scopedThreads = allThreads.filter(
      (t) => inScope(t) || openById.has(t.id) || (t.groupId && groupIds.has(t.groupId))
    );

    const rows = [];
    const seenIds = new Set();

    for (const thread of scopedThreads) {
      seenIds.add(thread.id);
      const tab = openById.get(thread.id);
      const classified = this.activity.classifyThread(thread, { recordTransition: false });
      const isOpen = Boolean(tab);
      const isActive = Boolean(tab?.active);
      const isUnread = this.stateStore.isThreadUnread(
        persisted,
        thread,
        classified.state,
        isActive
      );

      let status = 'idle';
      if (classified.state === 'waiting') {
        status = 'waiting';
      } else if (classified.state === 'thinking') {
        status = 'working';
      } else if (classified.state === 'errored') {
        status = 'failed';
      } else if (classified.state === 'completed') {
        status = 'completed';
      }

      const dot =
        status === 'waiting'
          ? 'waiting'
          : status === 'working'
            ? 'running'
            : thread.bgTask?.state === 'interrupted'
              ? 'failed'
              : isUnread
                ? status === 'failed'
                  ? 'failed'
                  : 'unread'
                : isOpen
                  ? 'idle'
                  : null;

      const category =
        status === 'waiting'
          ? 'needs_input'
          : status === 'working'
            ? 'working'
            : 'completed';

      const provider = thread.provider === 'claude' ? 'claude' : 'antigravity';
      const rawBgTasks = Array.isArray(thread.backgroundTasks) ? thread.backgroundTasks : [];
      const bgRunningCount = rawBgTasks.filter((t) => t && t.state === 'running').length;
      const bgTotalCount = rawBgTasks.length;
      const compactBgTasks = rawBgTasks.slice(-12).map((t) => ({
        id: t.id,
        fullId: t.fullId || t.id,
        subagentConversationId: t.subagentConversationId || '',
        kind: t.kind || 'task',
        subagentType: t.subagentType || '',
        summary: t.summary || '',
        command: String(t.command || '').slice(0, 320),
        state: t.state || 'completed',
        isDaemon: Boolean(t.isDaemon),
        startedAt: Number(t.startedAt || 0) * 1000,
        completedAt: t.completedAt ? Number(t.completedAt) * 1000 : 0,
        stepIndex: typeof t.stepIndex === 'number' ? t.stepIndex : -1
      }));

      rows.push({
        key: thread.id,
        id: thread.id,
        provider,
        draft: false,
        title: persisted.customTitles[thread.id] || thread.title || 'Untitled session',
        at: Number(thread.updatedAt || 0) * 1000,
        open: isOpen,
        active: isActive,
        group:
          persisted.threadGroups[thread.id] && groupIds.has(persisted.threadGroups[thread.id])
            ? persisted.threadGroups[thread.id]
            : null,
        archived: archivedSet.has(thread.id),
        cwd: thread.cwd || '',
        folder: thread.workspaceLabel || '',
        branch: thread.branch || '',
        model: thread.model || (provider === 'claude' ? 'Claude' : 'Gemini'),
        logged: true,
        status,
        dot,
        category,
        unread: isUnread,
        elsewhere: Boolean((status === 'working' || thread.elsewhere) && !isOpen),
        reason: classified.reason || null,
        stepCount: Number(thread.stepCount || 0),
        turnComplete: thread.turnComplete !== false,
        lastAssistantText: thread.lastAssistantText || '',
        pendingQuestion: thread.pendingQuestion || null,
        bgTasks: compactBgTasks,
        bgRunningCount,
        bgTotalCount
      });
    }

    for (const tab of this.openTabsList) {
      const provider = tab.provider === 'claude' ? 'claude' : 'antigravity';
      const defaultModel = provider === 'claude' ? 'Claude' : 'Gemini';
      if (tab.id && !seenIds.has(tab.id)) {
        seenIds.add(tab.id);
        rows.push({
          key: tab.id,
          id: tab.id,
          provider,
          draft: false,
          title: persisted.customTitles[tab.id] || tab.title || 'Untitled session',
          at: Date.now(),
          open: true,
          active: Boolean(tab.active),
          group: persisted.threadGroups[tab.id] || null,
          archived: false,
          cwd: '',
          folder: '',
          branch: '',
          model: defaultModel,
          logged: true,
          status: 'idle',
          dot: 'idle',
          category: 'completed',
          unread: false,
          elsewhere: false,
          reason: null
        });
      } else if (!tab.id) {
        const defaultDraftTitle =
          provider === 'claude' ? 'New Claude session' : 'New Antigravity session';
        rows.push({
          key: tab.uri,
          id: null,
          provider,
          draft: true,
          title:
            !tab.title || tab.title === 'Antigravity' || tab.title === 'Claude Code'
              ? defaultDraftTitle
              : tab.title,
          at: Date.now(),
          open: true,
          active: Boolean(tab.active),
          group: this.draftGroups.get(tab.uri) || null,
          archived: false,
          cwd: '',
          folder: '',
          branch: '',
          model: defaultModel,
          logged: false,
          status: 'idle',
          dot: 'idle',
          category: 'completed',
          unread: false,
          elsewhere: false,
          reason: null
        });
      }
    }

    rows.sort((a, b) => b.open - a.open || Boolean(b.draft) - Boolean(a.draft) || b.at - a.at);

    this.syncOpenTabBadges(persisted);

    const formatBucket = (b) => ({
      label: b.label,
      pct: b.usedPercent,
      reset: b.resetAt ? b.resetAt * 1000 : 0,
      resetText: b.resetText || '',
      expired: Boolean(b.expired)
    });

    const agyPrimaryLimits = (snap?.rateLimits?.primaryBars || []).map(formatBucket);
    const agyAllLimits = (snap?.rateLimits?.allBuckets || []).map(formatBucket);

    const claudePrimaryLimits = (snap?.claudeRateLimits?.primaryBars || []).map(formatBucket);
    const claudeAllLimits = (snap?.claudeRateLimits?.allBuckets || []).map(formatBucket);

    const agyFallbackMsg = snap?.serverConnected
      ? 'Loading quota windows…'
      : 'Waiting for Antigravity language server…';
    const claudeFallbackMsg = snap?.claudeAccount?.available
      ? 'Loading Claude quota windows…'
      : 'Sign in to Claude Code to view quota.';

    const buildAccountCardModel = (item, fallbackMsg) => {
      const provKey = item.provider === 'claude' ? 'claude' : 'antigravity';
      const pLimits = (item.rateLimits?.primaryBars || []).map(formatBucket);
      const aLimits = (item.rateLimits?.allBuckets || []).map(formatBucket);
      const prefMap =
        prefs.collapsedAccounts && typeof prefs.collapsedAccounts === 'object'
          ? prefs.collapsedAccounts
          : {};
      const isCardCollapsed =
        typeof prefMap[item.id] === 'boolean'
          ? Boolean(prefMap[item.id])
          : Boolean(item.collapsed);
      const isSignedOutItem = !item.available || Boolean(item.signedOut || item.account?.signedOut);
      return {
        id: item.id,
        provider: provKey,
        label: provKey === 'claude' ? 'Claude Code' : 'Antigravity',
        nickname: item.label || '',
        active: !isSignedOutItem && Boolean(item.active),
        hubLive: Boolean(item.hubLive),
        hubPendingCutover: Boolean(item.hubPendingCutover),
        collapsed: isCardCollapsed,
        addedAt: Number(item.addedAt || 0),
        sortOrder: Number.isFinite(Number(item.sortOrder)) ? Number(item.sortOrder) : 0,
        lastActiveAt: Number(item.lastActiveAt || 0),
        quotaUpdatedAt: Number(item.quotaUpdatedAt || snap?.loadedAt || 0),
        account: {
          name:
            item.name ||
            item.account?.name ||
            (provKey === 'claude' ? 'Claude Account' : 'Antigravity Account'),
          email: isSignedOutItem ? '' : item.email || item.account?.email || '',
          plan: isSignedOutItem
            ? ''
            : item.plan ||
              item.account?.plan ||
              (provKey === 'claude' ? 'Claude Code' : 'Google AI Pro'),
          nickname: item.label || '',
          available: !isSignedOutItem && Boolean(item.available),
          signedOut: isSignedOutItem
        },
        usage: !isSignedOutItem && pLimits.length
          ? {
              at: item.quotaUpdatedAt || snap?.loadedAt || Date.now(),
              limits: pLimits,
              allLimits: aLimits
            }
          : null,
        usageMessage: isSignedOutItem
          ? 'Not signed in.'
          : item.rateLimits?.error || fallbackMsg
      };
    };

    const agyAccountsModels = Array.isArray(this.accountsView?.antigravity) && this.accountsView.antigravity.length
      ? this.accountsView.antigravity.map((item) => buildAccountCardModel(item, agyFallbackMsg))
      : null;

    const claudeAccountsModels = Array.isArray(this.accountsView?.claude) && this.accountsView.claude.length
      ? this.accountsView.claude.map((item) => buildAccountCardModel(item, claudeFallbackMsg))
      : null;

    const agyActiveCard = agyAccountsModels?.find((a) => a.active) || agyAccountsModels?.[0] || null;
    const claudeActiveCard = claudeAccountsModels?.find((a) => a.active) || claudeAccountsModels?.[0] || null;

    const agyProviderInfo = {
      id: 'antigravity',
      label: 'Antigravity',
      account: agyActiveCard?.account || {
        name: snap?.account?.name || 'Antigravity Account',
        email: snap?.account?.email || '',
        plan: snap?.account?.plan || 'Google AI Pro',
        available: Boolean(snap?.account?.email || snap?.account?.name),
        signedOut: false
      },
      usage: agyActiveCard
        ? agyActiveCard.usage
        : agyPrimaryLimits.length
          ? {
              at: snap?.loadedAt || Date.now(),
              limits: agyPrimaryLimits,
              allLimits: agyAllLimits
            }
          : null,
      usageMessage: agyActiveCard?.usageMessage || agyFallbackMsg,
      accounts: agyAccountsModels || [
        {
          id: snap?.account?.email
            ? `antigravity:${String(snap.account.email).trim().toLowerCase()}`
            : 'antigravity:default',
          provider: 'antigravity',
          label: 'Antigravity',
          nickname: '',
          active: true,
          collapsed: Boolean(prefs.antigravityUsageCollapsed),
          account: {
            name: snap?.account?.name || 'Antigravity Account',
            email: snap?.account?.email || '',
            plan: snap?.account?.plan || 'Google AI Pro',
            nickname: '',
            available: Boolean(snap?.account?.email || snap?.account?.name),
            signedOut: false
          },
          usage: agyPrimaryLimits.length
            ? {
                at: snap?.loadedAt || Date.now(),
                limits: agyPrimaryLimits,
                allLimits: agyAllLimits
              }
            : null,
          usageMessage: agyFallbackMsg
        }
      ]
    };

    const claudeProviderInfo = {
      id: 'claude',
      label: 'Claude Code',
      account: claudeActiveCard?.account || {
        name: snap?.claudeAccount?.name || 'Claude Account',
        email: snap?.claudeAccount?.email || '',
        plan: snap?.claudeAccount?.plan || 'Claude Code',
        available: Boolean(snap?.claudeAccount?.available),
        signedOut: Boolean(snap?.claudeAccount?.signedOut)
      },
      usage: claudeActiveCard
        ? claudeActiveCard.usage
        : claudePrimaryLimits.length
          ? {
              at: snap?.loadedAt || Date.now(),
              limits: claudePrimaryLimits,
              allLimits: claudeAllLimits
            }
          : null,
      usageMessage: claudeActiveCard?.usageMessage || claudeFallbackMsg,
      accounts: claudeAccountsModels || [
        {
          id: snap?.claudeAccount?.email
            ? `claude:${String(snap.claudeAccount.email).trim().toLowerCase()}`
            : 'claude:default',
          provider: 'claude',
          label: 'Claude Code',
          nickname: '',
          active: true,
          collapsed: Boolean(prefs.claudeUsageCollapsed),
          account: {
            name: snap?.claudeAccount?.name || 'Claude Account',
            email: snap?.claudeAccount?.email || '',
            plan: snap?.claudeAccount?.plan || 'Claude Code',
            nickname: '',
            available: Boolean(snap?.claudeAccount?.available),
            signedOut: Boolean(snap?.claudeAccount?.signedOut)
          },
          usage: claudePrimaryLimits.length
            ? {
                at: snap?.loadedAt || Date.now(),
                limits: claudePrimaryLimits,
                allLimits: claudeAllLimits
              }
            : null,
          usageMessage: claudeFallbackMsg
        }
      ]
    };

    const byProviderUsage = snap?.usage?.byProvider || {};
    const summaryByProvider = {
      all: this.buildSummary(snap?.usage),
      antigravity: this.buildSummaryForWindows(byProviderUsage.antigravity || {}),
      claude: this.buildSummaryForWindows(byProviderUsage.claude || {})
    };

    const autoArchiveDays = this.getAutoArchiveInactiveDays(persisted, snap?.claudeLive);
    let hasAgyRows = false;
    let hasClaudeRows = false;
    for (const r of rows) {
      if (r.archived) continue;
      if (r.provider === 'claude') hasClaudeRows = true;
      else hasAgyRows = true;
    }
    const effectiveProviderFilter =
      (providerFilter === 'claude' && !hasClaudeRows) ||
      (providerFilter === 'antigravity' && !hasAgyRows)
        ? 'all'
        : providerFilter;
    if (effectiveProviderFilter !== providerFilter) {
      this.stateStore.updatePreferences({ providerFilter: effectiveProviderFilter }).catch(() => {});
    }

    const payload = {
      type: 'state',
      loading: this.loading,
      scope,
      providerFilter: effectiveProviderFilter,
      autoArchiveDays,
      workspace:
        vscode.workspace.name && vscode.workspace.name.toLowerCase() === 'claude'
          ? 'THEO'
          : vscode.workspace.name || 'All folders',
      account: agyProviderInfo.account,
      usage: agyProviderInfo.usage,
      usageMessage: agyProviderInfo.usageMessage,
      providers: {
        antigravity: agyProviderInfo,
        claude: claudeProviderInfo
      },
      accountOrder: Array.isArray(this.accountsView?.accountOrder)
        ? this.accountsView.accountOrder
        : [],
      pendingAccountLogin: this.accountVault?.getPendingLoginState?.() || null,
      bridge: this.bridgeStatus,
      remote: this.remote ? this.remote.getStatus() : null,
      collapsed,
      filter,
      groups: (persisted.groups || []).map((g) => ({
        id: g.id,
        name: g.name,
        collapsed: Boolean(g.collapsed)
      })),
      rows,
      total: scopedThreads.length,
      errors: 0,
      summary: summaryByProvider.all,
      summaryByProvider,
      editGroup: this.editGroup || null
    };

    const json = JSON.stringify(payload);
    if (json === this.lastPosted) {
      return;
    }
    this.lastPosted = json;
    this.editGroup = null;
    for (const v of this.views) {
      try {
        v.webview.postMessage(payload);
      } catch {}
    }
    if (this.remote) {
      this.remote.notifyStateUpdated();
    }
  }

  async handleMessage(m) {
    if (!m || typeof m.action !== 'string') {
      return;
    }

    switch (m.action) {
      case 'ready':
        this.lastPosted = null;
        this.render();
        return;

      case 'openRemote':
        await vscode.commands.executeCommand('antigravityHub.openRemote');
        return;

      case 'new': {
        this._tabSwitchCooldownUntil = Date.now() + 550;
        const newProvider = m.provider === 'claude' ? 'claude' : 'antigravity';
        this._pendingActiveTarget = null;
        const openedNew = await this.tabs.openNewSession({
          provider: newProvider,
          beside: Boolean(m.beside)
        });
        if (!m.beside && openedNew?.uri) {
          this.setPendingActiveTarget({
            key: openedNew.uri,
            provider: newProvider
          });
        }
        await this.refreshTabStateFast({
          optimisticActiveKey: m.beside ? '' : openedNew?.uri || '',
          forceOptimistic: !m.beside && Boolean(openedNew?.uri),
          scheduleFullRefreshMs: 320
        });
        return;
      }

      case 'refresh':
      case 'details':
        await this.refresh({ forceQuota: true });
        return;

      case 'reload':
        await vscode.commands.executeCommand('workbench.action.reloadWindow');
        return;

      case 'repair':
        try {
          await vscode.commands.executeCommand('antigravityHub.reconnectTabs', {
            forceRender: true
          });
        } catch {}
        if (typeof this.ensureBridge === 'function') {
          await this.ensureBridge({ promptReload: true });
        }
        await this.refresh();
        return;

      case 'config':
        await vscode.commands.executeCommand(
          'workbench.action.openSettings',
          '@ext:bhfirms.antigravity-hub'
        );
        return;

      case 'settings':
        await vscode.commands.executeCommand('antigravity.openSettings');
        return;

      case 'claudeSettings':
        await vscode.commands.executeCommand(
          'workbench.action.openSettings',
          '@ext:anthropic.claude-code'
        );
        return;

      case 'toggleDuplicateIcon':
        try {
          await vscode.commands.executeCommand(
            'antigravityHub.claudeSetActivityBarVisible',
            Boolean(m.visible)
          );
        } catch {}
        await this.refresh();
        return;

      case 'testNotification':
        await notifySessionTransition({
          thread: { id: '', title: 'Sample Unified Hub Session' },
          state: 'completed',
          preferences: {
            notifyOnComplete: true,
            notifySound: true,
            onlyNotifyBackground: false
          },
          isActiveTab: false
        });
        return;

      case 'scope':
        if (m.value === 'workspace' || m.value === 'all') {
          await this.stateStore.updatePreferences({ scope: m.value });
          this.render();
        }
        return;

      case 'providerFilter':
        if (['all', 'antigravity', 'claude'].includes(m.value)) {
          await this.stateStore.updatePreferences({ providerFilter: m.value });
          this.render();
        }
        return;

      case 'autoArchiveDays': {
        const days = Number(m.value);
        if ([0, 1, 2, 7, 14].includes(days)) {
          await this.stateStore.updatePreferences({ autoArchiveInactiveDays: days });
          try {
            await vscode.workspace
              .getConfiguration('antigravityHub')
              .update('autoArchiveInactiveDays', days, vscode.ConfigurationTarget.Global);
            await vscode.workspace
              .getConfiguration('claudeCode')
              .update('archiveInactiveSessions', days, vscode.ConfigurationTarget.Global);
          } catch {}
          if (days > 0 && this.snapshot) {
            await this.sweepAutoArchiveInactive(this.snapshot, days);
          }
          this.render();
        }
        return;
      }

      case 'archiveInactiveNow': {
        const days = typeof m.days === 'number' && m.days > 0 ? m.days : 1;
        if (this.snapshot) {
          await this.sweepAutoArchiveInactive(this.snapshot, days);
          this.render();
        }
        return;
      }

      case 'collapse': {
        const keyMap = {
          usage: 'accountSectionCollapsed',
          antigravityUsage: 'antigravityUsageCollapsed',
          claudeUsage: 'claudeUsageCollapsed',
          questions: 'questionsSectionCollapsed',
          bgTasks: 'bgTasksSectionCollapsed',
          sessions: 'sessionSectionCollapsed',
          ungrouped: 'ungroupedCollapsed',
          archived: 'archivedCollapsed'
        };
        const prefKey = keyMap[m.section];
        if (prefKey) {
          await this.stateStore.updatePreferences({ [prefKey]: Boolean(m.value) });
          this.render();
        }
        return;
      }

      case 'answerQuestion': {
        const sid = String(m.sessionId || m.id || '').trim();
        if (!sid) return;
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const isSkip = Boolean(m.skipped);
        const selectedOptionIds = Array.isArray(m.selectedOptionIds)
          ? m.selectedOptionIds.map((x) => String(x))
          : [];
        const selectedTexts = Array.isArray(m.selectedTexts)
          ? m.selectedTexts.map((x) => String(x))
          : [];
        const writeInResponse = String(m.writeInResponse || '').trim();
        const responses = Array.isArray(m.responses) ? m.responses : [];
        if (thread) {
          thread.pendingQuestion = null;
          thread.rpcWaitingCount = 0;
          thread.status = 'CASCADE_RUN_STATUS_RUNNING';
          thread.notFullyIdle = true;
        }
        this.activity?.liveByThreadId?.delete?.(sid);
        this.lastPosted = null;
        this.syncOpenTabBadges();
        this.render();

        if (provider === 'claude') {
          const answerText = writeInResponse || selectedTexts.join(', ');
          const answersMap = {};
          for (const r of responses) {
            if (r?.question && (r.writeInResponse || (r.selectedTexts && r.selectedTexts.length))) {
              answersMap[r.question] = r.writeInResponse || r.selectedTexts.join(', ');
            }
          }
          const permPayload = {
            id: m.approvalId || thread?.pendingQuestion?.approvalId || sid,
            sessionId: sid,
            approved: !isSkip && selectedOptionIds[0] !== 'deny',
            allowAlways: selectedOptionIds[0] === 'allow_always',
            writeInResponse,
            answers: answersMap
          };
          let claudeRes = null;
          try {
            const directClaude = require('./compat/claude-hub-bridge.cjs');
            if (typeof directClaude?.respondClaudePermission === 'function') {
              claudeRes = await directClaude.respondClaudePermission(permPayload);
            }
          } catch {}
          if (!claudeRes?.resolved) {
            claudeRes = await vscode.commands
              .executeCommand('antigravityHub.claudeRespondPermission', permPayload)
              .catch(() => null);
          }
          if (!claudeRes?.resolved && !isSkip && answerText) {
            await vscode.commands
              .executeCommand('antigravityHub.claudeSendPrompt', {
                id: sid,
                prompt: answerText,
                newSession: false,
                preserveFocus: false
              })
              .catch(() => null);
          }
        } else {
          let ansRes = null;
          if (this.store?.answerAntigravityQuestion) {
            ansRes = await this.store
              .answerAntigravityQuestion(sid, {
                skipped: isSkip,
                selectedOptionIds,
                selectedTexts,
                writeInResponse,
                responses
              })
              .catch(() => null);
          }
          if (!ansRes?.ok) {
            await vscode.commands
              .executeCommand('antigravityHub.remoteAction', {
                type: 'answerQuestion',
                kind: 'answerQuestion',
                id: sid,
                approvalId: m.approvalId || sid,
                skipped: isSkip,
                selectedOptionIds,
                selectedTexts,
                writeInResponse,
                responses
              })
              .catch(() => null);
          }
        }
        setTimeout(() => this.refresh().catch(() => {}), 350);
        return;
      }

      case 'accountCollapse': {
        const accountId = String(m.accountId || m.id || '').trim();
        if (!accountId) return;
        const curState = this.stateStore.read();
        const prevMap =
          curState?.preferences?.collapsedAccounts &&
          typeof curState.preferences.collapsedAccounts === 'object'
            ? curState.preferences.collapsedAccounts
            : {};
        await this.stateStore.updatePreferences({
          collapsedAccounts: {
            ...prevMap,
            [accountId]: Boolean(m.value)
          }
        });
        this.render();
        return;
      }

      case 'accountAdd': {
        if (!this.accountVault) return;
        const res = await this.accountVault.startAddAccount({
          provider: m.provider === 'claude' ? 'claude' : 'antigravity',
          label: m.label || m.nickname || '',
          emailHint: m.emailHint || m.email || '',
          switchOnComplete: m.switchOnComplete !== false,
          vscode
        });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        }
        this.lastPosted = null;
        this.render();
        return;
      }

      case 'accountCancelAdd':
        if (this.accountVault) {
          await this.accountVault.cancelAddAccount();
          this.lastPosted = null;
          this.render();
        }
        return;

      case 'accountFocusTerminal':
        this.accountVault?.focusLoginTerminal?.();
        return;

      case 'accountContinueVerification':
        this.accountVault?.continuePendingLoginAfterVerification?.();
        this.lastPosted = null;
        this.render();
        return;

      case 'accountOpenAuthUrl':
        this.accountVault?.reopenPendingAuthOrVerificationUrl?.();
        return;

      case 'accountSwitch': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        const res = await this.accountVault.switchActiveAccount({
          provider,
          accountId,
          vscode
        });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        } else if (res?.ok && res?.email) {
          vscode.window.setStatusBarMessage(
            `THEO: Active ${provider === 'claude' ? 'Claude Code' : 'Antigravity'} account → ${res.email}`,
            4000
          );
        }
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'accountNewSession': {
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (accountId && this.accountVault) {
          const list =
            provider === 'claude'
              ? this.accountsView?.claude || []
              : this.accountsView?.antigravity || [];
          const target = list.find((a) => a.id === accountId);
          if (target && !target.active) {
            const sw = await this.accountVault.switchActiveAccount({
              provider,
              accountId,
              vscode
            });
            if (!sw?.ok && sw?.error) {
              vscode.window.showWarningMessage(`THEO: ${sw.error}`);
              return;
            }
          }
        }
        await this.tabs.openNewSession({
          provider,
          beside: Boolean(m.beside)
        });
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'accountLabel': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        let nextLabel =
          typeof m.label === 'string'
            ? m.label
            : typeof m.name === 'string'
              ? m.name
              : null;
        if (m.prompt || nextLabel === null) {
          const list =
            provider === 'claude'
              ? this.accountsView?.claude || []
              : this.accountsView?.antigravity || [];
          const cur = list.find((a) => a.id === accountId);
          const entered = await vscode.window.showInputBox({
            title: `Nickname / Label for ${cur?.email || accountId}`,
            prompt: 'Optional friendly label (e.g., Personal, Friend, Work). Leave empty to clear.',
            value: cur?.label || ''
          });
          if (entered === undefined) return;
          nextLabel = entered;
        }
        this.accountVault.setAccountLabel({ provider, accountId, label: nextLabel });
        await this.refresh({ forceQuota: false });
        return;
      }

      case 'accountReorder': {
        if (!this.accountVault) return;
        this.accountVault.reorderAccount({
          accountId: String(m.accountId || m.id || '').trim(),
          provider: m.provider || '',
          direction: m.direction || '',
          targetAccountId: String(m.targetAccountId || '').trim(),
          position: m.position || '',
          orderedIds: Array.isArray(m.orderedIds) ? m.orderedIds : null
        });
        await this.refresh({ forceQuota: false });
        return;
      }

      case 'accountRemove': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        const list = (
          provider === 'claude'
            ? this.accountsView?.claude || []
            : this.accountsView?.antigravity || []
        ).filter((a) => a && a.available !== false && !a.signedOut);
        const cur = list.find((a) => a.id === accountId) || list[0] || null;
        const isLastForProvider = list.length <= 1;
        const provLabel = provider === 'claude' ? 'Claude Code' : 'Antigravity';
        if (m.confirm !== false) {
          const actionBtnLabel = isLastForProvider ? 'Sign out' : 'Disconnect';
          const promptMsg = isLastForProvider
            ? `Sign out ${cur?.email || provLabel} from ${provLabel}? Your other connected accounts will remain signed in.`
            : `Disconnect ${cur?.email || accountId} from THEO? Your other connected accounts will remain signed in.`;
          const choice = await vscode.window.showWarningMessage(
            promptMsg,
            { modal: true },
            actionBtnLabel
          );
          if (choice !== actionBtnLabel) return;
        }
        const res = await this.accountVault.removeAccount({ provider, accountId, vscode });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        } else if (res?.ok) {
          vscode.window.setStatusBarMessage(
            `THEO: ${res.signedOutProvider ? 'Signed out' : 'Disconnected'} ${cur?.email || provLabel}`,
            4000
          );
        }
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'filter':
        if (m.filter && typeof m.filter === 'object') {
          await this.stateStore.updatePreferences({
            filterStatuses: Array.isArray(m.filter.statuses) ? m.filter.statuses : [],
            filterTabStates: Array.isArray(m.filter.tabStates) ? m.filter.tabStates : [],
            filterActiveOnly: Boolean(m.filter.activeOnly)
          });
          this.render();
        }
        return;

      case 'open':
        if (m.id) {
          this._tabSwitchCooldownUntil = Date.now() + 550;
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const provider = thread?.provider || m.provider || 'antigravity';
          const title = thread?.title || '';
          this.setPendingActiveTarget({
            id: m.id,
            provider,
            title
          });
          await this.stateStore.markSeen(
            m.id,
            Math.max(Math.floor(Date.now() / 1000), Number(thread?.updatedAt) || 0),
            { clearUnread: true }
          );
          this.syncOpenTabBadges();
          this.render();
          await this.tabs.openThread(m.id, {
            provider,
            title
          });
          await this.markThreadSeen(m.id);
          await this.refreshTabStateFast({
            optimisticActiveId: m.id,
            forceOptimistic: true,
            scheduleFullRefreshMs: 380
          });
        }
        return;

      case 'beside':
        if (m.id) {
          this._tabSwitchCooldownUntil = Date.now() + 450;
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          await this.tabs.openThread(m.id, {
            provider: thread?.provider || m.provider || 'antigravity',
            title: thread?.title || '',
            beside: true
          });
          await this.markThreadSeen(m.id);
          await this.refreshTabStateFast({
            scheduleFullRefreshMs: 380
          });
        }
        return;

      case 'focus':
        this._tabSwitchCooldownUntil = Date.now() + 550;
        if (!m.beside && (m.id || m.key)) {
          this.setPendingActiveTarget({
            id: m.id || '',
            key: m.key || '',
            provider: m.provider || 'antigravity'
          });
          this.syncOpenTabBadges();
          this.render();
        }
        if (m.key) {
          await this.tabs.focusDraftTab(m.key, { beside: Boolean(m.beside) });
        }
        if (m.id) {
          await this.markThreadSeen(m.id);
        }
        await this.refreshTabStateFast({
          optimisticActiveId: m.beside ? '' : m.id || '',
          optimisticActiveKey: m.beside ? '' : m.key || '',
          forceOptimistic: !m.beside && Boolean(m.id || m.key),
          scheduleFullRefreshMs: 380
        });
        return;

      case 'closeTab':
        this.clearPendingActiveTargetIfMatches({ id: m.id, key: m.key });
        await this.tabs.closeThreadTab(m.id, { key: m.key });
        await this.refresh();
        return;

      case 'inspectBgTask': {
        const sid = String(m.sessionId || m.id || '').trim();
        const tid = String(m.taskId || '').trim();
        if (!sid || !tid) return;
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const matched =
          (thread?.backgroundTasks || []).find((t) => t.id === tid || t.fullId === tid) ||
          m.task ||
          { id: tid, fullId: tid, kind: 'task', summary: tid, command: '', state: 'completed' };
        const output = this.store?.readBackgroundTaskOutput
          ? this.store.readBackgroundTaskOutput(sid, provider, matched, 8000)
          : matched.outputPreview || '';
        const detailPayload = {
          type: 'bgTaskDetail',
          sessionId: sid,
          sessionTitle:
            this.stateStore.read()?.customTitles?.[sid] ||
            thread?.title ||
            m.sessionTitle ||
            'Session',
          provider,
          task: {
            id: matched.id,
            fullId: matched.fullId || matched.id,
            subagentConversationId: matched.subagentConversationId || '',
            kind: matched.kind || 'task',
            subagentType: matched.subagentType || '',
            summary: matched.summary || matched.id,
            command: matched.command || '',
            state: matched.state || 'completed',
            isDaemon: Boolean(matched.isDaemon),
            startedAt:
              Number(matched.startedAt || 0) > 0 && Number(matched.startedAt || 0) < 1e12
                ? Number(matched.startedAt) * 1000
                : Number(matched.startedAt || 0),
            completedAt:
              Number(matched.completedAt || 0) > 0 && Number(matched.completedAt || 0) < 1e12
                ? Number(matched.completedAt) * 1000
                : Number(matched.completedAt || 0),
            stepIndex: typeof matched.stepIndex === 'number' ? matched.stepIndex : -1
          },
          output
        };
        for (const v of this.views) {
          try {
            v.webview.postMessage(detailPayload);
          } catch {}
        }
        return;
      }

      case 'cancelBgTask': {
        const sid = String(m.sessionId || m.id || '').trim();
        const tid = String(m.taskId || '').trim();
        if (!sid || !tid) return;
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const matched =
          (thread?.backgroundTasks || []).find((t) => t.id === tid || t.fullId === tid) ||
          { id: tid, fullId: tid, kind: m.kind || 'task', stepIndex: typeof m.stepIndex === 'number' ? m.stepIndex : -1 };
        if (thread && Array.isArray(thread.backgroundTasks)) {
          for (const t of thread.backgroundTasks) {
            if (t.id === tid || t.fullId === tid) {
              t.state = 'cancelled';
              t.completedAt = Math.floor(Date.now() / 1000);
            }
          }
          if (thread.bgTask && (thread.bgTask.id === tid || thread.bgTask.id === matched.id)) {
            thread.bgTask = null;
          }
        }
        this.lastPosted = null;
        this.render();
        if (this.store?.cancelBackgroundTaskOnServer) {
          await this.store.cancelBackgroundTaskOnServer(sid, provider, matched).catch(() => {});
        }
        await this.refresh();
        return;
      }

      case 'cancelAllBgTasks': {
        const filterSid = String(m.sessionId || '').trim();
        const targets = (this.snapshot?.threads || []).filter((t) =>
          filterSid ? t.id === filterSid : Array.isArray(t.backgroundTasks) && t.backgroundTasks.some((x) => x.state === 'running')
        );
        for (const thread of targets) {
          const running = (thread.backgroundTasks || []).filter((x) => x.state === 'running');
          for (const item of running) {
            item.state = 'cancelled';
            item.completedAt = Math.floor(Date.now() / 1000);
            if (this.store?.cancelBackgroundTaskOnServer) {
              await this.store
                .cancelBackgroundTaskOnServer(thread.id, thread.provider || 'antigravity', item)
                .catch(() => {});
            }
          }
          thread.bgTask = null;
        }
        this.lastPosted = null;
        this.render();
        await this.refresh();
        return;
      }

      case 'interrupt':
      case 'stop':
      case 'cancel':
        if (m.id) {
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const provider = thread?.provider || m.provider || '';
          try {
            if (provider !== 'claude') {
              this.store?.markCascadeUserCancelled?.(m.id, true);
            }
            this.activity?.liveByThreadId?.delete?.(m.id);
            if (thread) {
              thread.userCancelled = true;
              thread.status = 'CASCADE_RUN_STATUS_IDLE';
              thread.notFullyIdle = false;
              thread.bgTask = null;
            }
            await this.stateStore.setUnread(
              m.id,
              false,
              Math.max(Math.floor(Date.now() / 1000), Number(thread?.updatedAt) || 0)
            );
            this.syncOpenTabBadges();
            this.render();
          } catch {}
          if (this.remote && typeof this.remote.interruptSession === 'function') {
            await this.remote.interruptSession(m.id, provider);
          } else {
            await this.store.cancelSessionOnServer(m.id, provider).catch(() => {});
            await this.refresh();
          }
        }
        return;

      case 'rename':
        if (m.id) {
          const cleanName = String(m.name || '')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, 120);
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const provider = thread?.provider || m.provider || '';
          await this.stateStore.setCustomTitle(m.id, cleanName);
          await this.tabs.syncTabTitle(m.id, cleanName, provider);
          this.store.renameSessionOnServer(m.id, cleanName, provider).catch(() => {});
          await this.refresh();
        }
        return;

      case 'archive': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        const archived = Boolean(m.value);
        if (archived) {
          for (const cid of cleanIds) {
            this.clearPendingActiveTargetIfMatches({ id: cid });
          }
        }
        if (cleanIds.length > 0) {
          await this.stateStore.setArchivedMany(cleanIds, archived, {
            manualUnarchive: !archived
          });
          if (archived) {
            await this.removeSessionsFromClaudeGroups(cleanIds);
          }
          const threadsById = new Map(
            (this.snapshot?.threads || []).map((t) => [t.id, t])
          );
          const claudeIds = cleanIds.filter(
            (id) => threadsById.get(id)?.provider === 'claude' || !threadsById.has(id)
          );
          if (claudeIds.length > 0) {
            vscode.commands
              .executeCommand('antigravityHub.claudeSetArchived', {
                ids: claudeIds,
                archived
              })
              .then(
                () => {},
                () => {}
              );
          }
        }
        this.render();
        return;
      }

      case 'unread': {
        const ids = Array.isArray(m.ids) ? m.ids : [m.id];
        const nowSec = Math.floor(Date.now() / 1000);
        for (const id of ids) {
          if (id) {
            const thread = (this.snapshot?.threads || []).find((t) => t.id === id);
            await this.stateStore.setUnread(
              id,
              Boolean(m.value),
              Math.max(nowSec, Number(thread?.updatedAt) || 0)
            );
            if (thread?.provider === 'claude') {
              try {
                await vscode.commands.executeCommand('antigravityHub.claudeSetUnread', {
                  id,
                  unread: Boolean(m.value)
                });
              } catch {}
            }
          }
        }
        this.syncOpenTabBadges();
        this.render();
        return;
      }

      case 'groupCreate': {
        const cleanGrpName = String(m.name || '').replace(/\s+/g, ' ').trim();
        const grp = await this.stateStore.createGroup(
          cleanGrpName || 'New group',
          '',
          String(m.group || '').trim()
        );
        if (grp) {
          const ids = Array.isArray(m.ids) ? m.ids : m.id ? [m.id] : [];
          for (const id of ids) {
            if (id) {
              await this.stateStore.assignThreadGroup(id, grp.id);
            }
          }
          if (!cleanGrpName) {
            this.editGroup = grp.id;
          }
          this.render();
        }
        return;
      }

      case 'newInGroup':
        if (m.group) {
          this._pendingActiveTarget = null;
          const opened = await this.tabs.openNewSession({
            provider: m.provider === 'claude' ? 'claude' : 'antigravity'
          });
          if (opened?.uri) {
            this.draftGroups.set(opened.uri, m.group);
          }
          await this.stateStore.toggleGroupCollapsed(m.group, false);
          await this.refresh();
        }
        return;

      case 'groupRename':
        if (m.group && m.name) {
          await this.stateStore.renameGroup(m.group, m.name);
          this.render();
        }
        return;

      case 'groupDelete':
        if (m.group) {
          const curState = this.stateStore.read();
          const victim = (curState.groups || []).find((g) => g.id === m.group);
          const memberIds = Object.entries(curState.threadGroups || {})
            .filter(([, gid]) => gid === m.group)
            .map(([tid]) => tid);
          await this.stateStore.deleteGroup(m.group);
          if (memberIds.length > 0) {
            await this.removeSessionsFromClaudeGroups(memberIds, m.group);
          }
          // Also purge the group from the native Claude Code extension's per-workspace
          // `sessionGroups:*` storage so it cannot be re-imported later.
          try {
            await vscode.commands.executeCommand('antigravityHub.claudeDeleteGroup', {
              id: m.group,
              name: victim?.name || ''
            });
          } catch {}
          this.render();
        }
        return;

      case 'groupToggle':
        if (m.group) {
          await this.stateStore.toggleGroupCollapsed(m.group, Boolean(m.value));
          this.render();
        }
        return;

      case 'groupAdd': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        if (cleanIds.length > 0 && m.group) {
          if (typeof this.stateStore.assignThreadGroupsMany === 'function') {
            await this.stateStore.assignThreadGroupsMany(cleanIds, m.group);
          } else {
            for (const id of cleanIds) {
              await this.stateStore.assignThreadGroup(id, m.group);
            }
          }
          if (this.store?.removedClaudeGroupSessionIds instanceof Set) {
            for (const id of cleanIds) {
              this.store.removedClaudeGroupSessionIds.delete(id);
            }
          }
        }
        this.render();
        return;
      }

      case 'groupRemove': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        if (cleanIds.length > 0) {
          if (typeof this.stateStore.assignThreadGroupsMany === 'function') {
            await this.stateStore.assignThreadGroupsMany(cleanIds, '');
          } else {
            for (const id of cleanIds) {
              await this.stateStore.assignThreadGroup(id, '');
            }
          }
          await this.removeSessionsFromClaudeGroups(cleanIds, String(m.group || '').trim());
        }
        this.render();
        return;
      }

      case 'copy':
        if (m.id) {
          await vscode.env.clipboard.writeText(m.id);
          vscode.window.setStatusBarMessage(`Copied session ID: ${m.id}`, 2500);
        }
        return;

      case 'reveal':
        if (m.id) {
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const logPath = this.store.getTranscriptLogPath(m.id, thread?.provider || m.provider || '');
          if (logPath && fs.existsSync(logPath)) {
            const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(logPath));
            await vscode.window.showTextDocument(doc, { preview: true });
          } else {
            vscode.window.showInformationMessage('No local transcript log found for this session yet.');
          }
        }
        return;
    }
  }

  async removeSessionsFromClaudeGroups(ids = [], groupId = '') {
    const cleanIds = (Array.isArray(ids) ? ids : [ids])
      .map((x) => String(x || '').trim())
      .filter(Boolean);
    if (cleanIds.length === 0) {
      return;
    }
    const rmSet = new Set(cleanIds);
    try {
      this.store?.noteRemovedClaudeGroupSessions?.(cleanIds);
    } catch {}
    try {
      if (Array.isArray(this.snapshot?.claudeLive?.sessionGroups)) {
        for (const g of this.snapshot.claudeLive.sessionGroups) {
          if (g && Array.isArray(g.sessionIds) && (!groupId || g.id === groupId)) {
            g.sessionIds = g.sessionIds.filter((sid) => !rmSet.has(String(sid || '').trim()));
          }
        }
      }
      if (Array.isArray(this.snapshot?.threads)) {
        for (const t of this.snapshot.threads) {
          if (t && rmSet.has(t.id) && (!groupId || t.groupId === groupId)) {
            t.groupId = '';
          }
        }
      }
    } catch {}
    try {
      const directBridge = require('./compat/claude-hub-bridge.cjs');
      if (typeof directBridge?.removeSessionsFromClaudeGroups === 'function') {
        await directBridge.removeSessionsFromClaudeGroups(directBridge.getBridgeState?.(), {
          ids: cleanIds,
          group: groupId
        });
      }
    } catch {}
    try {
      await vscode.commands.executeCommand('antigravityHub.claudeRemoveFromGroup', {
        ids: cleanIds,
        group: groupId
      });
    } catch {}
  }

  dispose() {
    if (this.renderTimer) {
      clearTimeout(this.renderTimer);
      this.renderTimer = null;
    }
    if (this._scheduledRefreshTimer) {
      clearTimeout(this._scheduledRefreshTimer);
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
    }
  }
}

module.exports = {
  HubProvider
};
