const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const { randomBytes } = require('crypto');
const { isSameOrChildPath } = require('./data');
const { notifySessionTransition } = require('./desktop-notify');
const { AccountVaultManager } = require('./accounts');
const {
  resolveClaudePermissionModePaths,
  resolveSharedClaudePermissionModeInfo,
  writeSharedClaudePermissionMode,
  normalizeExplicitClaudeMode
} = require('./direct-runner');

// Load limits for the sidebar pipeline (2026-11-12). Every streaming event from a running session used to
// force a complete reload, and a fast tab sync with a full render while one was in flight, on the
// Extension Host thread. A forced (activity) reload now runs at most once per
// ACTIVITY_REFRESH_MIN_INTERVAL_MS. Antigravity events carry live conversation state, so their running and
// waiting indicators stay current in between; Claude events carry none, so a Claude row's status, unread
// mark, pending question and finished toast follow the next reload, at most this interval plus one reload later.
const ACTIVITY_REFRESH_MIN_INTERVAL_MS = 2000;
// Spacing of the fast tab sync that forced events run while a reload is in flight or being held.
const ACTIVITY_FAST_TAB_SYNC_MIN_INTERVAL_MS = 250;
// requestRender() bursts are coalesced to this spacing; a single isolated request still renders in 45 ms.
const RENDER_BURST_MIN_INTERVAL_MS = 250;
// A payload that differs from the last post only in clock stamps is reposted at most this often.
const HEARTBEAT_POST_MIN_INTERVAL_MS = 30000;
// Upper bound on how long a clicked row stays highlighted while its tab is still opening.
const OPEN_PENDING_ACTIVE_MAX_MS = 12000;

// Splits the posted payload into `sig` (the payload with its clock stamps neutralised) and `stamps` (those
// stamps alone). Two payloads with the same `sig` show the same thing in the sidebar and on the phone:
// only "fetched at", "last sync" and latency values differ, and no view reads those from this payload.
// `sig` and `stamps` together are equal exactly when the full payload JSON is equal.
function buildStablePostSignature(payload) {
  const stamps = [];
  const stripUsage = (u) => {
    if (!u || typeof u !== 'object') return u;
    stamps.push(u.at);
    return { ...u, at: 0 };
  };
  const stripAccount = (a) => {
    if (!a || typeof a !== 'object') return a;
    stamps.push(a.quotaUpdatedAt);
    return { ...a, quotaUpdatedAt: 0, usage: stripUsage(a.usage) };
  };
  const stripProvider = (p) =>
    p && typeof p === 'object'
      ? {
          ...p,
          usage: stripUsage(p.usage),
          accounts: Array.isArray(p.accounts) ? p.accounts.map(stripAccount) : p.accounts
        }
      : p;
  let remote = payload?.remote;
  if (remote && typeof remote === 'object') {
    stamps.push(remote.lastCloudSyncAt, remote.lastCloudAttemptAt, remote.cloudSyncInFlight);
    let edgeRelay = remote.edgeRelay;
    if (edgeRelay && typeof edgeRelay === 'object') {
      stamps.push(edgeRelay.latencyMs);
      edgeRelay = { ...edgeRelay, latencyMs: 0 };
    }
    remote = {
      ...remote,
      lastCloudSyncAt: 0,
      lastCloudAttemptAt: 0,
      cloudSyncInFlight: false,
      edgeRelay
    };
  }
  const providers =
    payload?.providers && typeof payload.providers === 'object'
      ? {
          ...payload.providers,
          antigravity: stripProvider(payload.providers.antigravity),
          claude: stripProvider(payload.providers.claude)
        }
      : payload?.providers;
  const sig = JSON.stringify({ ...payload, usage: stripUsage(payload?.usage), providers, remote });
  return { sig, stamps: JSON.stringify(stamps) };
}

class HubProvider {
  constructor(context, deps) {
    this.context = context;
    this.store = deps.store;
    this.stateStore = deps.stateStore;
    this.activity = deps.activity;
    this.tabs = deps.tabs;
    this.ensureBridge = deps.ensureBridge;
    this.getPcSetupView = deps.getPcSetupView || null;
    this.checkPcSetup = deps.checkPcSetup || null;
    this.applyPcSetup = deps.applyPcSetup || null;
    this.accountVault =
      deps.accountVault ||
      new AccountVaultManager({
        onStateChange: () => {
          this.refresh({ forceQuota: false });
        }
      });
    this.accountsView = {
      antigravity: [],
      claude: [],
      pendingAccountLogin: null
    };

    this.view = null;
    this.views = new Set();
    this.snapshot = null;
    this.openTabsList = [];
    this.bridgeStatus = {
      active: false,
      antigravityActive: false,
      claudeActive: false,
      hideDuplicateIcon: true,
      reload: false,
      message: ''
    };
    this.bridgeInstallReport = null;
    this.loading = true;
    this.lastPosted = null;
    this.editGroup = null;
    this.renderTimer = null;
    this.refreshInFlight = null;
    this.pendingRefresh = null;
    this._scheduledRefreshTimer = null;
    this._scheduledRefreshOpts = null;
    this._tabSwitchCooldownUntil = 0;
    this._pendingActiveTarget = null;
    this._pendingActiveExpiryTimer = null;
    this._openReqSeq = 0;
    this.baselineInitialized = false;
    this.draftGroups = new Map();
    this.draftCreatedAt = new Map();
    this._permCacheWatcher = null;
    this._permCacheDebounce = null;
    if (process.env.THEO_SMOKE_TEST !== '1') {
      try {
        const { cacheFile } = resolveClaudePermissionModePaths();
        const claudeDir = cacheFile ? path.dirname(cacheFile) : '';
        if (claudeDir && fs.existsSync(claudeDir)) {
          const w = fs.watch(claudeDir, (_evt, fname) => {
            if (fname && String(fname) !== '.theo-claude-permission-mode.json') return;
            if (this._permCacheDebounce) clearTimeout(this._permCacheDebounce);
            this._permCacheDebounce = setTimeout(() => {
              this._permCacheDebounce = null;
              this.lastPosted = null;
              this.render();
            }, 40);
            if (typeof this._permCacheDebounce?.unref === 'function') {
              this._permCacheDebounce.unref();
            }
          });
          w.on('error', () => {});
          if (typeof w.unref === 'function') w.unref();
          this._permCacheWatcher = w;
        }
      } catch {}
    }
  }

  clearPendingActiveExpiryTimer() {
    if (this._pendingActiveExpiryTimer) {
      clearTimeout(this._pendingActiveExpiryTimer);
      this._pendingActiveExpiryTimer = null;
    }
  }

  setPendingActiveTarget({
    id = '',
    key = '',
    provider = 'antigravity',
    title = '',
    durationMs = 2200
  } = {}) {
    const cleanId = String(id || '').trim();
    const cleanKey = String(key || '').trim();
    if (!cleanId && !cleanKey) {
      this._pendingActiveTarget = null;
      this.clearPendingActiveExpiryTimer();
      return null;
    }
    const now = Date.now();
    const prev = this._pendingActiveTarget;
    const prevAlive = Boolean(prev && now < Number(prev.until || 0));
    const sameAsPrev = Boolean(
      prevAlive && ((cleanId && prev.id === cleanId) || (cleanKey && prev.key === cleanKey))
    );
    const outgoingIds = new Set(prevAlive && prev.outgoingIds ? prev.outgoingIds : []);
    const outgoingKeys = new Set(prevAlive && prev.outgoingKeys ? prev.outgoingKeys : []);
    if (prevAlive && !sameAsPrev) {
      if (prev.id) outgoingIds.add(String(prev.id).trim());
      if (prev.key) outgoingKeys.add(String(prev.key).trim());
    }
    if (Array.isArray(this.openTabsList)) {
      for (const tab of this.openTabsList) {
        if (!tab?.active) continue;
        const tabMatchesTarget =
          (cleanId && tab.id === cleanId) || (cleanKey && tab.uri === cleanKey);
        if (!tabMatchesTarget) {
          if (tab.id) outgoingIds.add(String(tab.id).trim());
          if (tab.uri) outgoingKeys.add(String(tab.uri).trim());
        }
      }
    }
    if (cleanId) outgoingIds.delete(cleanId);
    if (cleanKey) outgoingKeys.delete(cleanKey);
    const ttl = Math.max(250, Number(durationMs) || 2200);
    const alreadyOpenInTabs = Boolean(
      Array.isArray(this.openTabsList) &&
        this.openTabsList.some(
          (t) => (cleanId && t?.id === cleanId) || (cleanKey && t?.uri === cleanKey)
        )
    );
    const targetObj = {
      id: cleanId,
      key: cleanKey,
      provider: provider === 'claude' ? 'claude' : 'antigravity',
      title: String(title || ''),
      outgoingIds,
      outgoingKeys,
      setAt: now,
      until: now + ttl,
      seenOpenInTabs: alreadyOpenInTabs,
      confirmedInTabs: false,
      confirmedAt: 0
    };
    this._pendingActiveTarget = targetObj;
    this.clearPendingActiveExpiryTimer();
    this._pendingActiveExpiryTimer = setTimeout(() => {
      this._pendingActiveExpiryTimer = null;
      if (this._pendingActiveTarget === targetObj && Date.now() >= targetObj.until) {
        this._pendingActiveTarget = null;
        this.lastPosted = null;
        this.refreshTabStateFast().catch(() => {});
      }
    }, ttl + 45);
    if (typeof this._pendingActiveExpiryTimer?.unref === 'function') {
      this._pendingActiveExpiryTimer.unref();
    }
    if (Array.isArray(this.openTabsList)) {
      this.openTabsList = this.applyPendingActiveTargetToTabs(this.openTabsList);
    }
    return this._pendingActiveTarget;
  }

  // A sidebar click holds its row highlighted for as long as the tab is still opening (a cold Claude
  // session on a busy host can take longer than the default 2.2 s), then for a normal confirmation window
  // once the open call has returned. Without this the highlight fell back to the previously active
  // session mid-open and jumped again when the tab finally appeared.
  settlePendingActiveTarget(targetObj, durationMs = 2200) {
    if (!targetObj || this._pendingActiveTarget !== targetObj) {
      return;
    }
    const ttl = Math.max(250, Number(durationMs) || 2200);
    targetObj.until = Date.now() + ttl;
    this.clearPendingActiveExpiryTimer();
    this._pendingActiveExpiryTimer = setTimeout(() => {
      this._pendingActiveExpiryTimer = null;
      if (this._pendingActiveTarget === targetObj && Date.now() >= targetObj.until) {
        this._pendingActiveTarget = null;
        this.lastPosted = null;
        this.refreshTabStateFast().catch(() => {});
      }
    }, ttl + 45);
    if (typeof this._pendingActiveExpiryTimer?.unref === 'function') {
      this._pendingActiveExpiryTimer.unref();
    }
  }

  clearPendingActiveTargetIfMatches({ id = '', key = '' } = {}) {
    const cur = this._pendingActiveTarget;
    if (!cur) {
      return;
    }
    const cleanId = String(id || '').trim();
    const cleanKey = String(key || '').trim();
    if (
      (!cleanId && !cleanKey) ||
      (cleanId && cur.id === cleanId) ||
      (cleanKey && cur.key === cleanKey)
    ) {
      this._pendingActiveTarget = null;
      this.clearPendingActiveExpiryTimer();
    }
  }

  getPendingActiveTarget(now = Date.now()) {
    const cur = this._pendingActiveTarget;
    if (!cur || now >= Number(cur.until || 0)) {
      if (cur) {
        this._pendingActiveTarget = null;
        this.clearPendingActiveExpiryTimer();
      }
      return null;
    }
    return cur;
  }

  applyPendingActiveTargetToTabs(openTabs, explicitTarget = null) {
    const tabs = Array.isArray(openTabs)
      ? openTabs.map((t) => (t && typeof t === 'object' ? { ...t } : t))
      : [];
    const now = Date.now();
    const pending = this.getPendingActiveTarget(now);
    const matchesTarget = (tab, target) =>
      Boolean(
        tab &&
          target &&
          ((target.id && tab.id === target.id) || (target.key && tab.uri === target.key))
      );

    if (pending) {
      const rawTargetOpen = tabs.some((t) => matchesTarget(t, pending));
      if (rawTargetOpen) {
        pending.seenOpenInTabs = true;
      } else if (pending.seenOpenInTabs) {
        // Target tab was open and has now been closed — release immediately instead of resurrecting it!
        this._pendingActiveTarget = null;
        this.clearPendingActiveExpiryTimer();
        return tabs;
      }
      const rawTargetActive = tabs.some((t) => Boolean(t?.active) && matchesTarget(t, pending));
      const rawOtherActive = tabs.some((t) => Boolean(t?.active) && !matchesTarget(t, pending));

      if (rawTargetActive && !rawOtherActive) {
        pending.confirmedInTabs = true;
        if (!pending.confirmedAt) {
          pending.confirmedAt = now;
        }
        return tabs;
      }

      // Never allow an outgoing tab's late focus/view-state bounce to clear _pendingActiveTarget;
      // only release early when VS Code's own openTabs snapshot genuinely moved active state to a third tab
      // (or to the outgoing tab well after confirmation when the user deliberately clicked back in the tab bar).
      const otherActiveIsOutgoing = tabs.some(
        (t) =>
          Boolean(t?.active) &&
          !matchesTarget(t, pending) &&
          ((t.id && pending.outgoingIds?.has?.(t.id)) ||
            (t.uri && pending.outgoingKeys?.has?.(t.uri)))
      );
      const canReleaseToOther =
        pending.confirmedInTabs &&
        !rawTargetActive &&
        rawOtherActive &&
        (otherActiveIsOutgoing
          ? pending.confirmedAt > 0 && now - pending.confirmedAt > 900
          : now - pending.setAt > 280);
      if (canReleaseToOther) {
        this._pendingActiveTarget = null;
        this.clearPendingActiveExpiryTimer();
      } else {
        const matched = tabs.some((t) => matchesTarget(t, pending));
        if (matched) {
          for (const t of tabs) {
            const isTarget = matchesTarget(t, pending);
            t.active = isTarget;
            if (isTarget) {
              t.visible = true;
            }
          }
        } else if (pending.id || pending.key) {
          for (const t of tabs) {
            if (t) t.active = false;
          }
          const thread = pending.id
            ? (this.snapshot?.threads || []).find((th) => th.id === pending.id)
            : null;
          tabs.push({
            uri: pending.key || '',
            id: pending.id || '',
            provider: thread?.provider || pending.provider || 'antigravity',
            title: thread?.title || pending.title || '',
            active: true,
            visible: true,
            viewColumn: 1
          });
        }
        return tabs;
      }
    }

    const cleanId = String(explicitTarget?.id || '').trim();
    const cleanKey = String(explicitTarget?.key || '').trim();
    const forceExplicit = Boolean(explicitTarget?.force);
    // Only honor explicitTarget when explicitly forced (e.g. sidebar user click); unforced bridge/extension
    // notifications must never override authoritative vscode.window.tabGroups active state.
    if (forceExplicit && (cleanId || cleanKey)) {
      const target = { id: cleanId, key: cleanKey };
      const matched = tabs.some((t) => matchesTarget(t, target));
      if (matched) {
        for (const t of tabs) {
          const isTarget = matchesTarget(t, target);
          t.active = isTarget;
          if (isTarget) {
            t.visible = true;
          }
        }
      } else if (cleanId || cleanKey) {
        for (const t of tabs) {
          if (t) t.active = false;
        }
        const thread = cleanId
          ? (this.snapshot?.threads || []).find((th) => th.id === cleanId)
          : null;
        tabs.push({
          uri: cleanKey,
          id: cleanId,
          provider: thread?.provider || 'antigravity',
          title: thread?.title || '',
          active: true,
          visible: true,
          viewColumn: 1
        });
      }
    }
    return tabs;
  }

  get visible() {
    for (const v of this.views) {
      if (v && v.visible) {
        return true;
      }
    }
    return Boolean(this.view?.visible);
  }

  async markThreadSeen(threadId, seenAt = 0) {
    const id = String(threadId || '').trim();
    if (!id) {
      return;
    }
    const pending = this.getPendingActiveTarget();
    if (
      pending &&
      pending.id !== id &&
      pending.outgoingIds?.has?.(id) &&
      Date.now() - Number(pending.setAt || 0) < 900
    ) {
      return;
    }
    const thread = (this.snapshot?.threads || []).find((t) => t.id === id);
    const effectiveSeenAt = Math.max(
      Number(seenAt) || 0,
      Number(thread?.updatedAt) || 0,
      Math.floor(Date.now() / 1000)
    );
    await this.stateStore.markSeen(id, effectiveSeenAt, { clearUnread: true });
    if (thread?.provider === 'claude') {
      try {
        vscode.commands
          .executeCommand('antigravityHub.claudeSetUnread', {
            id,
            unread: false
          })
          .then(
            () => {},
            () => {}
          );
      } catch {}
    }
    if (Array.isArray(this.openTabsList)) {
      this.openTabsList = this.applyPendingActiveTargetToTabs(this.openTabsList);
    }
    this.syncOpenTabBadges();
    this.requestRender();
  }

  scheduleRefresh(delayMs = 280, options = {}) {
    this._scheduledRefreshOpts = {
      force: Boolean(this._scheduledRefreshOpts?.force || options.force),
      forceQuota: Boolean(this._scheduledRefreshOpts?.forceQuota || options.forceQuota)
    };
    const waitMs = Math.max(40, Number(delayMs) || 280);
    const dueAt = Date.now() + waitMs;
    if (this._scheduledRefreshTimer) {
      // A sooner request (a tab change wants its reload in 320 ms) re-arms a later timer, such as the one
      // an activity hold armed. A later request never pushes an earlier one back.
      if (dueAt + 15 >= Number(this._scheduledRefreshDueAt || 0)) {
        return;
      }
      clearTimeout(this._scheduledRefreshTimer);
      this._scheduledRefreshTimer = null;
    }
    this._scheduledRefreshDueAt = dueAt;
    this._scheduledRefreshTimer = setTimeout(() => {
      const opts = this._scheduledRefreshOpts || {};
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
      this._scheduledRefreshDueAt = 0;
      this.refresh(opts).catch(() => {});
    }, waitMs);
    if (typeof this._scheduledRefreshTimer?.unref === 'function') {
      this._scheduledRefreshTimer.unref();
    }
  }

  // Claude Code keeps its own unread list; a session marked read here is cleared there too.
  clearClaudeNativeUnread(thread) {
    if (thread?.provider !== 'claude' || !thread.id) {
      return;
    }
    try {
      Promise.resolve(
        vscode.commands.executeCommand('antigravityHub.claudeSetUnread', { id: thread.id, unread: false })
      ).catch(() => {});
    } catch {}
  }

  handleTabClosedFast({ id = '', key = '' } = {}) {
    const cleanId = String(id || '').trim();
    const cleanKey = String(key || '').trim();
    if (!cleanId && !cleanKey) {
      return;
    }
    this.clearPendingActiveTargetIfMatches({ id: cleanId, key: cleanKey });
    const nowSec = Math.floor(Date.now() / 1000);
    if (Array.isArray(this.openTabsList) && this.openTabsList.length > 0) {
      // Closing any tab, not only the focused one, marks its session read.
      const closingTab = this.openTabsList.find(
        (t) => t && ((cleanId && t.id === cleanId) || (cleanKey && t.uri === cleanKey))
      );
      const seenId = closingTab?.id || (closingTab ? cleanId : '');
      if (seenId) {
        const closedThread = (this.snapshot?.threads || []).find((t) => t.id === seenId);
        this.stateStore
          .markSeen(
            seenId,
            Math.max(nowSec + 5, Number(closedThread?.updatedAt || 0) + 5),
            { clearUnread: true }
          )
          .catch(() => {});
        this.clearClaudeNativeUnread(closedThread);
      }
      const nextList = this.openTabsList.filter(
        (t) =>
          !(
            (cleanKey && t?.uri === cleanKey) ||
            (!cleanKey && cleanId && t?.id === cleanId)
          )
      );
      if (nextList.length !== this.openTabsList.length) {
        this.openTabsList = nextList;
        this.lastPosted = null;
        this.syncOpenTabBadges();
        this.render();
      }
    }
    this.refreshTabStateFast({ scheduleFullRefreshMs: 260 }).catch(() => {});
  }

  async refreshTabStateFast({
    optimisticActiveId = '',
    optimisticActiveKey = '',
    forceOptimistic = false,
    scheduleFullRefreshMs = 0
  } = {}) {
    this._lastFastTabSyncAt = Date.now();
    try {
      const prevTabs = Array.isArray(this.openTabsList) ? this.openTabsList : [];
      const openTabs = await this.tabs.getOpenTabs();
      if (Array.isArray(openTabs)) {
        const nowSec = Math.floor(Date.now() / 1000);
        for (const prev of prevTabs) {
          if (!prev) continue;
          const stillOpen = openTabs.some(
            (cur) =>
              cur &&
              ((prev.uri && cur.uri && cur.uri === prev.uri) ||
                (!prev.uri && prev.id && cur.id === prev.id))
          );
          if (!stillOpen) {
            this.clearPendingActiveTargetIfMatches({
              id: prev.id || '',
              key: prev.uri || ''
            });
            this.lastPosted = null;
            // Closing any tab, not only the focused one, marks its session read.
            if (prev.id) {
              const closedThread = (this.snapshot?.threads || []).find((t) => t.id === prev.id);
              await this.stateStore.markSeen(
                prev.id,
                Math.max(nowSec + 5, Number(closedThread?.updatedAt || 0) + 5),
                { clearUnread: true }
              );
              this.clearClaudeNativeUnread(closedThread);
            }
          }
        }
        const cleanId = String(optimisticActiveId || '').trim();
        const cleanKey = String(optimisticActiveKey || '').trim();
        const adjustedTabs = this.applyPendingActiveTargetToTabs(openTabs, {
          id: cleanId,
          key: cleanKey,
          force: Boolean(forceOptimistic)
        });
        this.openTabsList = adjustedTabs;
        for (const tab of adjustedTabs) {
          if (tab?.active && tab?.id) {
            const activeThread = (this.snapshot?.threads || []).find((t) => t.id === tab.id);
            await this.stateStore.markSeen(
              tab.id,
              Math.max(nowSec, Number(activeThread?.updatedAt) || 0),
              { clearUnread: true }
            );
          }
        }
      }
    } catch {}
    this.syncOpenTabBadges();
    this.render();
    if (scheduleFullRefreshMs > 0) {
      this.scheduleRefresh(scheduleFullRefreshMs);
    }
  }

  async touchActiveTabs() {
    try {
      const openTabs = await this.tabs.getOpenTabs();
      if (Array.isArray(openTabs)) {
        const adjustedTabs = this.applyPendingActiveTargetToTabs(openTabs);
        this.openTabsList = adjustedTabs;
        for (const tab of adjustedTabs) {
          if (tab?.active && tab?.id) {
            await this.markThreadSeen(tab.id);
          }
        }
      }
    } catch {}
  }

  syncOpenTabBadges(persisted = null) {
    if (!Array.isArray(this.openTabsList) || this.openTabsList.length === 0) {
      return;
    }
    const state = persisted || this.stateStore.read();
    const threadsById = new Map(
      (this.snapshot?.threads || []).map((thread) => [thread.id, thread])
    );
    const badgesById = {};

    for (const tab of this.openTabsList) {
      if (!tab?.id) {
        continue;
      }
      const isActive = Boolean(tab.active);
      let thread = threadsById.get(tab.id);
      if (!thread) {
        const liveEntry = this.activity?.liveByThreadId?.get?.(tab.id);
        if (!liveEntry) {
          badgesById[tab.id] = 'plain';
          continue;
        }
        thread = {
          id: tab.id,
          provider: tab.provider === 'claude' ? 'claude' : 'antigravity',
          title: tab.title || 'Untitled session',
          updatedAt: Number(liveEntry.updatedAt || Math.floor(Date.now() / 1000)),
          stepCount: Number(liveEntry.stepCount || 0),
          notFullyIdle: Boolean(liveEntry.notFullyIdle),
          status: liveEntry.notFullyIdle ? 'CASCADE_RUN_STATUS_RUNNING' : 'CASCADE_RUN_STATUS_IDLE'
        };
      }
      if (
        tab.provider !== 'claude' &&
        thread.title &&
        thread.title !== 'Antigravity' &&
        (!tab.title || tab.title === 'new' || tab.title === 'Antigravity')
      ) {
        tab.title = thread.title;
        this.tabs.syncTabTitle(tab.id, thread.title, 'antigravity').catch(() => {});
      }
      const classified = this.activity.classifyThread(thread, { recordTransition: false });
      const isUnread = this.stateStore.isThreadUnread(state, thread, classified.state, isActive);
      let badge = 'plain';
      if (classified.state === 'waiting') {
        badge = 'pending';
      } else if (!isActive && isUnread && classified.state !== 'thinking') {
        badge = 'done';
      }
      if (badgesById[tab.id] === undefined || isActive || badge === 'pending') {
        badgesById[tab.id] = isActive && badge === 'done' ? 'plain' : badge;
      }
    }

    this.tabs.syncTabBadges(badgesById).catch(() => {});
  }

  resolveWebviewView(view) {
    this.view = view;
    this.views.add(view);
    this.lastPosted = null;
    if (Array.isArray(view.__bhfListeners)) {
      for (const l of view.__bhfListeners) {
        try {
          l?.dispose?.();
        } catch {}
      }
      view.__bhfListeners = [];
    }
    try {
      view.title = 'THEO';
    } catch {}
    const webview = view.webview;
    webview.options = {
      enableScripts: true,
      localResourceRoots: [vscode.Uri.joinPath(this.context.extensionUri, 'resources')]
    };

    this.applyWebviewHtml(webview);

    const listeners = [
      webview.onDidReceiveMessage(async (message) => {
        try {
          await this.handleMessage(message, { trustedWebview: true });
        } catch (err) {
          vscode.window.showErrorMessage(`THEO: ${err?.message || err}`);
        }
      }),
      view.onDidChangeVisibility(() => {
        if (view.visible) {
          this.refresh({ forceQuota: false });
        }
      }),
      view.onDidDispose(() => {
        listeners.forEach((l) => l.dispose());
        view.__bhfListeners = [];
        this.views.delete(view);
        if (this.view === view) {
          this.view = this.views.values().next().value || null;
        }
      })
    ];
    view.__bhfListeners = listeners;

    this.render();
    this.refresh({ forceQuota: true });
  }

  // Identity of the three files the sidebar page is built from. A webview is rebuilt only when this
  // changes: resetting `webview.html` reloads the whole page (a visible blink that also drops the scroll
  // position), so a hot swap of host-side modules must not do it.
  getWebviewResourceSignature() {
    const parts = [];
    for (const file of ['hub.html', 'hub.css', 'hub.js']) {
      try {
        const st = fs.statSync(path.join(this.context.extensionPath, 'resources', file));
        parts.push(`${file}:${Math.floor(st.mtimeMs)}:${st.size}`);
      } catch {
        parts.push(`${file}:missing`);
      }
    }
    return parts.join('|');
  }

  applyWebviewHtml(webview) {
    if (!webview) return;
    if (!this._webviewResourceSigs) {
      this._webviewResourceSigs = new WeakMap();
    }
    const resourceSig = this.getWebviewResourceSignature();
    const nonce = randomBytes(18).toString('hex');
    const resUri = (file) => {
      let ver = '';
      try {
        ver = `?v=${Math.floor(fs.statSync(path.join(this.context.extensionPath, 'resources', file)).mtimeMs)}`;
      } catch {}
      return (
        webview
          .asWebviewUri(vscode.Uri.joinPath(this.context.extensionUri, 'resources', file))
          .toString() + ver
      );
    };
    webview.html = fs
      .readFileSync(path.join(this.context.extensionPath, 'resources', 'hub.html'), 'utf8')
      .replaceAll('{{cspSource}}', webview.cspSource)
      .replaceAll('{{nonce}}', nonce)
      .replaceAll('{{css}}', resUri('hub.css'))
      .replaceAll('{{js}}', resUri('hub.js'));
    this._webviewResourceSigs.set(webview, resourceSig);
  }

  // Called after every hot swap. Host-only changes (remote.js, store.js, a bridge…) just repost the state;
  // the page itself is rebuilt only when hub.html / hub.css / hub.js changed on disk.
  reloadAllWebviews() {
    this.lastPosted = null;
    const resourceSig = this.getWebviewResourceSignature();
    for (const v of this.views) {
      try {
        if (this._webviewResourceSigs?.get(v.webview) !== resourceSig) {
          this.applyWebviewHtml(v.webview);
        }
      } catch {}
    }
    this.render();
  }

  openDetailsModal(scrollToPcSetup = false) {
    vscode.commands.executeCommand('antigravity.panel.focus').catch(() => {});
    this.lastPosted = null;
    this.render();
    for (const v of this.views) {
      try {
        v.webview.postMessage({
          type: 'openDetails',
          scrollToPcSetup: Boolean(scrollToPcSetup)
        });
      } catch {}
    }
  }

  setBridgeInstallReport(report) {
    this.bridgeInstallReport = report || null;
    const agyActive = Boolean(this.bridgeStatus?.antigravityActive);
    const claudeActive = Boolean(this.bridgeStatus?.claudeActive);
    const claudeSignedIn =
      typeof this.accountVault?.hasSignedInProvider === 'function'
        ? this.accountVault.hasSignedInProvider('claude')
        : report?.claudeSignedIn !== false;
    const needsAgy = Boolean(
      report?.needsAgyReload && (report?.agyHostUpdated || !agyActive)
    );
    const needsClaude = Boolean(
      claudeSignedIn && report?.needsClaudeReload && (report?.claudeHostUpdated || !claudeActive)
    );
    const reload = Boolean(needsAgy || needsClaude);
    this.bridgeStatus = {
      ...this.bridgeStatus,
      reload,
      message: !reload
        ? ''
        : needsAgy && needsClaude
          ? 'Reload VS Code once to activate the Antigravity & Claude Code bridges.'
          : needsClaude
            ? 'Reload VS Code once to activate the Claude Code bridge.'
            : 'Reload VS Code once to activate the Antigravity bridge.'
    };
    this.requestRender();
  }

  requestRender() {
    if (this.renderTimer) {
      return;
    }
    const sinceLastRenderMs = Date.now() - Number(this._lastRenderAt || 0);
    const delayMs =
      sinceLastRenderMs >= 0 && sinceLastRenderMs < RENDER_BURST_MIN_INTERVAL_MS
        ? Math.max(45, RENDER_BURST_MIN_INTERVAL_MS - sinceLastRenderMs)
        : 45;
    this.renderTimer = setTimeout(() => {
      this.renderTimer = null;
      this.render();
    }, delayMs);
  }

  getAutoArchiveInactiveDays(persisted = null, claudeLive = null) {
    const validDays = [0, 1, 2, 7, 14];
    const state = persisted || this.stateStore.read();
    const prefDays = state?.preferences?.autoArchiveInactiveDays;
    if (typeof prefDays === 'number' && validDays.includes(prefDays)) {
      return prefDays;
    }
    try {
      const hubCfgDays = vscode.workspace
        .getConfiguration('antigravityHub')
        .get('autoArchiveInactiveDays');
      if (typeof hubCfgDays === 'number' && validDays.includes(hubCfgDays)) {
        return hubCfgDays;
      }
      const claudeCfgDays = vscode.workspace
        .getConfiguration('claudeCode')
        .get('archiveInactiveSessions');
      if (typeof claudeCfgDays === 'number' && validDays.includes(claudeCfgDays)) {
        return claudeCfgDays;
      }
    } catch {}
    if (
      typeof claudeLive?.autoArchiveDays === 'number' &&
      validDays.includes(claudeLive.autoArchiveDays)
    ) {
      return claudeLive.autoArchiveDays;
    }
    return 14;
  }

  async sweepAutoArchiveInactive(snap, explicitDays = null) {
    const allThreads = snap?.threads || [];
    if (allThreads.length === 0) {
      return 0;
    }
    const state = this.stateStore.read();
    const days =
      typeof explicitDays === 'number'
        ? explicitDays
        : this.getAutoArchiveInactiveDays(state, snap?.claudeLive);
    if (!days || days <= 0) {
      return 0;
    }

    const nowSec = Math.floor(Date.now() / 1000);
    const cutoffSec = nowSec - days * 86400;
    const archivedSet = new Set(state.archivedIds || []);
    const groupIds = new Set((state.groups || []).map((g) => g.id));
    const openTabIds = new Set(
      (this.openTabsList || []).map((t) => t?.id).filter(Boolean)
    );

    const toArchive = [];
    const claudeToArchive = [];

    for (const thread of allThreads) {
      if (!thread?.id || archivedSet.has(thread.id) || openTabIds.has(thread.id)) {
        continue;
      }
      const hasGroup =
        Boolean(state.threadGroups?.[thread.id]) &&
        groupIds.has(state.threadGroups[thread.id]);
      if (hasGroup) {
        continue;
      }
      const classified = this.activity.classifyThread(thread, { recordTransition: false });
      if (
        classified.state === 'thinking' ||
        classified.state === 'waiting' ||
        thread.elsewhere
      ) {
        continue;
      }
      // Every thread here has no open tab, and a session with no open tab carries no unread mark
      // (see render), so a stored or derived unread state no longer blocks auto-archive.
      const unarchivedAtSec = Number(state.unarchivedAt?.[thread.id] || 0);
      const unassignedAtSec = Number(state.unassignedGroupThreads?.[thread.id] || 0);
      const effectiveActivitySec = Math.max(
        Number(thread.updatedAt || 0),
        unarchivedAtSec,
        unassignedAtSec
      );
      if (effectiveActivitySec > 0 && effectiveActivitySec < cutoffSec) {
        toArchive.push(thread.id);
        if (thread.provider === 'claude') {
          claudeToArchive.push(thread.id);
        }
      }
    }

    if (toArchive.length > 0) {
      await this.stateStore.setArchivedMany(toArchive, true);
      if (claudeToArchive.length > 0) {
        vscode.commands
          .executeCommand('antigravityHub.claudeSetArchived', {
            ids: claudeToArchive,
            archived: true
          })
          .then(
            () => {},
            () => {}
          );
      }
    }
    return toArchive.length;
  }

  hotReloadUpdatedModules() {
    const now = Date.now();
    if (now - Number(this._lastHotReloadCheckAt || 0) < 5000) {
      return;
    }
    this._lastHotReloadCheckAt = now;
    if (!this._moduleMtimes) {
      this._moduleMtimes = new Map();
    }
    const relPaths = [
      './data.js',
      './compat/antigravity-context-window.cjs',
      './compat/antigravity-hub-bridge.cjs',
      './compat/claude-hub-bridge.cjs',
      './accounts.js',
      './activity.js',
      './state.js',
      './store.js'
    ];
    let changed = false;
    let dataChanged = false;
    for (const rel of relPaths) {
      try {
        const resolved = require.resolve(rel);
        const stat = fs.statSync(resolved);
        const mtime = Math.floor(stat.mtimeMs);
        const prev = this._moduleMtimes.get(resolved);
        this._moduleMtimes.set(resolved, mtime);
        if (prev !== undefined && prev !== mtime) {
          delete require.cache[resolved];
          changed = true;
          if (rel === './data.js') {
            dataChanged = true;
          }
        }
      } catch {}
    }
    if (dataChanged) {
      for (const depRel of ['./accounts.js', './store.js']) {
        try {
          delete require.cache[require.resolve(depRel)];
        } catch {}
      }
    }
    if (changed) {
      try {
        const freshAccounts = require('./accounts.js');
        if (this.accountVault && freshAccounts?.AccountVaultManager?.prototype) {
          Object.setPrototypeOf(this.accountVault, freshAccounts.AccountVaultManager.prototype);
          if (!this.accountVault.hasCustomHttpsJsonRequest && freshAccounts.defaultHttpsJsonRequest) {
            this.accountVault.httpsJsonRequest = freshAccounts.defaultHttpsJsonRequest;
          }
          this.accountVault.agyQuotaInFlightById?.clear?.();
          this.accountVault.claudeQuotaInFlightById?.clear?.();
        }
      } catch {}
      try {
        const freshActivity = require('./activity.js');
        if (this.activity && freshActivity?.SessionActivityTracker?.prototype) {
          Object.setPrototypeOf(this.activity, freshActivity.SessionActivityTracker.prototype);
        }
      } catch {}
      try {
        const freshState = require('./state.js');
        if (this.stateStore && freshState?.HubStateStore?.prototype) {
          Object.setPrototypeOf(this.stateStore, freshState.HubStateStore.prototype);
        }
      } catch {}
      try {
        const freshStore = require('./store.js');
        if (this.store && freshStore?.AntigravityDataStore?.prototype) {
          Object.setPrototypeOf(this.store, freshStore.AntigravityDataStore.prototype);
        }
      } catch {}
      try {
        const freshClaudeBridge = require('./compat/claude-hub-bridge.cjs');
        freshClaudeBridge?.hotUpgradeLiveState?.();
      } catch {}
      try {
        const freshBridge = require('./compat/antigravity-hub-bridge.cjs');
        freshBridge?.hotUpgradeLiveState?.(freshBridge.getBridgeState(), vscode, this);
      } catch {}
    }
  }

  withTimeout(promise, ms, fallbackVal = null) {
    let timer = null;
    return Promise.race([
      Promise.resolve(promise).catch(() => fallbackVal),
      new Promise((resolve) => {
        timer = setTimeout(() => resolve(fallbackVal), Math.max(250, Number(ms) || 5000));
        if (typeof timer?.unref === 'function') timer.unref();
      })
    ]).finally(() => {
      if (timer) clearTimeout(timer);
    });
  }

  async refresh(options = {}) {
    if (
      !options.force &&
      !options.forceQuota &&
      this.snapshot &&
      Date.now() < Number(this._tabSwitchCooldownUntil || 0) &&
      Date.now() - Number(this.activity?.lastConversationEventAt || 0) > 250
    ) {
      const remainingMs = Math.max(120, Number(this._tabSwitchCooldownUntil || 0) - Date.now() + 40);
      await this.refreshTabStateFast({ scheduleFullRefreshMs: remainingMs });
      return;
    }
    // `prompt` marks a queued refresh that some caller other than a streaming event asked for (a phone
    // action, a sidebar command): it is never held by the activity limit below.
    if (
      options.force &&
      !options.forceQuota &&
      !options.prompt &&
      this.snapshot &&
      !this.refreshInFlight
    ) {
      // Measured from the start of the last reload, so an event that arrives while a reload runs waits at
      // most this interval plus one reload.
      const sinceLastFullMs = Date.now() - Number(this._lastFullRefreshStartedAt || this._lastFullRefreshAt || 0);
      if (sinceLastFullMs >= 0 && sinceLastFullMs < ACTIVITY_REFRESH_MIN_INTERVAL_MS) {
        this.scheduleRefresh(ACTIVITY_REFRESH_MIN_INTERVAL_MS - sinceLastFullMs + 20);
        return;
      }
    }
    if (this._scheduledRefreshTimer) {
      clearTimeout(this._scheduledRefreshTimer);
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
      this._scheduledRefreshDueAt = 0;
    }
    if (this.refreshInFlight) {
      if (Date.now() - Number(this.refreshStartedAt || 0) > 15000) {
        this.refreshInFlight = null;
      } else {
        this.pendingRefresh = {
          force: Boolean(this.pendingRefresh?.force || options.force),
          forceQuota: Boolean(this.pendingRefresh?.forceQuota || options.forceQuota),
          prompt: Boolean(this.pendingRefresh?.prompt || options.prompt || !options.force)
        };
        // Tab changes reach the sidebar through onDidChangeTabs, so this sync is only a safety net: one
        // every ACTIVITY_FAST_TAB_SYNC_MIN_INTERVAL_MS, not one full render per streaming event.
        if (
          options.force &&
          this.snapshot &&
          Date.now() - Number(this._lastFastTabSyncAt || 0) > ACTIVITY_FAST_TAB_SYNC_MIN_INTERVAL_MS
        ) {
          this.refreshTabStateFast().catch(() => {});
        }
        return this.refreshInFlight;
      }
    }
    if (options.force && this.snapshot && Date.now() - Number(this._lastFastTabSyncAt || 0) > 25) {
      await this.refreshTabStateFast();
    }
    const runToken = {};
    this._refreshToken = runToken;
    this.refreshStartedAt = Date.now();
    this.refreshInFlight = (async () => {
      try {
        if (!this.baselineInitialized) {
          this.baselineInitialized = true;
          await this.withTimeout(this.stateStore.ensureBaseline(), 3000, null);
        }
        try {
          this.hotReloadUpdatedModules();
          const directAgyBridge = require('./compat/antigravity-hub-bridge.cjs');
          directAgyBridge?.tickLiveBridgeHealth?.(this);
        } catch {}
        const persisted = this.stateStore.read();
        const [snap, openTabs, agyBridgeLive, claudeBridgeLive] = await Promise.all([
          this.withTimeout(
            this.store.loadSnapshot({
              customTitles: persisted.customTitles,
              archivedIds: persisted.archivedIds,
              unarchivedAt: persisted.unarchivedAt,
              threadGroups: persisted.threadGroups,
              forceRefreshQuota: Boolean(options.forceQuota)
            }),
            10000,
            this.snapshot
          ),
          this.withTimeout(this.tabs.getOpenTabs(), 3500, this.openTabsList || []),
          this.withTimeout(
            vscode.commands.executeCommand('antigravityHub.bridgeStatus').then(
              (res) => res || { active: false },
              () => ({ active: false })
            ),
            2500,
            { active: Boolean(this.bridgeStatus?.antigravityActive) }
          ),
          this.withTimeout(
            vscode.commands.executeCommand('antigravityHub.claudeBridgeStatus').then(
              (res) => res || { active: false },
              () => ({ active: false })
            ),
            2500,
            { active: Boolean(this.bridgeStatus?.claudeActive) }
          )
        ]);

        if (snap) {
          this.snapshot = snap;
          this.activity?.reconcileSnapshot?.(snap?.threads || [], snap?.loadedAt || Date.now());
        }
        this.openTabsList = this.applyPendingActiveTargetToTabs(
          Array.isArray(openTabs) ? openTabs : []
        );

        if (this.accountVault) {
          try {
            this.accountVault.syncActiveClaudeFromDisk(
              snap?.claudeConfigObj,
              snap?.claudeCredsObj,
              snap?.rawClaudeQuota,
              snap?.loadedAt
            );
            const curPrefs = this.stateStore.read()?.preferences || {};
            const resolvedAccounts = await this.withTimeout(
              this.accountVault.resolveAccountsSnapshot({
                nowMs: Date.now(),
                forceQuota: Boolean(options.forceQuota),
                antigravityAccount: snap?.account,
                antigravityLimits: snap?.rateLimits,
                rawAntigravityQuota: snap?.rawAntigravityQuota,
                claudeAccount: snap?.claudeAccount,
                claudeLimits: snap?.claudeRateLimits,
                rawClaudeQuota: snap?.rawClaudeQuota,
                claudeRelayMerged: snap?.claudeLive?.rateLimitWindows,
                collapsedProviders: {
                  antigravity: Boolean(curPrefs.antigravityUsageCollapsed),
                  claude: Boolean(curPrefs.claudeUsageCollapsed),
                  ...(curPrefs.collapsedAccounts || {})
                }
              }),
              8500,
              null
            );
            if (resolvedAccounts) {
              this.accountsView = resolvedAccounts;
            }
          } catch {}
        }
        const agyActive = Boolean(agyBridgeLive?.active);
        const claudeActive = Boolean(claudeBridgeLive?.active);
        const anyActive = agyActive || claudeActive;
        const hideDuplicateIcon =
          typeof claudeBridgeLive?.hideDuplicateIcon === 'boolean'
            ? claudeBridgeLive.hideDuplicateIcon
            : Boolean(
                vscode.workspace
                  .getConfiguration('antigravityHub')
                  .get('hideDuplicateActivityBarIcon', true)
              );

        const report = this.bridgeInstallReport;
        const claudeSignedIn =
          typeof this.accountVault?.hasSignedInProvider === 'function'
            ? this.accountVault.hasSignedInProvider('claude')
            : report?.claudeSignedIn !== false;
        const needsAgy = Boolean(
          report?.needsAgyReload && (report?.agyHostUpdated || !agyActive)
        );
        const needsClaude = Boolean(
          claudeSignedIn &&
            report?.needsClaudeReload &&
            (report?.claudeHostUpdated || !claudeActive)
        );
        const showReloadBanner = Boolean(needsAgy || needsClaude);

        this.bridgeStatus = {
          active: anyActive,
          antigravityActive: agyActive,
          claudeActive,
          hideDuplicateIcon,
          reload: showReloadBanner,
          message: !showReloadBanner
            ? ''
            : needsAgy && needsClaude
              ? 'Reload VS Code once to activate the Antigravity & Claude Code bridges.'
              : needsClaude
                ? 'Reload VS Code once to activate the Claude Code bridge.'
                : 'Reload VS Code once to activate the Antigravity bridge.'
        };
        this.loading = false;

        // Sync Claude Code native archived sessions & groups
        if (snap?.claudeLive) {
          await this.stateStore.syncClaudeNativeState(snap.claudeLive);
        }

        // Adopt draft group assignments once a draft tab binds to a conversation ID
        for (const tab of this.openTabsList) {
          if (tab.id && tab.uri && this.draftGroups.has(tab.uri)) {
            const gid = this.draftGroups.get(tab.uri);
            this.draftGroups.delete(tab.uri);
            await this.stateStore.assignThreadGroup(tab.id, gid);
          }
        }

        // Check active tab & transitions
        const activeTabs = this.openTabsList.filter((t) => t.active && t.id);
        const activeTabIds = new Set(activeTabs.map((t) => t.id));
        const openTabIds = new Set(this.openTabsList.map((t) => t?.id).filter(Boolean));
        const nowSec = Math.floor(Date.now() / 1000);
        for (const activeTab of activeTabs) {
          const activeThread = (snap.threads || []).find((t) => t.id === activeTab.id);
          await this.stateStore.markSeen(
            activeTab.id,
            Math.max(nowSec, Number(activeThread?.updatedAt) || 0),
            { clearUnread: true }
          );
        }

        const latestState = this.stateStore.read();
        for (const thread of snap.threads || []) {
          const classified = this.activity.classifyThread(thread);
          const isOpenActive = activeTabIds.has(thread.id);
          if (classified.transitionedFromWorking) {
            if (isOpenActive && vscode.window.state.focused) {
              await this.stateStore.markSeen(
                thread.id,
                Math.max(nowSec, Number(thread.updatedAt) || 0),
                { clearUnread: true }
              );
            } else if (openTabIds.has(thread.id)) {
              // A session that finishes with no open tab here gets no unread mark (see render).
              await this.stateStore.setUnread(thread.id, true);
            }
            notifySessionTransition({
              thread,
              state: classified.state,
              preferences: latestState.preferences,
              isActiveTab: isOpenActive,
              onOpenThread: (id) =>
                this.tabs.openThread(id, {
                  provider: thread.provider || 'antigravity',
                  title: thread.title
                })
            }).catch(() => {});
          }
        }

        // Auto-archive inactive sessions (skips open, working, waiting, unread, and grouped sessions)
        if (snap) {
          await this.withTimeout(this.sweepAutoArchiveInactive(snap), 3000, 0);
        }
      } finally {
        if (this._refreshToken === runToken) {
          this.refreshInFlight = null;
        }
        this._lastFullRefreshAt = Date.now();
        this._lastFullRefreshStartedAt = Number(this.refreshStartedAt) || this._lastFullRefreshAt;
        this.syncOpenTabBadges();
        this.render();
        if (!this.refreshInFlight && this.pendingRefresh) {
          const nextOpts = this.pendingRefresh;
          this.pendingRefresh = null;
          this.refresh(nextOpts);
        }
      }
    })();
    return this.refreshInFlight;
  }

  buildSummaryForWindows(windowsObj) {
    const win5h = windowsObj?.['5h'] || {};
    const win7d = windowsObj?.['7d'] || {};
    const days = Array.isArray(win7d.daily)
      ? win7d.daily.map((d) => ({
          key: d.date,
          label: d.label,
          tokens: Number(d.totalTokens || 0),
          turns: Number(d.turns || 0)
        }))
      : [];

    const todayBar = days[days.length - 1] || { tokens: 0, turns: 0 };
    return {
      today: {
        sessions: Number(win5h.sessions || 0),
        turns: Math.max(Number(win5h.turns || 0), Number(todayBar.turns || 0)),
        tokens: Math.max(Number(win5h.totalTokens || 0), Number(todayBar.tokens || 0)),
        input: Number(win5h.inputTokens || 0),
        cached: Number(win5h.cachedInputTokens || 0),
        output: Number(win5h.outputTokens || 0)
      },
      week: {
        sessions: Number(win7d.sessions || 0),
        turns: Number(win7d.turns || 0),
        tokens: Number(win7d.totalTokens || 0),
        input: Number(win7d.inputTokens || 0),
        cached: Number(win7d.cachedInputTokens || 0),
        output: Number(win7d.outputTokens || 0)
      },
      days: days.length
        ? days
        : [{ key: 'Today', label: 'Today', tokens: 0, turns: 0 }]
    };
  }

  buildSummary(usage) {
    return this.buildSummaryForWindows(usage?.windows || {});
  }

  render() {
    if (this.views.size === 0 && !this.view && !this.remote) {
      return;
    }
    this._lastRenderAt = Date.now();

    const persisted = this.stateStore.read();
    const prefs = persisted.preferences || {};
    const scope = prefs.scope === 'workspace' ? 'workspace' : 'all';
    const providerFilter = ['all', 'antigravity', 'claude'].includes(prefs.providerFilter)
      ? prefs.providerFilter
      : 'all';
    const collapsed = {
      usage: Boolean(prefs.accountSectionCollapsed),
      antigravityUsage: Boolean(prefs.antigravityUsageCollapsed),
      claudeUsage: Boolean(prefs.claudeUsageCollapsed),
      accounts: prefs.collapsedAccounts && typeof prefs.collapsedAccounts === 'object'
        ? { ...prefs.collapsedAccounts }
        : {},
      questions: Boolean(prefs.questionsSectionCollapsed),
      bgTasks: Boolean(prefs.bgTasksSectionCollapsed),
      sessions: Boolean(prefs.sessionSectionCollapsed),
      ungrouped: Boolean(prefs.ungroupedCollapsed),
      archived: prefs.archivedCollapsed !== undefined ? Boolean(prefs.archivedCollapsed) : true
    };
    const rawFilterStatuses = Array.isArray(prefs.filterStatuses) ? prefs.filterStatuses : [];
    const normalizedFilterStatuses =
      rawFilterStatuses.length >= 3 ||
      (rawFilterStatuses.length === 2 &&
        rawFilterStatuses.includes('completed') &&
        rawFilterStatuses.includes('working') &&
        !rawFilterStatuses.includes('needs_input'))
        ? []
        : rawFilterStatuses;
    if (normalizedFilterStatuses.length !== rawFilterStatuses.length) {
      this.stateStore.updatePreferences({ filterStatuses: normalizedFilterStatuses }).catch(() => {});
    }
    const filter = {
      statuses: normalizedFilterStatuses,
      tabStates: Array.isArray(prefs.filterTabStates) ? prefs.filterTabStates : [],
      activeOnly: Boolean(prefs.filterActiveOnly)
    };

    const snap = this.snapshot;
    const allThreads = snap?.threads || [];
    const workspaceRoots = (vscode.workspace.workspaceFolders || []).map((f) => f.uri.fsPath);

    const inScope = (thread) => {
      if (scope !== 'workspace' || workspaceRoots.length === 0) {
        return true;
      }
      if (!thread.cwd) {
        return false;
      }
      return workspaceRoots.some((root) => isSameOrChildPath(thread.cwd, root));
    };

    const openById = new Map();
    for (const tab of this.openTabsList) {
      if (tab.id && (!openById.has(tab.id) || tab.active)) {
        openById.set(tab.id, tab);
      }
    }

    const archivedSet = new Set(persisted.archivedIds || []);
    const groupIds = new Set((persisted.groups || []).map((g) => g.id));

    const scopedThreads = allThreads.filter(
      (t) => inScope(t) || openById.has(t.id) || (t.groupId && groupIds.has(t.groupId))
    );

    const rows = [];
    const seenIds = new Set();

    for (const thread of scopedThreads) {
      seenIds.add(thread.id);
      const tab = openById.get(thread.id);
      const classified = this.activity.classifyThread(thread, { recordTransition: false });
      const isOpen = Boolean(tab);
      const isActive = Boolean(tab?.active);
      // A session with no open tab on this host shows no unread mark, in the sidebar or on the phone
      // (user, 2026-11-12). A stored flag is kept for when the tab is reopened; auto-archive ignores it.
      const isUnread =
        isOpen &&
        this.stateStore.isThreadUnread(persisted, thread, classified.state, isActive);

      let status = 'idle';
      if (classified.state === 'waiting') {
        status = 'waiting';
      } else if (classified.state === 'thinking') {
        status = 'working';
      } else if (classified.state === 'errored') {
        status = 'failed';
      } else if (classified.state === 'completed') {
        status = 'completed';
      }

      const dot =
        status === 'waiting'
          ? 'waiting'
          : status === 'working'
            ? 'running'
            : thread.bgTask?.state === 'interrupted'
              ? 'failed'
              : isUnread
                ? status === 'failed'
                  ? 'failed'
                  : 'unread'
                : isOpen
                  ? 'idle'
                  : null;

      const category =
        status === 'waiting'
          ? 'needs_input'
          : status === 'working'
            ? 'working'
            : 'completed';

      const provider = thread.provider === 'claude' ? 'claude' : 'antigravity';
      const rawBgTasks = Array.isArray(thread.backgroundTasks) ? thread.backgroundTasks : [];
      const bgRunningCount = rawBgTasks.filter((t) => t && t.state === 'running').length;
      const bgTotalCount = rawBgTasks.length;
      const compactBgTasks = rawBgTasks.slice(-12).map((t) => ({
        id: t.id,
        fullId: t.fullId || t.id,
        subagentConversationId: t.subagentConversationId || '',
        kind: t.kind || 'task',
        subagentType: t.subagentType || '',
        summary: t.summary || '',
        command: String(t.command || '').slice(0, 320),
        state: t.state || 'completed',
        isDaemon: Boolean(t.isDaemon),
        startedAt: Number(t.startedAt || 0) * 1000,
        completedAt: t.completedAt ? Number(t.completedAt) * 1000 : 0,
        stepIndex: typeof t.stepIndex === 'number' ? t.stepIndex : -1
      }));

      rows.push({
        key: thread.id,
        id: thread.id,
        uri: tab?.uri || null,
        provider,
        draft: false,
        title: persisted.customTitles[thread.id] || thread.title || 'Untitled session',
        at: Number(thread.updatedAt || 0) * 1000,
        open: isOpen,
        active: isActive,
        group:
          persisted.threadGroups[thread.id] && groupIds.has(persisted.threadGroups[thread.id])
            ? persisted.threadGroups[thread.id]
            : null,
        archived: archivedSet.has(thread.id),
        cwd: thread.cwd || '',
        folder: thread.workspaceLabel || '',
        branch: thread.branch || '',
        deviceId: thread.deviceId || '',
        deviceName: thread.deviceName || '',
        source: thread.source || '',
        remotePeer: Boolean(thread.remotePeer || thread.source === 'cloud-relay'),
        model: thread.model || (provider === 'claude' ? 'Claude' : 'Gemini'),
        logged: true,
        status,
        dot,
        category,
        unread: isUnread,
        elsewhere: Boolean((status === 'working' || thread.elsewhere) && !isOpen),
        reason: classified.reason || null,
        stepCount: Number(thread.stepCount || 0),
        turnComplete: thread.turnComplete !== false,
        lastAssistantText: thread.lastAssistantText || '',
        pendingQuestion: thread.pendingQuestion || null,
        bgTasks: compactBgTasks,
        bgRunningCount,
        bgTotalCount
      });
    }

    if (!(this.draftCreatedAt instanceof Map)) {
      this.draftCreatedAt = new Map();
    }
    const openDraftUris = new Set();

    for (const tab of this.openTabsList) {
      const provider = tab.provider === 'claude' ? 'claude' : 'antigravity';
      const defaultModel = provider === 'claude' ? 'Claude' : 'Gemini';
      if (tab.id && !seenIds.has(tab.id)) {
        seenIds.add(tab.id);
        const liveEntry = this.activity?.liveByThreadId?.get?.(tab.id);
        const syntheticThread = {
          id: tab.id,
          provider,
          title: persisted.customTitles[tab.id] || tab.title || 'Untitled session',
          updatedAt: Number(liveEntry?.updatedAt || Math.floor(Date.now() / 1000)),
          stepCount: Number(liveEntry?.stepCount || 0),
          notFullyIdle: Boolean(liveEntry?.notFullyIdle),
          status: liveEntry?.notFullyIdle ? 'CASCADE_RUN_STATUS_RUNNING' : 'CASCADE_RUN_STATUS_IDLE'
        };
        const classified = this.activity.classifyThread(syntheticThread, { recordTransition: false });
        let fallbackStatus = 'idle';
        if (classified.state === 'waiting') {
          fallbackStatus = 'waiting';
        } else if (classified.state === 'thinking') {
          fallbackStatus = 'working';
        } else if (classified.state === 'errored') {
          fallbackStatus = 'failed';
        } else if (classified.state === 'completed') {
          fallbackStatus = 'completed';
        }
        const fallbackDot =
          fallbackStatus === 'waiting'
            ? 'waiting'
            : fallbackStatus === 'working'
              ? 'running'
              : 'idle';
        const fallbackCategory =
          fallbackStatus === 'waiting'
            ? 'needs_input'
            : fallbackStatus === 'working'
              ? 'working'
              : 'completed';
        rows.push({
          key: tab.id,
          id: tab.id,
          uri: tab.uri || null,
          provider,
          draft: false,
          title: syntheticThread.title,
          at: Number(syntheticThread.updatedAt) * 1000,
          open: true,
          active: Boolean(tab.active),
          group: persisted.threadGroups[tab.id] || null,
          archived: false,
          cwd: '',
          folder: '',
          branch: '',
          model: defaultModel,
          logged: true,
          status: fallbackStatus,
          dot: fallbackDot,
          category: fallbackCategory,
          unread: false,
          elsewhere: false,
          reason: classified.reason || null,
          stepCount: syntheticThread.stepCount
        });
      } else if (!tab.id) {
        const defaultDraftTitle =
          provider === 'claude' ? 'New Claude session' : 'New Antigravity session';
        const draftKey = tab.uri || `draft:${provider}`;
        openDraftUris.add(draftKey);
        if (!this.draftCreatedAt.has(draftKey)) {
          const initialDraftAt = Number(tab.createdAt || 0);
          this.draftCreatedAt.set(
            draftKey,
            Number.isFinite(initialDraftAt) && initialDraftAt > 0 ? initialDraftAt : Date.now()
          );
        }
        const draftAt = this.draftCreatedAt.get(draftKey) || Date.now();
        rows.push({
          key: tab.uri,
          id: null,
          uri: tab.uri || null,
          provider,
          draft: true,
          title:
            !tab.title || tab.title === 'Antigravity' || tab.title === 'Claude Code'
              ? defaultDraftTitle
              : tab.title,
          at: draftAt,
          open: true,
          active: Boolean(tab.active),
          group: this.draftGroups.get(tab.uri) || null,
          archived: false,
          cwd: '',
          folder: '',
          branch: '',
          model: defaultModel,
          logged: false,
          status: 'idle',
          dot: 'idle',
          category: 'completed',
          unread: false,
          elsewhere: false,
          reason: null
        });
      }
    }

    if (this.draftCreatedAt.size > openDraftUris.size) {
      for (const k of Array.from(this.draftCreatedAt.keys())) {
        if (!openDraftUris.has(k)) {
          this.draftCreatedAt.delete(k);
        }
      }
    }

    rows.sort((a, b) => b.open - a.open || Boolean(b.draft) - Boolean(a.draft) || b.at - a.at);

    this.syncOpenTabBadges(persisted);

    const formatBucket = (b) => ({
      label: b.label,
      pct: b.usedPercent,
      reset: b.resetAt ? b.resetAt * 1000 : 0,
      resetText: b.resetText || '',
      expired: Boolean(b.expired ?? b.windowExpired)
    });

    const agyPrimaryLimits = (snap?.rateLimits?.primaryBars || []).map(formatBucket);
    const agyAllLimits = (snap?.rateLimits?.allBuckets || []).map(formatBucket);

    const claudePrimaryLimits = (snap?.claudeRateLimits?.primaryBars || []).map(formatBucket);
    const claudeAllLimits = (snap?.claudeRateLimits?.allBuckets || []).map(formatBucket);

    const agyFallbackMsg = snap?.serverConnected
      ? 'Loading quota windows…'
      : 'Waiting for Antigravity language server…';
    const claudeFallbackMsg = snap?.claudeAccount?.available
      ? 'Loading Claude quota windows…'
      : 'Sign in to Claude Code to view quota.';

    const buildAccountCardModel = (item, fallbackMsg) => {
      const provKey = item.provider === 'claude' ? 'claude' : 'antigravity';
      const pLimits = (item.rateLimits?.primaryBars || []).map(formatBucket);
      const aLimits = (item.rateLimits?.allBuckets || []).map(formatBucket);
      const prefMap =
        prefs.collapsedAccounts && typeof prefs.collapsedAccounts === 'object'
          ? prefs.collapsedAccounts
          : {};
      const isCardCollapsed =
        typeof prefMap[item.id] === 'boolean'
          ? Boolean(prefMap[item.id])
          : Boolean(item.collapsed);
      const isSignedOutItem = !item.available || Boolean(item.signedOut || item.account?.signedOut);
      return {
        id: item.id,
        provider: provKey,
        label: provKey === 'claude' ? 'Claude Code' : 'Antigravity',
        nickname: item.label || '',
        active: !isSignedOutItem && Boolean(item.active),
        hubLive: Boolean(item.hubLive),
        hubPendingCutover: Boolean(item.hubPendingCutover),
        collapsed: isCardCollapsed,
        addedAt: Number(item.addedAt || 0),
        sortOrder: Number.isFinite(Number(item.sortOrder)) ? Number(item.sortOrder) : 0,
        lastActiveAt: Number(item.lastActiveAt || 0),
        quotaUpdatedAt: Number(item.quotaUpdatedAt || snap?.loadedAt || 0),
        account: {
          name:
            item.name ||
            item.account?.name ||
            (provKey === 'claude' ? 'Claude Account' : 'Antigravity Account'),
          email: isSignedOutItem ? '' : item.email || item.account?.email || '',
          plan: isSignedOutItem
            ? ''
            : item.plan ||
              item.account?.plan ||
              (provKey === 'claude' ? 'Claude Code' : 'Google AI Pro'),
          nickname: item.label || '',
          available: !isSignedOutItem && Boolean(item.available),
          signedOut: isSignedOutItem
        },
        usage: !isSignedOutItem && pLimits.length
          ? {
              at: item.quotaUpdatedAt || snap?.loadedAt || Date.now(),
              limits: pLimits,
              allLimits: aLimits
            }
          : null,
        usageMessage: isSignedOutItem
          ? 'Not signed in.'
          : item.rateLimits?.error || fallbackMsg
      };
    };

    const agyAccountsModels = Array.isArray(this.accountsView?.antigravity) && this.accountsView.antigravity.length
      ? this.accountsView.antigravity.map((item) => buildAccountCardModel(item, agyFallbackMsg))
      : null;

    const claudeAccountsModels = Array.isArray(this.accountsView?.claude) && this.accountsView.claude.length
      ? this.accountsView.claude.map((item) => buildAccountCardModel(item, claudeFallbackMsg))
      : null;

    const agyActiveCard = agyAccountsModels?.find((a) => a.active) || agyAccountsModels?.[0] || null;
    const claudeActiveCard = claudeAccountsModels?.find((a) => a.active) || claudeAccountsModels?.[0] || null;

    const agyProviderInfo = {
      id: 'antigravity',
      label: 'Antigravity',
      account: agyActiveCard?.account || {
        name: snap?.account?.name || 'Antigravity Account',
        email: snap?.account?.email || '',
        plan: snap?.account?.plan || 'Google AI Pro',
        available: Boolean(snap?.account?.email || snap?.account?.name),
        signedOut: false
      },
      usage: agyActiveCard
        ? agyActiveCard.usage
        : agyPrimaryLimits.length
          ? {
              at: snap?.loadedAt || Date.now(),
              limits: agyPrimaryLimits,
              allLimits: agyAllLimits
            }
          : null,
      usageMessage: agyActiveCard?.usageMessage || agyFallbackMsg,
      accounts: agyAccountsModels || [
        {
          id: snap?.account?.email
            ? `antigravity:${String(snap.account.email).trim().toLowerCase()}`
            : 'antigravity:default',
          provider: 'antigravity',
          label: 'Antigravity',
          nickname: '',
          active: true,
          collapsed: Boolean(prefs.antigravityUsageCollapsed),
          account: {
            name: snap?.account?.name || 'Antigravity Account',
            email: snap?.account?.email || '',
            plan: snap?.account?.plan || 'Google AI Pro',
            nickname: '',
            available: Boolean(snap?.account?.email || snap?.account?.name),
            signedOut: false
          },
          usage: agyPrimaryLimits.length
            ? {
                at: snap?.loadedAt || Date.now(),
                limits: agyPrimaryLimits,
                allLimits: agyAllLimits
              }
            : null,
          usageMessage: agyFallbackMsg
        }
      ]
    };

    const claudeProviderInfo = {
      id: 'claude',
      label: 'Claude Code',
      account: claudeActiveCard?.account || {
        name: snap?.claudeAccount?.name || 'Claude Account',
        email: snap?.claudeAccount?.email || '',
        plan: snap?.claudeAccount?.plan || 'Claude Code',
        available: Boolean(snap?.claudeAccount?.available),
        signedOut: Boolean(snap?.claudeAccount?.signedOut)
      },
      usage: claudeActiveCard
        ? claudeActiveCard.usage
        : claudePrimaryLimits.length
          ? {
              at: snap?.loadedAt || Date.now(),
              limits: claudePrimaryLimits,
              allLimits: claudeAllLimits
            }
          : null,
      usageMessage: claudeActiveCard?.usageMessage || claudeFallbackMsg,
      accounts: claudeAccountsModels || [
        {
          id: snap?.claudeAccount?.email
            ? `claude:${String(snap.claudeAccount.email).trim().toLowerCase()}`
            : 'claude:default',
          provider: 'claude',
          label: 'Claude Code',
          nickname: '',
          active: true,
          collapsed: Boolean(prefs.claudeUsageCollapsed),
          account: {
            name: snap?.claudeAccount?.name || 'Claude Account',
            email: snap?.claudeAccount?.email || '',
            plan: snap?.claudeAccount?.plan || 'Claude Code',
            nickname: '',
            available: Boolean(snap?.claudeAccount?.available),
            signedOut: Boolean(snap?.claudeAccount?.signedOut)
          },
          usage: claudePrimaryLimits.length
            ? {
                at: snap?.loadedAt || Date.now(),
                limits: claudePrimaryLimits,
                allLimits: claudeAllLimits
              }
            : null,
          usageMessage: claudeFallbackMsg
        }
      ]
    };

    const byProviderUsage = snap?.usage?.byProvider || {};
    const summaryByProvider = {
      all: this.buildSummary(snap?.usage),
      antigravity: this.buildSummaryForWindows(byProviderUsage.antigravity || {}),
      claude: this.buildSummaryForWindows(byProviderUsage.claude || {})
    };

    const autoArchiveDays = this.getAutoArchiveInactiveDays(persisted, snap?.claudeLive);
    let hasAgyRows = false;
    let hasClaudeRows = false;
    for (const r of rows) {
      if (r.archived) continue;
      if (r.provider === 'claude') hasClaudeRows = true;
      else hasAgyRows = true;
    }
    const effectiveProviderFilter =
      (providerFilter === 'claude' && !hasClaudeRows) ||
      (providerFilter === 'antigravity' && !hasAgyRows)
        ? 'all'
        : providerFilter;
    if (effectiveProviderFilter !== providerFilter) {
      this.stateStore.updatePreferences({ providerFilter: effectiveProviderFilter }).catch(() => {});
    }

    const curPending = this.getPendingActiveTarget();
    const pendingActiveKey =
      curPending && !curPending.confirmedInTabs
        ? curPending.id || curPending.key || null
        : null;

    const payload = {
      type: 'state',
      loading: this.loading,
      scope,
      providerFilter: effectiveProviderFilter,
      autoArchiveDays,
      pendingActiveKey,
      workspace:
        vscode.workspace.name && vscode.workspace.name.toLowerCase() === 'claude'
          ? 'THEO'
          : vscode.workspace.name || 'All folders',
      account: agyProviderInfo.account,
      usage: agyProviderInfo.usage,
      usageMessage: agyProviderInfo.usageMessage,
      providers: {
        antigravity: agyProviderInfo,
        claude: claudeProviderInfo
      },
      accountOrder: Array.isArray(this.accountsView?.accountOrder)
        ? this.accountsView.accountOrder
        : [],
      pendingAccountLogin: this.accountVault?.getPendingLoginState?.() || null,
      bridge: this.bridgeStatus,
      pcSetup: typeof this.getPcSetupView === 'function' ? this.getPcSetupView() : null,
      claudePermissionMode:
        this.remote && typeof this.remote.getClaudePermissionModeSnapshot === 'function'
          ? this.remote.getClaudePermissionModeSnapshot()
          : resolveSharedClaudePermissionModeInfo(),
      remote: this.remote ? this.remote.getStatus() : null,
      collapsed,
      filter,
      groups: (persisted.groups || []).map((g) => ({
        id: g.id,
        name: g.name,
        collapsed: Boolean(g.collapsed)
      })),
      rows,
      total: scopedThreads.length,
      errors: 0,
      summary: summaryByProvider.all,
      summaryByProvider,
      editGroup: this.editGroup || null
    };

    // `lastPosted = null` (set by every caller that needs a repost) always posts. Otherwise an unchanged
    // payload is skipped, and one whose only difference is a clock stamp waits for
    // HEARTBEAT_POST_MIN_INTERVAL_MS, so an idle sidebar is not sent the whole session list, and the remote
    // bridge is not woken, on every poll. The full JSON is built only for a payload that is posted.
    const stable = buildStablePostSignature(payload);
    if (this.lastPosted && stable.sig === this._lastPostedStableSig) {
      if (stable.stamps === this._lastPostedStamps) {
        return;
      }
      const sinceLastPostMs = Date.now() - Number(this._lastPostedAt || 0);
      if (sinceLastPostMs >= 0 && sinceLastPostMs < HEARTBEAT_POST_MIN_INTERVAL_MS) {
        return;
      }
    }
    this.lastPosted = JSON.stringify(payload);
    this._lastPostedStableSig = stable.sig;
    this._lastPostedStamps = stable.stamps;
    this._lastPostedAt = Date.now();
    this.editGroup = null;
    for (const v of this.views) {
      try {
        v.webview.postMessage(payload);
      } catch {}
    }
    if (this.remote) {
      this.remote.notifyStateUpdated?.();
    }
  }

  async handleMessage(m, meta = {}) {
    if (!m || typeof m.action !== 'string') {
      return;
    }

    // Any client action that mutates optimistic UI state or opens/focuses/closes tabs must bypass
    // lastPosted suppression on subsequent renders so authoritative server reconciliation always lands.
    if (
      [
        'open',
        'focus',
        'new',
        'newInGroup',
        'accountNewSession',
        'beside',
        'closeTab',
        'interrupt',
        'stop',
        'cancel',
        'rename',
        'archive',
        'unread',
        'groupCreate',
        'groupRename',
        'groupDelete',
        'groupToggle',
        'groupAdd',
        'groupRemove',
        'filter',
        'providerFilter',
        'scope',
        'collapse',
        'accountCollapse',
        'autoArchiveDays',
        'archiveInactiveNow',
        'checkPcSetup',
        'applyPcSetup',
        'openPcSetupDetails',
        'setClaudePermissionMode'
      ].includes(m.action)
    ) {
      this.lastPosted = null;
    }

    switch (m.action) {
      case 'ready':
        this.lastPosted = null;
        this.render();
        return;

      case 'openRemote':
        await vscode.commands.executeCommand('antigravityHub.openRemote');
        return;

      case 'new': {
        this._tabSwitchCooldownUntil = Date.now() + 550;
        const beside = Boolean(m.beside);
        const reqSeq = beside ? 0 : (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
        const newProvider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!beside) {
          this._pendingActiveTarget = null;
        }
        const openedNew = await this.tabs.openNewSession({
          provider: newProvider,
          beside
        });
        if (!beside && this._openReqSeq !== reqSeq) {
          return;
        }
        if (!beside && openedNew?.uri) {
          this.setPendingActiveTarget({
            key: openedNew.uri,
            provider: newProvider
          });
        }
        await this.refreshTabStateFast({
          optimisticActiveKey: beside ? '' : openedNew?.uri || '',
          forceOptimistic: !beside && Boolean(openedNew?.uri),
          scheduleFullRefreshMs: 320
        });
        return;
      }

      case 'refresh':
      case 'details':
        await this.refresh({ forceQuota: true });
        return;

      case 'checkPcSetup':
        if (typeof this.checkPcSetup === 'function') {
          await this.checkPcSetup({ force: true });
        }
        this.render();
        return;

      case 'openPcSetupDetails':
        this.openDetailsModal(true);
        return;

      case 'applyPcSetup':
        if (meta && meta.trustedWebview === true && typeof this.applyPcSetup === 'function') {
          await this.applyPcSetup({ only: typeof m.only === 'string' ? m.only : '' });
        }
        return;

      case 'setClaudePermissionMode': {
        if (!meta || meta.trustedWebview !== true) {
          return;
        }
        const nextMode = normalizeExplicitClaudeMode(m.mode || m.defaultMode || m.value);
        if (!nextMode) {
          return;
        }
        let res = null;
        if (this.remote && typeof this.remote.setFleetClaudePermissionMode === 'function') {
          res = await this.remote.setFleetClaudePermissionMode(nextMode, {
            source: 'theo-hub',
            updatedBy: 'THEO Sidebar'
          });
        } else {
          res = writeSharedClaudePermissionMode(nextMode, {
            source: 'theo-hub',
            updatedBy: 'THEO Sidebar',
            dirtyToStore: true
          });
          vscode.commands
            .executeCommand('antigravityHub.claudeSyncPermissionMode', {
              force: true,
              resetSessionOverrides: true
            })
            .catch(() => {});
        }
        if (res && res.ok === false && res.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        } else {
          const appliedMode = normalizeExplicitClaudeMode(res?.defaultMode) || nextMode;
          const friendly =
            appliedMode === 'bypassPermissions'
              ? 'Bypass (full control)'
              : appliedMode === 'plan'
                ? 'Plan'
                : appliedMode === 'auto'
                  ? 'Auto'
                  : appliedMode;
          vscode.window.setStatusBarMessage(`THEO: Fleet Claude mode set to ${friendly}`, 3500);
        }
        this.lastPosted = null;
        this.render();
        return;
      }

      case 'reload':
        await vscode.commands.executeCommand('workbench.action.reloadWindow');
        return;

      case 'repair':
        try {
          await vscode.commands.executeCommand('antigravityHub.reconnectTabs', {
            forceRender: true
          });
        } catch {}
        if (typeof this.ensureBridge === 'function') {
          await this.ensureBridge({ promptReload: true });
        }
        await this.refresh();
        return;

      case 'config':
        await vscode.commands.executeCommand(
          'workbench.action.openSettings',
          '@ext:bhfirms.antigravity-hub'
        );
        return;

      case 'settings':
        await vscode.commands.executeCommand('antigravity.openSettings');
        return;

      case 'claudeSettings':
        await vscode.commands.executeCommand(
          'workbench.action.openSettings',
          '@ext:anthropic.claude-code'
        );
        return;

      case 'toggleDuplicateIcon':
        try {
          await vscode.commands.executeCommand(
            'antigravityHub.claudeSetActivityBarVisible',
            Boolean(m.visible)
          );
        } catch {}
        await this.refresh();
        return;

      case 'testNotification':
        await notifySessionTransition({
          thread: { id: '', title: 'Sample Unified Hub Session' },
          state: 'completed',
          preferences: {
            notifyOnComplete: true,
            notifySound: true,
            onlyNotifyBackground: false
          },
          isActiveTab: false
        });
        return;

      case 'scope':
        if (m.value === 'workspace' || m.value === 'all') {
          await this.stateStore.updatePreferences({ scope: m.value });
          this.render();
        }
        return;

      case 'providerFilter':
        if (['all', 'antigravity', 'claude'].includes(m.value)) {
          await this.stateStore.updatePreferences({ providerFilter: m.value });
          this.render();
        }
        return;

      case 'autoArchiveDays': {
        const days = Number(m.value);
        if ([0, 1, 2, 7, 14].includes(days)) {
          await this.stateStore.updatePreferences({ autoArchiveInactiveDays: days });
          try {
            await vscode.workspace
              .getConfiguration('antigravityHub')
              .update('autoArchiveInactiveDays', days, vscode.ConfigurationTarget.Global);
            await vscode.workspace
              .getConfiguration('claudeCode')
              .update('archiveInactiveSessions', days, vscode.ConfigurationTarget.Global);
          } catch {}
          if (days > 0 && this.snapshot) {
            await this.sweepAutoArchiveInactive(this.snapshot, days);
          }
          this.render();
        }
        return;
      }

      case 'archiveInactiveNow': {
        const days = typeof m.days === 'number' && m.days > 0 ? m.days : 1;
        if (this.snapshot) {
          await this.sweepAutoArchiveInactive(this.snapshot, days);
          this.render();
        }
        return;
      }

      case 'collapse': {
        const keyMap = {
          usage: 'accountSectionCollapsed',
          antigravityUsage: 'antigravityUsageCollapsed',
          claudeUsage: 'claudeUsageCollapsed',
          questions: 'questionsSectionCollapsed',
          bgTasks: 'bgTasksSectionCollapsed',
          sessions: 'sessionSectionCollapsed',
          ungrouped: 'ungroupedCollapsed',
          archived: 'archivedCollapsed'
        };
        const prefKey = keyMap[m.section];
        if (prefKey) {
          await this.stateStore.updatePreferences({ [prefKey]: Boolean(m.value) });
          this.render();
        }
        return;
      }

      case 'answerQuestion': {
        const sid = String(m.sessionId || m.id || '').trim();
        if (!sid) return;
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const isSkip = Boolean(m.skipped);
        const selectedOptionIds = Array.isArray(m.selectedOptionIds)
          ? m.selectedOptionIds.map((x) => String(x))
          : [];
        const selectedTexts = Array.isArray(m.selectedTexts)
          ? m.selectedTexts.map((x) => String(x))
          : [];
        const writeInResponse = String(m.writeInResponse || '').trim();
        const responses = Array.isArray(m.responses) ? m.responses : [];
        if (thread) {
          thread.pendingQuestion = null;
          thread.rpcWaitingCount = 0;
          thread.status = 'CASCADE_RUN_STATUS_RUNNING';
          thread.notFullyIdle = true;
        }
        this.activity?.liveByThreadId?.delete?.(sid);
        this.lastPosted = null;
        this.syncOpenTabBadges();
        this.render();

        if (provider === 'claude') {
          const answerText = writeInResponse || selectedTexts.join(', ');
          const answersMap = {};
          for (const r of responses) {
            if (r?.question && (r.writeInResponse || (r.selectedTexts && r.selectedTexts.length))) {
              answersMap[r.question] = r.writeInResponse || r.selectedTexts.join(', ');
            }
          }
          const permPayload = {
            id: m.approvalId || thread?.pendingQuestion?.approvalId || sid,
            sessionId: sid,
            approved: !isSkip && selectedOptionIds[0] !== 'deny',
            allowAlways: selectedOptionIds[0] === 'allow_always',
            writeInResponse,
            answers: answersMap
          };
          let claudeRes = null;
          try {
            const directClaude = require('./compat/claude-hub-bridge.cjs');
            if (typeof directClaude?.respondClaudePermission === 'function') {
              claudeRes = await directClaude.respondClaudePermission(permPayload);
            }
          } catch {}
          if (!claudeRes?.resolved) {
            claudeRes = await vscode.commands
              .executeCommand('antigravityHub.claudeRespondPermission', permPayload)
              .catch(() => null);
          }
          if (!claudeRes?.resolved && !isSkip && answerText) {
            await vscode.commands
              .executeCommand('antigravityHub.claudeSendPrompt', {
                id: sid,
                prompt: answerText,
                newSession: false,
                preserveFocus: false
              })
              .catch(() => null);
          }
        } else {
          let ansRes = null;
          if (this.store?.answerAntigravityQuestion) {
            ansRes = await this.store
              .answerAntigravityQuestion(sid, {
                skipped: isSkip,
                selectedOptionIds,
                selectedTexts,
                writeInResponse,
                responses
              })
              .catch(() => null);
          }
          if (!ansRes?.ok) {
            await vscode.commands
              .executeCommand('antigravityHub.remoteAction', {
                type: 'answerQuestion',
                kind: 'answerQuestion',
                id: sid,
                approvalId: m.approvalId || sid,
                skipped: isSkip,
                selectedOptionIds,
                selectedTexts,
                writeInResponse,
                responses
              })
              .catch(() => null);
          }
        }
        setTimeout(() => this.refresh().catch(() => {}), 350);
        return;
      }

      case 'accountCollapse': {
        const accountId = String(m.accountId || m.id || '').trim();
        if (!accountId) return;
        const curState = this.stateStore.read();
        const prevMap =
          curState?.preferences?.collapsedAccounts &&
          typeof curState.preferences.collapsedAccounts === 'object'
            ? curState.preferences.collapsedAccounts
            : {};
        await this.stateStore.updatePreferences({
          collapsedAccounts: {
            ...prevMap,
            [accountId]: Boolean(m.value)
          }
        });
        this.render();
        return;
      }

      case 'accountAdd': {
        if (!this.accountVault) return;
        const res = await this.accountVault.startAddAccount({
          provider: m.provider === 'claude' ? 'claude' : 'antigravity',
          label: m.label || m.nickname || '',
          emailHint: m.emailHint || m.email || '',
          switchOnComplete: m.switchOnComplete !== false,
          vscode
        });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        }
        this.lastPosted = null;
        this.render();
        return;
      }

      case 'accountCancelAdd':
        if (this.accountVault) {
          await this.accountVault.cancelAddAccount();
          this.lastPosted = null;
          this.render();
        }
        return;

      case 'accountFocusTerminal':
        this.accountVault?.focusLoginTerminal?.();
        return;

      case 'accountContinueVerification':
        this.accountVault?.continuePendingLoginAfterVerification?.();
        this.lastPosted = null;
        this.render();
        return;

      case 'accountOpenAuthUrl':
        this.accountVault?.reopenPendingAuthOrVerificationUrl?.();
        return;

      case 'accountSwitch': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        const res = await this.accountVault.switchActiveAccount({
          provider,
          accountId,
          vscode
        });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        } else if (res?.ok && res?.email) {
          vscode.window.setStatusBarMessage(
            `THEO: Active ${provider === 'claude' ? 'Claude Code' : 'Antigravity'} account → ${res.email}`,
            4000
          );
        }
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'accountNewSession': {
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        const beside = Boolean(m.beside);
        const reqSeq = beside ? 0 : (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
        this._tabSwitchCooldownUntil = Date.now() + 550;
        if (!beside) {
          this._pendingActiveTarget = null;
          this.clearPendingActiveExpiryTimer();
        }
        if (accountId && this.accountVault) {
          const list =
            provider === 'claude'
              ? this.accountsView?.claude || []
              : this.accountsView?.antigravity || [];
          const target = list.find((a) => a.id === accountId);
          if (target && !target.active) {
            const sw = await this.accountVault.switchActiveAccount({
              provider,
              accountId,
              vscode
            });
            if (!sw?.ok && sw?.error) {
              vscode.window.showWarningMessage(`THEO: ${sw.error}`);
              return;
            }
          }
        }
        const openedAcctSession = await this.tabs.openNewSession({
          provider,
          beside
        });
        if (!beside && this._openReqSeq !== reqSeq) {
          return;
        }
        if (!beside && openedAcctSession?.uri) {
          this.setPendingActiveTarget({
            key: openedAcctSession.uri,
            provider
          });
        }
        await this.refreshTabStateFast({
          optimisticActiveKey: beside ? '' : openedAcctSession?.uri || '',
          forceOptimistic: !beside && Boolean(openedAcctSession?.uri),
          scheduleFullRefreshMs: 320
        });
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'accountLabel': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        let nextLabel =
          typeof m.label === 'string'
            ? m.label
            : typeof m.name === 'string'
              ? m.name
              : null;
        if (m.prompt || nextLabel === null) {
          const list =
            provider === 'claude'
              ? this.accountsView?.claude || []
              : this.accountsView?.antigravity || [];
          const cur = list.find((a) => a.id === accountId);
          const entered = await vscode.window.showInputBox({
            title: `Nickname / Label for ${cur?.email || accountId}`,
            prompt: 'Optional friendly label (e.g., Personal, Friend, Work). Leave empty to clear.',
            value: cur?.label || ''
          });
          if (entered === undefined) return;
          nextLabel = entered;
        }
        this.accountVault.setAccountLabel({ provider, accountId, label: nextLabel });
        await this.refresh({ forceQuota: false });
        return;
      }

      case 'accountReorder': {
        if (!this.accountVault) return;
        this.accountVault.reorderAccount({
          accountId: String(m.accountId || m.id || '').trim(),
          provider: m.provider || '',
          direction: m.direction || '',
          targetAccountId: String(m.targetAccountId || '').trim(),
          position: m.position || '',
          orderedIds: Array.isArray(m.orderedIds) ? m.orderedIds : null
        });
        await this.refresh({ forceQuota: false });
        return;
      }

      case 'accountRemove': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        const list = (
          provider === 'claude'
            ? this.accountsView?.claude || []
            : this.accountsView?.antigravity || []
        ).filter((a) => a && a.available !== false && !a.signedOut);
        const cur = list.find((a) => a.id === accountId) || list[0] || null;
        const isLastForProvider = list.length <= 1;
        const provLabel = provider === 'claude' ? 'Claude Code' : 'Antigravity';
        if (m.confirm !== false) {
          const actionBtnLabel = isLastForProvider ? 'Sign out' : 'Disconnect';
          const promptMsg = isLastForProvider
            ? `Sign out ${cur?.email || provLabel} from ${provLabel}? Your other connected accounts will remain signed in.`
            : `Disconnect ${cur?.email || accountId} from THEO? Your other connected accounts will remain signed in.`;
          const choice = await vscode.window.showWarningMessage(
            promptMsg,
            { modal: true },
            actionBtnLabel
          );
          if (choice !== actionBtnLabel) return;
        }
        const res = await this.accountVault.removeAccount({ provider, accountId, vscode });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        } else if (res?.ok) {
          vscode.window.setStatusBarMessage(
            `THEO: ${res.signedOutProvider ? 'Signed out' : 'Disconnected'} ${cur?.email || provLabel}`,
            4000
          );
        }
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'filter':
        if (m.filter && typeof m.filter === 'object') {
          await this.stateStore.updatePreferences({
            filterStatuses: Array.isArray(m.filter.statuses) ? m.filter.statuses : [],
            filterTabStates: Array.isArray(m.filter.tabStates) ? m.filter.tabStates : [],
            filterActiveOnly: Boolean(m.filter.activeOnly)
          });
          this.render();
        }
        return;

      case 'open':
        if (m.id) {
          const reqSeq = (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
          this._tabSwitchCooldownUntil = Date.now() + 550;
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const provider = thread?.provider || m.provider || 'antigravity';
          const title = thread?.title || '';
          const pendingOpen = this.setPendingActiveTarget({
            id: m.id,
            provider,
            title,
            durationMs: OPEN_PENDING_ACTIVE_MAX_MS
          });
          await this.stateStore.markSeen(
            m.id,
            Math.max(Math.floor(Date.now() / 1000), Number(thread?.updatedAt) || 0),
            { clearUnread: true }
          );
          if (this._openReqSeq !== reqSeq) {
            return;
          }
          this.syncOpenTabBadges();
          this.render();
          try {
            await this.tabs.openThread(m.id, {
              provider,
              title
            });
          } finally {
            this.settlePendingActiveTarget(pendingOpen);
          }
          if (this._openReqSeq !== reqSeq) {
            return;
          }
          await this.markThreadSeen(m.id);
          if (this._openReqSeq !== reqSeq) {
            return;
          }
          await this.refreshTabStateFast({
            optimisticActiveId: m.id,
            forceOptimistic: true,
            scheduleFullRefreshMs: 380
          });
        }
        return;

      case 'beside':
        if (m.id) {
          this._tabSwitchCooldownUntil = Date.now() + 450;
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          await this.tabs.openThread(m.id, {
            provider: thread?.provider || m.provider || 'antigravity',
            title: thread?.title || '',
            beside: true
          });
          await this.markThreadSeen(m.id);
          await this.refreshTabStateFast({
            scheduleFullRefreshMs: 380
          });
        }
        return;

      case 'focus': {
        this._tabSwitchCooldownUntil = Date.now() + 550;
        const beside = Boolean(m.beside);
        const reqSeq = beside ? 0 : (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
        let pendingFocus = null;
        if (!beside && (m.id || m.key)) {
          pendingFocus = this.setPendingActiveTarget({
            id: m.id || '',
            key: m.key || '',
            provider: m.provider || 'antigravity',
            durationMs: OPEN_PENDING_ACTIVE_MAX_MS
          });
          this.syncOpenTabBadges();
          this.render();
        }
        try {
          if (m.key) {
            await this.tabs.focusDraftTab(m.key, { beside });
          }
        } finally {
          this.settlePendingActiveTarget(pendingFocus);
        }
        if (!beside && this._openReqSeq !== reqSeq) {
          return;
        }
        if (m.id) {
          await this.markThreadSeen(m.id);
        }
        if (!beside && this._openReqSeq !== reqSeq) {
          return;
        }
        await this.refreshTabStateFast({
          optimisticActiveId: beside ? '' : m.id || '',
          optimisticActiveKey: beside ? '' : m.key || '',
          forceOptimistic: !beside && Boolean(m.id || m.key),
          scheduleFullRefreshMs: 380
        });
        return;
      }

      case 'closeTab':
        this.clearPendingActiveTargetIfMatches({ id: m.id, key: m.key });
        await this.tabs.closeThreadTab(m.id, { key: m.key });
        await this.refreshTabStateFast({ scheduleFullRefreshMs: 260 });
        return;

      case 'inspectBgTask': {
        const sid = String(m.sessionId || m.id || '').trim();
        const tid = String(m.taskId || '').trim();
        if (!sid || !tid) return;
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const matched =
          (thread?.backgroundTasks || []).find((t) => t.id === tid || t.fullId === tid) ||
          m.task ||
          { id: tid, fullId: tid, kind: 'task', summary: tid, command: '', state: 'completed' };
        const output = this.store?.readBackgroundTaskOutput
          ? this.store.readBackgroundTaskOutput(sid, provider, matched, 8000)
          : matched.outputPreview || '';
        const detailPayload = {
          type: 'bgTaskDetail',
          sessionId: sid,
          sessionTitle:
            this.stateStore.read()?.customTitles?.[sid] ||
            thread?.title ||
            m.sessionTitle ||
            'Session',
          provider,
          task: {
            id: matched.id,
            fullId: matched.fullId || matched.id,
            subagentConversationId: matched.subagentConversationId || '',
            kind: matched.kind || 'task',
            subagentType: matched.subagentType || '',
            summary: matched.summary || matched.id,
            command: matched.command || '',
            state: matched.state || 'completed',
            isDaemon: Boolean(matched.isDaemon),
            startedAt:
              Number(matched.startedAt || 0) > 0 && Number(matched.startedAt || 0) < 1e12
                ? Number(matched.startedAt) * 1000
                : Number(matched.startedAt || 0),
            completedAt:
              Number(matched.completedAt || 0) > 0 && Number(matched.completedAt || 0) < 1e12
                ? Number(matched.completedAt) * 1000
                : Number(matched.completedAt || 0),
            stepIndex: typeof matched.stepIndex === 'number' ? matched.stepIndex : -1
          },
          output
        };
        for (const v of this.views) {
          try {
            v.webview.postMessage(detailPayload);
          } catch {}
        }
        return;
      }

      case 'cancelBgTask': {
        const sid = String(m.sessionId || m.id || '').trim();
        const tid = String(m.taskId || '').trim();
        if (!sid || !tid) return;
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const matched =
          (thread?.backgroundTasks || []).find((t) => t.id === tid || t.fullId === tid) ||
          { id: tid, fullId: tid, kind: m.kind || 'task', stepIndex: typeof m.stepIndex === 'number' ? m.stepIndex : -1 };
        if (thread && Array.isArray(thread.backgroundTasks)) {
          for (const t of thread.backgroundTasks) {
            if (t.id === tid || t.fullId === tid) {
              t.state = 'cancelled';
              t.completedAt = Math.floor(Date.now() / 1000);
            }
          }
          if (thread.bgTask && (thread.bgTask.id === tid || thread.bgTask.id === matched.id)) {
            thread.bgTask = null;
          }
        }
        this.lastPosted = null;
        this.render();
        if (this.store?.cancelBackgroundTaskOnServer) {
          await this.store.cancelBackgroundTaskOnServer(sid, provider, matched).catch(() => {});
        }
        await this.refresh();
        return;
      }

      case 'cancelAllBgTasks': {
        const filterSid = String(m.sessionId || '').trim();
        const targets = (this.snapshot?.threads || []).filter((t) =>
          filterSid ? t.id === filterSid : Array.isArray(t.backgroundTasks) && t.backgroundTasks.some((x) => x.state === 'running')
        );
        for (const thread of targets) {
          const running = (thread.backgroundTasks || []).filter((x) => x.state === 'running');
          for (const item of running) {
            item.state = 'cancelled';
            item.completedAt = Math.floor(Date.now() / 1000);
            if (this.store?.cancelBackgroundTaskOnServer) {
              await this.store
                .cancelBackgroundTaskOnServer(thread.id, thread.provider || 'antigravity', item)
                .catch(() => {});
            }
          }
          thread.bgTask = null;
        }
        this.lastPosted = null;
        this.render();
        await this.refresh();
        return;
      }

      case 'interrupt':
      case 'stop':
      case 'cancel':
        if (m.id) {
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const provider = thread?.provider || m.provider || '';
          try {
            if (provider !== 'claude') {
              this.store?.markCascadeUserCancelled?.(m.id, true);
            }
            this.activity?.liveByThreadId?.delete?.(m.id);
            if (thread) {
              thread.userCancelled = true;
              thread.status = 'CASCADE_RUN_STATUS_IDLE';
              thread.notFullyIdle = false;
              thread.bgTask = null;
            }
            await this.stateStore.setUnread(
              m.id,
              false,
              Math.max(Math.floor(Date.now() / 1000), Number(thread?.updatedAt) || 0)
            );
            this.syncOpenTabBadges();
            this.render();
          } catch {}
          if (this.remote && typeof this.remote.interruptSession === 'function') {
            await this.remote.interruptSession(m.id, provider);
          } else {
            await this.store.cancelSessionOnServer(m.id, provider).catch(() => {});
            await this.refresh();
          }
        }
        return;

      case 'rename':
        if (m.id) {
          const cleanName = String(m.name || '')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, 120);
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const provider = thread?.provider || m.provider || '';
          await this.stateStore.setCustomTitle(m.id, cleanName);
          await this.tabs.syncTabTitle(m.id, cleanName, provider);
          this.store.renameSessionOnServer(m.id, cleanName, provider).catch(() => {});
          await this.refresh();
        }
        return;

      case 'archive': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        const archived = Boolean(m.value);
        if (archived) {
          for (const cid of cleanIds) {
            this.clearPendingActiveTargetIfMatches({ id: cid });
          }
        }
        if (cleanIds.length > 0) {
          await this.stateStore.setArchivedMany(cleanIds, archived, {
            manualUnarchive: !archived
          });
          if (archived) {
            await this.removeSessionsFromClaudeGroups(cleanIds);
          }
          const threadsById = new Map(
            (this.snapshot?.threads || []).map((t) => [t.id, t])
          );
          const claudeIds = cleanIds.filter(
            (id) => threadsById.get(id)?.provider === 'claude' || !threadsById.has(id)
          );
          if (claudeIds.length > 0) {
            vscode.commands
              .executeCommand('antigravityHub.claudeSetArchived', {
                ids: claudeIds,
                archived
              })
              .then(
                () => {},
                () => {}
              );
          }
        }
        this.render();
        return;
      }

      case 'unread': {
        const ids = Array.isArray(m.ids) ? m.ids : [m.id];
        const nowSec = Math.floor(Date.now() / 1000);
        // Only a session open in a tab on this host can carry an unread mark (see render).
        const openTabIds = new Set((this.openTabsList || []).map((t) => t?.id).filter(Boolean));
        for (const id of ids) {
          if (id) {
            if (m.value && !openTabIds.has(id)) {
              continue;
            }
            const thread = (this.snapshot?.threads || []).find((t) => t.id === id);
            await this.stateStore.setUnread(
              id,
              Boolean(m.value),
              Math.max(nowSec, Number(thread?.updatedAt) || 0)
            );
            if (thread?.provider === 'claude') {
              try {
                await vscode.commands.executeCommand('antigravityHub.claudeSetUnread', {
                  id,
                  unread: Boolean(m.value)
                });
              } catch {}
            }
          }
        }
        this.syncOpenTabBadges();
        this.render();
        return;
      }

      case 'groupCreate': {
        const cleanGrpName = String(m.name || '').replace(/\s+/g, ' ').trim();
        const grp = await this.stateStore.createGroup(
          cleanGrpName || 'New group',
          '',
          String(m.group || '').trim()
        );
        if (grp) {
          const ids = Array.isArray(m.ids) ? m.ids : m.id ? [m.id] : [];
          for (const id of ids) {
            if (id) {
              await this.stateStore.assignThreadGroup(id, grp.id);
            }
          }
          if (!cleanGrpName) {
            this.editGroup = grp.id;
          }
          this.render();
        }
        return;
      }

      case 'newInGroup':
        if (m.group) {
          this._tabSwitchCooldownUntil = Date.now() + 550;
          const reqSeq = (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
          const newProvider = m.provider === 'claude' ? 'claude' : 'antigravity';
          this._pendingActiveTarget = null;
          this.clearPendingActiveExpiryTimer();
          const opened = await this.tabs.openNewSession({
            provider: newProvider
          });
          if (opened?.uri) {
            this.draftGroups.set(opened.uri, m.group);
          }
          await this.stateStore.toggleGroupCollapsed(m.group, false);
          if (this._openReqSeq !== reqSeq) {
            return;
          }
          if (opened?.uri) {
            this.setPendingActiveTarget({
              key: opened.uri,
              provider: newProvider
            });
          }
          await this.refreshTabStateFast({
            optimisticActiveKey: opened?.uri || '',
            forceOptimistic: Boolean(opened?.uri),
            scheduleFullRefreshMs: 320
          });
        }
        return;

      case 'groupRename':
        if (m.group && m.name) {
          await this.stateStore.renameGroup(m.group, m.name);
          this.render();
        }
        return;

      case 'groupDelete':
        if (m.group) {
          const curState = this.stateStore.read();
          const victim = (curState.groups || []).find((g) => g.id === m.group);
          const memberIds = Object.entries(curState.threadGroups || {})
            .filter(([, gid]) => gid === m.group)
            .map(([tid]) => tid);
          await this.stateStore.deleteGroup(m.group);
          if (memberIds.length > 0) {
            await this.removeSessionsFromClaudeGroups(memberIds, m.group);
          }
          // Also purge the group from the native Claude Code extension's per-workspace
          // `sessionGroups:*` storage so it cannot be re-imported later.
          try {
            await vscode.commands.executeCommand('antigravityHub.claudeDeleteGroup', {
              id: m.group,
              name: victim?.name || ''
            });
          } catch {}
          this.render();
        }
        return;

      case 'groupToggle':
        if (m.group) {
          await this.stateStore.toggleGroupCollapsed(m.group, Boolean(m.value));
          this.render();
        }
        return;

      case 'groupAdd': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        if (cleanIds.length > 0 && m.group) {
          if (typeof this.stateStore.assignThreadGroupsMany === 'function') {
            await this.stateStore.assignThreadGroupsMany(cleanIds, m.group);
          } else {
            for (const id of cleanIds) {
              await this.stateStore.assignThreadGroup(id, m.group);
            }
          }
          if (this.store?.removedClaudeGroupSessionIds instanceof Set) {
            for (const id of cleanIds) {
              this.store.removedClaudeGroupSessionIds.delete(id);
            }
          }
        }
        this.render();
        return;
      }

      case 'groupRemove': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        if (cleanIds.length > 0) {
          if (typeof this.stateStore.assignThreadGroupsMany === 'function') {
            await this.stateStore.assignThreadGroupsMany(cleanIds, '');
          } else {
            for (const id of cleanIds) {
              await this.stateStore.assignThreadGroup(id, '');
            }
          }
          await this.removeSessionsFromClaudeGroups(cleanIds, String(m.group || '').trim());
        }
        this.render();
        return;
      }

      case 'copy':
        if (m.id) {
          await vscode.env.clipboard.writeText(m.id);
          vscode.window.setStatusBarMessage(`Copied session ID: ${m.id}`, 2500);
        }
        return;

      case 'reveal':
        if (m.id) {
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const logPath = this.store.getTranscriptLogPath(m.id, thread?.provider || m.provider || '');
          if (logPath && fs.existsSync(logPath)) {
            const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(logPath));
            await vscode.window.showTextDocument(doc, { preview: true });
          } else {
            vscode.window.showInformationMessage('No local transcript log found for this session yet.');
          }
        }
        return;
    }
  }

  async removeSessionsFromClaudeGroups(ids = [], groupId = '') {
    const cleanIds = (Array.isArray(ids) ? ids : [ids])
      .map((x) => String(x || '').trim())
      .filter(Boolean);
    if (cleanIds.length === 0) {
      return;
    }
    const rmSet = new Set(cleanIds);
    try {
      this.store?.noteRemovedClaudeGroupSessions?.(cleanIds);
    } catch {}
    try {
      if (Array.isArray(this.snapshot?.claudeLive?.sessionGroups)) {
        for (const g of this.snapshot.claudeLive.sessionGroups) {
          if (g && Array.isArray(g.sessionIds) && (!groupId || g.id === groupId)) {
            g.sessionIds = g.sessionIds.filter((sid) => !rmSet.has(String(sid || '').trim()));
          }
        }
      }
      if (Array.isArray(this.snapshot?.threads)) {
        for (const t of this.snapshot.threads) {
          if (t && rmSet.has(t.id) && (!groupId || t.groupId === groupId)) {
            t.groupId = '';
          }
        }
      }
    } catch {}
    try {
      const directBridge = require('./compat/claude-hub-bridge.cjs');
      if (typeof directBridge?.removeSessionsFromClaudeGroups === 'function') {
        await directBridge.removeSessionsFromClaudeGroups(directBridge.getBridgeState?.(), {
          ids: cleanIds,
          group: groupId
        });
      }
    } catch {}
    try {
      await vscode.commands.executeCommand('antigravityHub.claudeRemoveFromGroup', {
        ids: cleanIds,
        group: groupId
      });
    } catch {}
  }

  dispose() {
    this.clearPendingActiveExpiryTimer();
    if (this._permCacheDebounce) {
      clearTimeout(this._permCacheDebounce);
      this._permCacheDebounce = null;
    }
    if (this._permCacheWatcher) {
      try {
        this._permCacheWatcher.close();
      } catch {}
      this._permCacheWatcher = null;
    }
    if (this.renderTimer) {
      clearTimeout(this.renderTimer);
      this.renderTimer = null;
    }
    if (this._scheduledRefreshTimer) {
      clearTimeout(this._scheduledRefreshTimer);
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
    }
  }
}

module.exports = {
  HubProvider,
  buildStablePostSignature,
  ACTIVITY_REFRESH_MIN_INTERVAL_MS,
  ACTIVITY_FAST_TAB_SYNC_MIN_INTERVAL_MS,
  RENDER_BURST_MIN_INTERVAL_MS,
  HEARTBEAT_POST_MIN_INTERVAL_MS
};
