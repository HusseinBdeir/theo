const vscode = require('vscode');
const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const { randomBytes } = require('crypto');
const { isSameOrChildPath, isClaudeDesktopScratchPath } = require('./data');
const { SESSION_TAB_SCHEME, normalizeUriKey } = require('./compat/antigravity-tab-state.cjs');

function extractSessionIdFromUriOrKey(rawKey) {
  const k = String(rawKey || '').trim();
  if (!k) return '';
  if (!k.includes('://')) return k;
  const m = k.match(
    /^(?:claude-session|claude-draft|claude):\/\/(?:session|remembered)\/([^/?#]+)|^antigravity-session:\/\/route\/local\/([^/?#]+)/i
  );
  const rawId = (m && (m[1] || m[2])) || '';
  if (!rawId) return '';
  try {
    return decodeURIComponent(rawId).trim();
  } catch {
    return rawId.trim();
  }
}
const { notifySessionTransition } = require('./desktop-notify');
const { AccountVaultManager } = require('./accounts');
const {
  resolveClaudePermissionModePaths,
  resolveSharedClaudePermissionModeInfo,
  writeSharedClaudePermissionMode,
  normalizeExplicitClaudeMode
} = require('./direct-runner');
const { getHostIdleMs, getSelfDeviceRef, resolveRowPinState } = require('./device-identity');
const cwHub = () => require('./compat/antigravity-context-window.cjs');
const resolveSoftAndHardContextLimits = (...args) => cwHub().resolveSoftAndHardContextLimits(...args);
const formatSessionRowModelDisplayName = (...args) =>
  require('./remote').formatSessionRowModelDisplayName(...args);

const {
  collectTabGroupsProtectionSnapshot,
  isTabProtectedInLiveTabGroups,
  evaluateAutoParkTabCandidates,
  DEFAULT_AUTO_PARK_IDLE_MINUTES,
  DEFAULT_AUTO_PARK_KEEP_RECENT
} = require('./session-tabs');
// Held hot swap card (2026-11-20): the records extension.js writes, one per installed folder, when a broken
// edit in ~/bhfirms/theo-hub holds updates (bundle-updater.js readHotSwapHoldStatus). The files are parsed
// only when their names or mtimes change, so a render costs one readdir (and a stat per record, usually none).
// Returns the longest-held record or null.
const hotSwapHoldViewCache = { sig: null, view: null };
function readHotSwapHoldView() {
  try {
    const updater = require('./bundle-updater');
    if (typeof updater?.readHotSwapHoldStatus !== 'function' || typeof updater?.listHotSwapHoldFiles !== 'function') {
      return null;
    }
    const files = updater.listHotSwapHoldFiles();
    const sig = files.map((f) => `${f.name}:${f.mtimeMs}`).join('|');
    if (sig !== hotSwapHoldViewCache.sig) {
      hotSwapHoldViewCache.sig = sig;
      hotSwapHoldViewCache.view = files.length > 0 ? updater.readHotSwapHoldStatus() : null;
    }
    return hotSwapHoldViewCache.view;
  } catch {
    return null;
  }
}

// Bridge failure record for THEO Remote (2026-11-20): this window's "Folder locked" and "Update needed" products,
// kept in ~/.claude/theo-bridge-blocks/ (bundle-updater.js syncBridgeBlockStatus) so the process that sends
// phone alerts can report them. Written when the list changes, and as a heartbeat every minute while it lasts;
// removed when the window exits. The last write is kept on a globalThis key so a hot swap of this module does
// not rewrite or forget it.
const BRIDGE_BLOCK_SYNC_KEY = Symbol.for('theo-hub.bridge-block-sync');
const BRIDGE_BLOCK_EXIT_KEY = Symbol.for('theo-hub.bridge-block-exit');
function syncBridgeBlockRecord(failures) {
  try {
    const updater = require('./bundle-updater');
    if (typeof updater?.syncBridgeBlockStatus !== 'function') return;
    // Test runs never touch the real ~/.claude folder unless they point the records elsewhere.
    if (process.env.THEO_SMOKE_TEST === '1' && !process.env.THEO_BRIDGE_BLOCK_DIR) return;
    let app = '';
    try {
      app = vscode.env?.appName || '';
    } catch {}
    const list = (Array.isArray(failures) ? failures : []).map((f) => ({ ...f, app }));
    globalThis[BRIDGE_BLOCK_SYNC_KEY] = updater.syncBridgeBlockStatus({
      blocks: list,
      prev: globalThis[BRIDGE_BLOCK_SYNC_KEY] || null
    });
    // A closed window's record must not outlive it (a reused pid would keep it alive for up to 3 min).
    if (list.length > 0 && !globalThis[BRIDGE_BLOCK_EXIT_KEY]) {
      globalThis[BRIDGE_BLOCK_EXIT_KEY] = true;
      // The folder is fixed now, so a variable changed later (a test) cannot point the exit at another one.
      const recordPath = typeof updater.bridgeBlockStatusPath === 'function' ? updater.bridgeBlockStatusPath(process.pid) : '';
      process.once('exit', () => {
        if (!recordPath) return;
        try {
          fs.unlinkSync(recordPath);
        } catch {}
      });
    }
  } catch {}
}

// describePatchSkipNotice().patchSkips -> bridge record entries, one per skipped tweak on a loaded version.
// Empty while the loaded bundle-updater predates skip entries (a dev hot swap of this file alone): its
// normalizeBridgeBlocks would record them as locked folders (red-team gate 2026-11-24, Low).
function patchSkipBlocks(patchSkips) {
  const out = [];
  try {
    if (typeof require('./bundle-updater').BRIDGE_SKIP_REMIND_MS !== 'number') return out;
  } catch {
    return out;
  }
  for (const s of Array.isArray(patchSkips) ? patchSkips : []) {
    if (!s || s.active === false) continue;
    for (const id of Array.isArray(s.patches) ? s.patches : []) {
      const name = Array.isArray(s.names) ? s.names[s.patches.indexOf(id)] : '';
      out.push({ provider: s.provider, version: s.version || '', kind: 'skipped', patch: String(id), ...(name ? { name: String(name) } : {}) });
    }
  }
  return out;
}

// Hands-free reload card (2026-11-20): what auto-reload.js decided on its last pass for this window, or null.
function readAutoReloadView() {
  try {
    const mod = require('./auto-reload');
    return typeof mod?.getAutoReloadView === 'function' ? mod.getAutoReloadView() : null;
  } catch {
    return null;
  }
}

// Load limits for the sidebar pipeline (2026-11-12). Every streaming event from a running session used to
// force a complete reload, and a fast tab sync with a full render while one was in flight, on the
// Extension Host thread. A forced (activity) reload now runs at most once per
// ACTIVITY_REFRESH_MIN_INTERVAL_MS. Antigravity events carry live conversation state, so their running and
// waiting indicators stay current in between; Claude events carry none, so a Claude row's status, unread
// mark, pending question and finished toast follow the next reload, at most this interval plus one reload later.
const ACTIVITY_REFRESH_MIN_INTERVAL_MS = 2000;
// Spacing of the fast tab sync that forced events run while a reload is in flight or being held.
const ACTIVITY_FAST_TAB_SYNC_MIN_INTERVAL_MS = 250;
// requestRender() bursts are coalesced to this spacing; a single isolated request still renders in 45 ms.
const RENDER_BURST_MIN_INTERVAL_MS = 250;
// A payload that differs from the last post only in clock stamps is reposted at most this often.
const HEARTBEAT_POST_MIN_INTERVAL_MS = 30000;
// Upper bound on how long a clicked row stays highlighted while its tab is still opening.
const OPEN_PENDING_ACTIVE_MAX_MS = 12000;
// Warm tab pre-hydration bounds: Tier 1 warms deferred tabs & trajectory slices at 4.5s quiet;
// Tier 2 keeps 0..3 idle closed recent tabs pre-rendered behind the active tab based on adaptive hit-rate + RAM pressure.
const MAX_PREWARMED_TABS = 2;
const MAX_PREWARMED_TABS_CEILING = 3;
const PREWARM_TIER1_IDLE_MS = 4500;
const PREWARM_TIER2_IDLE_MS = 15000;
const PREWARM_OS_IDLE_MIN_MS = 45000;
const PREWARM_RETRY_COOLDOWN_MS = 120000;
const PREWARM_ADAPTIVE_MIN_SAMPLES = 5;
const PREWARM_MEM_CRITICAL_BYTES = 640 * 1024 * 1024;
const PREWARM_MEM_PRESSURE_BYTES = 1536 * 1024 * 1024;
const PREWARM_MEM_AMPLE_BYTES = 3072 * 1024 * 1024;
const PREWARM_MEM_CACHE_TTL_MS = 15000;
const PREWARM_REMOTE_HINT_TTL_MS = 20 * 60 * 1000;
const PREWARM_TELEMETRY_SYM = Symbol.for('bhfirms.theoHub.prewarmTelemetry');
const DEFAULT_GIT_BRANCHES = new Set(['main', 'master', 'trunk', 'develop', 'dev', 'head']);
const AFFINITY_STALE_MAX_AGE_MS = 14 * 86400 * 1000;
const AFFINITY_EDITOR_RECENT_MAX_AGE_MS = 4 * 3600 * 1000;
const AFFINITY_BOOST_FOLDER_MS = 6 * 3600 * 1000;
const AFFINITY_BOOST_WORKSPACE_MS = 3 * 3600 * 1000;
const AFFINITY_BOOST_FEATURE_BRANCH_MS = 8 * 3600 * 1000;
const AFFINITY_BOOST_FEATURE_BRANCH_ALONE_MS = 5 * 3600 * 1000;
const AFFINITY_BOOST_DEFAULT_BRANCH_SAME_REPO_MS = 2 * 3600 * 1000;
const AFFINITY_BOOST_REMOTE_HINT_MS = 72 * 3600 * 1000;

function computeAdaptivePrewarmLimits({ hits = 0, coldOpens = 0, evictions = 0, freeMemBytes } = {}) {
  const safeHits = Math.max(0, Number(hits || 0));
  const safeCold = Math.max(0, Number(coldOpens || 0));
  const safeEvict = Math.max(0, Number(evictions || 0));
  const totalAttempts = safeHits + safeCold;
  const hitRate = totalAttempts > 0 ? safeHits / totalAttempts : null;
  const hasMem = typeof freeMemBytes === 'number' && Number.isFinite(freeMemBytes) && freeMemBytes >= 0;

  if (hasMem && freeMemBytes < PREWARM_MEM_CRITICAL_BYTES) {
    return {
      maxWarmTabs: 0,
      tier2IdleMs: 45000,
      osIdleMinMs: 90000,
      adaptiveMode: 'mem_critical',
      adaptiveLabel: 'Paused (low RAM)'
    };
  }
  if (hasMem && freeMemBytes < PREWARM_MEM_PRESSURE_BYTES) {
    return {
      maxWarmTabs: 1,
      tier2IdleMs: 30000,
      osIdleMinMs: 60000,
      adaptiveMode: 'mem_pressure',
      adaptiveLabel: '1 tab (RAM saver)'
    };
  }
  if (
    (totalAttempts >= PREWARM_ADAPTIVE_MIN_SAMPLES && hitRate !== null && hitRate < 0.25) ||
    (safeEvict >= 6 && safeHits === 0)
  ) {
    return {
      maxWarmTabs: 1,
      tier2IdleMs: 25000,
      osIdleMinMs: 60000,
      adaptiveMode: 'low_hit_backoff',
      adaptiveLabel: '1 tab (low-hit backoff)'
    };
  }
  if (
    (!hasMem || freeMemBytes >= PREWARM_MEM_AMPLE_BYTES) &&
    totalAttempts >= 4 &&
    hitRate !== null &&
    hitRate > 0.6
  ) {
    return {
      maxWarmTabs: MAX_PREWARMED_TABS_CEILING,
      tier2IdleMs: 12000,
      osIdleMinMs: 35000,
      adaptiveMode: 'high_hit_boost',
      adaptiveLabel: '3 tabs (>60% hit boost)'
    };
  }
  return {
    maxWarmTabs: MAX_PREWARMED_TABS,
    tier2IdleMs: PREWARM_TIER2_IDLE_MS,
    osIdleMinMs: PREWARM_OS_IDLE_MIN_MS,
    adaptiveMode: 'baseline',
    adaptiveLabel: '2 tabs (standard)'
  };
}

const _gitDirCache = new Map();
const _gitHeadCache = new Map();

function normalizeAffinityPath(rawPath) {
  let clean = String(rawPath || '').trim();
  if (!clean) return '';
  clean = clean.replace(/\\/g, '/').replace(/\/+$/, '');
  if (process.platform === 'win32') {
    clean = clean.toLowerCase();
  }
  return clean;
}

function isSameOrChildAffinityPath(candidatePath, parentPath) {
  const c = normalizeAffinityPath(candidatePath);
  const p = normalizeAffinityPath(parentPath);
  if (!c || !p) return false;
  return c === p || c.startsWith(`${p}/`);
}

// Pure fs/stat-cached `.git/HEAD` reader (zero child processes; safe on Windows Smart App Control).
function resolveGitRepoAndBranchFast(targetPath, now = Date.now()) {
  const raw = String(targetPath || '').trim();
  if (!raw) return { repoRoot: '', commonRepoRoot: '', branch: '' };
  let startDir = raw;
  try {
    const st = fs.statSync(raw);
    if (!st.isDirectory()) {
      startDir = path.dirname(raw);
    }
  } catch {
    startDir = path.dirname(raw);
  }
  const cacheKey = normalizeAffinityPath(startDir);
  if (!cacheKey) return { repoRoot: '', commonRepoRoot: '', branch: '' };

  let dirInfo = _gitDirCache.get(cacheKey);
  if (!dirInfo || dirInfo.expiresAt <= now) {
    let cur = startDir;
    let found = null;
    for (let depth = 0; depth < 12 && cur; depth += 1) {
      const dotGit = path.join(cur, '.git');
      try {
        const dotStat = fs.statSync(dotGit);
        if (dotStat.isDirectory()) {
          found = {
            repoRoot: cur,
            commonRepoRoot: cur,
            gitHeadFile: path.join(dotGit, 'HEAD')
          };
          break;
        }
        if (dotStat.isFile()) {
          const linkText = fs.readFileSync(dotGit, 'utf8');
          const m = linkText.match(/^gitdir:\s*(.+)$/im);
          if (m && m[1]) {
            const gitDir = path.resolve(cur, m[1].trim());
            let commonRoot = cur;
            try {
              const commonFile = path.join(gitDir, 'commondir');
              if (fs.existsSync(commonFile)) {
                const relCommon = fs.readFileSync(commonFile, 'utf8').trim();
                const absCommon = path.resolve(gitDir, relCommon);
                commonRoot = path.dirname(absCommon);
              }
            } catch {}
            found = {
              repoRoot: cur,
              commonRepoRoot: commonRoot,
              gitHeadFile: path.join(gitDir, 'HEAD')
            };
            break;
          }
        }
      } catch {}
      const parent = path.dirname(cur);
      if (!parent || parent === cur) break;
      cur = parent;
    }
    dirInfo = found || { repoRoot: '', commonRepoRoot: '', gitHeadFile: '' };
    if (_gitDirCache.size >= 256) _gitDirCache.clear();
    _gitDirCache.set(cacheKey, { ...dirInfo, expiresAt: now + 10000 });
  }

  let branch = '';
  if (dirInfo.gitHeadFile) {
    try {
      const hStat = fs.statSync(dirInfo.gitHeadFile);
      const cachedHead = _gitHeadCache.get(dirInfo.gitHeadFile);
      if (cachedHead && cachedHead.mtimeMs === hStat.mtimeMs && cachedHead.size === hStat.size) {
        branch = cachedHead.branch;
      } else {
        const headText = fs.readFileSync(dirInfo.gitHeadFile, 'utf8').trim();
        const refMatch = headText.match(/^ref:\s*refs\/heads\/(.+)$/i);
        branch = refMatch && refMatch[1] ? refMatch[1].trim() : '';
        if (_gitHeadCache.size >= 256) _gitHeadCache.clear();
        _gitHeadCache.set(dirInfo.gitHeadFile, { mtimeMs: hStat.mtimeMs, size: hStat.size, branch });
      }
    } catch {
      branch = '';
    }
  }
  return {
    repoRoot: dirInfo.repoRoot || '',
    commonRepoRoot: dirInfo.commonRepoRoot || dirInfo.repoRoot || '',
    branch
  };
}

function normalizePrewarmSortMs(rawSortAt) {
  const n = Number(rawSortAt || 0);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return n < 1e11 ? n * 1000 : n;
}

function computePrewarmAffinityBoost({ thread, affinityContext, now = Date.now(), sortAtMs = 0 } = {}) {
  const reasons = [];
  if (!thread || !affinityContext) {
    return { boostMs: 0, reasons };
  }
  const nowMs = normalizePrewarmSortMs(now) || Date.now();
  if (sortAtMs > 0 && nowMs - sortAtMs > AFFINITY_STALE_MAX_AGE_MS) {
    return { boostMs: 0, reasons };
  }

  let boostMs = 0;
  let primaryFolderMatched = false;
  let sameRepoMatched = false;
  const threadCwd = String(thread.cwd || '').trim();
  let threadGit = null;
  const getThreadGit = () => {
    if (!threadGit) {
      threadGit = threadCwd ? resolveGitRepoAndBranchFast(threadCwd, nowMs) : { repoRoot: '', commonRepoRoot: '', branch: '' };
    }
    return threadGit;
  };

  const pFolder = String(affinityContext.folderPath || '').trim();
  const pRepoRoot = String(affinityContext.repoRoot || '').trim();
  const pCommonRoot = String(affinityContext.commonRepoRoot || pRepoRoot || '').trim();
  const pBranch = String(affinityContext.branch || '').trim();

  if (threadCwd) {
    const tGit = getThreadGit();
    const directFolderMatch = Boolean(
      (pFolder && (isSameOrChildAffinityPath(threadCwd, pFolder) || isSameOrChildAffinityPath(pFolder, threadCwd))) ||
      (pRepoRoot && isSameOrChildAffinityPath(threadCwd, pRepoRoot))
    );
    const sharedRepoMatch = Boolean(
      directFolderMatch ||
      (pCommonRoot && tGit.commonRepoRoot && normalizeAffinityPath(tGit.commonRepoRoot) === normalizeAffinityPath(pCommonRoot))
    );
    if (directFolderMatch || sharedRepoMatch) {
      primaryFolderMatched = true;
      sameRepoMatched = true;
      boostMs += AFFINITY_BOOST_FOLDER_MS;
      reasons.push('folder');
    } else if (Array.isArray(affinityContext.secondaryFolders)) {
      const secMatch = affinityContext.secondaryFolders.some(
        (sf) => sf && (isSameOrChildAffinityPath(threadCwd, sf) || isSameOrChildAffinityPath(sf, threadCwd))
      );
      if (secMatch) {
        boostMs += AFFINITY_BOOST_WORKSPACE_MS;
        reasons.push('workspace');
      }
    }
  }

  let threadBranch = String(thread.branch || '').trim();
  if (!threadBranch && threadCwd) {
    threadBranch = getThreadGit().branch || '';
  }
  if (pBranch && threadBranch && threadBranch === pBranch) {
    const isDefaultBranch = DEFAULT_GIT_BRANCHES.has(pBranch.toLowerCase());
    if (!isDefaultBranch) {
      boostMs += sameRepoMatched
        ? AFFINITY_BOOST_FEATURE_BRANCH_MS
        : AFFINITY_BOOST_FEATURE_BRANCH_ALONE_MS;
      reasons.push('branch');
    } else if (primaryFolderMatched || sameRepoMatched) {
      boostMs += AFFINITY_BOOST_DEFAULT_BRANCH_SAME_REPO_MS;
      reasons.push('branch');
    }
  }

  return { boostMs, reasons };
}

function createEmptyPrewarmTelemetryStore(resetGen = 1) {
  return {
    version: 1,
    resetGen: Number.isFinite(resetGen) && resetGen >= 1 ? Number(resetGen) : 1,
    startedAt: Date.now(),
    tier1Passes: 0,
    prewarmedOpens: 0,
    hits: 0,
    coldOpens: 0,
    evictions: 0,
    remoteHints: 0,
    totalWarmHitAgeMs: 0,
    lastHitAt: 0,
    byProvider: {
      antigravity: { prewarmedOpens: 0, hits: 0, coldOpens: 0, evictions: 0 },
      claude: { prewarmedOpens: 0, hits: 0, coldOpens: 0, evictions: 0 }
    }
  };
}

function ensurePrewarmTelemetryStore() {
  let st = globalThis[PREWARM_TELEMETRY_SYM];
  if (!st || typeof st !== 'object' || st.version !== 1) {
    st = createEmptyPrewarmTelemetryStore(1);
    globalThis[PREWARM_TELEMETRY_SYM] = st;
  } else {
    if (!Number.isFinite(st.resetGen) || st.resetGen < 1) {
      st.resetGen = 1;
    }
    if (!Number.isFinite(st.remoteHints)) {
      st.remoteHints = 0;
    }
  }
  return st;
}

function resetPrewarmTelemetryStore() {
  const prev = globalThis[PREWARM_TELEMETRY_SYM];
  const prevGen =
    prev && typeof prev === 'object' && Number.isFinite(prev.resetGen) ? Number(prev.resetGen) : 0;
  const st = createEmptyPrewarmTelemetryStore(prevGen + 1);
  globalThis[PREWARM_TELEMETRY_SYM] = st;
  return st;
}

// Splits the posted payload into `sig` (the payload with its clock stamps neutralised), `metaSig`
// (top-level metadata + view settings without rows or fast-changing header counters), `stamps`
// (clock stamps alone), and per-row JSON strings for incremental `rowPatch` diffing.
// Two payloads with the same `sig` show the same thing in the sidebar and on the phone.
function buildStablePostParts(payload) {
  const stamps = [];
  const stripUsage = (u) => {
    if (!u || typeof u !== 'object') return u;
    stamps.push(u.at);
    return { ...u, at: 0 };
  };
  const stripAccount = (a) => {
    if (!a || typeof a !== 'object') return a;
    stamps.push(a.quotaUpdatedAt);
    return { ...a, quotaUpdatedAt: 0, usage: stripUsage(a.usage) };
  };
  const stripProvider = (p) =>
    p && typeof p === 'object'
      ? {
          ...p,
          usage: stripUsage(p.usage),
          accounts: Array.isArray(p.accounts) ? p.accounts.map(stripAccount) : p.accounts
        }
      : p;
  let remote = payload?.remote;
  if (remote && typeof remote === 'object') {
    stamps.push(remote.lastCloudSyncAt, remote.lastCloudAttemptAt, remote.cloudSyncInFlight);
    let edgeRelay = remote.edgeRelay;
    if (edgeRelay && typeof edgeRelay === 'object') {
      stamps.push(edgeRelay.latencyMs);
      edgeRelay = { ...edgeRelay, latencyMs: 0 };
    }
    remote = {
      ...remote,
      lastCloudSyncAt: 0,
      lastCloudAttemptAt: 0,
      cloudSyncInFlight: false,
      edgeRelay
    };
  }
  const providers =
    payload?.providers && typeof payload.providers === 'object'
      ? {
          ...payload.providers,
          antigravity: stripProvider(payload.providers.antigravity),
          claude: stripProvider(payload.providers.claude)
        }
      : payload?.providers;

  const rawRows = Array.isArray(payload?.rows) ? payload.rows : [];
  const rowJsons = new Map();
  let canPatch = Array.isArray(payload?.rows);
  let rowsBody = '';
  for (let i = 0; i < rawRows.length; i += 1) {
    const r = rawRows[i];
    const rJson = JSON.stringify(r);
    if (i > 0) rowsBody += ',';
    rowsBody += rJson;
    if (canPatch) {
      const rk = r && typeof r.key === 'string' ? r.key : '';
      if (!rk || rowJsons.has(rk)) {
        canPatch = false;
      } else {
        rowJsons.set(rk, rJson);
      }
    }
  }
  const stripPrewarmTelemetry = (pt) => {
    if (!pt || typeof pt !== 'object') return pt ?? null;
    if ('freeMemMb' in pt) {
      stamps.push(pt.freeMemMb);
      return { ...pt, freeMemMb: 0 };
    }
    return pt;
  };
  const strippedRootUsage = stripUsage(payload?.usage);
  const metaSig = JSON.stringify({
    ...payload,
    rows: undefined,
    pendingActiveKey: null,
    total: 0,
    summary: null,
    summaryByProvider: null,
    prewarmTelemetry: null,
    usage: strippedRootUsage,
    providers,
    remote
  });
  const headerSig = JSON.stringify({
    pendingActiveKey: payload?.pendingActiveKey ?? null,
    total: payload?.total ?? 0,
    summary: payload?.summary ?? null,
    summaryByProvider: payload?.summaryByProvider ?? null,
    prewarmTelemetry: stripPrewarmTelemetry(payload?.prewarmTelemetry)
  });
  const hasRowsProp = Boolean(
    payload && Object.prototype.hasOwnProperty.call(payload, 'rows')
  );
  const sig = hasRowsProp
    ? `${metaSig}|${headerSig}|[${rowsBody}]`
    : JSON.stringify({ ...payload, usage: strippedRootUsage, providers, remote });
  return {
    sig,
    metaSig,
    headerSig,
    stamps: JSON.stringify(stamps),
    rowJsons,
    canPatch
  };
}

function buildStablePostSignature(payload) {
  const { sig, stamps } = buildStablePostParts(payload);
  return { sig, stamps };
}

// The sidebar notice about the Antigravity / Claude Code bridges, from the live bridge state and the
// last install report. A failed patch on a provider whose bridge is not live is reported as such, with
// no Reload button: a reload cannot fix it (Claude Code 2.1.327 reload loop, 2026-11-18).
// Optional patches an upstream update left out (bridge.js patchSkips, 2026-11-24): the bundle works but one
// THEO fix is missing, e.g. the Claude Code context-window pill on 2.1.330. One sentence per version, shown
// under any other notice; '' when nothing is skipped. Claude Code skips are hidden while signed out of Claude.
// Antigravity reports the same for its extension.js and, with no version, for its UI (/main.js).
function describePatchSkipNotice(report, claudeSignedIn) {
  const skips = (Array.isArray(report?.patchSkips) ? report.patchSkips : []).filter(
    (s) => s && Array.isArray(s.names) && s.names.length > 0 && (s.provider !== 'claude' || claudeSignedIn)
  );
  const listOf = (names) =>
    names.length <= 1 ? names[0] || '' : `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
  const sentences = skips.map((s) => {
    const product = `${s.label || (s.provider === 'claude' ? 'Claude Code' : 'Antigravity')}${s.version ? ` ${s.version}` : ''}`;
    const names = s.names.map((n) => String(n));
    const fixes = `THEO's ${listOf(names)} ${names.length > 1 ? 'fixes' : 'fix'}`;
    // The Antigravity UI entry has no version: /main.js comes from the running agy.exe, not an extension folder.
    if (s.source === 'ui') {
      return `The latest ${product} update changed the code behind ${fixes}, so ${names.length > 1 ? 'they are' : 'it is'} not applied. Everything else works. THEO needs an update to match it.`;
    }
    return s.active === false
      ? `The downloaded ${product} changed the code behind ${fixes}, so ${names.length > 1 ? 'they' : 'it'} will be missing once VS Code switches to it. THEO needs an update for that version.`
      : `${product} changed the code behind ${fixes}, so ${names.length > 1 ? 'they are' : 'it is'} not applied. Everything else works. THEO needs an update for this version.`;
  });
  return {
    patchSkips: skips.map((s) => ({
      provider: s.provider,
      version: s.version || '',
      active: s.active !== false,
      patches: Array.isArray(s.patches) ? s.patches.slice() : [],
      // Plain names, same order as `patches`: the phone alert names an Antigravity fix from these
      // (bundle-updater.js only knows the Claude Code names).
      names: s.names.map((n) => String(n))
    })),
    skipMessage: sentences.join(' ')
  };
}

function describeBridgeNotice({ agyActive, claudeActive, claudeSignedIn, report }) {
  return {
    ...describeBridgeFailureNotice({ agyActive, claudeActive, claudeSignedIn, report }),
    ...describePatchSkipNotice(report, claudeSignedIn)
  };
}

function describeBridgeFailureNotice({ agyActive, claudeActive, claudeSignedIn, report }) {
  // Only a failure on the version loaded in this window explains a dead bridge (`active`; reports from
  // before that flag existed count as active). A provider's failure never hides the other's reload.
  const failures = (Array.isArray(report?.patchFailures) ? report.patchFailures : []).filter(
    (f) => f && f.active !== false
  );
  const agyFailure = !agyActive ? failures.find((f) => f.provider === 'antigravity') || null : null;
  const claudeFailure =
    !claudeActive && claudeSignedIn ? failures.find((f) => f.provider === 'claude') || null : null;
  const needsAgy = Boolean(
    !agyFailure && report?.needsAgyReload && (report?.agyHostUpdated || !agyActive)
  );
  const needsClaude = Boolean(
    !claudeFailure &&
      claudeSignedIn &&
      report?.needsClaudeReload &&
      (report?.claudeHostUpdated || !claudeActive)
  );
  const reload = Boolean(needsAgy || needsClaude);
  const failed = [agyFailure, claudeFailure].filter(Boolean);
  if (failed.length > 0) {
    const nameOf = (list) =>
      list
        .map((f) => `${f.label || (f.provider === 'claude' ? 'Claude Code' : 'Antigravity')}${f.version ? ` ${f.version}` : ''}`)
        .join(' and ');
    // Two causes, two messages: a version THEO cannot patch needs a THEO update; a folder THEO cannot
    // write (read-only install, a program holding the files) needs the folder freed, and THEO retries.
    const blocked = failed.filter((f) => f.kind === 'unwritable');
    const unsupported = failed.filter((f) => f.kind !== 'unwritable');
    const otherReload = needsAgy
      ? ' Antigravity also needs a reload to pick up its bridge update.'
      : needsClaude
        ? ' Claude Code also needs a reload to pick up its bridge update.'
        : '';
    const parts = [];
    if (unsupported.length > 0) {
      parts.push(
        `THEO could not connect to ${nameOf(unsupported)} after its update, so ${unsupported.length > 1 ? 'those' : 'its'} ` +
          `sessions will not open from this sidebar. The tabs themselves still work. ` +
          `THEO needs an update for ${unsupported.length > 1 ? 'these versions' : 'this version'}; reloading will not fix that.`
      );
    }
    if (blocked.length > 0) {
      parts.push(
        `THEO cannot write to the ${nameOf(blocked)} ${blocked.length > 1 ? 'folders' : 'folder'}: ` +
          `${blocked.length > 1 ? 'they are' : 'it is'} read-only or held by another program, so ` +
          `${blocked.length > 1 ? 'those' : 'its'} sessions will not open from this sidebar. The tabs themselves still work. ` +
          `THEO keeps retrying and will ask for a reload once it can write there.`
      );
    }
    return {
      reload,
      attachFailed: true,
      attachFailedProviders: failed.map((f) => f.provider),
      attachBlockedProviders: blocked.map((f) => f.provider),
      // Product, version and cause only (no path, no error text): the phone alert names them (syncBridgeBlockRecord).
      attachFailures: failed.map((f) => ({
        provider: f.provider,
        version: f.version || '',
        kind: f.kind === 'unwritable' ? 'unwritable' : 'incompatible'
      })),
      message: parts.join(' ') + otherReload
    };
  }
  return {
    reload,
    attachFailed: false,
    attachFailedProviders: [],
    attachBlockedProviders: [],
    attachFailures: [],
    message: !reload
      ? ''
      : needsAgy && needsClaude
        ? 'Reload VS Code once to activate the Antigravity & Claude Code bridges.'
        : needsClaude
          ? 'Reload VS Code once to activate the Claude Code bridge.'
          : 'Reload VS Code once to activate the Antigravity bridge.'
  };
}

class HubProvider {
  constructor(context, deps) {
    this.context = context;
    this.store = deps.store;
    this.stateStore = deps.stateStore;
    this.activity = deps.activity;
    this.tabs = deps.tabs;
    this.ensureBridge = deps.ensureBridge;
    this.getPcSetupView = deps.getPcSetupView || null;
    this.checkPcSetup = deps.checkPcSetup || null;
    this.applyPcSetup = deps.applyPcSetup || null;
    this.accountVault =
      deps.accountVault ||
      new AccountVaultManager({
        onStateChange: () => {
          this.refresh({ forceQuota: false });
        }
      });
    this.accountsView = {
      antigravity: [],
      claude: [],
      pendingAccountLogin: null
    };

    this.view = null;
    this.views = new Set();
    this.snapshot = null;
    this.openTabsList = [];
    this.bridgeStatus = {
      active: false,
      antigravityActive: false,
      claudeActive: false,
      hideDuplicateIcon: true,
      reload: false,
      message: ''
    };
    this.bridgeInstallReport = null;
    this.loading = true;
    this.lastPosted = null;
    this.editGroup = null;
    this.renderTimer = null;
    this.refreshInFlight = null;
    this.pendingRefresh = null;
    this._scheduledRefreshTimer = null;
    this._scheduledRefreshOpts = null;
    this._tabSwitchCooldownUntil = 0;
    this._pendingActiveTarget = null;
    this._pendingActiveExpiryTimer = null;
    this._openReqSeq = 0;
    this._tabSyncSeq = 0;
    this._fastTabSyncTimer = null;
    this._pendingFastTabSyncOpts = null;
    this.baselineInitialized = false;
    this.draftGroups = new Map();
    this.draftCreatedAt = new Map();
    this._lastActiveSessionTab = null;
    this._prevActiveSessionTab = null;
    this._explicitNewSessionDepth = 0;
    this._permCacheWatcher = null;
    this._permCacheDebounce = null;
    if (process.env.THEO_SMOKE_TEST !== '1') {
      try {
        const { cacheFile } = resolveClaudePermissionModePaths();
        const claudeDir = cacheFile ? path.dirname(cacheFile) : '';
        if (claudeDir && fs.existsSync(claudeDir)) {
          const w = fs.watch(claudeDir, (_evt, fname) => {
            if (fname && String(fname) !== '.theo-claude-permission-mode.json') return;
            if (this._permCacheDebounce) clearTimeout(this._permCacheDebounce);
            this._permCacheDebounce = setTimeout(() => {
              this._permCacheDebounce = null;
              this.lastPosted = null;
              this.render();
            }, 40);
            if (typeof this._permCacheDebounce?.unref === 'function') {
              this._permCacheDebounce.unref();
            }
          });
          w.on('error', () => {});
          if (typeof w.unref === 'function') w.unref();
          this._permCacheWatcher = w;
        }
      } catch {}
    }
  }

  clearPendingActiveExpiryTimer() {
    if (this._pendingActiveExpiryTimer) {
      clearTimeout(this._pendingActiveExpiryTimer);
      this._pendingActiveExpiryTimer = null;
    }
  }

  setPendingActiveTarget({
    id = '',
    key = '',
    provider = 'antigravity',
    title = '',
    durationMs = 2200
  } = {}) {
    const cleanId = String(id || '').trim();
    const cleanKey = String(key || '').trim();
    if (!cleanId && !cleanKey) {
      this._pendingActiveTarget = null;
      this.clearPendingActiveExpiryTimer();
      return null;
    }
    const now = Date.now();
    const prev = this._pendingActiveTarget;
    const prevAlive = Boolean(prev && now < Number(prev.until || 0));
    const sameAsPrev = Boolean(
      prevAlive && ((cleanId && prev.id === cleanId) || (cleanKey && prev.key === cleanKey))
    );
    const outgoingIds = new Set(prevAlive && prev.outgoingIds ? prev.outgoingIds : []);
    const outgoingKeys = new Set(prevAlive && prev.outgoingKeys ? prev.outgoingKeys : []);
    if (prevAlive && !sameAsPrev) {
      if (prev.id) outgoingIds.add(String(prev.id).trim());
      if (prev.key) outgoingKeys.add(String(prev.key).trim());
    }
    if (Array.isArray(this.openTabsList)) {
      for (const tab of this.openTabsList) {
        if (!tab?.active) continue;
        const tabMatchesTarget =
          (cleanId && tab.id === cleanId) || (cleanKey && tab.uri === cleanKey);
        if (!tabMatchesTarget) {
          if (tab.id) outgoingIds.add(String(tab.id).trim());
          if (tab.uri) outgoingKeys.add(String(tab.uri).trim());
        }
      }
    }
    if (cleanId) outgoingIds.delete(cleanId);
    if (cleanKey) outgoingKeys.delete(cleanKey);
    const ttl = Math.max(250, Number(durationMs) || 2200);
    const alreadyOpenInTabs = Boolean(
      Array.isArray(this.openTabsList) &&
        this.openTabsList.some(
          (t) => (cleanId && t?.id === cleanId) || (cleanKey && t?.uri === cleanKey)
        )
    );
    const targetObj = {
      id: cleanId,
      key: cleanKey,
      provider: provider === 'claude' ? 'claude' : 'antigravity',
      title: String(title || ''),
      outgoingIds,
      outgoingKeys,
      setAt: now,
      until: now + ttl,
      seenOpenInTabs: alreadyOpenInTabs,
      confirmedInTabs: false,
      confirmedAt: 0
    };
    this._pendingActiveTarget = targetObj;
    this.clearPendingActiveExpiryTimer();
    this._pendingActiveExpiryTimer = setTimeout(() => {
      this._pendingActiveExpiryTimer = null;
      if (this._pendingActiveTarget === targetObj && Date.now() >= targetObj.until) {
        this._pendingActiveTarget = null;
        this.lastPosted = null;
        this.refreshTabStateFast().catch(() => {});
      }
    }, ttl + 45);
    if (typeof this._pendingActiveExpiryTimer?.unref === 'function') {
      this._pendingActiveExpiryTimer.unref();
    }
    if (Array.isArray(this.openTabsList)) {
      this.openTabsList = this.applyPendingActiveTargetToTabs(this.openTabsList);
    }
    return this._pendingActiveTarget;
  }

  // A sidebar click holds its row highlighted for as long as the tab is still opening (a cold Claude
  // session on a busy host can take longer than the default 2.2 s), then for a normal confirmation window
  // once the open call has returned. Without this the highlight fell back to the previously active
  // session mid-open and jumped again when the tab finally appeared.
  settlePendingActiveTarget(targetObj, durationMs = 2200) {
    if (!targetObj || this._pendingActiveTarget !== targetObj) {
      return;
    }
    const ttl = Math.max(250, Number(durationMs) || 2200);
    targetObj.until = Date.now() + ttl;
    this.clearPendingActiveExpiryTimer();
    this._pendingActiveExpiryTimer = setTimeout(() => {
      this._pendingActiveExpiryTimer = null;
      if (this._pendingActiveTarget === targetObj && Date.now() >= targetObj.until) {
        this._pendingActiveTarget = null;
        this.lastPosted = null;
        this.refreshTabStateFast().catch(() => {});
      }
    }, ttl + 45);
    if (typeof this._pendingActiveExpiryTimer?.unref === 'function') {
      this._pendingActiveExpiryTimer.unref();
    }
  }

  clearPendingActiveTargetIfMatches({ id = '', key = '' } = {}) {
    const cur = this._pendingActiveTarget;
    if (!cur) {
      return;
    }
    const cleanId = String(id || '').trim();
    const cleanKey = String(key || '').trim();
    if (
      (!cleanId && !cleanKey) ||
      (cleanId && cur.id === cleanId) ||
      (cleanKey && cur.key === cleanKey)
    ) {
      this._pendingActiveTarget = null;
      this.clearPendingActiveExpiryTimer();
    }
  }

  getPendingActiveTarget(now = Date.now()) {
    const cur = this._pendingActiveTarget;
    if (!cur || now >= Number(cur.until || 0)) {
      if (cur) {
        this._pendingActiveTarget = null;
        this.clearPendingActiveExpiryTimer();
      }
      return null;
    }
    return cur;
  }

  normalizeDraftGroupKey(uri) {
    const raw = String(uri || '').trim();
    if (!raw) return '';
    return raw.startsWith(`${SESSION_TAB_SCHEME}://`) ? normalizeUriKey(raw) : raw;
  }

  setDraftGroup(uri, groupId = '') {
    const key = this.normalizeDraftGroupKey(uri);
    if (!key) return;
    if (!(this.draftGroups instanceof Map)) {
      this.draftGroups = new Map();
    }
    const cleanGid = String(groupId || '').trim();
    if (!cleanGid || cleanGid === 'ungrouped') {
      this.draftGroups.delete(key);
      if (uri && uri !== key) this.draftGroups.delete(String(uri).trim());
      return;
    }
    this.draftGroups.set(key, cleanGid);
  }

  getDraftGroup(uri, validGroupIds = null) {
    if (!(this.draftGroups instanceof Map) || !uri) return '';
    const raw = String(uri).trim();
    const norm = this.normalizeDraftGroupKey(raw);
    const gid = String(this.draftGroups.get(norm) || this.draftGroups.get(raw) || '').trim();
    if (!gid || gid === 'ungrouped') return '';
    if (validGroupIds instanceof Set && !validGroupIds.has(gid)) return '';
    return gid;
  }

  resolveTabGroupId(tab, persisted = null, validGroupIds = null, archivedSet = null) {
    if (!tab || typeof tab !== 'object') return '';
    const st = persisted || this.stateStore.read();
    const groupsSet =
      validGroupIds instanceof Set
        ? validGroupIds
        : new Set((st.groups || []).map((g) => g?.id).filter(Boolean));
    const archSet =
      archivedSet instanceof Set
        ? archivedSet
        : new Set(Array.isArray(st.archivedIds) ? st.archivedIds : []);
    const cleanId = String(tab.id || '').trim();
    if (cleanId) {
      if (archSet.has(cleanId)) return '';
      const rawGid = String(st.threadGroups?.[cleanId] || '').trim();
      if (rawGid && rawGid !== 'ungrouped' && groupsSet.has(rawGid)) {
        return rawGid;
      }
    }
    const uri = String(tab.uri || tab.key || '').trim();
    return uri ? this.getDraftGroup(uri, groupsSet) : '';
  }

  updateLastActiveSessionContext(openTabs = this.openTabsList, persisted = null) {
    const tabs = Array.isArray(openTabs) ? openTabs : [];
    const st = persisted || this.stateStore.read();
    const validGroupIds = new Set((st.groups || []).map((g) => g?.id).filter(Boolean));
    const archivedSet = new Set(Array.isArray(st.archivedIds) ? st.archivedIds : []);
    const activeTab = tabs.find((t) => t && t.active);
    if (activeTab) {
      const nextId = String(activeTab.id || '').trim();
      const normUri = this.normalizeDraftGroupKey(activeTab.uri || '');
      const prev = this._lastActiveSessionTab;
      const isSameTab = Boolean(
        prev && ((nextId && prev.id === nextId) || (normUri && prev.uri === normUri))
      );
      if (prev && !isSameTab) {
        this._prevActiveSessionTab = prev;
      } else if (!prev) {
        this._prevActiveSessionTab = null;
      }
      this._lastActiveSessionTab = {
        id: nextId,
        uri: normUri,
        group: this.resolveTabGroupId(activeTab, st, validGroupIds, archivedSet)
      };
      return;
    }
    if (tabs.length === 0) {
      this._lastActiveSessionTab = null;
      this._prevActiveSessionTab = null;
      return;
    }
    if (this._lastActiveSessionTab) {
      const prev = this._lastActiveSessionTab;
      const stillOpen = tabs.find((t) => {
        if (!t) return false;
        if (prev.id && t.id === prev.id) return true;
        const tUri = this.normalizeDraftGroupKey(t.uri || '');
        return Boolean(prev.uri && tUri && tUri === prev.uri);
      });
      if (stillOpen) {
        this._lastActiveSessionTab = {
          id: String(stillOpen.id || '').trim(),
          uri: this.normalizeDraftGroupKey(stillOpen.uri || ''),
          group: this.resolveTabGroupId(stillOpen, st, validGroupIds, archivedSet)
        };
      } else {
        this._lastActiveSessionTab = null;
        this._prevActiveSessionTab = null;
      }
    }
  }

  async resolveInheritedGroupForNewSession({ explicitGroup, fromRemoteBridge = false } = {}) {
    const persisted = this.stateStore.read();
    const validGroupIds = new Set((persisted.groups || []).map((g) => g?.id).filter(Boolean));
    const archivedSet = new Set(Array.isArray(persisted.archivedIds) ? persisted.archivedIds : []);
    if (typeof explicitGroup === 'string') {
      const cleanGrp = explicitGroup.trim();
      if (cleanGrp && cleanGrp !== 'ungrouped' && validGroupIds.has(cleanGrp)) {
        return cleanGrp;
      }
      if (fromRemoteBridge) {
        return '';
      }
    }
    const pending = this.getPendingActiveTarget();
    if (pending && (pending.id || pending.key)) {
      return this.resolveTabGroupId(
        { id: pending.id || '', uri: pending.key || '' },
        persisted,
        validGroupIds,
        archivedSet
      );
    }
    if (!Array.isArray(this.openTabsList) || this.openTabsList.length === 0) {
      try {
        const liveTabs = await this.withTimeout(this.tabs.getOpenTabs(), 1200, []);
        if (Array.isArray(liveTabs) && liveTabs.length > 0) {
          this.openTabsList = this.applyPendingActiveTargetToTabs(liveTabs);
        }
      } catch {}
    }
    const tabs = Array.isArray(this.openTabsList) ? this.openTabsList : [];
    const activeTab = tabs.find((t) => t && t.active);
    if (activeTab) {
      return this.resolveTabGroupId(activeTab, persisted, validGroupIds, archivedSet);
    }
    if (this._lastActiveSessionTab) {
      const prev = this._lastActiveSessionTab;
      const matched = tabs.find((t) => {
        if (!t) return false;
        if (prev.id && t.id === prev.id) return true;
        const tUri = this.normalizeDraftGroupKey(t.uri || '');
        return Boolean(prev.uri && tUri && tUri === prev.uri);
      });
      if (matched) {
        return this.resolveTabGroupId(matched, persisted, validGroupIds, archivedSet);
      }
    }
    return '';
  }

  async adoptBoundDraftGroups(openTabs = this.openTabsList) {
    if (!(this.draftGroups instanceof Map) || this.draftGroups.size === 0) {
      return;
    }
    const persisted = this.stateStore.read();
    const validGroupIds = new Set((persisted.groups || []).map((g) => g?.id).filter(Boolean));
    for (const tab of Array.isArray(openTabs) ? openTabs : []) {
      if (!tab?.id || !tab?.uri) continue;
      const gid = this.getDraftGroup(tab.uri, validGroupIds);
      this.setDraftGroup(tab.uri, '');
      if (gid) {
        await this.stateStore.assignThreadGroup(tab.id, gid);
      }
    }
  }

  async maybeInheritGroupForNativeDraft(uri) {
    if (this._explicitNewSessionDepth > 0 || !uri) {
      return '';
    }
    const persisted = this.stateStore.read();
    const validGroupIds = new Set((persisted.groups || []).map((g) => g?.id).filter(Boolean));
    const archivedSet = new Set(Array.isArray(persisted.archivedIds) ? persisted.archivedIds : []);
    if (this.getDraftGroup(uri, validGroupIds)) {
      return this.getDraftGroup(uri, validGroupIds);
    }
    const normUri = this.normalizeDraftGroupKey(uri);
    let sourceTab = this._lastActiveSessionTab;
    if (sourceTab && !sourceTab.id && sourceTab.uri && sourceTab.uri === normUri) {
      sourceTab = this._prevActiveSessionTab;
    }
    if (!sourceTab) {
      return '';
    }
    const gid = this.resolveTabGroupId(sourceTab, persisted, validGroupIds, archivedSet);
    if (!gid) {
      return '';
    }
    this.setDraftGroup(uri, gid);
    await this.stateStore.toggleGroupCollapsed(gid, false);
    return gid;
  }

  applyPendingActiveTargetToTabs(openTabs, explicitTarget = null) {
    const tabs = Array.isArray(openTabs)
      ? openTabs.map((t) => (t && typeof t === 'object' ? { ...t } : t))
      : [];
    const now = Date.now();
    const pending = this.getPendingActiveTarget(now);
    const matchesTarget = (tab, target) =>
      Boolean(
        tab &&
          target &&
          ((target.id && tab.id === target.id) || (target.key && tab.uri === target.key))
      );

    if (pending) {
      const rawTargetOpen = tabs.some((t) => matchesTarget(t, pending));
      if (rawTargetOpen) {
        pending.seenOpenInTabs = true;
      } else if (pending.seenOpenInTabs) {
        // Target tab was open and has now been closed — release immediately instead of resurrecting it!
        this._pendingActiveTarget = null;
        this.clearPendingActiveExpiryTimer();
        return tabs;
      }
      const rawTargetActive = tabs.some((t) => Boolean(t?.active) && matchesTarget(t, pending));
      const rawOtherActive = tabs.some((t) => Boolean(t?.active) && !matchesTarget(t, pending));

      if (rawTargetActive && !rawOtherActive) {
        pending.confirmedInTabs = true;
        if (!pending.confirmedAt) {
          pending.confirmedAt = now;
        }
        return tabs;
      }

      // Never allow an outgoing tab's late focus/view-state bounce to clear _pendingActiveTarget;
      // only release early when VS Code's own openTabs snapshot genuinely moved active state to a third tab
      // (or to the outgoing tab well after confirmation when the user deliberately clicked back in the tab bar).
      const otherActiveIsOutgoing = tabs.some(
        (t) =>
          Boolean(t?.active) &&
          !matchesTarget(t, pending) &&
          ((t.id && pending.outgoingIds?.has?.(t.id)) ||
            (t.uri && pending.outgoingKeys?.has?.(t.uri)))
      );
      const canReleaseToOther =
        pending.confirmedInTabs &&
        !rawTargetActive &&
        rawOtherActive &&
        (otherActiveIsOutgoing
          ? pending.confirmedAt > 0 && now - pending.confirmedAt > 900
          : now - pending.setAt > 280);
      if (canReleaseToOther) {
        this._pendingActiveTarget = null;
        this.clearPendingActiveExpiryTimer();
      } else {
        const matched = tabs.some((t) => matchesTarget(t, pending));
        if (matched) {
          for (const t of tabs) {
            const isTarget = matchesTarget(t, pending);
            t.active = isTarget;
            if (isTarget) {
              t.visible = true;
            }
          }
        } else if (pending.id || pending.key) {
          for (const t of tabs) {
            if (t) t.active = false;
          }
          const thread = pending.id
            ? (this.snapshot?.threads || []).find((th) => th.id === pending.id)
            : null;
          tabs.push({
            uri: pending.key || '',
            id: pending.id || '',
            provider: thread?.provider || pending.provider || 'antigravity',
            title: thread?.title || pending.title || '',
            active: true,
            visible: true,
            viewColumn: 1
          });
        }
        return tabs;
      }
    }

    const cleanId = String(explicitTarget?.id || '').trim();
    const cleanKey = String(explicitTarget?.key || '').trim();
    const forceExplicit = Boolean(explicitTarget?.force);
    // Only honor explicitTarget when explicitly forced (e.g. sidebar user click); unforced bridge/extension
    // notifications must never override authoritative vscode.window.tabGroups active state.
    if (forceExplicit && (cleanId || cleanKey)) {
      const target = { id: cleanId, key: cleanKey };
      const matched = tabs.some((t) => matchesTarget(t, target));
      if (matched) {
        for (const t of tabs) {
          const isTarget = matchesTarget(t, target);
          t.active = isTarget;
          if (isTarget) {
            t.visible = true;
          }
        }
      } else if (cleanId || cleanKey) {
        for (const t of tabs) {
          if (t) t.active = false;
        }
        const thread = cleanId
          ? (this.snapshot?.threads || []).find((th) => th.id === cleanId)
          : null;
        tabs.push({
          uri: cleanKey,
          id: cleanId,
          provider: thread?.provider || 'antigravity',
          title: thread?.title || '',
          active: true,
          visible: true,
          viewColumn: 1
        });
      }
    }
    return tabs;
  }

  get visible() {
    for (const v of this.views) {
      if (v && v.visible) {
        return true;
      }
    }
    return Boolean(this.view?.visible);
  }

  async markThreadSeen(threadId, seenAt = 0) {
    const id = String(threadId || '').trim();
    if (!id) {
      return;
    }
    const pending = this.getPendingActiveTarget();
    if (
      pending &&
      pending.id !== id &&
      pending.outgoingIds?.has?.(id) &&
      Date.now() - Number(pending.setAt || 0) < 900
    ) {
      return;
    }
    const thread = (this.snapshot?.threads || []).find((t) => t.id === id);
    const effectiveSeenAt = Math.max(
      Number(seenAt) || 0,
      Number(thread?.updatedAt) || 0,
      Math.floor(Date.now() / 1000)
    );
    await this.stateStore.markSeen(id, effectiveSeenAt, { clearUnread: true });
    if (thread?.provider === 'claude') {
      try {
        vscode.commands
          .executeCommand('antigravityHub.claudeSetUnread', {
            id,
            unread: false
          })
          .then(
            () => {},
            () => {}
          );
      } catch {}
    }
    if (Array.isArray(this.openTabsList)) {
      this.openTabsList = this.applyPendingActiveTargetToTabs(this.openTabsList);
    }
    this.syncOpenTabBadges();
    this.requestRender();
  }

  scheduleRefresh(delayMs = 280, options = {}) {
    this._scheduledRefreshOpts = {
      force: Boolean(this._scheduledRefreshOpts?.force || options.force),
      forceQuota: Boolean(this._scheduledRefreshOpts?.forceQuota || options.forceQuota)
    };
    const waitMs = Math.max(40, Number(delayMs) || 280);
    const dueAt = Date.now() + waitMs;
    if (this._scheduledRefreshTimer) {
      // A sooner request (a tab change wants its reload in 320 ms) re-arms a later timer, such as the one
      // an activity hold armed. A later request never pushes an earlier one back.
      if (dueAt + 15 >= Number(this._scheduledRefreshDueAt || 0)) {
        return;
      }
      clearTimeout(this._scheduledRefreshTimer);
      this._scheduledRefreshTimer = null;
    }
    this._scheduledRefreshDueAt = dueAt;
    this._scheduledRefreshTimer = setTimeout(() => {
      const opts = this._scheduledRefreshOpts || {};
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
      this._scheduledRefreshDueAt = 0;
      this.refresh(opts).catch(() => {});
    }, waitMs);
    if (typeof this._scheduledRefreshTimer?.unref === 'function') {
      this._scheduledRefreshTimer.unref();
    }
  }

  // Claude Code keeps its own unread list; a session marked read here is cleared there too.
  clearClaudeNativeUnread(thread) {
    if (thread?.provider !== 'claude' || !thread.id) {
      return;
    }
    try {
      Promise.resolve(
        vscode.commands.executeCommand('antigravityHub.claudeSetUnread', { id: thread.id, unread: false })
      ).catch(() => {});
    } catch {}
  }

  isScratchDesktopSession(id, thread = null) {
    if (thread?.claudeDesktopScratch) {
      return true;
    }
    const cleanId = String(id || thread?.id || '').trim();
    if (!cleanId) {
      return false;
    }
    const snapThread = (this.snapshot?.threads || []).find((t) => t && t.id === cleanId);
    if (snapThread?.claudeDesktopScratch) {
      return true;
    }
    const mappedPath =
      thread?.filePath ||
      snapThread?.filePath ||
      this.store?.claudeFileById?.get?.(cleanId) ||
      this.store?.getTranscriptLogPath?.(cleanId, thread?.provider || snapThread?.provider || 'claude') ||
      '';
    return isClaudeDesktopScratchPath(mappedPath);
  }

  launchClaudeDesktopApp() {
    const platform = os.platform();
    const fallbackToProtocol = () => {
      try {
        Promise.resolve(vscode.env.openExternal(vscode.Uri.parse('claude://'))).catch(() => {});
      } catch {}
    };
    const spawnDetached = (cmd, args = []) => {
      try {
        const child = spawn(cmd, args, {
          detached: true,
          stdio: 'ignore',
          windowsHide: false
        });
        child.on('error', fallbackToProtocol);
        if (typeof child.unref === 'function') {
          child.unref();
        }
        return true;
      } catch {
        return false;
      }
    };
    if (platform === 'win32') {
      const localAppData =
        process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
      const candidates = [
        path.join(localAppData, 'Microsoft', 'WindowsApps', 'claude-desktop.exe'),
        path.join(localAppData, 'AnthropicClaude', 'claude.exe')
      ];
      for (const exePath of candidates) {
        try {
          if (fs.existsSync(exePath) && spawnDetached(exePath)) {
            return true;
          }
        } catch {}
      }
    } else if (platform === 'darwin') {
      if (spawnDetached('open', ['-a', 'Claude'])) {
        return true;
      }
    }
    fallbackToProtocol();
    return false;
  }

  async handleClaudeDesktopScratchOpen(thread, sessionId) {
    const cleanId = String(sessionId || thread?.id || '').trim();
    if (!cleanId) {
      return;
    }
    this.clearPendingActiveTargetIfMatches({ id: cleanId });
    const nowSec = Math.floor(Date.now() / 1000);
    await this.stateStore.markSeen(
      cleanId,
      Math.max(nowSec, Number(thread?.updatedAt) || 0),
      { clearUnread: true }
    );
    this.clearClaudeNativeUnread(thread || { id: cleanId, provider: 'claude' });
    this.syncOpenTabBadges();
    this.render();

    const logPath =
      thread?.filePath || this.store?.getTranscriptLogPath?.(cleanId, thread?.provider || 'claude') || '';
    const hasLog = Boolean(logPath && fs.existsSync(logPath));
    const titleLabel = String(thread?.title || '').trim();
    const promptMsg = titleLabel
      ? `"${titleLabel}" is a Claude Desktop chat (no VS Code workspace folder).`
      : 'This is a Claude Desktop chat (no VS Code workspace folder).';
    const actions = hasLog ? ['Open Claude Desktop', 'Show Transcript'] : ['Open Claude Desktop'];
    try {
      Promise.resolve(vscode.window.showInformationMessage(promptMsg, ...actions))
        .then(async (picked) => {
          if (picked === 'Open Claude Desktop') {
            this.launchClaudeDesktopApp();
          } else if (picked === 'Show Transcript' && hasLog) {
            try {
              const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(logPath));
              await vscode.window.showTextDocument(doc, { preview: true });
            } catch {}
          }
        })
        .catch(() => {});
    } catch {}
  }

  handleTabClosedFast({ id = '', key = '' } = {}) {
    const cleanId = String(id || '').trim();
    const cleanKey = String(key || '').trim();
    if (!cleanId && !cleanKey) {
      return;
    }
    this._tabSyncSeq = Number(this._tabSyncSeq || 0) + 1;
    this.clearPendingActiveTargetIfMatches({ id: cleanId, key: cleanKey });
    const nowSec = Math.floor(Date.now() / 1000);
    if (Array.isArray(this.openTabsList) && this.openTabsList.length > 0) {
      // Closing any tab, not only the focused one, marks its session read.
      const closingTab = this.openTabsList.find(
        (t) => t && ((cleanId && t.id === cleanId) || (cleanKey && t.uri === cleanKey))
      );
      const seenId = closingTab?.id || (closingTab ? cleanId : '');
      if (seenId) {
        const closedThread = (this.snapshot?.threads || []).find((t) => t.id === seenId);
        this.stateStore
          .markSeen(
            seenId,
            Math.max(nowSec + 5, Number(closedThread?.updatedAt || 0) + 5),
            { clearUnread: true }
          )
          .catch(() => {});
        this.clearClaudeNativeUnread(closedThread);
      }
      const normClosingKey = this.normalizeDraftGroupKey(cleanKey || closingTab?.uri || '');
      if (closingTab && !closingTab.id && normClosingKey) {
        this.setDraftGroup(normClosingKey, '');
      }
      if (
        this._lastActiveSessionTab &&
        ((cleanId && this._lastActiveSessionTab.id === cleanId) ||
          (normClosingKey && this._lastActiveSessionTab.uri === normClosingKey))
      ) {
        this._lastActiveSessionTab = null;
      }
      if (
        this._prevActiveSessionTab &&
        ((cleanId && this._prevActiveSessionTab.id === cleanId) ||
          (normClosingKey && this._prevActiveSessionTab.uri === normClosingKey))
      ) {
        this._prevActiveSessionTab = null;
      }
      const nextList = this.openTabsList.filter(
        (t) =>
          !(
            (cleanKey && t?.uri === cleanKey) ||
            (!cleanKey && cleanId && t?.id === cleanId)
          )
      );
      if (nextList.length !== this.openTabsList.length) {
        this.openTabsList = nextList;
        this._markDirtyReconcile({ id: cleanId, key: cleanKey });
        this.lastPosted = null;
        this.syncOpenTabBadges();
        this.render();
      }
    }
    this.refreshTabStateFast({ scheduleFullRefreshMs: 260 }).catch(() => {});
  }

  shouldScheduleFullRefreshAfterTabChange(openTabs = this.openTabsList) {
    if (!this.snapshot) {
      return true;
    }
    const sinceLastFullMs =
      Date.now() - Number(this._lastFullRefreshStartedAt || this._lastFullRefreshAt || 0);
    if (!Number.isFinite(sinceLastFullMs) || sinceLastFullMs < 0 || sinceLastFullMs >= 8000) {
      return true;
    }
    const knownIds = new Set((this.snapshot.threads || []).map((t) => t?.id).filter(Boolean));
    for (const tab of Array.isArray(openTabs) ? openTabs : []) {
      if (tab?.id && !knownIds.has(tab.id)) {
        return true;
      }
    }
    return false;
  }

  scheduleFastTabSync(delayMs = 16, options = {}) {
    const prev = this._pendingFastTabSyncOpts || {};
    this._pendingFastTabSyncOpts = {
      optimisticActiveId: options.optimisticActiveId || prev.optimisticActiveId || '',
      optimisticActiveKey: options.optimisticActiveKey || prev.optimisticActiveKey || '',
      forceOptimistic: Boolean(prev.forceOptimistic || options.forceOptimistic),
      scheduleFullRefreshMs: Math.max(
        Number(prev.scheduleFullRefreshMs || 0),
        Number(options.scheduleFullRefreshMs || 0)
      ),
      onlyIfStaleOrUnknown:
        prev.onlyIfStaleOrUnknown === false || options.onlyIfStaleOrUnknown === false
          ? false
          : Boolean(options.onlyIfStaleOrUnknown ?? prev.onlyIfStaleOrUnknown ?? true)
    };
    if (this._fastTabSyncTimer) {
      return;
    }
    this._fastTabSyncTimer = setTimeout(() => {
      const opts = this._pendingFastTabSyncOpts || {};
      this._fastTabSyncTimer = null;
      this._pendingFastTabSyncOpts = null;
      this.refreshTabStateFast(opts).catch(() => {});
    }, Math.max(0, Number(delayMs) || 16));
    if (typeof this._fastTabSyncTimer?.unref === 'function') {
      this._fastTabSyncTimer.unref();
    }
  }

  async refreshTabStateFast({
    optimisticActiveId = '',
    optimisticActiveKey = '',
    forceOptimistic = false,
    scheduleFullRefreshMs = 0,
    onlyIfStaleOrUnknown = false
  } = {}) {
    const syncSeq = (this._tabSyncSeq = Number(this._tabSyncSeq || 0) + 1);
    this._lastFastTabSyncAt = Date.now();
    try {
      const openTabs = await this.tabs.getOpenTabs();
      if (this._tabSyncSeq !== syncSeq) {
        return;
      }
      if (Array.isArray(openTabs)) {
        const prevTabs = Array.isArray(this.openTabsList) ? this.openTabsList : [];
        const nowSec = Math.floor(Date.now() / 1000);
        for (const prev of prevTabs) {
          if (!prev) continue;
          const stillOpen = openTabs.some(
            (cur) =>
              cur &&
              ((prev.uri && cur.uri && cur.uri === prev.uri) ||
                (!prev.uri && prev.id && cur.id === prev.id))
          );
          if (!stillOpen) {
            this.clearPendingActiveTargetIfMatches({
              id: prev.id || '',
              key: prev.uri || ''
            });
            if (!prev.id && prev.uri) {
              this.setDraftGroup(prev.uri, '');
            }
            this.lastPosted = null;
            // Closing any tab, not only the focused one, marks its session read.
            if (prev.id) {
              const closedThread = (this.snapshot?.threads || []).find((t) => t.id === prev.id);
              await this.stateStore.markSeen(
                prev.id,
                Math.max(nowSec + 5, Number(closedThread?.updatedAt || 0) + 5),
                { clearUnread: true }
              );
              if (this._tabSyncSeq !== syncSeq) {
                return;
              }
              this.clearClaudeNativeUnread(closedThread);
            }
          }
        }
        const cleanId = String(optimisticActiveId || '').trim();
        const cleanKey = String(optimisticActiveKey || '').trim();
        const adjustedTabs = this.applyPendingActiveTargetToTabs(openTabs, {
          id: cleanId,
          key: cleanKey,
          force: Boolean(forceOptimistic)
        });
        if (this._tabSyncSeq !== syncSeq) {
          return;
        }
        this.openTabsList = adjustedTabs;
        this.tabs?.recordOpenTabsActivity?.(this.openTabsList);
        await this.adoptBoundDraftGroups(adjustedTabs);
        if (this._tabSyncSeq !== syncSeq) {
          return;
        }
        this.updateLastActiveSessionContext(adjustedTabs);
        for (const tab of adjustedTabs) {
          if (tab?.active && tab?.id) {
            const activeThread = (this.snapshot?.threads || []).find((t) => t.id === tab.id);
            await this.stateStore.markSeen(
              tab.id,
              Math.max(nowSec, Number(activeThread?.updatedAt) || 0),
              { clearUnread: true }
            );
            if (this._tabSyncSeq !== syncSeq) {
              return;
            }
          }
        }
      }
    } catch {}
    if (this._tabSyncSeq !== syncSeq) {
      return;
    }
    this.syncOpenTabBadges();
    this.render();
    if (scheduleFullRefreshMs > 0) {
      if (!onlyIfStaleOrUnknown) {
        this.scheduleRefresh(scheduleFullRefreshMs);
      } else if (this.shouldScheduleFullRefreshAfterTabChange(this.openTabsList)) {
        this.scheduleRefresh(Math.max(scheduleFullRefreshMs, 900));
      }
    }
  }

  async touchActiveTabs() {
    const syncSeq = Number(this._tabSyncSeq || 0);
    try {
      const openTabs = await this.tabs.getOpenTabs();
      if (this._tabSyncSeq !== syncSeq) {
        return;
      }
      if (Array.isArray(openTabs)) {
        const adjustedTabs = this.applyPendingActiveTargetToTabs(openTabs);
        this.openTabsList = adjustedTabs;
        this.tabs?.recordOpenTabsActivity?.(this.openTabsList);
        await this.adoptBoundDraftGroups(adjustedTabs);
        if (this._tabSyncSeq !== syncSeq) {
          return;
        }
        this.updateLastActiveSessionContext(adjustedTabs);
        for (const tab of adjustedTabs) {
          if (tab?.active && tab?.id) {
            await this.markThreadSeen(tab.id);
          }
        }
      }
    } catch {}
  }

  syncOpenTabBadges(persisted = null) {
    if (!Array.isArray(this.openTabsList) || this.openTabsList.length === 0) {
      return;
    }
    const state = persisted || this.stateStore.read();
    const threadsById = new Map(
      (this.snapshot?.threads || []).map((thread) => [thread.id, thread])
    );
    const badgesById = {};

    for (const tab of this.openTabsList) {
      if (!tab?.id) {
        continue;
      }
      const isActive = Boolean(tab.active);
      let thread = threadsById.get(tab.id);
      if (!thread) {
        const liveEntry = this.activity?.liveByThreadId?.get?.(tab.id);
        if (!liveEntry) {
          badgesById[tab.id] = 'plain';
          continue;
        }
        thread = {
          id: tab.id,
          provider: tab.provider === 'claude' ? 'claude' : 'antigravity',
          title: tab.title || 'Untitled session',
          updatedAt: Number(liveEntry.updatedAt || Math.floor(Date.now() / 1000)),
          stepCount: Number(liveEntry.stepCount || 0),
          notFullyIdle: Boolean(liveEntry.notFullyIdle),
          status: liveEntry.notFullyIdle ? 'CASCADE_RUN_STATUS_RUNNING' : 'CASCADE_RUN_STATUS_IDLE'
        };
      }
      if (
        tab.provider !== 'claude' &&
        thread.title &&
        thread.title !== 'Antigravity' &&
        (!tab.title || tab.title === 'new' || tab.title === 'Antigravity')
      ) {
        tab.title = thread.title;
        this.tabs.syncTabTitle(tab.id, thread.title, 'antigravity').catch(() => {});
      }
      const classified = this.activity.classifyThread(thread, { recordTransition: false });
      const isUnread = this.stateStore.isThreadUnread(state, thread, classified.state, isActive);
      let badge = 'plain';
      if (classified.state === 'waiting') {
        badge = 'pending';
      } else if (!isActive && isUnread && classified.state !== 'thinking') {
        badge = 'done';
      }
      if (badgesById[tab.id] === undefined || isActive || badge === 'pending') {
        badgesById[tab.id] = isActive && badge === 'done' ? 'plain' : badge;
      }
    }

    this.tabs.syncTabBadges(badgesById).catch(() => {});
  }

  resolveWebviewView(view) {
    this.view = view;
    this.views.add(view);
    this.lastPosted = null;
    this._resetWebviewPostState(view?.webview || null);
    if (Array.isArray(view.__bhfListeners)) {
      for (const l of view.__bhfListeners) {
        try {
          l?.dispose?.();
        } catch {}
      }
      view.__bhfListeners = [];
    }
    try {
      view.title = 'THEO';
    } catch {}
    const webview = view.webview;
    webview.options = {
      enableScripts: true,
      localResourceRoots: [vscode.Uri.joinPath(this.context.extensionUri, 'resources')]
    };

    this.applyWebviewHtml(webview);

    const listeners = [
      webview.onDidReceiveMessage(async (message) => {
        try {
          await this.handleMessage(message, { trustedWebview: true, webview });
        } catch (err) {
          vscode.window.showErrorMessage(`THEO: ${err?.message || err}`);
        }
      }),
      view.onDidChangeVisibility(() => {
        if (view.visible) {
          this.refresh({ forceQuota: false });
        }
      }),
      view.onDidDispose(() => {
        listeners.forEach((l) => l.dispose());
        view.__bhfListeners = [];
        this.views.delete(view);
        if (this.view === view) {
          this.view = this.views.values().next().value || null;
        }
      })
    ];
    view.__bhfListeners = listeners;

    this.render();
    this.refresh({ forceQuota: true });
  }

  // Identity of the three files the sidebar page is built from. A webview is rebuilt only when this
  // changes: resetting `webview.html` reloads the whole page (a visible blink that also drops the scroll
  // position), so a hot swap of host-side modules must not do it.
  getWebviewResourceSignature() {
    const parts = [];
    for (const file of ['hub.html', 'hub.css', 'hub.js']) {
      try {
        const st = fs.statSync(path.join(this.context.extensionPath, 'resources', file));
        parts.push(`${file}:${Math.floor(st.mtimeMs)}:${st.size}`);
      } catch {
        parts.push(`${file}:missing`);
      }
    }
    return parts.join('|');
  }

  applyWebviewHtml(webview) {
    if (!webview) return;
    if (!this._webviewResourceSigs) {
      this._webviewResourceSigs = new WeakMap();
    }
    const resourceSig = this.getWebviewResourceSignature();
    const nonce = randomBytes(18).toString('hex');
    const resUri = (file) => {
      let ver = '';
      try {
        ver = `?v=${Math.floor(fs.statSync(path.join(this.context.extensionPath, 'resources', file)).mtimeMs)}`;
      } catch {}
      return (
        webview
          .asWebviewUri(vscode.Uri.joinPath(this.context.extensionUri, 'resources', file))
          .toString() + ver
      );
    };
    webview.html = fs
      .readFileSync(path.join(this.context.extensionPath, 'resources', 'hub.html'), 'utf8')
      .replaceAll('{{cspSource}}', webview.cspSource)
      .replaceAll('{{nonce}}', nonce)
      .replaceAll('{{css}}', resUri('hub.css'))
      .replaceAll('{{js}}', resUri('hub.js'));
    this._webviewResourceSigs.set(webview, resourceSig);
    this._resetWebviewPostState(webview);
  }

  // Lazily initialized so hot-swapped HubProvider instances (whose constructor did not re-run)
  // seamlessly support incremental per-webview rowPatch delivery without missing fields.
  _ensurePostTracking() {
    if (!(this._webviewPostState instanceof WeakMap)) {
      this._webviewPostState = new WeakMap();
    }
    if (!(this._webviewPostSeq instanceof WeakMap)) {
      this._webviewPostSeq = new WeakMap();
    }
    if (!(this._dirtyReconcileKeys instanceof Set)) {
      this._dirtyReconcileKeys = new Set();
    }
    if (!(this._dirtyReconcileIds instanceof Set)) {
      this._dirtyReconcileIds = new Set();
    }
  }

  _resetWebviewPostState(webview = null) {
    this._ensurePostTracking();
    if (webview) {
      this._webviewPostState.delete(webview);
      return;
    }
    this._webviewPostState = new WeakMap();
  }

  _markDirtyReconcile(target = {}) {
    this._ensurePostTracking();
    const id = String(target.id || '').trim();
    const key = String(target.key || '').trim();
    if (id) this._dirtyReconcileIds.add(id);
    if (key) this._dirtyReconcileKeys.add(key);
    const ids = Array.isArray(target.ids) ? target.ids : [];
    for (const rawId of ids) {
      const cleanId = String(rawId || '').trim();
      if (cleanId) this._dirtyReconcileIds.add(cleanId);
    }
  }

  // Called after every hot swap. Host-only changes (remote.js, store.js, a bridge…) just repost the state;
  // the page itself is rebuilt only when hub.html / hub.css / hub.js changed on disk.
  reloadAllWebviews() {
    this.lastPosted = null;
    this._resetWebviewPostState();
    const resourceSig = this.getWebviewResourceSignature();
    for (const v of this.views) {
      try {
        if (this._webviewResourceSigs?.get(v.webview) !== resourceSig) {
          this.applyWebviewHtml(v.webview);
        }
      } catch {}
    }
    this.render();
  }

  openDetailsModal(scrollToPcSetup = false) {
    vscode.commands.executeCommand('antigravity.panel.focus').catch(() => {});
    this.lastPosted = null;
    this.render();
    for (const v of this.views) {
      try {
        v.webview.postMessage({
          type: 'openDetails',
          scrollToPcSetup: Boolean(scrollToPcSetup)
        });
      } catch {}
    }
  }

  setBridgeInstallReport(report) {
    this.bridgeInstallReport = report || null;
    const agyActive = Boolean(this.bridgeStatus?.antigravityActive);
    const claudeActive = Boolean(this.bridgeStatus?.claudeActive);
    const claudeSignedIn =
      typeof this.accountVault?.hasSignedInProvider === 'function'
        ? this.accountVault.hasSignedInProvider('claude')
        : report?.claudeSignedIn !== false;
    this.bridgeStatus = {
      ...this.bridgeStatus,
      ...describeBridgeNotice({ agyActive, claudeActive, claudeSignedIn, report })
    };
    this.requestRender();
  }

  requestRender() {
    if (this.renderTimer) {
      return;
    }
    const sinceLastRenderMs = Date.now() - Number(this._lastRenderAt || 0);
    const delayMs =
      sinceLastRenderMs >= 0 && sinceLastRenderMs < RENDER_BURST_MIN_INTERVAL_MS
        ? Math.max(45, RENDER_BURST_MIN_INTERVAL_MS - sinceLastRenderMs)
        : 45;
    this.renderTimer = setTimeout(() => {
      this.renderTimer = null;
      this.render();
    }, delayMs);
  }

  getAutoArchiveInactiveDays(persisted = null, claudeLive = null) {
    const validDays = [0, 1, 2, 7, 14];
    const state = persisted || this.stateStore.read();
    const prefDays = state?.preferences?.autoArchiveInactiveDays;
    if (typeof prefDays === 'number' && validDays.includes(prefDays)) {
      return prefDays;
    }
    try {
      const hubCfgDays = vscode.workspace
        .getConfiguration('antigravityHub')
        .get('autoArchiveInactiveDays');
      if (typeof hubCfgDays === 'number' && validDays.includes(hubCfgDays)) {
        return hubCfgDays;
      }
      const claudeCfgDays = vscode.workspace
        .getConfiguration('claudeCode')
        .get('archiveInactiveSessions');
      if (typeof claudeCfgDays === 'number' && validDays.includes(claudeCfgDays)) {
        return claudeCfgDays;
      }
    } catch {}
    if (
      typeof claudeLive?.autoArchiveDays === 'number' &&
      validDays.includes(claudeLive.autoArchiveDays)
    ) {
      return claudeLive.autoArchiveDays;
    }
    return 14;
  }

  async sweepAutoArchiveInactive(snap, explicitDays = null) {
    const allThreads = snap?.threads || [];
    if (allThreads.length === 0) {
      return 0;
    }
    const state = this.stateStore.read();
    const days =
      typeof explicitDays === 'number'
        ? explicitDays
        : this.getAutoArchiveInactiveDays(state, snap?.claudeLive);
    if (!days || days <= 0) {
      return 0;
    }

    const nowSec = Math.floor(Date.now() / 1000);
    const cutoffSec = nowSec - days * 86400;
    const archivedSet = new Set(state.archivedIds || []);
    const groupIds = new Set((state.groups || []).map((g) => g.id));
    const openTabIds = new Set(
      (this.openTabsList || []).map((t) => t?.id).filter(Boolean)
    );

    const toArchive = [];
    const claudeToArchive = [];

    for (const thread of allThreads) {
      if (!thread?.id || archivedSet.has(thread.id) || openTabIds.has(thread.id)) {
        continue;
      }
      if (resolveRowPinState(thread, state.pinnedThreads, state.unpinnedThreads).pinned) {
        continue;
      }
      const hasGroup =
        Boolean(state.threadGroups?.[thread.id]) &&
        groupIds.has(state.threadGroups[thread.id]);
      if (hasGroup) {
        continue;
      }
      const classified = this.activity.classifyThread(thread, { recordTransition: false });
      if (
        classified.state === 'thinking' ||
        classified.state === 'waiting' ||
        thread.elsewhere
      ) {
        continue;
      }
      // Every thread here has no open tab, and a session with no open tab carries no unread mark
      // (see render), so a stored or derived unread state no longer blocks auto-archive.
      const unarchivedAtSec = Number(state.unarchivedAt?.[thread.id] || 0);
      const unassignedAtSec = Number(state.unassignedGroupThreads?.[thread.id] || 0);
      const effectiveActivitySec = Math.max(
        Number(thread.updatedAt || 0),
        unarchivedAtSec,
        unassignedAtSec
      );
      if (effectiveActivitySec > 0 && effectiveActivitySec < cutoffSec) {
        toArchive.push(thread.id);
        if (thread.provider === 'claude') {
          claudeToArchive.push(thread.id);
        }
      }
    }

    if (toArchive.length > 0) {
      await this.stateStore.setArchivedMany(toArchive, true);
      if (claudeToArchive.length > 0) {
        vscode.commands
          .executeCommand('antigravityHub.claudeSetArchived', {
            ids: claudeToArchive,
            archived: true
          })
          .then(
            () => {},
            () => {}
          );
      }
    }
    return toArchive.length;
  }

  getAutoParkConfig(persisted = null) {
    const state = persisted || this.stateStore.read();
    const prefMins = state?.preferences?.autoParkIdleTabsMinutes;
    const prefKeep = state?.preferences?.autoParkKeepRecentTabs;
    let idleMinutes =
      typeof prefMins === 'number' && Number.isFinite(prefMins)
        ? Math.max(0, prefMins)
        : null;
    let keepRecentTabs =
      typeof prefKeep === 'number' && Number.isFinite(prefKeep) && prefKeep >= 1
        ? Math.min(50, Math.floor(prefKeep))
        : null;
    try {
      const cfg = vscode.workspace?.getConfiguration?.('antigravityHub');
      if (idleMinutes === null) {
        const cfgMins = cfg?.get?.('autoParkIdleTabsMinutes');
        if (typeof cfgMins === 'number' && Number.isFinite(cfgMins)) {
          idleMinutes = Math.max(0, cfgMins);
        }
      }
      if (keepRecentTabs === null) {
        const cfgKeep = cfg?.get?.('autoParkKeepRecentTabs');
        if (typeof cfgKeep === 'number' && Number.isFinite(cfgKeep) && cfgKeep >= 1) {
          keepRecentTabs = Math.min(50, Math.floor(cfgKeep));
        }
      }
    } catch {}
    return {
      idleMinutes: idleMinutes === null ? DEFAULT_AUTO_PARK_IDLE_MINUTES : idleMinutes,
      keepRecentTabs: keepRecentTabs === null ? DEFAULT_AUTO_PARK_KEEP_RECENT : keepRecentTabs
    };
  }

  readAntigravityDraftDetails(proxyPortOverride = null) {
    let port = Number(proxyPortOverride || 0);
    if (!port && proxyPortOverride !== 0) {
      try {
        port = Number(cwHub().getProxyState?.()?.proxyPort || 0);
      } catch {
        port = 0;
      }
    }
    if (!(port > 0)) {
      return Promise.resolve({
        ok: true,
        proxyPort: 0,
        drafts: 0,
        reporting: 0,
        draftCascadeIds: [],
        reportingCascadeIds: [],
        draftTabIds: [],
        reportingTabIds: []
      });
    }
    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => {
        if (done) return;
        done = true;
        resolve(v);
      };
      try {
        const req = http.request(
          {
            hostname: '127.0.0.1',
            port,
            path: '/__bhf_draft_state?stats=1&details=1',
            method: 'GET',
            timeout: 1200
          },
          (res) => {
            let body = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => {
              if (body.length < 32768) body += chunk;
            });
            res.on('end', () => {
              try {
                const parsed = JSON.parse(body);
                if (res.statusCode === 200 && parsed && parsed.ok === true) {
                  finish({ ...parsed, ok: true, proxyPort: port });
                  return;
                }
              } catch {}
              finish({ ok: false, proxyPort: port });
            });
          }
        );
        req.on('error', () => finish({ ok: false, proxyPort: port }));
        req.on('timeout', () => {
          try { req.destroy(); } catch {}
          finish({ ok: false, proxyPort: port });
        });
        req.end();
      } catch {
        finish({ ok: false, proxyPort: port });
      }
    });
  }

  async sweepAutoParkIdleTabs(snap, opts = {}) {
    if (!opts.force && process.env.THEO_SMOKE_TEST === '1') {
      return 0;
    }
    const nowMs = Number(opts.now || Date.now());
    if (!opts.force && this._lastAutoParkSweepAt && nowMs - Number(this._lastAutoParkSweepAt) < 30000) {
      return 0;
    }
    if (this._autoParkInFlight && !opts.force) {
      return 0;
    }
    this._lastAutoParkSweepAt = nowMs;
    this._autoParkInFlight = true;
    try {
      const openTabs = Array.isArray(this.openTabsList) ? this.openTabsList : [];
      if (openTabs.length === 0) return 0;

      const persisted = this.stateStore.read();
      const { idleMinutes, keepRecentTabs } = this.getAutoParkConfig(persisted);
      const idleMs =
        typeof opts.idleMs === 'number'
          ? opts.idleMs
          : Number(idleMinutes || 0) * 60 * 1000;
      const keepRecentCount =
        typeof opts.keepRecentTabs === 'number' ? opts.keepRecentTabs : keepRecentTabs;
      if (!(idleMs > 0) || openTabs.length <= keepRecentCount) {
        return 0;
      }

      const activityByKey = this.tabs?.recordOpenTabsActivity?.(openTabs, nowMs);
      if (!(activityByKey instanceof Map)) {
        return 0;
      }

      const draftProtectedIds = new Set();
      let blockAllAgyHydratedAutoPark = false;
      let blockAllClaudeAutoPark = false;

      const hasHydratedAgyTabs = openTabs.some(
        (t) => t && t.provider !== 'claude' && t.id && t.hydrated !== false
      );
      if (hasHydratedAgyTabs) {
        const agyDrafts =
          opts.agyDraftStats || (await this.readAntigravityDraftDetails(opts.proxyPort));
        if (!agyDrafts || !(Number(agyDrafts.proxyPort || 0) > 0) || agyDrafts.ok !== true) {
          blockAllAgyHydratedAutoPark = true;
        } else {
          for (const id of agyDrafts.draftCascadeIds || []) {
            if (id) draftProtectedIds.add(String(id));
          }
          const reportingSet = new Set(
            (agyDrafts.reportingCascadeIds || []).map((id) => String(id || '').trim()).filter(Boolean)
          );
          for (const tab of openTabs) {
            if (tab && tab.provider !== 'claude' && tab.id && tab.hydrated !== false) {
              if (!reportingSet.has(String(tab.id))) {
                draftProtectedIds.add(String(tab.id));
              }
            }
          }
        }
      }

      const hasClaudeTabs = openTabs.some(
        (t) => t && t.provider === 'claude' && t.id && t.hydrated !== false
      );
      if (hasClaudeTabs) {
        let claudeDraftSnap = opts.claudeDraftSnap || null;
        if (!claudeDraftSnap) {
          try {
            const cb = require('./compat/claude-hub-bridge.cjs');
            claudeDraftSnap =
              typeof cb.getClaudeDraftSnapshot === 'function'
                ? cb.getClaudeDraftSnapshot({ ttlMs: 5 * 60 * 1000, now: nowMs, details: true })
                : null;
          } catch {
            claudeDraftSnap = null;
          }
        }
        let claudeExtActive = false;
        try {
          claudeExtActive = Boolean(
            vscode.extensions?.getExtension?.('anthropic.claude-code')?.isActive
          );
        } catch {}
        if (
          !claudeDraftSnap ||
          (claudeDraftSnap.attached === false && (claudeExtActive || hasClaudeTabs)) ||
          Boolean(claudeDraftSnap.hasAnonymousSilentOrDraft)
        ) {
          blockAllClaudeAutoPark = true;
        } else {
          for (const id of claudeDraftSnap.draftSessionIds || []) {
            if (id) draftProtectedIds.add(String(id));
          }
          for (const id of claudeDraftSnap.silentSessionIds || []) {
            if (id) draftProtectedIds.add(String(id));
          }
          const claudeReportingSet = new Set(
            (claudeDraftSnap.reportingSessionIds || []).map((id) => String(id || '').trim()).filter(Boolean)
          );
          for (const tab of openTabs) {
            if (tab && tab.provider === 'claude' && tab.id && tab.hydrated !== false) {
              if (!claudeReportingSet.has(String(tab.id))) {
                draftProtectedIds.add(String(tab.id));
              }
            }
          }
        }
      }

      const pendingApprovalIds = new Set();
      try {
        const approvals = opts.pendingApprovals || cwHub().getPendingApprovals?.() || [];
        for (const item of Array.isArray(approvals) ? approvals : []) {
          if (item?.id) pendingApprovalIds.add(String(item.id));
        }
      } catch {}
      try {
        const claudePerms =
          opts.claudePendingPermissions ||
          require('./compat/claude-hub-bridge.cjs').getPendingPermissionsSnapshot?.() ||
          [];
        for (const item of Array.isArray(claudePerms) ? claudePerms : []) {
          if (item?.sessionId) pendingApprovalIds.add(String(item.sessionId));
        }
      } catch {}

      const unreadIds = new Set();
      const pinnedIds = new Set();
      const archivedSet = new Set(persisted.archivedIds || []);
      const threadsById = new Map();
      for (const thread of snap?.threads || []) {
        if (!thread || !thread.id) continue;
        const classified = this.activity.classifyThread(thread, { recordTransition: false });
        const isArchived =
          archivedSet.has(thread.id) ||
          Boolean(thread.archived && !persisted.unarchivedAt?.[thread.id]);
        if (
          !isArchived &&
          this.stateStore.isThreadUnread(persisted, thread, classified.state, false)
        ) {
          unreadIds.add(thread.id);
        }
        if (
          resolveRowPinState(
            {
              id: thread.id,
              archived: isArchived,
              pinned: thread.pinned,
              pinnedAt: thread.pinnedAt,
              pinUpdatedAt: thread.pinUpdatedAt
            },
            persisted.pinnedThreads,
            persisted.unpinnedThreads
          ).pinned
        ) {
          pinnedIds.add(thread.id);
        }
        const rawBg = Array.isArray(thread.backgroundTasks) ? thread.backgroundTasks : [];
        const bgRunningCount = Math.max(
          rawBg.filter((x) => x && x.state === 'running').length,
          Number(thread.bgRunningTotal || 0)
        );
        threadsById.set(thread.id, {
          id: thread.id,
          provider: thread.provider === 'claude' ? 'claude' : 'antigravity',
          updatedAtMs: Number(thread.updatedAt || 0) * 1000,
          status: thread.status,
          notFullyIdle: Boolean(thread.notFullyIdle),
          classifiedState: classified.state,
          pendingQuestion: thread.pendingQuestion || null,
          elsewhere: Boolean(thread.elsewhere),
          bgRunningCount,
          scheduledWorkUntilMs: Number(thread.scheduledWorkUntil || 0) * 1000
        });
      }

      const tgSnap = opts.tabGroupsProtection || collectTabGroupsProtectionSnapshot(vscode);
      const candidates = evaluateAutoParkTabCandidates({
        openTabs,
        threadsById,
        activityByKey,
        unreadIds,
        pinnedIds,
        visibleUris: tgSnap.visibleUris,
        visibleLabels: tgSnap.visibleLabels,
        nativePinnedUris: tgSnap.nativePinnedUris,
        nativePinnedLabels: tgSnap.nativePinnedLabels,
        draftProtectedIds,
        pendingApprovalIds,
        blockAllClaudeAutoPark,
        blockAllAgyHydratedAutoPark,
        idleMs,
        keepRecentCount,
        maxClosePerPass: typeof opts.maxClosePerPass === 'number' ? opts.maxClosePerPass : 4,
        nowMs
      });

      let closedCount = 0;
      for (const cand of candidates) {
        if (!opts.skipLiveTabGroupRecheck && isTabProtectedInLiveTabGroups(cand, vscode)) {
          continue;
        }
        const ok = await this.tabs
          .closeThreadTab(cand.id, { key: cand.uri, provider: cand.provider })
          .catch(() => false);
        if (ok) closedCount += 1;
      }
      if (closedCount > 0) {
        const refreshedTabs = await this.tabs.getOpenTabs().catch(() => null);
        if (Array.isArray(refreshedTabs)) {
          this.openTabsList = this.applyPendingActiveTargetToTabs(refreshedTabs);
          this.tabs?.recordOpenTabsActivity?.(this.openTabsList, nowMs);
        }
      }
      return closedCount;
    } finally {
      this._autoParkInFlight = false;
    }
  }

  hotReloadUpdatedModules() {
    const now = Date.now();
    if (now - Number(this._lastHotReloadCheckAt || 0) < 5000) {
      return;
    }
    this._lastHotReloadCheckAt = now;
    if (!this._moduleMtimes) {
      this._moduleMtimes = new Map();
    }
    const relPaths = [
      './data.js',
      './compat/antigravity-context-window.cjs',
      './compat/antigravity-hub-bridge.cjs',
      './compat/claude-hub-bridge.cjs',
      './accounts.js',
      './activity.js',
      './session-tabs.js',
      './state.js',
      './store.js'
    ];
    let changed = false;
    let dataChanged = false;
    for (const rel of relPaths) {
      try {
        const resolved = require.resolve(rel);
        const stat = fs.statSync(resolved);
        const mtime = Math.floor(stat.mtimeMs);
        const prev = this._moduleMtimes.get(resolved);
        this._moduleMtimes.set(resolved, mtime);
        if (prev !== undefined && prev !== mtime) {
          delete require.cache[resolved];
          changed = true;
          if (rel === './data.js') {
            dataChanged = true;
          }
        }
      } catch {}
    }
    if (dataChanged) {
      for (const depRel of ['./accounts.js', './store.js']) {
        try {
          delete require.cache[require.resolve(depRel)];
        } catch {}
      }
    }
    if (changed) {
      try {
        const freshAccounts = require('./accounts.js');
        if (this.accountVault && freshAccounts?.AccountVaultManager?.prototype) {
          Object.setPrototypeOf(this.accountVault, freshAccounts.AccountVaultManager.prototype);
          if (!this.accountVault.hasCustomHttpsJsonRequest && freshAccounts.defaultHttpsJsonRequest) {
            this.accountVault.httpsJsonRequest = freshAccounts.defaultHttpsJsonRequest;
          }
          this.accountVault.agyQuotaInFlightById?.clear?.();
          this.accountVault.claudeQuotaInFlightById?.clear?.();
        }
      } catch {}
      try {
        const freshActivity = require('./activity.js');
        if (this.activity && freshActivity?.SessionActivityTracker?.prototype) {
          Object.setPrototypeOf(this.activity, freshActivity.SessionActivityTracker.prototype);
        }
      } catch {}
      try {
        const freshState = require('./state.js');
        if (this.stateStore && freshState?.HubStateStore?.prototype) {
          Object.setPrototypeOf(this.stateStore, freshState.HubStateStore.prototype);
        }
      } catch {}
      try {
        const freshStore = require('./store.js');
        if (this.store && freshStore?.AntigravityDataStore?.prototype) {
          Object.setPrototypeOf(this.store, freshStore.AntigravityDataStore.prototype);
          this.store.cachedSqliteMtimeMs = 0;
          this.store.sqliteCacheByPath?.clear?.();
          this.store.cachedClaudeVscMtimeMs = 0;
        }
      } catch {}
      try {
        const freshTabs = require('./session-tabs.js');
        if (this.tabs && freshTabs?.SessionTabManager?.prototype) {
          Object.setPrototypeOf(this.tabs, freshTabs.SessionTabManager.prototype);
        }
      } catch {}
      try {
        const freshClaudeBridge = require('./compat/claude-hub-bridge.cjs');
        freshClaudeBridge?.hotUpgradeLiveState?.();
      } catch {}
      try {
        const freshBridge = require('./compat/antigravity-hub-bridge.cjs');
        freshBridge?.hotUpgradeLiveState?.(freshBridge.getBridgeState(), vscode, this);
      } catch {}
    }
  }

  withTimeout(promise, ms, fallbackVal = null) {
    let timer = null;
    return Promise.race([
      Promise.resolve(promise).catch(() => fallbackVal),
      new Promise((resolve) => {
        timer = setTimeout(() => resolve(fallbackVal), Math.max(250, Number(ms) || 5000));
        if (typeof timer?.unref === 'function') timer.unref();
      })
    ]).finally(() => {
      if (timer) clearTimeout(timer);
    });
  }

  async refresh(options = {}) {
    if (
      !options.force &&
      !options.forceQuota &&
      this.snapshot &&
      Date.now() < Number(this._tabSwitchCooldownUntil || 0) &&
      Date.now() - Number(this.activity?.lastConversationEventAt || 0) > 250
    ) {
      const remainingMs = Math.max(120, Number(this._tabSwitchCooldownUntil || 0) - Date.now() + 40);
      await this.refreshTabStateFast({ scheduleFullRefreshMs: remainingMs });
      return;
    }
    // `prompt` marks a queued refresh that some caller other than a streaming event asked for (a phone
    // action, a sidebar command): it is never held by the activity limit below.
    if (
      options.force &&
      !options.forceQuota &&
      !options.prompt &&
      this.snapshot &&
      !this.refreshInFlight
    ) {
      // Measured from the start of the last reload, so an event that arrives while a reload runs waits at
      // most this interval plus one reload.
      const sinceLastFullMs = Date.now() - Number(this._lastFullRefreshStartedAt || this._lastFullRefreshAt || 0);
      if (sinceLastFullMs >= 0 && sinceLastFullMs < ACTIVITY_REFRESH_MIN_INTERVAL_MS) {
        this.scheduleRefresh(ACTIVITY_REFRESH_MIN_INTERVAL_MS - sinceLastFullMs + 20);
        return;
      }
    }
    if (this._scheduledRefreshTimer) {
      clearTimeout(this._scheduledRefreshTimer);
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
      this._scheduledRefreshDueAt = 0;
    }
    if (this.refreshInFlight) {
      if (Date.now() - Number(this.refreshStartedAt || 0) > 15000) {
        this.refreshInFlight = null;
      } else {
        this.pendingRefresh = {
          force: Boolean(this.pendingRefresh?.force || options.force),
          forceQuota: Boolean(this.pendingRefresh?.forceQuota || options.forceQuota),
          prompt: Boolean(this.pendingRefresh?.prompt || options.prompt || !options.force)
        };
        // Tab changes reach the sidebar through onDidChangeTabs, so this sync is only a safety net: one
        // every ACTIVITY_FAST_TAB_SYNC_MIN_INTERVAL_MS, not one full render per streaming event.
        if (
          options.force &&
          this.snapshot &&
          Date.now() - Number(this._lastFastTabSyncAt || 0) > ACTIVITY_FAST_TAB_SYNC_MIN_INTERVAL_MS
        ) {
          this.refreshTabStateFast().catch(() => {});
        }
        return this.refreshInFlight;
      }
    }
    if (options.force && this.snapshot && Date.now() - Number(this._lastFastTabSyncAt || 0) > 25) {
      await this.refreshTabStateFast();
    }
    const runToken = {};
    this._refreshToken = runToken;
    this.refreshStartedAt = Date.now();
    this.refreshInFlight = (async () => {
      try {
        if (!this.baselineInitialized) {
          this.baselineInitialized = true;
          await this.withTimeout(this.stateStore.ensureBaseline(), 3000, null);
        }
        try {
          this.hotReloadUpdatedModules();
          const directAgyBridge = require('./compat/antigravity-hub-bridge.cjs');
          directAgyBridge?.tickLiveBridgeHealth?.(this);
        } catch {}
        const persisted = this.stateStore.read();
        const preRefreshTabSeq = Number(this._tabSyncSeq || 0);
        const [snap, openTabs, agyBridgeLive, claudeBridgeLive] = await Promise.all([
          this.withTimeout(
            this.store.loadSnapshot({
              customTitles: persisted.customTitles,
              archivedIds: persisted.archivedIds,
              unarchivedAt: persisted.unarchivedAt,
              threadGroups: persisted.threadGroups,
              forceRefreshQuota: Boolean(options.forceQuota)
            }),
            10000,
            this.snapshot
          ),
          this.withTimeout(this.tabs.getOpenTabs(), 3500, this.openTabsList || []),
          this.withTimeout(
            vscode.commands.executeCommand('antigravityHub.bridgeStatus').then(
              (res) => res || { active: false },
              () => ({ active: false })
            ),
            2500,
            { active: Boolean(this.bridgeStatus?.antigravityActive) }
          ),
          this.withTimeout(
            vscode.commands.executeCommand('antigravityHub.claudeBridgeStatus').then(
              (res) => res || { active: false },
              () => ({ active: false })
            ),
            2500,
            { active: Boolean(this.bridgeStatus?.claudeActive) }
          )
        ]);

        if (snap) {
          this.snapshot = snap;
          this.activity?.reconcileSnapshot?.(snap?.threads || [], snap?.loadedAt || Date.now());
        }
        if (Number(this._tabSyncSeq || 0) === preRefreshTabSeq) {
          this.openTabsList = this.applyPendingActiveTargetToTabs(
            Array.isArray(openTabs) ? openTabs : []
          );
          this.tabs?.recordOpenTabsActivity?.(this.openTabsList);
        } else {
          const postRefreshTabSeq = Number(this._tabSyncSeq || 0);
          const latestOpenTabs = await this.withTimeout(
            this.tabs.getOpenTabs(),
            1500,
            this.openTabsList || []
          );
          if (Number(this._tabSyncSeq || 0) === postRefreshTabSeq && Array.isArray(latestOpenTabs)) {
            this.openTabsList = this.applyPendingActiveTargetToTabs(latestOpenTabs);
            this.tabs?.recordOpenTabsActivity?.(this.openTabsList);
          }
        }

        if (this.accountVault) {
          let earlyBootTimer = null;
          try {
            this.accountVault.syncActiveClaudeFromDisk(
              snap?.claudeConfigObj,
              snap?.claudeCredsObj,
              snap?.rawClaudeQuota,
              snap?.rawClaudeQuotaAt || 0
            );
            const curPrefs = this.stateStore.read()?.preferences || {};
            if (this.loading && snap) {
              earlyBootTimer = setTimeout(() => {
                earlyBootTimer = null;
                if (this.loading && this.snapshot === snap && this._refreshToken === runToken) {
                  this.loading = false;
                  this.syncOpenTabBadges();
                  this.render();
                }
              }, 350);
              if (typeof earlyBootTimer?.unref === 'function') {
                earlyBootTimer.unref();
              }
            }
            const resolvedAccounts = await this.withTimeout(
              this.accountVault.resolveAccountsSnapshot({
                nowMs: Date.now(),
                forceQuota: Boolean(options.forceQuota),
                antigravityAccount: snap?.account,
                antigravityLimits: snap?.rateLimits,
                rawAntigravityQuota: snap?.rawAntigravityQuota,
                rawActiveQuotaAt: snap?.rawAntigravityQuotaAt || 0,
                claudeAccount: snap?.claudeAccount,
                claudeLimits: snap?.claudeRateLimits,
                rawClaudeQuota: snap?.rawClaudeQuota,
                claudeRelayMerged: snap?.claudeLive?.rateLimitWindows,
                collapsedProviders: {
                  antigravity: Boolean(curPrefs.antigravityUsageCollapsed),
                  claude: Boolean(curPrefs.claudeUsageCollapsed),
                  ...(curPrefs.collapsedAccounts || {})
                }
              }),
              8500,
              null
            );
            if (resolvedAccounts) {
              this.accountsView = resolvedAccounts;
            }
          } catch {
          } finally {
            if (earlyBootTimer) {
              clearTimeout(earlyBootTimer);
              earlyBootTimer = null;
            }
          }
        }
        const agyActive = Boolean(agyBridgeLive?.active);
        const claudeActive = Boolean(claudeBridgeLive?.active);
        const anyActive = agyActive || claudeActive;
        const hideDuplicateIcon =
          typeof claudeBridgeLive?.hideDuplicateIcon === 'boolean'
            ? claudeBridgeLive.hideDuplicateIcon
            : Boolean(
                vscode.workspace
                  .getConfiguration('antigravityHub')
                  .get('hideDuplicateActivityBarIcon', true)
              );

        const report = this.bridgeInstallReport;
        const claudeSignedIn =
          typeof this.accountVault?.hasSignedInProvider === 'function'
            ? this.accountVault.hasSignedInProvider('claude')
            : report?.claudeSignedIn !== false;
        this.bridgeStatus = {
          active: anyActive,
          antigravityActive: agyActive,
          claudeActive,
          hideDuplicateIcon,
          ...describeBridgeNotice({ agyActive, claudeActive, claudeSignedIn, report })
        };
        // Skipped tweaks on the version this window loaded go to the phone too (one entry per tweak; a
        // downloaded version not loaded yet is reported once a window loads it). Hidden while signed out of
        // Claude, like the sidebar notice (describePatchSkipNotice).
        syncBridgeBlockRecord([
          ...(Array.isArray(this.bridgeStatus.attachFailures) ? this.bridgeStatus.attachFailures : []),
          ...patchSkipBlocks(this.bridgeStatus.patchSkips)
        ]);
        this.loading = false;

        // Sync Claude Code native archived sessions & groups
        if (snap?.claudeLive) {
          await this.stateStore.syncClaudeNativeState(snap.claudeLive);
        }

        // Adopt draft group assignments once a draft tab binds to a conversation ID
        await this.adoptBoundDraftGroups(this.openTabsList);
        this.updateLastActiveSessionContext(this.openTabsList);

        // Check active tab & transitions
        const activeTabs = this.openTabsList.filter((t) => t.active && t.id);
        const activeTabIds = new Set(activeTabs.map((t) => t.id));
        const openTabIds = new Set(this.openTabsList.map((t) => t?.id).filter(Boolean));
        const nowSec = Math.floor(Date.now() / 1000);
        for (const activeTab of activeTabs) {
          const activeThread = (snap.threads || []).find((t) => t.id === activeTab.id);
          await this.stateStore.markSeen(
            activeTab.id,
            Math.max(nowSec, Number(activeThread?.updatedAt) || 0),
            {
              clearUnread: true,
              contentUpdatedAt: Number(activeThread?.updatedAt || 0)
            }
          );
        }

        const latestState = this.stateStore.read();
        for (const thread of snap.threads || []) {
          const classified = this.activity.classifyThread(thread);
          const isOpenActive = activeTabIds.has(thread.id);
          if (classified.transitionedFromWorking) {
            if (isOpenActive && vscode.window.state.focused) {
              await this.stateStore.markSeen(
                thread.id,
                Math.max(nowSec, Number(thread.updatedAt) || 0),
                { clearUnread: true }
              );
            } else if (openTabIds.has(thread.id)) {
              // A session that finishes with no open tab here gets no unread mark (see render).
              await this.stateStore.setUnread(thread.id, true);
            }
            if (
              !thread.claudeDesktopScratch &&
              !(thread.claudeDesktop && latestState.preferences?.hideClaudeDesktopSessions)
            ) {
              notifySessionTransition({
                thread,
                state: classified.state,
                preferences: latestState.preferences,
                isActiveTab: isOpenActive,
                onOpenThread: (id) =>
                  this.tabs.openThread(id, {
                    provider: thread.provider || 'antigravity',
                    title: thread.title
                  })
              }).catch(() => {});
            }
          }
        }

        // Auto-archive inactive sessions (skips open, working, waiting, unread, and grouped sessions)
        if (snap) {
          await this.withTimeout(this.sweepAutoArchiveInactive(snap), 3000, 0);
          await this.withTimeout(this.sweepAutoParkIdleTabs(snap), 2500, 0);
        }
      } finally {
        if (this._refreshToken === runToken) {
          this.refreshInFlight = null;
        }
        this._lastFullRefreshAt = Date.now();
        this._lastFullRefreshStartedAt = Number(this.refreshStartedAt) || this._lastFullRefreshAt;
        this.syncOpenTabBadges();
        this.render();
        if (!this.refreshInFlight && this.pendingRefresh) {
          const nextOpts = this.pendingRefresh;
          this.pendingRefresh = null;
          this.refresh(nextOpts);
        }
      }
    })();
    return this.refreshInFlight;
  }

  buildSummaryForWindows(windowsObj) {
    const win5h = windowsObj?.['5h'] || {};
    const win7d = windowsObj?.['7d'] || {};
    const days = Array.isArray(win7d.daily)
      ? win7d.daily.map((d) => ({
          key: d.date,
          label: d.label,
          tokens: Number(d.totalTokens || 0),
          turns: Number(d.turns || 0)
        }))
      : [];

    const todayBar = days[days.length - 1] || { tokens: 0, turns: 0 };
    return {
      today: {
        sessions: Number(win5h.sessions || 0),
        turns: Math.max(Number(win5h.turns || 0), Number(todayBar.turns || 0)),
        tokens: Math.max(Number(win5h.totalTokens || 0), Number(todayBar.tokens || 0)),
        input: Number(win5h.inputTokens || 0),
        cached: Number(win5h.cachedInputTokens || 0),
        output: Number(win5h.outputTokens || 0)
      },
      week: {
        sessions: Number(win7d.sessions || 0),
        turns: Number(win7d.turns || 0),
        tokens: Number(win7d.totalTokens || 0),
        input: Number(win7d.inputTokens || 0),
        cached: Number(win7d.cachedInputTokens || 0),
        output: Number(win7d.outputTokens || 0)
      },
      days: days.length
        ? days
        : [{ key: 'Today', label: 'Today', tokens: 0, turns: 0 }]
    };
  }

  buildSummary(usage) {
    return this.buildSummaryForWindows(usage?.windows || {});
  }

  render() {
    if (this.views.size === 0 && !this.view && !this.remote) {
      return;
    }
    this._lastRenderAt = Date.now();

    const persisted = this.stateStore.read();
    const prefs = persisted.preferences || {};
    const scope = prefs.scope === 'workspace' ? 'workspace' : 'all';
    const providerFilter = ['all', 'antigravity', 'claude'].includes(prefs.providerFilter)
      ? prefs.providerFilter
      : 'all';
    const collapsed = {
      usage: Boolean(prefs.accountSectionCollapsed),
      antigravityUsage: Boolean(prefs.antigravityUsageCollapsed),
      claudeUsage: Boolean(prefs.claudeUsageCollapsed),
      accounts: prefs.collapsedAccounts && typeof prefs.collapsedAccounts === 'object'
        ? { ...prefs.collapsedAccounts }
        : {},
      questions: Boolean(prefs.questionsSectionCollapsed),
      bgTasks: Boolean(prefs.bgTasksSectionCollapsed),
      sessions: Boolean(prefs.sessionSectionCollapsed),
      ungrouped: Boolean(prefs.ungroupedCollapsed),
      archived: prefs.archivedCollapsed !== undefined ? Boolean(prefs.archivedCollapsed) : true
    };
    const rawFilterStatuses = Array.isArray(prefs.filterStatuses) ? prefs.filterStatuses : [];
    const normalizedFilterStatuses =
      rawFilterStatuses.length >= 3 ||
      (rawFilterStatuses.length === 2 &&
        rawFilterStatuses.includes('completed') &&
        rawFilterStatuses.includes('working') &&
        !rawFilterStatuses.includes('needs_input'))
        ? []
        : rawFilterStatuses;
    if (normalizedFilterStatuses.length !== rawFilterStatuses.length) {
      this.stateStore.updatePreferences({ filterStatuses: normalizedFilterStatuses }).catch(() => {});
    }
    const filter = {
      statuses: normalizedFilterStatuses,
      tabStates: Array.isArray(prefs.filterTabStates) ? prefs.filterTabStates : [],
      activeOnly: Boolean(prefs.filterActiveOnly)
    };

    const snap = this.snapshot;
    const allThreads = snap?.threads || [];
    const workspaceRoots = (vscode.workspace.workspaceFolders || []).map((f) => f.uri.fsPath);

    const inScope = (thread) => {
      if (scope !== 'workspace' || workspaceRoots.length === 0) {
        return true;
      }
      if (!thread.cwd) {
        return false;
      }
      return workspaceRoots.some((root) => isSameOrChildPath(thread.cwd, root));
    };

    const openById = new Map();
    for (const tab of this.openTabsList) {
      if (tab.id && (!openById.has(tab.id) || tab.active)) {
        openById.set(tab.id, tab);
      }
    }

    const groupIds = new Set((persisted.groups || []).map((g) => g.id));

    const scopedThreads = allThreads.filter(
      (t) => inScope(t) || openById.has(t.id) || (t.groupId && groupIds.has(t.groupId))
    );

    if (!(this.draftCreatedAt instanceof Map)) {
      this.draftCreatedAt = new Map();
    }

    const { rows } = require('./data').projectSessionRows({
      threads: scopedThreads,
      openTabs: this.openTabsList,
      persisted,
      groupIds,
      activity: this.activity,
      hasAttachedUi: true,
      resolvePinState: resolveRowPinState,
      resolveSoftLimitTokens: (_prov, model) =>
        resolveSoftAndHardContextLimits(model || '').softCompactionTargetTokens,
      formatModel: formatSessionRowModelDisplayName,
      isScratchSession: (id, prov) => prov === 'claude' && this.isScratchDesktopSession(id),
      includeTabUri: true,
      includeDraftTabs: true,
      draftCreatedAt: this.draftCreatedAt,
      draftGroups: this.draftGroups,
      sortOpenFirst: true
    });

    this.syncOpenTabBadges(persisted);

    const formatBucket = (b) => ({
      label: b.label,
      pct: b.usedPercent,
      reset: b.resetAt ? b.resetAt * 1000 : 0,
      resetText: b.resetText || '',
      expired: Boolean(b.expired ?? b.windowExpired),
      ...(b.pool ? { pool: b.pool } : {}),
      ...(b.key || b.bucketId ? { key: b.key || b.bucketId } : {})
    });

    const agyPrimaryLimits = (snap?.rateLimits?.primaryBars || []).map(formatBucket);
    const agyAllLimits = (snap?.rateLimits?.allBuckets || []).map(formatBucket);

    const claudePrimaryLimits = (snap?.claudeRateLimits?.primaryBars || []).map(formatBucket);
    const claudeAllLimits = (snap?.claudeRateLimits?.allBuckets || []).map(formatBucket);

    const agyFallbackMsg = snap?.serverConnected
      ? 'Loading quota windows…'
      : 'Waiting for Antigravity language server…';
    const claudeFallbackMsg = snap?.claudeAccount?.available
      ? 'Loading Claude quota windows…'
      : 'Sign in to Claude Code to view quota.';

    const buildAccountCardModel = (item, fallbackMsg) => {
      const provKey = item.provider === 'claude' ? 'claude' : 'antigravity';
      const pLimits = (item.rateLimits?.primaryBars || []).map(formatBucket);
      const aLimits = (item.rateLimits?.allBuckets || []).map(formatBucket);
      const prefMap =
        prefs.collapsedAccounts && typeof prefs.collapsedAccounts === 'object'
          ? prefs.collapsedAccounts
          : {};
      const isCardCollapsed =
        typeof prefMap[item.id] === 'boolean'
          ? Boolean(prefMap[item.id])
          : Boolean(item.collapsed);
      const isSignedOutItem = !item.available || Boolean(item.signedOut || item.account?.signedOut);
      return {
        id: item.id,
        provider: provKey,
        label: provKey === 'claude' ? 'Claude Code' : 'Antigravity',
        nickname: item.label || '',
        active: !isSignedOutItem && Boolean(item.active),
        hubLive: Boolean(item.hubLive),
        hubPendingCutover: Boolean(item.hubPendingCutover),
        collapsed: isCardCollapsed,
        addedAt: Number(item.addedAt || 0),
        sortOrder: Number.isFinite(Number(item.sortOrder)) ? Number(item.sortOrder) : 0,
        lastActiveAt: Number(item.lastActiveAt || 0),
        quotaUpdatedAt: Number(item.quotaUpdatedAt || snap?.loadedAt || 0),
        account: {
          name:
            item.name ||
            item.account?.name ||
            (provKey === 'claude' ? 'Claude Account' : 'Antigravity Account'),
          email: isSignedOutItem ? '' : item.email || item.account?.email || '',
          plan: isSignedOutItem
            ? ''
            : item.plan ||
              item.account?.plan ||
              (provKey === 'claude' ? 'Claude Code' : 'Google AI Pro'),
          nickname: item.label || '',
          available: !isSignedOutItem && Boolean(item.available),
          signedOut: isSignedOutItem
        },
        usage: !isSignedOutItem && pLimits.length
          ? {
              at: item.quotaUpdatedAt || snap?.loadedAt || Date.now(),
              limits: pLimits,
              allLimits: aLimits
            }
          : null,
        usageMessage: isSignedOutItem
          ? 'Not signed in.'
          : item.rateLimits?.error || fallbackMsg
      };
    };

    const agyAccountsModels = Array.isArray(this.accountsView?.antigravity) && this.accountsView.antigravity.length
      ? this.accountsView.antigravity.map((item) => buildAccountCardModel(item, agyFallbackMsg))
      : null;

    const claudeAccountsModels = Array.isArray(this.accountsView?.claude) && this.accountsView.claude.length
      ? this.accountsView.claude.map((item) => buildAccountCardModel(item, claudeFallbackMsg))
      : null;

    const agyActiveCard = agyAccountsModels?.find((a) => a.active) || agyAccountsModels?.[0] || null;
    const claudeActiveCard = claudeAccountsModels?.find((a) => a.active) || claudeAccountsModels?.[0] || null;

    const agyProviderInfo = {
      id: 'antigravity',
      label: 'Antigravity',
      account: agyActiveCard?.account || {
        name: snap?.account?.name || 'Antigravity Account',
        email: snap?.account?.email || '',
        plan: snap?.account?.plan || 'Google AI Pro',
        available: Boolean(snap?.account?.email || snap?.account?.name),
        signedOut: false
      },
      usage: agyActiveCard
        ? agyActiveCard.usage
        : agyPrimaryLimits.length
          ? {
              at: snap?.loadedAt || Date.now(),
              limits: agyPrimaryLimits,
              allLimits: agyAllLimits
            }
          : null,
      usageMessage: agyActiveCard?.usageMessage || agyFallbackMsg,
      accounts: agyAccountsModels || [
        {
          id: snap?.account?.email
            ? `antigravity:${String(snap.account.email).trim().toLowerCase()}`
            : 'antigravity:default',
          provider: 'antigravity',
          label: 'Antigravity',
          nickname: '',
          active: true,
          collapsed: Boolean(prefs.antigravityUsageCollapsed),
          account: {
            name: snap?.account?.name || 'Antigravity Account',
            email: snap?.account?.email || '',
            plan: snap?.account?.plan || 'Google AI Pro',
            nickname: '',
            available: Boolean(snap?.account?.email || snap?.account?.name),
            signedOut: false
          },
          usage: agyPrimaryLimits.length
            ? {
                at: snap?.loadedAt || Date.now(),
                limits: agyPrimaryLimits,
                allLimits: agyAllLimits
              }
            : null,
          usageMessage: agyFallbackMsg
        }
      ]
    };

    const claudeProviderInfo = {
      id: 'claude',
      label: 'Claude Code',
      account: claudeActiveCard?.account || {
        name: snap?.claudeAccount?.name || 'Claude Account',
        email: snap?.claudeAccount?.email || '',
        plan: snap?.claudeAccount?.plan || 'Claude Code',
        available: Boolean(snap?.claudeAccount?.available),
        signedOut: Boolean(snap?.claudeAccount?.signedOut)
      },
      usage: claudeActiveCard
        ? claudeActiveCard.usage
        : claudePrimaryLimits.length
          ? {
              at: snap?.loadedAt || Date.now(),
              limits: claudePrimaryLimits,
              allLimits: claudeAllLimits
            }
          : null,
      usageMessage: claudeActiveCard?.usageMessage || claudeFallbackMsg,
      accounts: claudeAccountsModels || [
        {
          id: snap?.claudeAccount?.email
            ? `claude:${String(snap.claudeAccount.email).trim().toLowerCase()}`
            : 'claude:default',
          provider: 'claude',
          label: 'Claude Code',
          nickname: '',
          active: true,
          collapsed: Boolean(prefs.claudeUsageCollapsed),
          account: {
            name: snap?.claudeAccount?.name || 'Claude Account',
            email: snap?.claudeAccount?.email || '',
            plan: snap?.claudeAccount?.plan || 'Claude Code',
            nickname: '',
            available: Boolean(snap?.claudeAccount?.available),
            signedOut: Boolean(snap?.claudeAccount?.signedOut)
          },
          usage: claudePrimaryLimits.length
            ? {
                at: snap?.loadedAt || Date.now(),
                limits: claudePrimaryLimits,
                allLimits: claudeAllLimits
              }
            : null,
          usageMessage: claudeFallbackMsg
        }
      ]
    };

    const byProviderUsage = snap?.usage?.byProvider || {};
    const summaryByProvider = {
      all: this.buildSummary(snap?.usage),
      antigravity: this.buildSummaryForWindows(byProviderUsage.antigravity || {}),
      claude: this.buildSummaryForWindows(byProviderUsage.claude || {})
    };

    const autoArchiveDays = this.getAutoArchiveInactiveDays(persisted, snap?.claudeLive);
    const hideClaudeDesktop = Boolean(prefs.hideClaudeDesktopSessions);
    let hasAgyRows = false;
    let hasClaudeRows = false;
    for (const r of rows) {
      if (r.archived) continue;
      if (hideClaudeDesktop && r.claudeDesktop && !r.open) continue;
      if (r.provider === 'claude') hasClaudeRows = true;
      else hasAgyRows = true;
    }
    const effectiveProviderFilter =
      (providerFilter === 'claude' && !hasClaudeRows) ||
      (providerFilter === 'antigravity' && !hasAgyRows)
        ? 'all'
        : providerFilter;
    if (effectiveProviderFilter !== providerFilter) {
      this.stateStore.updatePreferences({ providerFilter: effectiveProviderFilter }).catch(() => {});
    }

    // Hands-free reload (auto-reload.js) reads running turns, background tasks and scheduled work from these
    // rows. Stamped with the snapshot's own load time (a timed-out load reuses the old snapshot), so a stalled
    // store reads as unknown after 2 min. Sessions the folder filter hides from the list are added too.
    if (snap && !this.loading) {
      const threadById = new Map(allThreads.filter((t) => t && t.id).map((t) => [t.id, t]));
      const arRows = rows.map((r) => {
        const t = r && r.id ? threadById.get(r.id) : null;
        return {
          status: r.status,
          pendingQuestion: r.pendingQuestion,
          remotePeer: r.remotePeer,
          open: r.open,
          provider: r.provider,
          bgRunningCount: Math.max(Number(r.bgRunningCount || 0), Number(t?.bgRunningTotal || 0)),
          scheduledWorkUntil: Number(t?.scheduledWorkUntil || 0) * 1000
        };
      });
      const inRows = new Set(rows.map((r) => r && r.id).filter(Boolean));
      for (const t of allThreads) {
        if (!t || !t.id || inRows.has(t.id)) continue;
        const bgRun = Math.max(
          (Array.isArray(t.backgroundTasks) ? t.backgroundTasks : []).filter((x) => x && x.state === 'running').length,
          Number(t.bgRunningTotal || 0)
        );
        arRows.push({
          status: t.turnComplete === false && /RUNNING/.test(String(t.status || '')) ? 'working' : 'completed',
          pendingQuestion: t.pendingQuestion || null,
          remotePeer: Boolean(t.remotePeer || t.source === 'cloud-relay'),
          open: false,
          provider: t.provider === 'claude' ? 'claude' : 'antigravity',
          bgRunningCount: bgRun,
          scheduledWorkUntil: Number(t.scheduledWorkUntil || 0) * 1000
        });
      }
      this._autoReloadRows = arRows;
      this._autoReloadRowsAt = Number(snap.loadedAt || 0) || 0;
    }

    const curPending = this.getPendingActiveTarget();
    const pendingActiveKey =
      curPending && !curPending.confirmedInTabs
        ? curPending.id || curPending.key || null
        : null;

    const payload = {
      type: 'state',
      loading: this.loading,
      scope,
      providerFilter: effectiveProviderFilter,
      autoArchiveDays,
      hideThirdPartyQuota:
        typeof prefs.hideThirdPartyQuota === 'boolean'
          ? prefs.hideThirdPartyQuota
          : Boolean(vscode.workspace.getConfiguration('antigravityHub').get('hideThirdPartyQuota', false)),
      hideThirdPartyQuotaUpdatedAt: Number(prefs.hideThirdPartyQuotaUpdatedAt || 0),
      hideClaudeDesktop: Boolean(prefs.hideClaudeDesktopSessions),
      hideClaudeDesktopUpdatedAt: Number(prefs.hideClaudeDesktopSessionsUpdatedAt || 0),
      pendingActiveKey,
      workspace:
        vscode.workspace.name && vscode.workspace.name.toLowerCase() === 'claude'
          ? 'THEO'
          : vscode.workspace.name || 'All folders',
      account: agyProviderInfo.account,
      usage: agyProviderInfo.usage,
      usageMessage: agyProviderInfo.usageMessage,
      providers: {
        antigravity: agyProviderInfo,
        claude: claudeProviderInfo
      },
      accountOrder: Array.isArray(this.accountsView?.accountOrder)
        ? this.accountsView.accountOrder
        : [],
      pendingAccountLogin: this.accountVault?.getPendingLoginState?.() || null,
      bridge: this.bridgeStatus,
      pcSetup: typeof this.getPcSetupView === 'function' ? this.getPcSetupView() : null,
      hotSwapHold: readHotSwapHoldView(),
      autoReload: readAutoReloadView(),
      claudePermissionMode:
        this.remote && typeof this.remote.getClaudePermissionModeSnapshot === 'function'
          ? this.remote.getClaudePermissionModeSnapshot()
          : resolveSharedClaudePermissionModeInfo(),
      remote: this.remote ? this.remote.getStatus() : null,
      collapsed,
      filter,
      groups: (persisted.groups || []).map((g) => ({
        id: g.id,
        name: g.name,
        ...(g.color ? { color: g.color } : {}),
        collapsed: Boolean(g.collapsed)
      })),
      rows,
      total: scopedThreads.length,
      errors: 0,
      summary: summaryByProvider.all,
      summaryByProvider,
      prewarmTelemetry: this.buildPrewarmTelemetrySummary(),
      editGroup: this.editGroup || null
    };

    // `lastPosted = null` (set by every caller that needs a repost) always posts. Otherwise an unchanged
    // payload is skipped, and one whose only difference is a clock stamp waits for
    // HEARTBEAT_POST_MIN_INTERVAL_MS, so an idle sidebar is not sent the whole session list, and the remote
    // bridge is not woken, on every poll. The full JSON is built only for a payload that is posted.
    this._ensurePostTracking();
    const nowMs = Date.now();
    const hadLastPosted = Boolean(this.lastPosted);
    const prevStableSig = this._lastPostedStableSig;
    const prevStamps = this._lastPostedStamps;
    const sinceLastPostMs = nowMs - Number(this._lastPostedAt || 0);
    const parts = buildStablePostParts(payload);
    const hasUnseededWebview = Array.from(this.views).some(
      (v) => v?.webview && !this._webviewPostState.has(v.webview)
    );
    const hasDirtyReconcile =
      this._dirtyReconcileKeys.size > 0 || this._dirtyReconcileIds.size > 0;
    if (
      !hasUnseededWebview &&
      !hasDirtyReconcile &&
      hadLastPosted &&
      this._lastPostedStableSig &&
      parts.sig === this._lastPostedStableSig
    ) {
      if (parts.stamps === this._lastPostedStamps) {
        return;
      }
      if (sinceLastPostMs >= 0 && sinceLastPostMs < HEARTBEAT_POST_MIN_INTERVAL_MS) {
        return;
      }
    }
    const stampHeartbeatDue =
      hadLastPosted &&
      Boolean(prevStableSig) &&
      parts.sig === prevStableSig &&
      parts.stamps !== prevStamps &&
      (sinceLastPostMs < 0 || sinceLastPostMs >= HEARTBEAT_POST_MIN_INTERVAL_MS);
    this.lastPosted = JSON.stringify(payload);
    this._lastPostedObj = payload;
    this._lastPostedObjJson = this.lastPosted;
    this._lastPostedStableSig = parts.sig;
    this._lastPostedStamps = parts.stamps;
    this._lastPostedAt = nowMs;
    this.editGroup = null;

    const dirtyKeys = new Set(this._dirtyReconcileKeys);
    const dirtyIds = new Set(this._dirtyReconcileIds);
    this._dirtyReconcileKeys.clear();
    this._dirtyReconcileIds.clear();

    const activeKeys = new Set();
    for (const r of rows) {
      if (r && r.active && typeof r.key === 'string' && r.key) {
        activeKeys.add(r.key);
      }
    }
    const maxPatchRows = Math.max(40, Math.floor(parts.rowJsons.size * 0.5));

    for (const v of this.views) {
      const webview = v?.webview;
      if (!webview) continue;
      const nextSeq = Number(this._webviewPostSeq.get(webview) || 0) + 1;
      const prevView = this._webviewPostState.get(webview) || null;
      let msgToSend = null;
      if (
        !stampHeartbeatDue &&
        prevView &&
        prevView.canPatch &&
        parts.canPatch &&
        prevView.metaSig === parts.metaSig
      ) {
        const upserts = [];
        const forceActiveReconcile = !hadLastPosted;
        for (let i = 0; i < rows.length; i += 1) {
          const r = rows[i];
          const rk = r && typeof r.key === 'string' ? r.key : '';
          const rJson = parts.rowJsons.get(rk);
          const dirty =
            dirtyKeys.has(rk) ||
            (r?.id && dirtyIds.has(r.id)) ||
            (forceActiveReconcile && (r?.active || prevView.activeKeys?.has(rk)));
          if (dirty || prevView.rowJsons.get(rk) !== rJson) {
            upserts.push(r);
          }
        }
        const removedKeys = [];
        for (const prevKey of prevView.rowJsons.keys()) {
          if (!parts.rowJsons.has(prevKey)) {
            removedKeys.push(prevKey);
          }
        }
        if (upserts.length + removedKeys.length < maxPatchRows) {
          msgToSend = {
            type: 'rowPatch',
            seq: nextSeq,
            upserts,
            removedKeys,
            pendingActiveKey: payload.pendingActiveKey,
            total: payload.total,
            summary: payload.summary,
            summaryByProvider: payload.summaryByProvider,
            prewarmTelemetry: payload.prewarmTelemetry
          };
        }
      }
      if (
        !stampHeartbeatDue &&
        !hasDirtyReconcile &&
        prevView &&
        msgToSend?.type === 'rowPatch' &&
        msgToSend.upserts.length === 0 &&
        msgToSend.removedKeys.length === 0 &&
        prevView.headerSig === parts.headerSig &&
        hadLastPosted &&
        Boolean(prevStableSig) &&
        parts.sig === prevStableSig
      ) {
        continue;
      }
      if (!msgToSend) {
        msgToSend = { ...payload, seq: nextSeq };
      }
      try {
        webview.postMessage(msgToSend);
        this._webviewPostSeq.set(webview, nextSeq);
        this._webviewPostState.set(webview, {
          metaSig: parts.metaSig,
          headerSig: parts.headerSig,
          canPatch: parts.canPatch,
          rowJsons: parts.rowJsons,
          activeKeys
        });
      } catch {
        this._webviewPostState.delete(webview);
      }
    }
    if (this.remote) {
      this.remote.notifyStateUpdated?.();
    }
  }

  async handleMessage(m, meta = {}) {
    if (!m || typeof m.action !== 'string') {
      return;
    }

    // Any client action that mutates optimistic UI state or opens/focuses/closes tabs must bypass
    // lastPosted suppression on subsequent renders so authoritative server reconciliation always lands.
    if (
      [
        'open',
        'focus',
        'new',
        'newInGroup',
        'accountNewSession',
        'beside',
        'closeTab',
        'interrupt',
        'stop',
        'cancel',
        'answerQuestion',
        'cancelBgTask',
        'cancelAllBgTasks',
        'rename',
        'pin',
        'archive',
        'unread',
        'groupCreate',
        'groupRename',
        'groupDelete',
        'groupToggle',
        'groupAdd',
        'groupRemove',
        'filter',
        'providerFilter',
        'scope',
        'collapse',
        'accountCollapse',
        'autoArchiveDays',
        'archiveInactiveNow',
        'checkPcSetup',
        'applyPcSetup',
        'openPcSetupDetails',
        'setClaudePermissionMode',
        'setHideThirdPartyQuota',
        'setHideClaudeDesktop',
        'resetPrewarmTelemetry'
      ].includes(m.action)
    ) {
      this._markDirtyReconcile({ id: m.id || m.sessionId, ids: m.ids, key: m.key });
      this.lastPosted = null;
    }

    switch (m.action) {
      case 'ready':
        if (!meta?.webview) {
          this.lastPosted = null;
        }
        this._resetWebviewPostState(meta?.webview || null);
        this.render();
        return;

      case 'openRemote':
        await vscode.commands.executeCommand('antigravityHub.openRemote');
        return;

      case 'openVault':
        await vscode.env.openExternal(vscode.Uri.parse('https://memory.husseinbdeir.workers.dev/'));
        return;

      case 'new': {
        this._tabSwitchCooldownUntil = Date.now() + 550;
        const beside = Boolean(m.beside);
        const reqSeq = beside ? 0 : (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
        const newProvider = m.provider === 'claude' ? 'claude' : 'antigravity';
        const targetGroup = await this.resolveInheritedGroupForNewSession({
          explicitGroup: m.group,
          fromRemoteBridge: Boolean(m._fromRemoteBridge)
        });
        if (!beside) {
          this._pendingActiveTarget = null;
        }
        this._explicitNewSessionDepth = (this._explicitNewSessionDepth || 0) + 1;
        let openedNew = null;
        try {
          openedNew = await this.tabs.openNewSession({
            provider: newProvider,
            beside
          });
        } finally {
          this._explicitNewSessionDepth = Math.max(0, (this._explicitNewSessionDepth || 1) - 1);
        }
        if (openedNew?.uri && targetGroup) {
          this.setDraftGroup(openedNew.uri, targetGroup);
          await this.stateStore.toggleGroupCollapsed(targetGroup, false);
        }
        if (!beside && this._openReqSeq !== reqSeq) {
          return openedNew;
        }
        if (!beside && openedNew?.uri) {
          this.setPendingActiveTarget({
            key: openedNew.uri,
            provider: newProvider
          });
        }
        await this.refreshTabStateFast({
          optimisticActiveKey: beside ? '' : openedNew?.uri || '',
          forceOptimistic: !beside && Boolean(openedNew?.uri),
          scheduleFullRefreshMs: 320
        });
        return openedNew;
      }

      case 'refresh':
      case 'details':
        await this.refresh({ forceQuota: true });
        return;

      case 'resetPrewarmTelemetry':
        resetPrewarmTelemetryStore();
        if (this._prewarmedTier1StampById instanceof Map) {
          this._prewarmedTier1StampById.clear();
        }
        this.lastPosted = null;
        this.render();
        return;

      case 'checkPcSetup':
        if (typeof this.checkPcSetup === 'function') {
          await this.checkPcSetup({ force: true });
        }
        this.render();
        return;

      case 'openPcSetupDetails':
        this.openDetailsModal(true);
        return;

      case 'openHotSwapHeldFile': {
        // Opens the file that holds updates, from ~/bhfirms/theo-hub. Only a name the held record lists, and
        // only inside that folder.
        if (!meta || meta.trustedWebview !== true) return; // the sidebar only, never a relayed message
        const hold = readHotSwapHoldView();
        const rel = String(m.file || '');
        if (!hold || !rel || (rel !== hold.file && !hold.batch.includes(rel))) return;
        const repoRoot = path.join(os.homedir(), 'bhfirms', 'theo-hub');
        const target = path.resolve(repoRoot, rel);
        if (!target.startsWith(repoRoot + path.sep) || !fs.existsSync(target)) return;
        try {
          await vscode.window.showTextDocument(vscode.Uri.file(target), { preview: false });
        } catch {}
        return;
      }

      case 'applyPcSetup':
        if (meta && meta.trustedWebview === true && typeof this.applyPcSetup === 'function') {
          await this.applyPcSetup({ only: typeof m.only === 'string' ? m.only : '' });
        }
        return;

      case 'setClaudePermissionMode': {
        if (!meta || meta.trustedWebview !== true) {
          return;
        }
        const nextMode = normalizeExplicitClaudeMode(m.mode || m.defaultMode || m.value);
        if (!nextMode) {
          return;
        }
        let res = null;
        if (this.remote && typeof this.remote.setFleetClaudePermissionMode === 'function') {
          res = await this.remote.setFleetClaudePermissionMode(nextMode, {
            source: 'theo-hub',
            updatedBy: 'THEO Sidebar'
          });
        } else {
          res = writeSharedClaudePermissionMode(nextMode, {
            source: 'theo-hub',
            updatedBy: 'THEO Sidebar',
            dirtyToStore: true
          });
          vscode.commands
            .executeCommand('antigravityHub.claudeSyncPermissionMode', {
              force: true,
              resetSessionOverrides: true
            })
            .catch(() => {});
        }
        if (res && res.ok === false && res.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        } else {
          const appliedMode = normalizeExplicitClaudeMode(res?.defaultMode) || nextMode;
          const friendly =
            appliedMode === 'bypassPermissions'
              ? 'Bypass (full control)'
              : appliedMode === 'plan'
                ? 'Plan'
                : appliedMode === 'auto'
                  ? 'Auto'
                  : appliedMode;
          vscode.window.setStatusBarMessage(`THEO: Fleet Claude mode set to ${friendly}`, 3500);
        }
        this.lastPosted = null;
        this.render();
        return;
      }

      case 'reload':
        await vscode.commands.executeCommand('workbench.action.reloadWindow');
        return;

      case 'dismissAutoReloadFailure':
        try {
          require('./auto-reload').dismissCanaryFailures?.();
        } catch {}
        this.lastPosted = null;
        this.render();
        return;

      case 'repair':
        try {
          await vscode.commands.executeCommand('antigravityHub.reconnectTabs', {
            forceRender: true
          });
        } catch {}
        if (typeof this.ensureBridge === 'function') {
          await this.ensureBridge({ promptReload: true });
        }
        await this.refresh();
        return;

      case 'config':
        await vscode.commands.executeCommand(
          'workbench.action.openSettings',
          '@ext:bhfirms.antigravity-hub'
        );
        return;

      case 'settings':
        await vscode.commands.executeCommand('antigravity.openSettings');
        return;

      case 'claudeSettings':
        await vscode.commands.executeCommand(
          'workbench.action.openSettings',
          '@ext:anthropic.claude-code'
        );
        return;

      case 'toggleDuplicateIcon':
        try {
          await vscode.commands.executeCommand(
            'antigravityHub.claudeSetActivityBarVisible',
            Boolean(m.visible)
          );
        } catch {}
        await this.refresh();
        return;

      case 'testNotification':
        await notifySessionTransition({
          thread: { id: '', title: 'Sample Unified Hub Session' },
          state: 'completed',
          preferences: {
            notifyOnComplete: true,
            notifySound: true,
            onlyNotifyBackground: false
          },
          isActiveTab: false
        });
        return;

      case 'scope':
        if (m.value === 'workspace' || m.value === 'all') {
          await this.stateStore.updatePreferences({ scope: m.value });
          this.render();
        }
        return;

      case 'providerFilter':
        if (['all', 'antigravity', 'claude'].includes(m.value)) {
          await this.stateStore.updatePreferences({ providerFilter: m.value });
          this.render();
        }
        return;

      case 'autoArchiveDays': {
        const days = Number(m.value);
        if ([0, 1, 2, 7, 14].includes(days)) {
          await this.stateStore.updatePreferences({ autoArchiveInactiveDays: days });
          try {
            await vscode.workspace
              .getConfiguration('antigravityHub')
              .update('autoArchiveInactiveDays', days, vscode.ConfigurationTarget.Global);
            await vscode.workspace
              .getConfiguration('claudeCode')
              .update('archiveInactiveSessions', days, vscode.ConfigurationTarget.Global);
          } catch {}
          if (days > 0 && this.snapshot) {
            await this.sweepAutoArchiveInactive(this.snapshot, days);
          }
          this.render();
        }
        return;
      }

      case 'archiveInactiveNow': {
        const days = typeof m.days === 'number' && m.days > 0 ? m.days : 1;
        if (this.snapshot) {
          await this.sweepAutoArchiveInactive(this.snapshot, days);
          this.render();
        }
        return;
      }

      case 'setHideThirdPartyQuota': {
        const hide =
          typeof m.hide === 'boolean'
            ? m.hide
            : m.value === true || m.value === 'true' || m.value === 'hide' || m.value === 1;
        const updatedAt = Date.now();
        await this.stateStore.updatePreferences({
          hideThirdPartyQuota: hide,
          hideThirdPartyQuotaUpdatedAt: updatedAt
        });
        this._writingHideThirdPartyConfig = true;
        try {
          await vscode.workspace
            .getConfiguration('antigravityHub')
            .update('hideThirdPartyQuota', hide, vscode.ConfigurationTarget.Global);
        } catch {} finally {
          this._writingHideThirdPartyConfig = false;
        }
        this.lastPosted = null;
        this.render();
        try {
          this.remote?.notifyStateUpdated?.();
        } catch {}
        return;
      }

      case 'setHideClaudeDesktop': {
        const hide =
          typeof m.hide === 'boolean'
            ? m.hide
            : m.value === true || m.value === 'true' || m.value === 'hide' || m.value === 1;
        const updatedAt = Date.now();
        await this.stateStore.updatePreferences({
          hideClaudeDesktopSessions: hide,
          hideClaudeDesktopSessionsUpdatedAt: updatedAt
        });
        this._writingHideClaudeDesktopConfigCount =
          (this._writingHideClaudeDesktopConfigCount || 0) + 1;
        this._writingHideClaudeDesktopConfig = true;
        try {
          const cfg = vscode.workspace.getConfiguration('antigravityHub');
          const inspected = cfg.inspect?.('hideClaudeDesktopSessions');
          await cfg.update(
            'hideClaudeDesktopSessions',
            hide,
            vscode.ConfigurationTarget?.Global ?? 1
          );
          if (inspected?.workspaceValue !== undefined) {
            await cfg.update(
              'hideClaudeDesktopSessions',
              undefined,
              vscode.ConfigurationTarget?.Workspace ?? 2
            );
          }
          if (inspected?.workspaceFolderValue !== undefined) {
            await cfg.update(
              'hideClaudeDesktopSessions',
              undefined,
              vscode.ConfigurationTarget?.WorkspaceFolder ?? 3
            );
          }
        } catch {} finally {
          this._writingHideClaudeDesktopConfigCount = Math.max(
            0,
            (this._writingHideClaudeDesktopConfigCount || 1) - 1
          );
          this._writingHideClaudeDesktopConfig = this._writingHideClaudeDesktopConfigCount > 0;
        }
        this.lastPosted = null;
        this.render();
        try {
          this.remote?.notifyStateUpdated?.();
        } catch {}
        return;
      }

      case 'collapse': {
        const keyMap = {
          usage: 'accountSectionCollapsed',
          antigravityUsage: 'antigravityUsageCollapsed',
          claudeUsage: 'claudeUsageCollapsed',
          questions: 'questionsSectionCollapsed',
          bgTasks: 'bgTasksSectionCollapsed',
          sessions: 'sessionSectionCollapsed',
          ungrouped: 'ungroupedCollapsed',
          archived: 'archivedCollapsed'
        };
        const prefKey = keyMap[m.section];
        if (prefKey) {
          await this.stateStore.updatePreferences({ [prefKey]: Boolean(m.value) });
          this.render();
        }
        return;
      }

      case 'answerQuestion': {
        const sid = String(m.sessionId || m.id || '').trim();
        if (!sid) {
          await this.render();
          return;
        }
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const isSkip = Boolean(m.skipped || m.skip);
        if (this.isScratchDesktopSession(sid, thread)) {
          if (!isSkip) {
            await this.handleClaudeDesktopScratchOpen(thread || { id: sid, provider: 'claude' }, sid);
          }
          await this.render();
          return;
        }
        const selectedOptionIds = Array.isArray(m.selectedOptionIds)
          ? m.selectedOptionIds.map((x) => String(x))
          : [];
        const selectedTexts = Array.isArray(m.selectedTexts)
          ? m.selectedTexts.map((x) => String(x))
          : [];
        const writeInResponse = String(m.writeInResponse || '').trim();
        const responses = Array.isArray(m.responses) ? m.responses : [];
        if (thread) {
          thread.pendingQuestion = null;
          thread.rpcWaitingCount = 0;
          thread.status = 'CASCADE_RUN_STATUS_RUNNING';
          thread.notFullyIdle = true;
        }
        this.activity?.liveByThreadId?.delete?.(sid);
        this.lastPosted = null;
        this.syncOpenTabBadges();
        this.render();

        if (provider === 'claude') {
          const answerText = writeInResponse || selectedTexts.join(', ');
          const answersMap = {};
          for (const r of responses) {
            if (r?.question && (r.writeInResponse || (r.selectedTexts && r.selectedTexts.length))) {
              answersMap[r.question] = r.writeInResponse || r.selectedTexts.join(', ');
            }
          }
          const permPayload = {
            id: m.approvalId || thread?.pendingQuestion?.approvalId || sid,
            sessionId: sid,
            approved: !isSkip && selectedOptionIds[0] !== 'deny',
            allowAlways: selectedOptionIds[0] === 'allow_always',
            writeInResponse,
            answers: answersMap
          };
          let claudeRes = null;
          try {
            const directClaude = require('./compat/claude-hub-bridge.cjs');
            if (typeof directClaude?.respondClaudePermission === 'function') {
              claudeRes = await directClaude.respondClaudePermission(permPayload);
            }
          } catch {}
          if (!claudeRes?.resolved) {
            claudeRes = await vscode.commands
              .executeCommand('antigravityHub.claudeRespondPermission', permPayload)
              .catch(() => null);
          }
          if (!claudeRes?.resolved && !isSkip && answerText) {
            await vscode.commands
              .executeCommand('antigravityHub.claudeSendPrompt', {
                id: sid,
                prompt: answerText,
                newSession: false,
                preserveFocus: false
              })
              .catch(() => null);
          }
        } else {
          let ansRes = null;
          if (this.store?.answerAntigravityQuestion) {
            ansRes = await this.store
              .answerAntigravityQuestion(sid, {
                skipped: isSkip,
                selectedOptionIds,
                selectedTexts,
                writeInResponse,
                responses
              })
              .catch(() => null);
          }
          if (!ansRes?.ok) {
            await vscode.commands
              .executeCommand('antigravityHub.remoteAction', {
                type: 'answerQuestion',
                kind: 'answerQuestion',
                id: sid,
                approvalId: m.approvalId || sid,
                skipped: isSkip,
                selectedOptionIds,
                selectedTexts,
                writeInResponse,
                responses
              })
              .catch(() => null);
          }
        }
        setTimeout(() => this.refresh().catch(() => {}), 350);
        return;
      }

      case 'accountCollapse': {
        const accountId = String(m.accountId || m.id || '').trim();
        if (!accountId) return;
        const curState = this.stateStore.read();
        const prevMap =
          curState?.preferences?.collapsedAccounts &&
          typeof curState.preferences.collapsedAccounts === 'object'
            ? curState.preferences.collapsedAccounts
            : {};
        await this.stateStore.updatePreferences({
          collapsedAccounts: {
            ...prevMap,
            [accountId]: Boolean(m.value)
          }
        });
        this.render();
        return;
      }

      case 'accountAdd': {
        if (!this.accountVault) return;
        const res = await this.accountVault.startAddAccount({
          provider: m.provider === 'claude' ? 'claude' : 'antigravity',
          label: m.label || m.nickname || '',
          emailHint: m.emailHint || m.email || '',
          switchOnComplete: m.switchOnComplete !== false,
          vscode
        });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        }
        this.lastPosted = null;
        this.render();
        return;
      }

      case 'accountCancelAdd':
        if (this.accountVault) {
          await this.accountVault.cancelAddAccount();
          this.lastPosted = null;
          this.render();
        }
        return;

      case 'accountFocusTerminal':
        this.accountVault?.focusLoginTerminal?.();
        return;

      case 'accountContinueVerification':
        this.accountVault?.continuePendingLoginAfterVerification?.();
        this.lastPosted = null;
        this.render();
        return;

      case 'accountOpenAuthUrl':
        this.accountVault?.reopenPendingAuthOrVerificationUrl?.();
        return;

      case 'accountSwitch': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        await this.evictAllPrewarmedTabs('accountSwitch').catch(() => {});
        const res = await this.accountVault.switchActiveAccount({
          provider,
          accountId,
          vscode
        });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        } else if (res?.ok && res?.email) {
          vscode.window.setStatusBarMessage(
            `THEO: Active ${provider === 'claude' ? 'Claude Code' : 'Antigravity'} account → ${res.email}`,
            4000
          );
        }
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'accountNewSession': {
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        const beside = Boolean(m.beside);
        const reqSeq = beside ? 0 : (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
        const targetGroup = await this.resolveInheritedGroupForNewSession({
          explicitGroup: m.group,
          fromRemoteBridge: Boolean(m._fromRemoteBridge)
        });
        this._tabSwitchCooldownUntil = Date.now() + 550;
        if (!beside) {
          this._pendingActiveTarget = null;
          this.clearPendingActiveExpiryTimer();
        }
        if (accountId && this.accountVault) {
          const list =
            provider === 'claude'
              ? this.accountsView?.claude || []
              : this.accountsView?.antigravity || [];
          const target = list.find((a) => a.id === accountId);
          if (target && !target.active) {
            const sw = await this.accountVault.switchActiveAccount({
              provider,
              accountId,
              vscode
            });
            if (!sw?.ok && sw?.error) {
              vscode.window.showWarningMessage(`THEO: ${sw.error}`);
              return;
            }
          }
        }
        this._explicitNewSessionDepth = (this._explicitNewSessionDepth || 0) + 1;
        let openedAcctSession = null;
        try {
          openedAcctSession = await this.tabs.openNewSession({
            provider,
            beside
          });
        } finally {
          this._explicitNewSessionDepth = Math.max(0, (this._explicitNewSessionDepth || 1) - 1);
        }
        if (openedAcctSession?.uri && targetGroup) {
          this.setDraftGroup(openedAcctSession.uri, targetGroup);
          await this.stateStore.toggleGroupCollapsed(targetGroup, false);
        }
        if (!beside && this._openReqSeq !== reqSeq) {
          return;
        }
        if (!beside && openedAcctSession?.uri) {
          this.setPendingActiveTarget({
            key: openedAcctSession.uri,
            provider
          });
        }
        await this.refreshTabStateFast({
          optimisticActiveKey: beside ? '' : openedAcctSession?.uri || '',
          forceOptimistic: !beside && Boolean(openedAcctSession?.uri),
          scheduleFullRefreshMs: 320
        });
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'accountLabel': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        let nextLabel =
          typeof m.label === 'string'
            ? m.label
            : typeof m.name === 'string'
              ? m.name
              : null;
        if (m.prompt || nextLabel === null) {
          const list =
            provider === 'claude'
              ? this.accountsView?.claude || []
              : this.accountsView?.antigravity || [];
          const cur = list.find((a) => a.id === accountId);
          const entered = await vscode.window.showInputBox({
            title: `Nickname / Label for ${cur?.email || accountId}`,
            prompt: 'Optional friendly label (e.g., Personal, Friend, Work). Leave empty to clear.',
            value: cur?.label || ''
          });
          if (entered === undefined) return;
          nextLabel = entered;
        }
        this.accountVault.setAccountLabel({ provider, accountId, label: nextLabel });
        await this.refresh({ forceQuota: false });
        return;
      }

      case 'accountReorder': {
        if (!this.accountVault) return;
        this.accountVault.reorderAccount({
          accountId: String(m.accountId || m.id || '').trim(),
          provider: m.provider || '',
          direction: m.direction || '',
          targetAccountId: String(m.targetAccountId || '').trim(),
          position: m.position || '',
          orderedIds: Array.isArray(m.orderedIds) ? m.orderedIds : null
        });
        await this.refresh({ forceQuota: false });
        return;
      }

      case 'accountRemove': {
        if (!this.accountVault) return;
        const accountId = String(m.accountId || m.id || '').trim();
        const provider = m.provider === 'claude' ? 'claude' : 'antigravity';
        if (!accountId) return;
        const list = (
          provider === 'claude'
            ? this.accountsView?.claude || []
            : this.accountsView?.antigravity || []
        ).filter((a) => a && a.available !== false && !a.signedOut);
        const cur = list.find((a) => a.id === accountId) || list[0] || null;
        const isLastForProvider = list.length <= 1;
        const provLabel = provider === 'claude' ? 'Claude Code' : 'Antigravity';
        if (m.confirm !== false) {
          const actionBtnLabel = isLastForProvider ? 'Sign out' : 'Disconnect';
          const promptMsg = isLastForProvider
            ? `Sign out ${cur?.email || provLabel} from ${provLabel}? Your other connected accounts will remain signed in.`
            : `Disconnect ${cur?.email || accountId} from THEO? Your other connected accounts will remain signed in.`;
          const choice = await vscode.window.showWarningMessage(
            promptMsg,
            { modal: true },
            actionBtnLabel
          );
          if (choice !== actionBtnLabel) return;
        }
        await this.evictAllPrewarmedTabs('accountRemove').catch(() => {});
        const res = await this.accountVault.removeAccount({ provider, accountId, vscode });
        if (!res?.ok && res?.error) {
          vscode.window.showWarningMessage(`THEO: ${res.error}`);
        } else if (res?.ok) {
          vscode.window.setStatusBarMessage(
            `THEO: ${res.signedOutProvider ? 'Signed out' : 'Disconnected'} ${cur?.email || provLabel}`,
            4000
          );
        }
        await this.refresh({ forceQuota: true });
        return;
      }

      case 'filter':
        if (m.filter && typeof m.filter === 'object') {
          await this.stateStore.updatePreferences({
            filterStatuses: Array.isArray(m.filter.statuses) ? m.filter.statuses : [],
            filterTabStates: Array.isArray(m.filter.tabStates) ? m.filter.tabStates : [],
            filterActiveOnly: Boolean(m.filter.activeOnly)
          });
          this.render();
        }
        return;

      case 'open': {
        const openId = String(m.id || extractSessionIdFromUriOrKey(m.key) || '').trim();
        if (openId) {
          const reqSeq = (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
          this._tabSwitchCooldownUntil = Date.now() + 550;
          const thread = (this.snapshot?.threads || []).find((t) => t.id === openId);
          if (this.isScratchDesktopSession(openId, thread)) {
            await this.handleClaudeDesktopScratchOpen(
              thread || { id: openId, provider: m.provider || 'claude' },
              openId
            );
            return;
          }
          const provider = thread?.provider || m.provider || 'antigravity';
          const title = thread?.title || '';
          const pendingOpen = this.setPendingActiveTarget({
            id: openId,
            provider,
            title,
            durationMs: OPEN_PENDING_ACTIVE_MAX_MS
          });
          await this.stateStore.markSeen(
            openId,
            Math.max(Math.floor(Date.now() / 1000), Number(thread?.updatedAt) || 0),
            { clearUnread: true }
          );
          if (this._openReqSeq !== reqSeq) {
            return;
          }
          this.syncOpenTabBadges();
          this.render();
          let opened = null;
          try {
            opened = await this.tabs.openThread(openId, {
              provider,
              title
            });
          } finally {
            this.settlePendingActiveTarget(pendingOpen);
          }
          if (this._openReqSeq !== reqSeq) {
            return;
          }
          if (opened?.failed) {
            // Nothing opened: drop the 2.2 s pending highlight now and let the real tab state put the
            // highlight back where it was.
            this.clearPendingActiveTargetIfMatches({ id: openId });
            await this.refreshTabStateFast({ scheduleFullRefreshMs: 380 });
            return;
          }
          this.clearClaudeNativeUnread(thread);
          await this.refreshTabStateFast({
            optimisticActiveId: openId,
            forceOptimistic: true,
            scheduleFullRefreshMs: 380,
            onlyIfStaleOrUnknown: true
          });
        }
        return;
      }

      case 'beside': {
        const besideId = String(m.id || extractSessionIdFromUriOrKey(m.key) || '').trim();
        if (besideId) {
          this._tabSwitchCooldownUntil = Date.now() + 450;
          const thread = (this.snapshot?.threads || []).find((t) => t.id === besideId);
          if (this.isScratchDesktopSession(besideId, thread)) {
            await this.handleClaudeDesktopScratchOpen(
              thread || { id: besideId, provider: m.provider || 'claude' },
              besideId
            );
            return;
          }
          await this.tabs.openThread(besideId, {
            provider: thread?.provider || m.provider || 'antigravity',
            title: thread?.title || '',
            beside: true
          });
          await this.markThreadSeen(besideId);
          await this.refreshTabStateFast({
            scheduleFullRefreshMs: 380
          });
        }
        return;
      }

      case 'focus': {
        const focusId = String(m.id || extractSessionIdFromUriOrKey(m.key) || '').trim();
        const focusThread = focusId
          ? (this.snapshot?.threads || []).find((t) => t.id === focusId)
          : null;
        if (focusId && this.isScratchDesktopSession(focusId, focusThread)) {
          await this.handleClaudeDesktopScratchOpen(
            focusThread || { id: focusId, provider: m.provider || 'claude' },
            focusId
          );
          return;
        }
        this._tabSwitchCooldownUntil = Date.now() + 550;
        const beside = Boolean(m.beside);
        const reqSeq = beside ? 0 : (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
        let pendingFocus = null;
        if (!beside && (m.id || m.key)) {
          pendingFocus = this.setPendingActiveTarget({
            id: m.id || '',
            key: m.key || '',
            provider: m.provider || 'antigravity',
            durationMs: OPEN_PENDING_ACTIVE_MAX_MS
          });
          this.syncOpenTabBadges();
          this.render();
        }
        try {
          if (m.key) {
            await this.tabs.focusDraftTab(m.key, { beside });
          }
        } finally {
          this.settlePendingActiveTarget(pendingFocus);
        }
        if (!beside && this._openReqSeq !== reqSeq) {
          return;
        }
        if (m.id) {
          await this.markThreadSeen(m.id);
        }
        if (!beside && this._openReqSeq !== reqSeq) {
          return;
        }
        await this.refreshTabStateFast({
          optimisticActiveId: beside ? '' : m.id || '',
          optimisticActiveKey: beside ? '' : m.key || '',
          forceOptimistic: !beside && Boolean(m.id || m.key),
          scheduleFullRefreshMs: 380,
          onlyIfStaleOrUnknown: true
        });
        return;
      }

      case 'closeTab':
        this.clearPendingActiveTargetIfMatches({ id: m.id, key: m.key });
        await this.tabs.closeThreadTab(m.id, { key: m.key });
        await this.refreshTabStateFast({ scheduleFullRefreshMs: 260 });
        return;

      case 'inspectBgTask': {
        const sid = String(m.sessionId || m.id || '').trim();
        const tid = String(m.taskId || '').trim();
        if (!sid || !tid) return;
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const matched =
          (thread?.backgroundTasks || []).find((t) => t.id === tid || t.fullId === tid) ||
          m.task ||
          { id: tid, fullId: tid, kind: 'task', summary: tid, command: '', state: 'completed' };
        const output = this.store?.readBackgroundTaskOutput
          ? this.store.readBackgroundTaskOutput(sid, provider, matched, 8000)
          : matched.outputPreview || '';
        const detailPayload = {
          type: 'bgTaskDetail',
          sessionId: sid,
          sessionTitle:
            this.stateStore.read()?.customTitles?.[sid] ||
            thread?.title ||
            m.sessionTitle ||
            'Session',
          provider,
          task: {
            id: matched.id,
            fullId: matched.fullId || matched.id,
            subagentConversationId: matched.subagentConversationId || '',
            kind: matched.kind || 'task',
            subagentType: matched.subagentType || '',
            summary: matched.summary || matched.id,
            command: matched.command || '',
            state: matched.state || 'completed',
            isDaemon: Boolean(matched.isDaemon),
            startedAt:
              Number(matched.startedAt || 0) > 0 && Number(matched.startedAt || 0) < 1e12
                ? Number(matched.startedAt) * 1000
                : Number(matched.startedAt || 0),
            completedAt:
              Number(matched.completedAt || 0) > 0 && Number(matched.completedAt || 0) < 1e12
                ? Number(matched.completedAt) * 1000
                : Number(matched.completedAt || 0),
            stepIndex: typeof matched.stepIndex === 'number' ? matched.stepIndex : -1
          },
          output
        };
        for (const v of this.views) {
          try {
            v.webview.postMessage(detailPayload);
          } catch {}
        }
        return;
      }

      case 'cancelBgTask': {
        const sid = String(m.sessionId || m.id || '').trim();
        const tid = String(m.taskId || '').trim();
        if (!sid || !tid) {
          await this.render();
          return;
        }
        const thread = (this.snapshot?.threads || []).find((t) => t.id === sid);
        const provider = thread?.provider || m.provider || 'antigravity';
        const matched =
          (thread?.backgroundTasks || []).find((t) => t.id === tid || t.fullId === tid) ||
          { id: tid, fullId: tid, kind: m.kind || 'task', stepIndex: typeof m.stepIndex === 'number' ? m.stepIndex : -1 };
        if (thread && Array.isArray(thread.backgroundTasks)) {
          for (const t of thread.backgroundTasks) {
            if (t.id === tid || t.fullId === tid) {
              t.state = 'cancelled';
              t.completedAt = Math.floor(Date.now() / 1000);
            }
          }
          if (thread.bgTask && (thread.bgTask.id === tid || thread.bgTask.id === matched.id)) {
            thread.bgTask = null;
          }
        }
        this.lastPosted = null;
        this.render();
        if (this.store?.cancelBackgroundTaskOnServer) {
          await this.store.cancelBackgroundTaskOnServer(sid, provider, matched).catch(() => {});
        }
        await this.refresh();
        return;
      }

      case 'cancelAllBgTasks': {
        const filterSid = String(m.sessionId || '').trim();
        const targets = (this.snapshot?.threads || []).filter((t) =>
          filterSid ? t.id === filterSid : Array.isArray(t.backgroundTasks) && t.backgroundTasks.some((x) => x.state === 'running')
        );
        for (const thread of targets) {
          const running = (thread.backgroundTasks || []).filter((x) => x.state === 'running');
          for (const item of running) {
            item.state = 'cancelled';
            item.completedAt = Math.floor(Date.now() / 1000);
            if (this.store?.cancelBackgroundTaskOnServer) {
              await this.store
                .cancelBackgroundTaskOnServer(thread.id, thread.provider || 'antigravity', item)
                .catch(() => {});
            }
          }
          thread.bgTask = null;
        }
        this.lastPosted = null;
        this.render();
        await this.refresh();
        return;
      }

      case 'interrupt':
      case 'stop':
      case 'cancel':
        if (m.id) {
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const provider = thread?.provider || m.provider || '';
          try {
            if (provider !== 'claude') {
              this.store?.markCascadeUserCancelled?.(m.id, true);
            }
            this.activity?.liveByThreadId?.delete?.(m.id);
            if (thread) {
              thread.userCancelled = true;
              thread.status = 'CASCADE_RUN_STATUS_IDLE';
              thread.notFullyIdle = false;
              thread.bgTask = null;
            }
            await this.stateStore.setUnread(
              m.id,
              false,
              Math.max(Math.floor(Date.now() / 1000), Number(thread?.updatedAt) || 0)
            );
            this.syncOpenTabBadges();
            this.render();
          } catch {}
          if (this.remote && typeof this.remote.interruptSession === 'function') {
            await this.remote.interruptSession(m.id, provider);
          } else {
            await this.store.cancelSessionOnServer(m.id, provider).catch(() => {});
            await this.refresh();
          }
        }
        return;

      case 'rename':
        if (m.id) {
          const cleanName = String(m.name || '')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, 120);
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const provider = thread?.provider || m.provider || '';
          await this.stateStore.setCustomTitle(m.id, cleanName);
          await this.tabs.syncTabTitle(m.id, cleanName, provider);
          this.store.renameSessionOnServer(m.id, cleanName, provider).catch(() => {});
          await this.refresh();
        }
        return;

      case 'archive': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        const archived = Boolean(m.value);
        if (archived) {
          for (const cid of cleanIds) {
            this.clearPendingActiveTargetIfMatches({ id: cid });
            this.tabs?.closePrewarmedTab?.(cid, {}).catch(() => {});
          }
        }
        if (cleanIds.length > 0) {
          await this.stateStore.setArchivedMany(cleanIds, archived, {
            manualUnarchive: !archived
          });
          if (archived) {
            await this.removeSessionsFromClaudeGroups(cleanIds);
          }
          const threadsById = new Map(
            (this.snapshot?.threads || []).map((t) => [t.id, t])
          );
          const claudeIds = cleanIds.filter(
            (id) => threadsById.get(id)?.provider === 'claude' || !threadsById.has(id)
          );
          if (claudeIds.length > 0) {
            vscode.commands
              .executeCommand('antigravityHub.claudeSetArchived', {
                ids: claudeIds,
                archived
              })
              .then(
                () => {},
                () => {}
              );
          }
        }
        this.render();
        return;
      }

      case 'unread': {
        const ids = Array.isArray(m.ids) ? m.ids : [m.id];
        const nowSec = Math.floor(Date.now() / 1000);
        // Only a session open in a tab on this host can carry an unread mark (see render).
        const openTabIds = new Set((this.openTabsList || []).map((t) => t?.id).filter(Boolean));
        for (const id of ids) {
          if (id) {
            if (m.value && !openTabIds.has(id)) {
              continue;
            }
            const thread = (this.snapshot?.threads || []).find((t) => t.id === id);
            await this.stateStore.setUnread(
              id,
              Boolean(m.value),
              Math.max(nowSec, Number(thread?.updatedAt) || 0)
            );
            if (thread?.provider === 'claude') {
              try {
                await vscode.commands.executeCommand('antigravityHub.claudeSetUnread', {
                  id,
                  unread: Boolean(m.value)
                });
              } catch {}
            }
          }
        }
        this.syncOpenTabBadges();
        this.render();
        return;
      }

      case 'pin': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        const pinned = Boolean(m.value);
        const ts = Number(m.updatedAt || Date.now());
        if (cleanIds.length > 0 && typeof this.stateStore.setPinnedMany === 'function') {
          await this.stateStore.setPinnedMany(cleanIds, pinned, ts);
        }
        if (
          cleanIds.length > 0 &&
          !m._fromRemoteBridge &&
          typeof this.remote?.executeRemoteCommand === 'function'
        ) {
          const selfDevId = String(this.remote?.deviceInfo?.id || getSelfDeviceRef()?.id || '').trim();
          const threadsById = new Map((this.snapshot?.threads || []).map((t) => [t.id, t]));
          const byPeerDev = new Map();
          for (const cid of cleanIds) {
            const th = threadsById.get(cid);
            const ownerDev = String(
              (th && (th.remotePeer || th.source === 'cloud-relay') ? th.deviceId : '') ||
                (m.remotePeer ? m.deviceId : '') ||
                ''
            ).trim();
            if (ownerDev && ownerDev !== selfDevId) {
              const list = byPeerDev.get(ownerDev) || [];
              list.push(cid);
              byPeerDev.set(ownerDev, list);
            }
          }
          for (const [ownerDev, peerIds] of byPeerDev.entries()) {
            this.remote
              .executeRemoteCommand({
                type: 'sessionAction',
                action: 'pin',
                subAction: 'pin',
                id: peerIds[0],
                threadId: peerIds[0],
                ids: peerIds,
                value: pinned,
                updatedAt: ts,
                targetDeviceId: ownerDev
              })
              .catch(() => {});
          }
        }
        this.lastPosted = null;
        this.render();
        try {
          this.remote?.notifyStateUpdated?.();
        } catch {}
        return;
      }

      case 'groupCreate': {
        const cleanGrpName = String(m.name || '').replace(/\s+/g, ' ').trim();
        const grp = await this.stateStore.createGroup(
          cleanGrpName || 'New group',
          '',
          String(m.group || '').trim()
        );
        if (grp) {
          const ids = Array.isArray(m.ids) ? m.ids : m.id ? [m.id] : [];
          for (const id of ids) {
            if (id) {
              await this.stateStore.assignThreadGroup(id, grp.id);
            }
          }
          if (!cleanGrpName) {
            this.editGroup = grp.id;
          }
          this.render();
        }
        return;
      }

      case 'newInGroup':
        if (m.group) {
          this._tabSwitchCooldownUntil = Date.now() + 550;
          const reqSeq = (this._openReqSeq = Number(this._openReqSeq || 0) + 1);
          const newProvider = m.provider === 'claude' ? 'claude' : 'antigravity';
          this._pendingActiveTarget = null;
          this.clearPendingActiveExpiryTimer();
          this._explicitNewSessionDepth = (this._explicitNewSessionDepth || 0) + 1;
          let opened = null;
          try {
            opened = await this.tabs.openNewSession({
              provider: newProvider
            });
          } finally {
            this._explicitNewSessionDepth = Math.max(0, (this._explicitNewSessionDepth || 1) - 1);
          }
          if (opened?.uri) {
            this.setDraftGroup(opened.uri, m.group);
          }
          await this.stateStore.toggleGroupCollapsed(m.group, false);
          if (this._openReqSeq !== reqSeq) {
            return;
          }
          if (opened?.uri) {
            this.setPendingActiveTarget({
              key: opened.uri,
              provider: newProvider
            });
          }
          await this.refreshTabStateFast({
            optimisticActiveKey: opened?.uri || '',
            forceOptimistic: Boolean(opened?.uri),
            scheduleFullRefreshMs: 320
          });
        }
        return;

      case 'groupRename':
        if (m.group && m.name) {
          await this.stateStore.renameGroup(m.group, m.name);
          this.render();
        }
        return;

      case 'groupDelete':
        if (m.group) {
          const curState = this.stateStore.read();
          const victim = (curState.groups || []).find((g) => g.id === m.group);
          const memberIds = Object.entries(curState.threadGroups || {})
            .filter(([, gid]) => gid === m.group)
            .map(([tid]) => tid);
          if (this.draftGroups instanceof Map) {
            for (const [draftUri, draftGid] of Array.from(this.draftGroups.entries())) {
              if (draftGid === m.group) {
                this.draftGroups.delete(draftUri);
              }
            }
          }
          if (this._lastActiveSessionTab?.group === m.group) {
            this._lastActiveSessionTab.group = '';
          }
          if (this._prevActiveSessionTab?.group === m.group) {
            this._prevActiveSessionTab.group = '';
          }
          await this.stateStore.deleteGroup(m.group);
          if (memberIds.length > 0) {
            await this.removeSessionsFromClaudeGroups(memberIds, m.group);
          }
          // Also purge the group from the native Claude Code extension's per-workspace
          // `sessionGroups:*` storage so it cannot be re-imported later.
          try {
            await vscode.commands.executeCommand('antigravityHub.claudeDeleteGroup', {
              id: m.group,
              name: victim?.name || ''
            });
          } catch {}
          this.render();
        }
        return;

      case 'groupToggle':
        if (m.group) {
          await this.stateStore.toggleGroupCollapsed(m.group, Boolean(m.value));
          this.render();
        }
        return;

      case 'groupAdd': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        if (cleanIds.length > 0 && m.group) {
          if (typeof this.stateStore.assignThreadGroupsMany === 'function') {
            await this.stateStore.assignThreadGroupsMany(cleanIds, m.group);
          } else {
            for (const id of cleanIds) {
              await this.stateStore.assignThreadGroup(id, m.group);
            }
          }
          if (this.store?.removedClaudeGroupSessionIds instanceof Set) {
            for (const id of cleanIds) {
              this.store.removedClaudeGroupSessionIds.delete(id);
            }
          }
        } else if (m.key && m.group) {
          this.setDraftGroup(m.key, m.group);
          await this.stateStore.toggleGroupCollapsed(m.group, false);
        }
        this.render();
        return;
      }

      case 'groupRemove': {
        const rawIds = Array.isArray(m.ids) ? m.ids : [m.id];
        const cleanIds = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
        if (cleanIds.length > 0) {
          if (typeof this.stateStore.assignThreadGroupsMany === 'function') {
            await this.stateStore.assignThreadGroupsMany(cleanIds, '');
          } else {
            for (const id of cleanIds) {
              await this.stateStore.assignThreadGroup(id, '');
            }
          }
          await this.removeSessionsFromClaudeGroups(cleanIds, String(m.group || '').trim());
        } else if (m.key) {
          this.setDraftGroup(m.key, '');
        }
        this.render();
        return;
      }

      case 'copy':
        if (m.id) {
          await vscode.env.clipboard.writeText(m.id);
          vscode.window.setStatusBarMessage(`Copied session ID: ${m.id}`, 2500);
        }
        return;

      case 'reveal':
        if (m.id) {
          const thread = (this.snapshot?.threads || []).find((t) => t.id === m.id);
          const logPath = this.store.getTranscriptLogPath(m.id, thread?.provider || m.provider || '');
          if (logPath && fs.existsSync(logPath)) {
            const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(logPath));
            await vscode.window.showTextDocument(doc, { preview: true });
          } else {
            vscode.window.showInformationMessage('No local transcript log found for this session yet.');
          }
        }
        return;
    }
  }

  async removeSessionsFromClaudeGroups(ids = [], groupId = '') {
    const cleanIds = (Array.isArray(ids) ? ids : [ids])
      .map((x) => String(x || '').trim())
      .filter(Boolean);
    if (cleanIds.length === 0) {
      return;
    }
    const rmSet = new Set(cleanIds);
    try {
      this.store?.noteRemovedClaudeGroupSessions?.(cleanIds);
    } catch {}
    try {
      if (Array.isArray(this.snapshot?.claudeLive?.sessionGroups)) {
        for (const g of this.snapshot.claudeLive.sessionGroups) {
          if (g && Array.isArray(g.sessionIds) && (!groupId || g.id === groupId)) {
            g.sessionIds = g.sessionIds.filter((sid) => !rmSet.has(String(sid || '').trim()));
          }
        }
      }
      if (Array.isArray(this.snapshot?.threads)) {
        for (const t of this.snapshot.threads) {
          if (t && rmSet.has(t.id) && (!groupId || t.groupId === groupId)) {
            t.groupId = '';
          }
        }
      }
    } catch {}
    try {
      const directBridge = require('./compat/claude-hub-bridge.cjs');
      if (typeof directBridge?.removeSessionsFromClaudeGroups === 'function') {
        await directBridge.removeSessionsFromClaudeGroups(directBridge.getBridgeState?.(), {
          ids: cleanIds,
          group: groupId
        });
      }
    } catch {}
    try {
      await vscode.commands.executeCommand('antigravityHub.claudeRemoveFromGroup', {
        ids: cleanIds,
        group: groupId
      });
    } catch {}
  }

  _ensurePrewarmTracking() {
    if (!(this._prewarmDismissedIds instanceof Set)) {
      this._prewarmDismissedIds = new Set();
    }
    if (!(this._prewarmCooldownUntilById instanceof Map)) {
      this._prewarmCooldownUntilById = new Map();
    }
    if (!(this._prewarmedTier1StampById instanceof Map)) {
      this._prewarmedTier1StampById = new Map();
    }
    if (!(this._remotePrewarmHintsById instanceof Map)) {
      this._remotePrewarmHintsById = new Map();
    }
    if (!Number.isFinite(this._lastUserOrTabActivityAt) || this._lastUserOrTabActivityAt <= 0) {
      this._lastUserOrTabActivityAt = Date.now();
    }
  }

  _pruneRemotePrewarmHints(now = Date.now()) {
    this._ensurePrewarmTracking();
    const ts = Number.isFinite(now) && now > 0 ? now : Date.now();
    for (const [id, entry] of this._remotePrewarmHintsById.entries()) {
      if (!entry || Number(entry.expiresAt || 0) <= ts) {
        this._remotePrewarmHintsById.delete(id);
      }
    }
    while (this._remotePrewarmHintsById.size > 16) {
      const oldestKey = this._remotePrewarmHintsById.keys().next().value;
      if (oldestKey === undefined) break;
      this._remotePrewarmHintsById.delete(oldestKey);
    }
  }

  _countActiveRemoteHints(now = Date.now()) {
    this._pruneRemotePrewarmHints(now);
    return this._remotePrewarmHintsById.size;
  }

  getEffectiveFreeMemBytes(now = Date.now()) {
    if (typeof this._freeMemOverrideBytes === 'number' && Number.isFinite(this._freeMemOverrideBytes)) {
      return Math.max(0, this._freeMemOverrideBytes);
    }
    if (process.env.THEO_SMOKE_TEST === '1') {
      return 4 * 1024 * 1024 * 1024;
    }
    const ts = Number.isFinite(now) && now > 0 ? now : Date.now();
    if (
      this._cachedFreeMem &&
      ts - Number(this._cachedFreeMem.at || 0) < PREWARM_MEM_CACHE_TTL_MS
    ) {
      return this._cachedFreeMem.bytes;
    }
    let bytes = 4 * 1024 * 1024 * 1024;
    try {
      const free = os.freemem();
      if (typeof free === 'number' && Number.isFinite(free) && free >= 0) {
        bytes = free;
      }
    } catch {}
    this._cachedFreeMem = { bytes, at: ts };
    return bytes;
  }

  getAdaptivePrewarmPolicy(now = Date.now(), opts = {}) {
    const st = ensurePrewarmTelemetryStore();
    const freeMemBytes =
      typeof opts.freeMemBytes === 'number' && Number.isFinite(opts.freeMemBytes)
        ? Math.max(0, opts.freeMemBytes)
        : this.getEffectiveFreeMemBytes(now);
    const limits = computeAdaptivePrewarmLimits({
      hits: st.hits,
      coldOpens: st.coldOpens,
      evictions: st.evictions,
      freeMemBytes
    });
    return {
      ...limits,
      freeMemBytes,
      freeMemMb: Math.round(freeMemBytes / 1048576)
    };
  }

  noteActiveEditorContext(editorOrUri, now = Date.now()) {
    const uri = editorOrUri?.document?.uri || editorOrUri?.uri || editorOrUri || null;
    const scheme = String(uri?.scheme || '');
    const fsPath = scheme === 'file' ? String(uri?.fsPath || '').trim() : '';
    if (!fsPath) return null;
    const folderPath = path.dirname(fsPath);
    const gitInfo = resolveGitRepoAndBranchFast(fsPath, now);
    this._activeEditorContext = {
      fsPath,
      folderPath,
      repoRoot: gitInfo.repoRoot || '',
      commonRepoRoot: gitInfo.commonRepoRoot || gitInfo.repoRoot || '',
      branch: gitInfo.branch || '',
      updatedAt: Number.isFinite(now) && now > 0 ? now : Date.now()
    };
    this.notePrewarmActivity('editor', this._activeEditorContext.updatedAt);
    return this._activeEditorContext;
  }

  getPrewarmAffinityContext(now = Date.now(), openTabs = this.openTabsList) {
    const nowMs = normalizePrewarmSortMs(now) || Date.now();
    let folderPath = '';
    let repoRoot = '';
    let commonRepoRoot = '';
    let branch = '';
    const secondarySet = new Set();

    const liveEditorUri = vscode.window?.activeTextEditor?.document?.uri;
    const liveEditorPath =
      liveEditorUri && liveEditorUri.scheme === 'file' ? String(liveEditorUri.fsPath || '').trim() : '';
    if (liveEditorPath) {
      folderPath = path.dirname(liveEditorPath);
      const gitInfo = resolveGitRepoAndBranchFast(liveEditorPath, nowMs);
      repoRoot = gitInfo.repoRoot || '';
      commonRepoRoot = gitInfo.commonRepoRoot || repoRoot;
      branch = gitInfo.branch || '';
    } else if (
      this._activeEditorContext &&
      nowMs - Number(this._activeEditorContext.updatedAt || 0) <= AFFINITY_EDITOR_RECENT_MAX_AGE_MS
    ) {
      folderPath = this._activeEditorContext.folderPath || '';
      const freshTarget = this._activeEditorContext.fsPath || folderPath;
      const freshGit = freshTarget ? resolveGitRepoAndBranchFast(freshTarget, nowMs) : null;
      repoRoot = (freshGit && freshGit.repoRoot) || this._activeEditorContext.repoRoot || '';
      commonRepoRoot =
        (freshGit && freshGit.commonRepoRoot) ||
        this._activeEditorContext.commonRepoRoot ||
        repoRoot;
      branch = freshGit ? freshGit.branch || '' : this._activeEditorContext.branch || '';
    } else {
      const activeTabInput = vscode.window?.tabGroups?.activeTabGroup?.activeTab?.input;
      const tabUri = activeTabInput?.uri || activeTabInput?.modified || null;
      const tabFsPath = tabUri && tabUri.scheme === 'file' ? String(tabUri.fsPath || '').trim() : '';
      if (tabFsPath) {
        folderPath = path.dirname(tabFsPath);
        const gitInfo = resolveGitRepoAndBranchFast(tabFsPath, nowMs);
        repoRoot = gitInfo.repoRoot || '';
        commonRepoRoot = gitInfo.commonRepoRoot || repoRoot;
        branch = gitInfo.branch || '';
      }
    }

    const activeOpenTab = Array.isArray(openTabs) ? openTabs.find((t) => t && t.active && t.id) : null;
    if (activeOpenTab && Array.isArray(this.snapshot?.threads)) {
      const activeThread = this.snapshot.threads.find((t) => t && t.id === activeOpenTab.id);
      if (activeThread) {
        const tCwd = String(activeThread.cwd || '').trim();
        const tGit = tCwd ? resolveGitRepoAndBranchFast(tCwd, nowMs) : { repoRoot: '', commonRepoRoot: '', branch: '' };
        const tBranch = String(activeThread.branch || '').trim() || tGit.branch || '';
        if (!folderPath && tCwd) {
          folderPath = tCwd;
          repoRoot = tGit.repoRoot || '';
          commonRepoRoot = tGit.commonRepoRoot || repoRoot;
          branch = tBranch;
        } else if (tCwd) {
          secondarySet.add(tCwd);
        }
        if (!branch && tBranch && (!tCwd || !folderPath || isSameOrChildAffinityPath(tCwd, repoRoot || folderPath))) {
          branch = tBranch;
        }
      }
    }

    const wsFolders = Array.isArray(vscode.workspace?.workspaceFolders) ? vscode.workspace.workspaceFolders : [];
    for (const wf of wsFolders) {
      const wfPath = String(wf?.uri?.fsPath || '').trim();
      if (!wfPath) continue;
      if (!folderPath) {
        folderPath = wfPath;
        const gitInfo = resolveGitRepoAndBranchFast(wfPath, nowMs);
        repoRoot = gitInfo.repoRoot || '';
        commonRepoRoot = gitInfo.commonRepoRoot || repoRoot;
        if (!branch) branch = gitInfo.branch || '';
      } else if (!isSameOrChildAffinityPath(folderPath, wfPath) && !isSameOrChildAffinityPath(wfPath, folderPath)) {
        secondarySet.add(wfPath);
      }
    }

    return {
      folderPath,
      repoRoot,
      commonRepoRoot,
      branch,
      secondaryFolders: Array.from(secondarySet)
    };
  }

  buildPrewarmTelemetrySummary() {
    const st = ensurePrewarmTelemetryStore();
    const now = Date.now();
    const policy = this.getAdaptivePrewarmPolicy(now);
    const hits = Number(st.hits || 0);
    const coldOpens = Number(st.coldOpens || 0);
    const prewarmedOpens = Number(st.prewarmedOpens || 0);
    const evictions = Number(st.evictions || 0);
    const totalAttempts = hits + coldOpens;
    let activeBranch = '';
    let activeRepo = '';
    try {
      const aff = this.getPrewarmAffinityContext(now, this.openTabsList);
      activeBranch = String(aff?.branch || '');
      activeRepo = aff?.repoRoot
        ? path.basename(aff.repoRoot)
        : aff?.folderPath
          ? path.basename(aff.folderPath)
          : '';
    } catch {}
    return {
      startedAt: Number(st.startedAt || 0),
      tier1Passes: Number(st.tier1Passes || 0),
      prewarmedOpens,
      hits,
      coldOpens,
      evictions,
      remoteHints: Number(st.remoteHints || 0),
      activeRemoteHints: this._countActiveRemoteHints(now),
      hitRatePct: totalAttempts > 0 ? Math.round((hits / totalAttempts) * 100) : null,
      avgWarmAgeMs: hits > 0 ? Math.round(Number(st.totalWarmHitAgeMs || 0) / hits) : null,
      warmNow: Math.min(MAX_PREWARMED_TABS_CEILING, Math.max(0, prewarmedOpens - hits - evictions)),
      maxWarmTabs: policy.maxWarmTabs,
      adaptiveMode: policy.adaptiveMode,
      adaptiveLabel: policy.adaptiveLabel,
      freeMemMb: policy.freeMemMb,
      tier1IdleMs: PREWARM_TIER1_IDLE_MS,
      tier2IdleMs: policy.tier2IdleMs,
      osIdleMinMs: policy.osIdleMinMs,
      tier2SystemIdleSec: Math.round(policy.osIdleMinMs / 1000),
      activeBranch,
      activeRepo,
      byProvider: {
        antigravity: { ...(st.byProvider?.antigravity || { prewarmedOpens: 0, hits: 0, coldOpens: 0, evictions: 0 }) },
        claude: { ...(st.byProvider?.claude || { prewarmedOpens: 0, hits: 0, coldOpens: 0, evictions: 0 }) }
      }
    };
  }

  notePrewarmActivity(kind = 'activity', atMs = Date.now()) {
    this._ensurePrewarmTracking();
    if (kind !== 'blur') {
      this._lastUserOrTabActivityAt = Number.isFinite(atMs) && atMs > 0 ? atMs : Date.now();
    }
    this.scheduleIdlePrewarmCheck();
  }

  noteRemotePrewarmHint({ id, provider = '', source = 'remote', now = Date.now() } = {}) {
    const cleanId = String(id || '')
      .trim()
      .replace(/^(?:antigravity|claude):/, '');
    if (
      !cleanId ||
      cleanId === '__new__' ||
      cleanId === '__new_claude__' ||
      cleanId.startsWith('cmd-') ||
      cleanId.startsWith('draft-') ||
      !/^[A-Za-z0-9._:-]{1,160}$/.test(cleanId)
    ) {
      return false;
    }
    const ts = Number.isFinite(now) && now > 0 ? now : Date.now();
    this._ensurePrewarmTracking();
    this._pruneRemotePrewarmHints(ts);
    this._prewarmDismissedIds.delete(cleanId);
    this._prewarmCooldownUntilById.delete(cleanId);
    this._remotePrewarmHintsById.set(cleanId, {
      id: cleanId,
      provider: provider === 'claude' ? 'claude' : provider === 'antigravity' ? 'antigravity' : '',
      source: String(source || 'remote').trim().slice(0, 32),
      at: ts,
      expiresAt: ts + PREWARM_REMOTE_HINT_TTL_MS
    });
    while (this._remotePrewarmHintsById.size > 16) {
      const oldestKey = this._remotePrewarmHintsById.keys().next().value;
      if (oldestKey === undefined) break;
      this._remotePrewarmHintsById.delete(oldestKey);
    }
    ensurePrewarmTelemetryStore().remoteHints += 1;
    const policy = this.getAdaptivePrewarmPolicy(ts);
    const quietMs = Math.max(0, ts - Number(this._lastUserOrTabActivityAt || ts));
    if (quietMs >= policy.tier2IdleMs) {
      this.scheduleIdlePrewarmCheck(120);
    } else {
      this.scheduleIdlePrewarmCheck();
    }
    return true;
  }

  notePrewarmDismissed(id, now = Date.now()) {
    const cleanId = String(id || '')
      .trim()
      .replace(/^(?:antigravity|claude):/, '');
    if (!cleanId) return;
    this._ensurePrewarmTracking();
    const untilAt = (Number.isFinite(now) && now > 0 ? now : Date.now()) + PREWARM_RETRY_COOLDOWN_MS;
    this._prewarmDismissedIds.add(cleanId);
    this._prewarmCooldownUntilById.set(cleanId, untilAt);
  }

  notePrewarmPromoted(id) {
    const cleanId = String(id || '')
      .trim()
      .replace(/^(?:antigravity|claude):/, '');
    if (!cleanId) return;
    this._ensurePrewarmTracking();
    this._prewarmCooldownUntilById.delete(cleanId);
    this._prewarmDismissedIds.delete(cleanId);
  }

  selectPrewarmCandidates({
    now = Date.now(),
    openTabs = this.openTabsList,
    persisted = null,
    affinityContext = null,
    limit = null
  } = {}) {
    this._ensurePrewarmTracking();
    this._pruneRemotePrewarmHints(now);
    const effectiveLimit =
      typeof limit === 'number' && Number.isFinite(limit)
        ? Math.max(0, Math.min(MAX_PREWARMED_TABS_CEILING, Math.floor(limit)))
        : this.getAdaptivePrewarmPolicy(now).maxWarmTabs;
    if (effectiveLimit <= 0) {
      return [];
    }
    const threads = Array.isArray(this.snapshot?.threads) ? this.snapshot.threads : [];
    if (threads.length === 0) {
      return [];
    }
    const resolvedAffinity = affinityContext || this.getPrewarmAffinityContext(now, openTabs);
    const storeState = persisted || this.stateStore?.read?.() || {};
    const archivedSet = new Set(storeState.archivedIds || []);
    const openIds = new Set();
    const openKeys = new Set();
    for (const tab of Array.isArray(openTabs) ? openTabs : []) {
      if (!tab) continue;
      if (tab.id) openIds.add(String(tab.id).trim());
      if (tab.uri) openKeys.add(String(tab.uri).trim());
    }
    const out = [];
    for (const thread of threads) {
      if (!thread || !thread.id) continue;
      if (thread.remotePeer || thread.source === 'cloud-relay') continue;
      const cid = String(thread.id).trim();
      if (!cid || archivedSet.has(cid)) continue;
      if (openIds.has(cid) || (thread.uri && openKeys.has(String(thread.uri).trim()))) continue;
      if (this.isScratchDesktopSession(cid, thread)) continue;
      if (this._prewarmDismissedIds.has(cid)) continue;
      if (Number(this._prewarmCooldownUntilById.get(cid) || 0) > now) continue;
      const classified = this.activity?.classifyThread?.(thread, { recordTransition: false }) || {};
      if (classified.state === 'waiting' || classified.state === 'thinking') continue;
      const unreadIds = Array.isArray(storeState?.unreadIds) ? storeState.unreadIds : [];
      if (unreadIds.includes(cid) || Boolean(thread.claudeUnread)) continue;
      const sortAt = Number(thread.updatedAt || thread.at || 0);
      const sortAtMs = normalizePrewarmSortMs(sortAt);
      const affinity = computePrewarmAffinityBoost({
        thread,
        affinityContext: resolvedAffinity,
        now,
        sortAtMs
      });
      let totalBoostMs = affinity.boostMs;
      const reasons = affinity.reasons.slice();
      const rHint = this._remotePrewarmHintsById.get(cid);
      if (rHint && Number(rHint.expiresAt || 0) > now) {
        const recencyTieBreak = Math.max(
          0,
          Math.min(PREWARM_REMOTE_HINT_TTL_MS, Number(rHint.at || now) - (now - PREWARM_REMOTE_HINT_TTL_MS))
        );
        totalBoostMs += AFFINITY_BOOST_REMOTE_HINT_MS + recencyTieBreak;
        reasons.unshift('remote-focus');
      }
      out.push({
        id: cid,
        provider: thread.provider === 'claude' ? 'claude' : 'antigravity',
        title: thread.title || '',
        sortAt,
        sortAtMs,
        affinityBoostMs: totalBoostMs,
        scoreMs: sortAtMs + totalBoostMs,
        affinityReasons: reasons
      });
    }
    out.sort((a, b) => b.scoreMs - a.scoreMs || b.sortAtMs - a.sortAtMs || b.sortAt - a.sortAt);
    return out.slice(0, effectiveLimit);
  }

  async evictAllPrewarmedTabs(reason = 'evict') {
    if (!this.tabs || typeof this.tabs.getPrewarmedTabs !== 'function') {
      return 0;
    }
    const existing = await this.tabs.getPrewarmedTabs().catch(() => []);
    let closedCount = 0;
    for (const item of Array.isArray(existing) ? existing : []) {
      if (!item || !item.id) continue;
      const ok = await this.tabs
        .closePrewarmedTab(item.id, { provider: item.provider, uri: item.uri, reason })
        .catch(() => false);
      if (ok) closedCount += 1;
    }
    return closedCount;
  }

  scheduleIdlePrewarmCheck(delayMs = null) {
    if (process.env.THEO_SMOKE_TEST === '1' || process.env.THEO_DISABLE_PREWARM === '1') {
      return;
    }
    this._ensurePrewarmTracking();
    if (this._idlePrewarmTimer) {
      clearTimeout(this._idlePrewarmTimer);
      this._idlePrewarmTimer = null;
    }
    const now = Date.now();
    const policy = this.getAdaptivePrewarmPolicy(now);
    const quietMs = Math.max(0, now - Number(this._lastUserOrTabActivityAt || now));
    const waitMs =
      typeof delayMs === 'number' && delayMs >= 0
        ? delayMs
        : quietMs < PREWARM_TIER1_IDLE_MS
          ? PREWARM_TIER1_IDLE_MS - quietMs + 50
          : quietMs < policy.tier2IdleMs
            ? policy.tier2IdleMs - quietMs + 50
            : 250;
    this._idlePrewarmTimer = setTimeout(() => {
      this._idlePrewarmTimer = null;
      this.runIdlePrewarmPass().catch(() => {});
    }, waitMs);
    if (typeof this._idlePrewarmTimer?.unref === 'function') {
      this._idlePrewarmTimer.unref();
    }
  }

  async runIdlePrewarmPass(opts = {}) {
    if (
      !opts.force &&
      (process.env.THEO_SMOKE_TEST === '1' || process.env.THEO_DISABLE_PREWARM === '1')
    ) {
      return { ok: false, skipped: 'disabled' };
    }
    if (this._prewarmPassInFlight) {
      return this._prewarmPassInFlight;
    }
    let settled = false;
    let passPromise = null;
    passPromise = (async () => {
      try {
        this._ensurePrewarmTracking();
        if (this.accountVault?.getPendingLoginState?.()?.inProgress) {
          return { ok: false, skipped: 'login_in_progress' };
        }
        const now = Number(opts.now || Date.now());
        const quietMs = Math.max(0, now - Number(this._lastUserOrTabActivityAt || now));
        const policy = this.getAdaptivePrewarmPolicy(now, { freeMemBytes: opts.freeMemBytes });
        const maxWarmTabs = policy.maxWarmTabs;
        const candidates =
          maxWarmTabs > 0 ? this.selectPrewarmCandidates({ now, limit: maxWarmTabs }) : [];

        // Tier 1 (safe anytime after 4.5s quiet, zero new tabs): hydrate deferred background tabs
        // and warm head steps for top non-open Antigravity sessions (skipped under critical RAM pressure).
        let telemetryDirty = false;
        if (policy.adaptiveMode !== 'mem_critical' && (quietMs >= PREWARM_TIER1_IDLE_MS || opts.forceTier1)) {
          const tier1Limit = Math.max(2, maxWarmTabs);
          const tier1Candidates =
            candidates.length >= tier1Limit
              ? candidates
              : this.selectPrewarmCandidates({ now, limit: tier1Limit });
          const agyCandidates = tier1Candidates.filter((c) => c.provider === 'antigravity');
          const agyIds = agyCandidates.map((c) => c.id);
          const tier1Key = agyIds.join(',');
          if (
            this.tabs?.warmRecentSessions &&
            (opts.force ||
              tier1Key !== this._lastTier1WarmKey ||
              now - Number(this._lastTier1WarmAt || 0) >= 30000)
          ) {
            this._lastTier1WarmKey = tier1Key;
            this._lastTier1WarmAt = now;
            let hasNewTier1Candidate = false;
            for (const c of agyCandidates) {
              if (!c || !c.id) continue;
              const stamp = Number(c.sortAtMs || c.sortAt || 0);
              if (this._prewarmedTier1StampById.get(c.id) !== stamp) {
                hasNewTier1Candidate = true;
                this._prewarmedTier1StampById.set(c.id, stamp);
              }
            }
            while (this._prewarmedTier1StampById.size > 200) {
              const oldestKey = this._prewarmedTier1StampById.keys().next().value;
              if (oldestKey === undefined) break;
              this._prewarmedTier1StampById.delete(oldestKey);
            }
            let tier1Succeeded = false;
            try {
              await this.tabs.warmRecentSessions(agyIds, { maxDeferred: tier1Limit });
              tier1Succeeded = true;
            } catch {}
            if (tier1Succeeded && hasNewTier1Candidate) {
              ensurePrewarmTelemetryStore().tier1Passes += 1;
              telemetryDirty = true;
            }
          }
        }

        // Critical RAM pressure immediately releases existing prewarmed panels before waiting for Tier-2 idle.
        if (maxWarmTabs === 0) {
          const evictedAll = await this.evictAllPrewarmedTabs('mem_critical').catch(() => 0);
          if (evictedAll > 0 || telemetryDirty) {
            if (typeof this.render === 'function') {
              try { this.render(); } catch {}
            }
          }
          return {
            ok: true,
            tier: policy.adaptiveMode,
            opened: 0,
            evicted: evictedAll,
            candidates: 0,
            maxWarmTabs: 0
          };
        }

        // If adaptive maxWarmTabs shrank (e.g. 3 -> 1 under mem_pressure or low_hit_backoff), evict surplus
        // prewarmed tabs immediately even while VS Code is active instead of leaving them resident in RAM.
        let earlyEvicted = 0;
        const preGateWarm = (await this.tabs?.getPrewarmedTabs?.().catch(() => [])) || [];
        if (Array.isArray(preGateWarm) && preGateWarm.length > maxWarmTabs) {
          const targetKeys = new Set(candidates.map((c) => `${c.provider}:${c.id}`));
          const keptEarly = [];
          const sortedPreGate = [...preGateWarm].sort(
            (a, b) =>
              Number(targetKeys.has(`${b?.provider}:${b?.id}`)) -
              Number(targetKeys.has(`${a?.provider}:${a?.id}`))
          );
          for (const pw of sortedPreGate) {
            if (!pw || !pw.id) continue;
            const k = `${pw.provider}:${pw.id}`;
            if (!targetKeys.has(k) || keptEarly.length >= maxWarmTabs) {
              const ok = await this.tabs
                .closePrewarmedTab(pw.id, { provider: pw.provider, uri: pw.uri, reason: 'budget_shrink' })
                .catch(() => false);
              if (ok) {
                earlyEvicted += 1;
                telemetryDirty = true;
              }
            } else {
              keptEarly.push(k);
            }
          }
        }

        // Tier 2 (adaptive 0..3): requires >= policy.tier2IdleMs quiet AND (!focused || OS idle >= policy.osIdleMinMs)
        // AND an existing user-open tab so focus always stays anchored.
        // Tier 2 opens real editor tabs the sidebar treats as closed, which reads as "tabs opening by
        // themselves" (user, 2026-11-16). It is opt-in: only an explicit user/workspace `true` enables it,
        // and while it is off any prewarmed tab still open (including ones restored after a reload) is closed.
        let tier2Enabled = false;
        try {
          const info = vscode.workspace.getConfiguration('antigravityHub').inspect?.('prewarmRecentTabs');
          const explicit =
            info?.workspaceFolderValue ?? info?.workspaceValue ?? info?.globalValue;
          tier2Enabled = explicit === true;
        } catch {}
        if (!tier2Enabled && !opts.forceTier2) {
          const evictedOff = await this.evictAllPrewarmedTabs('tier2_disabled').catch(() => 0);
          if ((telemetryDirty || evictedOff > 0) && typeof this.render === 'function') {
            try { this.render(); } catch {}
          }
          return { ok: true, tier: 1, prewarmed: 0, evicted: earlyEvicted + evictedOff, maxWarmTabs };
        }
        const windowFocused = opts.windowFocused ?? (vscode.window?.state?.focused !== false);
        const rawOsIdle =
          typeof opts.osIdleMs === 'number' ? opts.osIdleMs : getHostIdleMs(now);
        const osIdleLong = typeof rawOsIdle === 'number' && rawOsIdle >= policy.osIdleMinMs;
        const canRunTier2 =
          Boolean(opts.forceTier2) ||
          (quietMs >= policy.tier2IdleMs && (!windowFocused || osIdleLong));
        if (!canRunTier2) {
          if (quietMs < policy.tier2IdleMs) {
            this.scheduleIdlePrewarmCheck(policy.tier2IdleMs - quietMs + 50);
          }
          if (telemetryDirty && typeof this.render === 'function') {
            try { this.render(); } catch {}
          }
          return { ok: true, tier: 1, prewarmed: 0, evicted: earlyEvicted, maxWarmTabs };
        }

        const anchorOpenTab = Array.isArray(this.openTabsList)
          ? (this.openTabsList.find((t) => Boolean(t && t.id && t.active)) ||
              this.openTabsList.find((t) => Boolean(t && t.id)))
          : null;
        const hasUserOpenTab =
          Boolean(anchorOpenTab) || Boolean(vscode.window?.tabGroups?.activeTabGroup?.activeTab);
        if (!hasUserOpenTab) {
          if (telemetryDirty && typeof this.render === 'function') {
            try { this.render(); } catch {}
          }
          return { ok: false, skipped: 'no_open_tab_anchor', evicted: earlyEvicted, maxWarmTabs };
        }

        const curPrewarmed = (await this.tabs?.getPrewarmedTabs?.().catch(() => [])) || [];
        const candMap = new Map(candidates.map((c) => [`${c.provider}:${c.id}`, c]));
        const kept = [];
        let evicted = earlyEvicted;
        for (const pw of Array.isArray(curPrewarmed) ? curPrewarmed : []) {
          if (!pw || !pw.id) continue;
          const k = `${pw.provider}:${pw.id}`;
          if (!candMap.has(k) || kept.length >= maxWarmTabs) {
            const ok = await this.tabs
              .closePrewarmedTab(pw.id, { provider: pw.provider, uri: pw.uri, reason: 'stale' })
              .catch(() => false);
            if (ok) {
              evicted += 1;
              telemetryDirty = true;
            }
          } else {
            kept.push(k);
          }
        }
        const keptSet = new Set(kept);
        let opened = 0;
        for (const cand of candidates) {
          if (keptSet.size + opened >= maxWarmTabs) break;
          const k = `${cand.provider}:${cand.id}`;
          if (keptSet.has(k)) continue;
          // Re-verify quiet & focus right before spawning the next panel.
          const nowCheck = typeof opts.now === 'number' ? opts.now : Date.now();
          if (!opts.forceTier2) {
            if (nowCheck - Number(this._lastUserOrTabActivityAt || nowCheck) < policy.tier2IdleMs) {
              break;
            }
          }
          const res = await this.tabs
            .prewarmThread(cand.id, {
              provider: cand.provider,
              title: cand.title,
              viewColumn: anchorOpenTab?.viewColumn ?? vscode.window?.tabGroups?.activeTabGroup?.viewColumn
            })
            .catch(() => null);
          if (res?.prewarmed) {
            opened += 1;
            telemetryDirty = true;
          } else if (!res?.alreadyOpen) {
            this._prewarmCooldownUntilById.set(cand.id, nowCheck + PREWARM_RETRY_COOLDOWN_MS);
          }
        }
        if (telemetryDirty && typeof this.render === 'function') {
          try { this.render(); } catch {}
        }
        return {
          ok: true,
          tier: 2,
          opened,
          evicted,
          candidates: candidates.length,
          maxWarmTabs,
          adaptiveMode: policy.adaptiveMode
        };
      } finally {
        settled = true;
        if (passPromise && this._prewarmPassInFlight === passPromise) {
          this._prewarmPassInFlight = null;
        }
      }
    })();
    if (!settled) {
      this._prewarmPassInFlight = passPromise;
    }
    return passPromise;
  }

  dispose() {
    this.clearPendingActiveExpiryTimer();
    this.evictAllPrewarmedTabs('dispose').catch(() => {});
    if (this._idlePrewarmTimer) {
      clearTimeout(this._idlePrewarmTimer);
      this._idlePrewarmTimer = null;
    }
    if (this._permCacheDebounce) {
      clearTimeout(this._permCacheDebounce);
      this._permCacheDebounce = null;
    }
    if (this._permCacheWatcher) {
      try {
        this._permCacheWatcher.close();
      } catch {}
      this._permCacheWatcher = null;
    }
    if (this.renderTimer) {
      clearTimeout(this.renderTimer);
      this.renderTimer = null;
    }
    if (this._fastTabSyncTimer) {
      clearTimeout(this._fastTabSyncTimer);
      this._fastTabSyncTimer = null;
      this._pendingFastTabSyncOpts = null;
    }
    if (this._scheduledRefreshTimer) {
      clearTimeout(this._scheduledRefreshTimer);
      this._scheduledRefreshTimer = null;
      this._scheduledRefreshOpts = null;
    }
  }
}

module.exports = {
  HubProvider,
  describeBridgeNotice,
  patchSkipBlocks,
  buildStablePostSignature,
  buildStablePostParts,
  ACTIVITY_REFRESH_MIN_INTERVAL_MS,
  ACTIVITY_FAST_TAB_SYNC_MIN_INTERVAL_MS,
  RENDER_BURST_MIN_INTERVAL_MS,
  HEARTBEAT_POST_MIN_INTERVAL_MS,
  MAX_PREWARMED_TABS,
  MAX_PREWARMED_TABS_CEILING,
  PREWARM_TIER1_IDLE_MS,
  PREWARM_TIER2_IDLE_MS,
  PREWARM_OS_IDLE_MIN_MS,
  PREWARM_ADAPTIVE_MIN_SAMPLES,
  PREWARM_MEM_CRITICAL_BYTES,
  PREWARM_MEM_PRESSURE_BYTES,
  PREWARM_MEM_AMPLE_BYTES,
  PREWARM_REMOTE_HINT_TTL_MS,
  computeAdaptivePrewarmLimits,
  ensurePrewarmTelemetryStore,
  resetPrewarmTelemetryStore,
  resolveGitRepoAndBranchFast,
  computePrewarmAffinityBoost
};
