'use strict';

const assert = require('assert');
const { spawnSync } = require('child_process');
const fs = require('fs');
const http = require('http');
const net = require('net');
const os = require('os');
const path = require('path');
const vm = require('vm');

process.env.THEO_SMOKE_TEST = '1';
process.env.THEO_DISABLE_HUB_PROCESS_REAP = '1';

const ROOT = path.resolve(__dirname, '..');

async function main() {
  // 1. Syntax check all CJS/JS modules
  const cjsFiles = [
    'extension.js',
    'accounts.js',
    'session-tabs.js',
    'hub.js',
    'data.js',
    'store.js',
    'state.js',
    'bridge.js',
    'remote.js',
    'device-identity.js',
    'ws-server.js',
    'direct-runner.js',
    'edge-relay-client.js',
    'activity.js',
    'desktop-notify.js',
    'desktop-launcher.js',
    'scripts/relay_keepalive.cjs',
    'scripts/theo_agent.cjs',
    'compat/antigravity-hub-bridge.cjs',
    'compat/antigravity-tab-state.cjs',
    'compat/antigravity-context-window.cjs',
    'compat/claude-hub-bridge.cjs',
    'compat/claude-webview-patches.cjs',
    'compat/excel-preview.cjs'
  ];
  for (const rel of cjsFiles) {
    const full = path.join(ROOT, rel);
    assert.ok(fs.existsSync(full), `Missing module ${rel}`);
    const code = fs.readFileSync(full, 'utf8');
    new vm.Script(code, { filename: full });
  }
  console.log(`[PASS] Syntax verified across ${cjsFiles.length} theo-hub modules`);

  // 2. Adversarial Check #1: Zero secrets in repo & pairing token roundtrip + hostile input rejection
  assert.strictEqual(
    fs.existsSync(path.join(ROOT, 'remote-relay.json')),
    false,
    'remote-relay.json must NOT exist inside theo-hub repo'
  );
  const devId = require(path.join(ROOT, 'device-identity.js'));
  const sampleToken = devId.buildPairTokenBase64Url({
    cloudUrl: 'https://example.invalid/relay',
    cloudKey: 'test-cloud-key',
    edgeAccessKey: 'a'.repeat(64),
    edgeRelayUrl: 'wss://theo-edge-relay.husseinbdeir.workers.dev/ws',
    port: 4318
  });
  assert.ok(sampleToken && !sampleToken.includes('+') && !sampleToken.includes('/'), 'URL-safe base64 token');
  const decoded = devId.parsePairTokenBase64Url(`https://husseinbdeir.github.io/theo/#pair=${sampleToken}&foo=1`);
  assert.strictEqual(decoded.edgeAccessKey, 'a'.repeat(64));
  assert.strictEqual(decoded.cloudKey, 'test-cloud-key');
  const multiLineTxt = [
    '=== THEO 1-Tap Mobile Pairing URL ===',
    `https://husseinbdeir.github.io/theo/#pair=${sampleToken}`,
    '',
    '=== Main Workstation 1-Line PowerShell ===',
    `$env:THEO_PAIR_TOKEN='${sampleToken}'; irm https://raw.githubusercontent.com/HusseinBdeir/theo/main/install.ps1 | iex`
  ].join('\r\n');
  const decodedMulti = devId.parsePairTokenBase64Url(multiLineTxt);
  assert.ok(decodedMulti, 'Multi-line mobile-pair-url.txt paste must decode cleanly');
  assert.strictEqual(decodedMulti.edgeAccessKey, 'a'.repeat(64));
  const decodedPs1 = devId.parsePairTokenBase64Url(
    `$env:THEO_PAIR_TOKEN="${sampleToken}"; irm https://raw.githubusercontent.com/HusseinBdeir/theo/main/install.ps1 | iex`
  );
  assert.ok(decodedPs1, 'PowerShell $env:THEO_PAIR_TOKEN line must decode cleanly');
  assert.strictEqual(decodedPs1.cloudKey, 'test-cloud-key');
  assert.strictEqual(devId.parsePairTokenBase64Url('not-a-valid-token-$$$'), null);
  assert.strictEqual(devId.parsePairTokenBase64Url('#pair=bm90LWpzb24'), null, 'Non-JSON #pair= must return null');
  assert.strictEqual(devId.parsePairTokenBase64Url(''), null);

  // Red-Team C-1: Reject secret-less or partial-overwrite #pair= payloads & unsafe endpoint schemes
  const encodeRawJsonToken = (obj) =>
    Buffer.from(JSON.stringify(obj), 'utf8')
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/g, '');
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'https://evil.example/steal', k: '', e: '' })}`),
    null,
    'Secret-less #pair= payload must return null (C-1)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'https://evil.example/steal', k: '', e: 'a'.repeat(64) })}`),
    null,
    'cloudUrl without cloudKey in #pair= must return null to prevent stored cloudKey exfiltration (C-1)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'http://evil.example/steal', k: 'k1', e: 'a'.repeat(64) })}`),
    null,
    'Non-TLS remote http:// cloudUrl in #pair= must fail closed (return null)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, r: 'javascript:alert(1)', e: 'a'.repeat(64) })}`),
    null,
    'javascript: edgeRelayUrl in #pair= must fail closed (return null)'
  );

  // Red-Team M-4 / M-5: Behavioral execution of Cloudflare Durable Object TheoRelayRoom (/pair/create, /pair/claim, 429 wipe, alarm)
  const nodeCrypto = require('crypto');
  const { DatabaseSync } = require('node:sqlite');
  const workerSrc = fs.readFileSync(path.join(ROOT, 'cloudflare-relay', 'src', 'index.js'), 'utf8');
  const cjsWorkerCode =
    workerSrc
      .replace(
        /import\s*\{\s*DurableObject\s*\}\s*from\s*["']cloudflare:workers["'];?/,
        'class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }'
      )
      .replace(/export\s+default\s+/, 'module.exports.worker = ')
      .replace(/export\s+class\s+TheoRelayRoom\b/, 'class TheoRelayRoom') +
    '\nmodule.exports.TheoRelayRoom = TheoRelayRoom;\n';
  const cfSubtle = new Proxy(globalThis.crypto.subtle, {
    get(target, prop) {
      if (prop === 'timingSafeEqual') {
        return (a, b) => nodeCrypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
      }
      const val = target[prop];
      return typeof val === 'function' ? val.bind(target) : val;
    }
  });
  const cfCrypto = new Proxy(globalThis.crypto, {
    get(target, prop) {
      if (prop === 'subtle') return cfSubtle;
      const val = target[prop];
      return typeof val === 'function' ? val.bind(target) : val;
    }
  });
  const workerMod = { exports: {} };
  vm.runInNewContext(
    cjsWorkerCode,
    {
      module: workerMod,
      exports: workerMod.exports,
      crypto: cfCrypto,
      TextEncoder,
      TextDecoder,
      Uint8Array,
      Uint32Array,
      URL,
      Request,
      Response,
      Headers,
      JSON,
      Date,
      Math,
      Number,
      String,
      Boolean,
      Array,
      Object,
      Set,
      Map,
      Promise,
      Error
    },
    { filename: 'cloudflare-relay-index.js' }
  );
  const { TheoRelayRoom, worker: edgeWorker } = workerMod.exports;
  const routedRoomNames = [];
  await edgeWorker.fetch(new Request('https://edge.example/pair/claim', { method: 'POST', body: '{}' }), {
    THEO_ROOM: {
      idFromName: (n) => {
        routedRoomNames.push(n);
        return n;
      },
      get: () => ({ fetch: async () => new Response('{}', { status: 200 }) })
    }
  });
  await edgeWorker.fetch(new Request('https://edge.example/ws'), {
    THEO_ROOM: {
      idFromName: (n) => {
        routedRoomNames.push(n);
        return n;
      },
      get: () => ({ fetch: async () => new Response('{}', { status: 426 }) })
    }
  });
  assert.deepStrictEqual(
    routedRoomNames,
    ['theo-pair-v1', 'theo-fleet-v2'],
    'Edge Worker must isolate /pair/* into theo-pair-v1 DO so hibernated WebSockets never pin old DO code'
  );
  const memDb = new DatabaseSync(':memory:');
  let scheduledAlarmAt = 0;
  const mockSql = {
    exec(query, ...params) {
      if (params.length === 0 && !/^\s*SELECT\b/i.test(query)) {
        memDb.exec(query);
        return [];
      }
      const stmt = memDb.prepare(query);
      if (/^\s*SELECT\b/i.test(query)) {
        return stmt.all(...params);
      }
      stmt.run(...params);
      return [];
    }
  };
  const roomAuthToken = devId.deriveEdgeAuthToken('unit-test-worker-secret');
  const room = new TheoRelayRoom(
    {
      getWebSockets: () => [],
      storage: {
        sql: mockSql,
        getAlarm: async () => scheduledAlarmAt || null,
        setAlarm: async (ts) => {
          scheduledAlarmAt = Number(ts || 0);
        }
      }
    },
    { AUTH_TOKEN: roomAuthToken }
  );

  // 1) Unauthenticated /pair/create -> 401
  const unauthCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: { Origin: 'http://127.0.0.1:4318', 'Content-Type': 'application/json' },
      body: JSON.stringify({ bundle: sampleToken })
    })
  );
  assert.strictEqual(unauthCreateRes.status, 401, 'Unauthenticated /pair/create must return 401');

  // 2) Disallowed Origin on /pair/create -> 403
  const evilOriginCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'https://evil.attacker.example',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken })
    })
  );
  assert.strictEqual(evilOriginCreateRes.status, 403, 'Hostile Origin on /pair/create must return 403');

  // 3) Oversized bundle (>8192 chars) -> 400
  const oversizedCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: 'a'.repeat(9000) })
    })
  );
  assert.strictEqual(oversizedCreateRes.status, 400, 'Oversized bundle on /pair/create must return 400');

  // 4) Valid /pair/create -> 200 + 6-digit code, single-use /pair/claim -> 200, replay -> 401
  const validCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 600 })
    })
  );
  assert.strictEqual(validCreateRes.status, 200, 'Authorized /pair/create must return 200');
  const createdJson = await validCreateRes.json();
  assert.match(String(createdJson.code || ''), /^\d{6}$/, 'Minted code must be exactly 6 digits');

  const firstClaimRes = await room.fetch(
    new Request('https://edge.example/pair/claim', {
      method: 'POST',
      headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: createdJson.code })
    })
  );
  assert.strictEqual(firstClaimRes.status, 200, 'Valid 6-digit /pair/claim must return 200');
  const firstClaimJson = await firstClaimRes.json();
  assert.strictEqual(firstClaimJson.bundle, sampleToken, 'Claimed bundle must equal minted bundle');

  const replayClaimRes = await room.fetch(
    new Request('https://edge.example/pair/claim', {
      method: 'POST',
      headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: createdJson.code })
    })
  );
  assert.strictEqual(replayClaimRes.status, 401, 'Replaying a consumed 6-digit code must return 401');

  // 5) Mint 2nd code, send 5 wrong guesses -> 5th returns 429 & wipes active codes
  const secondCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 600 })
    })
  );
  const secondJson = await secondCreateRes.json();
  const wrongCode = secondJson.code === '000000' ? '999999' : '000000';
  let fifthWrongStatus = 0;
  for (let attempt = 1; attempt <= 5; attempt += 1) {
    const r = await room.fetch(
      new Request('https://edge.example/pair/claim', {
        method: 'POST',
        headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: wrongCode })
      })
    );
    if (attempt < 5) {
      assert.strictEqual(r.status, 401, `Wrong attempt #${attempt} must return 401`);
    } else {
      fifthWrongStatus = r.status;
    }
  }
  assert.strictEqual(fifthWrongStatus, 429, '5th wrong attempt must trigger HTTP 429 lockout');
  const remainingCodesAfterWipe = memDb.prepare('SELECT COUNT(*) AS cnt FROM pair_codes').get().cnt;
  assert.strictEqual(remainingCodesAfterWipe, 0, '5th wrong attempt must wipe all active pair_codes');

  // 6) M-4: alarm() with 0 connected WebSockets must still reschedule cleanup while pair_codes exist
  memDb.exec("DELETE FROM kv WHERE k = 'pair_fail_state'");
  await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 120 })
    })
  );
  scheduledAlarmAt = 0;
  await room.alarm();
  assert.ok(scheduledAlarmAt > Date.now(), 'alarm() with 0 WebSockets must reschedule next pair_codes expiry cleanup (M-4)');
  memDb.close();

  // Verify theo-hub-bundle.zip (if present in sibling ../theo) leaks zero secrets or .wrangler state
  const siblingBundleZip = path.resolve(ROOT, '..', 'theo', 'theo-hub-bundle.zip');
  const liveCredPath = path.join(os.homedir(), '.theo', 'credentials.json');
  if (fs.existsSync(siblingBundleZip)) {
    const rawZipBytes = fs.readFileSync(siblingBundleZip);
    const rawZipLatin1 = rawZipBytes.toString('latin1');
    assert.strictEqual(rawZipLatin1.includes('remote-relay.json'), false, 'Bundle zip must not contain remote-relay.json');
    assert.strictEqual(rawZipLatin1.includes('.wrangler/'), false, 'Bundle zip must not contain .wrangler state');
    if (fs.existsSync(liveCredPath)) {
      const liveCreds = JSON.parse(fs.readFileSync(liveCredPath, 'utf8'));
      for (const secretField of ['edgeAccessKey', 'cloudKey']) {
        const val = String(liveCreds[secretField] || '').trim();
        if (val.length >= 16) {
          assert.strictEqual(
            rawZipLatin1.includes(val),
            false,
            `Bundle zip must NEVER contain live ${secretField}`
          );
        }
      }
    }
  }

  // Cross-host device attribution & localOnly snapshot symmetry invariant (#2 & Red-Team Finding #1/#5)
  const wsRow = devId.inferRowOwnerDevice(
    { cwd: 'C:\\Users\\HusseinBdeir\\bhfirms\\isabi-app' },
    { id: 'theo-laptop', name: 'THEO Laptop' }
  );
  assert.strictEqual(wsRow.id, 'main-workstation');
  assert.strictEqual(wsRow.deviceId, 'main-workstation');
  assert.strictEqual(wsRow.deviceName, 'Main Workstation');
  const lapRow = devId.inferRowOwnerDevice(
    { cwd: 'C:\\Users\\hbdei\\bhfirms\\theo' },
    { id: 'main-workstation', name: 'Main Workstation' }
  );
  assert.strictEqual(lapRow.id, 'theo-laptop');
  assert.strictEqual(lapRow.deviceId, 'theo-laptop');
  const nodeBinInfo = devId.resolveNodeBinaryInfo();
  assert.strictEqual(nodeBinInfo.executable, nodeBinInfo.nodeExe, 'resolveNodeBinaryInfo must expose nodeExe alias');
  assert.strictEqual(
    nodeBinInfo.electronRunAsNode,
    nodeBinInfo.useElectronRunAsNode,
    'resolveNodeBinaryInfo must expose useElectronRunAsNode alias'
  );

  const { TheoRemoteBridge } = require(path.join(ROOT, 'remote.js'));
  const mockBridge = new TheoRemoteBridge(null, {
    hub: {
      lastPosted: JSON.stringify({
        rows: [
          { id: 'loc-1', title: 'Laptop Local Thread', cwd: 'C:\\Users\\hbdei\\bhfirms\\theo', provider: 'antigravity', at: 200 },
          { id: 'rem-1', title: 'Workstation Synced Thread', cwd: 'C:\\Users\\HusseinBdeir\\bhfirms\\isabi-app', provider: 'claude', at: 300 }
        ]
      }),
      snapshot: {}
    }
  });
  if (mockBridge.edgeClient) mockBridge.edgeClient.stop();
  mockBridge.deviceInfo = { id: 'theo-laptop', name: 'Theo Laptop', role: 'secondary', capabilities: ['antigravity', 'claude'] };
  const localOnlySnap = await mockBridge.buildFullState({ localOnly: true });
  assert.deepStrictEqual(
    localOnlySnap.rows.map((r) => r.id),
    ['loc-1'],
    'buildFullState({ localOnly: true }) must retain local rows and exclude foreign-host rows'
  );
  const fullMergedSnap = await mockBridge.buildFullState({ localOnly: false });
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'loc-1')?.remotePeer, false);
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'rem-1')?.deviceId, 'main-workstation');
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'rem-1')?.remotePeer, true);

  let capturedEdgeUrl = '';
  mockBridge.setEffectiveEdgeUrl = async (u) => {
    capturedEdgeUrl = u;
    return { ok: true };
  };
  for (const payload of [{ url: 'wss://a.example/ws' }, { edgeRelayUrl: 'wss://b.example/ws' }]) {
    const rawNextUrl = payload.edgeRelayUrl !== undefined ? payload.edgeRelayUrl : payload.url;
    await mockBridge.setEffectiveEdgeUrl(String(rawNextUrl || '').trim());
    assert.strictEqual(capturedEdgeUrl, payload.edgeRelayUrl || payload.url);
  }

  // Red-Team H-1 / L-1 / M-5: Behavioral HTTP execution of TheoRemoteBridge.handleHttpRequest
  const unitBridgeTok = devId.deriveEdgeAuthToken('unit-test-http-bridge-secret');
  mockBridge.getDerivedBridgeToken = () => unitBridgeTok;
  mockBridge.verifyBridgeToken = (tok) => Boolean(tok && tok === unitBridgeTok);
  const bridgeHttpSrv = http.createServer((req, res) => {
    mockBridge.handleHttpRequest(req, res).catch((err) => {
      res.writeHead(500);
      res.end(String(err));
    });
  });
  await new Promise((resolve) => bridgeHttpSrv.listen(0, '127.0.0.1', resolve));
  const bridgeHttpPort = bridgeHttpSrv.address().port;
  try {
    const baseBridgeUrl = `http://127.0.0.1:${bridgeHttpPort}`;
    // Unauthenticated /api/ping -> 200 with authenticated: false & authRequired: true (H-1)
    const unauthPing = await fetch(`${baseBridgeUrl}/api/ping`);
    assert.strictEqual(unauthPing.status, 200);
    const unauthPingJson = await unauthPing.json();
    assert.strictEqual(unauthPingJson.authenticated, false, 'Unauthenticated /api/ping must set authenticated: false (H-1)');
    assert.strictEqual(unauthPingJson.authRequired, true, 'Unauthenticated /api/ping must set authRequired: true');

    // Authenticated /api/ping -> 200 with authenticated: true
    const authPing = await fetch(`${baseBridgeUrl}/api/ping`, {
      headers: { Authorization: `Bearer ${unitBridgeTok}` }
    });
    const authPingJson = await authPing.json();
    assert.strictEqual(authPingJson.authenticated, true, 'Authenticated /api/ping must set authenticated: true');

    // Unauthenticated /api/pairing-info & /api/pair-code -> 401
    const unauthPairInfo = await fetch(`${baseBridgeUrl}/api/pairing-info`);
    assert.strictEqual(unauthPairInfo.status, 401, 'Unauthenticated /api/pairing-info must return 401');
    const unauthPairCode = await fetch(`${baseBridgeUrl}/api/pair-code`, { method: 'POST' });
    assert.strictEqual(unauthPairCode.status, 401, 'Unauthenticated /api/pair-code must return 401');

    // Authenticated /api/pairing-info -> 200 with single-quoted PowerShell command & dual field names (L-1)
    const authPairInfo = await fetch(`${baseBridgeUrl}/api/pairing-info`, {
      headers: { Authorization: `Bearer ${unitBridgeTok}` }
    });
    assert.strictEqual(authPairInfo.status, 200);
    const authPairInfoJson = await authPairInfo.json();
    assert.strictEqual(authPairInfoJson.pairUrl, authPairInfoJson.mobilePairUrl, 'pairUrl and mobilePairUrl must match');
    assert.strictEqual(
      authPairInfoJson.workstationCmd,
      authPairInfoJson.workstationBootstrapPs1,
      'workstationCmd and workstationBootstrapPs1 must match'
    );
    if (authPairInfoJson.workstationCmd) {
      assert.ok(
        authPairInfoJson.workstationCmd.startsWith("$env:THEO_PAIR_TOKEN='"),
        'workstationCmd must single-quote $env:THEO_PAIR_TOKEN in PowerShell (L-1)'
      );
    }
  } finally {
    await new Promise((resolve) => bridgeHttpSrv.close(resolve));
  }
  console.log('[PASS] Adversarial #1: Zero repo secrets, DO /pair/create+/pair/claim+429+alarm, C-1/H-1/L-1 HTTP & #pair= checks');

  // 3. Adversarial Check #2: RFC 6455 WS server Origin gate, Auth gate (4001), onConnect post-auth firing, & unmasked/continuation validation
  const { attachWebSocketServer } = require(path.join(ROOT, 'ws-server.js'));
  const expectedSecret = devId.deriveEdgeAuthToken('unit-test-secret-key');
  let onConnectFiredCount = 0;
  const srv = http.createServer((req, res) => {
    res.writeHead(200);
    res.end('ok');
  });
  const wss = attachWebSocketServer(srv, {
    path: '/ws',
    verifyUpgrade: (req) => {
      const origin = String(req.headers.origin || '');
      if (origin && origin !== 'http://127.0.0.1' && origin !== 'https://husseinbdeir.github.io') {
        return { ok: false, status: 403, message: 'Forbidden Origin' };
      }
      return { ok: true };
    },
    verifyToken: (tok) => tok === expectedSecret,
    onConnect: (conn) => {
      onConnectFiredCount += 1;
      conn.sendJson({ type: 'welcome', ok: true });
    }
  });
  await new Promise((resolve) => srv.listen(0, '127.0.0.1', resolve));
  const port = srv.address().port;

  try {
    // 3a. Hostile Origin must be rejected with HTTP 403 before WS upgrade completes
    const evilStatus = await new Promise((resolve, reject) => {
      const req = http.request({
        host: '127.0.0.1',
        port,
        path: '/ws',
        headers: {
          Connection: 'Upgrade',
          Upgrade: 'websocket',
          Origin: 'https://evil.attacker.example',
          'Sec-WebSocket-Version': '13',
          'Sec-WebSocket-Key': Buffer.from('1234567890123456').toString('base64')
        }
      });
      req.on('response', (res) => {
        res.resume();
        resolve(res.statusCode);
      });
      req.on('upgrade', (_, sock) => {
        sock.destroy();
        resolve(101);
      });
      req.on('error', reject);
      req.end();
    });
    assert.strictEqual(evilStatus, 403, 'Evil Origin must receive 403');

    // 3b. Wrong token over WS must be rejected with close code 4001
    const badCloseCode = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, {
        headers: { Origin: 'https://husseinbdeir.github.io' }
      });
      const t = setTimeout(() => reject(new Error('WS close timeout')), 4000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ type: 'auth', token: 'wrong-token' }));
      });
      ws.addEventListener('close', (ev) => {
        clearTimeout(t);
        resolve(ev.code);
      });
    });
    assert.strictEqual(badCloseCode, 4001, 'Invalid WS auth token must close with 4001');
    assert.strictEqual(onConnectFiredCount, 0, 'onConnect must NEVER fire before valid WS token auth');

    // 3c. Valid token succeeds, receives auth_ok AND welcome from onConnect fallback
    const authedOk = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, {
        headers: { Origin: 'https://husseinbdeir.github.io' }
      });
      const seenTypes = new Set();
      const t = setTimeout(() => reject(new Error('WS auth_ok + welcome timeout')), 4000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ type: 'auth', token: expectedSecret }));
      });
      ws.addEventListener('message', (ev) => {
        const msg = JSON.parse(String(ev.data));
        seenTypes.add(msg.type);
        if (seenTypes.has('auth_ok') && seenTypes.has('welcome')) {
          clearTimeout(t);
          ws.close();
          resolve(true);
        }
      });
    });
    assert.strictEqual(authedOk, true);
    assert.strictEqual(onConnectFiredCount, 1, 'onConnect must fire exactly once after valid WS auth');

    // 3d. Unexpected RFC 6455 continuation frame (opcode 0x0 with no fragmented message) closes cleanly without crashing
    const protoClose = await new Promise((resolve) => {
      const sock = net.connect(port, '127.0.0.1', () => {
        const key = Buffer.from('abcdefghijklmnop').toString('base64');
        sock.write(
          `GET /ws HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: ${key}\r\n\r\n`
        );
      });
      let upgraded = false;
      let buf = Buffer.alloc(0);
      sock.on('data', (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        if (!upgraded && buf.includes('\r\n\r\n')) {
          upgraded = true;
          // Masked FIN=1 opcode=0x0 (unexpected continuation) length=2 mask=0x11223344 payload=0x0000
          const badFrame = Buffer.from([0x80, 0x82, 0x11, 0x22, 0x33, 0x44, 0x11, 0x22]);
          sock.write(badFrame);
        }
      });
      sock.on('close', () => resolve(true));
    });
    assert.strictEqual(protoClose, true);
  } finally {
    wss.closeAll();
    await new Promise((resolve) => srv.close(resolve));
  }
  console.log('[PASS] Adversarial #2: WS Origin 403, invalid-token 4001, valid auth_ok, and RFC 6455 protocol-error guard');

  // 4. Adversarial Check #3: Cortex SQLite protobuf decoder & sidecar recovery + missing-ID safety
  const { AntigravityDataStore } = require(path.join(ROOT, 'store.js'));
  const store = new AntigravityDataStore();
  assert.strictEqual(store.readCliConversationDbDetail('../../etc/passwd'), null, 'Path traversal ID must return null');
  assert.strictEqual(store.readCliConversationDbDetail('00000000-0000-0000-0000-000000000000'), null);
  const cliConvDir = path.join(os.homedir(), '.gemini', 'antigravity-cli', 'conversations');
  if (fs.existsSync(cliConvDir)) {
    const dbFiles = fs.readdirSync(cliConvDir).filter((f) => f.endsWith('.db'));
    if (dbFiles.length > 0) {
      let decodedAny = 0;
      for (const f of dbFiles.slice(0, 5)) {
        const cid = f.replace(/\.db$/, '');
        const parsed = store.readCliConversationDbDetail(cid);
        if (parsed && Array.isArray(parsed.messages) && parsed.messages.length > 0) {
          decodedAny += 1;
        }
      }
      assert.ok(decodedAny > 0, 'Expected at least 1 CLI SQLite conversation to decode >0 messages');
      console.log(`[PASS] Adversarial #3: Decoded ${decodedAny}/${Math.min(5, dbFiles.length)} CLI SQLite conversations + rejected traversal IDs`);
    }
  } else {
    console.log('[PASS] Adversarial #3: Traversal & missing SQLite ID guards verified');
  }

  // 5. Adversarial Check #4: >1.5MB transcript_full.jsonl thoughtBlocks/checkpoint/subagent + readSafeFilePreview traversal/secret rejection
  const remoteMod = require(path.join(ROOT, 'remote.js'));
  assert.strictEqual(remoteMod.isSensitivePreviewPath('../../.theo/credentials.json'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('.env.local'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('config/client_secret.json'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('keys/server.pem'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('remote.js\0.md'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('js/app.js'), false);

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-smoke-transcript-'));
  try {
    const compactLog = path.join(tmpDir, 'transcript.jsonl');
    const fullLog = path.join(tmpDir, 'transcript_full.jsonl');
    const padLine = JSON.stringify({
      step_index: 0,
      type: 'PLANNER_RESPONSE',
      status: 'DONE',
      created_at: '2026-11-08T10:00:00Z',
      content: 'padding '.repeat(210000)
    });
    const steps = [
      padLine,
      JSON.stringify({
        step_index: 1,
        type: 'USER_INPUT',
        status: 'DONE',
        created_at: '2026-11-08T10:01:00Z',
        content: '<USER_REQUEST>Audit subagents</USER_REQUEST>'
      }),
      JSON.stringify({
        step_index: 2,
        type: 'CHECKPOINT',
        status: 'DONE',
        created_at: '2026-11-08T10:01:05Z',
        content: 'Compacted 42 prior steps into context summary.'
      }),
      JSON.stringify({
        step_index: 3,
        type: 'PLANNER_RESPONSE',
        status: 'DONE',
        created_at: '2026-11-08T10:01:12Z',
        thinking: 'Mapping architecture before spawning Red-Team subagent.',
        tool_calls: [
          {
            id: 'tc-sub-1',
            name: 'default_api:invoke_subagent',
            arguments: {
              TypeName: 'red-team-gate',
              Role: '7-Axis Red-Team Auditor',
              Prompt: 'Audit git diff across 7 axes'
            }
          }
        ]
      }),
      JSON.stringify({
        step_index: 4,
        type: 'TOOL_RESPONSE',
        tool_call_id: 'tc-sub-1',
        created_at: '2026-11-08T10:01:20Z',
        content: '{"conversationId":"11111111-2222-3333-4444-555555555555","status":"running"}'
      }),
      JSON.stringify({
        step_index: 5,
        type: 'PLANNER_RESPONSE',
        status: 'DONE',
        created_at: '2026-11-08T10:01:29Z',
        thinking: 'Synthesizing final audit report.',
        content: 'All 7 axes verified clean.'
      })
    ];
    // Compact log lacks thinking; fullLog is >1.6MB and has full thinking
    fs.writeFileSync(compactLog, JSON.stringify({ step_index: 1, type: 'USER_INPUT', content: 'hi' }) + '\n', 'utf8');
    fs.writeFileSync(fullLog, steps.join('\n') + '\n', 'utf8');
    assert.ok(fs.statSync(fullLog).size > 1550 * 1024, 'fullLog must exceed 1.5MB threshold');

    const parsedLarge = remoteMod.parseAntigravityTranscriptFile(compactLog, 40);
    const ckpt = parsedLarge.messages.find((m) => m.role === 'checkpoint');
    assert.ok(ckpt && ckpt.text.includes('Compacted 42 prior steps'), 'Expected CHECKPOINT message preserved');
    const asst = parsedLarge.messages.filter((m) => m.role === 'assistant').pop();
    assert.ok(asst, 'Expected assistant turn after checkpoint');
    assert.ok(Array.isArray(asst.thoughtBlocks) && asst.thoughtBlocks.length === 2, 'Expected 2 coalesced thoughtBlocks from >1.5MB transcript_full.jsonl');
    assert.ok(asst.thinkingDurationSec >= 10, 'Expected positive thinkingDurationSec');
    const subTc = (asst.toolCalls || []).find((tc) => tc.kind === 'subagent');
    assert.ok(subTc, 'Expected invoke_subagent classified as kind=subagent');
    assert.strictEqual(subTc.subagentRole, '7-Axis Red-Team Auditor');
    assert.strictEqual(subTc.subagentConversationId, '11111111-2222-3333-4444-555555555555');
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  const previewBridge = new remoteMod.TheoRemoteBridge({ hub: { snapshot: { threads: [] } } });
  const okPrev = await previewBridge.readSafeFilePreview({
    path: `file:///${path.join(ROOT, 'remote.js').replace(/\\/g, '/')}#L1-L15`
  });
  assert.strictEqual(okPrev.ok, true, 'Expected valid workspace file preview to succeed');
  assert.strictEqual(okPrev.startLine, 1);
  assert.strictEqual(okPrev.endLine, 15);
  assert.ok(okPrev.content.includes('crypto'), 'Expected file content in preview');
  assert.strictEqual(okPrev.diffPatch, okPrev.gitDiff, 'Expected diffPatch alias matching gitDiff');

  const blockedTraversal = await previewBridge.readSafeFilePreview({ path: '../../.theo/credentials.json' });
  assert.strictEqual(blockedTraversal.ok, false);
  assert.strictEqual(blockedTraversal.status, 403);

  const blockedEnv = await previewBridge.readSafeFilePreview({ path: '.env.production' });
  assert.strictEqual(blockedEnv.ok, false);
  assert.strictEqual(blockedEnv.status, 403);

  const blockedDevVars = await previewBridge.readSafeFilePreview({ path: '.dev.vars' });
  assert.strictEqual(blockedDevVars.ok, false);
  assert.strictEqual(blockedDevVars.status, 403);

  const blockedSqlite = await previewBridge.readSafeFilePreview({ path: 'cache.sqlite-wal' });
  assert.strictEqual(blockedSqlite.ok, false);
  assert.strictEqual(blockedSqlite.status, 403);

  const blockedOutside = await previewBridge.readSafeFilePreview({
    path: process.platform === 'win32' ? 'C:\\Windows\\System32\\drivers\\etc\\hosts' : '/etc/hosts'
  });
  assert.strictEqual(blockedOutside.ok, false);
  assert.strictEqual(blockedOutside.status, 403);

  // Ephemeral HTTP server adversarial check on handleHttpRequest (auth + sensitive preview + static dotfile block)
  previewBridge.verifyBridgeToken = (tok) => tok === 'smoke-test-bridge-token';
  const httpSrv = http.createServer((req, res) => {
    previewBridge.handleHttpRequest(req, res).catch((err) => {
      res.writeHead(500);
      res.end(String(err));
    });
  });
  await new Promise((resolve) => httpSrv.listen(0, '127.0.0.1', resolve));
  try {
    const port = httpSrv.address().port;
    const base = `http://127.0.0.1:${port}`;

    const unauthedRes = await fetch(`${base}/api/file-preview?path=remote.js`);
    assert.strictEqual(unauthedRes.status, 401, 'Unauthenticated GET /api/file-preview must return 401');

    const authedSecretRes = await fetch(`${base}/api/file-preview?path=.dev.vars`, {
      headers: { Authorization: 'Bearer smoke-test-bridge-token' }
    });
    assert.strictEqual(authedSecretRes.status, 403, 'Authenticated GET /api/file-preview for .dev.vars must return 403');

    const authedOkRes = await fetch(
      `${base}/api/file-preview?path=${encodeURIComponent(`file:///${path.join(ROOT, 'remote.js').replace(/\\/g, '/')}#L1-L5`)}`,
      { headers: { Authorization: 'Bearer smoke-test-bridge-token' } }
    );
    assert.strictEqual(authedOkRes.status, 200, 'Authenticated GET /api/file-preview for workspace file must return 200');
    const authedOkBody = await authedOkRes.json();
    assert.strictEqual(authedOkBody.ok, true);
    assert.strictEqual(authedOkBody.diffPatch, authedOkBody.gitDiff);

    const dotGitStaticRes = await fetch(`${base}/.git/config`);
    assert.strictEqual(dotGitStaticRes.status, 404, 'Static handler must block /.git/config with 404');

    const dotEnvStaticRes = await fetch(`${base}/.env`);
    assert.strictEqual(dotEnvStaticRes.status, 404, 'Static handler must block /.env with 404');

    const unauthedCapRes = await fetch(`${base}/api/studio-capabilities?workspaceId=theo-hub`);
    assert.strictEqual(unauthedCapRes.status, 401, 'Unauthenticated GET /api/studio-capabilities must return 401');

    const authedCapRes = await fetch(`${base}/api/studio-capabilities?workspaceId=theo-hub`, {
      headers: { Authorization: 'Bearer smoke-test-bridge-token' }
    });
    assert.strictEqual(authedCapRes.status, 200, 'Authenticated GET /api/studio-capabilities must return 200');
    const capBody = await authedCapRes.json();
    assert.strictEqual(capBody.ok, true);
    assert.ok(Array.isArray(capBody.checks) && capBody.checks.some((c) => c.id === 'syntax:remote.js'), 'Expected syntax:remote.js check discovered');
    assert.ok(Array.isArray(capBody.skills), 'Expected discovered skills array');
    assert.ok(Array.isArray(capBody.ports), 'Expected probed ports array');

    const badWsCapRes = await fetch(`${base}/api/studio-capabilities?workspaceId=../../etc`, {
      headers: { Authorization: 'Bearer smoke-test-bridge-token' }
    });
    assert.strictEqual(badWsCapRes.status, 403, 'Unknown/traversal workspaceId must return 403');

    const unauthedCheckRes = await fetch(`${base}/api/studio-check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ workspaceId: 'theo-hub', checkId: 'syntax:remote.js' })
    });
    assert.strictEqual(unauthedCheckRes.status, 401, 'Unauthenticated POST /api/studio-check must return 401');

    const injectedCheckRes = await fetch(`${base}/api/studio-check`, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer smoke-test-bridge-token',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ workspaceId: 'theo-hub', checkId: 'git:status; rm -rf /' })
    });
    assert.strictEqual(injectedCheckRes.status, 403, 'Injected checkId must be rejected with 403');

    const unknownCheckRes = await fetch(`${base}/api/studio-check`, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer smoke-test-bridge-token',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ workspaceId: 'theo-hub', checkId: 'arbitrary:command' })
    });
    assert.strictEqual(unknownCheckRes.status, 403, 'Unlisted checkId must be rejected with 403');

    const validCheckRes = await fetch(`${base}/api/studio-check`, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer smoke-test-bridge-token',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ workspaceId: 'theo-hub', checkId: 'syntax:remote.js' })
    });
    assert.strictEqual(validCheckRes.status, 200, 'Allowlisted syntax:remote.js check must return 200');
    const validCheckBody = await validCheckRes.json();
    assert.strictEqual(validCheckBody.ok, true);
    assert.strictEqual(validCheckBody.passed, true);

    const parsedDiags = remoteMod.parseCheckDiagnostics(
      `${path.join(ROOT, 'remote.js')}:142:9: SyntaxError: Unexpected token\n${path.join(ROOT, '.env')}:1:1: Secret leak`,
      ROOT
    );
    assert.strictEqual(parsedDiags.length, 1, 'Expected sensitive .env diagnostic filtered out and remote.js:142 retained');
    assert.strictEqual(parsedDiags[0].relPath, 'remote.js');
    assert.strictEqual(parsedDiags[0].line, 142);
  } finally {
    await new Promise((resolve) => httpSrv.close(resolve));
    previewBridge.dispose();
  }
  console.log('[PASS] Adversarial #4: >1.5MB thoughtBlocks/checkpoint/subagent parser + HTTP/static readSafeFilePreview traversal/secret guards');

  // 6. Adversarial Check #5: Stream-interruption auto-compact (/compact -> CHECKPOINT -> chunked resume) + loop guards
  const agyBridge = require(path.join(ROOT, 'compat', 'antigravity-hub-bridge.cjs'));
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": EOF'),
    true,
    'Go SSE : EOF must be recognized as transient network error'
  );
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('There was a network issue connecting to the server, please try again.'),
    true,
    'Generic network issue connecting to the server must be recognized as transient network error'
  );
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('http2: client connection force closed via ClientConn.Close'),
    true,
    'http2 client connection force closed must be recognized as transient network error'
  );
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('stream idle timeout (5m0s): context deadline exceeded'),
    false,
    'Pure stream idle timeout / context deadline exceeded alone must NOT be classified as transient'
  );
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('RESOURCE_EXHAUSTED: quota exceeded'),
    false,
    'Quota errors must NEVER be classified as transient'
  );

  const tmpBrainDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-smoke-brain-'));
  const prevBrainRoot = process.env.THEO_BRAIN_ROOT_DIR;
  process.env.THEO_BRAIN_ROOT_DIR = tmpBrainDir;
  try {
    const writeTranscript = (cid, stepObjs, mtimeSec) => {
      const logDir = path.join(tmpBrainDir, cid, '.system_generated', 'logs');
      fs.mkdirSync(logDir, { recursive: true });
      const file = path.join(logDir, 'transcript.jsonl');
      fs.writeFileSync(file, stepObjs.map((s) => JSON.stringify(s)).join('\n') + '\n', 'utf8');
      if (mtimeSec) {
        fs.utimesSync(file, mtimeSec, mtimeSec);
      }
    };
    const baseNow = 1794227000;
    const elevenHoursAgo = baseNow - 40000;
    const isoAt = (sec) => new Date(sec * 1000).toISOString();

    // 6a. Mixed retry sequence (stream interrupted + EOF + stream idle timeout + network issue) at 241.5k tokens & 11h age -> /compact
    writeTranscript(
      'cid-mixed-241k',
      [
        { step_index: 94, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(elevenHoursAgo - 300), content: '<USER_REQUEST>Redesign fleet dashboard</USER_REQUEST>' },
        { step_index: 95, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 240), input_tokens: 241501, content: '' },
        { step_index: 96, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 200), content: 'Error: The stream was interrupted. Please continue the task you were working on.' },
        { step_index: 97, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 150), input_tokens: 241533, content: '' },
        { step_index: 98, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 100), content: 'Error: Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": EOF' },
        { step_index: 99, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 50), content: 'Error: stream idle timeout (5m0s): context deadline exceeded' },
        { step_index: 100, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(elevenHoursAgo), content: 'Error: There was a network issue connecting to the server, please try again.' }
      ],
      elevenHoursAgo
    );
    const mixed241k = agyBridge.inspectCascadeInterruptedState('cid-mixed-241k', baseNow);
    assert.strictEqual(mixed241k.interrupted, true, '11h-old mixed stream-interruption sequence must be recoverable');
    assert.strictEqual(mixed241k.reason, 'transient_network_error');
    assert.strictEqual(mixed241k.needsCompactionFirst, true, '>=215k token stream interruption must trigger compaction first');
    assert.strictEqual(mixed241k.resumePrompt, '/compact');

    // 6b. Post-compact CHECKPOINT step with pendingPostCompactResume=true -> CHUNKED_STREAM_RESUME_PROMPT
    writeTranscript(
      'cid-post-compact',
      [
        { step_index: 112, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 20), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 113, type: 'CHECKPOINT', status: 'DONE', created_at: isoAt(baseNow - 10), input_tokens: 245036, content: '# Resuming from a compaction' }
      ],
      baseNow - 10
    );
    const postCompact = agyBridge.inspectCascadeInterruptedState('cid-post-compact', baseNow, {
      pendingPostCompactResume: true
    });
    assert.strictEqual(postCompact.interrupted, true);
    assert.strictEqual(postCompact.reason, 'post_compact_auto_resume');
    assert.strictEqual(postCompact.resumePrompt, agyBridge.CHUNKED_STREAM_RESUME_PROMPT);

    // 6c. Negative assertion #1: Pure stream idle timeout (without stream interruption / EOF) must NOT auto-resume
    writeTranscript(
      'cid-pure-timeout',
      [
        { step_index: 1, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: 'run' },
        { step_index: 2, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 120), content: 'Error: stream idle timeout (5m0s): context deadline exceeded' },
        { step_index: 3, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 60), content: 'Error: stream idle timeout (5m0s): context deadline exceeded' }
      ],
      baseNow - 60
    );
    const pureTimeout = agyBridge.inspectCascadeInterruptedState('cid-pure-timeout', baseNow);
    assert.strictEqual(pureTimeout.interrupted, false);
    assert.strictEqual(pureTimeout.reason, 'repeated_error_message');

    // 6d. Negative assertion #2: Loop guard after CHUNKED_STREAM_RESUME_PROMPT fails again -> repeated_error_message
    writeTranscript(
      'cid-chunked-loop-guard',
      [
        { step_index: 10, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 300), content: 'Error: The stream was interrupted.' },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>` },
        { step_index: 12, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(baseNow - 150), input_tokens: 190000, content: '' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: The stream was interrupted.' }
      ],
      baseNow - 90
    );
    const chunkedLoopGuard = agyBridge.inspectCascadeInterruptedState('cid-chunked-loop-guard', baseNow);
    assert.strictEqual(chunkedLoopGuard.interrupted, false, 'Must stop if CHUNKED_STREAM_RESUME_PROMPT is followed by another error');
    assert.strictEqual(chunkedLoopGuard.reason, 'repeated_error_message');

    // 6e. Negative assertion #3: Loop guard after /compact fails with ERROR_MESSAGE -> repeated_error_message
    writeTranscript(
      'cid-compact-loop-guard',
      [
        { step_index: 10, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 300), content: 'Error: The stream was interrupted.' },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 12, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(baseNow - 150), input_tokens: 242000, content: '' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: The stream was interrupted.' }
      ],
      baseNow - 90
    );
    const compactLoopGuard = agyBridge.inspectCascadeInterruptedState('cid-compact-loop-guard', baseNow);
    assert.strictEqual(compactLoopGuard.interrupted, false, 'Must stop if /compact is followed by an error');
    assert.strictEqual(compactLoopGuard.reason, 'repeated_error_message');

    // 6f. Negative assertion #4: Unanswered /compact USER_INPUT (and [/compact](slashCommand;compact)) must be treated as already_sent_continue
    assert.strictEqual(agyBridge.isAutoContinueUserPrompt('[/compact](slashCommand;compact)'), true);
    assert.strictEqual(
      agyBridge.isAutoContinueUserPrompt('<USER_REQUEST>\n[/compact](slashCommand;compact)\n</USER_REQUEST>'),
      true
    );
    writeTranscript(
      'cid-compact-pending',
      [
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 60), content: '<USER_REQUEST>[/compact](slashCommand;compact)</USER_REQUEST>' }
      ],
      baseNow - 60
    );
    const compactPending = agyBridge.inspectCascadeInterruptedState('cid-compact-pending', baseNow);
    assert.strictEqual(compactPending.interrupted, false);
    assert.strictEqual(compactPending.reason, 'already_sent_continue');

    // 6f-2. Negative assertion #5: Expired pendingCompactAt or out-of-window pendingCompactStepIndex must NOT fire post_compact_auto_resume on a later manual /compact
    const expiredPostCompact = agyBridge.inspectCascadeInterruptedState('cid-post-compact', baseNow, {
      pendingPostCompactResume: true,
      pendingCompactStepIndex: 111,
      pendingCompactAt: baseNow - 1200
    });
    assert.strictEqual(
      expiredPostCompact.interrupted,
      false,
      'Expired pendingPostCompactResume (>900s) must NOT auto-fire CHUNKED_STREAM_RESUME_PROMPT on a later manual /compact'
    );
    const farStepPostCompact = agyBridge.inspectCascadeInterruptedState('cid-post-compact', baseNow, {
      pendingPostCompactResume: true,
      pendingCompactStepIndex: 50,
      pendingCompactAt: baseNow - 30
    });
    assert.strictEqual(
      farStepPostCompact.interrupted,
      false,
      'Out-of-window pendingCompactStepIndex (>+4 steps) must NOT auto-fire post_compact_auto_resume'
    );

    // 6g. Behavioral test of sendDirectCascadeRpcMessage (/compact slashCommand item, paginated stepOffset, + missing userConfig rejection)
    let capturedRpcReq = null;
    const capturedStepsReqs = [];
    let mockSteps = [
      {
        type: 'CORTEX_STEP_TYPE_USER_INPUT',
        userInput: {
          userConfig: { plannerConfig: { planModel: 'MODEL_PLACEHOLDER_M417' } },
          userAgentSpec: { builtinAgent: { defaultAgent: { surface: 'AGENT_SURFACE_HUB' } } }
        }
      }
    ];
    const mockHubSrv = http.createServer((req, res) => {
      let body = '';
      req.on('data', (c) => (body += c));
      req.on('end', () => {
        if (req.url.endsWith('/GetCascadeTrajectorySteps')) {
          capturedStepsReqs.push(JSON.parse(body || '{}'));
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ steps: mockSteps }));
        } else if (req.url.endsWith('/SendUserCascadeMessage')) {
          capturedRpcReq = JSON.parse(body || '{}');
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end('{}');
        } else {
          res.writeHead(404);
          res.end();
        }
      });
    });
    await new Promise((resolve) => mockHubSrv.listen(0, '127.0.0.1', resolve));
    try {
      const mPort = mockHubSrv.address().port;
      const okCompact = await agyBridge.sendDirectCascadeRpcMessage(mPort, 'csrf-123', 'cid-1', {
        prompt: '/compact',
        stepHint: 111
      });
      assert.strictEqual(okCompact.ok, true);
      assert.strictEqual(okCompact.method, 'directRpc');
      assert.strictEqual(
        capturedStepsReqs[0]?.stepOffset,
        105,
        'sendDirectCascadeRpcMessage with stepHint=111 must query paginated tail stepOffset=105 first'
      );
      assert.strictEqual(capturedStepsReqs[0]?.stepLimit, 10);
      assert.strictEqual(capturedRpcReq.cascadeId, 'cid-1');
      assert.strictEqual(
        capturedRpcReq.items?.[0]?.item?.slashCommand?.info?.name,
        'compact',
        'sendDirectCascadeRpcMessage(/compact) must send SLASH_COMMAND_TYPE_SYSTEM compact item'
      );
      assert.strictEqual(
        capturedRpcReq.items?.[0]?.item?.slashCommand?.info?.type,
        'SLASH_COMMAND_TYPE_SYSTEM'
      );

      mockSteps = [];
      const noConfigRes = await agyBridge.sendDirectCascadeRpcMessage(mPort, 'csrf-123', 'cid-1', {
        prompt: '/compact'
      });
      assert.strictEqual(noConfigRes.ok, false, 'Missing userConfig must fail closed');
      assert.strictEqual(noConfigRes.reason, 'missing_user_config');

      // 6h. Steady-state checkAndResumeInterruptedCascades: unflushed STOP_REASON_CLIENT_STREAM_ERROR + orphaned PENDING tool steps + terminal live ERROR_MESSAGE -> /compact -> live CHECKPOINT -> CHUNKED_STREAM_RESUME_PROMPT
      const prevResumedPath = process.env.THEO_RESUMED_CASCADES_PATH;
      const tmpResumedPath = path.join(tmpBrainDir, 'bhf-resumed-cascades.json');
      process.env.THEO_RESUMED_CASCADES_PATH = tmpResumedPath;
      try {
        writeTranscript(
          'cid-stream-err-172',
          [
            {
              step_index: 1,
              type: 'USER_INPUT',
              status: 'DONE',
              created_at: isoAt(baseNow - 1200),
              content: '<USER_REQUEST>Check and resolve missing upgrades</USER_REQUEST>'
            },
            {
              step_index: 169,
              type: 'PLANNER_RESPONSE',
              status: 'DONE',
              created_at: isoAt(baseNow - 600),
              input_tokens: 249245,
              content: '',
              tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
            }
          ],
          baseNow - 600
        );
        const sentMessages = [];
        let liveTrajectorySteps = {
          0: {
            metadata: { stepIndex: 1 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE',
            userInput: {
              userConfig: { plannerConfig: { planModel: 'MODEL_PLACEHOLDER_M417' } },
              userAgentSpec: { builtinAgent: { defaultAgent: { surface: 'AGENT_SURFACE_HUB' } } }
            }
          },
          168: {
            metadata: { stepIndex: 168 },
            type: 'CORTEX_STEP_TYPE_CODE_ACTION',
            status: 'CORTEX_STEP_STATUS_DONE'
          },
          169: {
            metadata: { stepIndex: 169 },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: {
              stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR',
              toolCalls: [{ id: 'tc1', name: 'edit_file' }, { id: 'tc2', name: 'edit_file' }]
            }
          },
          170: {
            metadata: { stepIndex: 170 },
            type: 'CORTEX_STEP_TYPE_GENERIC',
            status: 'CORTEX_STEP_STATUS_PENDING'
          },
          171: {
            metadata: { stepIndex: 171 },
            type: 'CORTEX_STEP_TYPE_GENERIC',
            status: 'CORTEX_STEP_STATUS_PENDING'
          },
          172: {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                userErrorMessage: 'Agent execution terminated due to error.',
                shortError:
                  'agent executor error: generating and executing: stream reading error: http2: client connection force closed via ClientConn.Close'
              }
            }
          }
        };
        const cascadeSrv = http.createServer((req, res) => {
          let b = '';
          req.on('data', (c) => (b += c));
          req.on('end', () => {
            if (req.url.endsWith('/GetAllCascadeTrajectories')) {
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(
                JSON.stringify({
                  trajectorySummaries: {
                    'cid-stream-err-172': {
                      status: 'CASCADE_RUN_STATUS_IDLE',
                      stepCount: 173
                    }
                  }
                })
              );
            } else if (req.url.endsWith('/GetCascadeTrajectorySteps')) {
              const parsed = JSON.parse(b || '{}');
              const offset = Number(parsed.stepOffset || 0);
              const limit = Number(parsed.stepLimit || 50);
              const out = [];
              for (const [k, v] of Object.entries(liveTrajectorySteps)) {
                const idx = Number(k);
                if (idx >= offset && out.length < limit) {
                  out.push(v);
                }
              }
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ steps: out }));
            } else if (req.url.endsWith('/SendUserCascadeMessage')) {
              sentMessages.push(JSON.parse(b || '{}'));
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end('{}');
            } else {
              res.writeHead(404);
              res.end();
            }
          });
        });
        await new Promise((resolve) => cascadeSrv.listen(0, '127.0.0.1', resolve));
        try {
          const cPort = cascadeSrv.address().port;
          const bState = agyBridge.getBridgeState();
          bState.serverManager = { port: cPort, csrfToken: 'csrf-test' };
          bState.resumeCheckInFlight = false;

          // Step 1: Orphaned PENDING steps 170-171 followed by ERROR_MESSAGE 172 must NOT block recovery -> sends /compact
          const res1 = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(res1.resumed, 1, 'Expected cid-stream-err-172 to auto-compact despite orphaned PENDING tool steps');
          assert.strictEqual(sentMessages.length, 1);
          assert.strictEqual(sentMessages[0]?.items?.[0]?.item?.slashCommand?.info?.name, 'compact');
          const savedMap1 = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMap1['cid-stream-err-172']?.stepIndex, 172);
          assert.strictEqual(savedMap1['cid-stream-err-172']?.reason, 'auto_compact_before_resume');
          assert.strictEqual(savedMap1['cid-stream-err-172']?.pendingPostCompactResume, true);

          // Step 2: Once /compact finishes in live RPC at Step 174 (CHECKPOINT DONE), next tick sends CHUNKED_STREAM_RESUME_PROMPT
          liveTrajectorySteps[173] = {
            metadata: { stepIndex: 173 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE'
          };
          liveTrajectorySteps[174] = {
            metadata: { stepIndex: 174 },
            type: 'CORTEX_STEP_TYPE_CHECKPOINT',
            status: 'CORTEX_STEP_STATUS_DONE'
          };
          const res2 = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 15,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(res2.resumed, 1, 'Expected post-compact CHECKPOINT at step 174 to auto-resume with chunked prompt');
          assert.strictEqual(sentMessages.length, 2);
          assert.strictEqual(sentMessages[1]?.items?.[0]?.text, agyBridge.CHUNKED_STREAM_RESUME_PROMPT);
          const savedMap2 = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMap2['cid-stream-err-172']?.stepIndex, 174);
          assert.strictEqual(savedMap2['cid-stream-err-172']?.reason, 'post_compact_auto_resume');
          assert.strictEqual(Boolean(savedMap2['cid-stream-err-172']?.pendingPostCompactResume), false);

          // Step 3 (Negative assertion): Genuine active PENDING/RUNNING tail step with no subsequent ERROR_MESSAGE must NOT resume
          fs.unlinkSync(tmpResumedPath);
          delete liveTrajectorySteps[172];
          delete liveTrajectorySteps[173];
          delete liveTrajectorySteps[174];
          liveTrajectorySteps[169].plannerResponse.stopReason = 'STOP_REASON_TOOL_CALL';
          liveTrajectorySteps[170].status = 'CORTEX_STEP_STATUS_RUNNING';
          const resActive = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 30,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resActive.resumed, 0, 'Genuinely running tail step must NOT be double-resumed');
          assert.strictEqual(sentMessages.length, 2);

          // Step 4 (Negative assertion): Live ERROR_MESSAGE with quota/resource_exhausted must NOT auto-resume
          liveTrajectorySteps[170].status = 'CORTEX_STEP_STATUS_PENDING';
          liveTrajectorySteps[172] = {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                shortError: 'RESOURCE_EXHAUSTED: quota exceeded for model'
              }
            }
          };
          const resQuota = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 45,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resQuota.resumed, 0, 'Live quota exceeded ERROR_MESSAGE must NOT auto-resume');
          assert.strictEqual(sentMessages.length, 2);

          // Step 5 (Negative assertion): Unflushed live ERROR_MESSAGE after CHUNKED_STREAM_RESUME_PROMPT turn must NOT loop
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>Check and resolve missing upgrades</USER_REQUEST>'
              },
              {
                step_index: 168,
                type: 'CHECKPOINT',
                status: 'DONE',
                created_at: isoAt(baseNow - 800),
                content: '# Resuming from compaction'
              },
              {
                step_index: 169,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 700),
                content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>`
              },
              {
                step_index: 170,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 600),
                input_tokens: 185000,
                content: 'Applying patch in chunks:',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 600
          );
          liveTrajectorySteps[169].plannerResponse.stopReason = 'STOP_REASON_CLIENT_STREAM_ERROR';
          liveTrajectorySteps[172] = {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                shortError: 'stream reading error: http2: client connection force closed via ClientConn.Close'
              }
            }
          };
          const resLoopGuard = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 60,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resLoopGuard.resumed,
            0,
            'Unflushed live ERROR_MESSAGE after CHUNKED_STREAM_RESUME_PROMPT turn must NOT loop'
          );
          assert.strictEqual(sentMessages.length, 2);

          // Step 6: Freshly booted hub (bypassMinAge=true) + PLANNER_RESPONSE with preface content + tool_calls still verifies live stepIndex=172
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>Check and resolve missing upgrades</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 5),
                input_tokens: 249245,
                content: 'Applying the final two edits now:',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 5
          );
          const resFreshBoot = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 10,
            bypassMinAge: true,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resFreshBoot.resumed, 1, 'Freshly booted hub must still verify live steps and compact');
          const savedMapFresh = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(
            savedMapFresh['cid-stream-err-172']?.stepIndex,
            172,
            'Freshly booted hub must record liveVerifiedMaxIdx=172 instead of stale transcript stepIndex=169'
          );

          // Step 7: Mid-prose stream error (lToolCalls.length === 0 in transcript.jsonl, unflushed STOP_REASON_CLIENT_STREAM_ERROR + live ERROR_MESSAGE at step 1155 like 87213501) -> auto-resumes!
          fs.unlinkSync(tmpResumedPath);
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>WTC vs SharePoint Cash Flow Discrepancy</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 30),
                input_tokens: 120554,
                content: 'The root cause of the discrepancy is:\n- **Manufacturing (WTC, BBConstruction & Holding (',
                tool_calls: []
              }
            ],
            baseNow - 30
          );
          delete liveTrajectorySteps[170];
          delete liveTrajectorySteps[171];
          liveTrajectorySteps[169] = {
            metadata: { stepIndex: 169, modelUsage: { inputTokens: 16927, cacheReadTokens: 103627 } },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: {
              stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR',
              response: 'The root cause of the discrepancy is:\n- **Manufacturing (WTC, BBConstruction & Holding ('
            }
          };
          liveTrajectorySteps[172] = {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                errorCode: 2,
                userErrorMessage: 'Agent execution terminated due to error.',
                shortError:
                  'agent executor error: generating and executing: stream reading error: http2: client connection force closed via ClientConn.Close'
              }
            }
          };
          const prevSentLen = sentMessages.length;
          const resMidProse = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resMidProse.resumed,
            1,
            'Unflushed live STOP_REASON_CLIENT_STREAM_ERROR + ERROR_MESSAGE after prose-only PLANNER_RESPONSE must auto-resume'
          );
          assert.strictEqual(sentMessages.length, prevSentLen + 1);
          assert.strictEqual(sentMessages[sentMessages.length - 1]?.items?.[0]?.text, 'continue');
          const savedMapMidProse = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMapMidProse['cid-stream-err-172']?.stepIndex, 172);
          assert.strictEqual(savedMapMidProse['cid-stream-err-172']?.reason, 'error_message');

          // Step 8 (Negative assertion): Normal completed prose PLANNER_RESPONSE (STOP_REASON_STOP_PATTERN, no live ERROR_MESSAGE) must NOT auto-resume and must cache completed_prose_verified
          fs.unlinkSync(tmpResumedPath);
          delete liveTrajectorySteps[172];
          liveTrajectorySteps[169] = {
            metadata: { stepIndex: 169, modelUsage: { inputTokens: 16927, cacheReadTokens: 103627 } },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: {
              stopReason: 'STOP_REASON_STOP_PATTERN',
              response: 'Complete answer finished normally.'
            }
          };
          const resNormalProse = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 10,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resNormalProse.resumed,
            0,
            'Normal completed prose PLANNER_RESPONSE (STOP_REASON_STOP_PATTERN) must NEVER be auto-resumed'
          );
          assert.strictEqual(
            bState.__bhfVerifiedIdleProseCache instanceof Map &&
              bState.__bhfVerifiedIdleProseCache.has('cid-stream-err-172'),
            true,
            'Normal completed prose PLANNER_RESPONSE must be cached in __bhfVerifiedIdleProseCache so subsequent polls skip RPC'
          );

          // Step 8b (Negative assertion): Earlier error step superseded by a subsequent USER_INPUT + completed PLANNER_RESPONSE (or empty verifySteps) must NEVER auto-resume
          bState.__bhfVerifiedIdleProseCache.clear();
          liveTrajectorySteps[169] = {
            metadata: { stepIndex: 169 },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: { stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR' }
          };
          liveTrajectorySteps[172] = {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: { error: { shortError: 'http2: client connection force closed via ClientConn.Close' } }
          };
          liveTrajectorySteps[173] = {
            metadata: { stepIndex: 173 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE',
            userInput: { userResponse: 'continue' }
          };
          liveTrajectorySteps[174] = {
            metadata: { stepIndex: 174 },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: {
              stopReason: 'STOP_REASON_STOP_PATTERN',
              response: 'Resumed and finished cleanly.'
            }
          };
          const resSupersededError = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 20,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resSupersededError.resumed,
            0,
            'Negative: Earlier error step superseded by subsequent USER_INPUT + completed PLANNER_RESPONSE must NEVER auto-resume'
          );

          bState.__bhfVerifiedIdleProseCache.clear();
          liveTrajectorySteps = {};
          const resEmptyVerify = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 30,
            hubStartedAtSec: baseNow + 25,
            bypassMinAge: true,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resEmptyVerify.resumed,
            0,
            'Negative: Empty verifySteps on unflushed_live_stream_error must fail closed (resumed=0)'
          );

          // Step 8c: Exact a99d759e / 89e11fe5-811->813 scenario: plain "continue" (USER_INPUT) on disk followed by unflushed live ERROR_MESSAGE during Wi-Fi roam
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>Theo Avatar Redesign and Upgrade</USER_REQUEST>'
              },
              {
                step_index: 168,
                type: 'GENERIC',
                status: 'DONE',
                created_at: isoAt(baseNow - 60),
                content: 'Showing lines 2900-3540 of 4308'
              },
              {
                step_index: 169,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 45),
                error: 'wsarecv: A connection attempt failed because the connected party did not properly respond'
              },
              {
                step_index: 170,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 40),
                content: '<USER_REQUEST>\ncontinue\n</USER_REQUEST>'
              }
            ],
            baseNow - 40
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 169,
                reason: 'error_message',
                resumedAt: baseNow - 40
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            169: {
              metadata: { stepIndex: 169 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  shortError:
                    'Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": net/http: cannot rewind body after connection loss'
                }
              }
            },
            170: {
              metadata: { stepIndex: 170 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: {
                userResponse: 'continue',
                userConfig: { plannerConfig: { planModel: 'MODEL_PLACEHOLDER_M42' } }
              }
            },
            172: {
              metadata: { stepIndex: 172 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  userErrorMessage: 'Agent execution terminated due to error.',
                  shortError:
                    'agent executor error: generating and executing: request failed: Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": http2: client connection force closed via ClientConn.Close'
                }
              }
            }
          };
          const resWifiOffline = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 35,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => false
          });
          assert.strictEqual(
            resWifiOffline.resumed,
            0,
            'Negative: Must NOT send second-chance resume while networkOnlineCheck reports offline'
          );
          const sentBefore8c = sentMessages.length;
          const resAfterContinueErr = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 35,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resAfterContinueErr.resumed,
            1,
            'Unflushed live ERROR_MESSAGE after plain auto-continue must promote to CHUNKED_STREAM_RESUME_PROMPT once online'
          );
          assert.strictEqual(sentMessages.length, sentBefore8c + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT
          );
          const savedMap8c = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMap8c['cid-stream-err-172']?.stepIndex, 172);

          // Step 9: notifyCascadeTerminatedError debounce & empty-ID negative guard + syncActiveTurnWakeLock & ensureWindowsStandbyNetworkGuard lifecycle
          assert.strictEqual(
            agyBridge.notifyCascadeTerminatedError(bState, ''),
            false,
            'Empty cascadeId in notifyCascadeTerminatedError must return false'
          );
          assert.strictEqual(
            agyBridge.notifyCascadeTerminatedError(bState, 'cid-term-banner-1'),
            true,
            'First notifyCascadeTerminatedError for cid must return true'
          );
          assert.strictEqual(
            agyBridge.notifyCascadeTerminatedError(bState, 'cid-term-banner-1'),
            false,
            'Duplicate notifyCascadeTerminatedError within 15s cooldown must return false'
          );

          let wakeSpawnCount = 0;
          let wakeEndedCount = 0;
          const mockWakeSpawner = () => {
            wakeSpawnCount += 1;
            const fakeChild = {
              exitCode: null,
              killed: false,
              stdin: {
                end() {
                  wakeEndedCount += 1;
                  fakeChild.exitCode = 0;
                }
              },
              kill() {
                fakeChild.killed = true;
                fakeChild.exitCode = 0;
              },
              on() {},
              unref() {}
            };
            return fakeChild;
          };
          const w1 = agyBridge.syncActiveTurnWakeLock(bState, true, {
            nowMs: 100000,
            spawnWakeLockProcess: mockWakeSpawner
          });
          assert.strictEqual(w1.active, true);
          assert.strictEqual(w1.spawned, true);
          assert.strictEqual(wakeSpawnCount, 1);

          const wGrace = agyBridge.syncActiveTurnWakeLock(bState, false, {
            nowMs: 105000,
            releaseGraceMs: 15000,
            spawnWakeLockProcess: mockWakeSpawner
          });
          assert.strictEqual(wGrace.active, true, 'Wake lock must hold during 15s grace window');
          assert.strictEqual(wGrace.graceHold, true);
          assert.strictEqual(wakeEndedCount, 0);

          const wRelease = agyBridge.syncActiveTurnWakeLock(bState, false, {
            nowMs: 120000,
            releaseGraceMs: 15000,
            spawnWakeLockProcess: mockWakeSpawner
          });
          assert.strictEqual(wRelease.active, false, 'Wake lock must release once grace window expires');
          assert.strictEqual(wRelease.released, true);
          assert.strictEqual(wakeEndedCount, 1);

          let capturedPowerScript = '';
          const pg1 = agyBridge.ensureWindowsStandbyNetworkGuard(bState, {
            nowMs: 200000,
            minIntervalMs: 600000,
            powerGuardRunner: (script) => {
              capturedPowerScript = script;
            }
          });
          assert.strictEqual(pg1, true);
          assert.ok(capturedPowerScript.includes('9d7815a6-7ee4-497e-8888-515a05f02364'), 'Power guard must disable HIBERNATEIDLE');
          assert.ok(capturedPowerScript.includes('f15576e8-98b7-4186-b944-eafa664402d9'), 'Power guard must enable CONNECTIVITYINSTANDBY');
          const pgRateLimited = agyBridge.ensureWindowsStandbyNetworkGuard(bState, {
            nowMs: 250000,
            minIntervalMs: 600000,
            powerGuardRunner: () => {}
          });
          assert.strictEqual(pgRateLimited, false, 'Negative: ensureWindowsStandbyNetworkGuard must rate-limit within minIntervalMs');
        } finally {
          await new Promise((resolve) => cascadeSrv.close(resolve));
        }
      } finally {
        if (prevResumedPath === undefined) {
          delete process.env.THEO_RESUMED_CASCADES_PATH;
        } else {
          process.env.THEO_RESUMED_CASCADES_PATH = prevResumedPath;
        }
      }
    } finally {
      await new Promise((resolve) => mockHubSrv.close(resolve));
    }
  } finally {
    if (prevBrainRoot === undefined) {
      delete process.env.THEO_BRAIN_ROOT_DIR;
    } else {
      process.env.THEO_BRAIN_ROOT_DIR = prevBrainRoot;
    }
    fs.rmSync(tmpBrainDir, { recursive: true, force: true });
  }
  console.log('[PASS] Adversarial #5: Stream-interruption auto-compact (/compact -> CHECKPOINT -> chunked resume) + loop guards');

  // ---------------------------------------------------------------------------
  // Adversarial Check #6: v62 Antigravity PlanModel Enum Resolution
  // (MODEL_PLACEHOLDER_M417..M419 / M318..M320 / M400..M405) & Cloudflare DO
  // SQLite thread_cache (<25ms Edge fallback when hosts are offline)
  // ---------------------------------------------------------------------------
  assert.strictEqual(
    remoteMod.formatModelDisplayName('MODEL_PLACEHOLDER_M417'),
    'Gemini 4 Argon (High)',
    'MODEL_PLACEHOLDER_M417 must format to Gemini 4 Argon (High)'
  );
  assert.strictEqual(
    remoteMod.formatModelDisplayName('MODEL_PLACEHOLDER_M319'),
    'Gemini 3.8 Flash (Medium)',
    'MODEL_PLACEHOLDER_M319 must format to Gemini 3.8 Flash (Medium)'
  );
  assert.strictEqual(
    remoteMod.formatModelDisplayName('MODEL_PLACEHOLDER_M400'),
    'Claude Opus 5.5 (Low)',
    'MODEL_PLACEHOLDER_M400 must format to Claude Opus 5.5 (Low)'
  );
  assert.strictEqual(
    remoteMod.resolveAntigravityPlanModelEnum('gemini-4-argon', 'low'),
    'MODEL_PLACEHOLDER_M419',
    'gemini-4-argon + low must resolve to MODEL_PLACEHOLDER_M419'
  );
  assert.strictEqual(
    remoteMod.resolveAntigravityPlanModelEnum('gemini-3.8-flash', 'medium'),
    'MODEL_PLACEHOLDER_M319',
    'gemini-3.8-flash + medium must resolve to MODEL_PLACEHOLDER_M319'
  );
  assert.strictEqual(
    remoteMod.resolveAntigravityPlanModelEnum('<img src=x onerror=alert(1)>', 'bogus'),
    '',
    'Negative: Hostile/unknown model string must return empty enum string'
  );

  // Test Cloudflare DO SQLite thread_cache (v2.2)
  const cacheDb = new DatabaseSync(':memory:');
  const cacheSql = {
    exec(query, ...params) {
      if (params.length === 0 && !/^\s*SELECT\b/i.test(query)) {
        cacheDb.exec(query);
        return [];
      }
      const stmt = cacheDb.prepare(query);
      if (/^\s*SELECT\b/i.test(query)) {
        return stmt.all(...params);
      }
      stmt.run(...params);
      return [];
    }
  };
  const cacheRoom = new TheoRelayRoom(
    {
      getWebSockets: () => [],
      storage: {
        sql: cacheSql,
        getAlarm: async () => null,
        setAlarm: async () => {}
      }
    },
    { AUTH_TOKEN: roomAuthToken }
  );
  cacheRoom._saveThreadDetail(
    'sess-edge-cached-1',
    'theo-laptop',
    {
      id: 'sess-edge-cached-1',
      provider: 'antigravity',
      title: 'Edge Cached Conversation',
      messages: [{ id: 'm1', role: 'assistant', text: 'Served from Cloudflare Edge SQLite' }]
    }
  );
  const cachedEntry = cacheRoom._getCachedThreadDetail('sess-edge-cached-1');
  assert.ok(cachedEntry && cachedEntry.detail, 'Edge DO SQLite thread_cache must store and retrieve thread payload');
  assert.strictEqual(cachedEntry.detail.title, 'Edge Cached Conversation');
  assert.strictEqual(
    cacheRoom._getCachedThreadDetail('non-existent-thread'),
    null,
    'Negative: Missing thread_cache entry must return null'
  );
  cacheDb.close();

  // Test findActiveCascadesFromDiskTranscripts with both (3600) and (Date.now(), { maxInterruptedAgeMs: 3600000 })
  const hubBridgeMod = require('../compat/antigravity-hub-bridge.cjs');
  const tmpContinuityBrainDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-brain-cont-'));
  const prevContinuityBrainRoot = process.env.THEO_BRAIN_ROOT_DIR;
  try {
    process.env.THEO_BRAIN_ROOT_DIR = tmpContinuityBrainDir;
    const mockCascadeId = '11111111-2222-3333-4444-555555555555';
    const mockLogsDir = path.join(tmpContinuityBrainDir, mockCascadeId, '.system_generated', 'logs');
    fs.mkdirSync(mockLogsDir, { recursive: true });
    const mockTranscriptPath = path.join(mockLogsDir, 'transcript.jsonl');
    const stepCreatedAt = new Date(Date.now() - 180 * 1000).toISOString();
    fs.writeFileSync(
      mockTranscriptPath,
      `${JSON.stringify({
        step_index: 1,
        source: 'USER_EXPLICIT',
        type: 'USER_INPUT',
        status: 'DONE',
        created_at: stepCreatedAt,
        content: 'Continue long task while VS Code is closed'
      })}\n`,
      'utf8'
    );
    const mtimeDate = new Date(Date.now() - 180 * 1000);
    fs.utimesSync(mockTranscriptPath, mtimeDate, mtimeDate);
    const bySecArg = hubBridgeMod.findActiveCascadesFromDiskTranscripts(3600);
    const byOptions = hubBridgeMod.findActiveCascadesFromDiskTranscripts(Date.now(), {
      maxInterruptedAgeMs: 3600 * 1000
    });
    assert.ok(
      bySecArg.includes(mockCascadeId),
      'findActiveCascadesFromDiskTranscripts(3600) must treat <1e11 first arg as maxAgeSec and find 180s-old interrupted cascade'
    );
    assert.ok(
      byOptions.includes(mockCascadeId),
      'findActiveCascadesFromDiskTranscripts(Date.now(), { maxInterruptedAgeMs: 3600000 }) must find 180s-old interrupted cascade'
    );
  } finally {
    if (prevContinuityBrainRoot === undefined) delete process.env.THEO_BRAIN_ROOT_DIR;
    else process.env.THEO_BRAIN_ROOT_DIR = prevContinuityBrainRoot;
    try {
      fs.rmSync(tmpContinuityBrainDir, { recursive: true, force: true });
    } catch {}
  }

  console.log('[PASS] Adversarial #6: v62 Antigravity PlanModel Enum Resolution, Headless Cascade Continuity & Cloudflare DO SQLite thread_cache verified');

  // 14. Adversarial #7: Desktop App Launcher, Multi-Frame ICO, Hostile Input Rejection, Quarantine & v(N-1)->v(N) Lifecycle
  const desktopLauncher = require('../desktop-launcher');
  const icoPath = path.join(ROOT, 'resources', 'theo.ico');
  assert.ok(fs.existsSync(icoPath), 'resources/theo.ico must exist');
  const icoCheck = desktopLauncher.validateIcoBuffer(fs.readFileSync(icoPath));
  assert.strictEqual(icoCheck.valid, true, 'resources/theo.ico must be a valid ICO container');
  assert.strictEqual(icoCheck.frameCount, 6, 'resources/theo.ico must pack all 6 resolution frames (16..256)');

  // Negative ICO bounds
  assert.strictEqual(desktopLauncher.validateIcoBuffer(Buffer.from('not-an-ico')).valid, false);
  assert.strictEqual(desktopLauncher.validateIcoBuffer(Buffer.alloc(22, 0)).valid, false);

  // Negative URL & CLI argument injection checks
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('http://127.0.0.1:4318/'), 'http://127.0.0.1:4318/');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('https://husseinbdeir.github.io/theo/'), 'https://husseinbdeir.github.io/theo/');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('javascript:alert(1)'), null, 'Must reject javascript: URL');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('file:///C:/Windows/System32/calc.exe'), null, 'Must reject file: URL');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('http://evil.example.com/theo'), null, 'Must reject non-loopback http: URL');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('https://husseinbdeir.github.io/theo/" --gpu-launcher="calc.exe'), null, 'Must reject embedded quotes');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('https://user:pass@husseinbdeir.github.io/theo/'), null, 'Must reject URL credentials');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('https://husseinbdeir.github.io/theo/#pair=secret123'), null, 'Must reject #pair= secret in shortcut args');
  assert.throws(
    () => desktopLauncher.buildBrowserAppArguments('javascript:alert(1)'),
    /invalid URL/i,
    'buildBrowserAppArguments must throw on hostile URL'
  );

  // Negative Hotkey validation checks
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Ctrl+Alt+t'), 'Ctrl+Alt+T');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Alt+Ctrl+Shift+t'), 'Ctrl+Alt+Shift+T');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('none'), '');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey(''), '');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('T'), null, 'Must reject bare single-letter hotkey');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Ctrl+T'), null, 'Must reject single-modifier letter hotkey that hijacks normal Ctrl+T');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Ctrl+Alt+T; calc.exe'), null, 'Must reject hotkey with command injection');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Ctrl+Ctrl+T'), null, 'Must reject duplicate modifier');

  // Negative Quarantine check: THEO_SMOKE_TEST=1 must refuse touching real Desktop/Start Menu
  assert.throws(
    () => desktopLauncher.installDesktopShortcuts({}),
    /Quarantine violation/i,
    'installDesktopShortcuts must fail closed in THEO_SMOKE_TEST=1 when sandbox dirs are omitted'
  );
  assert.throws(
    () => desktopLauncher.uninstallDesktopShortcuts({}),
    /Quarantine violation/i,
    'uninstallDesktopShortcuts must fail closed in THEO_SMOKE_TEST=1 when sandbox dirs are omitted'
  );

  // Full sandbox lifecycle: Create -> Idempotent Skip -> v(N-1)->v(N) legacy shortcut cleanup -> Uninstall
  const tmpShortcutRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-desktop-lnk-'));
  try {
    const sbHome = path.join(tmpShortcutRoot, 'home');
    const sbDesktop = path.join(tmpShortcutRoot, 'Desktop');
    const sbPrograms = path.join(tmpShortcutRoot, 'Programs');
    const sbTaskbar = path.join(tmpShortcutRoot, 'TaskBar');
    const sbPwa = path.join(tmpShortcutRoot, 'theo-pwa');
    fs.mkdirSync(sbDesktop, { recursive: true });
    fs.mkdirSync(sbPrograms, { recursive: true });
    fs.mkdirSync(sbTaskbar, { recursive: true });
    fs.mkdirSync(sbPwa, { recursive: true });
    fs.writeFileSync(path.join(sbPwa, 'index.html'), '<!doctype html><title>THEO</title>', 'utf8');

    // Seed pre-upgrade legacy shortcuts + pre-pinned v1 TaskBar THEO.lnk to verify v(N-1)->v(N) upgrade continuity
    fs.writeFileSync(path.join(sbDesktop, 'THEO Remote.lnk'), 'legacy', 'utf8');
    fs.writeFileSync(path.join(sbPrograms, 'THEO Studio.lnk'), 'legacy', 'utf8');
    fs.writeFileSync(path.join(sbTaskbar, 'THEO.lnk'), 'v1-pinned-msedge-lnk', 'utf8');
    fs.mkdirSync(path.join(sbHome, '.theo'), { recursive: true });
    fs.writeFileSync(
      path.join(sbHome, '.theo', 'desktop-shortcut.json'),
      JSON.stringify({
        version: 1,
        shortcutName: 'THEO.lnk',
        targetPath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        arguments: '--app="http://127.0.0.1:4318/"',
        url: 'http://127.0.0.1:4318/',
        hotkey: 'Ctrl+Alt+T',
        desktopShortcutPath: path.join(sbDesktop, 'THEO.lnk'),
        startMenuShortcutPath: path.join(sbPrograms, 'THEO.lnk')
      }),
      'utf8'
    );

    const firstInstall = desktopLauncher.installDesktopShortcuts({
      hubRoot: ROOT,
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar,
      pwaRoot: sbPwa,
      port: 4318,
      hotkey: 'Ctrl+Alt+T'
    });
    assert.strictEqual(firstInstall.ok, true);
    assert.strictEqual(firstInstall.skipped, false, 'v1 msedge.exe state must upgrade to v2 THEO.exe without skipping');
    assert.strictEqual(firstInstall.version, 2);
    assert.strictEqual(firstInstall.appUserModelId, 'BHFIRMS.THEO.Desktop');
    assert.strictEqual(firstInstall.url, 'http://127.0.0.1:4318/');
    assert.strictEqual(firstInstall.targetPath, firstInstall.launcherExePath, 'Shortcut TargetPath must be native THEO.exe, never msedge.exe');
    assert.strictEqual(firstInstall.arguments, '', 'Shortcut Arguments must be empty so Windows Taskbar never strips --app');
    assert.ok(fs.existsSync(firstInstall.launcherExePath), 'Compiled ~/.theo/THEO.exe must exist');
    assert.ok(fs.existsSync(firstInstall.desktopShortcutPath), 'Desktop THEO.lnk must be created');
    assert.ok(fs.existsSync(firstInstall.startMenuShortcutPath), 'Start Menu THEO.lnk must be created');
    assert.ok(fs.existsSync(firstInstall.taskbarShortcutPath), 'Pinned TaskBar THEO.lnk must be upgraded in-place');
    assert.ok(fs.existsSync(firstInstall.iconPath), 'Stable ~/.theo/theo.ico must be created');
    assert.ok(fs.existsSync(path.join(firstInstall.profileDir, 'First Run')), 'Isolated app-profile First Run sentinel must be pre-seeded');
    assert.strictEqual(fs.existsSync(path.join(sbDesktop, 'THEO Remote.lnk')), false, 'Legacy THEO Remote.lnk must be cleaned up');
    assert.strictEqual(fs.existsSync(path.join(sbPrograms, 'THEO Studio.lnk')), false, 'Legacy THEO Studio.lnk must be cleaned up');

    // Verify .lnk PropertyStore (1SPS) contains BHFIRMS.THEO.Desktop AUMID in UTF-16LE
    const aumidUtf16 = Buffer.from('BHFIRMS.THEO.Desktop', 'utf16le');
    for (const lnkFile of [
      firstInstall.desktopShortcutPath,
      firstInstall.startMenuShortcutPath,
      firstInstall.taskbarShortcutPath
    ]) {
      const lnkBytes = fs.readFileSync(lnkFile);
      assert.ok(
        lnkBytes.includes(aumidUtf16),
        `${path.basename(lnkFile)} in ${path.basename(path.dirname(lnkFile))} must embed BHFIRMS.THEO.Desktop AUMID in PropertyStore`
      );
    }

    // Verify compiled THEO.exe --verify-config and quarantine enforcement
    const quarantineRun = spawnSync(firstInstall.launcherExePath, [], {
      env: { ...process.env, THEO_SMOKE_TEST: '1' },
      encoding: 'utf8',
      timeout: 8000,
      windowsHide: true
    });
    assert.strictEqual(
      quarantineRun.status,
      2,
      'Negative: THEO.exe without --verify-config must fail closed (exit 2) under THEO_SMOKE_TEST=1'
    );

    const verifyRun = spawnSync(
      firstInstall.launcherExePath,
      ['--verify-config', '--state-file', firstInstall.stateFilePath],
      {
        env: { ...process.env, THEO_SMOKE_TEST: '1' },
        encoding: 'utf8',
        timeout: 8000,
        windowsHide: true
      }
    );
    assert.strictEqual(verifyRun.status, 0, 'THEO.exe --verify-config must succeed');
    const verifyJson = JSON.parse(verifyRun.stdout.trim());
    assert.strictEqual(verifyJson.ok, true);
    assert.strictEqual(verifyJson.url, 'http://127.0.0.1:4318/');
    assert.strictEqual(verifyJson.profileDir, firstInstall.profileDir);
    assert.strictEqual(
      verifyJson.appUserModelId,
      'BHFIRMS.THEO.Desktop',
      'THEO.exe --verify-config must report canonical BHFIRMS.THEO.Desktop AUMID without host registry pollution'
    );

    const secondInstall = desktopLauncher.installDesktopShortcuts({
      hubRoot: ROOT,
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar,
      pwaRoot: sbPwa,
      port: 4318,
      hotkey: 'Ctrl+Alt+T'
    });
    assert.strictEqual(secondInstall.skipped, true, 'Repeat install with identical spec must fast-skip');

    // Reversibility check: updating existing shortcut with hotkey: '' (-NoHotkey) must clear Hotkey in the .lnk binary on disk
    const clearedHotkeyInstall = desktopLauncher.installDesktopShortcuts({
      hubRoot: ROOT,
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar,
      pwaRoot: sbPwa,
      port: 4318,
      hotkey: ''
    });
    assert.strictEqual(clearedHotkeyInstall.skipped, false, 'Changing hotkey to empty must re-save shortcut');
    assert.strictEqual(clearedHotkeyInstall.hotkey, '');

    // M-1 check: subsequent background run with hotkey: undefined (simulating relay_keepalive_start.ps1 -Quiet)
    // MUST preserve the user's saved hotkey: '' preference rather than resetting to 'Ctrl+Alt+T'
    const backgroundKeepaliveInstall = desktopLauncher.installDesktopShortcuts({
      hubRoot: ROOT,
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar,
      pwaRoot: sbPwa,
      port: 4318
    });
    assert.strictEqual(backgroundKeepaliveInstall.hotkey, '', 'Background install must preserve saved -NoHotkey preference');
    assert.strictEqual(backgroundKeepaliveInstall.skipped, true, 'Background install with unchanged saved preference must fast-skip');

    // Missing local PWA directory must fall back cleanly to HTTPS PWA URL
    const fallbackUrl = desktopLauncher.resolveDesktopLaunchUrl({
      pwaRoot: path.join(tmpShortcutRoot, 'missing-pwa'),
      port: 4318
    });
    assert.strictEqual(fallbackUrl, 'https://husseinbdeir.github.io/theo/');

    const uninstallRes = desktopLauncher.uninstallDesktopShortcuts({
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar
    });
    assert.strictEqual(uninstallRes.ok, true);
    assert.strictEqual(uninstallRes.removedShortcuts.length, 3);
    assert.strictEqual(uninstallRes.removedStateFile, true);
    assert.strictEqual(uninstallRes.removedIconFile, true);
    assert.strictEqual(uninstallRes.removedLauncherExe, true);
    assert.strictEqual(fs.existsSync(firstInstall.desktopShortcutPath), false);
    assert.strictEqual(fs.existsSync(firstInstall.startMenuShortcutPath), false);
    assert.strictEqual(fs.existsSync(firstInstall.taskbarShortcutPath), false);
    assert.strictEqual(fs.existsSync(firstInstall.iconPath), false);
    assert.strictEqual(fs.existsSync(firstInstall.launcherExePath), false);
  } finally {
    try {
      fs.rmSync(tmpShortcutRoot, { recursive: true, force: true });
    } catch {}
  }

  console.log('[PASS] Adversarial #7: Desktop App Launcher, Multi-Frame ICO, Hostile Input Rejection, Quarantine & v(N-1)->v(N) Lifecycle verified');

  // 15. Adversarial #8: v63 Live Activity Descriptor & Dual wsHub/edgeClient thread_detail Streaming
  const liveBridge = new remoteMod.TheoRemoteBridge({});
  const idleAct = liveBridge.deriveLiveActivityDescriptor([], false, null);
  assert.strictEqual(idleAct.active, false, 'Negative: Idle session must return { active: false }');

  const readingAct = liveBridge.deriveLiveActivityDescriptor(
    [
      {
        role: 'assistant',
        thinking: 'Checking core3d.js',
        totalTurnTools: 4,
        toolCalls: [
          { kind: 'read', file: 'core3d.js', relPath: 'js/core3d.js', lineRange: 'L1-L80', summary: 'Read core3d.js' }
        ]
      }
    ],
    true,
    null
  );
  assert.strictEqual(readingAct.active, true);
  assert.strictEqual(readingAct.verb, 'Reading');
  assert.strictEqual(readingAct.file, 'core3d.js');
  assert.strictEqual(readingAct.label, 'Reading core3d.js');
  assert.strictEqual(readingAct.stepCount, 4);

  const thinkingOnlyAct = liveBridge.deriveLiveActivityDescriptor(
    [{ role: 'assistant', thinking: 'Synthesizing architecture...', toolCalls: [] }],
    true,
    { stepStatus: 'CORTEX_STEP_STATUS_GENERATING', thinking: 'Synthesizing architecture...', toolCalls: [] }
  );
  assert.strictEqual(thinkingOnlyAct.verb, 'Thinking…');
  assert.strictEqual(thinkingOnlyAct.target, '');

  // Negative #2: Malformed / non-assistant messages array must not throw and must fall back cleanly
  const malformedAct = liveBridge.deriveLiveActivityDescriptor(
    [null, undefined, { role: 'user', text: 'test prompt' }],
    true,
    null
  );
  assert.strictEqual(malformedAct.active, true);
  assert.strictEqual(malformedAct.verb, 'Thinking…');
  assert.strictEqual(malformedAct.stepCount, 0);

  // Negative #3: Path-traversal / non-UUID cascadeId on fetchLiveCascadeTailOverlay must return null immediately
  const traversalTail = await liveBridge.fetchLiveCascadeTailOverlay('../../../etc/passwd', 5);
  assert.strictEqual(traversalTail, null, 'Negative: Non-UUID cascadeId must be rejected by fetchLiveCascadeTailOverlay');
  console.log('[PASS] Adversarial #8: v63 Live Activity Descriptor (Reading / Editing / Thinking…) & 3 Negative Guards verified');

  // 16. Adversarial #9: Subagent Background-Task Settlement (subagentSummariesById + Disk ERROR_MESSAGE vs Active Running Subagent)
  const tmpSubHomeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-subagent-settle-'));
  try {
    const subBrainDir = path.join(tmpSubHomeDir, 'brain');
    const subBaseNow = Math.floor(Date.now() / 1000);
    const isoSub = (sec) => new Date(sec * 1000).toISOString();
    const writeSubBrainTranscript = (cid, lines, mtimeSec) => {
      const logDir = path.join(subBrainDir, cid, '.system_generated', 'logs');
      fs.mkdirSync(logDir, { recursive: true });
      const p = path.join(logDir, 'transcript.jsonl');
      fs.writeFileSync(p, lines.map((l) => JSON.stringify(l)).join('\n') + '\n', 'utf8');
      const d = new Date(mtimeSec * 1000);
      fs.utimesSync(p, d, d);
    };

    const subStore = new AntigravityDataStore();
    subStore.readUserCancelledCascades = () => ({});

    // Positive #1: Fast (<15s) parent yield after invoke_subagent settles when subagentSummariesById reports IDLE
    const fastParentCid = 'aaaa1111-2222-3333-4444-555555555551';
    const fastSubCid = '2f49c9aa-5d75-4b9e-a18d-29cb75182652';
    writeSubBrainTranscript(
      fastParentCid,
      [
        { step_index: 1, type: 'USER_INPUT', status: 'DONE', created_at: isoSub(subBaseNow - 12), content: 'Audit codebase' },
        {
          step_index: 2,
          type: 'PLANNER_RESPONSE',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 10),
          content: '',
          tool_calls: [{ id: 'tc1', name: 'default_api:invoke_subagent', arguments: '{"TypeName":"research","Role":"Auditor","Prompt":"Check files"}' }]
        },
        {
          step_index: 3,
          type: 'GENERIC',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 10),
          content: `{"conversationId":"${fastSubCid}"}`
        },
        {
          step_index: 4,
          type: 'PLANNER_RESPONSE',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 7),
          content: 'Waiting for subagent response.'
        }
      ],
      subBaseNow - 7
    );
    const agyMapFast = new Map([
      [
        fastParentCid,
        {
          id: fastParentCid,
          status: 'CASCADE_RUN_STATUS_IDLE',
          notFullyIdle: false,
          stepCount: 5,
          bgTask: null
        }
      ]
    ]);
    const subMapFast = new Map([
      [fastSubCid, { id: fastSubCid, rootId: fastParentCid, status: 'CASCADE_RUN_STATUS_IDLE', stepCount: 2, updatedAt: subBaseNow - 5 }]
    ]);
    const ctxFast = subStore._createTokenAnalyticsContext(
      tmpSubHomeDir,
      agyMapFast,
      new Map(),
      new Map(),
      subBaseNow * 1000,
      subMapFast
    );
    subStore._ingestSingleBrainEntry({ name: fastParentCid, isDirectory: () => true }, ctxFast);
    const settledFastThread = agyMapFast.get(fastParentCid);
    assert.strictEqual(
      settledFastThread.backgroundTasks?.[0]?.state,
      'completed',
      'Subagent with IDLE live RPC summary must settle to completed even when parent yielded within 3s'
    );
    assert.strictEqual(settledFastThread.bgTask, null, 'Settled subagent must clear parent bgTask');
    assert.strictEqual(settledFastThread.status, 'CASCADE_RUN_STATUS_IDLE');

    // Positive #2: Subagent whose own disk transcript ends on ERROR_MESSAGE settles even without RPC summary
    writeSubBrainTranscript(
      fastSubCid,
      [
        { step_index: 1, type: 'USER_INPUT', status: 'DONE', created_at: isoSub(subBaseNow - 10), content: 'Check files' },
        { step_index: 2, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoSub(subBaseNow - 6), content: 'Error Unknown: Agent execution terminated due to error.' }
      ],
      subBaseNow - 6
    );
    const agyMapDiskErr = new Map([
      [
        fastParentCid,
        {
          id: fastParentCid,
          status: 'CASCADE_RUN_STATUS_IDLE',
          notFullyIdle: false,
          stepCount: 5,
          bgTask: null
        }
      ]
    ]);
    const ctxDiskErr = subStore._createTokenAnalyticsContext(
      tmpSubHomeDir,
      agyMapDiskErr,
      new Map(),
      new Map(),
      subBaseNow * 1000,
      new Map()
    );
    subStore._ingestSingleBrainEntry({ name: fastParentCid, isDirectory: () => true }, ctxDiskErr);
    assert.strictEqual(
      agyMapDiskErr.get(fastParentCid).backgroundTasks?.[0]?.state,
      'completed',
      'Subagent whose disk transcript ends on ERROR_MESSAGE must settle to completed'
    );
    assert.strictEqual(agyMapDiskErr.get(fastParentCid).bgTask, null);

    // Negative #1: Active RUNNING subagent after slow (>15s) parent yielding response must remain running
    const slowParentCid = 'bbbb1111-2222-3333-4444-555555555552';
    const activeSubCid = '4f49c9aa-5d75-4b9e-a18d-29cb75182654';
    writeSubBrainTranscript(
      slowParentCid,
      [
        { step_index: 1, type: 'USER_INPUT', status: 'DONE', created_at: isoSub(subBaseNow - 45), content: 'Deep audit' },
        {
          step_index: 2,
          type: 'PLANNER_RESPONSE',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 40),
          content: '',
          tool_calls: [{ id: 'tc2', name: 'default_api:invoke_subagent', arguments: '{"TypeName":"research","Role":"Deep Researcher","Prompt":"Inspect all modules"}' }]
        },
        {
          step_index: 3,
          type: 'GENERIC',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 40),
          content: `{"conversationId":"${activeSubCid}"}`
        },
        {
          step_index: 4,
          type: 'PLANNER_RESPONSE',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 15),
          content: 'Subagent launched; waiting for its completion.'
        }
      ],
      subBaseNow - 15
    );
    const agyMapSlowRunning = new Map([
      [
        slowParentCid,
        {
          id: slowParentCid,
          status: 'CASCADE_RUN_STATUS_IDLE',
          notFullyIdle: false,
          stepCount: 5,
          bgTask: null
        }
      ]
    ]);
    const subMapSlowRunning = new Map([
      [activeSubCid, { id: activeSubCid, rootId: slowParentCid, status: 'CASCADE_RUN_STATUS_RUNNING', stepCount: 6, updatedAt: subBaseNow - 2 }]
    ]);
    const ctxSlowRunning = subStore._createTokenAnalyticsContext(
      tmpSubHomeDir,
      agyMapSlowRunning,
      new Map(),
      new Map(),
      subBaseNow * 1000,
      subMapSlowRunning
    );
    subStore._ingestSingleBrainEntry({ name: slowParentCid, isDirectory: () => true }, ctxSlowRunning);
    const activeParentThread = agyMapSlowRunning.get(slowParentCid);
    assert.strictEqual(
      activeParentThread.backgroundTasks?.[0]?.state,
      'running',
      'Negative: Subagent with RUNNING live RPC summary must NOT be prematurely settled after >15s parent yield'
    );
    assert.strictEqual(activeParentThread.bgTask?.state, 'running');
    assert.strictEqual(activeParentThread.status, 'CASCADE_RUN_STATUS_RUNNING');

    // Negative #2: Without RPC summary or subagent transcript, parent still waiting at yielding step (maxStepIndex <= subStepIndex + 2) must keep subagent running
    const agyMapNoRpcYet = new Map([
      [
        slowParentCid,
        {
          id: slowParentCid,
          status: 'CASCADE_RUN_STATUS_IDLE',
          notFullyIdle: false,
          stepCount: 5,
          bgTask: null
        }
      ]
    ]);
    const ctxNoRpcYet = subStore._createTokenAnalyticsContext(
      tmpSubHomeDir,
      agyMapNoRpcYet,
      new Map(),
      new Map(),
      subBaseNow * 1000,
      new Map()
    );
    subStore._ingestSingleBrainEntry({ name: slowParentCid, isDirectory: () => true }, ctxNoRpcYet);
    assert.strictEqual(
      agyMapNoRpcYet.get(slowParentCid).backgroundTasks?.[0]?.state,
      'running',
      'Negative: Parent waiting at yielding step (maxStepIndex <= subStepIndex + 2) without RPC summary must keep subagent running'
    );
    assert.strictEqual(agyMapNoRpcYet.get(slowParentCid).bgTask?.state, 'running');
  } finally {
    try {
      fs.rmSync(tmpSubHomeDir, { recursive: true, force: true });
    } catch {}
  }
  console.log('[PASS] Adversarial #9: Subagent background-task settlement (live RPC + disk ERROR_MESSAGE vs active RUNNING subagent) verified');

  console.log('ALL_SMOKE_TESTS_PASSED');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
