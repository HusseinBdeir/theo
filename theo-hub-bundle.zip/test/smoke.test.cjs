'use strict';

const assert = require('assert');
const fs = require('fs');
const http = require('http');
const net = require('net');
const os = require('os');
const path = require('path');
const vm = require('vm');

process.env.THEO_SMOKE_TEST = '1';
process.env.THEO_DISABLE_HUB_PROCESS_REAP = '1';

const ROOT = path.resolve(__dirname, '..');

async function main() {
  // 1. Syntax check all CJS/JS modules
  const cjsFiles = [
    'extension.js',
    'accounts.js',
    'session-tabs.js',
    'hub.js',
    'data.js',
    'store.js',
    'state.js',
    'bridge.js',
    'remote.js',
    'device-identity.js',
    'ws-server.js',
    'direct-runner.js',
    'edge-relay-client.js',
    'activity.js',
    'desktop-notify.js',
    'scripts/relay_keepalive.cjs',
    'scripts/theo_agent.cjs',
    'compat/antigravity-hub-bridge.cjs',
    'compat/antigravity-tab-state.cjs',
    'compat/antigravity-context-window.cjs',
    'compat/claude-hub-bridge.cjs',
    'compat/claude-webview-patches.cjs',
    'compat/excel-preview.cjs'
  ];
  for (const rel of cjsFiles) {
    const full = path.join(ROOT, rel);
    assert.ok(fs.existsSync(full), `Missing module ${rel}`);
    const code = fs.readFileSync(full, 'utf8');
    new vm.Script(code, { filename: full });
  }
  console.log(`[PASS] Syntax verified across ${cjsFiles.length} theo-hub modules`);

  // 2. Adversarial Check #1: Zero secrets in repo & pairing token roundtrip + hostile input rejection
  assert.strictEqual(
    fs.existsSync(path.join(ROOT, 'remote-relay.json')),
    false,
    'remote-relay.json must NOT exist inside theo-hub repo'
  );
  const devId = require(path.join(ROOT, 'device-identity.js'));
  const sampleToken = devId.buildPairTokenBase64Url({
    cloudUrl: 'https://example.invalid/relay',
    cloudKey: 'test-cloud-key',
    edgeAccessKey: 'a'.repeat(64),
    edgeRelayUrl: 'wss://theo-edge-relay.husseinbdeir.workers.dev/ws',
    port: 4318
  });
  assert.ok(sampleToken && !sampleToken.includes('+') && !sampleToken.includes('/'), 'URL-safe base64 token');
  const decoded = devId.parsePairTokenBase64Url(`https://husseinbdeir.github.io/theo/#pair=${sampleToken}&foo=1`);
  assert.strictEqual(decoded.edgeAccessKey, 'a'.repeat(64));
  assert.strictEqual(decoded.cloudKey, 'test-cloud-key');
  const multiLineTxt = [
    '=== THEO 1-Tap Mobile Pairing URL ===',
    `https://husseinbdeir.github.io/theo/#pair=${sampleToken}`,
    '',
    '=== Main Workstation 1-Line PowerShell ===',
    `$env:THEO_PAIR_TOKEN='${sampleToken}'; irm https://raw.githubusercontent.com/HusseinBdeir/theo/main/install.ps1 | iex`
  ].join('\r\n');
  const decodedMulti = devId.parsePairTokenBase64Url(multiLineTxt);
  assert.ok(decodedMulti, 'Multi-line mobile-pair-url.txt paste must decode cleanly');
  assert.strictEqual(decodedMulti.edgeAccessKey, 'a'.repeat(64));
  const decodedPs1 = devId.parsePairTokenBase64Url(
    `$env:THEO_PAIR_TOKEN="${sampleToken}"; irm https://raw.githubusercontent.com/HusseinBdeir/theo/main/install.ps1 | iex`
  );
  assert.ok(decodedPs1, 'PowerShell $env:THEO_PAIR_TOKEN line must decode cleanly');
  assert.strictEqual(decodedPs1.cloudKey, 'test-cloud-key');
  assert.strictEqual(devId.parsePairTokenBase64Url('not-a-valid-token-$$$'), null);
  assert.strictEqual(devId.parsePairTokenBase64Url('#pair=bm90LWpzb24'), null, 'Non-JSON #pair= must return null');
  assert.strictEqual(devId.parsePairTokenBase64Url(''), null);

  // Red-Team C-1: Reject secret-less or partial-overwrite #pair= payloads & unsafe endpoint schemes
  const encodeRawJsonToken = (obj) =>
    Buffer.from(JSON.stringify(obj), 'utf8')
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/g, '');
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'https://evil.example/steal', k: '', e: '' })}`),
    null,
    'Secret-less #pair= payload must return null (C-1)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'https://evil.example/steal', k: '', e: 'a'.repeat(64) })}`),
    null,
    'cloudUrl without cloudKey in #pair= must return null to prevent stored cloudKey exfiltration (C-1)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'http://evil.example/steal', k: 'k1', e: 'a'.repeat(64) })}`),
    null,
    'Non-TLS remote http:// cloudUrl in #pair= must fail closed (return null)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, r: 'javascript:alert(1)', e: 'a'.repeat(64) })}`),
    null,
    'javascript: edgeRelayUrl in #pair= must fail closed (return null)'
  );

  // Red-Team M-4 / M-5: Behavioral execution of Cloudflare Durable Object TheoRelayRoom (/pair/create, /pair/claim, 429 wipe, alarm)
  const nodeCrypto = require('crypto');
  const { DatabaseSync } = require('node:sqlite');
  const workerSrc = fs.readFileSync(path.join(ROOT, 'cloudflare-relay', 'src', 'index.js'), 'utf8');
  const cjsWorkerCode =
    workerSrc
      .replace(
        /import\s*\{\s*DurableObject\s*\}\s*from\s*["']cloudflare:workers["'];?/,
        'class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }'
      )
      .replace(/export\s+default\s+/, 'module.exports.worker = ')
      .replace(/export\s+class\s+TheoRelayRoom\b/, 'class TheoRelayRoom') +
    '\nmodule.exports.TheoRelayRoom = TheoRelayRoom;\n';
  const cfSubtle = new Proxy(globalThis.crypto.subtle, {
    get(target, prop) {
      if (prop === 'timingSafeEqual') {
        return (a, b) => nodeCrypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
      }
      const val = target[prop];
      return typeof val === 'function' ? val.bind(target) : val;
    }
  });
  const cfCrypto = new Proxy(globalThis.crypto, {
    get(target, prop) {
      if (prop === 'subtle') return cfSubtle;
      const val = target[prop];
      return typeof val === 'function' ? val.bind(target) : val;
    }
  });
  const workerMod = { exports: {} };
  vm.runInNewContext(
    cjsWorkerCode,
    {
      module: workerMod,
      exports: workerMod.exports,
      crypto: cfCrypto,
      TextEncoder,
      TextDecoder,
      Uint8Array,
      Uint32Array,
      URL,
      Request,
      Response,
      Headers,
      JSON,
      Date,
      Math,
      Number,
      String,
      Boolean,
      Array,
      Object,
      Set,
      Map,
      Promise,
      Error
    },
    { filename: 'cloudflare-relay-index.js' }
  );
  const { TheoRelayRoom } = workerMod.exports;
  const memDb = new DatabaseSync(':memory:');
  let scheduledAlarmAt = 0;
  const mockSql = {
    exec(query, ...params) {
      if (params.length === 0 && !/^\s*SELECT\b/i.test(query)) {
        memDb.exec(query);
        return [];
      }
      const stmt = memDb.prepare(query);
      if (/^\s*SELECT\b/i.test(query)) {
        return stmt.all(...params);
      }
      stmt.run(...params);
      return [];
    }
  };
  const roomAuthToken = devId.deriveEdgeAuthToken('unit-test-worker-secret');
  const room = new TheoRelayRoom(
    {
      getWebSockets: () => [],
      storage: {
        sql: mockSql,
        getAlarm: async () => scheduledAlarmAt || null,
        setAlarm: async (ts) => {
          scheduledAlarmAt = Number(ts || 0);
        }
      }
    },
    { AUTH_TOKEN: roomAuthToken }
  );

  // 1) Unauthenticated /pair/create -> 401
  const unauthCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: { Origin: 'http://127.0.0.1:4318', 'Content-Type': 'application/json' },
      body: JSON.stringify({ bundle: sampleToken })
    })
  );
  assert.strictEqual(unauthCreateRes.status, 401, 'Unauthenticated /pair/create must return 401');

  // 2) Disallowed Origin on /pair/create -> 403
  const evilOriginCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'https://evil.attacker.example',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken })
    })
  );
  assert.strictEqual(evilOriginCreateRes.status, 403, 'Hostile Origin on /pair/create must return 403');

  // 3) Oversized bundle (>8192 chars) -> 400
  const oversizedCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: 'a'.repeat(9000) })
    })
  );
  assert.strictEqual(oversizedCreateRes.status, 400, 'Oversized bundle on /pair/create must return 400');

  // 4) Valid /pair/create -> 200 + 6-digit code, single-use /pair/claim -> 200, replay -> 401
  const validCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 600 })
    })
  );
  assert.strictEqual(validCreateRes.status, 200, 'Authorized /pair/create must return 200');
  const createdJson = await validCreateRes.json();
  assert.match(String(createdJson.code || ''), /^\d{6}$/, 'Minted code must be exactly 6 digits');

  const firstClaimRes = await room.fetch(
    new Request('https://edge.example/pair/claim', {
      method: 'POST',
      headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: createdJson.code })
    })
  );
  assert.strictEqual(firstClaimRes.status, 200, 'Valid 6-digit /pair/claim must return 200');
  const firstClaimJson = await firstClaimRes.json();
  assert.strictEqual(firstClaimJson.bundle, sampleToken, 'Claimed bundle must equal minted bundle');

  const replayClaimRes = await room.fetch(
    new Request('https://edge.example/pair/claim', {
      method: 'POST',
      headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: createdJson.code })
    })
  );
  assert.strictEqual(replayClaimRes.status, 401, 'Replaying a consumed 6-digit code must return 401');

  // 5) Mint 2nd code, send 5 wrong guesses -> 5th returns 429 & wipes active codes
  const secondCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 600 })
    })
  );
  const secondJson = await secondCreateRes.json();
  const wrongCode = secondJson.code === '000000' ? '999999' : '000000';
  let fifthWrongStatus = 0;
  for (let attempt = 1; attempt <= 5; attempt += 1) {
    const r = await room.fetch(
      new Request('https://edge.example/pair/claim', {
        method: 'POST',
        headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: wrongCode })
      })
    );
    if (attempt < 5) {
      assert.strictEqual(r.status, 401, `Wrong attempt #${attempt} must return 401`);
    } else {
      fifthWrongStatus = r.status;
    }
  }
  assert.strictEqual(fifthWrongStatus, 429, '5th wrong attempt must trigger HTTP 429 lockout');
  const remainingCodesAfterWipe = memDb.prepare('SELECT COUNT(*) AS cnt FROM pair_codes').get().cnt;
  assert.strictEqual(remainingCodesAfterWipe, 0, '5th wrong attempt must wipe all active pair_codes');

  // 6) M-4: alarm() with 0 connected WebSockets must still reschedule cleanup while pair_codes exist
  memDb.exec("DELETE FROM kv WHERE k = 'pair_fail_state'");
  await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 120 })
    })
  );
  scheduledAlarmAt = 0;
  await room.alarm();
  assert.ok(scheduledAlarmAt > Date.now(), 'alarm() with 0 WebSockets must reschedule next pair_codes expiry cleanup (M-4)');
  memDb.close();

  // Verify theo-hub-bundle.zip (if present in sibling ../theo) leaks zero secrets or .wrangler state
  const siblingBundleZip = path.resolve(ROOT, '..', 'theo', 'theo-hub-bundle.zip');
  const liveCredPath = path.join(os.homedir(), '.theo', 'credentials.json');
  if (fs.existsSync(siblingBundleZip)) {
    const rawZipBytes = fs.readFileSync(siblingBundleZip);
    const rawZipLatin1 = rawZipBytes.toString('latin1');
    assert.strictEqual(rawZipLatin1.includes('remote-relay.json'), false, 'Bundle zip must not contain remote-relay.json');
    assert.strictEqual(rawZipLatin1.includes('.wrangler/'), false, 'Bundle zip must not contain .wrangler state');
    if (fs.existsSync(liveCredPath)) {
      const liveCreds = JSON.parse(fs.readFileSync(liveCredPath, 'utf8'));
      for (const secretField of ['edgeAccessKey', 'cloudKey']) {
        const val = String(liveCreds[secretField] || '').trim();
        if (val.length >= 16) {
          assert.strictEqual(
            rawZipLatin1.includes(val),
            false,
            `Bundle zip must NEVER contain live ${secretField}`
          );
        }
      }
    }
  }

  // Cross-host device attribution & localOnly snapshot symmetry invariant (#2 & Red-Team Finding #1/#5)
  const wsRow = devId.inferRowOwnerDevice(
    { cwd: 'C:\\Users\\HusseinBdeir\\bhfirms\\isabi-app' },
    { id: 'theo-laptop', name: 'THEO Laptop' }
  );
  assert.strictEqual(wsRow.id, 'main-workstation');
  assert.strictEqual(wsRow.deviceId, 'main-workstation');
  assert.strictEqual(wsRow.deviceName, 'Main Workstation');
  const lapRow = devId.inferRowOwnerDevice(
    { cwd: 'C:\\Users\\hbdei\\bhfirms\\theo' },
    { id: 'main-workstation', name: 'Main Workstation' }
  );
  assert.strictEqual(lapRow.id, 'theo-laptop');
  assert.strictEqual(lapRow.deviceId, 'theo-laptop');
  const nodeBinInfo = devId.resolveNodeBinaryInfo();
  assert.strictEqual(nodeBinInfo.executable, nodeBinInfo.nodeExe, 'resolveNodeBinaryInfo must expose nodeExe alias');
  assert.strictEqual(
    nodeBinInfo.electronRunAsNode,
    nodeBinInfo.useElectronRunAsNode,
    'resolveNodeBinaryInfo must expose useElectronRunAsNode alias'
  );

  const { TheoRemoteBridge } = require(path.join(ROOT, 'remote.js'));
  const mockBridge = new TheoRemoteBridge(null, {
    hub: {
      lastPosted: JSON.stringify({
        rows: [
          { id: 'loc-1', title: 'Laptop Local Thread', cwd: 'C:\\Users\\hbdei\\bhfirms\\theo', provider: 'antigravity', at: 200 },
          { id: 'rem-1', title: 'Workstation Synced Thread', cwd: 'C:\\Users\\HusseinBdeir\\bhfirms\\isabi-app', provider: 'claude', at: 300 }
        ]
      }),
      snapshot: {}
    }
  });
  if (mockBridge.edgeClient) mockBridge.edgeClient.stop();
  mockBridge.deviceInfo = { id: 'theo-laptop', name: 'Theo Laptop', role: 'secondary', capabilities: ['antigravity', 'claude'] };
  const localOnlySnap = await mockBridge.buildFullState({ localOnly: true });
  assert.deepStrictEqual(
    localOnlySnap.rows.map((r) => r.id),
    ['loc-1'],
    'buildFullState({ localOnly: true }) must retain local rows and exclude foreign-host rows'
  );
  const fullMergedSnap = await mockBridge.buildFullState({ localOnly: false });
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'loc-1')?.remotePeer, false);
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'rem-1')?.deviceId, 'main-workstation');
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'rem-1')?.remotePeer, true);

  let capturedEdgeUrl = '';
  mockBridge.setEffectiveEdgeUrl = async (u) => {
    capturedEdgeUrl = u;
    return { ok: true };
  };
  for (const payload of [{ url: 'wss://a.example/ws' }, { edgeRelayUrl: 'wss://b.example/ws' }]) {
    const rawNextUrl = payload.edgeRelayUrl !== undefined ? payload.edgeRelayUrl : payload.url;
    await mockBridge.setEffectiveEdgeUrl(String(rawNextUrl || '').trim());
    assert.strictEqual(capturedEdgeUrl, payload.edgeRelayUrl || payload.url);
  }

  // Red-Team H-1 / L-1 / M-5: Behavioral HTTP execution of TheoRemoteBridge.handleHttpRequest
  const unitBridgeTok = devId.deriveEdgeAuthToken('unit-test-http-bridge-secret');
  mockBridge.getDerivedBridgeToken = () => unitBridgeTok;
  mockBridge.verifyBridgeToken = (tok) => Boolean(tok && tok === unitBridgeTok);
  const bridgeHttpSrv = http.createServer((req, res) => {
    mockBridge.handleHttpRequest(req, res).catch((err) => {
      res.writeHead(500);
      res.end(String(err));
    });
  });
  await new Promise((resolve) => bridgeHttpSrv.listen(0, '127.0.0.1', resolve));
  const bridgeHttpPort = bridgeHttpSrv.address().port;
  try {
    const baseBridgeUrl = `http://127.0.0.1:${bridgeHttpPort}`;
    // Unauthenticated /api/ping -> 200 with authenticated: false & authRequired: true (H-1)
    const unauthPing = await fetch(`${baseBridgeUrl}/api/ping`);
    assert.strictEqual(unauthPing.status, 200);
    const unauthPingJson = await unauthPing.json();
    assert.strictEqual(unauthPingJson.authenticated, false, 'Unauthenticated /api/ping must set authenticated: false (H-1)');
    assert.strictEqual(unauthPingJson.authRequired, true, 'Unauthenticated /api/ping must set authRequired: true');

    // Authenticated /api/ping -> 200 with authenticated: true
    const authPing = await fetch(`${baseBridgeUrl}/api/ping`, {
      headers: { Authorization: `Bearer ${unitBridgeTok}` }
    });
    const authPingJson = await authPing.json();
    assert.strictEqual(authPingJson.authenticated, true, 'Authenticated /api/ping must set authenticated: true');

    // Unauthenticated /api/pairing-info & /api/pair-code -> 401
    const unauthPairInfo = await fetch(`${baseBridgeUrl}/api/pairing-info`);
    assert.strictEqual(unauthPairInfo.status, 401, 'Unauthenticated /api/pairing-info must return 401');
    const unauthPairCode = await fetch(`${baseBridgeUrl}/api/pair-code`, { method: 'POST' });
    assert.strictEqual(unauthPairCode.status, 401, 'Unauthenticated /api/pair-code must return 401');

    // Authenticated /api/pairing-info -> 200 with single-quoted PowerShell command & dual field names (L-1)
    const authPairInfo = await fetch(`${baseBridgeUrl}/api/pairing-info`, {
      headers: { Authorization: `Bearer ${unitBridgeTok}` }
    });
    assert.strictEqual(authPairInfo.status, 200);
    const authPairInfoJson = await authPairInfo.json();
    assert.strictEqual(authPairInfoJson.pairUrl, authPairInfoJson.mobilePairUrl, 'pairUrl and mobilePairUrl must match');
    assert.strictEqual(
      authPairInfoJson.workstationCmd,
      authPairInfoJson.workstationBootstrapPs1,
      'workstationCmd and workstationBootstrapPs1 must match'
    );
    if (authPairInfoJson.workstationCmd) {
      assert.ok(
        authPairInfoJson.workstationCmd.startsWith("$env:THEO_PAIR_TOKEN='"),
        'workstationCmd must single-quote $env:THEO_PAIR_TOKEN in PowerShell (L-1)'
      );
    }
  } finally {
    await new Promise((resolve) => bridgeHttpSrv.close(resolve));
  }
  console.log('[PASS] Adversarial #1: Zero repo secrets, DO /pair/create+/pair/claim+429+alarm, C-1/H-1/L-1 HTTP & #pair= checks');

  // 3. Adversarial Check #2: RFC 6455 WS server Origin gate, Auth gate (4001), onConnect post-auth firing, & unmasked/continuation validation
  const { attachWebSocketServer } = require(path.join(ROOT, 'ws-server.js'));
  const expectedSecret = devId.deriveEdgeAuthToken('unit-test-secret-key');
  let onConnectFiredCount = 0;
  const srv = http.createServer((req, res) => {
    res.writeHead(200);
    res.end('ok');
  });
  const wss = attachWebSocketServer(srv, {
    path: '/ws',
    verifyUpgrade: (req) => {
      const origin = String(req.headers.origin || '');
      if (origin && origin !== 'http://127.0.0.1' && origin !== 'https://husseinbdeir.github.io') {
        return { ok: false, status: 403, message: 'Forbidden Origin' };
      }
      return { ok: true };
    },
    verifyToken: (tok) => tok === expectedSecret,
    onConnect: (conn) => {
      onConnectFiredCount += 1;
      conn.sendJson({ type: 'welcome', ok: true });
    }
  });
  await new Promise((resolve) => srv.listen(0, '127.0.0.1', resolve));
  const port = srv.address().port;

  try {
    // 3a. Hostile Origin must be rejected with HTTP 403 before WS upgrade completes
    const evilStatus = await new Promise((resolve, reject) => {
      const req = http.request({
        host: '127.0.0.1',
        port,
        path: '/ws',
        headers: {
          Connection: 'Upgrade',
          Upgrade: 'websocket',
          Origin: 'https://evil.attacker.example',
          'Sec-WebSocket-Version': '13',
          'Sec-WebSocket-Key': Buffer.from('1234567890123456').toString('base64')
        }
      });
      req.on('response', (res) => {
        res.resume();
        resolve(res.statusCode);
      });
      req.on('upgrade', (_, sock) => {
        sock.destroy();
        resolve(101);
      });
      req.on('error', reject);
      req.end();
    });
    assert.strictEqual(evilStatus, 403, 'Evil Origin must receive 403');

    // 3b. Wrong token over WS must be rejected with close code 4001
    const badCloseCode = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, {
        headers: { Origin: 'https://husseinbdeir.github.io' }
      });
      const t = setTimeout(() => reject(new Error('WS close timeout')), 4000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ type: 'auth', token: 'wrong-token' }));
      });
      ws.addEventListener('close', (ev) => {
        clearTimeout(t);
        resolve(ev.code);
      });
    });
    assert.strictEqual(badCloseCode, 4001, 'Invalid WS auth token must close with 4001');
    assert.strictEqual(onConnectFiredCount, 0, 'onConnect must NEVER fire before valid WS token auth');

    // 3c. Valid token succeeds, receives auth_ok AND welcome from onConnect fallback
    const authedOk = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, {
        headers: { Origin: 'https://husseinbdeir.github.io' }
      });
      const seenTypes = new Set();
      const t = setTimeout(() => reject(new Error('WS auth_ok + welcome timeout')), 4000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ type: 'auth', token: expectedSecret }));
      });
      ws.addEventListener('message', (ev) => {
        const msg = JSON.parse(String(ev.data));
        seenTypes.add(msg.type);
        if (seenTypes.has('auth_ok') && seenTypes.has('welcome')) {
          clearTimeout(t);
          ws.close();
          resolve(true);
        }
      });
    });
    assert.strictEqual(authedOk, true);
    assert.strictEqual(onConnectFiredCount, 1, 'onConnect must fire exactly once after valid WS auth');

    // 3d. Unexpected RFC 6455 continuation frame (opcode 0x0 with no fragmented message) closes cleanly without crashing
    const protoClose = await new Promise((resolve) => {
      const sock = net.connect(port, '127.0.0.1', () => {
        const key = Buffer.from('abcdefghijklmnop').toString('base64');
        sock.write(
          `GET /ws HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: ${key}\r\n\r\n`
        );
      });
      let upgraded = false;
      let buf = Buffer.alloc(0);
      sock.on('data', (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        if (!upgraded && buf.includes('\r\n\r\n')) {
          upgraded = true;
          // Masked FIN=1 opcode=0x0 (unexpected continuation) length=2 mask=0x11223344 payload=0x0000
          const badFrame = Buffer.from([0x80, 0x82, 0x11, 0x22, 0x33, 0x44, 0x11, 0x22]);
          sock.write(badFrame);
        }
      });
      sock.on('close', () => resolve(true));
    });
    assert.strictEqual(protoClose, true);
  } finally {
    wss.closeAll();
    await new Promise((resolve) => srv.close(resolve));
  }
  console.log('[PASS] Adversarial #2: WS Origin 403, invalid-token 4001, valid auth_ok, and RFC 6455 protocol-error guard');

  // 4. Adversarial Check #3: Cortex SQLite protobuf decoder & sidecar recovery + missing-ID safety
  const { AntigravityDataStore } = require(path.join(ROOT, 'store.js'));
  const store = new AntigravityDataStore();
  assert.strictEqual(store.readCliConversationDbDetail('../../etc/passwd'), null, 'Path traversal ID must return null');
  assert.strictEqual(store.readCliConversationDbDetail('00000000-0000-0000-0000-000000000000'), null);
  const cliConvDir = path.join(os.homedir(), '.gemini', 'antigravity-cli', 'conversations');
  if (fs.existsSync(cliConvDir)) {
    const dbFiles = fs.readdirSync(cliConvDir).filter((f) => f.endsWith('.db'));
    if (dbFiles.length > 0) {
      let decodedAny = 0;
      for (const f of dbFiles.slice(0, 5)) {
        const cid = f.replace(/\.db$/, '');
        const parsed = store.readCliConversationDbDetail(cid);
        if (parsed && Array.isArray(parsed.messages) && parsed.messages.length > 0) {
          decodedAny += 1;
        }
      }
      assert.ok(decodedAny > 0, 'Expected at least 1 CLI SQLite conversation to decode >0 messages');
      console.log(`[PASS] Adversarial #3: Decoded ${decodedAny}/${Math.min(5, dbFiles.length)} CLI SQLite conversations + rejected traversal IDs`);
    }
  } else {
    console.log('[PASS] Adversarial #3: Traversal & missing SQLite ID guards verified');
  }

  console.log('ALL_SMOKE_TESTS_PASSED');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
