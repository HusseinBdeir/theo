'use strict';

const assert = require('assert');
const { spawnSync } = require('child_process');
const fs = require('fs');
const http = require('http');
const net = require('net');
const os = require('os');
const path = require('path');
const vm = require('vm');

process.env.THEO_SMOKE_TEST = '1';
process.env.THEO_DISABLE_HUB_PROCESS_REAP = '1';

const ROOT = path.resolve(__dirname, '..');

async function main() {
  // 1. Syntax check all CJS/JS modules
  const cjsFiles = [
    'extension.js',
    'accounts.js',
    'session-tabs.js',
    'hub.js',
    'data.js',
    'store.js',
    'state.js',
    'bridge.js',
    'remote.js',
    'device-identity.js',
    'pc-setup.js',
    'bundle-updater.js',
    'ws-server.js',
    'direct-runner.js',
    'edge-relay-client.js',
    'activity.js',
    'desktop-notify.js',
    'desktop-launcher.js',
    'scripts/relay_keepalive.cjs',
    'scripts/theo_agent.cjs',
    'scripts/memory_cloud_sync.cjs',
    'compat/antigravity-hub-bridge.cjs',
    'compat/antigravity-tab-state.cjs',
    'compat/antigravity-context-window.cjs',
    'compat/claude-hub-bridge.cjs',
    'compat/claude-webview-patches.cjs',
    'compat/excel-preview.cjs'
  ];
  for (const rel of cjsFiles) {
    const full = path.join(ROOT, rel);
    assert.ok(fs.existsSync(full), `Missing module ${rel}`);
    const code = fs.readFileSync(full, 'utf8');
    new vm.Script(code, { filename: full });
  }
  console.log(`[PASS] Syntax verified across ${cjsFiles.length} theo-hub modules`);

  // 2. Adversarial Check #1: Zero secrets in repo & pairing token roundtrip + hostile input rejection
  assert.strictEqual(
    fs.existsSync(path.join(ROOT, 'remote-relay.json')),
    false,
    'remote-relay.json must NOT exist inside theo-hub repo'
  );
  const devId = require(path.join(ROOT, 'device-identity.js'));
  const sampleToken = devId.buildPairTokenBase64Url({
    cloudUrl: 'https://example.invalid/relay',
    cloudKey: 'test-cloud-key',
    edgeAccessKey: 'a'.repeat(64),
    edgeRelayUrl: 'wss://theo-edge-relay.husseinbdeir.workers.dev/ws',
    port: 4318
  });
  assert.ok(sampleToken && !sampleToken.includes('+') && !sampleToken.includes('/'), 'URL-safe base64 token');
  const decoded = devId.parsePairTokenBase64Url(`https://husseinbdeir.github.io/theo/#pair=${sampleToken}&foo=1`);
  assert.strictEqual(decoded.edgeAccessKey, 'a'.repeat(64));
  assert.strictEqual(decoded.cloudKey, 'test-cloud-key');
  const multiLineTxt = [
    '=== THEO 1-Tap Mobile Pairing URL ===',
    `https://husseinbdeir.github.io/theo/#pair=${sampleToken}`,
    '',
    '=== Main Workstation 1-Line PowerShell ===',
    `$env:THEO_PAIR_TOKEN='${sampleToken}'; irm https://raw.githubusercontent.com/HusseinBdeir/theo/main/install.ps1 | iex`
  ].join('\r\n');
  const decodedMulti = devId.parsePairTokenBase64Url(multiLineTxt);
  assert.ok(decodedMulti, 'Multi-line mobile-pair-url.txt paste must decode cleanly');
  assert.strictEqual(decodedMulti.edgeAccessKey, 'a'.repeat(64));
  const decodedPs1 = devId.parsePairTokenBase64Url(
    `$env:THEO_PAIR_TOKEN="${sampleToken}"; irm https://raw.githubusercontent.com/HusseinBdeir/theo/main/install.ps1 | iex`
  );
  assert.ok(decodedPs1, 'PowerShell $env:THEO_PAIR_TOKEN line must decode cleanly');
  assert.strictEqual(decodedPs1.cloudKey, 'test-cloud-key');
  assert.strictEqual(devId.parsePairTokenBase64Url('not-a-valid-token-$$$'), null);
  assert.strictEqual(devId.parsePairTokenBase64Url('#pair=bm90LWpzb24'), null, 'Non-JSON #pair= must return null');
  assert.strictEqual(devId.parsePairTokenBase64Url(''), null);

  // Red-Team C-1: Reject secret-less or partial-overwrite #pair= payloads & unsafe endpoint schemes
  const encodeRawJsonToken = (obj) =>
    Buffer.from(JSON.stringify(obj), 'utf8')
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/g, '');
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'https://evil.example/steal', k: '', e: '' })}`),
    null,
    'Secret-less #pair= payload must return null (C-1)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'https://evil.example/steal', k: '', e: 'a'.repeat(64) })}`),
    null,
    'cloudUrl without cloudKey in #pair= must return null to prevent stored cloudKey exfiltration (C-1)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, u: 'http://evil.example/steal', k: 'k1', e: 'a'.repeat(64) })}`),
    null,
    'Non-TLS remote http:// cloudUrl in #pair= must fail closed (return null)'
  );
  assert.strictEqual(
    devId.parsePairTokenBase64Url(`#pair=${encodeRawJsonToken({ v: 1, r: 'javascript:alert(1)', e: 'a'.repeat(64) })}`),
    null,
    'javascript: edgeRelayUrl in #pair= must fail closed (return null)'
  );

  // Red-Team M-4 / M-5: Behavioral execution of Cloudflare Durable Object TheoRelayRoom (/pair/create, /pair/claim, 429 wipe, alarm)
  const nodeCrypto = require('crypto');
  const { DatabaseSync } = require('node:sqlite');
  const workerSrc = fs.readFileSync(path.join(ROOT, 'cloudflare-relay', 'src', 'index.js'), 'utf8');
  const cjsWorkerCode =
    workerSrc
      .replace(
        /import\s*\{\s*DurableObject\s*\}\s*from\s*["']cloudflare:workers["'];?/,
        'class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }'
      )
      .replace(/export\s+default\s+/, 'module.exports.worker = ')
      .replace(/export\s+class\s+TheoRelayRoom\b/, 'class TheoRelayRoom') +
    '\nmodule.exports.TheoRelayRoom = TheoRelayRoom;\n';
  const cfSubtle = new Proxy(globalThis.crypto.subtle, {
    get(target, prop) {
      if (prop === 'timingSafeEqual') {
        return (a, b) => nodeCrypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
      }
      const val = target[prop];
      return typeof val === 'function' ? val.bind(target) : val;
    }
  });
  const cfCrypto = new Proxy(globalThis.crypto, {
    get(target, prop) {
      if (prop === 'subtle') return cfSubtle;
      const val = target[prop];
      return typeof val === 'function' ? val.bind(target) : val;
    }
  });
  const workerMod = { exports: {} };
  vm.runInNewContext(
    cjsWorkerCode,
    {
      module: workerMod,
      exports: workerMod.exports,
      crypto: cfCrypto,
      TextEncoder,
      TextDecoder,
      Uint8Array,
      Uint32Array,
      URL,
      Request,
      Response,
      Headers,
      JSON,
      Date,
      Math,
      Number,
      String,
      Boolean,
      Array,
      Object,
      Set,
      Map,
      Promise,
      Error
    },
    { filename: 'cloudflare-relay-index.js' }
  );
  const { TheoRelayRoom, worker: edgeWorker } = workerMod.exports;
  const routedRoomNames = [];
  await edgeWorker.fetch(new Request('https://edge.example/pair/claim', { method: 'POST', body: '{}' }), {
    THEO_ROOM: {
      idFromName: (n) => {
        routedRoomNames.push(n);
        return n;
      },
      get: () => ({ fetch: async () => new Response('{}', { status: 200 }) })
    }
  });
  await edgeWorker.fetch(new Request('https://edge.example/ws'), {
    THEO_ROOM: {
      idFromName: (n) => {
        routedRoomNames.push(n);
        return n;
      },
      get: () => ({ fetch: async () => new Response('{}', { status: 426 }) })
    }
  });
  assert.deepStrictEqual(
    routedRoomNames,
    ['theo-pair-v1', 'theo-fleet-v2'],
    'Edge Worker must isolate /pair/* into theo-pair-v1 DO so hibernated WebSockets never pin old DO code'
  );
  const memDb = new DatabaseSync(':memory:');
  let scheduledAlarmAt = 0;
  const mockSql = {
    exec(query, ...params) {
      if (params.length === 0 && !/^\s*SELECT\b/i.test(query)) {
        memDb.exec(query);
        return [];
      }
      const stmt = memDb.prepare(query);
      if (/^\s*SELECT\b/i.test(query)) {
        return stmt.all(...params);
      }
      stmt.run(...params);
      return [];
    }
  };
  const roomAuthToken = devId.deriveEdgeAuthToken('unit-test-worker-secret');
  const room = new TheoRelayRoom(
    {
      getWebSockets: () => [],
      storage: {
        sql: mockSql,
        getAlarm: async () => scheduledAlarmAt || null,
        setAlarm: async (ts) => {
          scheduledAlarmAt = Number(ts || 0);
        }
      }
    },
    { AUTH_TOKEN: roomAuthToken }
  );

  // 1) Unauthenticated /pair/create -> 401
  const unauthCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: { Origin: 'http://127.0.0.1:4318', 'Content-Type': 'application/json' },
      body: JSON.stringify({ bundle: sampleToken })
    })
  );
  assert.strictEqual(unauthCreateRes.status, 401, 'Unauthenticated /pair/create must return 401');

  // 2) Disallowed Origin on /pair/create -> 403
  const evilOriginCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'https://evil.attacker.example',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken })
    })
  );
  assert.strictEqual(evilOriginCreateRes.status, 403, 'Hostile Origin on /pair/create must return 403');

  // 3) Oversized bundle (>8192 chars) -> 400
  const oversizedCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: 'a'.repeat(9000) })
    })
  );
  assert.strictEqual(oversizedCreateRes.status, 400, 'Oversized bundle on /pair/create must return 400');

  // 4) Valid /pair/create -> 200 + 6-digit code, single-use /pair/claim -> 200, replay -> 401
  const validCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 600 })
    })
  );
  assert.strictEqual(validCreateRes.status, 200, 'Authorized /pair/create must return 200');
  const createdJson = await validCreateRes.json();
  assert.match(String(createdJson.code || ''), /^\d{6}$/, 'Minted code must be exactly 6 digits');

  const firstClaimRes = await room.fetch(
    new Request('https://edge.example/pair/claim', {
      method: 'POST',
      headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: createdJson.code })
    })
  );
  assert.strictEqual(firstClaimRes.status, 200, 'Valid 6-digit /pair/claim must return 200');
  const firstClaimJson = await firstClaimRes.json();
  assert.strictEqual(firstClaimJson.bundle, sampleToken, 'Claimed bundle must equal minted bundle');

  const replayClaimRes = await room.fetch(
    new Request('https://edge.example/pair/claim', {
      method: 'POST',
      headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: createdJson.code })
    })
  );
  assert.strictEqual(replayClaimRes.status, 401, 'Replaying a consumed 6-digit code must return 401');

  // 5) Mint 2nd code, send 5 wrong guesses -> 5th returns 429 & wipes active codes
  const secondCreateRes = await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 600 })
    })
  );
  const secondJson = await secondCreateRes.json();
  const wrongCode = secondJson.code === '000000' ? '999999' : '000000';
  let fifthWrongStatus = 0;
  for (let attempt = 1; attempt <= 5; attempt += 1) {
    const r = await room.fetch(
      new Request('https://edge.example/pair/claim', {
        method: 'POST',
        headers: { Origin: 'https://husseinbdeir.github.io', 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: wrongCode })
      })
    );
    if (attempt < 5) {
      assert.strictEqual(r.status, 401, `Wrong attempt #${attempt} must return 401`);
    } else {
      fifthWrongStatus = r.status;
    }
  }
  assert.strictEqual(fifthWrongStatus, 429, '5th wrong attempt must trigger HTTP 429 lockout');
  const remainingCodesAfterWipe = memDb.prepare('SELECT COUNT(*) AS cnt FROM pair_codes').get().cnt;
  assert.strictEqual(remainingCodesAfterWipe, 0, '5th wrong attempt must wipe all active pair_codes');

  // 6) M-4: alarm() with 0 connected WebSockets must still reschedule cleanup while pair_codes exist
  memDb.exec("DELETE FROM kv WHERE k = 'pair_fail_state'");
  await room.fetch(
    new Request('https://edge.example/pair/create', {
      method: 'POST',
      headers: {
        Origin: 'http://127.0.0.1:4318',
        Authorization: `Bearer ${roomAuthToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ bundle: sampleToken, ttlSec: 120 })
    })
  );
  scheduledAlarmAt = 0;
  await room.alarm();
  assert.ok(scheduledAlarmAt > Date.now(), 'alarm() with 0 WebSockets must reschedule next pair_codes expiry cleanup (M-4)');
  memDb.close();

  // Verify theo-hub-bundle.zip (the fresh build in dist/ and the Pages copy in sibling ../theo) leaks zero secrets or .wrangler state
  const liveCredPath = path.join(os.homedir(), '.theo', 'credentials.json');
  for (const siblingBundleZip of [
    path.join(ROOT, 'dist', 'theo-hub-bundle.zip'),
    path.resolve(ROOT, '..', 'theo', 'theo-hub-bundle.zip')
  ]) {
    if (!fs.existsSync(siblingBundleZip)) continue;
    const rawZipBytes = fs.readFileSync(siblingBundleZip);
    const rawZipLatin1 = rawZipBytes.toString('latin1');
    assert.strictEqual(rawZipLatin1.includes('remote-relay.json'), false, 'Bundle zip must not contain remote-relay.json');
    assert.strictEqual(rawZipLatin1.includes('.wrangler/'), false, 'Bundle zip must not contain .wrangler state');
    if (fs.existsSync(liveCredPath)) {
      const liveCreds = JSON.parse(fs.readFileSync(liveCredPath, 'utf8'));
      for (const secretField of ['edgeAccessKey', 'cloudKey']) {
        const val = String(liveCreds[secretField] || '').trim();
        if (val.length >= 16) {
          assert.strictEqual(
            rawZipLatin1.includes(val),
            false,
            `Bundle zip must NEVER contain live ${secretField}`
          );
        }
      }
    }
  }

  // ---- Equal hosts: no PC is special ----
  // (a) No host module may name a PC, a home folder or a primary / secondary role.
  for (const rel of [
    'device-identity.js',
    'pc-setup.js',
    'bundle-updater.js',
    'remote.js',
    'store.js',
    'state.js',
    'edge-relay-client.js',
    'scripts/relay_keepalive.cjs',
    'cloudflare-relay/src/index.js',
    'cloudflare-relay/src/store.js'
  ]) {
    const srcText = fs.readFileSync(path.join(ROOT, rel), 'utf8');
    for (const banned of [
      /users\\+husseinbdeir/i,
      /users\\+hbdei\b/i,
      /main-workstation/i,
      /theo-laptop/i,
      /isPrimaryHost/,
      /isPrimaryStale/,
      /primary_state/,
      /['"]secondary['"]/
    ]) {
      // The store names `primary_state` only to recognise a host on an older build, which is the one thing that
      // still writes it.
      if (rel === 'cloudflare-relay/src/store.js' && String(banned) === String(/primary_state/)) continue;
      assert.strictEqual(banned.test(srcText), false, `${rel} must not contain ${banned} (no PC is special)`);
    }
  }
  assert.strictEqual(devId.HOST_ROLE, 'host');
  assert.strictEqual(devId.getDeviceIdentity().role, 'host', 'every host has the same role');

  // (b) Session ownership is learned from what each host publishes, never from a list in code.
  const fleetHomesTmp = path.join(os.tmpdir(), `theo-fleet-homes-smoke-${process.pid}.json`);
  fs.writeFileSync(
    fleetHomesTmp,
    JSON.stringify({ homes: { 'C:\\Users\\alpha-user': { id: 'pc-alpha', name: 'Alpha PC' } } }),
    'utf8'
  );
  const prevFleetHomesEnv = process.env.THEO_FLEET_HOMES_PATH;
  process.env.THEO_FLEET_HOMES_PATH = fleetHomesTmp;
  const selfDevRef = { id: 'pc-self', name: 'Self PC' };
  const alphaRow = devId.inferRowOwnerDevice({ cwd: 'C:\\Users\\alpha-user\\bhfirms\\isabi-app' }, selfDevRef);
  assert.strictEqual(alphaRow.id, 'pc-alpha', 'a session under another host\'s published home belongs to that host');
  assert.strictEqual(alphaRow.deviceId, 'pc-alpha');
  assert.strictEqual(alphaRow.deviceName, 'Alpha PC');
  assert.strictEqual(devId.inferRowOwnerDevice({ cwd: 'c:/users/ALPHA-USER/x' }, selfDevRef).id, 'pc-alpha');
  assert.strictEqual(
    devId.inferRowOwnerDevice({ cwd: 'C:\\Users\\alpha-user-2\\x' }, selfDevRef).id,
    'pc-self',
    'a home folder only matches on a folder boundary'
  );
  assert.strictEqual(
    devId.inferRowOwnerDevice({ cwd: path.join(os.homedir(), 'bhfirms', 'theo') }, selfDevRef).id,
    'pc-self',
    'a session under this host\'s own home is local'
  );
  assert.strictEqual(devId.inferRowOwnerDevice({ cwd: 'D:\\work\\x' }, selfDevRef).id, 'pc-self');
  assert.strictEqual(
    devId.inferRowOwnerDevice(
      { cwd: path.join(os.homedir(), 'x'), deviceId: 'pc-beta', deviceName: 'Beta PC' },
      selfDevRef,
      { trustStamp: true }
    ).id,
    'pc-beta',
    'a row another host published stays that host\'s even when both PCs use the same home folder name'
  );
  assert.strictEqual(
    devId.inferRowOwnerDevice({ cwd: os.homedir(), deviceId: 'pc-beta', source: 'cloud-relay' }, selfDevRef).id,
    'pc-beta'
  );
  assert.notStrictEqual(
    devId.inferRowOwnerDevice({ cwd: 'D:\\x', source: 'cloud-relay' }, null).id,
    devId.getSelfDeviceRef().id,
    'an unstamped row from the store is never attributed to this host'
  );
  assert.strictEqual(
    devId.rememberFleetHomes(
      [
        { id: 'pc-beta', name: 'Beta PC', homedir: 'C:\\Users\\beta-user\\' },
        { id: 'pc-self', name: 'Self PC', homedir: 'C:\\Users\\self-user' },
        { id: 'pc-twin', name: 'Twin PC', homedir: os.homedir() }
      ],
      'pc-self'
    ),
    true
  );
  assert.strictEqual(devId.inferRowOwnerDevice({ cwd: 'C:\\Users\\beta-user\\repo' }, selfDevRef).id, 'pc-beta');
  const persistedHomes = JSON.parse(fs.readFileSync(fleetHomesTmp, 'utf8')).homes;
  assert.deepStrictEqual(
    Object.keys(persistedHomes).sort(),
    ['c:\\users\\alpha-user', 'c:\\users\\beta-user'],
    'only other hosts with a home folder of their own are recorded'
  );
  assert.strictEqual(
    devId.rememberFleetHomes([{ id: 'pc-beta', name: 'Beta PC', homedir: 'C:\\Users\\beta-user' }], 'pc-self'),
    false,
    'an unchanged fleet is not rewritten'
  );

  // (c) Each host follows the same thing: the sessions the other hosts published about themselves.
  const peerSnap = devId.buildPeerSnapshot(
    {
      'pc-self': {
        device: { name: 'Self PC' },
        snapshot: { rows: [{ id: 's1' }], groups: [{ id: 'g-self', name: 'Mine' }] },
        updatedAt: 5
      },
      'pc-alpha': {
        device: { name: 'Alpha PC' },
        snapshot: { rows: [{ id: 'a1', group: 'g1' }, { id: 'dup' }], groups: [{ id: 'g1', name: 'Ops' }] },
        workspaces: [{ id: 'w1' }],
        updatedAt: 9
      },
      'pc-beta': { device: { name: 'Beta PC' }, rows: [{ id: 'b1', deviceId: 'wrong' }, { id: 'dup' }], updatedAt: 7 }
    },
    'pc-self'
  );
  assert.deepStrictEqual(peerSnap.rows.map((r) => r.id), ['a1', 'dup', 'b1']);
  assert.strictEqual(peerSnap.rows[0].deviceId, 'pc-alpha');
  assert.strictEqual(peerSnap.rows[0].deviceName, 'Alpha PC');
  assert.strictEqual(peerSnap.rows[1].deviceId, 'pc-alpha', 'a session two hosts list goes to the fresher entry');
  assert.strictEqual(peerSnap.rows[2].deviceId, 'pc-beta', 'the publishing host is the owner');
  assert.deepStrictEqual(peerSnap.groups.map((g) => g.id), ['g1']);
  assert.deepStrictEqual(peerSnap.workspaces.map((w) => w.id), ['w1']);

  // (d) The store address follows the Edge relay pairing: no per-PC store setting.
  assert.strictEqual(
    devId.deriveStoreEndpoint('wss://edge.example.workers.dev/ws'),
    'https://edge.example.workers.dev/store'
  );
  assert.strictEqual(
    devId.deriveStoreEndpoint('wss://edge.example.workers.dev/ws/?x=1#y'),
    'https://edge.example.workers.dev/store'
  );
  assert.strictEqual(devId.deriveStoreEndpoint('ws://127.0.0.1:8787/ws'), 'http://127.0.0.1:8787/store');
  assert.strictEqual(devId.deriveStoreEndpoint('ws://evil.example/ws'), '', 'plain http is only allowed on loopback');
  assert.strictEqual(devId.deriveStoreEndpoint(''), '');
  {
    const envKeys = ['THEO_EDGE_KEY', 'THEO_EDGE_RELAY_URL', 'THEO_CLOUD_URL', 'THEO_CLOUD_KEY'];
    const savedEnv = Object.fromEntries(envKeys.map((k) => [k, process.env[k]]));
    try {
      delete process.env.THEO_CLOUD_URL;
      delete process.env.THEO_CLOUD_KEY;
      process.env.THEO_EDGE_KEY = 'b'.repeat(64);
      process.env.THEO_EDGE_RELAY_URL = 'wss://edge.example.workers.dev/ws';
      const derivedCreds = devId.loadTheoCredentials();
      if (!derivedCreds.cloudPinned) {
        assert.strictEqual(derivedCreds.cloudSource, 'edge');
        assert.strictEqual(derivedCreds.cloudUrl, 'https://edge.example.workers.dev/store');
        assert.strictEqual(derivedCreds.cloudKey, devId.deriveEdgeAuthToken('b'.repeat(64)));
        assert.strictEqual(Buffer.from(derivedCreds.u, 'base64').toString('utf8'), derivedCreds.cloudUrl);
      }
      process.env.THEO_CLOUD_URL = 'https://override.example/store';
      process.env.THEO_CLOUD_KEY = 'override-key';
      const envCreds = devId.loadTheoCredentials();
      assert.strictEqual(envCreds.cloudSource, 'env');
      assert.strictEqual(envCreds.cloudUrl, 'https://override.example/store');
      assert.strictEqual(envCreds.cloudKey, 'override-key');
    } finally {
      for (const k of envKeys) {
        if (savedEnv[k] === undefined) delete process.env[k];
        else process.env[k] = savedEnv[k];
      }
    }
  }

  // (e) A group deleted here is not brought back by another host; a same-name group is reused.
  {
    const { mergePeerGroups } = require(path.join(ROOT, 'state.js'));
    const merged = mergePeerGroups(
      {
        groups: [{ id: 'local-ops', name: 'Ops', color: 'blue', collapsed: false }],
        threadGroups: { kept: 'local-ops' },
        unassignedGroupThreads: { freed: 1 },
        deletedGroups: [{ id: 'g-dead', name: 'Old Stuff' }]
      },
      {
        groups: [
          { id: 'g-dead', name: 'Renamed Since' },
          { id: 'g-dead-2', name: 'old stuff' },
          { id: 'peer-ops', name: 'ops' },
          { id: 'g-new', name: 'Finance', color: 'green' }
        ],
        rows: [
          { id: 't1', group: 'g-dead' },
          { id: 't2', group: 'g-dead-2' },
          { id: 't3', group: 'peer-ops' },
          { id: 't4', group: 'g-new' },
          { id: 'kept', group: 'g-new' },
          { id: 'freed', group: 'g-new' },
          { id: 't5', group: 'g-unknown' }
        ]
      }
    );
    assert.deepStrictEqual(merged.groups.map((g) => g.id), ['local-ops', 'g-new']);
    assert.deepStrictEqual(merged.threadGroups, { kept: 'local-ops', t3: 'local-ops', t4: 'g-new' });

    // What another host published is shown here but not stored here, so a group follows its owner.
    const { withoutPeerOverlay, HubStateStore } = require(path.join(ROOT, 'state.js'));
    const stored = withoutPeerOverlay(merged);
    assert.deepStrictEqual(stored.groups.map((g) => g.id), ['local-ops'], 'a peer group is not written into this host\'s state');
    assert.deepStrictEqual(stored.threadGroups, { kept: 'local-ops' }, 'nor is where a peer filed its sessions');
    assert.deepStrictEqual(merged.groups.map((g) => g.id), ['local-ops', 'g-new'], 'the state in use still shows them');
    let savedByMemento = null;
    const overlayStore = new HubStateStore({
      get: () => ({ baseline: 1 }),
      update: async (_key, value) => {
        savedByMemento = value;
      }
    });
    await overlayStore.write(merged);
    assert.deepStrictEqual(savedByMemento.groups.map((g) => g.id), ['local-ops'], 'write() persists the state without the overlay');
    assert.deepStrictEqual(savedByMemento.threadGroups, { kept: 'local-ops' });
    assert.ok(Number(savedByMemento.updatedAt) > 0);
    // Changing a peer group here, or filing one of this host's sessions into it, makes it this host's own.
    merged.groups.find((g) => g.id === 'g-new').collapsed = true;
    assert.deepStrictEqual(withoutPeerOverlay(merged).groups.map((g) => g.id), ['local-ops', 'g-new']);
    merged.groups.find((g) => g.id === 'g-new').collapsed = false;
    merged.threadGroups['my-local-session'] = 'g-new';
    assert.deepStrictEqual(withoutPeerOverlay(merged).groups.map((g) => g.id), ['local-ops', 'g-new']);
    assert.deepStrictEqual(withoutPeerOverlay(merged).threadGroups, { kept: 'local-ops', 'my-local-session': 'g-new' });
    // A session the user moved to another group here keeps that choice.
    merged.threadGroups.t4 = 'local-ops';
    assert.strictEqual(withoutPeerOverlay(merged).threadGroups.t4, 'local-ops');
    const plain = { groups: [{ id: 'x' }], threadGroups: { a: 'x' } };
    assert.strictEqual(withoutPeerOverlay(plain), plain, 'a state with no overlay is stored as it is');
  }

  // (f) Exactly one host acts for the fleet, chosen by the store and never by name.
  {
    const { decideFleetDuty, classifyQueuedCommand } = require(path.join(ROOT, 'remote.js'));
    const nowMs = 1794000000000;
    const fresh = (role, rows = []) => ({ device: { role }, snapshot: { rows }, updatedAt: nowMs - 5000 });
    const stale = (role) => ({ device: { role }, updatedAt: nowMs - 200000 });
    const dutyA = decideFleetDuty({
      selfDevId: 'pc-a',
      storeCoordinator: { deviceId: 'pc-a' },
      deviceStates: { 'pc-b': fresh('host', [{ id: 'sess-b' }]) },
      nowMs
    });
    const dutyB = decideFleetDuty({
      selfDevId: 'pc-b',
      storeCoordinator: { deviceId: 'pc-a' },
      deviceStates: { 'pc-a': fresh('host', [{ id: 'sess-a' }]) },
      nowMs
    });
    assert.strictEqual(dutyA.isCoordinator, true);
    assert.strictEqual(dutyB.isCoordinator, false);
    assert.strictEqual(dutyB.coordinatorDeviceId, 'pc-a');
    assert.ok(dutyA.onlinePeerThreadIds.has('sess-b'));
    // Swapping which host the store names swaps the duty: it is not tied to either PC.
    assert.strictEqual(
      decideFleetDuty({ selfDevId: 'pc-b', storeCoordinator: { deviceId: 'pc-b' }, deviceStates: {}, nowMs }).isCoordinator,
      true
    );
    // A host on a build from before equal hosts is online: stand back even when the store names this host.
    const dutyLegacy = decideFleetDuty({
      selfDevId: 'pc-a',
      storeCoordinator: { deviceId: 'pc-a' },
      deviceStates: { 'old-host': fresh('primary') },
      nowMs
    });
    assert.strictEqual(dutyLegacy.isCoordinator, false);
    assert.strictEqual(dutyLegacy.legacyLeadOnline, true);
    // The store's own report of such a host (timed on the store's clock) is enough without any published role.
    const dutyLegacyByStore = decideFleetDuty({
      selfDevId: 'pc-a',
      storeCoordinator: { deviceId: 'pc-a', legacyLead: true },
      deviceStates: {},
      nowMs
    });
    assert.strictEqual(dutyLegacyByStore.isCoordinator, false);
    assert.strictEqual(dutyLegacyByStore.legacyLeadOnline, true);
    assert.strictEqual(
      decideFleetDuty({
        selfDevId: 'pc-a',
        storeCoordinator: { deviceId: 'pc-a' },
        deviceStates: { 'old-host': stale('primary') },
        nowMs
      }).isCoordinator,
      true,
      'a legacy host that has gone quiet no longer holds anything'
    );
    assert.strictEqual(
      decideFleetDuty({ selfDevId: 'pc-a', storeCoordinator: null, deviceStates: { 'pc-a': fresh('primary') }, nowMs })
        .legacyLeadOnline,
      false,
      'this host\'s own entry is ignored'
    );
    // A store without the duty: the lowest id among the hosts that are online, so still exactly one.
    assert.strictEqual(
      decideFleetDuty({ selfDevId: 'pc-b', deviceStates: { 'pc-a': fresh('host') }, nowMs }).isCoordinator,
      false
    );
    assert.strictEqual(
      decideFleetDuty({ selfDevId: 'pc-a', deviceStates: { 'pc-b': fresh('host') }, nowMs }).isCoordinator,
      true
    );
    assert.strictEqual(
      decideFleetDuty({ selfDevId: 'pc-b', deviceStates: { 'pc-a': stale('host') }, nowMs }).isCoordinator,
      true
    );

    const ctxA = { selfDevId: 'pc-a', localThreadIds: new Set(['sess-a', 'sess-both']), duty: dutyA };
    const ctxB = { selfDevId: 'pc-b', localThreadIds: new Set(['sess-b', 'sess-both']), duty: dutyB };
    const takers = (cmd) => [ctxA, ctxB].filter((ctx) => classifyQueuedCommand(cmd, ctx).mine).map((c) => c.selfDevId);
    assert.deepStrictEqual(takers({ id: 'cmd-1' }), ['pc-a'], 'a command for no PC goes to the coordinator only');
    assert.deepStrictEqual(takers({ id: 'cmd-2', targetDeviceId: 'auto' }), ['pc-a']);
    assert.deepStrictEqual(takers({ id: 'cmd-3', targetDeviceId: 'pc-b' }), ['pc-b'], 'a named PC always gets its command');
    assert.deepStrictEqual(
      takers({ id: 'cmd-4', threadId: 'sess-a', targetDeviceId: 'pc-b' }),
      ['pc-b'],
      'a named PC wins over session ownership'
    );
    assert.deepStrictEqual(takers({ id: 'cmd-5', threadId: 'sess-b' }), ['pc-b'], 'a session goes to the PC that has it');
    assert.deepStrictEqual(takers({ id: 'cmd-6', threadId: 'sess-a' }), ['pc-a']);
    assert.deepStrictEqual(
      takers({ id: 'cmd-7', threadId: 'sess-both' }),
      ['pc-a', 'pc-b'],
      'a session both PCs hold is eligible on both: the store claim then picks one'
    );
    assert.strictEqual(classifyQueuedCommand({ id: 'cmd-3', targetDeviceId: 'pc-b' }, ctxB).explicitlyForMe, true);
    assert.strictEqual(classifyQueuedCommand({ id: 'cmd-1' }, ctxA).explicitlyForMe, false);
    const remoteSrcText = fs.readFileSync(path.join(ROOT, 'remote.js'), 'utf8');
    assert.ok(/op: 'get_control', deviceId: selfDevId/.test(remoteSrcText), 'the poll must name this host');
    assert.ok(/op: 'claim'/.test(remoteSrcText), 'queued commands must be claimed in the store');
  }

  const nodeBinInfo = devId.resolveNodeBinaryInfo();
  assert.strictEqual(nodeBinInfo.executable, nodeBinInfo.nodeExe, 'resolveNodeBinaryInfo must expose nodeExe alias');
  assert.strictEqual(
    nodeBinInfo.electronRunAsNode,
    nodeBinInfo.useElectronRunAsNode,
    'resolveNodeBinaryInfo must expose useElectronRunAsNode alias'
  );

  const { TheoRemoteBridge } = require(path.join(ROOT, 'remote.js'));
  const mockBridge = new TheoRemoteBridge(null, {
    hub: {
      lastPosted: JSON.stringify({
        rows: [
          { id: 'loc-1', title: 'Local Thread', cwd: 'D:\\work\\theo', provider: 'antigravity', at: 200 },
          { id: 'rem-1', title: 'Thread restored from another host', cwd: 'C:\\Users\\alpha-user\\bhfirms\\isabi-app', provider: 'claude', at: 300 }
        ]
      }),
      snapshot: {}
    }
  });
  if (mockBridge.edgeClient) mockBridge.edgeClient.stop();
  mockBridge.deviceInfo = { id: 'pc-self', name: 'Self PC', role: 'host', capabilities: ['antigravity', 'claude'] };
  mockBridge.remoteDeviceStates = {
    'pc-beta': {
      device: { id: 'pc-beta', name: 'Beta PC' },
      snapshot: { rows: [{ id: 'peer-1', title: 'Peer Thread', cwd: path.join(os.homedir(), 'x'), provider: 'claude', at: 100 }] },
      updatedAt: Date.now()
    }
  };
  const localOnlySnap = await mockBridge.buildFullState({ localOnly: true });
  assert.deepStrictEqual(
    localOnlySnap.rows.map((r) => r.id),
    ['loc-1'],
    'buildFullState({ localOnly: true }) must retain local rows and exclude foreign-host rows'
  );
  const fullMergedSnap = await mockBridge.buildFullState({ localOnly: false });
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'loc-1')?.remotePeer, false);
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'loc-1')?.deviceId, 'pc-self');
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'rem-1')?.deviceId, 'pc-alpha');
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'rem-1')?.remotePeer, true);
  assert.strictEqual(
    fullMergedSnap.rows.find((r) => r.id === 'peer-1')?.deviceId,
    'pc-beta',
    'a session a peer published stays that peer\'s even when its folder sits under this host\'s home'
  );
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'peer-1')?.remotePeer, true);
  const fleetView = mockBridge.getUnifiedFleetDevices();
  assert.strictEqual(fleetView.find((d) => d.id === 'pc-beta')?.role, 'host');
  assert.strictEqual(fleetView.find((d) => d.id === 'pc-beta')?.sessionCount, 1);
  assert.strictEqual(fullMergedSnap.device.role, 'host');
  mockBridge.remoteDeviceStates = {};

  // (g) The sync cycle itself, driven against a stand-in store: who runs a queued command, what is written.
  {
    const syncBridge = new TheoRemoteBridge(null, {
      hub: {
        lastPosted: JSON.stringify({
          rows: [{ id: 'loc-1', title: 'Local Thread', cwd: 'D:\\work\\theo', provider: 'antigravity', at: 200 }]
        }),
        snapshot: {}
      }
    });
    if (syncBridge.edgeClient) syncBridge.edgeClient.stop();
    const peerCacheTmp = path.join(os.tmpdir(), `theo-peer-cache-smoke-${process.pid}.json`);
    const claimedTmp = path.join(os.tmpdir(), `theo-claimed-smoke-${process.pid}.json`);
    const lastStateTmp = path.join(os.tmpdir(), `theo-last-state-smoke-${process.pid}.json`);
    const prevClaimedEnv = process.env.THEO_CLAIMED_CMDS_PATH;
    process.env.THEO_CLAIMED_CMDS_PATH = claimedTmp;
    syncBridge.lastStateCachePath = lastStateTmp;
    syncBridge.deviceInfo = { id: 'pc-self', name: 'Self PC', role: 'host', capabilities: [] };
    syncBridge.peerCachePathOverride = peerCacheTmp;
    syncBridge.relayConfig.url = 'https://store.invalid/store';
    syncBridge.relayConfig.key = 'k'.repeat(64);
    syncBridge.pushDevices = [];
    syncBridge.syncFromDiskPersonalLedger = () => {};
    syncBridge.ensureCloudPrayerTimersArmed = async () => {};
    syncBridge.evaluateRealtimePushAlerts = async () => {};
    syncBridge.workspacesDetailCachedAt = Date.now();
    syncBridge.workspacesDetailCache = {};
    syncBridge.getThreadDetail = async (id) => ({ id, messages: [] });
    const executed = [];
    let execResult = { ok: true };
    syncBridge.executeRemoteCommand = async (cmd) => {
      executed.push(cmd.id || cmd.cmdId);
      return execResult;
    };
    const makeStore = ({ coordinator = null, queue = [], deviceStates = {}, claimAnswer = () => true } = {}) => {
      const requests = [];
      return {
        requests,
        post: async (payload) => {
          requests.push(JSON.parse(JSON.stringify(payload)));
          if (payload.op === 'get_control') {
            return { ok: true, ...(coordinator ? { coordinator } : {}), docs: { queue: { commands: queue } } };
          }
          if (payload.op === 'get_theo') return { ok: true, docs: { device_states: deviceStates, threads: {} } };
          if (payload.op === 'claim') {
            if (payload.release) return { ok: true, released: true };
            const answer = claimAnswer(payload);
            return answer === null ? { ok: false } : { ok: true, claimed: answer, by: answer ? payload.deviceId : 'pc-other' };
          }
          return { ok: true };
        }
      };
    };
    const runCycle = async (store) => {
      syncBridge.postStore = (payload) => store.post(payload);
      syncBridge._lastFleetFollowAt = 0;
      syncBridge._lastCloudDeviceWriteAt = 0; // a host that is not the coordinator writes its entry every 20 s
      syncBridge.cloudSyncInFlight = false;
      syncBridge.remoteDeviceStates = {};
      executed.length = 0;
      store.requests.length = 0;
      const res = await syncBridge.syncCloudRelay({ pushState: true });
      assert.ok(res && res.ok, `the sync cycle must complete (${syncBridge.lastCloudError || 'no error text'})`);
      return store.requests;
    };
    const claims = (reqs) => reqs.filter((q) => q.op === 'claim' && !q.release);
    const releases = (reqs) => reqs.filter((q) => q.op === 'claim' && q.release);
    const fleetPatch = (reqs) => reqs.find((q) => q.op === 'patch' && q.patch && q.patch.device_states);
    const queuePatch = (reqs) => reqs.find((q) => q.op === 'patch' && q.patch && q.patch.queue);
    let cmdSeq = 0;
    const pendingCmd = (extra = {}) => ({
      id: `cmd-smoke-${process.pid}-${Date.now()}-${++cmdSeq}`,
      createdAt: Date.now(),
      status: 'pending',
      type: 'refresh',
      ...extra
    });
    const me = { deviceId: 'pc-self', since: 1, lastBeat: 1, ttlMs: 90000, legacyLead: false };
    const freshPeer = (id, role = 'host') => ({
      device: { id, name: id, role, homedir: '' },
      snapshot: { rows: [{ id: `sess-${id}`, title: 'Peer', provider: 'claude', at: 50 }] },
      updatedAt: Date.now()
    });

    // 1. This host holds the duty: it claims the command, runs it once and writes the shared state.
    let cmd = pendingCmd();
    let store = makeStore({ coordinator: me, queue: [cmd], deviceStates: { 'pc-zeta': freshPeer('pc-zeta') } });
    let reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [cmd.id]);
    assert.strictEqual(claims(reqs).length, 1);
    assert.strictEqual(claims(reqs)[0].deviceId, 'pc-self');
    assert.ok(/^cmd:[0-9a-f]{64}$/.test(claims(reqs)[0].claimKey));
    assert.strictEqual(reqs.find((q) => q.op === 'get_control').deviceId, 'pc-self', 'the poll names this host');
    let fp = fleetPatch(reqs);
    assert.deepStrictEqual(Object.keys(fp.patch.device_states), ['pc-self'], 'a host sends only its own fleet entry');
    assert.ok(!('rows' in fp.patch.device_states['pc-self']), 'the entry carries its sessions once');
    assert.deepStrictEqual(fp.patch.device_states['pc-self'].snapshot.rows.map((r) => r.id), ['loc-1']);
    assert.strictEqual(fp.patch.device_states['pc-self'].device.role, 'host');
    assert.strictEqual(fp.patch.meta.deviceId, 'pc-self');
    assert.ok(fp.patch.state && fp.patch.state.snapshot, 'the coordinator writes the shared state');
    assert.ok(!('primary_state' in fp.patch), 'no host writes a primary state any more');
    assert.strictEqual(queuePatch(reqs).patch.queue.commands.find((c) => c.id === cmd.id).status, 'done');
    const peerCache = JSON.parse(fs.readFileSync(peerCacheTmp, 'utf8'));
    assert.strictEqual(peerCache.peerOnly, true);
    assert.deepStrictEqual(peerCache.snapshot.rows.map((r) => [r.id, r.deviceId]), [['sess-pc-zeta', 'pc-zeta']]);
    // The same command seen again is not claimed or run a second time.
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, []);
    assert.strictEqual(claims(reqs).length, 0);

    // 2. Another host already claimed it: not run, left pending, nothing written to the queue.
    cmd = pendingCmd();
    store = makeStore({ coordinator: me, queue: [cmd], claimAnswer: () => false });
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [], 'a command another host claimed is never run here');
    assert.strictEqual(claims(reqs).length, 1);
    assert.strictEqual(queuePatch(reqs), undefined);
    reqs = await runCycle(store);
    assert.strictEqual(claims(reqs).length, 0, 'and it is not asked about again');

    // 3. The store could not answer the claim: not run now, tried again on the next cycle.
    cmd = pendingCmd();
    let claimMode = null;
    store = makeStore({ coordinator: me, queue: [cmd], claimAnswer: () => claimMode });
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [], 'without an answer from the store the command waits');
    claimMode = true;
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [cmd.id], 'and runs once the store can be asked');

    // 4. A deferred command hands its claim back and is retried.
    cmd = pendingCmd();
    store = makeStore({ coordinator: me, queue: [cmd] });
    execResult = { deferCommand: true };
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [cmd.id]);
    assert.strictEqual(releases(reqs).length, 1, 'a deferred command releases its claim');
    assert.strictEqual(releases(reqs)[0].claimKey, claims(reqs)[0].claimKey);
    assert.strictEqual(queuePatch(reqs), undefined);
    execResult = { ok: true };
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [cmd.id], 'and is taken again on the next cycle');

    // 5. A command addressed to this host by id needs no claim, whoever holds the duty.
    cmd = pendingCmd({ targetDeviceId: 'pc-self' });
    store = makeStore({ coordinator: { ...me, deviceId: 'pc-other' }, queue: [cmd] });
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [cmd.id]);
    assert.strictEqual(claims(reqs).length, 0);

    // 6. Another host holds the duty: an untargeted command is left to it and the shared state is not written.
    cmd = pendingCmd();
    store = makeStore({ coordinator: { ...me, deviceId: 'pc-other' }, queue: [cmd] });
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, []);
    assert.strictEqual(claims(reqs).length, 0);
    fp = fleetPatch(reqs);
    assert.ok(!('state' in fp.patch), 'only the coordinator writes the shared state');
    assert.deepStrictEqual(Object.keys(fp.patch.device_states), ['pc-self'], 'but every host always writes its own entry');

    // 7. A host on a build from before equal hosts is online: stand back, whichever way it is detected.
    for (const legacyStore of [
      makeStore({ coordinator: { ...me, legacyLead: true }, queue: [pendingCmd()] }),
      makeStore({ coordinator: me, queue: [pendingCmd()], deviceStates: { 'old-host': freshPeer('old-host', 'primary') } })
    ]) {
      reqs = await runCycle(legacyStore);
      assert.deepStrictEqual(executed, [], 'nothing runs twice while an older host still leads');
      assert.strictEqual(claims(reqs).length, 0);
      assert.ok(!('state' in fleetPatch(reqs).patch));
    }

    // 8. A store without equal hosts (older Worker): the whole fleet map in the old shape, no claims, and the
    //    lowest device id among the online hosts acts.
    cmd = pendingCmd();
    store = makeStore({ coordinator: null, queue: [cmd], deviceStates: { 'pc-zeta': freshPeer('pc-zeta') } });
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [cmd.id]);
    assert.strictEqual(claims(reqs).length, 0, 'an older store is never asked for a claim');
    fp = fleetPatch(reqs);
    assert.deepStrictEqual(Object.keys(fp.patch.device_states).sort(), ['pc-self', 'pc-zeta']);
    assert.ok(Array.isArray(fp.patch.device_states['pc-self'].rows));
    assert.ok(fp.patch.state);
    cmd = pendingCmd();
    store = makeStore({ coordinator: null, queue: [cmd], deviceStates: { 'pc-alpha0': freshPeer('pc-alpha0') } });
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [], 'with an older store the other online host has the lower id');
    assert.ok(!('state' in fleetPatch(reqs).patch));

    // 9. A command that arrived directly is noted, so its queued copy is a no-op here and on every other host.
    store = makeStore({ coordinator: me });
    await runCycle(store);
    const directCmd = { cmdId: `cmd-smoke-direct-${process.pid}-${Date.now()}`, createdAt: Date.now(), type: 'refresh' };
    store.requests.length = 0;
    executed.length = 0;
    let directOut = await syncBridge.executeDirectCommand({ ...directCmd });
    assert.strictEqual(directOut.ok, true);
    assert.deepStrictEqual(executed, [directCmd.cmdId], 'the direct command itself always runs');
    await new Promise((resolve) => setImmediate(resolve));
    assert.strictEqual(claims(store.requests).length, 1, 'an untargeted direct command is claimed in the store');
    const queuedCopy = { id: directCmd.cmdId, createdAt: directCmd.createdAt, status: 'pending', type: 'refresh' };
    const directClaimKey = claims(store.requests)[0].claimKey;
    // The same command arriving again over another direct path is answered, not run again.
    executed.length = 0;
    const repeatOut = await syncBridge.executeDirectCommand({ ...directCmd });
    assert.deepStrictEqual([repeatOut.ok, repeatOut.duplicate], [true, true]);
    assert.deepStrictEqual(executed, [], 'a repeated direct command is not run twice');
    store = makeStore({ coordinator: me, queue: [queuedCopy] });
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [], 'the queued copy of a command already run directly is skipped');
    assert.strictEqual(syncBridge.storeClaimKey(`${queuedCopy.id}:${queuedCopy.createdAt}`), directClaimKey, 'both paths claim the same key');
    const closedCopy = queuePatch(reqs).patch.queue.commands.find((c) => c.id === queuedCopy.id);
    assert.deepStrictEqual([closedCopy.status, closedCopy.via], ['done', 'direct'], 'and is closed in the queue, not left pending');
    assert.strictEqual(queuePatch(reqs).patch.queue.results[queuedCopy.id].via, 'direct');
    // After a restart (a new bridge, nothing in memory) a queued copy that is still pending is not run either:
    // the note on disk lasts as long as the store's own claims.
    {
      const restarted = new TheoRemoteBridge(null, { hub: { lastPosted: JSON.stringify({ rows: [] }), snapshot: {} } });
      if (restarted.edgeClient) restarted.edgeClient.stop();
      restarted.deviceInfo = syncBridge.deviceInfo;
      restarted.peerCachePathOverride = peerCacheTmp;
      restarted.lastStateCachePath = lastStateTmp;
      restarted.relayConfig.url = 'https://store.invalid/store';
      restarted.relayConfig.key = 'k'.repeat(64);
      restarted.pushDevices = [];
      restarted.syncFromDiskPersonalLedger = () => {};
      restarted.ensureCloudPrayerTimersArmed = async () => {};
      restarted.evaluateRealtimePushAlerts = async () => {};
      restarted.workspacesDetailCachedAt = Date.now();
      restarted.getThreadDetail = async (id) => ({ id, messages: [] });
      const ranAfterRestart = [];
      restarted.executeRemoteCommand = async (c) => {
        ranAfterRestart.push(c.id);
        return { ok: true };
      };
      for (const target of ['pc-self', undefined]) {
        const stale = makeStore({ coordinator: me, queue: [{ ...queuedCopy, ...(target ? { targetDeviceId: target } : {}) }] });
        restarted.postStore = (payload) => stale.post(payload);
        restarted._lastFleetFollowAt = 0;
        restarted.cloudSyncInFlight = false;
        const res = await restarted.syncCloudRelay({ pushState: true });
        assert.ok(res && res.ok);
      }
      assert.deepStrictEqual(ranAfterRestart, [], 'a command already run is not run again after a restart');
      const claimedOnDisk = JSON.parse(fs.readFileSync(claimedTmp, 'utf8'));
      assert.ok(claimedOnDisk[`${queuedCopy.id}:${queuedCopy.createdAt}`] > 0);
    }
    // An untargeted direct command whose queued copy another host already took is not run here.
    store = makeStore({ coordinator: me, claimAnswer: () => false });
    await runCycle(store);
    executed.length = 0;
    const lateOut = await syncBridge.executeDirectCommand({ cmdId: `cmd-smoke-late-${process.pid}-${Date.now()}`, createdAt: Date.now(), type: 'refresh' });
    assert.deepStrictEqual([lateOut.ok, lateOut.duplicate, lateOut.claimedElsewhere], [true, true, true]);
    assert.deepStrictEqual(executed, [], 'a direct command another host already claimed is not run');
    // A direct command that fails is un-noted, so the queued copy can still run.
    const failedCmd = { cmdId: `cmd-smoke-failed-${process.pid}-${Date.now()}`, createdAt: Date.now(), type: 'refresh' };
    store = makeStore({ coordinator: me });
    await runCycle(store);
    store.requests.length = 0;
    execResult = { ok: false, error: 'boom' };
    directOut = await syncBridge.executeDirectCommand({ ...failedCmd });
    assert.strictEqual(directOut.ok, false);
    await new Promise((resolve) => setTimeout(resolve, 20));
    assert.strictEqual(releases(store.requests).length, 1, 'a failed direct command hands its claim back');
    execResult = { ok: true };
    store = makeStore({ coordinator: me, queue: [{ id: failedCmd.cmdId, createdAt: failedCmd.createdAt, status: 'pending', type: 'refresh' }] });
    reqs = await runCycle(store);
    assert.deepStrictEqual(executed, [failedCmd.cmdId]);
    // A repeat that arrives while the first is still running gets that run's result, so a slow failure is never
    // reported to the phone as success; a repeat after a successful run gets the finished result back.
    {
      store = makeStore({ coordinator: me });
      await runCycle(store);
      const slowCmd = { cmdId: `cmd-smoke-slow-${process.pid}-${Date.now()}`, createdAt: Date.now(), targetDeviceId: 'pc-self', type: 'refresh' };
      let releaseSlow = null;
      const realExec = syncBridge.executeRemoteCommand;
      let slowRuns = 0;
      syncBridge.executeRemoteCommand = async () => {
        slowRuns++;
        await new Promise((resolve) => {
          releaseSlow = resolve;
        });
        return { ok: false, error: 'slow failure' };
      };
      const firstRun = syncBridge.executeDirectCommand({ ...slowCmd });
      const repeatRun = syncBridge.executeDirectCommand({ ...slowCmd });
      await new Promise((resolve) => setImmediate(resolve));
      releaseSlow();
      const [firstOut, repeatDuring] = await Promise.all([firstRun, repeatRun]);
      assert.strictEqual(slowRuns, 1, 'a repeat never starts a second run');
      assert.deepStrictEqual([firstOut.ok, repeatDuring.ok, repeatDuring.error], [false, false, 'slow failure']);
      // The failed command was un-noted: a later attempt runs.
      syncBridge.executeRemoteCommand = async () => ({ ok: true, sessionId: 'sess-new-1' });
      const retryOut = await syncBridge.executeDirectCommand({ ...slowCmd });
      assert.deepStrictEqual([retryOut.ok, retryOut.sessionId, retryOut.duplicate], [true, 'sess-new-1', undefined]);
      const afterDone = await syncBridge.executeDirectCommand({ ...slowCmd });
      assert.deepStrictEqual([afterDone.ok, afterDone.sessionId, afterDone.duplicate], [true, 'sess-new-1', true], 'a late repeat gets the finished result, fields included');
      syncBridge.executeRemoteCommand = realExec;
    }
    // A targeted direct command, and one without a command id, never touch the store.
    store = makeStore({ coordinator: me });
    await runCycle(store);
    store.requests.length = 0;
    await syncBridge.executeDirectCommand({ cmdId: `cmd-smoke-targeted-${process.pid}`, createdAt: 1, targetDeviceId: 'pc-self', type: 'refresh' });
    await syncBridge.executeDirectCommand({ type: 'refresh' });
    await new Promise((resolve) => setImmediate(resolve));
    assert.strictEqual(store.requests.length, 0);

    if (prevClaimedEnv === undefined) delete process.env.THEO_CLAIMED_CMDS_PATH;
    else process.env.THEO_CLAIMED_CMDS_PATH = prevClaimedEnv;
    for (const tmpFile of [peerCacheTmp, claimedTmp, lastStateTmp]) {
      try {
        fs.unlinkSync(tmpFile);
      } catch {}
    }

    // (h) A relay move: the store address follows the relay with no per-PC step, and a wrong address cannot strand
    //     a host. Runs on credential and device files of its own.
    {
      const credTmp = path.join(os.tmpdir(), `theo-cred-smoke-${process.pid}.json`);
      const devTmp = path.join(os.tmpdir(), `theo-device-smoke-${process.pid}.json`);
      const moveEnvKeys = ['THEO_CRED_PATH', 'THEO_DEVICE_PATH', 'THEO_EDGE_KEY', 'THEO_EDGE_RELAY_URL', 'THEO_CLOUD_URL', 'THEO_CLOUD_KEY'];
      const moveEnvSaved = Object.fromEntries(moveEnvKeys.map((k) => [k, process.env[k]]));
      for (const k of moveEnvKeys) delete process.env[k];
      process.env.THEO_CRED_PATH = credTmp;
      process.env.THEO_DEVICE_PATH = devTmp;
      try {
        const b64 = (s) => Buffer.from(s, 'utf8').toString('base64');
        const edgeKey = 'c'.repeat(64);
        const storeOf = (host) => `https://${host}.example/store`;
        fs.writeFileSync(
          credTmp,
          JSON.stringify({ u: b64('https://legacy.example/flow'), k: b64('legacy-key'), edgeAccessKey: edgeKey, edgeRelayUrl: 'wss://edge-one.example/ws', port: 4318 }),
          'utf8'
        );
        fs.writeFileSync(devTmp, JSON.stringify({ id: 'Bad Id!', name: 'Main Workstation', role: 'primary' }), 'utf8');
        const readCredFile = () => JSON.parse(fs.readFileSync(credTmp, 'utf8'));

        // A paired host uses the store behind its relay, and saving any setting leaves the file's own address alone.
        let moveCreds = devId.loadTheoCredentials();
        assert.deepStrictEqual([moveCreds.cloudSource, moveCreds.cloudUrl], ['edge', storeOf('edge-one')]);
        assert.strictEqual(moveCreds.cloudKey, devId.deriveEdgeAuthToken(edgeKey));
        assert.strictEqual(moveCreds.fileCloudUrl, 'https://legacy.example/flow');
        devId.saveTheoCredentials({ allowLan: true });
        assert.strictEqual(Buffer.from(readCredFile().u, 'base64').toString('utf8'), 'https://legacy.example/flow', 'a derived address is never written over the file\'s own');
        assert.strictEqual(Buffer.from(readCredFile().k, 'base64').toString('utf8'), 'legacy-key');
        assert.strictEqual(readCredFile().allowLan, true);

        // A saved identity from an older build is brought into shape: usable id, computer name, the one role.
        assert.strictEqual(devId.cleanDeviceId('pc-a_1.b'), 'pc-a_1.b');
        assert.strictEqual(devId.cleanDeviceId('My PC #1'), 'my-pc-1');
        assert.strictEqual(devId.cleanDeviceId(''), '');
        const movedIdentity = devId.getDeviceIdentity();
        assert.deepStrictEqual([movedIdentity.id, movedIdentity.role], ['bad-id', 'host']);
        assert.strictEqual(movedIdentity.name, os.hostname() || 'Workstation', 'a name an older build assigned gives way to the computer name');
        const savedDevice = JSON.parse(fs.readFileSync(devTmp, 'utf8'));
        assert.deepStrictEqual([savedDevice.id, savedDevice.role, savedDevice.name], ['bad-id', 'host', movedIdentity.name]);

        const moveBridge = new TheoRemoteBridge(null, { hub: { lastPosted: JSON.stringify({ rows: [] }), snapshot: {} } });
        if (moveBridge.edgeClient) moveBridge.edgeClient.stop();
        moveBridge.edgeClient = null;
        // Only the move itself is under test here: keep the background sync cycle (which would follow an announced
        // relay by itself) out of it.
        moveBridge.syncCloudRelay = async () => null;
        assert.strictEqual(moveBridge.relayConfig.url, storeOf('edge-one'));
        const movePosts = [];
        moveBridge.postStore = async (payload) => {
          movePosts.push({ url: moveBridge.relayConfig.url, payload });
          return { ok: true };
        };
        let probeAnswer = false;
        const probed = [];
        moveBridge.probeStore = async (url) => {
          probed.push(url);
          return probeAnswer;
        };

        // 1. The store behind the new relay does not answer yet: keep the store that works, pin nothing, ask later.
        await moveBridge.setEffectiveEdgeUrl('wss://edge-two.example/ws', { broadcastCloud: false });
        assert.strictEqual(moveBridge.relayConfig.url, storeOf('edge-one'), 'the host stays on the store that answers');
        assert.deepStrictEqual(probed, [storeOf('edge-two')]);
        assert.strictEqual(readCredFile().edgeRelayUrl, 'wss://edge-two.example/ws');
        assert.ok(!('cloudPinned' in readCredFile()), 'a failed check never pins the store address');
        assert.strictEqual(Buffer.from(readCredFile().u, 'base64').toString('utf8'), 'https://legacy.example/flow');
        await moveBridge.settleStoreAddress();
        assert.strictEqual(probed.length, 1, 'the waiting store is asked at most once a minute');
        moveBridge.pendingStore.checkedAt = Date.now() - 61000;
        probeAnswer = true;
        assert.strictEqual(await moveBridge.settleStoreAddress(), true);
        assert.strictEqual(moveBridge.relayConfig.url, storeOf('edge-two'), 'once it answers, the host moves with no restart');
        assert.strictEqual(moveBridge.relayConfig.key, devId.deriveEdgeAuthToken(edgeKey));
        assert.strictEqual(moveBridge.pendingStore, null);
        await new Promise((resolve) => setTimeout(resolve, 25));
        const joined = movePosts.find((p) => p.payload.patch && p.payload.patch.edge_relay);
        assert.deepStrictEqual([joined.url, joined.payload.patch.edge_relay.url], [storeOf('edge-two'), 'wss://edge-two.example/ws'], 'the store just joined is told where the relay is');

        // A store that already announces a relay somewhere else again is not overwritten: the fleet has moved on.
        {
          movePosts.length = 0;
          const realPost = moveBridge.postStore;
          moveBridge.postStore = async (payload) => {
            movePosts.push({ url: moveBridge.relayConfig.url, payload });
            return payload.op === 'get_control' ? { ok: true, docs: { edge_relay: { url: 'wss://edge-later.example/ws' } } } : { ok: true };
          };
          await moveBridge.setEffectiveEdgeUrl('wss://edge-four.example/ws', { broadcastCloud: false });
          assert.strictEqual(moveBridge.relayConfig.url, storeOf('edge-four'));
          await new Promise((resolve) => setTimeout(resolve, 25));
          assert.strictEqual(movePosts.filter((p) => p.payload.patch && p.payload.patch.edge_relay).length, 0, 'a newer announcement in the joined store is left for the next cycle to follow');
          moveBridge.postStore = realPost;
          await moveBridge.setEffectiveEdgeUrl('wss://edge-two.example/ws', { broadcastCloud: false });
          assert.strictEqual(moveBridge.relayConfig.url, storeOf('edge-two'));
          await new Promise((resolve) => setTimeout(resolve, 25));
        }

        // 2. A mistyped relay address, then the right one: the host recovers by itself.
        probeAnswer = false;
        await moveBridge.setEffectiveEdgeUrl('wss://typo.example/ws', { broadcastCloud: false });
        assert.strictEqual(moveBridge.relayConfig.url, storeOf('edge-two'));
        assert.ok(moveBridge.pendingStore);
        probeAnswer = true;
        await moveBridge.setEffectiveEdgeUrl('wss://edge-two.example/ws', { broadcastCloud: false });
        assert.strictEqual(moveBridge.relayConfig.url, storeOf('edge-two'));
        assert.strictEqual(moveBridge.pendingStore, null, 'correcting the address clears the wait');
        moveCreds = devId.loadTheoCredentials();
        assert.deepStrictEqual([moveCreds.cloudSource, moveCreds.cloudUrl, moveCreds.cloudPinned], ['edge', storeOf('edge-two'), false]);

        // 3. A move announced in the store is followed only after the store behind the announced relay answers.
        let followCalls = 0;
        const realSetEdge = moveBridge.setEffectiveEdgeUrl.bind(moveBridge);
        moveBridge.setEffectiveEdgeUrl = async (...args) => {
          followCalls++;
          return realSetEdge(...args);
        };
        probeAnswer = false;
        assert.strictEqual(await moveBridge.followAnnouncedEdgeRelay('wss://edge-three.example/ws'), false);
        assert.strictEqual(followCalls, 0, 'an announced relay whose store does not answer is not followed');
        assert.strictEqual(readCredFile().edgeRelayUrl, 'wss://edge-two.example/ws');
        probeAnswer = true;
        assert.strictEqual(await moveBridge.followAnnouncedEdgeRelay('wss://edge-three.example/ws'), false, 'a refused address is left alone for ten minutes');
        moveBridge._edgeFollowRefused.at = Date.now() - 11 * 60 * 1000;
        assert.strictEqual(await moveBridge.followAnnouncedEdgeRelay('wss://edge-three.example/ws'), true);
        assert.strictEqual(followCalls, 1);
        assert.strictEqual(moveBridge.relayConfig.url, storeOf('edge-three'));
        assert.strictEqual(readCredFile().edgeRelayUrl, 'wss://edge-three.example/ws');
      } finally {
        for (const k of moveEnvKeys) {
          if (moveEnvSaved[k] === undefined) delete process.env[k];
          else process.env[k] = moveEnvSaved[k];
        }
        for (const tmpFile of [credTmp, devTmp]) {
          try {
            fs.unlinkSync(tmpFile);
          } catch {}
        }
      }
    }
    console.log('[PASS] Equal hosts: sync cycle against a stand-in store (claims, duty, fleet entry, legacy host, older store, direct commands)');
  }
  if (prevFleetHomesEnv === undefined) delete process.env.THEO_FLEET_HOMES_PATH;
  else process.env.THEO_FLEET_HOMES_PATH = prevFleetHomesEnv;
  try {
    fs.unlinkSync(fleetHomesTmp);
  } catch {}

  let capturedEdgeUrl = '';
  mockBridge.setEffectiveEdgeUrl = async (u) => {
    capturedEdgeUrl = u;
    return { ok: true };
  };
  for (const payload of [{ url: 'wss://a.example/ws' }, { edgeRelayUrl: 'wss://b.example/ws' }]) {
    const rawNextUrl = payload.edgeRelayUrl !== undefined ? payload.edgeRelayUrl : payload.url;
    await mockBridge.setEffectiveEdgeUrl(String(rawNextUrl || '').trim());
    assert.strictEqual(capturedEdgeUrl, payload.edgeRelayUrl || payload.url);
  }

  // Red-Team H-1 / L-1 / M-5: Behavioral HTTP execution of TheoRemoteBridge.handleHttpRequest
  const unitBridgeTok = devId.deriveEdgeAuthToken('unit-test-http-bridge-secret');
  mockBridge.getDerivedBridgeToken = () => unitBridgeTok;
  mockBridge.verifyBridgeToken = (tok) => Boolean(tok && tok === unitBridgeTok);
  const bridgeHttpSrv = http.createServer((req, res) => {
    mockBridge.handleHttpRequest(req, res).catch((err) => {
      res.writeHead(500);
      res.end(String(err));
    });
  });
  await new Promise((resolve) => bridgeHttpSrv.listen(0, '127.0.0.1', resolve));
  const bridgeHttpPort = bridgeHttpSrv.address().port;
  try {
    const baseBridgeUrl = `http://127.0.0.1:${bridgeHttpPort}`;
    // Unauthenticated /api/ping -> 200 with authenticated: false & authRequired: true (H-1)
    const unauthPing = await fetch(`${baseBridgeUrl}/api/ping`);
    assert.strictEqual(unauthPing.status, 200);
    const unauthPingJson = await unauthPing.json();
    assert.strictEqual(unauthPingJson.authenticated, false, 'Unauthenticated /api/ping must set authenticated: false (H-1)');
    assert.strictEqual(unauthPingJson.authRequired, true, 'Unauthenticated /api/ping must set authRequired: true');

    // Authenticated /api/ping -> 200 with authenticated: true
    const authPing = await fetch(`${baseBridgeUrl}/api/ping`, {
      headers: { Authorization: `Bearer ${unitBridgeTok}` }
    });
    const authPingJson = await authPing.json();
    assert.strictEqual(authPingJson.authenticated, true, 'Authenticated /api/ping must set authenticated: true');

    // Unauthenticated /api/pairing-info & /api/pair-code -> 401
    const unauthPairInfo = await fetch(`${baseBridgeUrl}/api/pairing-info`);
    assert.strictEqual(unauthPairInfo.status, 401, 'Unauthenticated /api/pairing-info must return 401');
    const unauthPairCode = await fetch(`${baseBridgeUrl}/api/pair-code`, { method: 'POST' });
    assert.strictEqual(unauthPairCode.status, 401, 'Unauthenticated /api/pair-code must return 401');

    // Authenticated /api/pairing-info -> 200 with single-quoted PowerShell command & dual field names (L-1)
    const authPairInfo = await fetch(`${baseBridgeUrl}/api/pairing-info`, {
      headers: { Authorization: `Bearer ${unitBridgeTok}` }
    });
    assert.strictEqual(authPairInfo.status, 200);
    const authPairInfoJson = await authPairInfo.json();
    assert.strictEqual(authPairInfoJson.pairUrl, authPairInfoJson.mobilePairUrl, 'pairUrl and mobilePairUrl must match');
    assert.strictEqual(
      authPairInfoJson.workstationCmd,
      authPairInfoJson.workstationBootstrapPs1,
      'workstationCmd and workstationBootstrapPs1 must match'
    );
    if (authPairInfoJson.workstationCmd) {
      assert.ok(
        authPairInfoJson.workstationCmd.startsWith("$env:THEO_PAIR_TOKEN='"),
        'workstationCmd must single-quote $env:THEO_PAIR_TOKEN in PowerShell (L-1)'
      );
    }
  } finally {
    await new Promise((resolve) => bridgeHttpSrv.close(resolve));
  }
  console.log('[PASS] Adversarial #1: Zero repo secrets, DO /pair/create+/pair/claim+429+alarm, C-1/H-1/L-1 HTTP & #pair= checks');

  // 3. Adversarial Check #2: RFC 6455 WS server Origin gate, Auth gate (4001), onConnect post-auth firing, & unmasked/continuation validation
  const { attachWebSocketServer } = require(path.join(ROOT, 'ws-server.js'));
  const expectedSecret = devId.deriveEdgeAuthToken('unit-test-secret-key');
  let onConnectFiredCount = 0;
  const srv = http.createServer((req, res) => {
    res.writeHead(200);
    res.end('ok');
  });
  const wss = attachWebSocketServer(srv, {
    path: '/ws',
    verifyUpgrade: (req) => {
      const origin = String(req.headers.origin || '');
      if (origin && origin !== 'http://127.0.0.1' && origin !== 'https://husseinbdeir.github.io') {
        return { ok: false, status: 403, message: 'Forbidden Origin' };
      }
      return { ok: true };
    },
    verifyToken: (tok) => tok === expectedSecret,
    onConnect: (conn) => {
      onConnectFiredCount += 1;
      conn.sendJson({ type: 'welcome', ok: true });
    }
  });
  await new Promise((resolve) => srv.listen(0, '127.0.0.1', resolve));
  const port = srv.address().port;

  try {
    // 3a. Hostile Origin must be rejected with HTTP 403 before WS upgrade completes
    const evilStatus = await new Promise((resolve, reject) => {
      const req = http.request({
        host: '127.0.0.1',
        port,
        path: '/ws',
        headers: {
          Connection: 'Upgrade',
          Upgrade: 'websocket',
          Origin: 'https://evil.attacker.example',
          'Sec-WebSocket-Version': '13',
          'Sec-WebSocket-Key': Buffer.from('1234567890123456').toString('base64')
        }
      });
      req.on('response', (res) => {
        res.resume();
        resolve(res.statusCode);
      });
      req.on('upgrade', (_, sock) => {
        sock.destroy();
        resolve(101);
      });
      req.on('error', reject);
      req.end();
    });
    assert.strictEqual(evilStatus, 403, 'Evil Origin must receive 403');

    // 3b. Wrong token over WS must be rejected with close code 4001
    const badCloseCode = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, {
        headers: { Origin: 'https://husseinbdeir.github.io' }
      });
      const t = setTimeout(() => reject(new Error('WS close timeout')), 4000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ type: 'auth', token: 'wrong-token' }));
      });
      ws.addEventListener('close', (ev) => {
        clearTimeout(t);
        resolve(ev.code);
      });
    });
    assert.strictEqual(badCloseCode, 4001, 'Invalid WS auth token must close with 4001');
    assert.strictEqual(onConnectFiredCount, 0, 'onConnect must NEVER fire before valid WS token auth');

    // 3c. Valid token succeeds, receives auth_ok AND welcome from onConnect fallback
    const authedOk = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, {
        headers: { Origin: 'https://husseinbdeir.github.io' }
      });
      const seenTypes = new Set();
      const t = setTimeout(() => reject(new Error('WS auth_ok + welcome timeout')), 4000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ type: 'auth', token: expectedSecret }));
      });
      ws.addEventListener('message', (ev) => {
        const msg = JSON.parse(String(ev.data));
        seenTypes.add(msg.type);
        if (seenTypes.has('auth_ok') && seenTypes.has('welcome')) {
          clearTimeout(t);
          ws.close();
          resolve(true);
        }
      });
    });
    assert.strictEqual(authedOk, true);
    assert.strictEqual(onConnectFiredCount, 1, 'onConnect must fire exactly once after valid WS auth');

    // 3d. Unexpected RFC 6455 continuation frame (opcode 0x0 with no fragmented message) closes cleanly without crashing
    const protoClose = await new Promise((resolve) => {
      const sock = net.connect(port, '127.0.0.1', () => {
        const key = Buffer.from('abcdefghijklmnop').toString('base64');
        sock.write(
          `GET /ws HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: ${key}\r\n\r\n`
        );
      });
      let upgraded = false;
      let buf = Buffer.alloc(0);
      sock.on('data', (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        if (!upgraded && buf.includes('\r\n\r\n')) {
          upgraded = true;
          // Masked FIN=1 opcode=0x0 (unexpected continuation) length=2 mask=0x11223344 payload=0x0000
          const badFrame = Buffer.from([0x80, 0x82, 0x11, 0x22, 0x33, 0x44, 0x11, 0x22]);
          sock.write(badFrame);
        }
      });
      sock.on('close', () => resolve(true));
    });
    assert.strictEqual(protoClose, true);
  } finally {
    wss.closeAll();
    await new Promise((resolve) => srv.close(resolve));
  }
  console.log('[PASS] Adversarial #2: WS Origin 403, invalid-token 4001, valid auth_ok, and RFC 6455 protocol-error guard');

  // 4. Adversarial Check #3: Cortex SQLite protobuf decoder & sidecar recovery + missing-ID safety
  const { AntigravityDataStore } = require(path.join(ROOT, 'store.js'));
  const store = new AntigravityDataStore();
  assert.strictEqual(store.readCliConversationDbDetail('../../etc/passwd'), null, 'Path traversal ID must return null');
  assert.strictEqual(store.readCliConversationDbDetail('00000000-0000-0000-0000-000000000000'), null);
  const cliConvDir = path.join(os.homedir(), '.gemini', 'antigravity-cli', 'conversations');
  if (fs.existsSync(cliConvDir)) {
    const dbFiles = fs.readdirSync(cliConvDir).filter((f) => f.endsWith('.db'));
    if (dbFiles.length > 0) {
      let decodedAny = 0;
      for (const f of dbFiles.slice(0, 5)) {
        const cid = f.replace(/\.db$/, '');
        const parsed = store.readCliConversationDbDetail(cid);
        if (parsed && Array.isArray(parsed.messages) && parsed.messages.length > 0) {
          decodedAny += 1;
        }
      }
      assert.ok(decodedAny > 0, 'Expected at least 1 CLI SQLite conversation to decode >0 messages');
      console.log(`[PASS] Adversarial #3: Decoded ${decodedAny}/${Math.min(5, dbFiles.length)} CLI SQLite conversations + rejected traversal IDs`);
    }
  } else {
    console.log('[PASS] Adversarial #3: Traversal & missing SQLite ID guards verified');
  }

  // 5. Adversarial Check #4: >1.5MB transcript_full.jsonl thoughtBlocks/checkpoint/subagent + readSafeFilePreview traversal/secret rejection
  const remoteMod = require(path.join(ROOT, 'remote.js'));
  assert.strictEqual(remoteMod.isSensitivePreviewPath('../../.theo/credentials.json'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('.env.local'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('config/client_secret.json'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('keys/server.pem'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('remote.js\0.md'), true);
  assert.strictEqual(remoteMod.isSensitivePreviewPath('js/app.js'), false);

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-smoke-transcript-'));
  try {
    const compactLog = path.join(tmpDir, 'transcript.jsonl');
    const fullLog = path.join(tmpDir, 'transcript_full.jsonl');
    const padLine = JSON.stringify({
      step_index: 0,
      type: 'PLANNER_RESPONSE',
      status: 'DONE',
      created_at: '2026-11-08T10:00:00Z',
      content: 'padding '.repeat(210000)
    });
    const steps = [
      padLine,
      JSON.stringify({
        step_index: 1,
        type: 'USER_INPUT',
        status: 'DONE',
        created_at: '2026-11-08T10:01:00Z',
        content: '<USER_REQUEST>Audit subagents</USER_REQUEST>'
      }),
      JSON.stringify({
        step_index: 2,
        type: 'CHECKPOINT',
        status: 'DONE',
        created_at: '2026-11-08T10:01:05Z',
        content: 'Compacted 42 prior steps into context summary.'
      }),
      JSON.stringify({
        step_index: 3,
        type: 'PLANNER_RESPONSE',
        status: 'DONE',
        created_at: '2026-11-08T10:01:12Z',
        thinking: 'Mapping architecture before spawning Red-Team subagent.',
        tool_calls: [
          {
            id: 'tc-sub-1',
            name: 'default_api:invoke_subagent',
            arguments: {
              TypeName: 'red-team-gate',
              Role: '7-Axis Red-Team Auditor',
              Prompt: 'Audit git diff across 7 axes'
            }
          }
        ]
      }),
      JSON.stringify({
        step_index: 4,
        type: 'TOOL_RESPONSE',
        tool_call_id: 'tc-sub-1',
        created_at: '2026-11-08T10:01:20Z',
        content: '{"conversationId":"11111111-2222-3333-4444-555555555555","status":"running"}'
      }),
      JSON.stringify({
        step_index: 5,
        type: 'PLANNER_RESPONSE',
        status: 'DONE',
        created_at: '2026-11-08T10:01:29Z',
        thinking: 'Synthesizing final audit report.',
        content: 'All 7 axes verified clean.'
      })
    ];
    // Compact log lacks thinking; fullLog is >1.6MB and has full thinking
    fs.writeFileSync(compactLog, JSON.stringify({ step_index: 1, type: 'USER_INPUT', content: 'hi' }) + '\n', 'utf8');
    fs.writeFileSync(fullLog, steps.join('\n') + '\n', 'utf8');
    assert.ok(fs.statSync(fullLog).size > 1550 * 1024, 'fullLog must exceed 1.5MB threshold');

    const parsedLarge = remoteMod.parseAntigravityTranscriptFile(compactLog, 40);
    const ckpt = parsedLarge.messages.find((m) => m.role === 'checkpoint');
    assert.ok(ckpt && ckpt.text.includes('Compacted 42 prior steps'), 'Expected CHECKPOINT message preserved');
    const asst = parsedLarge.messages.filter((m) => m.role === 'assistant').pop();
    assert.ok(asst, 'Expected assistant turn after checkpoint');
    assert.ok(Array.isArray(asst.thoughtBlocks) && asst.thoughtBlocks.length === 2, 'Expected 2 coalesced thoughtBlocks from >1.5MB transcript_full.jsonl');
    assert.ok(asst.thinkingDurationSec >= 10, 'Expected positive thinkingDurationSec');
    const subTc = (asst.toolCalls || []).find((tc) => tc.kind === 'subagent');
    assert.ok(subTc, 'Expected invoke_subagent classified as kind=subagent');
    assert.strictEqual(subTc.subagentRole, '7-Axis Red-Team Auditor');
    assert.strictEqual(subTc.subagentConversationId, '11111111-2222-3333-4444-555555555555');
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  const previewBridge = new remoteMod.TheoRemoteBridge({ hub: { snapshot: { threads: [] } } });
  const okPrev = await previewBridge.readSafeFilePreview({
    path: `file:///${path.join(ROOT, 'remote.js').replace(/\\/g, '/')}#L1-L15`
  });
  assert.strictEqual(okPrev.ok, true, 'Expected valid workspace file preview to succeed');
  assert.strictEqual(okPrev.startLine, 1);
  assert.strictEqual(okPrev.endLine, 15);
  assert.ok(okPrev.content.includes('crypto'), 'Expected file content in preview');
  assert.strictEqual(okPrev.diffPatch, okPrev.gitDiff, 'Expected diffPatch alias matching gitDiff');

  const blockedTraversal = await previewBridge.readSafeFilePreview({ path: '../../.theo/credentials.json' });
  assert.strictEqual(blockedTraversal.ok, false);
  assert.strictEqual(blockedTraversal.status, 403);

  const blockedEnv = await previewBridge.readSafeFilePreview({ path: '.env.production' });
  assert.strictEqual(blockedEnv.ok, false);
  assert.strictEqual(blockedEnv.status, 403);

  const blockedDevVars = await previewBridge.readSafeFilePreview({ path: '.dev.vars' });
  assert.strictEqual(blockedDevVars.ok, false);
  assert.strictEqual(blockedDevVars.status, 403);

  const blockedSqlite = await previewBridge.readSafeFilePreview({ path: 'cache.sqlite-wal' });
  assert.strictEqual(blockedSqlite.ok, false);
  assert.strictEqual(blockedSqlite.status, 403);

  const blockedOutside = await previewBridge.readSafeFilePreview({
    path: process.platform === 'win32' ? 'C:\\Windows\\System32\\drivers\\etc\\hosts' : '/etc/hosts'
  });
  assert.strictEqual(blockedOutside.ok, false);
  assert.strictEqual(blockedOutside.status, 403);

  // Ephemeral HTTP server adversarial check on handleHttpRequest (auth + sensitive preview + static dotfile block)
  previewBridge.verifyBridgeToken = (tok) => tok === 'smoke-test-bridge-token';
  const httpSrv = http.createServer((req, res) => {
    previewBridge.handleHttpRequest(req, res).catch((err) => {
      res.writeHead(500);
      res.end(String(err));
    });
  });
  await new Promise((resolve) => httpSrv.listen(0, '127.0.0.1', resolve));
  try {
    const port = httpSrv.address().port;
    const base = `http://127.0.0.1:${port}`;

    const unauthedRes = await fetch(`${base}/api/file-preview?path=remote.js`);
    assert.strictEqual(unauthedRes.status, 401, 'Unauthenticated GET /api/file-preview must return 401');

    const authedSecretRes = await fetch(`${base}/api/file-preview?path=.dev.vars`, {
      headers: { Authorization: 'Bearer smoke-test-bridge-token' }
    });
    assert.strictEqual(authedSecretRes.status, 403, 'Authenticated GET /api/file-preview for .dev.vars must return 403');

    const authedOkRes = await fetch(
      `${base}/api/file-preview?path=${encodeURIComponent(`file:///${path.join(ROOT, 'remote.js').replace(/\\/g, '/')}#L1-L5`)}`,
      { headers: { Authorization: 'Bearer smoke-test-bridge-token' } }
    );
    assert.strictEqual(authedOkRes.status, 200, 'Authenticated GET /api/file-preview for workspace file must return 200');
    const authedOkBody = await authedOkRes.json();
    assert.strictEqual(authedOkBody.ok, true);
    assert.strictEqual(authedOkBody.diffPatch, authedOkBody.gitDiff);

    const dotGitStaticRes = await fetch(`${base}/.git/config`);
    assert.strictEqual(dotGitStaticRes.status, 404, 'Static handler must block /.git/config with 404');

    const dotEnvStaticRes = await fetch(`${base}/.env`);
    assert.strictEqual(dotEnvStaticRes.status, 404, 'Static handler must block /.env with 404');

    const unauthedCapRes = await fetch(`${base}/api/studio-capabilities?workspaceId=theo-hub`);
    assert.strictEqual(unauthedCapRes.status, 401, 'Unauthenticated GET /api/studio-capabilities must return 401');

    const authedCapRes = await fetch(`${base}/api/studio-capabilities?workspaceId=theo-hub`, {
      headers: { Authorization: 'Bearer smoke-test-bridge-token' }
    });
    assert.strictEqual(authedCapRes.status, 200, 'Authenticated GET /api/studio-capabilities must return 200');
    const capBody = await authedCapRes.json();
    assert.strictEqual(capBody.ok, true);
    assert.ok(Array.isArray(capBody.checks) && capBody.checks.some((c) => c.id === 'syntax:remote.js'), 'Expected syntax:remote.js check discovered');
    assert.ok(Array.isArray(capBody.skills), 'Expected discovered skills array');
    assert.ok(Array.isArray(capBody.ports), 'Expected probed ports array');

    const badWsCapRes = await fetch(`${base}/api/studio-capabilities?workspaceId=../../etc`, {
      headers: { Authorization: 'Bearer smoke-test-bridge-token' }
    });
    assert.strictEqual(badWsCapRes.status, 403, 'Unknown/traversal workspaceId must return 403');

    const unauthedCheckRes = await fetch(`${base}/api/studio-check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ workspaceId: 'theo-hub', checkId: 'syntax:remote.js' })
    });
    assert.strictEqual(unauthedCheckRes.status, 401, 'Unauthenticated POST /api/studio-check must return 401');

    const injectedCheckRes = await fetch(`${base}/api/studio-check`, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer smoke-test-bridge-token',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ workspaceId: 'theo-hub', checkId: 'git:status; rm -rf /' })
    });
    assert.strictEqual(injectedCheckRes.status, 403, 'Injected checkId must be rejected with 403');

    const unknownCheckRes = await fetch(`${base}/api/studio-check`, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer smoke-test-bridge-token',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ workspaceId: 'theo-hub', checkId: 'arbitrary:command' })
    });
    assert.strictEqual(unknownCheckRes.status, 403, 'Unlisted checkId must be rejected with 403');

    const validCheckRes = await fetch(`${base}/api/studio-check`, {
      method: 'POST',
      headers: {
        Authorization: 'Bearer smoke-test-bridge-token',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ workspaceId: 'theo-hub', checkId: 'syntax:remote.js' })
    });
    assert.strictEqual(validCheckRes.status, 200, 'Allowlisted syntax:remote.js check must return 200');
    const validCheckBody = await validCheckRes.json();
    assert.strictEqual(validCheckBody.ok, true);
    assert.strictEqual(validCheckBody.passed, true);

    const parsedDiags = remoteMod.parseCheckDiagnostics(
      `${path.join(ROOT, 'remote.js')}:142:9: SyntaxError: Unexpected token\n${path.join(ROOT, '.env')}:1:1: Secret leak`,
      ROOT
    );
    assert.strictEqual(parsedDiags.length, 1, 'Expected sensitive .env diagnostic filtered out and remote.js:142 retained');
    assert.strictEqual(parsedDiags[0].relPath, 'remote.js');
    assert.strictEqual(parsedDiags[0].line, 142);
  } finally {
    await new Promise((resolve) => httpSrv.close(resolve));
    previewBridge.dispose();
  }
  console.log('[PASS] Adversarial #4: >1.5MB thoughtBlocks/checkpoint/subagent parser + HTTP/static readSafeFilePreview traversal/secret guards');

  // 6. Adversarial Check #5: Stream-interruption auto-compact (/compact -> CHECKPOINT -> chunked resume) + loop guards
  const agyBridge = require(path.join(ROOT, 'compat', 'antigravity-hub-bridge.cjs'));
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": EOF'),
    true,
    'Go SSE : EOF must be recognized as transient network error'
  );
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('There was a network issue connecting to the server, please try again.'),
    true,
    'Generic network issue connecting to the server must be recognized as transient network error'
  );
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('http2: client connection force closed via ClientConn.Close'),
    true,
    'http2 client connection force closed must be recognized as transient network error'
  );
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('stream idle timeout (5m0s): context deadline exceeded'),
    false,
    'Pure stream idle timeout / context deadline exceeded alone must NOT be classified as transient'
  );
  assert.strictEqual(
    agyBridge.isTransientNetworkErrorText('RESOURCE_EXHAUSTED: quota exceeded'),
    false,
    'Quota errors must NEVER be classified as transient'
  );

  const tmpBrainDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-smoke-brain-'));
  const prevBrainRoot = process.env.THEO_BRAIN_ROOT_DIR;
  process.env.THEO_BRAIN_ROOT_DIR = tmpBrainDir;
  try {
    const writeTranscript = (cid, stepObjs, mtimeSec) => {
      const logDir = path.join(tmpBrainDir, cid, '.system_generated', 'logs');
      fs.mkdirSync(logDir, { recursive: true });
      const file = path.join(logDir, 'transcript.jsonl');
      fs.writeFileSync(file, stepObjs.map((s) => JSON.stringify(s)).join('\n') + '\n', 'utf8');
      if (mtimeSec) {
        fs.utimesSync(file, mtimeSec, mtimeSec);
      }
    };
    const baseNow = 1794227000;
    const elevenHoursAgo = baseNow - 40000;
    const isoAt = (sec) => new Date(sec * 1000).toISOString();

    // 6a. Mixed retry sequence (stream interrupted + EOF + stream idle timeout + network issue) at 241.5k tokens & 11h age -> /compact
    writeTranscript(
      'cid-mixed-241k',
      [
        { step_index: 94, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(elevenHoursAgo - 300), content: '<USER_REQUEST>Redesign fleet dashboard</USER_REQUEST>' },
        { step_index: 95, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 240), input_tokens: 241501, content: '' },
        { step_index: 96, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 200), content: 'Error: The stream was interrupted. Please continue the task you were working on.' },
        { step_index: 97, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 150), input_tokens: 241533, content: '' },
        { step_index: 98, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 100), content: 'Error: Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": EOF' },
        { step_index: 99, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(elevenHoursAgo - 50), content: 'Error: stream idle timeout (5m0s): context deadline exceeded' },
        { step_index: 100, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(elevenHoursAgo), content: 'Error: There was a network issue connecting to the server, please try again.' }
      ],
      elevenHoursAgo
    );
    const mixed241k = agyBridge.inspectCascadeInterruptedState('cid-mixed-241k', baseNow);
    assert.strictEqual(mixed241k.interrupted, true, '11h-old mixed stream-interruption sequence must be recoverable');
    assert.strictEqual(mixed241k.reason, 'transient_network_error');
    assert.strictEqual(mixed241k.needsCompactionFirst, true, '>=215k token stream interruption must trigger compaction first');
    assert.strictEqual(mixed241k.resumePrompt, '/compact');

    // 6b. Post-compact CHECKPOINT step with pendingPostCompactResume=true -> CHUNKED_STREAM_RESUME_PROMPT
    writeTranscript(
      'cid-post-compact',
      [
        { step_index: 112, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 20), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 113, type: 'CHECKPOINT', status: 'DONE', created_at: isoAt(baseNow - 10), input_tokens: 245036, content: '# Resuming from a compaction' }
      ],
      baseNow - 10
    );
    const postCompact = agyBridge.inspectCascadeInterruptedState('cid-post-compact', baseNow, {
      pendingPostCompactResume: true
    });
    assert.strictEqual(postCompact.interrupted, true);
    assert.strictEqual(postCompact.reason, 'post_compact_auto_resume');
    assert.strictEqual(postCompact.resumePrompt, agyBridge.CHUNKED_STREAM_RESUME_PROMPT);

    // 6c. Negative assertion #1: Pure stream idle timeout (without stream interruption / EOF) must NOT auto-resume
    writeTranscript(
      'cid-pure-timeout',
      [
        { step_index: 1, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: 'run' },
        { step_index: 2, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 120), content: 'Error: stream idle timeout (5m0s): context deadline exceeded' },
        { step_index: 3, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 60), content: 'Error: stream idle timeout (5m0s): context deadline exceeded' }
      ],
      baseNow - 60
    );
    const pureTimeout = agyBridge.inspectCascadeInterruptedState('cid-pure-timeout', baseNow);
    assert.strictEqual(pureTimeout.interrupted, false);
    assert.strictEqual(pureTimeout.reason, 'repeated_error_message');

    // 6d. Negative assertion #2: Loop guard after CHUNKED_STREAM_RESUME_PROMPT fails again -> repeated_error_message
    writeTranscript(
      'cid-chunked-loop-guard',
      [
        { step_index: 10, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 300), content: 'Error: The stream was interrupted.' },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>` },
        { step_index: 12, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(baseNow - 150), input_tokens: 190000, content: '' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: The stream was interrupted.' }
      ],
      baseNow - 90
    );
    const chunkedLoopGuard = agyBridge.inspectCascadeInterruptedState('cid-chunked-loop-guard', baseNow);
    assert.strictEqual(chunkedLoopGuard.interrupted, false, 'Must stop if CHUNKED_STREAM_RESUME_PROMPT is followed by another error');
    assert.strictEqual(chunkedLoopGuard.reason, 'repeated_error_message');

    // 6e. Fallback + loop guard after /compact fails: transient error falls back ONCE to CHUNKED_STREAM_RESUME_PROMPT; non-transient or subsequent chunked failure stops
    writeTranscript(
      'cid-compact-loop-guard',
      [
        { step_index: 10, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 300), content: 'Error: The stream was interrupted.' },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 12, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(baseNow - 150), input_tokens: 242000, content: '' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: pre-invocation hook: context summarization: net/http: TLS handshake timeout' }
      ],
      baseNow - 90
    );
    const compactFallback = agyBridge.inspectCascadeInterruptedState('cid-compact-loop-guard', baseNow);
    assert.strictEqual(compactFallback.interrupted, true, 'Transient network failure during /compact must fall back once to chunked resume');
    assert.strictEqual(compactFallback.requiresNetworkCheck, true);
    assert.strictEqual(compactFallback.needsCompactionFirst, false);
    assert.strictEqual(compactFallback.resumePrompt, agyBridge.CHUNKED_STREAM_RESUME_PROMPT);

    writeTranscript(
      'cid-compact-non-transient-guard',
      [
        { step_index: 10, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 300), content: 'Error: The stream was interrupted.' },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: invalid_argument: context length exceeded' }
      ],
      baseNow - 90
    );
    const compactNonTransient = agyBridge.inspectCascadeInterruptedState('cid-compact-non-transient-guard', baseNow);
    assert.strictEqual(compactNonTransient.interrupted, false, 'Non-transient failure after /compact must stop immediately');
    assert.strictEqual(compactNonTransient.reason, 'repeated_error_message');

    writeTranscript(
      'cid-compact-then-chunked-guard',
      [
        { step_index: 10, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 300), content: 'Error: The stream was interrupted.' },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 160), content: 'Error: net/http: TLS handshake timeout' },
        { step_index: 14, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 120), content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>` },
        { step_index: 15, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: The stream was interrupted.' }
      ],
      baseNow - 90
    );
    const compactThenChunkedGuard = agyBridge.inspectCascadeInterruptedState('cid-compact-then-chunked-guard', baseNow);
    assert.strictEqual(compactThenChunkedGuard.interrupted, false, 'Must stop once both /compact and CHUNKED_STREAM_RESUME_PROMPT have failed');
    assert.strictEqual(compactThenChunkedGuard.reason, 'repeated_error_message');

    // 6e-2. Disk-flushed /compact or chunked error when pre-compact stream drop was unflushed (transcript step 10 = PLANNER_RESPONSE with tool_calls)
    writeTranscript(
      'cid-planner-compact-tls-fallback',
      [
        { step_index: 10, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(baseNow - 300), input_tokens: 226190, content: '', tool_calls: [{ id: 'tc1', name: 'edit_file' }] },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: pre-invocation hook: context summarization: net/http: TLS handshake timeout' }
      ],
      baseNow - 90
    );
    const plannerCompactTls = agyBridge.inspectCascadeInterruptedState('cid-planner-compact-tls-fallback', baseNow);
    assert.strictEqual(plannerCompactTls.interrupted, true);
    assert.strictEqual(plannerCompactTls.requiresNetworkCheck, true);
    assert.strictEqual(plannerCompactTls.needsCompactionFirst, false);
    assert.strictEqual(
      plannerCompactTls.resumePrompt,
      agyBridge.CHUNKED_STREAM_RESUME_PROMPT,
      'Flushed TLS handshake timeout after /compact on interrupted PLANNER_RESPONSE must select CHUNKED_STREAM_RESUME_PROMPT, never bare continue'
    );

    writeTranscript(
      'cid-planner-compact-nontransient',
      [
        { step_index: 10, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(baseNow - 300), input_tokens: 226190, content: '', tool_calls: [{ id: 'tc1', name: 'edit_file' }] },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: invalid_argument: context length exceeded' }
      ],
      baseNow - 90
    );
    const plannerCompactNonTransient = agyBridge.inspectCascadeInterruptedState('cid-planner-compact-nontransient', baseNow);
    assert.strictEqual(plannerCompactNonTransient.interrupted, false, 'Non-transient /compact error after interrupted PLANNER_RESPONSE must stop');
    assert.strictEqual(plannerCompactNonTransient.reason, 'repeated_error_message');

    writeTranscript(
      'cid-planner-chunked-loop-guard',
      [
        { step_index: 10, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(baseNow - 300), input_tokens: 226190, content: '', tool_calls: [{ id: 'tc1', name: 'edit_file' }] },
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 200), content: '<USER_REQUEST>/compact</USER_REQUEST>' },
        { step_index: 13, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 160), content: 'Error: net/http: TLS handshake timeout' },
        { step_index: 14, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 120), content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>` },
        { step_index: 15, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoAt(baseNow - 90), content: 'Error: The stream was interrupted.' }
      ],
      baseNow - 90
    );
    const plannerChunkedGuard = agyBridge.inspectCascadeInterruptedState('cid-planner-chunked-loop-guard', baseNow);
    assert.strictEqual(plannerChunkedGuard.interrupted, false, 'Chunked error after interrupted PLANNER_RESPONSE must stop');
    assert.strictEqual(plannerChunkedGuard.reason, 'repeated_error_message');

    // compactFailed=true keeps minAgeSec=4 and alreadyTriedCompact=true latched across offline polls
    writeTranscript(
      'cid-compact-failed-latch',
      [
        { step_index: 10, type: 'PLANNER_RESPONSE', status: 'DONE', created_at: isoAt(baseNow - 8), input_tokens: 226190, content: '', tool_calls: [{ id: 'tc1', name: 'edit_file' }] }
      ],
      baseNow - 8
    );
    const compactFailedLatch = agyBridge.inspectCascadeInterruptedState('cid-compact-failed-latch', baseNow, {
      compactFailed: true,
      pendingCompactAt: baseNow - 10
    });
    assert.strictEqual(compactFailedLatch.interrupted, true, 'compactFailed latch must preserve 4s minAgeSec instead of stalling for 25s');
    assert.strictEqual(compactFailedLatch.alreadyTriedCompact, true, 'compactFailed latch must prevent sending a second /compact');
    assert.strictEqual(compactFailedLatch.needsCompactionFirst, false);

    // 6f. Negative assertion #4: Unanswered /compact USER_INPUT (and [/compact](slashCommand;compact)) must be treated as already_sent_continue
    assert.strictEqual(agyBridge.isAutoContinueUserPrompt('[/compact](slashCommand;compact)'), true);
    assert.strictEqual(
      agyBridge.isAutoContinueUserPrompt('<USER_REQUEST>\n[/compact](slashCommand;compact)\n</USER_REQUEST>'),
      true
    );
    writeTranscript(
      'cid-compact-pending',
      [
        { step_index: 11, type: 'USER_INPUT', status: 'DONE', created_at: isoAt(baseNow - 60), content: '<USER_REQUEST>[/compact](slashCommand;compact)</USER_REQUEST>' }
      ],
      baseNow - 60
    );
    const compactPending = agyBridge.inspectCascadeInterruptedState('cid-compact-pending', baseNow);
    assert.strictEqual(compactPending.interrupted, false);
    assert.strictEqual(compactPending.reason, 'already_sent_continue');

    // 6f-2. Negative assertion #5: Expired pendingCompactAt or out-of-window pendingCompactStepIndex must NOT fire post_compact_auto_resume on a later manual /compact
    const expiredPostCompact = agyBridge.inspectCascadeInterruptedState('cid-post-compact', baseNow, {
      pendingPostCompactResume: true,
      pendingCompactStepIndex: 111,
      pendingCompactAt: baseNow - 1200
    });
    assert.strictEqual(
      expiredPostCompact.interrupted,
      false,
      'Expired pendingPostCompactResume (>900s) must NOT auto-fire CHUNKED_STREAM_RESUME_PROMPT on a later manual /compact'
    );
    const farStepPostCompact = agyBridge.inspectCascadeInterruptedState('cid-post-compact', baseNow, {
      pendingPostCompactResume: true,
      pendingCompactStepIndex: 50,
      pendingCompactAt: baseNow - 30
    });
    assert.strictEqual(
      farStepPostCompact.interrupted,
      false,
      'Out-of-window pendingCompactStepIndex (>+4 steps) must NOT auto-fire post_compact_auto_resume'
    );

    // 6g. Behavioral test of sendDirectCascadeRpcMessage (/compact slashCommand item, paginated stepOffset, + missing userConfig rejection)
    let capturedRpcReq = null;
    const capturedStepsReqs = [];
    let mockSteps = [
      {
        type: 'CORTEX_STEP_TYPE_USER_INPUT',
        userInput: {
          userConfig: { plannerConfig: { planModel: 'MODEL_PLACEHOLDER_M417' } },
          userAgentSpec: { builtinAgent: { defaultAgent: { surface: 'AGENT_SURFACE_HUB' } } }
        }
      }
    ];
    const mockHubSrv = http.createServer((req, res) => {
      let body = '';
      req.on('data', (c) => (body += c));
      req.on('end', () => {
        if (req.url.endsWith('/GetCascadeTrajectorySteps')) {
          capturedStepsReqs.push(JSON.parse(body || '{}'));
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ steps: mockSteps }));
        } else if (req.url.endsWith('/SendUserCascadeMessage')) {
          capturedRpcReq = JSON.parse(body || '{}');
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end('{}');
        } else {
          res.writeHead(404);
          res.end();
        }
      });
    });
    await new Promise((resolve) => mockHubSrv.listen(0, '127.0.0.1', resolve));
    try {
      const mPort = mockHubSrv.address().port;
      const okCompact = await agyBridge.sendDirectCascadeRpcMessage(mPort, 'csrf-123', 'cid-1', {
        prompt: '/compact',
        stepHint: 111
      });
      assert.strictEqual(okCompact.ok, true);
      assert.strictEqual(okCompact.method, 'directRpc');
      assert.strictEqual(
        capturedStepsReqs[0]?.stepOffset,
        105,
        'sendDirectCascadeRpcMessage with stepHint=111 must query paginated tail stepOffset=105 first'
      );
      assert.strictEqual(capturedStepsReqs[0]?.stepLimit, 10);
      assert.strictEqual(capturedRpcReq.cascadeId, 'cid-1');
      assert.strictEqual(
        capturedRpcReq.items?.[0]?.item?.slashCommand?.info?.name,
        'compact',
        'sendDirectCascadeRpcMessage(/compact) must send SLASH_COMMAND_TYPE_SYSTEM compact item'
      );
      assert.strictEqual(
        capturedRpcReq.items?.[0]?.item?.slashCommand?.info?.type,
        'SLASH_COMMAND_TYPE_SYSTEM'
      );

      mockSteps = [];
      const noConfigRes = await agyBridge.sendDirectCascadeRpcMessage(mPort, 'csrf-123', 'cid-1', {
        prompt: '/compact'
      });
      assert.strictEqual(noConfigRes.ok, false, 'Missing userConfig must fail closed');
      assert.strictEqual(noConfigRes.reason, 'missing_user_config');

      // 6h. Steady-state checkAndResumeInterruptedCascades: unflushed STOP_REASON_CLIENT_STREAM_ERROR + orphaned PENDING tool steps + terminal live ERROR_MESSAGE -> /compact -> live CHECKPOINT -> CHUNKED_STREAM_RESUME_PROMPT
      const prevResumedPath = process.env.THEO_RESUMED_CASCADES_PATH;
      const tmpResumedPath = path.join(tmpBrainDir, 'bhf-resumed-cascades.json');
      process.env.THEO_RESUMED_CASCADES_PATH = tmpResumedPath;
      try {
        writeTranscript(
          'cid-stream-err-172',
          [
            {
              step_index: 1,
              type: 'USER_INPUT',
              status: 'DONE',
              created_at: isoAt(baseNow - 1200),
              content: '<USER_REQUEST>Check and resolve missing upgrades</USER_REQUEST>'
            },
            {
              step_index: 169,
              type: 'PLANNER_RESPONSE',
              status: 'DONE',
              created_at: isoAt(baseNow - 600),
              input_tokens: 249245,
              content: '',
              tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
            }
          ],
          baseNow - 600
        );
        const sentMessages = [];
        let liveTrajectorySteps = {
          0: {
            metadata: { stepIndex: 1 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE',
            userInput: {
              userConfig: { plannerConfig: { planModel: 'MODEL_PLACEHOLDER_M417' } },
              userAgentSpec: { builtinAgent: { defaultAgent: { surface: 'AGENT_SURFACE_HUB' } } }
            }
          },
          168: {
            metadata: { stepIndex: 168 },
            type: 'CORTEX_STEP_TYPE_CODE_ACTION',
            status: 'CORTEX_STEP_STATUS_DONE'
          },
          169: {
            metadata: { stepIndex: 169 },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: {
              stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR',
              toolCalls: [{ id: 'tc1', name: 'edit_file' }, { id: 'tc2', name: 'edit_file' }]
            }
          },
          170: {
            metadata: { stepIndex: 170 },
            type: 'CORTEX_STEP_TYPE_GENERIC',
            status: 'CORTEX_STEP_STATUS_PENDING'
          },
          171: {
            metadata: { stepIndex: 171 },
            type: 'CORTEX_STEP_TYPE_GENERIC',
            status: 'CORTEX_STEP_STATUS_PENDING'
          },
          172: {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                userErrorMessage: 'Agent execution terminated due to error.',
                shortError:
                  'agent executor error: generating and executing: stream reading error: http2: client connection force closed via ClientConn.Close'
              }
            }
          }
        };
        const baseStepZero = liveTrajectorySteps[0];
        const cascadeSrv = http.createServer((req, res) => {
          let b = '';
          req.on('data', (c) => (b += c));
          req.on('end', () => {
            if (req.url.endsWith('/GetAllCascadeTrajectories')) {
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(
                JSON.stringify({
                  trajectorySummaries: {
                    'cid-stream-err-172': {
                      status: 'CASCADE_RUN_STATUS_IDLE',
                      stepCount: Math.max(
                        173,
                        ...Object.keys(liveTrajectorySteps).map((k) => Number(k) + 1)
                      )
                    }
                  }
                })
              );
            } else if (req.url.endsWith('/GetCascadeTrajectorySteps')) {
              const parsed = JSON.parse(b || '{}');
              const offset = Number(parsed.stepOffset || 0);
              const limit = Number(parsed.stepLimit || 50);
              const out = [];
              for (const [k, v] of Object.entries(liveTrajectorySteps)) {
                const idx = Number(k);
                if (idx >= offset && out.length < limit) {
                  out.push(v);
                }
              }
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ steps: out }));
            } else if (req.url.endsWith('/SendUserCascadeMessage')) {
              sentMessages.push(JSON.parse(b || '{}'));
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end('{}');
            } else {
              res.writeHead(404);
              res.end();
            }
          });
        });
        await new Promise((resolve) => cascadeSrv.listen(0, '127.0.0.1', resolve));
        try {
          const cPort = cascadeSrv.address().port;
          const bState = agyBridge.getBridgeState();
          bState.serverManager = { port: cPort, csrfToken: 'csrf-test' };
          bState.resumeCheckInFlight = false;

          // Step 1: Orphaned PENDING steps 170-171 followed by ERROR_MESSAGE 172 must NOT block recovery -> sends /compact
          const res1 = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(res1.resumed, 1, 'Expected cid-stream-err-172 to auto-compact despite orphaned PENDING tool steps');
          assert.strictEqual(sentMessages.length, 1);
          assert.strictEqual(sentMessages[0]?.items?.[0]?.item?.slashCommand?.info?.name, 'compact');
          const savedMap1 = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMap1['cid-stream-err-172']?.stepIndex, 172);
          assert.strictEqual(savedMap1['cid-stream-err-172']?.reason, 'auto_compact_before_resume');
          assert.strictEqual(savedMap1['cid-stream-err-172']?.pendingPostCompactResume, true);

          // Step 2: Once /compact finishes in live RPC at Step 174 (CHECKPOINT DONE), next tick sends CHUNKED_STREAM_RESUME_PROMPT
          liveTrajectorySteps[173] = {
            metadata: { stepIndex: 173 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE'
          };
          liveTrajectorySteps[174] = {
            metadata: { stepIndex: 174 },
            type: 'CORTEX_STEP_TYPE_CHECKPOINT',
            status: 'CORTEX_STEP_STATUS_DONE'
          };
          const res2 = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 15,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(res2.resumed, 1, 'Expected post-compact CHECKPOINT at step 174 to auto-resume with chunked prompt');
          assert.strictEqual(sentMessages.length, 2);
          assert.strictEqual(sentMessages[1]?.items?.[0]?.text, agyBridge.CHUNKED_STREAM_RESUME_PROMPT);
          const savedMap2 = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMap2['cid-stream-err-172']?.stepIndex, 174);
          assert.strictEqual(savedMap2['cid-stream-err-172']?.reason, 'post_compact_auto_resume');
          assert.strictEqual(Boolean(savedMap2['cid-stream-err-172']?.pendingPostCompactResume), false);

          // Step 3 (Negative assertion): Genuine active PENDING/RUNNING tail step with no subsequent ERROR_MESSAGE must NOT resume
          fs.unlinkSync(tmpResumedPath);
          delete liveTrajectorySteps[172];
          delete liveTrajectorySteps[173];
          delete liveTrajectorySteps[174];
          liveTrajectorySteps[169].plannerResponse.stopReason = 'STOP_REASON_TOOL_CALL';
          liveTrajectorySteps[170].status = 'CORTEX_STEP_STATUS_RUNNING';
          const resActive = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 30,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resActive.resumed, 0, 'Genuinely running tail step must NOT be double-resumed');
          assert.strictEqual(sentMessages.length, 2);

          // Step 4 (Negative assertion): Live ERROR_MESSAGE with quota/resource_exhausted must NOT auto-resume
          liveTrajectorySteps[170].status = 'CORTEX_STEP_STATUS_PENDING';
          liveTrajectorySteps[172] = {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                shortError: 'RESOURCE_EXHAUSTED: quota exceeded for model'
              }
            }
          };
          const resQuota = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 45,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resQuota.resumed, 0, 'Live quota exceeded ERROR_MESSAGE must NOT auto-resume');
          assert.strictEqual(sentMessages.length, 2);

          // Step 5 (Negative assertion): Unflushed live ERROR_MESSAGE after CHUNKED_STREAM_RESUME_PROMPT turn must NOT loop
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>Check and resolve missing upgrades</USER_REQUEST>'
              },
              {
                step_index: 168,
                type: 'CHECKPOINT',
                status: 'DONE',
                created_at: isoAt(baseNow - 800),
                content: '# Resuming from compaction'
              },
              {
                step_index: 169,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 700),
                content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>`
              },
              {
                step_index: 170,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 600),
                input_tokens: 185000,
                content: 'Applying patch in chunks:',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 600
          );
          liveTrajectorySteps[169].plannerResponse.stopReason = 'STOP_REASON_CLIENT_STREAM_ERROR';
          liveTrajectorySteps[172] = {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                shortError: 'stream reading error: http2: client connection force closed via ClientConn.Close'
              }
            }
          };
          const resLoopGuard = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 60,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resLoopGuard.resumed,
            0,
            'Unflushed live ERROR_MESSAGE after CHUNKED_STREAM_RESUME_PROMPT turn must NOT loop'
          );
          assert.strictEqual(sentMessages.length, 2);

          // Step 6: Freshly booted hub (bypassMinAge=true) + PLANNER_RESPONSE with preface content + tool_calls still verifies live stepIndex=172
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>Check and resolve missing upgrades</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 5),
                input_tokens: 249245,
                content: 'Applying the final two edits now:',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 5
          );
          const resFreshBoot = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 10,
            bypassMinAge: true,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resFreshBoot.resumed, 1, 'Freshly booted hub must still verify live steps and compact');
          const savedMapFresh = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(
            savedMapFresh['cid-stream-err-172']?.stepIndex,
            172,
            'Freshly booted hub must record liveVerifiedMaxIdx=172 instead of stale transcript stepIndex=169'
          );

          // Step 7: Mid-prose stream error (lToolCalls.length === 0 in transcript.jsonl, unflushed STOP_REASON_CLIENT_STREAM_ERROR + live ERROR_MESSAGE at step 1155 like 87213501) -> auto-resumes!
          fs.unlinkSync(tmpResumedPath);
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>WTC vs SharePoint Cash Flow Discrepancy</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 30),
                input_tokens: 120554,
                content: 'The root cause of the discrepancy is:\n- **Manufacturing (WTC, BBConstruction & Holding (',
                tool_calls: []
              }
            ],
            baseNow - 30
          );
          delete liveTrajectorySteps[170];
          delete liveTrajectorySteps[171];
          liveTrajectorySteps[169] = {
            metadata: { stepIndex: 169, modelUsage: { inputTokens: 16927, cacheReadTokens: 103627 } },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: {
              stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR',
              response: 'The root cause of the discrepancy is:\n- **Manufacturing (WTC, BBConstruction & Holding ('
            }
          };
          liveTrajectorySteps[172] = {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                errorCode: 2,
                userErrorMessage: 'Agent execution terminated due to error.',
                shortError:
                  'agent executor error: generating and executing: stream reading error: http2: client connection force closed via ClientConn.Close'
              }
            }
          };
          const prevSentLen = sentMessages.length;
          const resMidProse = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resMidProse.resumed,
            1,
            'Unflushed live STOP_REASON_CLIENT_STREAM_ERROR + ERROR_MESSAGE after prose-only PLANNER_RESPONSE must auto-resume'
          );
          assert.strictEqual(sentMessages.length, prevSentLen + 1);
          assert.strictEqual(sentMessages[sentMessages.length - 1]?.items?.[0]?.text, 'continue');
          const savedMapMidProse = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMapMidProse['cid-stream-err-172']?.stepIndex, 172);
          assert.strictEqual(savedMapMidProse['cid-stream-err-172']?.reason, 'error_message');

          // Step 8 (Negative assertion): Normal completed prose PLANNER_RESPONSE (STOP_REASON_STOP_PATTERN, no live ERROR_MESSAGE) must NOT auto-resume and must cache completed_prose_verified
          fs.unlinkSync(tmpResumedPath);
          delete liveTrajectorySteps[172];
          liveTrajectorySteps[169] = {
            metadata: { stepIndex: 169, modelUsage: { inputTokens: 16927, cacheReadTokens: 103627 } },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: {
              stopReason: 'STOP_REASON_STOP_PATTERN',
              response: 'Complete answer finished normally.'
            }
          };
          const resNormalProse = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 10,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resNormalProse.resumed,
            0,
            'Normal completed prose PLANNER_RESPONSE (STOP_REASON_STOP_PATTERN) must NEVER be auto-resumed'
          );
          assert.strictEqual(
            bState.__bhfVerifiedIdleProseCache instanceof Map &&
              bState.__bhfVerifiedIdleProseCache.has('cid-stream-err-172'),
            true,
            'Normal completed prose PLANNER_RESPONSE must be cached in __bhfVerifiedIdleProseCache so subsequent polls skip RPC'
          );

          // Step 8b (Negative assertion): Earlier error step superseded by a subsequent USER_INPUT + completed PLANNER_RESPONSE (or empty verifySteps) must NEVER auto-resume
          bState.__bhfVerifiedIdleProseCache.clear();
          liveTrajectorySteps[169] = {
            metadata: { stepIndex: 169 },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: { stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR' }
          };
          liveTrajectorySteps[172] = {
            metadata: { stepIndex: 172 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: { error: { shortError: 'http2: client connection force closed via ClientConn.Close' } }
          };
          liveTrajectorySteps[173] = {
            metadata: { stepIndex: 173 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE',
            userInput: { userResponse: 'continue' }
          };
          liveTrajectorySteps[174] = {
            metadata: { stepIndex: 174 },
            type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
            status: 'CORTEX_STEP_STATUS_DONE',
            plannerResponse: {
              stopReason: 'STOP_REASON_STOP_PATTERN',
              response: 'Resumed and finished cleanly.'
            }
          };
          const resSupersededError = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 20,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resSupersededError.resumed,
            0,
            'Negative: Earlier error step superseded by subsequent USER_INPUT + completed PLANNER_RESPONSE must NEVER auto-resume'
          );

          bState.__bhfVerifiedIdleProseCache.clear();
          liveTrajectorySteps = {};
          const resEmptyVerify = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 30,
            hubStartedAtSec: baseNow + 25,
            bypassMinAge: true,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resEmptyVerify.resumed,
            0,
            'Negative: Empty verifySteps on unflushed_live_stream_error must fail closed (resumed=0)'
          );

          // Step 8c: Exact a99d759e / 89e11fe5-811->813 scenario: plain "continue" (USER_INPUT) on disk followed by unflushed live ERROR_MESSAGE during Wi-Fi roam
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>Theo Avatar Redesign and Upgrade</USER_REQUEST>'
              },
              {
                step_index: 168,
                type: 'GENERIC',
                status: 'DONE',
                created_at: isoAt(baseNow - 60),
                content: 'Showing lines 2900-3540 of 4308'
              },
              {
                step_index: 169,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 45),
                error: 'wsarecv: A connection attempt failed because the connected party did not properly respond'
              },
              {
                step_index: 170,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 40),
                content: '<USER_REQUEST>\ncontinue\n</USER_REQUEST>'
              }
            ],
            baseNow - 40
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 169,
                reason: 'error_message',
                resumedAt: baseNow - 40
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            169: {
              metadata: { stepIndex: 169 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  shortError:
                    'Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": net/http: cannot rewind body after connection loss'
                }
              }
            },
            170: {
              metadata: { stepIndex: 170 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: {
                userResponse: 'continue',
                userConfig: { plannerConfig: { planModel: 'MODEL_PLACEHOLDER_M42' } }
              }
            },
            172: {
              metadata: { stepIndex: 172 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  userErrorMessage: 'Agent execution terminated due to error.',
                  shortError:
                    'agent executor error: generating and executing: request failed: Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": http2: client connection force closed via ClientConn.Close'
                }
              }
            }
          };
          const resWifiOffline = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 35,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => false
          });
          assert.strictEqual(
            resWifiOffline.resumed,
            0,
            'Negative: Must NOT send second-chance resume while networkOnlineCheck reports offline'
          );
          const sentBefore8c = sentMessages.length;
          const resAfterContinueErr = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 35,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resAfterContinueErr.resumed,
            1,
            'Unflushed live ERROR_MESSAGE after plain auto-continue must promote to CHUNKED_STREAM_RESUME_PROMPT once online'
          );
          assert.strictEqual(sentMessages.length, sentBefore8c + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT
          );
          const savedMap8c = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMap8c['cid-stream-err-172']?.stepIndex, 172);

          // Step 8d: Exact 2433423f / 4743e2dd scenario: auto_compact_before_resume (/compact) fails mid-summarization during Wi-Fi roam -> waits while offline without clobbering stepIndex -> falls back ONCE to CHUNKED_STREAM_RESUME_PROMPT when TLS recovers -> stops if chunked fallback also fails
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 60),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 60
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow - 10,
                pendingPostCompactResume: true
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            169: {
              metadata: { stepIndex: 169 },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: {
                stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR',
                toolCalls: [{ id: 'tc1', name: 'edit_file' }]
              }
            },
            172: {
              metadata: { stepIndex: 172 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  shortError:
                    'Post "https://daily-cloudcode-pa.googleapis.com/v1internal:streamGenerateContent?alt=sse": net/http: cannot rewind body after connection loss'
                }
              }
            },
            173: {
              metadata: { stepIndex: 173 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: {
                items: [{ item: { slashCommand: { info: { name: 'compact' } } } }],
                userConfig: { plannerConfig: { planModel: 'MODEL_PLACEHOLDER_M417' } }
              }
            },
            174: {
              metadata: { stepIndex: 174 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  userErrorMessage: 'Agent execution terminated due to error.',
                  shortError:
                    'agent executor error: pre-invocation hook: context summarization: failed to generate summary: http2: client connection force closed via ClientConn.Close'
                }
              }
            }
          };
          const resCompactErrOffline = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 50,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => false
          });
          assert.strictEqual(
            resCompactErrOffline.resumed,
            0,
            'Negative: Failed /compact during Wi-Fi outage must NOT fire fallback while TLS is still offline'
          );
          const savedAfterCompactOffline = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(
            savedAfterCompactOffline['cid-stream-err-172']?.stepIndex,
            172,
            'Failed /compact cleanup must NOT advance stepIndex to error step 174 before fallback runs'
          );
          assert.strictEqual(
            Boolean(savedAfterCompactOffline['cid-stream-err-172']?.pendingPostCompactResume),
            false
          );
          assert.strictEqual(
            savedAfterCompactOffline['cid-stream-err-172']?.compactFailed,
            true,
            'Offline poll after failed /compact must latch compactFailed=true'
          );
          const sentBefore8d = sentMessages.length;
          const resCompactErrOnline = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 55,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resCompactErrOnline.resumed,
            1,
            'Failed /compact must fall back once to CHUNKED_STREAM_RESUME_PROMPT once TLS :443 recovers'
          );
          assert.strictEqual(sentMessages.length, sentBefore8d + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT
          );
          const savedMap8d = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMap8d['cid-stream-err-172']?.stepIndex, 174);
          assert.strictEqual(Boolean(savedMap8d['cid-stream-err-172']?.compactFailed), false);

          liveTrajectorySteps[175] = {
            metadata: { stepIndex: 175 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE',
            userInput: {
              items: [{ text: agyBridge.CHUNKED_STREAM_RESUME_PROMPT }],
              userConfig: { plannerConfig: { planModel: 'MODEL_PLACEHOLDER_M417' } }
            }
          };
          liveTrajectorySteps[176] = {
            metadata: { stepIndex: 176 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                shortError: 'http2: client connection force closed via ClientConn.Close'
              }
            }
          };
          const resCompactThenChunkedErr = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 70,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resCompactThenChunkedErr.resumed,
            0,
            'Negative: Must stop if CHUNKED_STREAM_RESUME_PROMPT fallback after failed /compact also errors without tool progress'
          );

          // Step 8d-2: Young disk step (ageSec=8 < 25 and < 45) when /compact fails in live RPC must immediately fall back on first online poll without stalling 45s, AND flushed /compact + TLS timeout followed by unflushed non-transient live error must NOT loop
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 8),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 8
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow - 6,
                pendingPostCompactResume: true
              }
            }),
            'utf8'
          );
          delete liveTrajectorySteps[175];
          delete liveTrajectorySteps[176];
          const sentBeforeYoungCompactErr = sentMessages.length;
          const resYoungCompactErr = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resYoungCompactErr.resumed,
            1,
            'Young disk step (ageSec=8 < 45) with failed live /compact must immediately send CHUNKED_STREAM_RESUME_PROMPT on first online poll'
          );
          assert.strictEqual(sentMessages.length, sentBeforeYoungCompactErr + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT
          );

          // Flushed disk /compact + TLS timeout (steps 172..174) followed by unflushed live CHUNKED_STREAM_RESUME_PROMPT + non-transient error (steps 175..176)
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 171,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 90),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              },
              {
                step_index: 172,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 80),
                error: 'net/http: cannot rewind body after connection loss'
              },
              {
                step_index: 173,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 75),
                content: '<USER_REQUEST>[/compact](slashCommand;compact)</USER_REQUEST>'
              },
              {
                step_index: 174,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 50),
                error: 'net/http: TLS handshake timeout'
              }
            ],
            baseNow - 50
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 174,
                reason: 'error_message',
                resumedAt: baseNow - 40
              }
            }),
            'utf8'
          );
          liveTrajectorySteps[175] = {
            metadata: { stepIndex: 175 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE',
            userInput: {
              items: [{ text: agyBridge.CHUNKED_STREAM_RESUME_PROMPT }]
            }
          };
          liveTrajectorySteps[176] = {
            metadata: { stepIndex: 176 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                shortError: 'agent executor error: internal model failure'
              }
            }
          };
          const resFlushedCompactLiveNonTransient = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 10,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resFlushedCompactLiveNonTransient.resumed,
            0,
            'Negative: Flushed /compact + TLS timeout followed by unflushed live chunked-resume non-transient error must NOT loop'
          );

          // Live step 175 with empty items: [] and userResponse: CHUNKED_STREAM_RESUME_PROMPT followed by live transient network error 176 must ALSO stop (resumed === 0)
          liveTrajectorySteps[175] = {
            metadata: { stepIndex: 175 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE',
            userInput: {
              items: [],
              userResponse: agyBridge.CHUNKED_STREAM_RESUME_PROMPT
            }
          };
          liveTrajectorySteps[176] = {
            metadata: { stepIndex: 176 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                shortError: 'http2: client connection force closed via ClientConn.Close'
              }
            }
          };
          const resUserResponseFallbackLoopGuard =
            await agyBridge.checkAndResumeInterruptedCascades(bState, {
              candidateIds: ['cid-stream-err-172'],
              nowSec: baseNow + 12,
              hubStartedAtSec: baseNow - 3600,
              networkOnlineCheck: () => true
            });
          assert.strictEqual(
            resUserResponseFallbackLoopGuard.resumed,
            0,
            'Negative: Live userInput with items:[] + userResponse=CHUNKED_STREAM_RESUME_PROMPT followed by transient error must NOT loop'
          );

          // Live step 176 CORTEX_STEP_TYPE_EPHEMERAL_MESSAGE (DONE) injected between CHUNKED_STREAM_RESUME_PROMPT (175) and ERROR_MESSAGE (177) must NOT count as tool progress
          liveTrajectorySteps[176] = {
            metadata: { stepIndex: 176 },
            type: 'CORTEX_STEP_TYPE_EPHEMERAL_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE'
          };
          liveTrajectorySteps[177] = {
            metadata: { stepIndex: 177 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: {
              error: {
                shortError: 'http2: client connection force closed via ClientConn.Close'
              }
            }
          };
          const resEphemeralBetweenChunkedAndErr =
            await agyBridge.checkAndResumeInterruptedCascades(bState, {
              candidateIds: ['cid-stream-err-172'],
              nowSec: baseNow + 14,
              hubStartedAtSec: baseNow - 3600,
              networkOnlineCheck: () => true
            });
          assert.strictEqual(
            resEphemeralBetweenChunkedAndErr.resumed,
            0,
            'Negative: CORTEX_STEP_TYPE_EPHEMERAL_MESSAGE (DONE) after CHUNKED_STREAM_RESUME_PROMPT must NOT reset liveSawChunkedWithoutProgress'
          );
          delete liveTrajectorySteps[177];

          // Disk CHUNKED_STREAM_RESUME_PROMPT followed by unfinished PLANNER_RESPONSE (tool_calls: [tc1], zero DONE tools, no ERROR_MESSAGE) must return repeated_error_message
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 175,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 50),
                content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>`
              },
              {
                step_index: 176,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 35),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 35
          );
          const chkChunkedThenUnfinishedPlanner = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow
          );
          assert.strictEqual(chkChunkedThenUnfinishedPlanner.interrupted, false);
          assert.strictEqual(
            chkChunkedThenUnfinishedPlanner.reason,
            'repeated_error_message',
            'Negative: CHUNKED_STREAM_RESUME_PROMPT followed by unfinished PLANNER_RESPONSE without tool progress must stop'
          );

          // Step 8d-3: Genuine human turn AFTER a failed CHUNKED_STREAM_RESUME_PROMPT fallback must recover (on disk and in live RPC), AND /compact must re-arm after DONE tool progress, AND /compact failing with context deadline exceeded must fall back once to CHUNKED_STREAM_RESUME_PROMPT
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 173,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 90),
                content: '<USER_REQUEST>[/compact](slashCommand;compact)</USER_REQUEST>'
              },
              {
                step_index: 174,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 85),
                error:
                  'agent executor error: pre-invocation hook: context summarization: failed to generate summary: context deadline exceeded'
              }
            ],
            baseNow - 85
          );
          const chkCompactDeadlineDisk = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow
          );
          assert.strictEqual(
            chkCompactDeadlineDisk.interrupted,
            true,
            'Disk /compact failing with context deadline exceeded must fall back once to CHUNKED_STREAM_RESUME_PROMPT'
          );
          assert.strictEqual(
            chkCompactDeadlineDisk.resumePrompt,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT
          );

          // Live /compact failing with context deadline exceeded -> falls back once to CHUNKED_STREAM_RESUME_PROMPT
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 15),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 15
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow - 10,
                pendingPostCompactResume: true
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            169: {
              metadata: { stepIndex: 169 },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: { toolCalls: [{ id: 'tc1', name: 'edit_file' }] }
            },
            173: {
              metadata: { stepIndex: 173 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { items: [{ item: { slashCommand: { info: { name: 'compact' } } } }] }
            },
            174: {
              metadata: { stepIndex: 174 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  shortError:
                    'agent executor error: pre-invocation hook: context summarization: failed to generate summary: context deadline exceeded'
                }
              }
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const sentBeforeDeadlineCompact = sentMessages.length;
          const resLiveDeadlineCompact = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resLiveDeadlineCompact.resumed,
            1,
            'Live /compact failing with context deadline exceeded must send CHUNKED_STREAM_RESUME_PROMPT once'
          );
          assert.strictEqual(sentMessages.length, sentBeforeDeadlineCompact + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT
          );

          //Disk ends at repeated_error_message (step 176 after failed CHUNKED_STREAM_RESUME_PROMPT), then human sends new prompt in live RPC (177) + transient error (178) -> must recover!
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 175,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 80),
                content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>`
              },
              {
                step_index: 176,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 70),
                error: 'net/http: cannot rewind body after connection loss'
              }
            ],
            baseNow - 70
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 176,
                reason: 'error_message',
                resumedAt: baseNow - 80
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            175: {
              metadata: { stepIndex: 175 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { userResponse: agyBridge.CHUNKED_STREAM_RESUME_PROMPT }
            },
            176: {
              metadata: { stepIndex: 176 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: { error: { shortError: 'net/http: cannot rewind body after connection loss' } }
            },
            177: {
              metadata: { stepIndex: 177 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { userResponse: '<USER_REQUEST>Edit helper.js now</USER_REQUEST>' }
            },
            178: {
              metadata: { stepIndex: 178 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: { error: { shortError: 'net/http: cannot rewind body after connection loss' } }
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const resLiveNewHumanTurn = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 20,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resLiveNewHumanTurn.resumed,
            1,
            'Genuine new human USER_INPUT in live RPC after prior disk repeated_error_message must recover'
          );

          // Disk human turn after failed CHUNKED_STREAM_RESUME_PROMPT + re-armed /compact after DONE tool progress
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 173,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 300),
                content: '<USER_REQUEST>[/compact](slashCommand;compact)</USER_REQUEST>'
              },
              {
                step_index: 174,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 290),
                error: 'net/http: TLS handshake timeout'
              },
              {
                step_index: 175,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 280),
                content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>`
              },
              {
                step_index: 176,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 270),
                error: 'net/http: cannot rewind body after connection loss'
              },
              {
                step_index: 177,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 120),
                content: '<USER_REQUEST>Edit helper.js</USER_REQUEST>'
              },
              {
                step_index: 178,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 40),
                error: 'net/http: cannot rewind body after connection loss'
              }
            ],
            baseNow - 40
          );
          const chkDiskNewHumanTurn = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow
          );
          assert.strictEqual(
            chkDiskNewHumanTurn.interrupted,
            true,
            'Disk human USER_INPUT after prior failed CHUNKED_STREAM_RESUME_PROMPT must recover'
          );

          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 173,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 300),
                content: '<USER_REQUEST>[/compact](slashCommand;compact)</USER_REQUEST>'
              },
              {
                step_index: 174,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 290),
                error: 'net/http: TLS handshake timeout'
              },
              {
                step_index: 175,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 280),
                content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>`
              },
              {
                step_index: 176,
                type: 'GENERIC',
                status: 'DONE',
                created_at: isoAt(baseNow - 200),
                content: 'File edited'
              },
              {
                step_index: 177,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 40),
                input_tokens: 235000,
                content: '',
                tool_calls: [{ id: 'tc2', name: 'run_command', arguments: '{}' }]
              }
            ],
            baseNow - 40
          );
          const chkRearmedCompact = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow
          );
          assert.strictEqual(chkRearmedCompact.interrupted, true);
          assert.strictEqual(
            chkRearmedCompact.needsCompactionFirst,
            true,
            'DONE tool progress after an earlier failed /compact must re-arm needsCompactionFirst on >=215k stream drops'
          );
          assert.strictEqual(chkRearmedCompact.resumePrompt, '/compact');

          // Trailing SYSTEM_MESSAGE after failed live /compact ERROR_MESSAGE must still latch compactFailed and send CHUNKED_STREAM_RESUME_PROMPT
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 8),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 8
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow - 6,
                pendingPostCompactResume: true
              }
            }),
            'utf8'
          );
          liveTrajectorySteps[175] = {
            metadata: { stepIndex: 175 },
            type: 'CORTEX_STEP_TYPE_SYSTEM_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE'
          };
          delete liveTrajectorySteps[176];
          const sentBeforeTrailingSys = sentMessages.length;
          const resTrailingSys = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resTrailingSys.resumed,
            1,
            'Trailing SYSTEM_MESSAGE after failed live /compact ERROR_MESSAGE must still fall back to CHUNKED_STREAM_RESUME_PROMPT'
          );
          assert.strictEqual(sentMessages.length, sentBeforeTrailingSys + 1);

          // Mid-prose PLANNER_RESPONSE (DONE, non-empty content, no tool_calls, >=215k tokens) followed on disk by CHUNKED_STREAM_RESUME_PROMPT + ERROR_MESSAGE must NEVER loop
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 90),
                input_tokens: 226190,
                content: 'Mid-prose interrupted output before Wi-Fi roam',
                tool_calls: []
              },
              {
                step_index: 175,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 50),
                content: `<USER_REQUEST>${agyBridge.CHUNKED_STREAM_RESUME_PROMPT}</USER_REQUEST>`
              },
              {
                step_index: 176,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 35),
                error: 'net/http: cannot rewind body after connection loss'
              }
            ],
            baseNow - 35
          );
          const chkMidProseChunkedErr = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow
          );
          assert.strictEqual(chkMidProseChunkedErr.interrupted, false);
          assert.strictEqual(
            chkMidProseChunkedErr.reason,
            'repeated_error_message',
            'Negative: Disk CHUNKED_STREAM_RESUME_PROMPT + ERROR_MESSAGE after mid-prose PLANNER_RESPONSE must return repeated_error_message'
          );

          // Step 8d-4: Offline /compact deadline failure (including >15m outage), UNAUTHENTICATED/RESOURCE_EXHAUSTED hard blocks, live tool progress after chunked resume, and user-cancelled + trailing SYSTEM_MESSAGE
          assert.strictEqual(
            chkCompactDeadlineDisk.requiresNetworkCheck,
            true,
            'Disk /compact failing with context deadline exceeded must require TLS network check'
          );
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 2400),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 1300),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 1300
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow - 1200,
                pendingPostCompactResume: true
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            169: {
              metadata: { stepIndex: 169 },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: { toolCalls: [{ id: 'tc1', name: 'edit_file' }] }
            },
            173: {
              metadata: { stepIndex: 173 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { items: [{ item: { slashCommand: { info: { name: 'compact' } } } }] }
            },
            174: {
              metadata: { stepIndex: 174 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  shortError:
                    'agent executor error: pre-invocation hook: context summarization: failed to generate summary: context deadline exceeded'
                }
              }
            }
          };
          // First poll at t = baseNow - 1190 (offline): latches compactFailed=true, does NOT fire offline
          const resDeadlineOffline1 = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow - 1190,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => false
          });
          assert.strictEqual(
            resDeadlineOffline1.resumed,
            0,
            'Negative: Offline live /compact context deadline exceeded must NOT fire CHUNKED_STREAM_RESUME_PROMPT while offline'
          );
          const mapDeadlineOffline1 = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(mapDeadlineOffline1['cid-stream-err-172']?.stepIndex, 172);
          assert.strictEqual(mapDeadlineOffline1['cid-stream-err-172']?.compactFailed, true);
          // Second poll >15 min later (20 min = 1200s > 900s, still offline): compactFailed stays latched!
          const resDeadlineOffline2 = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 10,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => false
          });
          assert.strictEqual(resDeadlineOffline2.resumed, 0);
          const mapDeadlineOffline2 = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(
            mapDeadlineOffline2['cid-stream-err-172']?.compactFailed,
            true,
            'compactFailed must remain latched across >15 min offline outages'
          );
          // Third poll when TLS :443 recovers at t = baseNow + 20: sends CHUNKED_STREAM_RESUME_PROMPT once!
          const sentBeforeLongOutageRecover = sentMessages.length;
          const resDeadlineOnlineAfterLongOutage = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 20,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resDeadlineOnlineAfterLongOutage.resumed,
            1,
            'Live /compact deadline failure must recover once with CHUNKED_STREAM_RESUME_PROMPT when TLS returns after >15m outage'
          );
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT
          );
          assert.strictEqual(sentMessages.length, sentBeforeLongOutageRecover + 1);

          // Hard auth/quota errors: UNAUTHENTICATED / invalid_grant (on /compact and normal turn) + single-error disk RESOURCE_EXHAUSTED
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 300),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 2,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 40),
                error: 'RESOURCE_EXHAUSTED: quota exceeded for model'
              }
            ],
            baseNow - 40
          );
          const chkSingleDiskQuota = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow
          );
          assert.strictEqual(
            chkSingleDiskQuota.interrupted,
            false,
            'Negative: Single-error disk RESOURCE_EXHAUSTED must NEVER return interrupted=true'
          );
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 300),
                content: '<USER_REQUEST>[/compact](slashCommand;compact)</USER_REQUEST>'
              },
              {
                step_index: 2,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 40),
                error: 'rpc error: code = Unauthenticated desc = invalid authentication credentials'
              }
            ],
            baseNow - 40
          );
          const chkCompactUnauth = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow
          );
          assert.strictEqual(
            chkCompactUnauth.interrupted,
            false,
            'Negative: UNAUTHENTICATED error on /compact must NEVER auto-resume'
          );
          assert.strictEqual(
            agyBridge.inspectCascadeInterruptedState &&
              agyBridge.checkAndResumeInterruptedCascades !== undefined,
            true
          );

          // Live CHUNKED_STREAM_RESUME_PROMPT -> real live tool execution (CODE_ACTION DONE) -> subsequent Wi-Fi drop ERROR_MESSAGE must recover!
          fs.unlinkSync(tmpResumedPath);
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 90),
                input_tokens: 195000,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 90
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            170: {
              metadata: { stepIndex: 170 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { userResponse: agyBridge.CHUNKED_STREAM_RESUME_PROMPT }
            },
            171: {
              metadata: { stepIndex: 171 },
              type: 'CORTEX_STEP_TYPE_CODE_ACTION',
              status: 'CORTEX_STEP_STATUS_DONE'
            },
            172: {
              metadata: { stepIndex: 172 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: { shortError: 'http2: client connection force closed via ClientConn.Close' }
              }
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const resLiveToolProgressAfterChunked = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 30,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resLiveToolProgressAfterChunked.resumed,
            1,
            'Live CODE_ACTION DONE after CHUNKED_STREAM_RESUME_PROMPT must re-arm recovery on subsequent live Wi-Fi drop'
          );

          // User-cancelled turn (CORTEX_STEP_STATUS_CANCELED) followed by trailing CORTEX_STEP_TYPE_SYSTEM_MESSAGE (DONE) + cancelled /compact must NEVER auto-resume
          fs.unlinkSync(tmpResumedPath);
          liveTrajectorySteps = {
            0: baseStepZero,
            170: {
              metadata: { stepIndex: 170 },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_CANCELED',
              plannerResponse: { response: 'Partial stopped output' }
            },
            171: {
              metadata: { stepIndex: 171 },
              type: 'CORTEX_STEP_TYPE_SYSTEM_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE'
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const resCanceledWithSysNoise = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 35,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resCanceledWithSysNoise.resumed,
            0,
            'Negative: User-cancelled step followed by trailing SYSTEM_MESSAGE must NEVER auto-resume'
          );
          const savedMapCanceledNoise = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMapCanceledNoise['cid-stream-err-172']?.reason, 'user_cancelled');

          // Empty CANCELED PLANNER_RESPONSE (stopped while thinking before emitting text/tools) + trailing SYSTEM_MESSAGE DONE must ALSO record user_cancelled and NEVER auto-resume
          fs.unlinkSync(tmpResumedPath);
          liveTrajectorySteps = {
            0: baseStepZero,
            170: {
              metadata: { stepIndex: 170 },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_CANCELED',
              plannerResponse: {}
            },
            171: {
              metadata: { stepIndex: 171 },
              type: 'CORTEX_STEP_TYPE_SYSTEM_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE'
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const resCanceledEmptyThink = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 36,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resCanceledEmptyThink.resumed,
            0,
            'Negative: Empty CANCELED PLANNER_RESPONSE followed by SYSTEM_MESSAGE DONE must NEVER auto-resume'
          );
          const savedMapCanceledEmptyThink = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMapCanceledEmptyThink['cid-stream-err-172']?.reason, 'user_cancelled');

          // CANCELED CORTEX_STEP_TYPE_THOUGHT + trailing SYSTEM_MESSAGE DONE must ALSO record user_cancelled and NEVER auto-resume
          fs.unlinkSync(tmpResumedPath);
          liveTrajectorySteps = {
            0: baseStepZero,
            170: {
              metadata: { stepIndex: 170 },
              type: 'CORTEX_STEP_TYPE_THOUGHT',
              status: 'CORTEX_STEP_STATUS_CANCELED'
            },
            171: {
              metadata: { stepIndex: 171 },
              type: 'CORTEX_STEP_TYPE_SYSTEM_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE'
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const resCanceledThought = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 37,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resCanceledThought.resumed,
            0,
            'Negative: CANCELED THOUGHT step followed by SYSTEM_MESSAGE DONE must NEVER auto-resume'
          );
          const savedMapCanceledThought = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMapCanceledThought['cid-stream-err-172']?.reason, 'user_cancelled');

          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow + 30,
                pendingPostCompactResume: true
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            173: {
              metadata: { stepIndex: 173 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_CANCELED',
              userInput: { items: [{ item: { slashCommand: { info: { name: 'compact' } } } }] }
            },
            174: {
              metadata: { stepIndex: 174 },
              type: 'CORTEX_STEP_TYPE_EPHEMERAL_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE'
            }
          };
          const resCanceledCompact = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 40,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resCanceledCompact.resumed,
            0,
            'Negative: Cancelled /compact followed by EPHEMERAL_MESSAGE must record user_cancelled and NOT auto-resume'
          );
          const savedMapCanceledCompact = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMapCanceledCompact['cid-stream-err-172']?.reason, 'user_cancelled');
          assert.strictEqual(Boolean(savedMapCanceledCompact['cid-stream-err-172']?.pendingPostCompactResume), false);

          // Step 8d-5: >50-step unflushed RPC pagination (check.stepIndex + 65), pre-check.stepIndex CODE_ACTION DONE preserving liveSawCompactSinceCheckpoint, and compactFailed clearance across human/tool progress
          fs.unlinkSync(tmpResumedPath);
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 90),
                input_tokens: 195000,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 90
          );
          const denseSteps = { 0: baseStepZero };
          for (let s = 165; s <= 231; s += 1) {
            denseSteps[s] = {
              metadata: { stepIndex: s },
              type: 'CORTEX_STEP_TYPE_CODE_ACTION',
              status: 'CORTEX_STEP_STATUS_DONE'
            };
          }
          denseSteps[232] = {
            metadata: { stepIndex: 232 },
            type: 'CORTEX_STEP_TYPE_USER_INPUT',
            status: 'CORTEX_STEP_STATUS_DONE',
            userInput: { userResponse: agyBridge.CHUNKED_STREAM_RESUME_PROMPT }
          };
          denseSteps[233] = {
            metadata: { stepIndex: 233 },
            type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
            status: 'CORTEX_STEP_STATUS_DONE',
            errorMessage: { error: { shortError: 'http2: client connection force closed via ClientConn.Close' } }
          };
          liveTrajectorySteps = denseSteps;
          bState.__bhfVerifiedIdleProseCache.clear();
          const resPaginatedExhausted = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 50,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resPaginatedExhausted.resumed,
            0,
            'Negative: >50-step unflushed RPC trajectory ending in failed CHUNKED_STREAM_RESUME_PROMPT must NOT loop'
          );

          // Same >50-step span where tail step 233 is an unflushed stream error after CODE_ACTION DONE at 232 -> must recover at step 233!
          denseSteps[232] = {
            metadata: { stepIndex: 232 },
            type: 'CORTEX_STEP_TYPE_CODE_ACTION',
            status: 'CORTEX_STEP_STATUS_DONE'
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const resPaginatedRecover = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 55,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resPaginatedRecover.resumed,
            1,
            '>50-step unflushed RPC trajectory ending in live stream error must paginate to tail and recover'
          );
          const savedMapPaginated = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(savedMapPaginated['cid-stream-err-172']?.stepIndex, 233);

          // Pre-check.stepIndex CODE_ACTION DONE at step 168 before disk /compact (170) + ERROR_MESSAGE (171) with empty live userInput must NOT wipe liveSawCompactSinceCheckpoint
          fs.unlinkSync(tmpResumedPath);
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 168,
                type: 'GENERIC',
                status: 'DONE',
                created_at: isoAt(baseNow - 120),
                content: 'Edited file'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 100),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              },
              {
                step_index: 170,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 80),
                content: '<USER_REQUEST>[/compact](slashCommand;compact)</USER_REQUEST>'
              },
              {
                step_index: 171,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 60),
                error: 'net/http: TLS handshake timeout'
              }
            ],
            baseNow - 60
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            168: {
              metadata: { stepIndex: 168 },
              type: 'CORTEX_STEP_TYPE_CODE_ACTION',
              status: 'CORTEX_STEP_STATUS_DONE'
            },
            169: {
              metadata: { stepIndex: 169, modelUsage: { inputTokens: 226190 } },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: { stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR', toolCalls: [{ id: 'tc1' }] }
            },
            170: {
              metadata: { stepIndex: 170 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { items: [] }
            },
            171: {
              metadata: { stepIndex: 171 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: { error: { shortError: 'net/http: TLS handshake timeout' } }
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const sentBeforePreStepCheck = sentMessages.length;
          const resPreStepCheck = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 60,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resPreStepCheck.resumed, 1);
          assert.strictEqual(sentMessages.length, sentBeforePreStepCheck + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT,
            'Pre-check.stepIndex CODE_ACTION DONE must NOT re-trigger /compact after disk /compact failed'
          );

          // Stale compactFailed=true latched at stepIndex=172 must clear when a subsequent human turn + DONE tool step runs, restoring ageSec<45 guard and re-arming /compact
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow - 200,
                compactFailed: true
              }
            }),
            'utf8'
          );
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 175,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 60),
                content: '<USER_REQUEST>Run next build step</USER_REQUEST>'
              },
              {
                step_index: 176,
                type: 'GENERIC',
                status: 'DONE',
                created_at: isoAt(baseNow - 50),
                content: 'Command succeeded'
              },
              {
                step_index: 177,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 30),
                input_tokens: 230000,
                content: '',
                tool_calls: [{ id: 'tc3', name: 'run_command', arguments: '{}' }]
              }
            ],
            baseNow - 30
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            177: {
              metadata: { stepIndex: 177, modelUsage: { inputTokens: 230000 } },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: { stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR', toolCalls: [{ id: 'tc3' }] }
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          // Young step (ageSec = 30 < 45): compactFailed is cleared, so steady-state <45s guard holds off!
          const resClearedCompactYoung = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resClearedCompactYoung.resumed,
            0,
            'Once compactFailed is cleared by subsequent human/tool progress, steady-state <45s guard must be restored'
          );
          const mapClearedYoung = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(Boolean(mapClearedYoung['cid-stream-err-172']?.compactFailed), false);
          // Once ageSec >= 45 (nowSec = baseNow + 20 -> ageSec = 50), /compact re-arms!
          const sentBeforeRearmLive = sentMessages.length;
          const resClearedCompactMature = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 20,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resClearedCompactMature.resumed, 1);
          assert.strictEqual(sentMessages.length, sentBeforeRearmLive + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.item?.slashCommand?.info?.name,
            'compact',
            'Cleared compactFailed after human/tool progress must re-arm /compact on >=215k stream drop'
          );

          // Pre-compact live CODE_ACTION DONE between disk check.stepIndex (169, ageSec=10) and prevEntry.stepIndex (172) + empty userInput items:[] on /compact (173) + TLS handshake timeout (174):
          // offline polls must keep compactFailed=true (and require network check), and online poll at ageSec<45 must send CHUNKED_STREAM_RESUME_PROMPT once (never /compact twice)
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow + 10),
                input_tokens: 120000,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow + 10
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow + 12,
                pendingPostCompactResume: true
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            169: {
              metadata: { stepIndex: 169 },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: { toolCalls: [{ id: 'tc1', name: 'edit_file' }] }
            },
            170: {
              metadata: { stepIndex: 170 },
              type: 'CORTEX_STEP_TYPE_CODE_ACTION',
              status: 'CORTEX_STEP_STATUS_DONE'
            },
            171: {
              metadata: { stepIndex: 171, modelUsage: { inputTokens: 226190 } },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: { stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR', toolCalls: [{ id: 'tc2' }] }
            },
            172: {
              metadata: { stepIndex: 172 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: { error: { shortError: 'net/http: cannot rewind body after connection loss' } }
            },
            173: {
              metadata: { stepIndex: 173 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { items: [] }
            },
            174: {
              metadata: { stepIndex: 174 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: { error: { shortError: 'net/http: TLS handshake timeout' } }
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const chkDiskCompactReqNet = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow + 20,
            { compactFailed: true, pendingCompactStepIndex: 172, pendingCompactAt: baseNow + 12 }
          );
          assert.strictEqual(
            chkDiskCompactReqNet.requiresNetworkCheck,
            true,
            'unfinished_planner_tool_call with compactFailed=true must set requiresNetworkCheck=true'
          );
          const resPreCompactOffline1 = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 20,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => false
          });
          assert.strictEqual(resPreCompactOffline1.resumed, 0);
          const mapPreCompactOffline1 = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(
            mapPreCompactOffline1['cid-stream-err-172']?.compactFailed,
            true,
            'Pre-compact CODE_ACTION DONE at 170 (<172) must NOT wipe compactFailed on offline poll 1'
          );
          const resPreCompactOffline2 = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 25,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => false
          });
          assert.strictEqual(resPreCompactOffline2.resumed, 0);
          const mapPreCompactOffline2 = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(
            mapPreCompactOffline2['cid-stream-err-172']?.compactFailed,
            true,
            'compactFailed must remain latched across subsequent offline polls'
          );
          const sentBeforePreCompactOnline = sentMessages.length;
          // Online poll at nowSec = baseNow + 30 -> disk ageSec = 20 (< 45s steady-state threshold)
          const resPreCompactOnline = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 30,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(
            resPreCompactOnline.resumed,
            1,
            'Online poll after pre-compact CODE_ACTION DONE + failed /compact must recover without <45s stall'
          );
          assert.strictEqual(sentMessages.length, sentBeforePreCompactOnline + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT,
            'Failed /compact with empty live userInput items:[] must fall back to CHUNKED_STREAM_RESUME_PROMPT (never resend /compact)'
          );

          // Summarization-failure + ClientConn.Close stream hint at 226190 tokens with empty /compact USER_INPUT (disk + live without prevEntry.compactFailed) must select CHUNKED_STREAM_RESUME_PROMPT (never /compact)
          fs.unlinkSync(tmpResumedPath);
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 148,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 120),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              },
              {
                step_index: 150,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 60),
                content: ''
              },
              {
                step_index: 151,
                type: 'ERROR_MESSAGE',
                status: 'DONE',
                created_at: isoAt(baseNow - 40),
                error:
                  'agent executor error: pre-invocation hook: context summarization: failed to generate summary: http2: client connection force closed via ClientConn.Close'
              }
            ],
            baseNow - 40
          );
          const chkDiskSummStreamClose = agyBridge.inspectCascadeInterruptedState(
            'cid-stream-err-172',
            baseNow
          );
          assert.strictEqual(chkDiskSummStreamClose.interrupted, true);
          assert.strictEqual(
            chkDiskSummStreamClose.needsCompactionFirst,
            false,
            'Disk context summarization + ClientConn.Close with empty USER_INPUT must NOT re-select /compact'
          );
          assert.strictEqual(
            chkDiskSummStreamClose.resumePrompt,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT,
            'Disk context summarization + ClientConn.Close with empty USER_INPUT must fall back to CHUNKED_STREAM_RESUME_PROMPT'
          );
          // Live-only variant without prevEntry.compactFailed
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 1200),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 148,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 120),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 120
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            148: {
              metadata: { stepIndex: 148, modelUsage: { inputTokens: 226190 } },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: { stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR', toolCalls: [{ id: 'tc1' }] }
            },
            150: {
              metadata: { stepIndex: 150 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { items: [] }
            },
            151: {
              metadata: { stepIndex: 151 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: {
                error: {
                  shortError:
                    'agent executor error: pre-invocation hook: context summarization: failed to generate summary: http2: client connection force closed via ClientConn.Close'
                }
              }
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const sentBeforeLiveSummClose = sentMessages.length;
          const resLiveSummClose = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 40,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resLiveSummClose.resumed, 1);
          assert.strictEqual(sentMessages.length, sentBeforeLiveSummClose + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT,
            'Live context summarization + ClientConn.Close with empty items:[] must fall back to CHUNKED_STREAM_RESUME_PROMPT'
          );

          // First wakeup poll arriving 1200s (>900s) after auto_compact_before_resume (pendingPostCompactResume=true) with live step 173 (items:[]) + 174 (TLS handshake timeout) must latch compactFailed offline and send CHUNKED_STREAM_RESUME_PROMPT once online
          writeTranscript(
            'cid-stream-err-172',
            [
              {
                step_index: 1,
                type: 'USER_INPUT',
                status: 'DONE',
                created_at: isoAt(baseNow - 2400),
                content: '<USER_REQUEST>work on recommendations</USER_REQUEST>'
              },
              {
                step_index: 169,
                type: 'PLANNER_RESPONSE',
                status: 'DONE',
                created_at: isoAt(baseNow - 1300),
                input_tokens: 226190,
                content: '',
                tool_calls: [{ id: 'tc1', name: 'edit_file', arguments: '{}' }]
              }
            ],
            baseNow - 1300
          );
          fs.writeFileSync(
            tmpResumedPath,
            JSON.stringify({
              'cid-stream-err-172': {
                stepIndex: 172,
                reason: 'auto_compact_before_resume',
                resumedAt: baseNow - 1200,
                pendingPostCompactResume: true
              }
            }),
            'utf8'
          );
          liveTrajectorySteps = {
            0: baseStepZero,
            169: {
              metadata: { stepIndex: 169, modelUsage: { inputTokens: 226190 } },
              type: 'CORTEX_STEP_TYPE_PLANNER_RESPONSE',
              status: 'CORTEX_STEP_STATUS_DONE',
              plannerResponse: { stopReason: 'STOP_REASON_CLIENT_STREAM_ERROR', toolCalls: [{ id: 'tc1' }] }
            },
            173: {
              metadata: { stepIndex: 173 },
              type: 'CORTEX_STEP_TYPE_USER_INPUT',
              status: 'CORTEX_STEP_STATUS_DONE',
              userInput: { items: [] }
            },
            174: {
              metadata: { stepIndex: 174 },
              type: 'CORTEX_STEP_TYPE_ERROR_MESSAGE',
              status: 'CORTEX_STEP_STATUS_DONE',
              errorMessage: { error: { shortError: 'net/http: TLS handshake timeout' } }
            }
          };
          bState.__bhfVerifiedIdleProseCache.clear();
          const resFirstPollAfter20mSleepOffline = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => false
          });
          assert.strictEqual(resFirstPollAfter20mSleepOffline.resumed, 0);
          const mapFirstPollAfter20mSleep = JSON.parse(fs.readFileSync(tmpResumedPath, 'utf8'));
          assert.strictEqual(
            mapFirstPollAfter20mSleep['cid-stream-err-172']?.compactFailed,
            true,
            'First poll arriving 1200s (>900s) after auto_compact_before_resume must inspect liveStepsAfterCompact and latch compactFailed'
          );
          const sentBefore20mOnline = sentMessages.length;
          const resFirstPollAfter20mSleepOnline = await agyBridge.checkAndResumeInterruptedCascades(bState, {
            candidateIds: ['cid-stream-err-172'],
            nowSec: baseNow + 10,
            hubStartedAtSec: baseNow - 3600,
            networkOnlineCheck: () => true
          });
          assert.strictEqual(resFirstPollAfter20mSleepOnline.resumed, 1);
          assert.strictEqual(sentMessages.length, sentBefore20mOnline + 1);
          assert.strictEqual(
            sentMessages[sentMessages.length - 1]?.items?.[0]?.text,
            agyBridge.CHUNKED_STREAM_RESUME_PROMPT,
            'Online recovery after 1200s sleep + failed /compact must send CHUNKED_STREAM_RESUME_PROMPT (never duplicate /compact)'
          );

          // Step 8e: Direct socket tests of probeUpstreamNetworkOnline (real TLS secureConnect, untrusted MITM cert, TCP-only blackhole, and immediate TCP FIN close)
          const tlsMod = require('tls');
          const derLen = (len) =>
            len < 0x80
              ? Buffer.from([len])
              : len <= 0xff
                ? Buffer.from([0x81, len])
                : Buffer.from([0x82, (len >> 8) & 0xff, len & 0xff]);
          const derTlv = (tag, body) => Buffer.concat([Buffer.from([tag]), derLen(body.length), body]);
          const derSeq = (...items) => derTlv(0x30, Buffer.concat(items));
          const derSet = (...items) => derTlv(0x31, Buffer.concat(items));
          const derOid = (bytes) => derTlv(0x06, Buffer.from(bytes));
          const derUtf8 = (s) => derTlv(0x0c, Buffer.from(s, 'utf8'));
          const derUtc = (s) => derTlv(0x17, Buffer.from(s, 'ascii'));
          const { privateKey: ephKey, publicKey: ephPub } = nodeCrypto.generateKeyPairSync('ec', {
            namedCurve: 'prime256v1'
          });
          const ephAlgId = derSeq(derOid([0x2a, 0x86, 0x48, 0xce, 0x3d, 0x04, 0x03, 0x02]));
          const ephName = derSeq(derSet(derSeq(derOid([0x55, 0x04, 0x03]), derUtf8('localhost'))));
          const ephValidity = derSeq(derUtc('250101000000Z'), derUtc('350101000000Z'));
          const ephTbs = derSeq(
            derTlv(0xa0, derTlv(0x02, Buffer.from([0x02]))),
            derTlv(0x02, Buffer.from([0x01])),
            ephAlgId,
            ephName,
            ephValidity,
            ephName,
            ephPub.export({ type: 'spki', format: 'der' })
          );
          const ephSig = nodeCrypto.sign('sha256', ephTbs, ephKey);
          const ephCertDer = derSeq(ephTbs, ephAlgId, derTlv(0x03, Buffer.concat([Buffer.from([0x00]), ephSig])));
          const pemWord = 'CERTIFICATE';
          const ephCertPem = `-----BEGIN ${pemWord}-----\n${ephCertDer.toString('base64').match(/.{1,64}/g).join('\n')}\n-----END ${pemWord}-----\n`;
          const ephKeyPem = ephKey.export({ type: 'pkcs8', format: 'pem' });

          const mockTlsSrv = tlsMod.createServer({ key: ephKeyPem, cert: ephCertPem }, (s) => {
            s.on('error', () => {});
          });
          const mockBlackholeSrv = net.createServer((s) => {
            s.on('error', () => {});
          });
          const mockFinSrv = net.createServer((s) => {
            s.on('error', () => {});
            s.end();
          });
          await Promise.all([
            new Promise((r) => mockTlsSrv.listen(0, '127.0.0.1', r)),
            new Promise((r) => mockBlackholeSrv.listen(0, '127.0.0.1', r)),
            new Promise((r) => mockFinSrv.listen(0, '127.0.0.1', r))
          ]);
          try {
            const loopbackLookup = (_h, cb) => cb(null, '127.0.0.1');
            const tlsOk = await agyBridge.probeUpstreamNetworkOnline(1500, {
              host: 'localhost',
              port: mockTlsSrv.address().port,
              servername: 'localhost',
              ca: ephCertPem,
              lookupFn: loopbackLookup,
              allowInSmokeTest: true,
              bypassCache: true
            });
            assert.strictEqual(tlsOk, true, 'Trusted TLS secureConnect must resolve true');

            const untrustedTlsOk = await agyBridge.probeUpstreamNetworkOnline(1500, {
              host: 'localhost',
              port: mockTlsSrv.address().port,
              servername: 'localhost',
              lookupFn: loopbackLookup,
              allowInSmokeTest: true,
              bypassCache: true
            });
            assert.strictEqual(untrustedTlsOk, false, 'Untrusted captive-portal TLS cert must fail closed (false)');

            const blackholeOk = await agyBridge.probeUpstreamNetworkOnline(150, {
              host: 'localhost',
              port: mockBlackholeSrv.address().port,
              servername: 'localhost',
              lookupFn: loopbackLookup,
              allowInSmokeTest: true,
              bypassCache: true
            });
            assert.strictEqual(blackholeOk, false, 'TCP-open / TLS-silent blackhole must resolve false on timeout');

            const finT0 = Date.now();
            const finOk = await agyBridge.probeUpstreamNetworkOnline(2500, {
              host: 'localhost',
              port: mockFinSrv.address().port,
              servername: 'localhost',
              lookupFn: loopbackLookup,
              allowInSmokeTest: true,
              bypassCache: true
            });
            const finElapsed = Date.now() - finT0;
            assert.strictEqual(finOk, false, 'Premature TCP FIN before secureConnect must resolve false');
            assert.ok(finElapsed < 500, `Premature TCP FIN must resolve via close listener without waiting 2500ms (took ${finElapsed}ms)`);
          } finally {
            mockTlsSrv.close();
            mockBlackholeSrv.close();
            mockFinSrv.close();
          }

          // Step 9: notifyCascadeTerminatedError debounce & empty-ID negative guard + syncActiveTurnWakeLock & ensureWindowsStandbyNetworkGuard lifecycle
          assert.strictEqual(
            agyBridge.notifyCascadeTerminatedError(bState, ''),
            false,
            'Empty cascadeId in notifyCascadeTerminatedError must return false'
          );
          assert.strictEqual(
            agyBridge.notifyCascadeTerminatedError(bState, 'cid-term-banner-1'),
            true,
            'First notifyCascadeTerminatedError for cid must return true'
          );
          assert.strictEqual(
            agyBridge.notifyCascadeTerminatedError(bState, 'cid-term-banner-1'),
            false,
            'Duplicate notifyCascadeTerminatedError within 15s cooldown must return false'
          );

          let wakeSpawnCount = 0;
          let wakeEndedCount = 0;
          const mockWakeSpawner = () => {
            wakeSpawnCount += 1;
            const fakeChild = {
              exitCode: null,
              killed: false,
              stdin: {
                end() {
                  wakeEndedCount += 1;
                  fakeChild.exitCode = 0;
                }
              },
              kill() {
                fakeChild.killed = true;
                fakeChild.exitCode = 0;
              },
              on() {},
              unref() {}
            };
            return fakeChild;
          };
          const w1 = agyBridge.syncActiveTurnWakeLock(bState, true, {
            nowMs: 100000,
            spawnWakeLockProcess: mockWakeSpawner
          });
          assert.strictEqual(w1.active, true);
          assert.strictEqual(w1.spawned, true);
          assert.strictEqual(wakeSpawnCount, 1);

          const wGrace = agyBridge.syncActiveTurnWakeLock(bState, false, {
            nowMs: 105000,
            releaseGraceMs: 15000,
            spawnWakeLockProcess: mockWakeSpawner
          });
          assert.strictEqual(wGrace.active, true, 'Wake lock must hold during 15s grace window');
          assert.strictEqual(wGrace.graceHold, true);
          assert.strictEqual(wakeEndedCount, 0);

          const wRelease = agyBridge.syncActiveTurnWakeLock(bState, false, {
            nowMs: 120000,
            releaseGraceMs: 15000,
            spawnWakeLockProcess: mockWakeSpawner
          });
          assert.strictEqual(wRelease.active, false, 'Wake lock must release once grace window expires');
          assert.strictEqual(wRelease.released, true);
          assert.strictEqual(wakeEndedCount, 1);

          let capturedPowerScript = '';
          const pg1 = agyBridge.ensureWindowsStandbyNetworkGuard(bState, {
            nowMs: 200000,
            minIntervalMs: 600000,
            powerGuardRunner: (script) => {
              capturedPowerScript = script;
            }
          });
          assert.strictEqual(pg1, true);
          assert.ok(capturedPowerScript.includes('9d7815a6-7ee4-497e-8888-515a05f02364'), 'Power guard must disable HIBERNATEIDLE');
          assert.ok(capturedPowerScript.includes('f15576e8-98b7-4186-b944-eafa664402d9'), 'Power guard must enable CONNECTIVITYINSTANDBY');
          const pgRateLimited = agyBridge.ensureWindowsStandbyNetworkGuard(bState, {
            nowMs: 250000,
            minIntervalMs: 600000,
            powerGuardRunner: () => {}
          });
          assert.strictEqual(pgRateLimited, false, 'Negative: ensureWindowsStandbyNetworkGuard must rate-limit within minIntervalMs');
        } finally {
          await new Promise((resolve) => cascadeSrv.close(resolve));
        }
      } finally {
        if (prevResumedPath === undefined) {
          delete process.env.THEO_RESUMED_CASCADES_PATH;
        } else {
          process.env.THEO_RESUMED_CASCADES_PATH = prevResumedPath;
        }
      }
    } finally {
      await new Promise((resolve) => mockHubSrv.close(resolve));
    }
  } finally {
    if (prevBrainRoot === undefined) {
      delete process.env.THEO_BRAIN_ROOT_DIR;
    } else {
      process.env.THEO_BRAIN_ROOT_DIR = prevBrainRoot;
    }
    fs.rmSync(tmpBrainDir, { recursive: true, force: true });
  }
  console.log('[PASS] Adversarial #5: Stream-interruption auto-compact (/compact -> CHECKPOINT -> chunked resume) + loop guards');

  // ---------------------------------------------------------------------------
  // Adversarial Check #6: v62 Antigravity PlanModel Enum Resolution
  // (MODEL_PLACEHOLDER_M417..M419 / M318..M320 / M400..M405) & Cloudflare DO
  // SQLite thread_cache (<25ms Edge fallback when hosts are offline)
  // ---------------------------------------------------------------------------
  assert.strictEqual(
    remoteMod.formatModelDisplayName('MODEL_PLACEHOLDER_M417'),
    'Gemini 4 Argon (High)',
    'MODEL_PLACEHOLDER_M417 must format to Gemini 4 Argon (High)'
  );
  assert.strictEqual(
    remoteMod.formatModelDisplayName('MODEL_PLACEHOLDER_M319'),
    'Gemini 3.8 Flash (Medium)',
    'MODEL_PLACEHOLDER_M319 must format to Gemini 3.8 Flash (Medium)'
  );
  assert.strictEqual(
    remoteMod.formatModelDisplayName('MODEL_PLACEHOLDER_M400'),
    'Claude Opus 5.5 (Low)',
    'MODEL_PLACEHOLDER_M400 must format to Claude Opus 5.5 (Low)'
  );
  assert.strictEqual(
    remoteMod.resolveAntigravityPlanModelEnum('gemini-4-argon', 'low'),
    'MODEL_PLACEHOLDER_M419',
    'gemini-4-argon + low must resolve to MODEL_PLACEHOLDER_M419'
  );
  assert.strictEqual(
    remoteMod.resolveAntigravityPlanModelEnum('gemini-3.8-flash', 'medium'),
    'MODEL_PLACEHOLDER_M319',
    'gemini-3.8-flash + medium must resolve to MODEL_PLACEHOLDER_M319'
  );
  assert.strictEqual(
    remoteMod.resolveAntigravityPlanModelEnum('<img src=x onerror=alert(1)>', 'bogus'),
    '',
    'Negative: Hostile/unknown model string must return empty enum string'
  );

  // Test Cloudflare DO SQLite thread_cache (v2.2)
  const cacheDb = new DatabaseSync(':memory:');
  const cacheSql = {
    exec(query, ...params) {
      if (params.length === 0 && !/^\s*SELECT\b/i.test(query)) {
        cacheDb.exec(query);
        return [];
      }
      const stmt = cacheDb.prepare(query);
      if (/^\s*SELECT\b/i.test(query)) {
        return stmt.all(...params);
      }
      stmt.run(...params);
      return [];
    }
  };
  const cacheRoom = new TheoRelayRoom(
    {
      getWebSockets: () => [],
      storage: {
        sql: cacheSql,
        getAlarm: async () => null,
        setAlarm: async () => {}
      }
    },
    { AUTH_TOKEN: roomAuthToken }
  );
  cacheRoom._saveThreadDetail(
    'sess-edge-cached-1',
    'theo-laptop',
    {
      id: 'sess-edge-cached-1',
      provider: 'antigravity',
      title: 'Edge Cached Conversation',
      messages: [{ id: 'm1', role: 'assistant', text: 'Served from Cloudflare Edge SQLite' }]
    }
  );
  const cachedEntry = cacheRoom._getCachedThreadDetail('sess-edge-cached-1');
  assert.ok(cachedEntry && cachedEntry.detail, 'Edge DO SQLite thread_cache must store and retrieve thread payload');
  assert.strictEqual(cachedEntry.detail.title, 'Edge Cached Conversation');
  assert.strictEqual(
    cacheRoom._getCachedThreadDetail('non-existent-thread'),
    null,
    'Negative: Missing thread_cache entry must return null'
  );
  cacheDb.close();

  // Test findActiveCascadesFromDiskTranscripts with both (3600) and (Date.now(), { maxInterruptedAgeMs: 3600000 })
  const hubBridgeMod = require('../compat/antigravity-hub-bridge.cjs');
  const tmpContinuityBrainDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-brain-cont-'));
  const prevContinuityBrainRoot = process.env.THEO_BRAIN_ROOT_DIR;
  try {
    process.env.THEO_BRAIN_ROOT_DIR = tmpContinuityBrainDir;
    const mockCascadeId = '11111111-2222-3333-4444-555555555555';
    const mockLogsDir = path.join(tmpContinuityBrainDir, mockCascadeId, '.system_generated', 'logs');
    fs.mkdirSync(mockLogsDir, { recursive: true });
    const mockTranscriptPath = path.join(mockLogsDir, 'transcript.jsonl');
    const stepCreatedAt = new Date(Date.now() - 180 * 1000).toISOString();
    fs.writeFileSync(
      mockTranscriptPath,
      `${JSON.stringify({
        step_index: 1,
        source: 'USER_EXPLICIT',
        type: 'USER_INPUT',
        status: 'DONE',
        created_at: stepCreatedAt,
        content: 'Continue long task while VS Code is closed'
      })}\n`,
      'utf8'
    );
    const mtimeDate = new Date(Date.now() - 180 * 1000);
    fs.utimesSync(mockTranscriptPath, mtimeDate, mtimeDate);
    const bySecArg = hubBridgeMod.findActiveCascadesFromDiskTranscripts(3600);
    const byOptions = hubBridgeMod.findActiveCascadesFromDiskTranscripts(Date.now(), {
      maxInterruptedAgeMs: 3600 * 1000
    });
    assert.ok(
      bySecArg.includes(mockCascadeId),
      'findActiveCascadesFromDiskTranscripts(3600) must treat <1e11 first arg as maxAgeSec and find 180s-old interrupted cascade'
    );
    assert.ok(
      byOptions.includes(mockCascadeId),
      'findActiveCascadesFromDiskTranscripts(Date.now(), { maxInterruptedAgeMs: 3600000 }) must find 180s-old interrupted cascade'
    );
  } finally {
    if (prevContinuityBrainRoot === undefined) delete process.env.THEO_BRAIN_ROOT_DIR;
    else process.env.THEO_BRAIN_ROOT_DIR = prevContinuityBrainRoot;
    try {
      fs.rmSync(tmpContinuityBrainDir, { recursive: true, force: true });
    } catch {}
  }

  console.log('[PASS] Adversarial #6: v62 Antigravity PlanModel Enum Resolution, Headless Cascade Continuity & Cloudflare DO SQLite thread_cache verified');

  // 14. Adversarial #7: Desktop App Launcher, Multi-Frame ICO, Hostile Input Rejection, Quarantine & v(N-1)->v(N) Lifecycle
  const desktopLauncher = require('../desktop-launcher');
  const icoPath = path.join(ROOT, 'resources', 'theo.ico');
  assert.ok(fs.existsSync(icoPath), 'resources/theo.ico must exist');
  const icoCheck = desktopLauncher.validateIcoBuffer(fs.readFileSync(icoPath));
  assert.strictEqual(icoCheck.valid, true, 'resources/theo.ico must be a valid ICO container');
  assert.strictEqual(icoCheck.frameCount, 6, 'resources/theo.ico must pack all 6 resolution frames (16..256)');

  // Negative ICO bounds
  assert.strictEqual(desktopLauncher.validateIcoBuffer(Buffer.from('not-an-ico')).valid, false);
  assert.strictEqual(desktopLauncher.validateIcoBuffer(Buffer.alloc(22, 0)).valid, false);

  // Negative URL & CLI argument injection checks
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('http://127.0.0.1:4318/'), 'http://127.0.0.1:4318/');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('https://husseinbdeir.github.io/theo/'), 'https://husseinbdeir.github.io/theo/');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('javascript:alert(1)'), null, 'Must reject javascript: URL');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('file:///C:/Windows/System32/calc.exe'), null, 'Must reject file: URL');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('http://evil.example.com/theo'), null, 'Must reject non-loopback http: URL');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('https://husseinbdeir.github.io/theo/" --gpu-launcher="calc.exe'), null, 'Must reject embedded quotes');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('https://user:pass@husseinbdeir.github.io/theo/'), null, 'Must reject URL credentials');
  assert.strictEqual(desktopLauncher.validateDesktopAppUrl('https://husseinbdeir.github.io/theo/#pair=secret123'), null, 'Must reject #pair= secret in shortcut args');
  assert.throws(
    () => desktopLauncher.buildBrowserAppArguments('javascript:alert(1)'),
    /invalid URL/i,
    'buildBrowserAppArguments must throw on hostile URL'
  );

  // Negative Hotkey validation checks
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Ctrl+Alt+t'), 'Ctrl+Alt+T');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Alt+Ctrl+Shift+t'), 'Ctrl+Alt+Shift+T');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('none'), '');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey(''), '');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('T'), null, 'Must reject bare single-letter hotkey');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Ctrl+T'), null, 'Must reject single-modifier letter hotkey that hijacks normal Ctrl+T');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Ctrl+Alt+T; calc.exe'), null, 'Must reject hotkey with command injection');
  assert.strictEqual(desktopLauncher.normalizeShortcutHotkey('Ctrl+Ctrl+T'), null, 'Must reject duplicate modifier');

  // Negative Quarantine check: THEO_SMOKE_TEST=1 must refuse touching real Desktop/Start Menu
  assert.throws(
    () => desktopLauncher.installDesktopShortcuts({}),
    /Quarantine violation/i,
    'installDesktopShortcuts must fail closed in THEO_SMOKE_TEST=1 when sandbox dirs are omitted'
  );
  assert.throws(
    () => desktopLauncher.uninstallDesktopShortcuts({}),
    /Quarantine violation/i,
    'uninstallDesktopShortcuts must fail closed in THEO_SMOKE_TEST=1 when sandbox dirs are omitted'
  );

  // Full sandbox lifecycle: Create -> Idempotent Skip -> v(N-1)->v(N) legacy shortcut cleanup -> Uninstall
  const tmpShortcutRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-desktop-lnk-'));
  try {
    const sbHome = path.join(tmpShortcutRoot, 'home');
    const sbDesktop = path.join(tmpShortcutRoot, 'Desktop');
    const sbPrograms = path.join(tmpShortcutRoot, 'Programs');
    const sbTaskbar = path.join(tmpShortcutRoot, 'TaskBar');
    const sbPwa = path.join(tmpShortcutRoot, 'theo-pwa');
    fs.mkdirSync(sbDesktop, { recursive: true });
    fs.mkdirSync(sbPrograms, { recursive: true });
    fs.mkdirSync(sbTaskbar, { recursive: true });
    fs.mkdirSync(sbPwa, { recursive: true });
    fs.writeFileSync(path.join(sbPwa, 'index.html'), '<!doctype html><title>THEO</title>', 'utf8');

    // Seed pre-upgrade legacy shortcuts + pre-pinned v1 TaskBar THEO.lnk to verify v(N-1)->v(N) upgrade continuity
    fs.writeFileSync(path.join(sbDesktop, 'THEO Remote.lnk'), 'legacy', 'utf8');
    fs.writeFileSync(path.join(sbPrograms, 'THEO Studio.lnk'), 'legacy', 'utf8');
    fs.writeFileSync(path.join(sbTaskbar, 'THEO.lnk'), 'v1-pinned-msedge-lnk', 'utf8');
    fs.mkdirSync(path.join(sbHome, '.theo'), { recursive: true });
    fs.writeFileSync(
      path.join(sbHome, '.theo', 'desktop-shortcut.json'),
      JSON.stringify({
        version: 1,
        shortcutName: 'THEO.lnk',
        targetPath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        arguments: '--app="http://127.0.0.1:4318/"',
        url: 'http://127.0.0.1:4318/',
        hotkey: 'Ctrl+Alt+T',
        desktopShortcutPath: path.join(sbDesktop, 'THEO.lnk'),
        startMenuShortcutPath: path.join(sbPrograms, 'THEO.lnk')
      }),
      'utf8'
    );

    const firstInstall = desktopLauncher.installDesktopShortcuts({
      hubRoot: ROOT,
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar,
      pwaRoot: sbPwa,
      port: 4318,
      hotkey: 'Ctrl+Alt+T'
    });
    assert.strictEqual(firstInstall.ok, true);
    assert.strictEqual(firstInstall.skipped, false, 'v1 msedge.exe state must upgrade to v2 THEO.exe without skipping');
    assert.strictEqual(firstInstall.version, 2);
    assert.strictEqual(firstInstall.appUserModelId, 'BHFIRMS.THEO.Desktop');
    assert.strictEqual(firstInstall.url, 'http://127.0.0.1:4318/');
    assert.strictEqual(firstInstall.targetPath, firstInstall.launcherExePath, 'Shortcut TargetPath must be native THEO.exe, never msedge.exe');
    assert.strictEqual(firstInstall.arguments, '', 'Shortcut Arguments must be empty so Windows Taskbar never strips --app');
    assert.ok(fs.existsSync(firstInstall.launcherExePath), 'Compiled ~/.theo/THEO.exe must exist');
    assert.ok(fs.existsSync(firstInstall.desktopShortcutPath), 'Desktop THEO.lnk must be created');
    assert.ok(fs.existsSync(firstInstall.startMenuShortcutPath), 'Start Menu THEO.lnk must be created');
    assert.ok(fs.existsSync(firstInstall.taskbarShortcutPath), 'Pinned TaskBar THEO.lnk must be upgraded in-place');
    assert.ok(fs.existsSync(firstInstall.iconPath), 'Stable ~/.theo/theo.ico must be created');
    assert.ok(fs.existsSync(path.join(firstInstall.profileDir, 'First Run')), 'Isolated app-profile First Run sentinel must be pre-seeded');
    assert.strictEqual(fs.existsSync(path.join(sbDesktop, 'THEO Remote.lnk')), false, 'Legacy THEO Remote.lnk must be cleaned up');
    assert.strictEqual(fs.existsSync(path.join(sbPrograms, 'THEO Studio.lnk')), false, 'Legacy THEO Studio.lnk must be cleaned up');

    // Verify .lnk PropertyStore (1SPS) contains BHFIRMS.THEO.Desktop AUMID in UTF-16LE
    const aumidUtf16 = Buffer.from('BHFIRMS.THEO.Desktop', 'utf16le');
    for (const lnkFile of [
      firstInstall.desktopShortcutPath,
      firstInstall.startMenuShortcutPath,
      firstInstall.taskbarShortcutPath
    ]) {
      const lnkBytes = fs.readFileSync(lnkFile);
      assert.ok(
        lnkBytes.includes(aumidUtf16),
        `${path.basename(lnkFile)} in ${path.basename(path.dirname(lnkFile))} must embed BHFIRMS.THEO.Desktop AUMID in PropertyStore`
      );
    }

    // Verify compiled THEO.exe --verify-config and quarantine enforcement
    const quarantineRun = spawnSync(firstInstall.launcherExePath, [], {
      env: { ...process.env, THEO_SMOKE_TEST: '1' },
      encoding: 'utf8',
      timeout: 20000,
      windowsHide: true
    });
    assert.strictEqual(
      quarantineRun.status,
      2,
      'Negative: THEO.exe without --verify-config must fail closed (exit 2) under THEO_SMOKE_TEST=1'
    );

    const verifyRun = spawnSync(
      firstInstall.launcherExePath,
      ['--verify-config', '--state-file', firstInstall.stateFilePath],
      {
        env: { ...process.env, THEO_SMOKE_TEST: '1' },
        encoding: 'utf8',
        timeout: 20000,
        windowsHide: true
      }
    );
    assert.strictEqual(verifyRun.status, 0, 'THEO.exe --verify-config must succeed');
    const verifyJson = JSON.parse(verifyRun.stdout.trim());
    assert.strictEqual(verifyJson.ok, true);
    assert.strictEqual(verifyJson.url, 'http://127.0.0.1:4318/');
    assert.strictEqual(verifyJson.profileDir, firstInstall.profileDir);
    assert.strictEqual(
      verifyJson.appUserModelId,
      'BHFIRMS.THEO.Desktop',
      'THEO.exe --verify-config must report canonical BHFIRMS.THEO.Desktop AUMID without host registry pollution'
    );

    const secondInstall = desktopLauncher.installDesktopShortcuts({
      hubRoot: ROOT,
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar,
      pwaRoot: sbPwa,
      port: 4318,
      hotkey: 'Ctrl+Alt+T'
    });
    assert.strictEqual(secondInstall.skipped, true, 'Repeat install with identical spec must fast-skip');

    // Reversibility check: updating existing shortcut with hotkey: '' (-NoHotkey) must clear Hotkey in the .lnk binary on disk
    const clearedHotkeyInstall = desktopLauncher.installDesktopShortcuts({
      hubRoot: ROOT,
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar,
      pwaRoot: sbPwa,
      port: 4318,
      hotkey: ''
    });
    assert.strictEqual(clearedHotkeyInstall.skipped, false, 'Changing hotkey to empty must re-save shortcut');
    assert.strictEqual(clearedHotkeyInstall.hotkey, '');

    // M-1 check: subsequent background run with hotkey: undefined (simulating relay_keepalive_start.ps1 -Quiet)
    // MUST preserve the user's saved hotkey: '' preference rather than resetting to 'Ctrl+Alt+T'
    const backgroundKeepaliveInstall = desktopLauncher.installDesktopShortcuts({
      hubRoot: ROOT,
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar,
      pwaRoot: sbPwa,
      port: 4318
    });
    assert.strictEqual(backgroundKeepaliveInstall.hotkey, '', 'Background install must preserve saved -NoHotkey preference');
    assert.strictEqual(backgroundKeepaliveInstall.skipped, true, 'Background install with unchanged saved preference must fast-skip');

    // Missing local PWA directory must fall back cleanly to HTTPS PWA URL
    const fallbackUrl = desktopLauncher.resolveDesktopLaunchUrl({
      pwaRoot: path.join(tmpShortcutRoot, 'missing-pwa'),
      port: 4318
    });
    assert.strictEqual(fallbackUrl, 'https://husseinbdeir.github.io/theo/');

    const uninstallRes = desktopLauncher.uninstallDesktopShortcuts({
      homeDir: sbHome,
      desktopDir: sbDesktop,
      programsDir: sbPrograms,
      taskbarDir: sbTaskbar
    });
    assert.strictEqual(uninstallRes.ok, true);
    assert.strictEqual(uninstallRes.removedShortcuts.length, 3);
    assert.strictEqual(uninstallRes.removedStateFile, true);
    assert.strictEqual(uninstallRes.removedIconFile, true);
    assert.strictEqual(uninstallRes.removedLauncherExe, true);
    assert.strictEqual(fs.existsSync(firstInstall.desktopShortcutPath), false);
    assert.strictEqual(fs.existsSync(firstInstall.startMenuShortcutPath), false);
    assert.strictEqual(fs.existsSync(firstInstall.taskbarShortcutPath), false);
    assert.strictEqual(fs.existsSync(firstInstall.iconPath), false);
    assert.strictEqual(fs.existsSync(firstInstall.launcherExePath), false);
  } finally {
    try {
      fs.rmSync(tmpShortcutRoot, { recursive: true, force: true });
    } catch {}
  }

  console.log('[PASS] Adversarial #7: Desktop App Launcher, Multi-Frame ICO, Hostile Input Rejection, Quarantine & v(N-1)->v(N) Lifecycle verified');

  // 15. Adversarial #8: v63 Live Activity Descriptor & Dual wsHub/edgeClient thread_detail Streaming
  const liveBridge = new remoteMod.TheoRemoteBridge({});
  const idleAct = liveBridge.deriveLiveActivityDescriptor([], false, null);
  assert.strictEqual(idleAct.active, false, 'Negative: Idle session must return { active: false }');

  const readingAct = liveBridge.deriveLiveActivityDescriptor(
    [
      {
        role: 'assistant',
        thinking: 'Checking core3d.js',
        totalTurnTools: 4,
        toolCalls: [
          { kind: 'read', file: 'core3d.js', relPath: 'js/core3d.js', lineRange: 'L1-L80', summary: 'Read core3d.js' }
        ]
      }
    ],
    true,
    null
  );
  assert.strictEqual(readingAct.active, true);
  assert.strictEqual(readingAct.verb, 'Reading');
  assert.strictEqual(readingAct.file, 'core3d.js');
  assert.strictEqual(readingAct.label, 'Reading core3d.js');
  assert.strictEqual(readingAct.stepCount, 4);

  const thinkingOnlyAct = liveBridge.deriveLiveActivityDescriptor(
    [{ role: 'assistant', thinking: 'Synthesizing architecture...', toolCalls: [] }],
    true,
    { stepStatus: 'CORTEX_STEP_STATUS_GENERATING', thinking: 'Synthesizing architecture...', toolCalls: [] }
  );
  assert.strictEqual(thinkingOnlyAct.verb, 'Thinking…');
  assert.strictEqual(thinkingOnlyAct.target, '');

  // Negative #2: Malformed / non-assistant messages array must not throw and must fall back cleanly
  const malformedAct = liveBridge.deriveLiveActivityDescriptor(
    [null, undefined, { role: 'user', text: 'test prompt' }],
    true,
    null
  );
  assert.strictEqual(malformedAct.active, true);
  assert.strictEqual(malformedAct.verb, 'Thinking…');
  assert.strictEqual(malformedAct.stepCount, 0);

  // Negative #3: Path-traversal / non-UUID cascadeId on fetchLiveCascadeTailOverlay must return null immediately
  const traversalTail = await liveBridge.fetchLiveCascadeTailOverlay('../../../etc/passwd', 5);
  assert.strictEqual(traversalTail, null, 'Negative: Non-UUID cascadeId must be rejected by fetchLiveCascadeTailOverlay');
  console.log('[PASS] Adversarial #8: v63 Live Activity Descriptor (Reading / Editing / Thinking…) & 3 Negative Guards verified');

  // 16. Adversarial #9: Subagent Background-Task Settlement (subagentSummariesById + Disk ERROR_MESSAGE vs Active Running Subagent)
  const tmpSubHomeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-subagent-settle-'));
  try {
    const subBrainDir = path.join(tmpSubHomeDir, 'brain');
    const subBaseNow = Math.floor(Date.now() / 1000);
    const isoSub = (sec) => new Date(sec * 1000).toISOString();
    const writeSubBrainTranscript = (cid, lines, mtimeSec) => {
      const logDir = path.join(subBrainDir, cid, '.system_generated', 'logs');
      fs.mkdirSync(logDir, { recursive: true });
      const p = path.join(logDir, 'transcript.jsonl');
      fs.writeFileSync(p, lines.map((l) => JSON.stringify(l)).join('\n') + '\n', 'utf8');
      const d = new Date(mtimeSec * 1000);
      fs.utimesSync(p, d, d);
    };

    const subStore = new AntigravityDataStore();
    subStore.readUserCancelledCascades = () => ({});

    // Positive #1: Fast (<15s) parent yield after invoke_subagent settles when subagentSummariesById reports IDLE
    const fastParentCid = 'aaaa1111-2222-3333-4444-555555555551';
    const fastSubCid = '2f49c9aa-5d75-4b9e-a18d-29cb75182652';
    writeSubBrainTranscript(
      fastParentCid,
      [
        { step_index: 1, type: 'USER_INPUT', status: 'DONE', created_at: isoSub(subBaseNow - 12), content: 'Audit codebase' },
        {
          step_index: 2,
          type: 'PLANNER_RESPONSE',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 10),
          content: '',
          tool_calls: [{ id: 'tc1', name: 'default_api:invoke_subagent', arguments: '{"TypeName":"research","Role":"Auditor","Prompt":"Check files"}' }]
        },
        {
          step_index: 3,
          type: 'GENERIC',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 10),
          content: `{"conversationId":"${fastSubCid}"}`
        },
        {
          step_index: 4,
          type: 'PLANNER_RESPONSE',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 7),
          content: 'Waiting for subagent response.'
        }
      ],
      subBaseNow - 7
    );
    const agyMapFast = new Map([
      [
        fastParentCid,
        {
          id: fastParentCid,
          status: 'CASCADE_RUN_STATUS_IDLE',
          notFullyIdle: false,
          stepCount: 5,
          bgTask: null
        }
      ]
    ]);
    const subMapFast = new Map([
      [fastSubCid, { id: fastSubCid, rootId: fastParentCid, status: 'CASCADE_RUN_STATUS_IDLE', stepCount: 2, updatedAt: subBaseNow - 5 }]
    ]);
    const ctxFast = subStore._createTokenAnalyticsContext(
      tmpSubHomeDir,
      agyMapFast,
      new Map(),
      new Map(),
      subBaseNow * 1000,
      subMapFast
    );
    subStore._ingestSingleBrainEntry({ name: fastParentCid, isDirectory: () => true }, ctxFast);
    const settledFastThread = agyMapFast.get(fastParentCid);
    assert.strictEqual(
      settledFastThread.backgroundTasks?.[0]?.state,
      'completed',
      'Subagent with IDLE live RPC summary must settle to completed even when parent yielded within 3s'
    );
    assert.strictEqual(settledFastThread.bgTask, null, 'Settled subagent must clear parent bgTask');
    assert.strictEqual(settledFastThread.status, 'CASCADE_RUN_STATUS_IDLE');

    // Positive #2: Subagent whose own disk transcript ends on ERROR_MESSAGE settles even without RPC summary
    writeSubBrainTranscript(
      fastSubCid,
      [
        { step_index: 1, type: 'USER_INPUT', status: 'DONE', created_at: isoSub(subBaseNow - 10), content: 'Check files' },
        { step_index: 2, type: 'ERROR_MESSAGE', status: 'DONE', created_at: isoSub(subBaseNow - 6), content: 'Error Unknown: Agent execution terminated due to error.' }
      ],
      subBaseNow - 6
    );
    const agyMapDiskErr = new Map([
      [
        fastParentCid,
        {
          id: fastParentCid,
          status: 'CASCADE_RUN_STATUS_IDLE',
          notFullyIdle: false,
          stepCount: 5,
          bgTask: null
        }
      ]
    ]);
    const ctxDiskErr = subStore._createTokenAnalyticsContext(
      tmpSubHomeDir,
      agyMapDiskErr,
      new Map(),
      new Map(),
      subBaseNow * 1000,
      new Map()
    );
    subStore._ingestSingleBrainEntry({ name: fastParentCid, isDirectory: () => true }, ctxDiskErr);
    assert.strictEqual(
      agyMapDiskErr.get(fastParentCid).backgroundTasks?.[0]?.state,
      'completed',
      'Subagent whose disk transcript ends on ERROR_MESSAGE must settle to completed'
    );
    assert.strictEqual(agyMapDiskErr.get(fastParentCid).bgTask, null);

    // Negative #1: Active RUNNING subagent after slow (>15s) parent yielding response must remain running
    const slowParentCid = 'bbbb1111-2222-3333-4444-555555555552';
    const activeSubCid = '4f49c9aa-5d75-4b9e-a18d-29cb75182654';
    writeSubBrainTranscript(
      slowParentCid,
      [
        { step_index: 1, type: 'USER_INPUT', status: 'DONE', created_at: isoSub(subBaseNow - 45), content: 'Deep audit' },
        {
          step_index: 2,
          type: 'PLANNER_RESPONSE',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 40),
          content: '',
          tool_calls: [{ id: 'tc2', name: 'default_api:invoke_subagent', arguments: '{"TypeName":"research","Role":"Deep Researcher","Prompt":"Inspect all modules"}' }]
        },
        {
          step_index: 3,
          type: 'GENERIC',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 40),
          content: `{"conversationId":"${activeSubCid}"}`
        },
        {
          step_index: 4,
          type: 'PLANNER_RESPONSE',
          status: 'DONE',
          created_at: isoSub(subBaseNow - 15),
          content: 'Subagent launched; waiting for its completion.'
        }
      ],
      subBaseNow - 15
    );
    const agyMapSlowRunning = new Map([
      [
        slowParentCid,
        {
          id: slowParentCid,
          status: 'CASCADE_RUN_STATUS_IDLE',
          notFullyIdle: false,
          stepCount: 5,
          bgTask: null
        }
      ]
    ]);
    const subMapSlowRunning = new Map([
      [activeSubCid, { id: activeSubCid, rootId: slowParentCid, status: 'CASCADE_RUN_STATUS_RUNNING', stepCount: 6, updatedAt: subBaseNow - 2 }]
    ]);
    const ctxSlowRunning = subStore._createTokenAnalyticsContext(
      tmpSubHomeDir,
      agyMapSlowRunning,
      new Map(),
      new Map(),
      subBaseNow * 1000,
      subMapSlowRunning
    );
    subStore._ingestSingleBrainEntry({ name: slowParentCid, isDirectory: () => true }, ctxSlowRunning);
    const activeParentThread = agyMapSlowRunning.get(slowParentCid);
    assert.strictEqual(
      activeParentThread.backgroundTasks?.[0]?.state,
      'running',
      'Negative: Subagent with RUNNING live RPC summary must NOT be prematurely settled after >15s parent yield'
    );
    assert.strictEqual(activeParentThread.bgTask?.state, 'running');
    assert.strictEqual(activeParentThread.status, 'CASCADE_RUN_STATUS_RUNNING');

    // Negative #2: Without RPC summary or subagent transcript, parent still waiting at yielding step (maxStepIndex <= subStepIndex + 2) must keep subagent running
    const agyMapNoRpcYet = new Map([
      [
        slowParentCid,
        {
          id: slowParentCid,
          status: 'CASCADE_RUN_STATUS_IDLE',
          notFullyIdle: false,
          stepCount: 5,
          bgTask: null
        }
      ]
    ]);
    const ctxNoRpcYet = subStore._createTokenAnalyticsContext(
      tmpSubHomeDir,
      agyMapNoRpcYet,
      new Map(),
      new Map(),
      subBaseNow * 1000,
      new Map()
    );
    subStore._ingestSingleBrainEntry({ name: slowParentCid, isDirectory: () => true }, ctxNoRpcYet);
    assert.strictEqual(
      agyMapNoRpcYet.get(slowParentCid).backgroundTasks?.[0]?.state,
      'running',
      'Negative: Parent waiting at yielding step (maxStepIndex <= subStepIndex + 2) without RPC summary must keep subagent running'
    );
    assert.strictEqual(agyMapNoRpcYet.get(slowParentCid).bgTask?.state, 'running');
  } finally {
    try {
      fs.rmSync(tmpSubHomeDir, { recursive: true, force: true });
    } catch {}
  }
  console.log('[PASS] Adversarial #9: Subagent background-task settlement (live RPC + disk ERROR_MESSAGE vs active RUNNING subagent) verified');

  // Plan rename 2026-10-30: credential ids still say max/max_20x, label must read Ultra / Max
  {
    const { formatClaudePlanName } = require(path.join(ROOT, 'data.js'));
    assert.strictEqual(formatClaudePlanName('max', 'default_claude_max_20x'), 'Claude Ultra (10x)');
    assert.strictEqual(formatClaudePlanName('max', 'default_claude_max_5x'), 'Claude Max (5x)');
    assert.strictEqual(formatClaudePlanName('ultra', ''), 'Claude Ultra (10x)');
    assert.strictEqual(formatClaudePlanName('pro', 'default_claude_pro'), 'Claude Pro');
  }

  // Claude plans without a session limit (verified Ultra): `five_hour: null` + weekly window
  {
    const { parseClaudeQuotaSummary } = require(path.join(ROOT, 'data.js'));
    const qNow = Date.UTC(2026, 10, 10, 12, 0, 0);
    const futureIso = new Date(qNow + 3 * 86400 * 1000).toISOString();
    const futureSec = Math.floor(qNow / 1000) + 3600;
    const pastSec = Math.floor(qNow / 1000) - 3600;
    const fableLimit = {
      kind: 'weekly_scoped',
      percent: 4,
      resets_at: futureIso,
      scope: { model: { id: null, display_name: 'Fable' } }
    };
    const labelsOf = (summary) => summary.primaryBars.map((b) => b.label);

    const ultra = parseClaudeQuotaSummary(
      { five_hour: null, seven_day: { utilization: 2, resets_at: futureIso }, limits: [fableLimit] },
      null,
      qNow
    );
    assert.deepStrictEqual(labelsOf(ultra), ['Weekly (7 day)', 'Fable limit']);
    assert.strictEqual(ultra.session, null, 'Negative: no synthesized Session bar when five_hour is null');
    assert.ok(
      !ultra.allBuckets.some((b) => b.bucketId === 'claude-5h'),
      'Negative: allBuckets must not carry a claude-5h bucket for a no-session-limit plan'
    );
    assert.strictEqual(ultra.available, true);

    const ultraStaleRelay = parseClaudeQuotaSummary(
      { five_hour: null, seven_day: { utilization: 2, resets_at: futureIso }, limits: [fableLimit] },
      { five_hour: { utilization: 0.4, resetsAt: pastSec } },
      qNow
    );
    assert.ok(
      !labelsOf(ultraStaleRelay).includes('Session (5hr)'),
      'Negative: an expired relay five_hour window must not resurrect the Session bar'
    );

    const ultraNoResetRelay = parseClaudeQuotaSummary(
      { five_hour: null, seven_day: { utilization: 2, resets_at: futureIso }, limits: [fableLimit] },
      { five_hour: { utilization: 0 } },
      qNow
    );
    assert.ok(
      !labelsOf(ultraNoResetRelay).includes('Session (5hr)'),
      'Negative: a relay five_hour window without a reset must not resurrect the Session bar'
    );

    const liveRelay = parseClaudeQuotaSummary(
      { five_hour: null, seven_day: { utilization: 2, resets_at: futureIso }, limits: [fableLimit] },
      { five_hour: { utilization: 0.4, resetsAt: futureSec } },
      qNow
    );
    assert.strictEqual(liveRelay.primaryBars[0].label, 'Session (5hr)');
    assert.strictEqual(liveRelay.primaryBars[0].usedPercent, 40);

    const limited = parseClaudeQuotaSummary(
      {
        five_hour: { utilization: 31, resets_at: new Date(qNow + 3600 * 1000).toISOString() },
        seven_day: { utilization: 2, resets_at: futureIso },
        limits: [fableLimit]
      },
      null,
      qNow
    );
    assert.deepStrictEqual(labelsOf(limited), ['Session (5hr)', 'Weekly (7 day)', 'Fable limit']);
    assert.strictEqual(limited.session.usedPercent, 31);

    // Unknown shape (key absent, or everything null): keep the three placeholder bars
    const legacy = parseClaudeQuotaSummary(
      { seven_day: { utilization: 2, resets_at: futureIso }, limits: [fableLimit] },
      null,
      qNow
    );
    assert.deepStrictEqual(labelsOf(legacy), ['Session (5hr)', 'Weekly (7 day)', 'Fable limit']);
    const relayOnly = parseClaudeQuotaSummary(
      { five_hour: null, seven_day: null },
      { seven_day: { utilization: 0.1, resetsAt: futureSec } },
      qNow
    );
    assert.deepStrictEqual(labelsOf(relayOnly), ['Session (5hr)', 'Weekly (7 day)', 'Fable limit']);
    const empty = parseClaudeQuotaSummary({ five_hour: null, seven_day: null }, null, qNow);
    assert.strictEqual(empty.available, false);
    assert.strictEqual(empty.primaryBars.length, 0);
    console.log('[PASS] Claude quota: no Session (5hr) bar when the plan reports five_hour: null');
  }

  // Antigravity quota: surface both Gemini and Claude & GPT (3p-5h + 3p-weekly) pools on primary cards in 5hr -> 7d order
  {
    const { parseAntigravityQuotaSummary } = require(path.join(ROOT, 'data.js'));
    const qNow = Date.UTC(2026, 10, 12, 12, 0, 0);
    const in45m = new Date(qNow + 45 * 60 * 1000).toISOString();
    const in5h = new Date(qNow + 5 * 3600 * 1000).toISOString();
    const in36h = new Date(qNow + 36 * 3600 * 1000).toISOString();
    const in7d = new Date(qNow + 7 * 86400 * 1000).toISOString();
    const expiredIso = new Date(qNow - 120 * 1000).toISOString();
    const labelsOf = (s) => s.primaryBars.map((b) => b.label);

    // Real Google AI Ultra response shape: weekly precedes 5h inside each group
    const ultraAgy = parseAntigravityQuotaSummary(
      {
        response: {
          groups: [
            {
              displayName: 'Gemini Models',
              buckets: [
                { bucketId: 'gemini-weekly', window: 'weekly', remainingFraction: 0.12, resetTime: in36h },
                { bucketId: 'gemini-5h', window: '5h', remainingFraction: 0.98, resetTime: in45m }
              ]
            },
            {
              displayName: 'Claude and GPT models',
              buckets: [
                { bucketId: '3p-weekly', window: 'weekly', remainingFraction: 1, resetTime: in7d },
                { bucketId: '3p-5h', window: '5h', remainingFraction: 0.85, resetTime: in5h }
              ]
            }
          ]
        }
      },
      qNow
    );
    assert.strictEqual(ultraAgy.available, true);
    assert.deepStrictEqual(labelsOf(ultraAgy), [
      'Session (5hr)',
      'Weekly (7 day)',
      'Claude & GPT (5hr)',
      'Claude & GPT (7 day)'
    ]);
    assert.deepStrictEqual(
      ultraAgy.allBuckets.map((b) => b.label),
      ['Session (5hr)', 'Weekly (7 day)', 'Claude & GPT (5hr)', 'Claude & GPT (7 day)'],
      'Details modal allBuckets must match primary 5hr -> 7 day order'
    );
    assert.strictEqual(ultraAgy.session.usedPercent, 2);
    assert.strictEqual(ultraAgy.weekly.usedPercent, 88);
    assert.strictEqual(ultraAgy.thirdPartySession.usedPercent, 15);
    assert.strictEqual(ultraAgy.thirdPartyWeekly.usedPercent, 0);

    // Negative: 3p-only or renamed-id Claude & GPT buckets must never be mislabeled as Gemini Session/Weekly
    const thirdPartyOnly = parseAntigravityQuotaSummary(
      {
        groups: [
          {
            displayName: 'Claude and GPT models',
            buckets: [
              { bucketId: 'custom-weekly', window: 'weekly', remainingFraction: 0.6, resetTime: in7d },
              { bucketId: 'custom-5h', window: '5h', remainingFraction: 0.4, resetTime: expiredIso }
            ]
          },
          {
            displayName: 'Experimental Addon',
            buckets: [{ bucketId: 'exp-monthly', window: 'monthly', remainingFraction: 0.5, resetTime: in7d }]
          }
        ]
      },
      qNow
    );
    assert.strictEqual(thirdPartyOnly.session, null, 'Negative: 3p 5h must not collide with Gemini session');
    assert.strictEqual(thirdPartyOnly.weekly, null, 'Negative: 3p weekly must not collide with Gemini weekly');
    assert.deepStrictEqual(labelsOf(thirdPartyOnly), ['Claude & GPT (5hr)', 'Claude & GPT (7 day)']);
    assert.strictEqual(thirdPartyOnly.thirdPartySession.windowExpired, true);
    assert.strictEqual(thirdPartyOnly.thirdPartySession.usedPercent, 0);
    assert.strictEqual(thirdPartyOnly.thirdPartySession.resetText, 'Window idle');
    assert.strictEqual(
      thirdPartyOnly.allBuckets.length,
      3,
      'Unrecognized extra buckets must still remain visible in allBuckets'
    );

    //AntigravityDataStore.hasQuotaWindowJustExpired must unwrap { response: { groups } } and detect expired 3p windows
    const { AntigravityDataStore } = require(path.join(ROOT, 'store.js'));
    const storeProbe = {
      cachedQuota: {
        response: {
          groups: [
            {
              displayName: 'Gemini Models',
              buckets: [{ bucketId: 'gemini-weekly', window: 'weekly', remainingFraction: 0.5, resetTime: in7d }]
            },
            {
              displayName: 'Claude and GPT models',
              buckets: [{ bucketId: '3p-5h', window: '5h', remainingFraction: 0, resetTime: expiredIso }]
            }
          ]
        }
      },
      lastQuotaWindowExpiryResetAt: 0
    };
    assert.strictEqual(
      AntigravityDataStore.prototype.hasQuotaWindowJustExpired.call(storeProbe, qNow),
      true,
      'hasQuotaWindowJustExpired must unwrap response.groups and detect expired 3p-5h window'
    );
    assert.strictEqual(
      AntigravityDataStore.prototype.hasQuotaWindowJustExpired.call(storeProbe, qNow),
      false,
      'hasQuotaWindowJustExpired must fire only once per expired reset timestamp'
    );
    console.log('[PASS] Antigravity quota: Claude & GPT (5hr + 7 day) pool surfaced cleanly alongside Gemini');
  }

  // Adversarial #10: Cryptographically signed theo-hub-bundle.zip self-updater + anti-rollback + dirty-git guard
  {
    const zlib = require('zlib');
    const crypto = require('crypto');
    const bundleUpdater = require(path.join(ROOT, 'bundle-updater.js'));

    function buildTestZipBuffer(entryMap) {
      const localChunks = [];
      const cdChunks = [];
      let offset = 0;
      const entries = Object.entries(entryMap);
      for (const [name, rawVal] of entries) {
        const nameBuf = Buffer.from(name, 'utf8');
        const dataBuf = Buffer.isBuffer(rawVal) ? rawVal : Buffer.from(String(rawVal), 'utf8');
        const compBuf = zlib.deflateRawSync(dataBuf);
        const crc = bundleUpdater.crc32Buffer(dataBuf);

        const lh = Buffer.alloc(30);
        lh.writeUInt32LE(0x04034b50, 0);
        lh.writeUInt16LE(20, 4);
        lh.writeUInt16LE(0, 6);
        lh.writeUInt16LE(8, 8);
        lh.writeUInt16LE(0, 10);
        lh.writeUInt16LE(0, 12);
        lh.writeUInt32LE(crc, 14);
        lh.writeUInt32LE(compBuf.length, 18);
        lh.writeUInt32LE(dataBuf.length, 22);
        lh.writeUInt16LE(nameBuf.length, 26);
        lh.writeUInt16LE(0, 28);
        localChunks.push(lh, nameBuf, compBuf);

        const cd = Buffer.alloc(46);
        cd.writeUInt32LE(0x02014b50, 0);
        cd.writeUInt16LE(20, 4);
        cd.writeUInt16LE(20, 6);
        cd.writeUInt16LE(0, 8);
        cd.writeUInt16LE(8, 10);
        cd.writeUInt16LE(0, 12);
        cd.writeUInt16LE(0, 14);
        cd.writeUInt32LE(crc, 16);
        cd.writeUInt32LE(compBuf.length, 20);
        cd.writeUInt32LE(dataBuf.length, 24);
        cd.writeUInt16LE(nameBuf.length, 28);
        cd.writeUInt16LE(0, 30);
        cd.writeUInt16LE(0, 32);
        cd.writeUInt16LE(0, 34);
        cd.writeUInt16LE(0, 36);
        cd.writeUInt32LE(0, 38);
        cd.writeUInt32LE(offset, 42);
        cdChunks.push(cd, nameBuf);

        offset += 30 + nameBuf.length + compBuf.length;
      }
      const cdBuf = Buffer.concat(cdChunks);
      const eocd = Buffer.alloc(22);
      eocd.writeUInt32LE(0x06054b50, 0);
      eocd.writeUInt16LE(0, 4);
      eocd.writeUInt16LE(0, 6);
      eocd.writeUInt16LE(entries.length, 8);
      eocd.writeUInt16LE(entries.length, 10);
      eocd.writeUInt32LE(cdBuf.length, 12);
      eocd.writeUInt32LE(offset, 16);
      eocd.writeUInt16LE(0, 20);
      return Buffer.concat([...localChunks, cdBuf, eocd]);
    }

    function makeValidBundleEntries(builtAt, markerText = 'v1') {
      const coreFiles = {
        'package.json': JSON.stringify({ name: 'theo-hub', publisher: 'bhfirms', version: '0.1.0' }),
        'extension.js': `module.exports = { marker: ${JSON.stringify(markerText)} };\n`,
        'remote.js': `module.exports = { marker: ${JSON.stringify(markerText)} };\n`,
        'store.js': `module.exports = { marker: ${JSON.stringify(markerText)} };\n`,
        'device-identity.js': `module.exports = { marker: ${JSON.stringify(markerText)} };\n`,
        'scripts/relay_keepalive.cjs': `module.exports = { marker: ${JSON.stringify(markerText)} };\n`
      };
      const filesHashes = {};
      for (const [rel, txt] of Object.entries(coreFiles)) {
        filesHashes[rel] = crypto.createHash('sha256').update(txt, 'utf8').digest('hex');
      }
      return {
        ...coreFiles,
        '.theo-bundle-manifest.json': JSON.stringify({
          formatVersion: 1,
          version: '0.1.0',
          builtAt,
          files: filesHashes
        })
      };
    }

    // Reject Zip-Slip, forbidden secret files, and syntax-broken JS before touching disk
    assert.strictEqual(bundleUpdater.validateSafeZipEntryPath('../evil.js').ok, false, 'Zip-Slip ../ must be rejected');
    assert.strictEqual(bundleUpdater.validateSafeZipEntryPath('credentials.json').ok, false, 'credentials.json must be rejected');
    assert.throws(() => {
      const badSyntax = makeValidBundleEntries(Date.now(), 'broken');
      badSyntax['remote.js'] = 'const broken = ;\n';
      const mf = JSON.parse(badSyntax['.theo-bundle-manifest.json']);
      mf.files['remote.js'] = crypto.createHash('sha256').update(badSyntax['remote.js'], 'utf8').digest('hex');
      badSyntax['.theo-bundle-manifest.json'] = JSON.stringify(mf);
      bundleUpdater.extractAndVerifyBundleZip(buildTestZipBuffer(badSyntax));
    }, /SyntaxError|Unexpected token/, 'Negative: syntax-broken JS in bundle must fail vm.Script gate');

    const tmpUpdDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-self-upd-'));
    let servedZip = Buffer.alloc(0);
    const zipSrv = http.createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Length': servedZip.length });
      res.end(servedZip);
    });
    await new Promise((r) => zipSrv.listen(0, '127.0.0.1', r));
    const zipUrl = `http://127.0.0.1:${zipSrv.address().port}/theo-hub-bundle.zip`;
    const testEdgeKey = 'e'.repeat(64);

    try {
      const extDir = path.join(tmpUpdDir, 'ext');
      const repoDir = path.join(tmpUpdDir, 'repo');
      const stampPath = path.join(tmpUpdDir, 'stamp.json');
      const lockPath = path.join(tmpUpdDir, 'upd.lock');
      fs.mkdirSync(extDir, { recursive: true });
      fs.mkdirSync(repoDir, { recursive: true });

      const builtAt1 = Date.now() - 5000;
      servedZip = buildTestZipBuffer(makeValidBundleEntries(builtAt1, 'release-1'));
      const sha1 = crypto.createHash('sha256').update(servedZip).digest('hex');

      // Domain-separation negative check: derived edge auth token CANNOT forge a bundle signature
      const derivedTok = devId.deriveEdgeAuthToken(testEdgeKey);
      const forgedRec = {
        version: '0.1.0',
        builtAt: builtAt1,
        size: servedZip.length,
        sha256: sha1,
        url: zipUrl,
        sig: bundleUpdater.signHubReleaseRecord(
          { version: '0.1.0', builtAt: builtAt1, sha256: sha1, url: zipUrl },
          derivedTok
        )
      };
      assert.strictEqual(
        bundleUpdater.verifyHubReleaseRecord(forgedRec, testEdgeKey, { allowLoopbackTest: true }).ok,
        false,
        'Negative: mobile/relay derived token must never validate as bundle signing key'
      );

      // Disallowed external URL negative check
      const evilUrlRec = {
        version: '0.1.0',
        builtAt: builtAt1,
        sha256: sha1,
        url: 'https://evil.attacker.example/theo/theo-hub-bundle.zip'
      };
      evilUrlRec.sig = bundleUpdater.signHubReleaseRecord(evilUrlRec, testEdgeKey);
      assert.strictEqual(
        bundleUpdater.verifyHubReleaseRecord(evilUrlRec, testEdgeKey).reason,
        'disallowed_url'
      );

      // Far-future builtAt negative check
      const futureRec = {
        version: '0.1.0',
        builtAt: Date.now() + 3600 * 1000,
        sha256: sha1,
        url: zipUrl
      };
      futureRec.sig = bundleUpdater.signHubReleaseRecord(futureRec, testEdgeKey);
      assert.strictEqual(
        bundleUpdater.verifyHubReleaseRecord(futureRec, testEdgeKey, { allowLoopbackTest: true }).reason,
        'invalid_built_at'
      );

      // Valid signed bundle applies to extDir + non-git repoDir and writes anti-rollback stamp
      const validRec1 = {
        version: '0.1.0',
        builtAt: builtAt1,
        size: servedZip.length,
        sha256: sha1,
        url: zipUrl
      };
      validRec1.sig = bundleUpdater.signHubReleaseRecord(validRec1, testEdgeKey);
      const apply1 = await bundleUpdater.maybeApplyHubReleaseUpdate(validRec1, {
        edgeAccessKey: testEdgeKey,
        allowLoopbackTest: true,
        extTargets: [extDir],
        repoDir,
        stampPath,
        lockPath,
        skipLauncherRebuild: true
      });
      assert.strictEqual(apply1.updated, true);
      assert.ok(fs.readFileSync(path.join(extDir, 'remote.js'), 'utf8').includes('release-1'));
      assert.ok(fs.readFileSync(path.join(repoDir, 'remote.js'), 'utf8').includes('release-1'));

      // Anti-rollback: same sha and older builtAt with different sha are both ignored
      const replay = await bundleUpdater.maybeApplyHubReleaseUpdate(validRec1, {
        edgeAccessKey: testEdgeKey,
        allowLoopbackTest: true,
        extTargets: [extDir],
        repoDir,
        stampPath,
        lockPath,
        skipLauncherRebuild: true
      });
      assert.strictEqual(replay.updated, false);
      assert.strictEqual(replay.reason, 'already_installed_sha');

      const olderZip = buildTestZipBuffer(makeValidBundleEntries(builtAt1 - 10000, 'release-0-rollback'));
      const olderSha = crypto.createHash('sha256').update(olderZip).digest('hex');
      const rollbackRec = {
        version: '0.1.0',
        builtAt: builtAt1 - 10000,
        size: olderZip.length,
        sha256: olderSha,
        url: zipUrl
      };
      rollbackRec.sig = bundleUpdater.signHubReleaseRecord(rollbackRec, testEdgeKey);
      const rollbackRes = await bundleUpdater.maybeApplyHubReleaseUpdate(rollbackRec, {
        edgeAccessKey: testEdgeKey,
        allowLoopbackTest: true,
        extTargets: [extDir],
        repoDir,
        stampPath,
        lockPath,
        skipLauncherRebuild: true
      });
      assert.strictEqual(rollbackRes.updated, false);
      assert.strictEqual(rollbackRes.reason, 'not_newer_than_installed');

      // Dirty git worktree protection: extDir updates while uncommitted edits in repoDir are preserved!
      const dirtyGitRepo = path.join(tmpUpdDir, 'dirty-git-repo');
      fs.mkdirSync(dirtyGitRepo, { recursive: true });
      spawnSync('git', ['init'], { cwd: dirtyGitRepo, windowsHide: true });
      spawnSync('git', ['config', 'user.email', 'test@example.com'], { cwd: dirtyGitRepo, windowsHide: true });
      spawnSync('git', ['config', 'user.name', 'Test'], { cwd: dirtyGitRepo, windowsHide: true });
      fs.writeFileSync(path.join(dirtyGitRepo, 'remote.js'), '// committed baseline\n', 'utf8');
      spawnSync('git', ['add', 'remote.js'], { cwd: dirtyGitRepo, windowsHide: true });
      spawnSync('git', ['commit', '-m', 'init'], { cwd: dirtyGitRepo, windowsHide: true });
      fs.writeFileSync(path.join(dirtyGitRepo, 'remote.js'), '// local uncommitted work\n', 'utf8');

      const builtAt2 = Date.now() - 1000;
      servedZip = buildTestZipBuffer(makeValidBundleEntries(builtAt2, 'release-2'));
      const sha2 = crypto.createHash('sha256').update(servedZip).digest('hex');
      const validRec2 = {
        version: '0.1.0',
        builtAt: builtAt2,
        size: servedZip.length,
        sha256: sha2,
        url: zipUrl
      };
      validRec2.sig = bundleUpdater.signHubReleaseRecord(validRec2, testEdgeKey);
      const apply2 = await bundleUpdater.maybeApplyHubReleaseUpdate(validRec2, {
        edgeAccessKey: testEdgeKey,
        allowLoopbackTest: true,
        extTargets: [extDir],
        repoDir: dirtyGitRepo,
        stampPath,
        lockPath,
        skipLauncherRebuild: true
      });
      assert.strictEqual(apply2.updated, true, `apply2 failed: ${JSON.stringify(apply2)}`);
      assert.strictEqual(apply2.repoResult, 'skipped_dirty_worktree');
      assert.ok(fs.readFileSync(path.join(extDir, 'remote.js'), 'utf8').includes('release-2'), 'installed extension updates');
      assert.strictEqual(
        fs.readFileSync(path.join(dirtyGitRepo, 'remote.js'), 'utf8'),
        '// local uncommitted work\n',
        'uncommitted git edits in repoDir are never overwritten'
      );

      // Versioned extension target registers in extensions.json and self-heals if target folder is wiped (High #5)
      const fakeVscodeExtParent = path.join(tmpUpdDir, '.vscode', 'extensions');
      fs.mkdirSync(fakeVscodeExtParent, { recursive: true });
      const versionedExtDir = path.join(fakeVscodeExtParent, 'bhfirms.theo-hub-0.1.1');
      const builtAt3 = Date.now() - 500;
      servedZip = buildTestZipBuffer(makeValidBundleEntries(builtAt3, 'release-3'));
      const sha3 = crypto.createHash('sha256').update(servedZip).digest('hex');
      const validRec3 = {
        version: '0.1.1',
        builtAt: builtAt3,
        size: servedZip.length,
        sha256: sha3,
        url: zipUrl
      };
      validRec3.sig = bundleUpdater.signHubReleaseRecord(validRec3, testEdgeKey);
      const apply3 = await bundleUpdater.maybeApplyHubReleaseUpdate(validRec3, {
        edgeAccessKey: testEdgeKey,
        allowLoopbackTest: true,
        homeDir: tmpUpdDir,
        extTargets: [versionedExtDir],
        repoDir: dirtyGitRepo,
        stampPath,
        lockPath,
        skipLauncherRebuild: true,
        skipBridgePrepatch: true
      });
      assert.strictEqual(apply3.updated, true);
      const extJsonEntries = JSON.parse(fs.readFileSync(path.join(fakeVscodeExtParent, 'extensions.json'), 'utf8'));
      const regEntry = extJsonEntries.find((e) => e?.identifier?.id === 'bhfirms.theo-hub');
      assert.ok(regEntry, 'self-updater must register bhfirms.theo-hub in extensions.json');
      assert.strictEqual(regEntry.version, '0.1.1');
      assert.strictEqual(regEntry.relativeLocation, 'bhfirms.theo-hub-0.1.1');

      // Wiping versionedExtDir while stamp.json still holds sha3 triggers automatic self-healing re-install!
      fs.rmSync(versionedExtDir, { recursive: true, force: true });
      const healRes = await bundleUpdater.maybeApplyHubReleaseUpdate(validRec3, {
        edgeAccessKey: testEdgeKey,
        allowLoopbackTest: true,
        homeDir: tmpUpdDir,
        extTargets: [versionedExtDir],
        repoDir: dirtyGitRepo,
        stampPath,
        lockPath,
        skipLauncherRebuild: true,
        skipBridgePrepatch: true
      });
      assert.strictEqual(healRes.updated, true, 'missing extension target must self-heal even when stamp.json matches sha');
      assert.ok(fs.existsSync(path.join(versionedExtDir, 'remote.js')));

      // End-to-end build_vsix.py --no-publish-store & --publish-only test (Critical #1 & #2):
      // proves bundle verification succeeds and publish sends derived cloudKey (NEVER raw edgeAccessKey)!
      const buildOutDir = path.join(tmpUpdDir, 'dist-test');
      let capturedPublishBody = null;
      const publishSrv = http.createServer((req, res) => {
        if (req.method === 'GET' && req.url.startsWith('/theo/theo-hub-bundle.zip')) {
          const builtBundle = fs.readFileSync(path.join(buildOutDir, 'theo-hub-bundle.zip'));
          res.writeHead(200, { 'Content-Type': 'application/zip' });
          res.end(builtBundle);
          return;
        }
        if (req.method === 'POST' && req.url === '/store') {
          const chunks = [];
          req.on('data', (c) => chunks.push(c));
          req.on('end', () => {
            capturedPublishBody = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: true }));
          });
          return;
        }
        res.writeHead(404);
        res.end();
      });
      await new Promise((r) => publishSrv.listen(0, '127.0.0.1', r));
      try {
        const pubPort = publishSrv.address().port;
        const pubBundleUrl = `http://127.0.0.1:${pubPort}/theo/theo-hub-bundle.zip`;
        const tmpCredFile = path.join(tmpUpdDir, 'pub-creds.json');
        fs.writeFileSync(
          tmpCredFile,
          JSON.stringify({
            edgeAccessKey: testEdgeKey,
            edgeRelayUrl: `ws://127.0.0.1:${pubPort}/ws`,
            cloudUrl: `http://127.0.0.1:${pubPort}/store`,
            cloudPinned: true,
            k: Buffer.from(devId.deriveEdgeAuthToken(testEdgeKey), 'utf8').toString('base64'),
            u: Buffer.from(`http://127.0.0.1:${pubPort}/store`, 'utf8').toString('base64')
          }),
          'utf8'
        );
        // Also test unpinned edge-derived credential shape (no cloudKey field in JSON at all!)
        const unpinnedCredFile = path.join(tmpUpdDir, 'unpinned-creds.json');
        fs.writeFileSync(
          unpinnedCredFile,
          JSON.stringify({
            edgeAccessKey: testEdgeKey,
            edgeRelayUrl: `ws://127.0.0.1:${pubPort}/ws`
          }),
          'utf8'
        );
        const portablePy = path.join(os.homedir(), '.local', 'python312', 'python.exe');
        const pyExe =
          process.platform === 'win32'
            ? fs.existsSync(portablePy)
              ? portablePy
              : 'python'
            : 'python3';
        const runPyAsync = (pyArgs, opts = {}) =>
          new Promise((resolve) => {
            const { spawn: spawnChild } = require('child_process');
            const cp = spawnChild(pyExe, pyArgs, {
              cwd: ROOT,
              env: opts.env || process.env,
              windowsHide: true,
              stdio: ['ignore', 'pipe', 'pipe']
            });
            let stdout = '';
            let stderr = '';
            const timer = setTimeout(() => {
              try {
                cp.kill();
              } catch {}
              resolve({ status: null, stdout, stderr: `${stderr}\nTIMEOUT` });
            }, opts.timeout || 20000);
            cp.stdout.on('data', (d) => {
              stdout += d.toString('utf8');
            });
            cp.stderr.on('data', (d) => {
              stderr += d.toString('utf8');
            });
            cp.on('close', (code) => {
              clearTimeout(timer);
              resolve({ status: code, stdout, stderr });
            });
          });
        const b1 = await runPyAsync(
          [
            path.join(ROOT, 'build_vsix.py'),
            '--no-publish-store',
            '--out-dir',
            buildOutDir,
            '--bundle-url',
            pubBundleUrl
          ],
          { timeout: 30000 }
        );
        assert.strictEqual(b1.status, 0, `build_vsix.py --no-publish-store failed: ${b1.stderr || b1.stdout}`);
        assert.ok(fs.existsSync(path.join(buildOutDir, 'theo-hub-release-meta.json')));

        // Note: ws://127.0.0.1 derives http://127.0.0.1:<port>/store via deriveStoreEndpoint
        const b2Env = { ...process.env, THEO_CRED_PATH: unpinnedCredFile };
        delete b2Env.THEO_CLOUD_URL;
        delete b2Env.THEO_CLOUD_KEY;
        delete b2Env.THEO_EDGE_KEY;
        delete b2Env.THEO_EDGE_RELAY_URL;
        const b2 = await runPyAsync(
          [
            path.join(ROOT, 'build_vsix.py'),
            '--publish-only',
            '--out-dir',
            buildOutDir,
            '--bundle-url',
            pubBundleUrl,
            '--allow-loopback-test'
          ],
          { env: b2Env, timeout: 20000 }
        );
        assert.strictEqual(b2.status, 0, `build_vsix.py --publish-only failed: ${b2.stderr || b2.stdout}`);
        assert.ok(capturedPublishBody && capturedPublishBody.op === 'patch');
        assert.strictEqual(
          capturedPublishBody.key,
          devId.deriveEdgeAuthToken(testEdgeKey),
          'publish_hub_release MUST authenticate with derived cloudKey, NEVER raw edgeAccessKey'
        );
        assert.notStrictEqual(capturedPublishBody.key, testEdgeKey);
        assert.strictEqual(
          bundleUpdater.verifyHubReleaseRecord(capturedPublishBody.patch.hub_release, testEdgeKey, {
            allowLoopbackTest: true
          }).ok,
          true
        );
      } finally {
        await new Promise((r) => publishSrv.close(r));
      }
    } finally {
      await new Promise((r) => (zipUrl ? zipSrv.close(r) : r()));
      try {
        fs.rmSync(tmpUpdDir, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
      } catch {}
    }
    console.log('[PASS] Adversarial #10: Signed theo-hub-bundle.zip self-updater, domain separation, anti-rollback & dirty-git guard verified');
  }

  // Adversarial #11: Local NTFS junction home-folder attribution vs restored peer sessions
  {
    const tmpJuncRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-junc-home-'));
    const prevSelfHome = process.env.THEO_SELF_HOMEDIR;
    const prevFleetPath = process.env.THEO_FLEET_HOMES_PATH;
    try {
      const realSelfHome = path.join(tmpJuncRoot, 'Users', 'localuser');
      const junctionAliasHome = path.join(tmpJuncRoot, 'Users', 'AliasUser');
      fs.mkdirSync(path.join(realSelfHome, 'bhfirms', 'repo'), { recursive: true });
      fs.symlinkSync(realSelfHome, junctionAliasHome, 'junction');

      process.env.THEO_SELF_HOMEDIR = realSelfHome;
      process.env.THEO_FLEET_HOMES_PATH = path.join(tmpJuncRoot, 'fleet-homes.json');

      const selfDev = { id: 'pc-this', name: 'This PC' };
      devId.rememberFleetHomes(
        [
          {
            id: 'pc-peer',
            name: 'Peer PC',
            homedir: junctionAliasHome,
            rowIds: ['restored-from-peer-1']
          },
          {
            id: 'pc-remote',
            name: 'Remote PC',
            homedir: path.join(tmpJuncRoot, 'OtherDisk', 'OtherUser'),
            rowIds: []
          }
        ],
        'pc-this'
      );

      const aliasRepoCwd = path.join(junctionAliasHome, 'bhfirms', 'repo');
      // 1) A session started locally on this PC under the junction path belongs to THIS PC
      const localNewOwner = devId.inferRowOwnerDevice(
        { id: 'started-here-1', cwd: aliasRepoCwd, status: 'idle' },
        selfDev
      );
      assert.strictEqual(localNewOwner.id, 'pc-this', 'local session under NTFS junction alias must belong to this PC');

      // 2) An idle restored session that the peer PC published in its rowIds stays owned by the peer PC
      const restoredIdleOwner = devId.inferRowOwnerDevice(
        { id: 'restored-from-peer-1', cwd: aliasRepoCwd, status: 'idle', open: false },
        selfDev
      );
      assert.strictEqual(restoredIdleOwner.id, 'pc-peer', 'idle restored peer transcript keeps peer ownership');

      // 3) Opening or resuming that restored session locally makes it owned by this PC
      const reopenedLocalOwner = devId.inferRowOwnerDevice(
        { id: 'restored-from-peer-1', cwd: aliasRepoCwd, status: 'idle', open: true },
        selfDev
      );
      assert.strictEqual(reopenedLocalOwner.id, 'pc-this', 'session opened locally under junction alias belongs to this PC');

      // 4) Non-junction foreign home folder still belongs to the peer
      const nonAliasOwner = devId.inferRowOwnerDevice(
        { id: 'any-row', cwd: path.join(tmpJuncRoot, 'OtherDisk', 'OtherUser', 'proj') },
        selfDev
      );
      assert.strictEqual(nonAliasOwner.id, 'pc-remote');

      // 5) Legacy non-peerOnly .theo-cloud-sessions-cache.json must NOT poison junction attribution (Medium #9)
      const legacyFleetFile = path.join(tmpJuncRoot, 'legacy-fleet-homes.json');
      const legacyCacheFile = path.join(tmpJuncRoot, 'legacy-sessions-cache.json');
      const prevPeerCacheEnv = process.env.THEO_PEER_CACHE_PATH;
      process.env.THEO_FLEET_HOMES_PATH = legacyFleetFile;
      process.env.THEO_PEER_CACHE_PATH = legacyCacheFile;
      try {
        // Legacy fleet-homes without rowIds (`hasRowIds === false`)
        fs.writeFileSync(
          legacyFleetFile,
          JSON.stringify({
            homes: {
              [junctionAliasHome.toLowerCase()]: { id: 'pc-peer', name: 'Peer PC' }
            }
          }),
          'utf8'
        );
        // Legacy cache WITHOUT `peerOnly: true` holding local session mislabelled as pc-peer
        fs.writeFileSync(
          legacyCacheFile,
          JSON.stringify({
            snapshot: {
              rows: [{ id: 'local-idle-under-alias', deviceId: 'pc-peer' }]
            }
          }),
          'utf8'
        );
        const ownerWithLegacyCache = devId.inferRowOwnerDevice(
          { id: 'local-idle-under-alias', cwd: aliasRepoCwd, status: 'idle', open: false },
          selfDev
        );
        assert.strictEqual(
          ownerWithLegacyCache.id,
          'pc-this',
          'Legacy non-peerOnly cache snapshot.rows must NOT misattribute local junction sessions to peer'
        );
      } finally {
        if (prevPeerCacheEnv === undefined) delete process.env.THEO_PEER_CACHE_PATH;
        else process.env.THEO_PEER_CACHE_PATH = prevPeerCacheEnv;
      }
    } finally {
      if (prevSelfHome === undefined) delete process.env.THEO_SELF_HOMEDIR;
      else process.env.THEO_SELF_HOMEDIR = prevSelfHome;
      if (prevFleetPath === undefined) delete process.env.THEO_FLEET_HOMES_PATH;
      else process.env.THEO_FLEET_HOMES_PATH = prevFleetPath;
      try {
        fs.rmSync(tmpJuncRoot, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
      } catch {}
    }
    console.log('[PASS] Adversarial #11: Local NTFS junction home-folder attribution vs restored peer transcripts verified');
  }

  // Adversarial #12: Mid-run crash retry (lease-bounded claims) + Edge Relay last-typed host routing
  {
    const {
      TheoRemoteBridge: LeaseBridge,
      beginCloudCommandLease,
      completeCloudCommandOnce,
      isCloudCommandSealed
    } = require(path.join(ROOT, 'remote.js'));
    const tmpClaimFile = path.join(os.tmpdir(), `theo-lease-smoke-${process.pid}.json`);
    const prevClaimEnv = process.env.THEO_CLAIMED_CMDS_PATH;
    process.env.THEO_CLAIMED_CMDS_PATH = tmpClaimFile;
    try {
      // Local in-flight lease expires after crash so restarted bridge retries, then seals permanently on completion
      assert.strictEqual(beginCloudCommandLease('cmd-crash-local:1', 60), true);
      assert.strictEqual(beginCloudCommandLease('cmd-crash-local:1', 60), false, 'duplicate blocked while in-flight');
      assert.strictEqual(isCloudCommandSealed('cmd-crash-local:1'), false);
      await new Promise((r) => setTimeout(r, 75));
      assert.strictEqual(beginCloudCommandLease('cmd-crash-local:1', 60), true, 'expired in-flight lease is retried after crash');
      assert.strictEqual(completeCloudCommandOnce('cmd-crash-local:1'), true);
      assert.strictEqual(isCloudCommandSealed('cmd-crash-local:1'), true);
      await new Promise((r) => setTimeout(r, 75));
      assert.strictEqual(beginCloudCommandLease('cmd-crash-local:1', 60), false, 'completed command remains sealed');
      const diskMap = JSON.parse(fs.readFileSync(tmpClaimFile, 'utf8'));
      assert.strictEqual(typeof diskMap['cmd-crash-local:1'], 'number');

      // Cross-host crash takeover in syncCloudRelay: peer holds lease -> self waits -> lease expires -> self takes over!
      const b = new LeaseBridge(null, { hub: { lastPosted: JSON.stringify({ rows: [] }), snapshot: {} } });
      if (b.edgeClient) b.edgeClient.stop();
      b.deviceInfo = { id: 'pc-survivor', name: 'Survivor', role: 'host', capabilities: [] };
      b.relayConfig.url = 'https://store.invalid/store';
      b.relayConfig.key = 'k'.repeat(64);
      b.pushDevices = [];
      b.syncFromDiskPersonalLedger = () => {};
      b.ensureCloudPrayerTimersArmed = async () => {};
      b.evaluateRealtimePushAlerts = async () => {};
      b.workspacesDetailCachedAt = Date.now();
      b.getThreadDetail = async (id) => ({ id, messages: [] });
      const ran = [];
      b.executeRemoteCommand = async (c) => {
        ran.push(c.id);
        return { ok: true };
      };
      const leaseExpiry = Date.now() + 80;
      let claimCalls = 0;
      const pending = { id: 'cmd-peer-died-1', createdAt: Date.now(), status: 'pending', type: 'refresh' };
      b.postStore = async (payload) => {
        if (payload.op === 'get_control') {
          return {
            ok: true,
            coordinator: { deviceId: 'pc-survivor', since: 1, lastBeat: 1, ttlMs: 90000, legacyLead: false },
            docs: { queue: { commands: [pending] } }
          };
        }
        if (payload.op === 'get_theo') return { ok: true, docs: { device_states: {}, threads: {} } };
        if (payload.op === 'claim' && !payload.release) {
          claimCalls++;
          if (Date.now() < leaseExpiry) {
            return { ok: true, claimed: false, by: 'pc-crashed', leaseUntil: leaseExpiry };
          }
          return { ok: true, claimed: true, by: payload.deviceId, leaseUntil: Date.now() + 60000 };
        }
        return { ok: true };
      };

      b._lastFleetFollowAt = Date.now();
      await b.syncCloudRelay({ pushState: false });
      assert.deepStrictEqual(ran, [], 'waits while peer in-flight lease is active');
      assert.strictEqual(claimCalls, 1);

      // Immediate second poll within hold window makes zero redundant claim calls
      b.cloudSyncInFlight = false;
      await b.syncCloudRelay({ pushState: false });
      assert.strictEqual(claimCalls, 1, 'holds locally until peer lease expiry');

      // Once peer lease expires and command is still pending, survivor re-claims and executes it!
      await new Promise((r) => setTimeout(r, 95));
      b.cloudSyncInFlight = false;
      await b.syncCloudRelay({ pushState: false });
      assert.deepStrictEqual(ran, ['cmd-peer-died-1'], 'survivor takes over and runs command after peer mid-run crash');

      // Transient network failure on queue patch after local seal must retry queue closure on next cycle without re-running (Medium #8)
      const transientCmd = { id: 'cmd-transient-patch-1', createdAt: Date.now(), status: 'pending', type: 'refresh' };
      let transientPatches = 0;
      let lastPatchedQueue = null;
      const ranTransient = [];
      b.executeRemoteCommand = async (c) => {
        ranTransient.push(c.id);
        return { ok: true, note: 'ran-once' };
      };
      b.postStore = async (payload) => {
        if (payload.op === 'get_control') {
          return {
            ok: true,
            coordinator: { deviceId: 'pc-survivor', since: 1, lastBeat: 1, ttlMs: 90000, legacyLead: false },
            docs: { queue: lastPatchedQueue || { commands: [transientCmd] } }
          };
        }
        if (payload.op === 'get_theo') return { ok: true, docs: { device_states: {}, threads: {} } };
        if (payload.op === 'claim') {
          return { ok: true, claimed: true, by: payload.deviceId, leaseUntil: Date.now() + 60000 };
        }
        if (payload.op === 'patch') {
          if (payload.patch?.queue) {
            transientPatches++;
            if (transientPatches === 1) {
              throw new Error('simulated transient network drop');
            }
            lastPatchedQueue = payload.patch.queue;
          }
          return { ok: true };
        }
        return { ok: true };
      };
      b.cloudSyncInFlight = false;
      await b.syncCloudRelay({ pushState: false });
      assert.deepStrictEqual(ranTransient, ['cmd-transient-patch-1']);
      assert.strictEqual(lastPatchedQueue, null, 'first patch dropped');

      // Next sync cycle: command is NOT executed a second time, and pendingQueueClosures closes it in the store!
      b.cloudSyncInFlight = false;
      await b.syncCloudRelay({ pushState: false });
      assert.deepStrictEqual(ranTransient, ['cmd-transient-patch-1'], 'never re-executes sealed command');
      assert.ok(lastPatchedQueue, 'second cycle flushes pendingQueueClosures to store');
      assert.strictEqual(lastPatchedQueue.commands.find((c) => c.id === 'cmd-transient-patch-1')?.status, 'done');
      assert.strictEqual(lastPatchedQueue.results['cmd-transient-patch-1']?.note, 'ran-once');
    } finally {
      if (prevClaimEnv === undefined) delete process.env.THEO_CLAIMED_CMDS_PATH;
      else process.env.THEO_CLAIMED_CMDS_PATH = prevClaimEnv;
      try {
        fs.unlinkSync(tmpClaimFile);
      } catch {}
    }

    // Pre-upgrade THEO.exe `--verify-config` gate (`supportsIdleMs`) on Windows (Critical #3)
    if (process.platform === 'win32') {
      const tmpLauncherDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-idle-gate-'));
      try {
        const cscCandidates = [
          path.join(process.env.WINDIR || 'C:\\Windows', 'Microsoft.NET', 'Framework64', 'v4.0.30319', 'csc.exe'),
          path.join(process.env.WINDIR || 'C:\\Windows', 'Microsoft.NET', 'Framework', 'v4.0.30319', 'csc.exe')
        ];
        const cscExe = cscCandidates.find((p) => fs.existsSync(p));
        assert.ok(cscExe, 'Expected .NET Framework csc.exe on Windows');
        const canaryFile = path.join(tmpLauncherDir, 'unwanted-gui-launch.txt');
        const legacyCs = path.join(tmpLauncherDir, 'LegacyTheo.cs');
        const legacyExe = path.join(tmpLauncherDir, 'LegacyTheo.exe');
        fs.writeFileSync(
          legacyCs,
          [
            'using System;',
            'using System.IO;',
            'class P {',
            '  static int Main(string[] args) {',
            '    foreach (string a in args) {',
            '      if (a == "--verify-config") { Console.WriteLine("{\\"ok\\":true}"); return 0; }',
            '    }',
            `    File.WriteAllText(@\"${canaryFile.replace(/\\/g, '\\\\')}\", \"launched\");`,
            '    return 0;',
            '  }',
            '}'
          ].join('\r\n'),
          'utf8'
        );
        const comp = spawnSync(cscExe, ['/nologo', '/target:exe', `/out:${legacyExe}`, legacyCs], {
          windowsHide: true,
          encoding: 'utf8',
          timeout: 20000
        });
        assert.strictEqual(comp.status, 0, `csc compile failed: ${comp.stdout || comp.stderr}`);

        const preGateRes = await new Promise((resolve) => {
          devId.refreshOsIdleMsAsync({
            exePath: legacyExe,
            allowInSmokeTest: true,
            ignoreInterval: true,
            onDone: resolve
          });
        });
        assert.strictEqual(preGateRes.polled, false);
        assert.strictEqual(preGateRes.reason, 'unsupported_launcher');
        assert.strictEqual(
          fs.existsSync(canaryFile),
          false,
          'Pre-upgrade THEO.exe without supportsIdleMs:true must NEVER be invoked with --idle-ms'
        );
      } finally {
        try {
          fs.rmSync(tmpLauncherDir, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
        } catch {}
      }
    }

    // Edge Relay _selectTargetHost routes untargeted ('auto') RPCs to the last-typed host
    const { DatabaseSync } = require('node:sqlite');
    const actDb = new DatabaseSync(':memory:');
    const actSql = {
      exec(query, ...params) {
        if (params.length === 0 && !/^\s*SELECT\b/i.test(query)) {
          actDb.exec(query);
          return [];
        }
        const stmt = actDb.prepare(query);
        return /^\s*SELECT\b/i.test(query) ? stmt.all(...params) : (stmt.run(...params), []);
      }
    };
    const makeFakeHostWs = (deviceId, connectedAt) => {
      const att = {
        role: 'host',
        authenticated: true,
        deviceId,
        deviceName: deviceId,
        connectedAt,
        lastSeenAt: Date.now()
      };
      return {
        deserializeAttachment: () => att,
        serializeAttachment: (next) => Object.assign(att, next)
      };
    };
    const wsOld = makeFakeHostWs('pc-connected-longest', 1000);
    const wsTyped = makeFakeHostWs('pc-last-typed', 5000);
    const actRelay = new TheoRelayRoom(
      {
        getWebSockets: () => [wsOld, wsTyped],
        storage: {
          sql: actSql,
          getAlarm: async () => null,
          setAlarm: async () => {}
        }
      },
      { AUTH_TOKEN: roomAuthToken }
    );
    // Before any input is reported, tenure picks wsOld
    assert.strictEqual(actRelay._selectTargetHost('auto').att.deviceId, 'pc-connected-longest');
    // User types on wsTyped (idleMs: 800ms) -> 'auto' immediately routes to pc-last-typed!
    actRelay._noteHostActivity('pc-last-typed', 800, Date.now());
    assert.strictEqual(
      actRelay._selectTargetHost('auto').att.deviceId,
      'pc-last-typed',
      'Untargeted phone commands route to the PC the user last typed on'
    );
    // Explicit targetDeviceId always overrides auto preference
    assert.strictEqual(actRelay._selectTargetHost('pc-connected-longest').att.deviceId, 'pc-connected-longest');
    actDb.close();
    console.log('[PASS] Adversarial #12: Lease-bounded crash takeover & Edge Relay last-typed host routing verified');
  }

  // =========================================================================
  // Adversarial #13: Shared Claude permission mode for phone runs & already-open chats
  // =========================================================================
  {
    const { EventEmitter } = require('events');
    const {
      TheoDirectRunner,
      resolveEffectiveClaudeCliPermission
    } = require('../direct-runner');
    const claudeBridge = require('../compat/claude-hub-bridge.cjs');
    const tmpPermDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-shared-perm-'));
    try {
      const tmpHome = path.join(tmpPermDir, 'home');
      const tmpMemRoot = path.join(tmpHome, 'OneDrive - BHFIRMS', 'System', 'System', 'THEO');
      const sharedFile = path.join(tmpMemRoot, 'Admin', 'claude-permission-mode.json');
      const claudeSettingsFile = path.join(tmpHome, '.claude', 'settings.json');
      fs.mkdirSync(path.dirname(sharedFile), { recursive: true });
      fs.mkdirSync(path.dirname(claudeSettingsFile), { recursive: true });

      const makeFakeSpawnRecorder = () => {
        const calls = [];
        const spawnImpl = (cmd, args) => {
          calls.push({ cmd, args: [...args] });
          const child = new EventEmitter();
          child.pid = 42424;
          child.stdout = new EventEmitter();
          child.stderr = new EventEmitter();
          child.kill = () => {};
          setImmediate(() => {
            child.stdout.emit(
              'data',
              Buffer.from(
                `${JSON.stringify({ type: 'system', subtype: 'init', session_id: 'sess-phone-1' })}\n` +
                  `${JSON.stringify({ type: 'result', is_error: false, result: 'ok' })}\n`
              )
            );
            child.emit('close', 0);
          });
          return child;
        };
        return { calls, spawnImpl };
      };

      // 1. Shared file bypassPermissions -> phone/headless runner passes both flags
      fs.writeFileSync(sharedFile, JSON.stringify({ defaultMode: 'bypassPermissions' }), 'utf8');
      const rec1 = makeFakeSpawnRecorder();
      const runner = new TheoDirectRunner({
        resolveClaudeBin: () => 'claude-fake-bin',
        spawnImpl: rec1.spawnImpl,
        permissionOptions: { homeDir: tmpHome, memoryRoot: tmpMemRoot }
      });
      const run1 = await runner.startPromptRun({
        prompt: 'hello from phone',
        provider: 'claude',
        newSession: true,
        cwd: tmpPermDir,
        mode: ''
      });
      assert.strictEqual(run1.ok, true);
      assert.strictEqual(rec1.calls.length, 1);
      assert.ok(rec1.calls[0].args.includes('--permission-mode=bypassPermissions'));
      assert.ok(rec1.calls[0].args.includes('--allow-dangerously-skip-permissions'));

      // 2. Explicit mode: 'plan' overrides shared bypassPermissions and omits --allow-dangerously-skip-permissions
      const runPlan = await runner.startPromptRun({
        prompt: 'plan only',
        provider: 'claude',
        newSession: true,
        cwd: tmpPermDir,
        mode: 'plan'
      });
      assert.strictEqual(runPlan.ok, true);
      assert.ok(rec1.calls[1].args.includes('--permission-mode=plan'));
      assert.ok(!rec1.calls[1].args.includes('--allow-dangerously-skip-permissions'));

      // 3. Corrupt shared file fails closed to 'auto' even if ~/.claude/settings.json has bypassPermissions
      fs.writeFileSync(
        claudeSettingsFile,
        JSON.stringify({ permissions: { defaultMode: 'bypassPermissions' } }),
        'utf8'
      );
      fs.writeFileSync(sharedFile, '{corrupt json', 'utf8');
      const permCorrupt = resolveEffectiveClaudeCliPermission('', {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      assert.deepStrictEqual(
        [permCorrupt.mode, permCorrupt.allowDangerouslySkipPermissions],
        ['auto', false],
        'corrupt shared mode file must fail closed to auto'
      );

      // 4. Missing shared file falls back to ~/.claude/settings.json
      fs.unlinkSync(sharedFile);
      const permFallback = resolveEffectiveClaudeCliPermission('', {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      assert.deepStrictEqual(
        [permFallback.mode, permFallback.allowDangerouslySkipPermissions],
        ['bypassPermissions', true]
      );

      // 5. Shared file 'auto' -> omits --allow-dangerously-skip-permissions
      fs.writeFileSync(sharedFile, JSON.stringify({ defaultMode: 'auto' }), 'utf8');
      const runAuto = await runner.startPromptRun({
        prompt: 'auto run',
        provider: 'claude',
        newSession: true,
        cwd: tmpPermDir,
        mode: ''
      });
      assert.strictEqual(runAuto.ok, true);
      assert.ok(rec1.calls[2].args.includes('--permission-mode=auto'));
      assert.ok(!rec1.calls[2].args.includes('--allow-dangerously-skip-permissions'));

      // 6. Live sync of already-open Claude chats via claude-hub-bridge.cjs
      fs.writeFileSync(sharedFile, JSON.stringify({ defaultMode: 'bypassPermissions' }), 'utf8');
      const globalCfg = new Map([
        ['allowDangerouslySkipPermissions', false],
        ['initialPermissionMode', undefined]
      ]);
      let defaultPermInGlobalState = 'auto';
      const fakeVscode = {
        ConfigurationTarget: { Global: 1 },
        ViewColumn: { One: 1, Beside: 2 },
        window: {},
        commands: {
          registerCommand: () => ({ dispose() {} }),
          executeCommand: async () => undefined
        },
        workspace: {
          getConfiguration: (section) => {
            assert.strictEqual(section, 'claudeCode');
            return {
              inspect: (k) => ({ globalValue: globalCfg.get(k) }),
              update: async (k, v) => {
                if (v === undefined) globalCfg.delete(k);
                else globalCfg.set(k, v);
              }
            };
          }
        }
      };
      const modeStoreMap = new Map([
        ['sess-open-auto', { mode: 'auto' }],
        ['sess-open-plan', { mode: 'plan' }]
      ]);
      const setPermCalls = [];
      const sentPayloads = [];
      const postedWebviewMsgs = [];
      const transportedMsgs = [];
      let loadConfigCount = 0;
      const fakePanel = {
        title: 'Terminal permission prompts',
        webview: { postMessage: (m) => postedWebviewMsgs.push(m) }
      };
      const fakeComms = {
        channels: new Map([
          ['ch-auto', { sessionId: 'sess-open-auto', query: { transport: { options: { permissionMode: 'auto' } } } }],
          ['ch-plan', { sessionId: 'sess-open-plan', query: { transport: { options: { permissionMode: 'plan' } } } }],
          ['ch-pending', { sessionId: 'sess-pending', query: { transport: { options: { permissionMode: 'default' } } } }]
        ]),
        settings: {
          getAllowDangerouslySkipPermissions: () => Boolean(globalCfg.get('allowDangerouslySkipPermissions'))
        },
        loadConfig: async () => {
          loadConfigCount += 1;
        },
        pushStateUpdate: async () => {},
        setPermissionMode: async (chId, mode, userInitiated) => {
          // Enforce same gate as real extension: bypass requires allowDangerouslySkipPermissions === true
          if (mode === 'bypassPermissions' && !globalCfg.get('allowDangerouslySkipPermissions')) {
            return { type: 'set_permission_mode_response', success: false };
          }
          setPermCalls.push({ chId, mode, userInitiated });
          return { type: 'set_permission_mode_response', success: true };
        },
        send: (payload) => {
          sentPayloads.push(payload);
        },
        transportMessage: async (chId, msg) => {
          transportedMsgs.push({ chId, msg });
        },
        launchClaude: async (chId, sid, cwd, permMode) => ({ chId, sid, cwd, permMode })
      };
      const fakeState = {
        attached: true,
        vscode: fakeVscode,
        context: { subscriptions: [] },
        badgeById: new Map(),
        hookedPanels: new WeakSet(),
        pendingPermissions: new Map([
          ['perm-1', { sessionId: 'sess-pending', channelId: 'ch-pending', comms: fakeComms }]
        ]),
        hookedComms: new WeakSet(),
        controller: {
          allComms: new Set([fakeComms]),
          panelComms: new Map([[fakePanel, fakeComms]]),
          sessionPanels: new Map([['sess-open-auto', fakePanel]]),
          createPanel: async (sid, initialPrompt) => {
            const newSid = sid || 'sess-ide-created';
            const createdPanel = {
              title: initialPrompt || 'Claude Code',
              webview: { postMessage: () => {} },
              onDidDispose: () => ({ dispose() {} }),
              onDidChangeViewState: () => ({ dispose() {} })
            };
            const createdComms = {
              channels: new Map(),
              settings: fakeComms.settings,
              loadConfig: async () => {},
              pushStateUpdate: async () => {},
              setPermissionMode: fakeComms.setPermissionMode,
              send: fakeComms.send,
              launchClaude: async (chId, launchSid, cwd, permMode) => ({
                chId,
                sid: launchSid,
                cwd,
                permMode
              })
            };
            fakeState.controller.allComms.add(createdComms);
            fakeState.controller.panelComms.set(createdPanel, createdComms);
            fakeState.controller.sessionPanels.set(newSid, createdPanel);
            return { createdPanel };
          },
          settings: {
            getInitialPermissionMode: () => globalCfg.get('initialPermissionMode') || defaultPermInGlobalState,
            setPermissionMode: async (m) => {
              defaultPermInGlobalState = m;
            },
            sessionModeStore: {
              ids: () => [...modeStoreMap.keys()],
              get: (sid) => modeStoreMap.get(sid)
            },
            clearSessionPermissionMode: async (sid) => {
              modeStoreMap.delete(sid);
            }
          }
        }
      };
      claudeBridge.ensurePermissionSyncSupport(fakeState);

      const sync1 = await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      assert.strictEqual(sync1.ok, true);
      assert.deepStrictEqual(sync1.switchedChannels, ['ch-auto'], 'switches open auto channel, skips plan & pending');
      assert.strictEqual(sync1.deferredPending, true, 'defers channel with active permission dialog');
      assert.strictEqual(globalCfg.get('allowDangerouslySkipPermissions'), true);
      assert.strictEqual(globalCfg.get('initialPermissionMode'), 'bypassPermissions');
      assert.ok(loadConfigCount >= 1, 'refreshes comms config before switching to bypassPermissions');
      assert.strictEqual(modeStoreMap.has('sess-open-auto'), false, 'clears stale auto mode in sessionModeStore');
      assert.strictEqual(modeStoreMap.get('sess-open-plan')?.mode, 'plan', 'keeps plan mode in sessionModeStore');
      assert.ok(
        sentPayloads.some(
          (p) =>
            p.type === 'io_message' &&
            p.channelId === 'ch-auto' &&
            p.message?.subtype === 'status' &&
            p.message?.permissionMode === 'bypassPermissions'
        ),
        'pushes live status io_message so open tab mode picker updates without reload'
      );
      assert.ok(
        postedWebviewMsgs.some((m) => m.type === 'bhf_shared_permission_mode' && m.mode === 'bypassPermissions')
      );

      // Once pending permission clears, next sync switches ch-pending and settles
      fakeState.pendingPermissions.clear();
      const sync2 = await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      assert.deepStrictEqual(sync2.switchedChannels, ['ch-pending']);
      assert.strictEqual(sync2.deferredPending, false);

      // Subsequent poll with unchanged shared file is a pure no-op
      const syncNoop = await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      assert.strictEqual(syncNoop.noop, true);

      // User manually switches ch-auto to 'acceptEdits' in the mode picker -> respected while shared mode stays bypassPermissions
      await fakeComms.setPermissionMode('ch-auto', 'acceptEdits', true);
      const syncAfterManual = await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot,
        force: true
      });
      assert.ok(
        !syncAfterManual.switchedChannels.includes('ch-auto'),
        'user manual picker choice is not overwritten under same shared mode'
      );

      // Resuming an idle session via launchClaude upgrades stale 'auto' to 'bypassPermissions', while a new draft tab preserves user choice
      const resumedLaunch = await fakeComms.launchClaude('ch-idle-resumed', 'sess-old-idle', tmpPermDir, 'auto');
      assert.strictEqual(resumedLaunch.permMode, 'bypassPermissions');
      const draftUserChoice = await fakeComms.launchClaude('ch-new-draft', undefined, tmpPermDir, 'acceptEdits');
      assert.strictEqual(draftUserChoice.permMode, 'acceptEdits');

      // Flipping shared mode to 'auto' switches open bypass & manual channels to 'auto' (still preserving 'plan') and closes bypass gate
      fs.writeFileSync(sharedFile, JSON.stringify({ defaultMode: 'auto' }), 'utf8');
      const syncBackAuto = await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      assert.strictEqual(syncBackAuto.ok, true);
      assert.deepStrictEqual(syncBackAuto.switchedChannels.sort(), ['ch-auto', 'ch-pending']);
      assert.strictEqual(globalCfg.get('allowDangerouslySkipPermissions'), false);
      assert.strictEqual(globalCfg.get('initialPermissionMode'), undefined);
      assert.strictEqual(defaultPermInGlobalState, 'auto');

      // 7. Red-Team #5.1: getBridgePatchDigest includes CLAUDE_CTX_UI_RUNTIME_JS & stale webview/index.js re-patches
      const bridgeInstaller = require(path.join(ROOT, 'bridge.js'));
      const webviewPatches = require(path.join(ROOT, 'compat', 'claude-webview-patches.cjs'));
      assert.notStrictEqual(
        bridgeInstaller.getBridgePatchDigest({ claudeCtxUiRuntimeJs: '// modified runtime' }),
        bridgeInstaller.getBridgePatchDigest(),
        'getBridgePatchDigest must change whenever CLAUDE_CTX_UI_RUNTIME_JS changes'
      );
      const fakeClaudeExtDir = path.join(tmpPermDir, 'anthropic.claude-code-2.1.322-win32-x64');
      fs.mkdirSync(path.join(fakeClaudeExtDir, 'webview'), { recursive: true });
      const stockClaudeExtSrc =
        'function act(c,v,ctrl){c.subscriptions.push(v.window.registerWebviewViewProvider("claudeVSCodeSessionsList",{resolveWebviewView(w,x,y){ctrl.resolveSessionListView(w,x,y)}}))}';
      const stockClaudeWebviewSrc = [
        'class Sess{updateUsage(u){let s=u.input_tokens+u.output_tokens;return s}}',
        'function CwBtn({usedTokens:a,contextWindow:b,onCompact:c,buttonClassName:d}){return null}',
        'let callObj={usedTokens:sess.usageData.value.totalTokens,contextWindow:fn(sess.usageData.value.contextWindow,sess.usageData.value.maxOutputTokens),onCompact:doCompact,buttonClassName:styles.usageButtonV2};',
        'let dlg={openContextDialog:()=>setDlg(!0)};'
      ].join('\n');
      const stalePatchedWebviewSrc = stockClaudeWebviewSrc + '\n/*bhf-context-window*/\n/*bhf-context-window-start*/\n;(function(){window.__oldRuntime=1;})();\n/*bhf-context-window-end*/\n';
      const extJsPath = path.join(fakeClaudeExtDir, 'extension.js');
      const wvJsPath = path.join(fakeClaudeExtDir, 'webview', 'index.js');
      const pkgJsonPath = path.join(fakeClaudeExtDir, 'package.json');
      fs.writeFileSync(`${extJsPath}.orig`, stockClaudeExtSrc, 'utf8');
      fs.writeFileSync(extJsPath, bridgeInstaller.patchClaudeExtensionSource(stockClaudeExtSrc), 'utf8');
      fs.writeFileSync(`${wvJsPath}.orig`, stockClaudeWebviewSrc, 'utf8');
      fs.writeFileSync(wvJsPath, stalePatchedWebviewSrc, 'utf8');
      fs.writeFileSync(pkgJsonPath, JSON.stringify({ name: 'claude-code', activationEvents: [] }), 'utf8');
      const bStat = fs.statSync(extJsPath);
      const wStat = fs.statSync(wvJsPath);
      const pStat = fs.statSync(pkgJsonPath);
      fs.writeFileSync(
        path.join(fakeClaudeExtDir, '.theo-bridge-stamp.json'),
        JSON.stringify({
          stampVersion: bridgeInstaller.BRIDGE_STAMP_VERSION,
          bridgePatchDigest: '0000000000000000',
          bundleMtimeMs: Math.floor(bStat.mtimeMs),
          bundleSize: bStat.size,
          webviewMtimeMs: Math.floor(wStat.mtimeMs),
          webviewSize: wStat.size,
          pkgMtimeMs: Math.floor(pStat.mtimeMs),
          pkgSize: pStat.size
        }),
        'utf8'
      );
      const upgradeRes = bridgeInstaller.ensureClaudeBridgeInstalledForExtensionDir(fakeClaudeExtDir, ROOT);
      assert.strictEqual(upgradeRes.installed, true);
      assert.strictEqual(upgradeRes.webviewUpdated, true, 'stale bridgePatchDigest must force webview/index.js re-patch');
      const upgradedWebviewText = fs.readFileSync(wvJsPath, 'utf8');
      assert.ok(upgradedWebviewText.includes('bhf_shared_permission_mode'));
      assert.ok(upgradedWebviewText.includes('syncIdleSessionPermMode'));
      assert.ok(!upgradedWebviewText.includes('__oldRuntime'));
      // Also verify in-place replacement when .orig is absent
      const repatchedNoOrig = webviewPatches.patchClaudeWebviewSource(stalePatchedWebviewSrc);
      assert.ok(repatchedNoOrig.includes('bhf_shared_permission_mode'));
      assert.ok(!repatchedNoOrig.includes('__oldRuntime'));

      // 8. Red-Team #5.2: Post-attach idle panel + sidebar comms.webview + non-bypass syncIdleSessionPermMode
      const idlePanelMsgs = [];
      const sidebarMsgs = [];
      const postAttachIdlePanel = {
        title: 'Idle Restored Tab',
        webview: { postMessage: (m) => idlePanelMsgs.push(m) }
      };
      const postAttachIdleComms = {
        channels: new Map(),
        settings: fakeComms.settings,
        loadConfig: async () => {},
        pushStateUpdate: async () => {},
        send: () => {}
      };
      const sidebarComms = {
        channels: new Map(),
        webview: { postMessage: (m) => sidebarMsgs.push(m) },
        settings: fakeComms.settings,
        loadConfig: async () => {},
        pushStateUpdate: async () => {},
        send: () => {}
      };
      fakeState.controller.panelComms.set(postAttachIdlePanel, postAttachIdleComms);
      fakeState.controller.allComms.add(postAttachIdleComms);
      fakeState.controller.allComms.add(sidebarComms);
      const syncUnsyncedViews = await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      assert.notStrictEqual(syncUnsyncedViews.noop, true, 'unsynced webviews must not hit early noop return');
      assert.ok(
        idlePanelMsgs.some((m) => m.type === 'bhf_shared_permission_mode' && m.mode === 'auto'),
        'post-attach idle editor panel receives bhf_shared_permission_mode'
      );
      assert.ok(
        sidebarMsgs.some((m) => m.type === 'bhf_shared_permission_mode' && m.mode === 'auto'),
        'sidebar comms.webview receives bhf_shared_permission_mode'
      );

      // Execute CLAUDE_CTX_UI_RUNTIME_JS in a minimal VM DOM stub to verify idle session picker updates
      const vmMsgListeners = [];
      const vmWindow = {
        innerWidth: 1024,
        innerHeight: 768,
        addEventListener: (ev, fn) => {
          if (ev === 'message') vmMsgListeners.push(fn);
        }
      };
      const vmDoc = {
        readyState: 'complete',
        head: { appendChild() {} },
        body: {},
        getElementById: () => null,
        createElement: () => ({
          style: {},
          setAttribute() {},
          appendChild() {},
          addEventListener() {}
        }),
        querySelector: () => null,
        querySelectorAll: () => [],
        addEventListener() {}
      };
      vm.runInNewContext(
        webviewPatches.CLAUDE_CTX_UI_RUNTIME_JS,
        {
          window: vmWindow,
          document: vmDoc,
          MutationObserver: class {
            observe() {}
            disconnect() {}
          },
          Node: class {},
          queueMicrotask: (fn) => fn(),
          setInterval: () => ({ unref() {} }),
          clearInterval: () => {},
          setTimeout: () => 0,
          clearTimeout: () => {},
          WeakMap,
          Map,
          Set,
          Math,
          Number,
          String,
          Boolean,
          Array,
          Object,
          Date,
          JSON
        },
        { filename: 'claude-ctx-runtime-test.js' }
      );
      const vmIdleSess = {
        claudeChannelId: undefined,
        permissionMode: { value: 'default' },
        connection: {
          value: {
            config: {
              value: {
                allowDangerouslySkipPermissions: false,
                initialPermissionMode: '',
                claudeSettings: { effective: { permissions: { defaultMode: 'acceptEdits' } } }
              }
            }
          }
        },
        setPermissionMode(mode) {
          this.permissionMode.value = mode;
        }
      };
      vmWindow.__bhfTrackClaudeSession(vmIdleSess, null, 0, 200000);
      assert.strictEqual(
        vmIdleSess.permissionMode.value,
        'acceptEdits',
        'idle session falls back to claudeSettings.effective.permissions.defaultMode before postMessage arrives'
      );
      for (const fn of vmMsgListeners) fn({ data: { type: 'bhf_shared_permission_mode', mode: 'auto' } });
      assert.strictEqual(vmIdleSess.permissionMode.value, 'auto');
      for (const fn of vmMsgListeners) fn({ data: { type: 'bhf_shared_permission_mode', mode: 'plan' } });
      assert.strictEqual(vmIdleSess.permissionMode.value, 'plan');
      for (const fn of vmMsgListeners) fn({ data: { type: 'bhf_shared_permission_mode', mode: 'auto' } });
      assert.strictEqual(
        vmIdleSess.permissionMode.value,
        'auto',
        'idle session synced into plan by shared mode switches back when shared mode leaves plan'
      );
      // Organic/manual plan choice on an idle session is preserved when shared mode changes
      vmIdleSess.setPermissionMode('plan', false, true);
      for (const fn of vmMsgListeners) fn({ data: { type: 'bhf_shared_permission_mode', mode: 'acceptEdits' } });
      assert.strictEqual(
        vmIdleSess.permissionMode.value,
        'plan',
        'idle session organically/manually in plan mode stays in plan'
      );
      vmIdleSess.setPermissionMode('auto', false, true);
      vmIdleSess.connection.value.config.value.allowDangerouslySkipPermissions = true;
      for (const fn of vmMsgListeners) {
        fn({ data: { type: 'bhf_shared_permission_mode', mode: 'bypassPermissions' } });
      }
      assert.strictEqual(vmIdleSess.permissionMode.value, 'bypassPermissions');

      // 9. Red-Team Round 2 #2/#3/#4: Shared 'plan' -> 'auto' transition, seeded draft manual override vs unseeded draft, and headless cache eviction
      globalCfg.set('initialPermissionMode', 'auto');
      fs.writeFileSync(sharedFile, JSON.stringify({ defaultMode: 'plan' }), 'utf8');
      const [syncPlanA, syncPlanB] = await Promise.all([
        claudeBridge.syncSharedClaudePermissionMode(fakeState, {
          homeDir: tmpHome,
          memoryRoot: tmpMemRoot
        }),
        claudeBridge.syncSharedClaudePermissionMode(fakeState, {
          homeDir: tmpHome,
          memoryRoot: tmpMemRoot,
          force: true
        })
      ]);
      assert.strictEqual(syncPlanA.ok, true);
      assert.strictEqual(syncPlanB.mode, 'plan', 'concurrent sync calls serialize cleanly');
      assert.strictEqual(
        globalCfg.get('initialPermissionMode'),
        undefined,
        'non-bypass initialPermissionMode is cleared from VS Code config'
      );
      assert.strictEqual(
        defaultPermInGlobalState,
        undefined,
        'globalState defaultPermissionMode is cleared when shared mode is plan'
      );
      assert.strictEqual(fakeComms.__bhfChannelModes.get('ch-auto'), 'plan');
      assert.strictEqual(fakeComms.__bhfSharedPlanChannels.has('ch-auto'), true);
      assert.strictEqual(
        fakeComms.__bhfSharedPlanChannels.has('ch-plan'),
        false,
        'organically-plan channel is not marked as shared-synced plan'
      );

      // Seeded draft tab (fakePanel.webview.__bhfAppliedSharedPermMode === 'plan') where user picked 'auto' preserves 'auto'
      assert.strictEqual(fakePanel.webview.__bhfAppliedSharedPermMode, 'plan');
      const manualOnSeededPlanDraft = await fakeComms.launchClaude(
        'ch-plan-manual-draft',
        undefined,
        tmpPermDir,
        'auto'
      );
      assert.strictEqual(
        manualOnSeededPlanDraft.permMode,
        'auto',
        'manual picker choice on a seeded draft tab under shared plan is preserved'
      );
      assert.strictEqual(
        fakeComms.__bhfUserChosenChannelModes.get('ch-plan-manual-draft')?.mode,
        'auto'
      );

      // Unseeded draft panel whose webview has not yet received bhf_shared_permission_mode upgrades stale 'auto' to 'plan'
      const unseededPanel = { title: 'Unseeded Draft', webview: { postMessage: () => {} } };
      const unseededComms = {
        channels: new Map(),
        settings: fakeComms.settings,
        loadConfig: async () => {},
        pushStateUpdate: async () => {},
        setPermissionMode: fakeComms.setPermissionMode,
        send: fakeComms.send,
        launchClaude: async (chId, sid, cwd, permMode) => ({ chId, sid, cwd, permMode })
      };
      fakeState.controller.panelComms.set(unseededPanel, unseededComms);
      fakeState.controller.allComms.add(unseededComms);
      // Hook unseededComms via sync, then simulate an unseeded webview before launchClaude
      await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      delete unseededPanel.webview.__bhfAppliedSharedPermMode;
      const unseededPlanLaunch = await unseededComms.launchClaude(
        'ch-plan-unseeded',
        undefined,
        tmpPermDir,
        'auto'
      );
      assert.strictEqual(
        unseededPlanLaunch.permMode,
        'plan',
        'unseeded draft tab upgrades stale auto to plan when shared mode is plan'
      );
      assert.strictEqual(unseededComms.__bhfUserChosenChannelModes.has('ch-plan-unseeded'), false);

      // Transition shared mode from 'plan' -> 'auto': shared-synced channels ('ch-auto', 'ch-pending') return to 'auto',
      // while organic 'ch-plan' stays in 'plan'!
      fs.writeFileSync(sharedFile, JSON.stringify({ defaultMode: 'auto' }), 'utf8');
      const syncLeavePlan = await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot
      });
      assert.strictEqual(syncLeavePlan.ok, true);
      assert.ok(syncLeavePlan.switchedChannels.includes('ch-auto'), 'ch-auto exits shared plan back to auto');
      assert.ok(syncLeavePlan.switchedChannels.includes('ch-pending'), 'ch-pending exits shared plan back to auto');
      assert.ok(!syncLeavePlan.switchedChannels.includes('ch-plan'), 'organic ch-plan stays in plan');
      assert.strictEqual(fakeComms.__bhfChannelModes.get('ch-auto'), 'auto');
      assert.strictEqual(modeStoreMap.get('sess-open-plan')?.mode, 'plan');

      // Headless bundle-updater cache eviction: mutating compat/claude-webview-patches.cjs in a temp hub dir updates digest
      const bundleUpdater = require(path.join(ROOT, 'bundle-updater.js'));
      const tmpHubCopyDir = path.join(tmpPermDir, 'hub-copy');
      fs.mkdirSync(path.join(tmpHubCopyDir, 'compat'), { recursive: true });
      fs.copyFileSync(path.join(ROOT, 'bridge.js'), path.join(tmpHubCopyDir, 'bridge.js'));
      const tmpPatchesPath = path.join(tmpHubCopyDir, 'compat', 'claude-webview-patches.cjs');
      fs.copyFileSync(path.join(ROOT, 'compat', 'claude-webview-patches.cjs'), tmpPatchesPath);
      const firstPrepatch = bundleUpdater.runHeadlessBridgePrepatch(tmpHubCopyDir, []);
      assert.strictEqual(firstPrepatch.ok, true);
      const mutatedPatchesSrc = fs
        .readFileSync(tmpPatchesPath, 'utf8')
        .replace('/*bhf-context-window-end*/', '/*bhf-mutated-test*/\n/*bhf-context-window-end*/');
      fs.writeFileSync(tmpPatchesPath, mutatedPatchesSrc, 'utf8');
      const secondPrepatch = bundleUpdater.runHeadlessBridgePrepatch(tmpHubCopyDir, []);
      assert.strictEqual(secondPrepatch.ok, true);
      assert.notStrictEqual(
        secondPrepatch.bridgePatchDigest,
        firstPrepatch.bridgePatchDigest,
        'runHeadlessBridgePrepatch must evict compat/claude-webview-patches.cjs before requiring bridge.js'
      );

      // IDE-mode phone prompt (sendPromptToClaude): new session + no cross-panel leak + existing open session explicit mode
      fs.writeFileSync(sharedFile, JSON.stringify({ defaultMode: 'bypassPermissions' }), 'utf8');
      const ideNewRes = await claudeBridge.sendPromptToClaude({
        state: fakeState,
        newSession: true,
        prompt: 'phone ide new chat',
        mode: 'plan'
      });
      assert.strictEqual(ideNewRes.sent, true);
      assert.strictEqual(ideNewRes.id, 'sess-ide-created');
      assert.strictEqual(
        fakeState.__bhfPendingIdeLaunchMode,
        null,
        'sendPromptToClaude clears state.__bhfPendingIdeLaunchMode immediately once panel override is attached'
      );
      // Unrelated desktop tabs launching right afterwards are NOT hijacked into 'plan'
      const unrelatedDraftLaunch = await unseededComms.launchClaude(
        'ch-unrelated-draft',
        undefined,
        tmpPermDir,
        'auto'
      );
      assert.strictEqual(unrelatedDraftLaunch.permMode, 'auto');
      const unrelatedResumedLaunch = await unseededComms.launchClaude(
        'ch-unrelated-resumed',
        'sess-unrelated-idle',
        tmpPermDir,
        'auto'
      );
      assert.strictEqual(unrelatedResumedLaunch.permMode, 'bypassPermissions');

      const createdIdePanel = fakeState.controller.sessionPanels.get('sess-ide-created');
      const createdIdeComms = fakeState.controller.panelComms.get(createdIdePanel);
      assert.strictEqual(createdIdePanel.__bhfLaunchModeOverride?.mode, 'plan');
      await claudeBridge.syncSharedClaudePermissionMode(fakeState, {
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot,
        force: true
      });
      const ideLaunchRes = await createdIdeComms.launchClaude(
        'ch-ide-created',
        undefined,
        tmpPermDir,
        'auto'
      );
      assert.strictEqual(ideLaunchRes.permMode, 'plan');

      const ideExistingRes = await claudeBridge.sendPromptToClaude({
        state: fakeState,
        id: 'sess-open-auto',
        prompt: 'phone ide follow-up in acceptEdits',
        mode: 'acceptEdits'
      });
      assert.strictEqual(ideExistingRes.sent, true);
      assert.strictEqual(ideExistingRes.method, 'transportMessage');
      assert.strictEqual(fakeComms.__bhfChannelModes.get('ch-auto'), 'acceptEdits');
      assert.strictEqual(transportedMsgs.length, 1);
    } finally {
      fs.rmSync(tmpPermDir, { recursive: true, force: true });
    }
    console.log('[PASS] Adversarial #13: Shared Claude permission mode for phone runs & already-open chats verified');
  }

  // 15. Adversarial Check #14: Background idle memory-git sync in relay_keepalive.cjs (10m quiet, deletions, offline ahead recovery, mid-push edit race, private-note & ignore hygiene)
  {
    const keepaliveLib = require(path.join(ROOT, 'scripts', 'relay_keepalive.cjs'));
    assert.strictEqual(keepaliveLib.MEMORY_GIT_IDLE_QUIET_MS, 10 * 60 * 1000);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('.git', '.git', false), true);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('_archive', '_archive', true), true);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('Admin/run.log', 'run.log', false), true);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('Admin/out.csv', 'out.csv', false), true);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('Admin/theo-hub-bundle.zip', 'theo-hub-bundle.zip', false), true);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('THEO.md.bak_1', 'THEO.md.bak_1', false), true);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('memory.bak_dir', 'memory.bak_dir', true), true);
    assert.strictEqual(
      keepaliveLib.isIgnoredMemoryGitEntry('memory/bank-kyc-ali-bdeir.md', 'bank-kyc-ali-bdeir.md', false),
      true
    );
    assert.strictEqual(
      keepaliveLib.isIgnoredMemoryGitEntry(
        'memory/user-passports-antigua-lebanon.md',
        'user-passports-antigua-lebanon.md',
        false
      ),
      true
    );
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('THEO.md', 'THEO.md', false), false);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('Set Up This PC.cmd', 'Set Up This PC.cmd', false), false);
    assert.strictEqual(keepaliveLib.isIgnoredMemoryGitEntry('Admin/theo-pc-setup.py', 'theo-pc-setup.py', false), false);

    const tmpIdleDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-memgit-idle-'));
    try {
      const tmpHome = path.join(tmpIdleDir, 'home');
      const tmpMemRoot = path.join(tmpHome, 'OneDrive - BHFIRMS', 'System', 'System', 'THEO');
      const tmpGitDir = path.join(tmpHome, '.gitdirs', 'claude-memory');
      const tmpRemoteDir = path.join(tmpIdleDir, 'remote.git');
      const tmpStateFile = path.join(tmpHome, '.claude', '.theo-memory-git-idle.json');
      fs.mkdirSync(path.join(tmpMemRoot, 'Admin'), { recursive: true });
      fs.mkdirSync(path.join(tmpMemRoot, 'memory'), { recursive: true });
      fs.mkdirSync(path.join(tmpHome, '.claude'), { recursive: true });

      const liveMemRoot = fs.existsSync(path.join(os.homedir(), 'bhfirms', 'memory', 'THEO.md'))
        ? path.join(os.homedir(), 'bhfirms', 'memory')
        : path.join(os.homedir(), 'OneDrive - BHFIRMS', 'System', 'System', 'THEO');
      const liveMemGit = path.join(liveMemRoot, 'Admin', 'bhfirms-memory-git.py');
      const liveGitIgnore = path.join(liveMemRoot, '.gitignore');
      const pyExe = keepaliveLib.findLocalConsolePythonExe(os.homedir());
      const gitCheck = spawnSync('git', ['--version'], { windowsHide: true, encoding: 'utf8' });
      assert.ok(pyExe, 'Expected local Python executable for memory-git idle smoke test');
      assert.strictEqual(gitCheck.status, 0, 'Expected git CLI for memory-git idle smoke test');

      if (fs.existsSync(liveGitIgnore)) {
        fs.copyFileSync(liveGitIgnore, path.join(tmpMemRoot, '.gitignore'));
      } else {
        fs.writeFileSync(
          path.join(tmpMemRoot, '.gitignore'),
          '.claude/\n.vscode/\n.wrangler/\n_archive/\n*.bak*\ntmp/\nscratchpad/\noutput/\n__pycache__/\nAdmin/*.csv\nAdmin/*.log\n*bank-kyc-ali-bdeir*\n*user-passports-antigua-lebanon*\n*.zip\n*.pdf\n*.html\n',
          'utf8'
        );
      }
      assert.ok(fs.existsSync(liveMemGit), 'Expected Admin/bhfirms-memory-git.py on disk');
      fs.copyFileSync(liveMemGit, path.join(tmpMemRoot, 'Admin', 'bhfirms-memory-git.py'));

      const baseMs = 1_800_000_000_000;
      const setFileTime = (p, ms) => {
        const d = new Date(ms);
        fs.utimesSync(p, d, d);
      };

      const theoMd = path.join(tmpMemRoot, 'THEO.md');
      const noteMd = path.join(tmpMemRoot, 'memory', 'notes.md');
      const privMd = path.join(tmpMemRoot, 'memory', 'bank-kyc-ali-bdeir.md');
      fs.writeFileSync(theoMd, '# THEO Index\r\n', 'utf8');
      fs.writeFileSync(noteMd, 'initial note\r\n', 'utf8');
      fs.writeFileSync(privMd, 'TOP SECRET PRIVATE KYC DATA\r\n', 'utf8');
      setFileTime(theoMd, baseMs - 3600_000);
      setFileTime(noteMd, baseMs - 3600_000);
      setFileTime(path.join(tmpMemRoot, '.gitignore'), baseMs - 3600_000);
      setFileTime(path.join(tmpMemRoot, 'Admin', 'bhfirms-memory-git.py'), baseMs - 3600_000);

      // Ignored & private files must never shift scanTrackedMemoryTree
      const scanBeforeIgnored = keepaliveLib.scanTrackedMemoryTree(tmpMemRoot);
      assert.strictEqual(scanBeforeIgnored.ok, true);
      fs.mkdirSync(path.join(tmpMemRoot, '_archive'), { recursive: true });
      fs.writeFileSync(path.join(tmpMemRoot, '_archive', 'archived.md'), 'ignored', 'utf8');
      fs.writeFileSync(path.join(tmpMemRoot, 'Admin', 'debug.log'), 'ignored', 'utf8');
      fs.writeFileSync(path.join(tmpMemRoot, 'Admin', 'theo-hub-bundle.zip'), 'ignored', 'utf8');
      fs.writeFileSync(path.join(tmpMemRoot, 'THEO.md.bak'), 'ignored', 'utf8');
      fs.mkdirSync(path.join(tmpMemRoot, 'memory.bak_2026'), { recursive: true });
      fs.writeFileSync(path.join(tmpMemRoot, 'memory.bak_2026', 'old.md'), 'ignored', 'utf8');
      fs.writeFileSync(privMd, 'UPDATED SECRET DATA\r\n', 'utf8');
      const scanAfterIgnored = keepaliveLib.scanTrackedMemoryTree(tmpMemRoot);
      assert.strictEqual(
        scanAfterIgnored.treeSig,
        scanBeforeIgnored.treeSig,
        'Ignored files and private notes must never perturb treeSig'
      );
      assert.strictEqual(
        scanAfterIgnored.latestFileMtimeMs,
        scanBeforeIgnored.latestFileMtimeMs,
        'Ignored files and private notes must never perturb latestFileMtimeMs'
      );

      // Init bare stand-in remote
      const initBare = spawnSync(
        'git',
        ['init', '--quiet', '--bare', '--initial-branch=main', tmpRemoteDir],
        { windowsHide: true, encoding: 'utf8' }
      );
      assert.strictEqual(initBare.status, 0, initBare.stderr);

      // Sandbox guard: refuses without THEO_MEMORY_REMOTE
      let fakeNow = baseMs;
      const unsafeCtrl = keepaliveLib.createMemoryGitIdleSyncController({
        allowInSmokeTest: true,
        nowFn: () => fakeNow,
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot,
        gitDir: tmpGitDir,
        stateFile: tmpStateFile,
        pythonExe: pyExe,
        bootDelayMs: 0,
        pollMs: 1000,
        env: {
          ...process.env,
          THEO_GUARD_HOME: tmpHome,
          THEO_MEMORY_REMOTE: ''
        }
      });
      assert.strictEqual(unsafeCtrl.maybeTick(fakeNow, { forcePoll: true }).action, 'sandbox-missing-remote');

      let currentRemote = tmpRemoteDir;
      const makeEnv = () => ({
        ...process.env,
        THEO_GUARD_HOME: tmpHome,
        THEO_MEMORY_ROOT: tmpMemRoot,
        THEO_MEMORY_GITDIR: tmpGitDir,
        THEO_MEMORY_REMOTE: currentRemote,
        COMPUTERNAME: 'TEST-HOST'
      });

      const logs = [];
      const ctrl = keepaliveLib.createMemoryGitIdleSyncController({
        allowInSmokeTest: true,
        nowFn: () => fakeNow,
        logFn: (m) => logs.push(m),
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot,
        gitDir: tmpGitDir,
        stateFile: tmpStateFile,
        pythonExe: pyExe,
        bootDelayMs: 0,
        pollMs: 1000,
        minSpawnGapMs: 5000,
        retryBackoffMs: [120_000, 300_000],
        get env() {
          return makeEnv();
        }
      });

      // Initial quiet seed (>10m old) -> spawns once, seeds remote, latches clean
      const seedRes = ctrl.maybeTick(fakeNow, { forcePoll: true });
      assert.strictEqual(seedRes.action, 'spawned');
      const seedDone = await ctrl.waitForInFlight();
      assert.strictEqual(seedDone.exitCode, 0);
      fakeNow += 60_000;
      assert.strictEqual(
        ctrl.maybeTick(fakeNow, { forcePoll: true }).action,
        'clean',
        'Subsequent ticks must fast-exit clean with zero spawns'
      );

      // Fresh controller restart reads persisted .theo-memory-git-idle.json and stays clean immediately
      const restartedCtrl = keepaliveLib.createMemoryGitIdleSyncController({
        allowInSmokeTest: true,
        nowFn: () => fakeNow,
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot,
        gitDir: tmpGitDir,
        stateFile: tmpStateFile,
        pythonExe: pyExe,
        bootDelayMs: 0,
        pollMs: 1000,
        env: makeEnv()
      });
      assert.strictEqual(
        restartedCtrl.maybeTick(fakeNow, { forcePoll: true }).action,
        'clean',
        'Restarted daemon must reuse persisted clean state without spawning Python'
      );

      // Packed-refs support: pack loose refs and verify readMemoryGitRefs & clean fast-path still hold
      const packRefs = spawnSync('git', [`--git-dir=${tmpGitDir}`, 'pack-refs', '--all', '--prune'], {
        windowsHide: true,
        encoding: 'utf8'
      });
      assert.strictEqual(packRefs.status, 0, packRefs.stderr);
      fakeNow += 60_000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'clean');

      // Active theo-sync.lock held by current live PID skips without spawning
      const lockFile = path.join(tmpGitDir, 'theo-sync.lock');
      fs.writeFileSync(lockFile, `${process.pid} 2026-11-11 10:00:00 1\n`, 'utf8');
      setFileTime(lockFile, fakeNow);
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'git-locked');
      fs.unlinkSync(lockFile);

      // Antigravity / hand edit: <10m quiet waits, >=10m quiet commits "Idle sync (TEST-HOST): ..." and pushes
      fakeNow += 60_000;
      fs.writeFileSync(noteMd, 'edited in antigravity\r\n', 'utf8');
      setFileTime(noteMd, fakeNow);
      fakeNow += 5 * 60 * 1000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'waiting-quiet');
      fakeNow += 5 * 60 * 1000 + 1000;
      const idleSpawn = ctrl.maybeTick(fakeNow, { forcePoll: true });
      assert.strictEqual(idleSpawn.action, 'spawned');
      assert.strictEqual(idleSpawn.trigger, 'idle');
      const idleDone = await ctrl.waitForInFlight();
      assert.strictEqual(idleDone.exitCode, 0);

      const remoteSubj = spawnSync(
        'git',
        [`--git-dir=${tmpRemoteDir}`, 'log', '-1', '--format=%s', 'main'],
        { windowsHide: true, encoding: 'utf8' }
      ).stdout.trim();
      assert.strictEqual(remoteSubj, 'Idle sync (TEST-HOST): memory/notes.md');

      // Deletion settle window: deleting a tracked file while remaining files are old still waits 10m from detection
      const extraMd = path.join(tmpMemRoot, 'memory', 'ephemeral.md');
      fakeNow += 60_000;
      fs.writeFileSync(extraMd, 'temporary tracked note\r\n', 'utf8');
      setFileTime(extraMd, fakeNow);
      fakeNow += 10 * 60 * 1000 + 1000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'spawned');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 0);
      fakeNow += 60_000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'clean');

      // Delete extraMd now; remaining files are all >10m old, yet deletion was just observed so it must wait 10m
      fakeNow += 60_000;
      fs.unlinkSync(extraMd);
      assert.strictEqual(
        ctrl.maybeTick(fakeNow, { forcePoll: true }).action,
        'waiting-quiet',
        'Tracked file deletion must start a fresh 10-minute quiet window'
      );
      // Fresh controller cold-boot right after deletion (when surviving files are >10m old) must ALSO wait 10m
      const coldAfterDelCtrl = keepaliveLib.createMemoryGitIdleSyncController({
        allowInSmokeTest: true,
        nowFn: () => fakeNow,
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot,
        gitDir: tmpGitDir,
        stateFile: tmpStateFile,
        pythonExe: pyExe,
        bootDelayMs: 0,
        pollMs: 1000,
        env: makeEnv()
      });
      assert.strictEqual(
        coldAfterDelCtrl.maybeTick(fakeNow, { forcePoll: true }).action,
        'waiting-quiet',
        'Fresh controller booted right after <10m deletion must not immediately commit using old surviving file mtimes'
      );
      fakeNow += 10 * 60 * 1000 + 1000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'spawned');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 0);
      const treeAfterDel = spawnSync(
        'git',
        [`--git-dir=${tmpRemoteDir}`, 'ls-tree', '-r', '--name-only', 'main'],
        { windowsHide: true, encoding: 'utf8' }
      ).stdout;
      assert.strictEqual(treeAfterDel.includes('memory/ephemeral.md'), false);

      // Transient reconnect while clean clears cloudRecoveredAt so 60s poll throttle stays intact
      fakeNow += 60_000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'clean');
      ctrl.noteCloudConnectivity(false, fakeNow + 100);
      assert.strictEqual(ctrl.noteCloudConnectivity(true, fakeNow + 200), true);
      assert.strictEqual(ctrl.maybeTick(fakeNow + 200).action, 'clean');
      assert.strictEqual(
        ctrl.maybeTick(fakeNow + 500).action,
        'throttled',
        'Post-recovery clean check must clear cloudRecoveredAt so pollMs throttle remains enforced'
      );
      fakeNow += 2_000;

      // Offline laptop -> local commit -> backoff while offline -> immediate push on Wi-Fi recovery (<10m!)
      currentRemote = path.join(tmpIdleDir, 'unreachable-remote.git');
      ctrl.noteCloudConnectivity(false, fakeNow);
      fakeNow += 60_000;
      fs.writeFileSync(noteMd, 'edited on airplane offline\r\n', 'utf8');
      setFileTime(noteMd, fakeNow);
      fakeNow += 10 * 60 * 1000 + 1000;
      const offSpawn = ctrl.maybeTick(fakeNow, { forcePoll: true });
      assert.strictEqual(offSpawn.action, 'spawned');
      const offDone = await ctrl.waitForInFlight();
      assert.strictEqual(offDone.exitCode, 2, 'Offline sync must commit locally and exit 2');

      const refsWhileOffline = keepaliveLib.readMemoryGitRefs(tmpGitDir, fakeNow);
      assert.notStrictEqual(
        refsWhileOffline.mainSha,
        refsWhileOffline.originMainSha,
        'Local main must be ahead of origin/main after offline commit'
      );

      // Next tick 35s later while still offline -> enters backoff instead of hammering git fetch
      fakeNow += 35_000;
      assert.strictEqual(
        ctrl.maybeTick(fakeNow, { forcePoll: true }).action,
        'backoff',
        'Still-offline laptop must back off instead of tight-looping'
      );

      // Wi-Fi reconnects! Cloud connectivity flips false -> true -> immediate push on `ahead` trigger
      currentRemote = tmpRemoteDir;
      fakeNow += 5_000;
      assert.strictEqual(ctrl.noteCloudConnectivity(true, fakeNow), true);
      const recovSpawn = ctrl.maybeTick(fakeNow);
      assert.strictEqual(recovSpawn.action, 'spawned');
      assert.strictEqual(recovSpawn.trigger, 'ahead');
      const recovDone = await ctrl.waitForInFlight();
      assert.strictEqual(recovDone.exitCode, 0);
      fakeNow += 60_000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'clean');
      const syncedBody = spawnSync(
        'git',
        [`--git-dir=${tmpRemoteDir}`, 'show', 'main:memory/notes.md'],
        { windowsHide: true, encoding: 'utf8' }
      ).stdout;
      assert.strictEqual(syncedBody, 'edited on airplane offline\r\n');

      // External Claude Code SessionEnd offline commit: <10m quiet still pushes IMMEDIATELY on Wi-Fi recovery,
      // unless a post-commit <10m file edit is mid-flight
      currentRemote = path.join(tmpIdleDir, 'unreachable-remote.git');
      ctrl.noteCloudConnectivity(false, fakeNow);
      fakeNow += 60_000;
      fs.writeFileSync(noteMd, 'session-end offline commit\r\n', 'utf8');
      setFileTime(noteMd, fakeNow);
      fakeNow += 2_000;
      const extSessionEnd = spawnSync(
        pyExe,
        ['-B', path.join(tmpMemRoot, 'Admin', 'bhfirms-memory-git.py'), '--auto'],
        { cwd: tmpHome, env: makeEnv(), windowsHide: true, encoding: 'utf8' }
      );
      assert.strictEqual(extSessionEnd.status, 2, extSessionEnd.stdout + extSessionEnd.stderr);
      setFileTime(path.join(tmpGitDir, 'refs', 'heads', 'main'), fakeNow);
      setFileTime(path.join(tmpGitDir, 'last-auto-sync.log'), fakeNow);

      // 30s later while STILL offline: recent-external-failure guard skips hammering git fetch
      fakeNow += 30_000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'recent-external-failure');

      // 30s later (<10m since edit!) Wi-Fi reconnects -> immediate `ahead` push without waiting 10m
      currentRemote = tmpRemoteDir;
      fakeNow += 30_000;
      assert.strictEqual(ctrl.noteCloudConnectivity(true, fakeNow), true);
      const extRecov = ctrl.maybeTick(fakeNow);
      assert.strictEqual(extRecov.action, 'spawned');
      assert.strictEqual(extRecov.trigger, 'ahead');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 0);
      assert.strictEqual(
        spawnSync('git', [`--git-dir=${tmpRemoteDir}`, 'show', 'main:memory/notes.md'], {
          windowsHide: true,
          encoding: 'utf8'
        }).stdout,
        'session-end offline commit\r\n'
      );

      // Post-commit <10m edit guard: if an offline commit exists AND user edits a file 10s later,
      // Wi-Fi recovery waits for the new edit's 10m quiet window instead of committing mid-sentence
      currentRemote = path.join(tmpIdleDir, 'unreachable-remote.git');
      ctrl.noteCloudConnectivity(false, fakeNow);
      fakeNow += 60_000;
      fs.writeFileSync(noteMd, 'offline commit v1\r\n', 'utf8');
      setFileTime(noteMd, fakeNow);
      fakeNow += 10 * 60 * 1000 + 1000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'spawned');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 2);
      // Now user starts typing a brand-new edit 10s after the offline commit
      fakeNow += 10_000;
      fs.writeFileSync(noteMd, 'offline commit v1 + fresh mid-sentence edit\r\n', 'utf8');
      setFileTime(noteMd, fakeNow);
      currentRemote = tmpRemoteDir;
      fakeNow += 15_000;
      ctrl.noteCloudConnectivity(true, fakeNow);
      assert.strictEqual(
        ctrl.maybeTick(fakeNow, { forcePoll: true }).action,
        'waiting-quiet',
        'Must not commit a 15-second-old post-commit edit upon Wi-Fi recovery'
      );
      fakeNow += 10 * 60 * 1000;
      const postEditSpawn = ctrl.maybeTick(fakeNow, { forcePoll: true });
      assert.strictEqual(postEditSpawn.action, 'spawned');
      assert.strictEqual(postEditSpawn.trigger, 'idle');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 0);

      // External offline commit (exit=2) + <10m tracked file deletion before next poll + Wi-Fi recovery -> must wait 10m
      const draftToDelete = path.join(tmpMemRoot, 'memory', 'draft-del.md');
      fakeNow += 60_000;
      fs.writeFileSync(draftToDelete, 'draft before offline deletion\r\n', 'utf8');
      setFileTime(draftToDelete, fakeNow);
      fakeNow += 10 * 60 * 1000 + 1000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'spawned');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 0);
      fakeNow += 60_000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'clean');

      currentRemote = path.join(tmpIdleDir, 'unreachable-remote.git');
      ctrl.noteCloudConnectivity(false, fakeNow);
      fakeNow += 5_000;
      fs.writeFileSync(noteMd, 'offline edit before draft deletion\r\n', 'utf8');
      setFileTime(noteMd, fakeNow);
      fakeNow += 5_000;
      const extBeforeDel = spawnSync(
        pyExe,
        ['-B', path.join(tmpMemRoot, 'Admin', 'bhfirms-memory-git.py'), '--auto'],
        { cwd: tmpHome, env: makeEnv(), windowsHide: true, encoding: 'utf8' }
      );
      assert.strictEqual(extBeforeDel.status, 2);
      setFileTime(path.join(tmpGitDir, 'refs', 'heads', 'main'), fakeNow);
      setFileTime(path.join(tmpGitDir, 'last-auto-sync.log'), fakeNow);
      // Delete draftToDelete 5s AFTER the external offline commit, BEFORE the next poll
      fakeNow += 5_000;
      fs.unlinkSync(draftToDelete);
      currentRemote = tmpRemoteDir;
      fakeNow += 5_000;
      assert.strictEqual(ctrl.noteCloudConnectivity(true, fakeNow), true);
      assert.strictEqual(
        ctrl.maybeTick(fakeNow).action,
        'waiting-quiet',
        '5-second-old deletion after external offline commit must not push immediately on Wi-Fi recovery'
      );
      fakeNow += 10 * 60 * 1000;
      const delAfterOffSpawn = ctrl.maybeTick(fakeNow, { forcePoll: true });
      assert.strictEqual(delAfterOffSpawn.action, 'spawned');
      assert.strictEqual(delAfterOffSpawn.trigger, 'idle');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 0);

      // Paused OneDrive (remote ahead, zero local edits): must enter `waiting-onedrive` and NOT loop git fetch
      fakeNow += 60_000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'clean');
      const peerCloneDir = path.join(tmpIdleDir, 'peer-clone');
      assert.strictEqual(
        spawnSync('git', ['clone', '--quiet', tmpRemoteDir, peerCloneDir], {
          windowsHide: true,
          encoding: 'utf8'
        }).status,
        0
      );
      const peerOnlyFile = path.join(peerCloneDir, 'memory', 'peer-only.md');
      fs.writeFileSync(peerOnlyFile, 'pushed from peer PC while OneDrive paused\r\n', 'utf8');
      assert.strictEqual(
        spawnSync('git', ['-C', peerCloneDir, 'add', 'memory/peer-only.md'], {
          windowsHide: true,
          encoding: 'utf8'
        }).status,
        0
      );
      assert.strictEqual(
        spawnSync(
          'git',
          [
            '-C',
            peerCloneDir,
            '-c',
            'user.name=Hussein Bdeir',
            '-c',
            'user.email=hbdeir16@gmail.com',
            'commit',
            '-q',
            '-m',
            'Peer commit'
          ],
          { windowsHide: true, encoding: 'utf8' }
        ).status,
        0
      );
      assert.strictEqual(
        spawnSync('git', ['-C', peerCloneDir, 'push', '--quiet', 'origin', 'main'], {
          windowsHide: true,
          encoding: 'utf8'
        }).status,
        0
      );
      // Fetch origin/main locally (simulating --status) while tmpMemRoot still lacks peer-only.md
      assert.strictEqual(
        spawnSync('git', [`--git-dir=${tmpGitDir}`, 'fetch', '--quiet', 'origin'], {
          windowsHide: true,
          encoding: 'utf8'
        }).status,
        0
      );
      fakeNow += 60_000;
      assert.strictEqual(
        ctrl.maybeTick(fakeNow, { forcePoll: true }).action,
        'waiting-onedrive',
        'Known-clean host behind origin/main with paused OneDrive must not treat behind as ahead'
      );
      // Even a brand-new controller with empty stateFile runs once (exit=0, own_edits==0) and then latches waiting-onedrive
      const staleStateFile = path.join(tmpHome, '.claude', '.theo-memory-git-idle-fresh.json');
      const staleCtrl = keepaliveLib.createMemoryGitIdleSyncController({
        allowInSmokeTest: true,
        nowFn: () => fakeNow,
        homeDir: tmpHome,
        memoryRoot: tmpMemRoot,
        gitDir: tmpGitDir,
        stateFile: staleStateFile,
        pythonExe: pyExe,
        bootDelayMs: 0,
        pollMs: 1000,
        retryBackoffMs: [120_000, 300_000],
        get env() {
          return makeEnv();
        }
      });
      const firstStaleTick = staleCtrl.maybeTick(fakeNow, { forcePoll: true });
      assert.strictEqual(firstStaleTick.action, 'spawned');
      assert.strictEqual((await staleCtrl.waitForInFlight()).exitCode, 0);
      // Advance well past retryBackoffMs and toggle cloud connectivity false -> true: must NOT spawn again
      fakeNow += 45 * 60 * 1000;
      staleCtrl.noteCloudConnectivity(false, fakeNow);
      staleCtrl.noteCloudConnectivity(true, fakeNow + 1000);
      assert.strictEqual(
        staleCtrl.maybeTick(fakeNow + 1000).action,
        'waiting-onedrive',
        'Paused OneDrive must stay in waiting-onedrive across backoff and cloud reconnects until disk changes'
      );
      // Deliver peer-only.md via OneDrive -> settles -> syncs cleanly to origin/main
      fakeNow += 2_000;
      const deliveredPeerMd = path.join(tmpMemRoot, 'memory', 'peer-only.md');
      fs.writeFileSync(deliveredPeerMd, 'pushed from peer PC while OneDrive paused\r\n', 'utf8');
      setFileTime(deliveredPeerMd, fakeNow);
      fakeNow += 10 * 60 * 1000 + 1000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'spawned');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 0);
      fakeNow += 60_000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'clean');

      // Mid-push concurrent edit race: edit made while child is running must NOT be marked clean
      fakeNow += 60_000;
      fs.writeFileSync(noteMd, 'edit before spawn\r\n', 'utf8');
      setFileTime(noteMd, fakeNow);
      fakeNow += 10 * 60 * 1000 + 1000;
      const raceSpawn = ctrl.maybeTick(fakeNow, { forcePoll: true });
      assert.strictEqual(raceSpawn.action, 'spawned');
      // Mutate file BEFORE awaiting child completion so disk moves past startedTreeSig
      fakeNow += 1000;
      fs.writeFileSync(noteMd, 'concurrent edit mid-push\r\n', 'utf8');
      setFileTime(noteMd, fakeNow);
      await ctrl.waitForInFlight();
      fakeNow += 60_000;
      assert.strictEqual(
        ctrl.maybeTick(fakeNow, { forcePoll: true }).action,
        'waiting-quiet',
        'Concurrent edit during in-flight push must remain dirty and wait for its own quiet window'
      );
      fakeNow += 10 * 60 * 1000;
      assert.strictEqual(ctrl.maybeTick(fakeNow, { forcePoll: true }).action, 'spawned');
      assert.strictEqual((await ctrl.waitForInFlight()).exitCode, 0);
      const raceBody = spawnSync(
        'git',
        [`--git-dir=${tmpRemoteDir}`, 'show', 'main:memory/notes.md'],
        { windowsHide: true, encoding: 'utf8' }
      ).stdout;
      assert.strictEqual(raceBody, 'concurrent edit mid-push\r\n');

      // Verify private note NEVER leaked to stand-in remote in any commit
      const allRemoteObjs = spawnSync(
        'git',
        [`--git-dir=${tmpRemoteDir}`, 'rev-list', '--objects', '--all'],
        { windowsHide: true, encoding: 'utf8' }
      ).stdout.toLowerCase();
      assert.strictEqual(allRemoteObjs.includes('bank-kyc-ali-bdeir'), false);
    } finally {
      try {
        fs.rmSync(tmpIdleDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
      } catch {}
    }
    console.log('[PASS] Adversarial #14: Keepalive background idle & offline-ahead memory-git sync verified');
  }

  // Adversarial #15: PC Setup Checker, Path Sanitization, Toast Deduplication & Trusted-Webview Gate
  {
    const Module = require('module');
    const pcSetup = require(path.join(ROOT, 'pc-setup.js'));
    const pcSetupSrc = fs.readFileSync(path.join(ROOT, 'pc-setup.js'), 'utf8');
    assert.strictEqual(
      /\b(execFileSync|spawnSync|execSync)\b/.test(pcSetupSrc),
      false,
      'pc-setup.js must never block the Extension Host with synchronous child_process calls'
    );

    const dirtySanitized = pcSetup.sanitizePublicPcSetupSummary({
      checkedAt: 1700000000000,
      ready: false,
      okCount: 9,
      totalCount: 11,
      pendingCount: 2,
      pending: [
        { id: 'claude-automode', name: 'Claude Code auto-mode rules' },
        { id: 'theo-hub', name: 'C:\\Users\\secretuser\\bhfirms\\theo-hub stale' },
        { id: 'bad;rm -rf /', name: 'Evil step' }
      ]
    });
    assert.strictEqual(dirtySanitized.okCount, 9);
    assert.strictEqual(dirtySanitized.totalCount, 11);
    assert.strictEqual(dirtySanitized.pending.length, 2);
    assert.strictEqual(dirtySanitized.pending[0].name, 'Claude Code auto-mode rules');
    assert.strictEqual(
      dirtySanitized.pending[1].name,
      'theo-hub',
      'Public fleet summary must scrub any accidentally leaked Windows/POSIX file path'
    );

    const tmpPcDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-pc-setup-hub-'));
    const origLoad = Module._load;
    try {
      const fakeHome = path.join(tmpPcDir, 'home');
      const fakeRoot = path.join(fakeHome, 'OneDrive - BHFIRMS', 'System', 'System', 'THEO');
      fs.mkdirSync(path.join(fakeRoot, 'Admin'), { recursive: true });
      fs.writeFileSync(path.join(fakeRoot, 'THEO.md'), '# THEO\n', 'utf8');
      fs.writeFileSync(
        path.join(fakeRoot, 'Admin', 'pc-setup-manifest.json'),
        '{"schemaVersion":1,"steps":[]}\n',
        'utf8'
      );
      fs.writeFileSync(
        path.join(fakeRoot, 'Admin', 'theo-pc-setup.py'),
        [
          'import json, os',
          'h = os.environ.get("THEO_SETUP_HOME", "")',
          'print(json.dumps({',
          '  "ok": False,',
          '  "pc": "PEER-BOX",',
          '  "steps": [',
          '    {"id": "runtimes", "title": "Runtimes", "ok": True, "summary": "ready"},',
          '    {"id": "claude-automode", "title": "Auto-mode rules", "ok": False, "user_terminal": True, "summary": h + "\\\\.claude\\\\settings.json missing rule"}',
          '  ]',
          '}))',
          'raise SystemExit(1)'
        ].join('\n'),
        'utf8'
      );
      const cacheFile = path.join(fakeHome, '.claude', '.theo-pc-setup-status.json');
      const stampFile = path.join(fakeHome, '.claude', '.theo-pc-setup-toast-stamp.json');
      const view = await pcSetup.checkPcSetupStatus({
        allowInSmokeTest: true,
        force: true,
        homeDir: fakeHome,
        memoryRoot: fakeRoot,
        cachePath: cacheFile
      });
      assert.strictEqual(view.available, true);
      assert.strictEqual(view.ready, false);
      assert.strictEqual(view.okCount, 1);
      assert.strictEqual(view.totalCount, 2);
      assert.strictEqual(view.pendingCount, 1);
      assert.ok(
        view.steps[1].summary.startsWith('~'),
        'Local step summary should replace raw home directory with ~'
      );
      const cachedRaw = fs.readFileSync(cacheFile, 'utf8');
      assert.strictEqual(
        cachedRaw.includes(fakeHome),
        false,
        'Persisted public status cache must never contain host paths'
      );
      const cachedPub = pcSetup.readCachedPcSetupSummary({ cachePath: cacheFile });
      assert.strictEqual(cachedPub.pendingCount, 1);
      assert.strictEqual(cachedPub.pending[0].id, 'claude-automode');

      // Brand-new PC before Python 3.8+ is installed: manifest fallback must still report pending & write status cache
      const noPyHome = path.join(tmpPcDir, 'nopy-home');
      const noPyRoot = path.join(noPyHome, 'OneDrive - BHFIRMS', 'System', 'System', 'THEO');
      fs.mkdirSync(path.join(noPyRoot, 'Admin'), { recursive: true });
      fs.writeFileSync(path.join(noPyRoot, 'THEO.md'), '# THEO\n', 'utf8');
      fs.writeFileSync(
        path.join(noPyRoot, 'Admin', 'pc-setup-manifest.json'),
        JSON.stringify({
          schemaVersion: 1,
          steps: [
            { id: 'runtimes', title: 'Python, Node.js, Git & User PATH' },
            { id: 'theo-hub', title: 'THEO Hub extension' }
          ]
        }),
        'utf8'
      );
      const noPyCache = path.join(noPyHome, '.claude', '.theo-pc-setup-status.json');
      const noPyView = await pcSetup.checkPcSetupStatus({
        allowInSmokeTest: true,
        force: true,
        pythonExe: '',
        homeDir: noPyHome,
        memoryRoot: noPyRoot,
        cachePath: noPyCache
      });
      assert.strictEqual(noPyView.available, true, 'Missing Python must still surface manifest-backed setup checklist');
      assert.strictEqual(noPyView.ready, false, 'Missing Python must never masquerade as ready');
      assert.strictEqual(noPyView.pendingCount, 2);
      assert.strictEqual(fs.existsSync(noPyCache), true, 'Missing Python fallback must persist .theo-pc-setup-status.json');
      assert.strictEqual(
        pcSetup.readCachedPcSetupSummary({ cachePath: noPyCache }).pendingCount,
        2
      );
      assert.strictEqual(
        pcSetup.shouldPromptPcSetupToast(noPyView, {
          stampPath: path.join(noPyHome, '.claude', '.theo-pc-setup-toast-stamp.json'),
          now: 1700000000000
        }),
        true,
        'Missing Python on a brand-new PC must still trigger the one-time setup toast'
      );

      // Non-zero Setup-THEO-PC.ps1 exit during applyPcSetupFromTrustedUi must return ok: false with a scrubbed non-empty error
      if (process.platform === 'win32') {
        const failPs1 = path.join(fakeRoot, 'Admin', 'Setup-THEO-PC.ps1');
        fs.writeFileSync(
          failPs1,
          'Write-Error "Simulated network failure in $env:USERPROFILE\\secret"; exit 1\n',
          'utf8'
        );
        const failApply = await pcSetup.applyPcSetupFromTrustedUi({
          allowInSmokeTest: true,
          homeDir: fakeHome,
          memoryRoot: fakeRoot,
          cachePath: cacheFile
        });
        assert.strictEqual(failApply.ok, false, 'Non-zero PowerShell apply must return ok: false');
        assert.ok(
          typeof failApply.error === 'string' && failApply.error.length > 0,
          'Failed applyPcSetupFromTrustedUi must populate res.error so extension.js never shows a false up-to-date toast'
        );
        assert.strictEqual(
          failApply.error.includes(fakeHome),
          false,
          'Scrubbed apply error must not leak raw host home path'
        );
      }

      // Toast deduplication: first time true, repeat within 12h false, new pending id true
      const t0 = 1700000000000;
      assert.strictEqual(
        pcSetup.shouldPromptPcSetupToast(view, { stampPath: stampFile, now: t0 }),
        true
      );
      pcSetup.recordPcSetupToastShown(view, { stampPath: stampFile, now: t0 });
      assert.strictEqual(
        pcSetup.shouldPromptPcSetupToast(view, { stampPath: stampFile, now: t0 + 60_000 }),
        false,
        'Identical pending set must not re-toast within cooldown'
      );
      const evolvedView = {
        ...view,
        pendingCount: 2,
        pending: [...view.pending, { id: 'new-tool', title: 'New Tool' }]
      };
      assert.strictEqual(
        pcSetup.shouldPromptPcSetupToast(evolvedView, { stampPath: stampFile, now: t0 + 60_000 }),
        true,
        'Newly evolved setup step must prompt immediately'
      );

      // Trusted-webview gate on HubProvider.handleMessage('applyPcSetup')
      Module._load = function (request, parent, isMain) {
        if (request === 'vscode') {
          return {
            commands: { executeCommand: async () => {} },
            workspace: { name: 'THEO', getConfiguration: () => ({ get: () => undefined, update: async () => {} }) },
            window: { showInformationMessage: async () => null, showErrorMessage: async () => null }
          };
        }
        return origLoad.apply(this, arguments);
      };
      const { HubProvider } = require(path.join(ROOT, 'hub.js'));
      const { AntigravityDataStore } = require(path.join(ROOT, 'store.js'));
      const { HubStateStore } = require(path.join(ROOT, 'state.js'));
      const { SessionActivityTracker } = require(path.join(ROOT, 'activity.js'));
      let trustedApplyCalls = 0;
      const fakeGlobalState = { get: () => undefined, update: async () => {} };
      const gatedHub = new HubProvider(
        { extensionPath: ROOT, extensionUri: { fsPath: ROOT }, globalState: fakeGlobalState },
        {
          store: new AntigravityDataStore(),
          stateStore: new HubStateStore(fakeGlobalState, { diskBackup: false }),
          activity: new SessionActivityTracker(),
          tabs: { getOpenSessionTabs: () => [] },
          ensureBridge: async () => ({}),
          applyPcSetup: async () => {
            trustedApplyCalls += 1;
          }
        }
      );
      await gatedHub.handleMessage({ action: 'applyPcSetup' });
      assert.strictEqual(
        trustedApplyCalls,
        0,
        'Untrusted programmatic handleMessage("applyPcSetup") must be ignored'
      );
      await gatedHub.handleMessage({ action: 'applyPcSetup' }, { trustedWebview: true });
      assert.strictEqual(
        trustedApplyCalls,
        1,
        'Genuine webview click ({ trustedWebview: true }) must invoke applyPcSetup'
      );
      gatedHub.dispose();
    } finally {
      Module._load = origLoad;
      try {
        fs.rmSync(tmpPcDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
      } catch {}
    }
    console.log('[PASS] Adversarial #15: PC Setup Checker, sanitization, toast dedup & trusted-webview gate verified');
  }

  // ---- Adversarial #16: Fleet Claude Permission Mode (JSONC mutator, paused-OneDrive cache, Remote Bridge & Hub trusted gate) ----
  {
    const tmpModeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-claude-mode-'));
    const Module = require('module');
    const origLoad = Module._load;
    try {
      const dr = require(path.join(ROOT, 'direct-runner.js'));
      const cb = require(path.join(ROOT, 'compat', 'claude-hub-bridge.cjs'));

      // 16a. JSONC-safe VS Code settings mutator preserves // comments, /* */ comments, CRLF, URLs, and nested keys
      const jsoncBefore = [
        '{',
        '  // User theme and proxy URL',
        '  "http.proxy": "http://127.0.0.1:8080 // not a comment",',
        '  /* Keep nested untouched */',
        '  "nested": {',
        '    "claudeCode.initialPermissionMode": "doNotTouch"',
        '  },',
        '  "claudeCode.initialPermissionMode": "auto",',
        '  "editor.fontSize": 14',
        '}',
        ''
      ].join('\r\n');
      const mutated = dr.mutateJsoncTopLevelKeys(jsoncBefore, {
        'claudeCode.initialPermissionMode': 'bypassPermissions',
        'claudeCode.allowDangerouslySkipPermissions': true
      });
      assert.strictEqual(mutated.ok, true);
      assert.strictEqual(mutated.changed, true);
      assert.ok(mutated.text.includes('\r\n'), 'CRLF line endings must be preserved');
      assert.ok(mutated.text.includes('// User theme and proxy URL'), 'line comments must be preserved');
      assert.ok(mutated.text.includes('/* Keep nested untouched */'), 'block comments must be preserved');
      assert.ok(
        mutated.text.includes('"claudeCode.initialPermissionMode": "doNotTouch"'),
        'nested identically-named keys must never be overwritten'
      );
      assert.ok(
        mutated.text.includes('"claudeCode.initialPermissionMode": "bypassPermissions"'),
        'existing top-level initialPermissionMode must be updated in place'
      );
      assert.ok(
        mutated.text.includes('"claudeCode.allowDangerouslySkipPermissions": true'),
        'missing top-level allowDangerouslySkipPermissions must be inserted'
      );
      const corruptJsonc = dr.mutateJsoncTopLevelKeys('{ "unterminated: 123', {
        'claudeCode.initialPermissionMode': 'plan'
      });
      assert.strictEqual(corruptJsonc.ok, false, 'corrupt JSONC must fail safely without corrupting file');

      // 16b. Paused-OneDrive resilience across BOTH direct-runner.js AND compat/claude-hub-bridge.cjs + manual disk edit override
      const fakeHome = path.join(tmpModeDir, 'home');
      const fakeMem = path.join(fakeHome, 'OneDrive - BHFIRMS', 'System', 'System', 'THEO');
      const sharedFile = path.join(fakeMem, 'Admin', 'claude-permission-mode.json');
      const cacheFile = path.join(fakeHome, '.claude', '.theo-claude-permission-mode.json');
      const vsSettingsFile = path.join(fakeHome, 'AppData', 'Roaming', 'Code', 'User', 'settings.json');
      fs.mkdirSync(path.dirname(sharedFile), { recursive: true });
      fs.mkdirSync(path.dirname(cacheFile), { recursive: true });
      fs.mkdirSync(path.dirname(vsSettingsFile), { recursive: true });
      fs.writeFileSync(vsSettingsFile, jsoncBefore, 'utf8');

      // Initial state: OneDrive shared file sits at `bypassPermissions`
      const baseTimeMs = Date.now() - 60000;
      fs.writeFileSync(
        sharedFile,
        JSON.stringify({ defaultMode: 'bypassPermissions', description: 'Shared mode' }, null, 2) + '\n',
        'utf8'
      );
      const baseDate = new Date(baseTimeMs);
      fs.utimesSync(sharedFile, baseDate, baseDate);

      // Simulate a laptop whose OneDrive is paused: phone/Cloud Store switches fleet to `plan` (`rev: 5`),
      // updating the local cache + local settings while `Admin\claude-permission-mode.json` stays frozen on disk at `bypassPermissions`!
      const wRes = dr.writeSharedClaudePermissionMode(
        'plan',
        {
          rev: 5,
          updatedAt: baseTimeMs + 10000,
          updatedBy: 'THEO Remote',
          source: 'theo-store'
        },
        {
          homeDir: fakeHome,
          memoryRoot: fakeMem,
          modeFilePath: sharedFile,
          localCachePath: cacheFile,
          vscodeSettingsPath: vsSettingsFile,
          skipSharedFile: true
        }
      );
      assert.strictEqual(wRes.ok, true);
      assert.strictEqual(
        JSON.parse(fs.readFileSync(sharedFile, 'utf8')).defaultMode,
        'bypassPermissions',
        'Simulated paused-OneDrive shared file remains frozen at bypassPermissions'
      );
      assert.strictEqual(
        JSON.parse(fs.readFileSync(path.join(fakeHome, '.claude', 'settings.json'), 'utf8')).permissions.defaultMode,
        'plan',
        '~/.claude/settings.json updated to plan'
      );
      const vsAfterPlan = fs.readFileSync(vsSettingsFile, 'utf8');
      assert.ok(
        vsAfterPlan.includes('// User theme and proxy URL') &&
          vsAfterPlan.includes('"claudeCode.initialPermissionMode": "doNotTouch"') &&
          !vsAfterPlan.includes('"claudeCode.initialPermissionMode": "auto"'),
        'Commented VS Code settings.json clears top-level initialPermissionMode override on plan while preserving comments & nested keys'
      );

      // Both direct-runner and claude-hub-bridge MUST resolve `plan` from the local fleet cache despite frozen OneDrive file!
      const pathOpts = {
        homeDir: fakeHome,
        memoryRoot: fakeMem,
        modeFilePath: sharedFile,
        localCachePath: cacheFile
      };
      const drInfo = dr.resolveSharedClaudePermissionModeInfo(pathOpts);
      assert.strictEqual(drInfo.defaultMode, 'plan', 'direct-runner resolves plan from local cache when OneDrive is paused');
      assert.strictEqual(drInfo.rev, 5);
      const cbInfo = cb.readSharedClaudePermissionMode(pathOpts);
      assert.strictEqual(cbInfo.mode, 'plan', 'claude-hub-bridge resolves plan from local cache when OneDrive is paused');

      // Now user manually edits `Admin\claude-permission-mode.json` on disk (`auto`, newer mtime) -> manual edit wins!
      const manualTimeMs = Date.now() + 5000;
      fs.writeFileSync(
        sharedFile,
        JSON.stringify({ defaultMode: 'auto', description: 'Manual edit' }, null, 2) + '\n',
        'utf8'
      );
      const manualDate = new Date(manualTimeMs);
      fs.utimesSync(sharedFile, manualDate, manualDate);
      assert.strictEqual(
        dr.resolveSharedClaudePermissionMode(pathOpts),
        'auto',
        'Manual disk edit with newer mtime overrides previous cloud cache in direct-runner'
      );
      assert.strictEqual(
        cb.readSharedClaudePermissionMode(pathOpts).mode,
        'auto',
        'Manual disk edit with newer mtime overrides previous cloud cache in claude-hub-bridge'
      );

      // 16c. TheoRemoteBridge Store reconciliation, offline dirtyToStore push, post-reload Plan exit via registered command & Hub trusted-webview gate
      const prevGuardHome = process.env.THEO_GUARD_HOME;
      process.env.THEO_GUARD_HOME = fakeHome;
      try {
        const registeredCommands = new Map();
        const vscodeMock = {
          ConfigurationTarget: { Global: 1 },
          commands: {
            registerCommand: (id, handler) => {
              registeredCommands.set(id, handler);
              return { dispose: () => registeredCommands.delete(id) };
            },
            executeCommand: async (id, ...args) => {
              const fn = registeredCommands.get(id);
              if (!fn) {
                throw new Error(`command '${id}' not found`);
              }
              return fn(...args);
            }
          },
          workspace: {
            name: 'THEO',
            getConfiguration: () => ({
              get: () => undefined,
              inspect: () => ({ globalValue: undefined }),
              update: async () => {}
            }),
            onDidChangeConfiguration: () => ({ dispose: () => {} })
          },
          window: {
            showInformationMessage: async () => null,
            showWarningMessage: async () => null,
            showErrorMessage: async () => null,
            setStatusBarMessage: () => {}
          }
        };
        Module._load = function (request, parent, isMain) {
          if (request === 'vscode') {
            return vscodeMock;
          }
          return origLoad.apply(this, arguments);
        };
        delete require.cache[require.resolve(path.join(ROOT, 'compat', 'claude-hub-bridge.cjs'))];
        delete require.cache[require.resolve(path.join(ROOT, 'remote.js'))];
        delete require.cache[require.resolve(path.join(ROOT, 'hub.js'))];
        delete globalThis.__antigravityClaudeBridgeV1;

        const isolatedCb = require(path.join(ROOT, 'compat', 'claude-hub-bridge.cjs'));
        const { TheoRemoteBridge } = require(path.join(ROOT, 'remote.js'));
        const { HubProvider } = require(path.join(ROOT, 'hub.js'));
        const { AntigravityDataStore } = require(path.join(ROOT, 'store.js'));
        const { HubStateStore } = require(path.join(ROOT, 'state.js'));
        const { SessionActivityTracker } = require(path.join(ROOT, 'activity.js'));

        // Attach claude-hub-bridge with a reloaded session stuck in 'plan' (empty __bhfSharedPlanSessionIds)
        const storedModes = new Map([['sess-reloaded-plan', 'plan']]);
        let liveChannelMode = 'plan';
        const postedWebviewMsgs = [];
        const mockWebview = {
          postMessage: (m) => {
            postedWebviewMsgs.push(m);
            return true;
          }
        };
        const mockPanel = { title: 'Reloaded Plan Tab', active: true, visible: true, webview: mockWebview };
        const mockComms = {
          channels: new Map([
            [
              'ch-reloaded-1',
              { sessionId: 'sess-reloaded-plan', query: { transport: { options: { permissionMode: 'plan' } } } }
            ]
          ]),
          setPermissionMode: async (_chId, nextMode) => {
            liveChannelMode = nextMode;
            return { success: true };
          },
          send: () => {}
        };
        const mockController = {
          sessionPanels: new Map([['sess-reloaded-plan', mockPanel]]),
          panelComms: new Map([[mockPanel, mockComms]]),
          allComms: new Set([mockComms]),
          settings: {
            sessionModeStore: {
              ids: () => Array.from(storedModes.keys()),
              get: (sid) => storedModes.get(sid),
              update: async (sid, val) => {
                if (val === undefined) storedModes.delete(sid);
                else storedModes.set(sid, val);
              }
            },
            clearSessionPermissionMode: async (sid) => {
              storedModes.delete(sid);
            }
          }
        };
        isolatedCb.attach({
          controller: mockController,
          context: { subscriptions: [] },
          vscode: vscodeMock
        });
        const cbState = isolatedCb.getBridgeState();
        if (cbState?.permSyncInterval) {
          clearInterval(cbState.permSyncInterval);
          cbState.permSyncInterval = null;
        }
        assert.strictEqual(
          registeredCommands.has('antigravityHub.claudeSyncPermissionMode'),
          true,
          'compat/claude-hub-bridge.cjs must register antigravityHub.claudeSyncPermissionMode'
        );

        // Background sync WITHOUT resetSessionOverrides must preserve organic post-reload 'plan' session
        cbState.__bhfSharedPlanSessionIds.clear();
        await vscodeMock.commands.executeCommand('antigravityHub.claudeSyncPermissionMode', {
          ...pathOpts,
          force: true,
          resetSessionOverrides: false
        });
        assert.strictEqual(
          liveChannelMode,
          'plan',
          'Background sync without resetSessionOverrides must preserve organic Plan session'
        );
        assert.strictEqual(storedModes.get('sess-reloaded-plan'), 'plan');

        const storePayloads = [];
        const edgePushes = [];
        let failStoreNetwork = false;
        let mockStoreRev = 10;
        const bridge = new TheoRemoteBridge({ extensionPath: ROOT }, {});
        bridge.vscode = vscodeMock;
        bridge.relayConfig = { url: 'https://edge.example/store', key: 'unit-test-store-key' };
        bridge.postStore = async (body) => {
          if (failStoreNetwork) {
            throw new Error('simulated_offline_store');
          }
          storePayloads.push(body);
          if (body?.patch?.claude_permission_mode) {
            mockStoreRev =
              Math.max(mockStoreRev, Number(body.patch.claude_permission_mode.expectedRev || 0)) + 1;
            return {
              ok: true,
              claude_permission_mode: {
                defaultMode: body.patch.claude_permission_mode.defaultMode,
                rev: mockStoreRev,
                updatedAt: Date.now(),
                updatedBy: body.patch.claude_permission_mode.updatedBy || 'PeerHost',
                source: body.patch.claude_permission_mode.source || 'test'
              }
            };
          }
          return { ok: true, docs: {} };
        };
        bridge.edgeClient = {
          pushClaudePermissionMode: (doc) => {
            edgePushes.push(doc);
            return true;
          },
          stop: () => {}
        };

        // Explicit Fleet switch to bypassPermissions MUST invoke registered command with resetSessionOverrides: true and exit post-reload 'plan'!
        const setRes = await bridge.setFleetClaudePermissionMode('bypassPermissions', {
          source: 'unit-test',
          updatedBy: 'PeerHost'
        });
        await new Promise((r) => setTimeout(r, 25));
        assert.strictEqual(setRes.ok, true);
        assert.strictEqual(setRes.defaultMode, 'bypassPermissions');
        assert.strictEqual(setRes.claudePermissionMode?.rev, 11);
        assert.strictEqual(
          liveChannelMode,
          'bypassPermissions',
          'Explicit Fleet Mode switch must exit post-reload Plan session on live channel'
        );
        assert.strictEqual(
          storedModes.has('sess-reloaded-plan'),
          false,
          'Explicit Fleet Mode switch must clear stored Plan override in sessionModeStore'
        );
        assert.strictEqual(storePayloads.length, 1);
        assert.strictEqual(storePayloads[0].patch.claude_permission_mode.defaultMode, 'bypassPermissions');
        assert.strictEqual(edgePushes.length, 1);
        assert.strictEqual(edgePushes[0].defaultMode, 'bypassPermissions');
        assert.strictEqual(edgePushes[0].rev, 11);
        assert.strictEqual(edgePushes[0].alreadyStored, true);

        // Reconciling a newer Store rev (`rev: 12`, `plan`) pulls it locally without re-patching Store
        const storeTimeRev12 = Date.now() + 2000;
        await bridge.reconcileClaudePermissionModeWithStore({
          claude_permission_mode: {
            defaultMode: 'plan',
            rev: 12,
            updatedAt: storeTimeRev12,
            updatedBy: 'THEO Remote',
            source: 'theo-remote'
          }
        });
        assert.strictEqual(bridge.getClaudePermissionModeSnapshot().defaultMode, 'plan');
        assert.strictEqual(bridge.getClaudePermissionModeSnapshot().rev, 12);
        assert.strictEqual(storePayloads.length, 1, 'Pulling newer Store mode must not echo-patch Store');

        // Dual-channel incoming alreadyStored frame (`rev: 13`, `auto`) applies locally WITHOUT re-patching Store
        await bridge.handleIncomingEdgeClaudeMode({
          defaultMode: 'auto',
          rev: 13,
          alreadyStored: true,
          updatedAt: storeTimeRev12 + 1000,
          updatedBy: 'THEO Remote',
          source: 'theo-remote'
        });
        assert.strictEqual(bridge.getClaudePermissionModeSnapshot().defaultMode, 'auto');
        assert.strictEqual(bridge.getClaudePermissionModeSnapshot().rev, 13);
        assert.strictEqual(storePayloads.length, 1, 'alreadyStored WS/HTTP delivery must never double-patch Store');

        // Offline local Sidebar switch (`dirtyToStore: true`) must push outward on reconnect instead of being overwritten by older Store doc
        failStoreNetwork = true;
        const offlineTs = storeTimeRev12 + 8000;
        await bridge.setFleetClaudePermissionMode('bypassPermissions', {
          source: 'theo-hub',
          updatedBy: 'OfflinePC',
          updatedAt: offlineTs
        });
        const cacheWhileOffline = dr.readLocalClaudePermissionCache({ localCachePath: cacheFile });
        assert.strictEqual(cacheWhileOffline?.defaultMode, 'bypassPermissions');
        assert.strictEqual(cacheWhileOffline?.dirtyToStore, true, 'Failed Store patch must mark local cache dirtyToStore=true');
        failStoreNetwork = false;
        const reconOut = await bridge.reconcileClaudePermissionModeWithStore({
          claude_permission_mode: {
            defaultMode: 'auto',
            rev: 13,
            updatedAt: storeTimeRev12 + 1000,
            updatedBy: 'THEO Remote',
            source: 'theo-remote'
          }
        });
        assert.strictEqual(reconOut.ok, true);
        assert.strictEqual(reconOut.defaultMode, 'bypassPermissions', 'Newer offline dirtyToStore choice must push outward to Store on reconnect');
        assert.strictEqual(storePayloads.length, 2, 'Reconnect reconciliation must push dirty offline mode to Store');
        assert.strictEqual(
          dr.readLocalClaudePermissionCache({ localCachePath: cacheFile })?.dirtyToStore,
          false,
          'Successful Store sync must clear dirtyToStore=false'
        );

        // Delayed OneDrive unpause / `git pull` arriving with an older stamped `rev` (`rev: 11`, `auto`) and a brand-new `mtime` must NEVER overwrite newer fleet `plan` (`rev >= 15`)
        const planTs = offlineTs + 10000;
        const planSetRes = await bridge.setFleetClaudePermissionMode('plan', {
          source: 'theo-remote',
          updatedBy: 'THEO Remote',
          updatedAt: planTs
        });
        const planRev = planSetRes.claudePermissionMode?.rev;
        assert.ok(planRev >= 15, `Expected planRev >= 15, got ${planRev}`);
        const payloadsBeforeDelayedDisk = storePayloads.length;
        fs.writeFileSync(
          sharedFile,
          JSON.stringify({ defaultMode: 'auto', rev: 11, updatedAt: planTs - 20000 }, null, 2),
          'utf8'
        );
        const delayedSec = (planTs + 5000) / 1000;
        fs.utimesSync(sharedFile, delayedSec, delayedSec);
        assert.strictEqual(
          dr.resolveSharedClaudePermissionModeInfo({
            modeFilePath: sharedFile,
            localCachePath: cacheFile
          }).defaultMode,
          'plan',
          'resolveSharedClaudePermissionModeInfo must ignore delayed OneDrive file with stale rev < cache.rev'
        );
        const healedOut = await bridge.reconcileClaudePermissionModeWithStore({
          claude_permission_mode: {
            defaultMode: 'plan',
            rev: planRev,
            updatedAt: planTs,
            updatedBy: 'THEO Remote',
            source: 'theo-remote'
          }
        });
        assert.strictEqual(healedOut.defaultMode || healedOut.claudePermissionMode?.defaultMode, 'plan');
        assert.strictEqual(
          storePayloads.length,
          payloadsBeforeDelayedDisk,
          'Delayed stale-rev OneDrive arrival must NEVER patch Store'
        );
        const healedDisk = JSON.parse(fs.readFileSync(sharedFile, 'utf8'));
        assert.strictEqual(healedDisk.defaultMode, 'plan', 'Delayed stale-rev OneDrive file must be healed back to Store mode');
        assert.strictEqual(
          Object.prototype.hasOwnProperty.call(healedDisk, 'rev') ||
            Object.prototype.hasOwnProperty.call(healedDisk, 'updatedAt'),
          false,
          'Git-tracked Admin/claude-permission-mode.json must stay pure { description, defaultMode } without volatile rev/updatedAt'
        );

        // Unstamped (`rev: 0`) legacy OneDrive file arriving on a laptop with `lastSyncedDiskMode: ''` / `lastSyncedDiskMtimeMs: 0` must NEVER clobber newer Store `plan` (`rev >= 15`)
        fs.writeFileSync(
          cacheFile,
          JSON.stringify(
            {
              defaultMode: 'plan',
              rev: planRev,
              updatedAt: planTs,
              updatedBy: 'THEO Remote',
              source: 'theo-remote',
              dirtyToStore: false,
              lastSyncedDiskMode: '',
              lastSyncedDiskMtimeMs: 0,
              lastSyncedDiskRev: 0
            },
            null,
            2
          ),
          'utf8'
        );
        fs.writeFileSync(
          sharedFile,
          JSON.stringify({ defaultMode: 'bypassPermissions' }, null, 2),
          'utf8'
        );
        const unstampedSec = (planTs + 9000) / 1000;
        fs.utimesSync(sharedFile, unstampedSec, unstampedSec);
        assert.strictEqual(
          dr.resolveSharedClaudePermissionModeInfo({
            modeFilePath: sharedFile,
            localCachePath: cacheFile
          }).defaultMode,
          'plan',
          'direct-runner must ignore unstamped rev=0 OneDrive hydration when cache.rev > 0 and no prior disk baseline existed'
        );
        assert.strictEqual(
          isolatedCb.readSharedClaudePermissionMode({
            modeFilePath: sharedFile,
            localCachePath: cacheFile
          }).mode,
          'plan',
          'claude-hub-bridge must ignore unstamped rev=0 OneDrive hydration when cache.rev > 0 and no prior disk baseline existed'
        );
        const payloadsBeforeUnstamped = storePayloads.length;
        const unstampedRecon = await bridge.reconcileClaudePermissionModeWithStore({
          claude_permission_mode: {
            defaultMode: 'plan',
            rev: planRev,
            updatedAt: planTs,
            updatedBy: 'THEO Remote',
            source: 'theo-remote'
          }
        });
        assert.strictEqual(
          unstampedRecon.claudePermissionMode?.defaultMode,
          'plan',
          'reconcileClaudePermissionModeWithStore must keep Store plan against unstamped rev=0 hydration'
        );
        assert.strictEqual(
          storePayloads.length,
          payloadsBeforeUnstamped,
          'Unstamped rev=0 hydration must make 0 /store patches'
        );
        assert.strictEqual(
          JSON.parse(fs.readFileSync(sharedFile, 'utf8')).defaultMode,
          'plan',
          'Unstamped rev=0 file must be healed to Store mode'
        );

        // Standby VS Code Window 2 passive sync: when `~/.claude/.theo-claude-permission-mode.json` advances to a new `rev`, passive syncSharedClaudePermissionMode() (no explicit resetSessionOverrides) must still exit per-tab Plan
        storedModes.set('sess-reloaded-plan', 'plan');
        liveChannelMode = 'plan';
        dr.writeSharedClaudePermissionMode(
          'auto',
          { rev: planRev + 1, updatedAt: planTs + 15000, updatedBy: 'Window1', source: 'theo-remote' },
          { modeFilePath: sharedFile, localCachePath: cacheFile, skipSharedFile: true }
        );
        await isolatedCb.syncSharedClaudePermissionMode(isolatedCb.getBridgeState());
        assert.strictEqual(
          liveChannelMode,
          'auto',
          'Standby VS Code window passive sync must exit Plan when local Store cache advances to a new rev'
        );
        assert.strictEqual(
          storedModes.has('sess-reloaded-plan'),
          false,
          'Standby VS Code window passive sync must clear stored Plan override when cache rev advances'
        );

        // Standby VS Code Window 2 active click -> Primary `:4318` Window 1 loopback fan-out (`wsHub` + `edgeClient` + single `/store` patch, plus `alreadyStored` `same_rev` loopback fan-out)
        const wsBroadcasts = [];
        bridge.wsHub = {
          clients: new Set(['local-ws-client-1']),
          broadcast: (frame) => wsBroadcasts.push(frame)
        };
        const loopbackSrv = http.createServer((req, res) => bridge.handleHttpRequest(req, res));
        await new Promise((resolve, reject) => {
          loopbackSrv.once('error', reject);
          loopbackSrv.listen(0, '127.0.0.1', resolve);
        });
        try {
          const loopbackPort = loopbackSrv.address().port;
          bridge.port = loopbackPort;
          bridge.listening = true;

          let standbySyncedCalls = 0;
          const standbyBridge = new TheoRemoteBridge({ extensionPath: ROOT }, {});
          standbyBridge.port = loopbackPort;
          standbyBridge.listening = false;
          standbyBridge.standbyBindTimer = { unref() {} };
          standbyBridge.relayConfig = bridge.relayConfig;
          standbyBridge.postStore = async () => {
            throw new Error('standby_must_delegate_store_patch_to_primary');
          };
          standbyBridge.claudeBridge = {
            syncSharedClaudePermissionMode: () => {
              standbySyncedCalls++;
            }
          };

          const storeBeforeStandbyClick = storePayloads.length;
          const edgeBeforeStandbyClick = edgePushes.length;
          const wsBeforeStandbyClick = wsBroadcasts.length;

          const standbyOut = await standbyBridge.setFleetClaudePermissionMode('bypassPermissions', {
            source: 'theo-hub',
            updatedBy: 'StandbyWindow2'
          });
          assert.strictEqual(standbyOut.ok, true);
          assert.strictEqual(standbyOut.defaultMode, 'bypassPermissions');
          assert.strictEqual(
            storePayloads.length - storeBeforeStandbyClick,
            1,
            'Standby VS Code window click must delegate to primary and patch /store strictly once'
          );
          assert.strictEqual(
            edgePushes.length - edgeBeforeStandbyClick,
            1,
            'Primary :4318 window must broadcast standby window click on Edge WS'
          );
          assert.strictEqual(edgePushes[edgePushes.length - 1].defaultMode, 'bypassPermissions');
          assert.strictEqual(edgePushes[edgePushes.length - 1].alreadyStored, true);
          assert.strictEqual(
            wsBroadcasts.length - wsBeforeStandbyClick,
            1,
            'Primary :4318 window must broadcast standby window click on :4318/ws'
          );
          assert.strictEqual(wsBroadcasts[wsBroadcasts.length - 1].type, 'claude_permission_mode');
          assert.strictEqual(wsBroadcasts[wsBroadcasts.length - 1].defaultMode, 'bypassPermissions');
          assert.strictEqual(
            standbySyncedCalls,
            1,
            'Standby VS Code window must also sync its own in-process Claude tabs after delegation'
          );

          // Even when ~/.claude/.theo-claude-permission-mode.json already carries rev N (`same_rev` on disk), POST /api/claude-permission-mode with alreadyStored + loopbackFanout MUST still fan out on wsHub + edgeClient!
          const sameRevN = Number(standbyOut.claudePermissionMode?.rev || 0) + 1;
          dr.writeSharedClaudePermissionMode(
            'plan',
            { rev: sameRevN, updatedAt: Date.now(), updatedBy: 'StandbyFallback', source: 'theo-hub' },
            { modeFilePath: sharedFile, localCachePath: cacheFile, skipSharedFile: true }
          );
          const edgeBeforeSameRev = edgePushes.length;
          const wsBeforeSameRev = wsBroadcasts.length;
          const tok = bridge.getDerivedBridgeToken();
          const sameRevRes = await fetch(`http://127.0.0.1:${loopbackPort}/api/claude-permission-mode`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...(tok ? { Authorization: `Bearer ${tok}` } : {})
            },
            body: JSON.stringify({
              defaultMode: 'plan',
              rev: sameRevN,
              alreadyStored: true,
              loopbackFanout: true,
              updatedAt: Date.now(),
              updatedBy: 'StandbyFallback',
              source: 'theo-hub'
            })
          });
          assert.strictEqual(sameRevRes.status, 200);
          assert.strictEqual(
            edgePushes.length - edgeBeforeSameRev,
            1,
            'same_rev loopbackFanout POST must still push claude_permission_mode to Edge WS'
          );
          assert.strictEqual(edgePushes[edgePushes.length - 1].defaultMode, 'plan');
          assert.strictEqual(edgePushes[edgePushes.length - 1].rev, sameRevN);
          assert.strictEqual(
            wsBroadcasts.length - wsBeforeSameRev,
            1,
            'same_rev loopbackFanout POST must still broadcast claude_permission_mode to :4318/ws'
          );
          assert.strictEqual(wsBroadcasts[wsBroadcasts.length - 1].defaultMode, 'plan');
        } finally {
          bridge.listening = false;
          await new Promise((r) => loopbackSrv.close(r));
        }

        // 16c-ii. Idle/draft/reloaded Claude webview opened under Fleet `plan` exits `plan` on Fleet switch, while manual per-tab `plan` stays protected on passive sync
        const { CLAUDE_CTX_UI_RUNTIME_JS } = require('../compat/claude-webview-patches.cjs');
        const msgListeners = [];
        const stubEl = () => ({
          style: {},
          classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
          setAttribute() {},
          getAttribute: () => null,
          appendChild() {},
          remove() {},
          contains: () => false,
          querySelectorAll: () => [],
          querySelector: () => null,
          addEventListener() {},
          getBoundingClientRect: () => ({ left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 })
        });
        const wvCtx = {
          window: {
            addEventListener(type, fn) {
              if (type === 'message') msgListeners.push(fn);
            }
          },
          document: {
            readyState: 'complete',
            head: stubEl(),
            body: stubEl(),
            getElementById: () => null,
            createElement: () => stubEl(),
            querySelectorAll: () => [],
            querySelector: () => null,
            addEventListener() {}
          },
          MutationObserver: class {
            observe() {}
            disconnect() {}
          },
          Node: class {},
          queueMicrotask: (fn) => fn(),
          setInterval: () => 0,
          setTimeout: () => 0,
          clearTimeout: () => {}
        };
        wvCtx.window.window = wvCtx.window;
        wvCtx.window.document = wvCtx.document;
        vm.runInNewContext(CLAUDE_CTX_UI_RUNTIME_JS, wvCtx);
        assert.strictEqual(typeof wvCtx.window.__bhfTrackClaudeSession, 'function');
        assert.strictEqual(msgListeners.length, 1);

        const idlePlanSession = {
          claudeChannelId: undefined,
          permissionMode: { value: 'plan' },
          connection: {
            value: {
              config: {
                value: {
                  allowDangerouslySkipPermissions: true,
                  claudeSettings: { effective: { permissions: { defaultMode: 'plan' } } }
                }
              }
            }
          },
          setPermissionMode(nextM) {
            this.permissionMode.value = nextM;
          }
        };
        wvCtx.window.__bhfTrackClaudeSession(idlePlanSession);
        assert.strictEqual(
          idlePlanSession.__bhfSyncedIntoPlan,
          true,
          'Idle webview booted into plan via Fleet config must mark __bhfSyncedIntoPlan=true'
        );
        msgListeners[0]({
          data: { type: 'bhf_shared_permission_mode', mode: 'auto', resetSessionOverrides: false }
        });
        assert.strictEqual(
          idlePlanSession.permissionMode.value,
          'auto',
          'Idle webview booted under Fleet plan must exit plan when Fleet Mode switches to auto'
        );

        // Manual per-tab Plan pick under Fleet `auto`: preserved on passive sync, exited on explicit Fleet switch (`resetSessionOverrides: true`)
        idlePlanSession.setPermissionMode('plan', false, true);
        assert.strictEqual(idlePlanSession.permissionMode.value, 'plan');
        msgListeners[0]({
          data: { type: 'bhf_shared_permission_mode', mode: 'auto', resetSessionOverrides: false }
        });
        assert.strictEqual(
          idlePlanSession.permissionMode.value,
          'plan',
          'Manual per-tab Plan override must survive passive reconcile when resetSessionOverrides=false'
        );
        msgListeners[0]({
          data: {
            type: 'bhf_shared_permission_mode',
            mode: 'bypassPermissions',
            resetSessionOverrides: true
          }
        });
        assert.strictEqual(
          idlePlanSession.permissionMode.value,
          'bypassPermissions',
          'Explicit Fleet Mode switch (resetSessionOverrides=true) must exit Plan cleanly on idle tabs'
        );

        // HubProvider trustedWebview gate for `setClaudePermissionMode`
        let hubModeCalls = [];
        const fakeGlobalState = { get: () => undefined, update: async () => {} };
        const modeHub = new HubProvider(
          { extensionPath: ROOT, extensionUri: { fsPath: ROOT }, globalState: fakeGlobalState },
          {
            store: new AntigravityDataStore(),
            stateStore: new HubStateStore(fakeGlobalState, { diskBackup: false }),
            activity: new SessionActivityTracker(),
            tabs: { getOpenSessionTabs: () => [] },
            ensureBridge: async () => ({})
          }
        );
        modeHub.remote = {
          getStatus: () => ({ ok: true }),
          notifyStateUpdated: () => {},
          getClaudePermissionModeSnapshot: () => ({ defaultMode: 'plan', rev: 12 }),
          setFleetClaudePermissionMode: async (m, meta) => {
            hubModeCalls.push({ m, meta });
            return { ok: true, defaultMode: m, rev: 13 };
          }
        };
        await modeHub.handleMessage({ action: 'setClaudePermissionMode', mode: 'bypassPermissions' });
        assert.strictEqual(
          hubModeCalls.length,
          0,
          'Untrusted programmatic handleMessage("setClaudePermissionMode") must be ignored'
        );
        await modeHub.handleMessage(
          { action: 'setClaudePermissionMode', mode: 'bypassPermissions' },
          { trustedWebview: true }
        );
        assert.strictEqual(hubModeCalls.length, 1, 'Trusted webview click invokes setFleetClaudePermissionMode');
        assert.strictEqual(hubModeCalls[0].m, 'bypassPermissions');
        modeHub.dispose();
        bridge.dispose?.();
      } finally {
        delete globalThis.__antigravityClaudeBridgeV1;
        if (prevGuardHome === undefined) delete process.env.THEO_GUARD_HOME;
        else process.env.THEO_GUARD_HOME = prevGuardHome;
      }

      // 16d. Static hygiene: zero native `title=` attributes on `.claude-mode-pill` / `renderClaudeModeRowHTML`
      // and zero hardcoded usernames or PC names in modified files.
      const hubWebviewSrc = fs.readFileSync(path.join(ROOT, 'resources', 'hub.js'), 'utf8');
      const modeFnMatch = hubWebviewSrc.match(/function renderClaudeModeRowHTML[\s\S]*?\n  \}/);
      assert.ok(modeFnMatch, 'renderClaudeModeRowHTML must exist in resources/hub.js');
      assert.strictEqual(
        /\btitle\s*=/.test(modeFnMatch[0]),
        false,
        'renderClaudeModeRowHTML must contain zero native title= attributes'
      );
      for (const relFile of [
        'direct-runner.js',
        'compat/claude-hub-bridge.cjs',
        'edge-relay-client.js',
        'remote.js',
        'hub.js',
        'resources/hub.js',
        'cloudflare-relay/src/store.js',
        'cloudflare-relay/src/index.js'
      ]) {
        const txt = fs.readFileSync(path.join(ROOT, relFile), 'utf8');
        assert.strictEqual(
          /Hussein-Laptop|main-workstation|theo-laptop|hbdei/i.test(txt),
          false,
          `${relFile} must not hardcode workstation or OS account names`
        );
      }
    } finally {
      Module._load = origLoad;
      try {
        fs.rmSync(tmpModeDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
      } catch {}
    }
    console.log('[PASS] Adversarial #16: Fleet Claude Mode JSONC mutator, paused-OneDrive cache, Store sync & Hub gate verified');
  }

  // ---- Adversarial #17: Antigravity wedged GetAuthStatus fast-fallback, signed-out safety, origin/host gate, socket cleanup & worker broadcast ----
  {
    const prevDisableWorker = process.env.THEO_DISABLE_PROXY_WORKER;
    const prevHubStatePath = process.env.THEO_PERSISTENT_HUB_STATE_PATH;
    const tmpHubStateDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-adv17-'));
    const tmpHubStateFile = path.join(tmpHubStateDir, 'bhf-persistent-hub.json');
    process.env.THEO_PERSISTENT_HUB_STATE_PATH = tmpHubStateFile;
    process.env.THEO_DISABLE_PROXY_WORKER = '1';
    const ctxWinMod = require(path.join(ROOT, 'compat', 'antigravity-context-window.cjs'));
    try {
      // 17a. Identifier-agnostic patchMainJsSource + member-chain boundary safety + multi-call loop
      new vm.Script(ctxWinMod.buildClientWsBootScript(), { filename: 'bhf_ws_boot.js' });
      new vm.Script(ctxWinMod.buildClientContextUiScript(), { filename: 'bhf_context_ui.js' });

      const sampleMainJs =
        'async function Z5a(a,b=0){var c=(x)=>x,d=(x)=>x,g={timeoutMs:1E4};var k=d(await c(a._lsClient.getAuthStatus({},g)));return k}';
      const patchedSample = ctxWinMod.patchMainJsSource(sampleMainJs);
      assert.ok(
        patchedSample.includes('/*bhf-fast-auth-status*/') &&
          patchedSample.includes('window.__bhfFastGetAuthStatus(a,()=>a._lsClient.getAuthStatus({},g))'),
        'patchMainJsSource must wrap ._lsClient.getAuthStatus call without relying on minified outer names'
      );
      new vm.Script(patchedSample, { filename: 'patched_sample_main.js' });

      const dottedSample = 'function run(){return this.svc._lsClient.getAuthStatus({foo:1})}';
      const patchedDotted = ctxWinMod.patchMainJsSource(dottedSample);
      assert.ok(
        patchedDotted.includes('window.__bhfFastGetAuthStatus(this.svc,()=>this.svc._lsClient.getAuthStatus({foo:1}))'),
        'patchMainJsSource must handle dotted/this receiver expressions'
      );
      new vm.Script(patchedDotted, { filename: 'patched_dotted_main.js' });

      const chainAndMultiSample =
        'const arr=[{svc:{_lsClient:{getAuthStatus:()=>1}}}],b={_lsClient:{getAuthStatus:()=>2}},c={_lsClient:{getAuthStatus:()=>3}};const x=arr[0].svc._lsClient.getAuthStatus({}),y=b._lsClient.getAuthStatus({}),z=b?.svc._lsClient.getAuthStatus({}),w=c._lsClient.getAuthStatus({});';
      const patchedChainMulti = ctxWinMod.patchMainJsSource(chainAndMultiSample);
      new vm.Script(patchedChainMulti, { filename: 'patched_chain_multi_main.js' });
      assert.ok(
        patchedChainMulti.includes('window.__bhfFastGetAuthStatus(b,()=>b._lsClient.getAuthStatus({}))') &&
          patchedChainMulti.includes('window.__bhfFastGetAuthStatus(c,()=>c._lsClient.getAuthStatus({}))') &&
          !patchedChainMulti.includes('arr[0].(') &&
          !patchedChainMulti.includes('b?.('),
        'patchMainJsSource must skip unsafe mid-chain receivers without SyntaxError and wrap all remaining call sites'
      );

      // 17b. Live proxy against mock upstream hub with wedged GetAuthStatus
      let mockSignedIn = true;
      let hangGetAuthStatus = true;
      const hungResponses = new Set();
      const createMockHubServer = (expectedCsrf) =>
        http.createServer((req, res) => {
          if (req.headers['x-codeium-csrf-token'] !== expectedCsrf) {
            res.writeHead(403, { 'Content-Type': 'application/json' });
            res.end('{"error":"bad_csrf"}');
            return;
          }
          if (req.url === '/exa.language_server_pb.LanguageServerService/HasAuthToken') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ hasToken: mockSignedIn }));
            return;
          }
          if (req.url === '/exa.language_server_pb.LanguageServerService/GetUserStatus') {
            if (!mockSignedIn) {
              res.writeHead(401, { 'Content-Type': 'application/json' });
              res.end('{"code":"unauthenticated","message":"not logged into antigravity"}');
              return;
            }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(
              JSON.stringify({
                userStatus: {
                  email: 'unit.tester@example.com',
                  isGcpTos: false
                }
              })
            );
            return;
          }
          if (req.url === '/exa.language_server_pb.LanguageServerService/GetAuthStatus') {
            if (hangGetAuthStatus) {
              hungResponses.add(res);
              req.on('close', () => hungResponses.delete(res));
              res.on('close', () => hungResponses.delete(res));
              return;
            }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(
              JSON.stringify({
                authResult: {
                  hasValidAuth: true,
                  projectId: 'proj-warmed',
                  grantedScopes: ['email', 'openid'],
                  email: 'secret.leak@example.com',
                  apiKey: 'ya29.super-secret-token'
                }
              })
            );
            return;
          }
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end('<html><head></head><body>ok</body></html>');
        });

      let mockHub = createMockHubServer('unit-test-csrf');
      await new Promise((resolve, reject) => {
        mockHub.once('error', reject);
        mockHub.listen(0, '127.0.0.1', resolve);
      });

      let hubPort = mockHub.address().port;
      fs.writeFileSync(
        tmpHubStateFile,
        JSON.stringify({
          port: hubPort,
          csrfToken: 'unit-test-csrf',
          serverUrl: `http://127.0.0.1:${hubPort}`
        }),
        'utf8'
      );

      await ctxWinMod.stopContextProxy();
      try {
        const proxyUrl = await ctxWinMod.ensureContextProxy(
          {
            serverManager: {
              port: hubPort,
              serverUrl: `http://127.0.0.1:${hubPort}`,
              csrfToken: 'unit-test-csrf'
            }
          },
          `http://127.0.0.1:${hubPort}`
        );
        const proxyPort = Number(new URL(proxyUrl).port);

        // Foreign Origin must be rejected on /__bhf_auth_fastcheck
        const evilRes = await fetch(`${proxyUrl}/__bhf_auth_fastcheck`, {
          headers: { Origin: 'https://evil.attacker.example' }
        });
        assert.strictEqual(evilRes.status, 403, 'Foreign Origin on /__bhf_auth_fastcheck must return 403');

        // DNS-rebinding Host header (no Origin header) must also be rejected with 403
        const rebindStatus = await new Promise((resolve, reject) => {
          const rReq = http.request(
            {
              hostname: '127.0.0.1',
              port: proxyPort,
              path: '/__bhf_auth_fastcheck',
              method: 'GET',
              headers: { Host: 'evil.attacker.example' }
            },
            (rRes) => {
              rRes.resume();
              resolve(rRes.statusCode);
            }
          );
          rReq.on('error', reject);
          rReq.end();
        });
        assert.strictEqual(rebindStatus, 403, 'DNS-rebound Host header without Origin must return 403');

        // Warm lastValidAuthResultByPort when GetAuthStatus works, then re-wedge and verify sensitive fields are stripped
        hangGetAuthStatus = false;
        ctxWinMod.getProxyState()._localAuthProbeCache = null;
        ctxWinMod.getProxyState()._authStatusRefreshThrottle?.clear?.();
        await fetch(`${proxyUrl}/__bhf_auth_fastcheck`, {
          headers: { Origin: 'vscode-webview://unit-test-webview' }
        });
        await new Promise((r) => setTimeout(r, 80));
        hangGetAuthStatus = true;
        ctxWinMod.getProxyState()._localAuthProbeCache = null;

        // Same-origin / vscode-webview Origin succeeds in <250ms even while GetAuthStatus hangs
        const fastRes = await fetch(`${proxyUrl}/__bhf_auth_fastcheck`, {
          headers: { Origin: 'vscode-webview://unit-test-webview' }
        });
        assert.strictEqual(fastRes.status, 200);
        const fastJson = await fastRes.json();
        assert.strictEqual(fastJson.ok, true);
        assert.strictEqual(fastJson.signedIn, true);
        assert.strictEqual(fastJson.authResult?.hasValidAuth, true);
        assert.strictEqual(fastJson.authResult?.projectId, 'proj-warmed');
        assert.strictEqual(
          Object.prototype.hasOwnProperty.call(fastJson, 'email') ||
            Object.prototype.hasOwnProperty.call(fastJson.authResult || {}, 'email') ||
            Object.prototype.hasOwnProperty.call(fastJson.authResult || {}, 'apiKey'),
          false,
          '/__bhf_auth_fastcheck must strip unexpected/sensitive fields (email, apiKey) from cached authResult'
        );

        // Client window.__bhfFastGetAuthStatus resolves fallback when WS getAuthStatus hangs
        const bootVm = {
          window: {
            location: {
              origin: proxyUrl,
              href: `${proxyUrl}/c/new`,
              pathname: '/c/new',
              search: '',
              hash: ''
            },
            history: { state: null, pushState() {}, replaceState() {} },
            addEventListener() {},
            fetch: (u, init) => fetch(new URL(String(u), proxyUrl).toString(), init)
          },
          URL,
          URLSearchParams,
          Headers,
          Set,
          Promise,
          Date,
          Math,
          String,
          Number,
          Boolean,
          Object,
          Array,
          RegExp,
          encodeURIComponent,
          setTimeout,
          clearTimeout
        };
        bootVm.window.window = bootVm.window;
        vm.runInNewContext(ctxWinMod.buildClientWsBootScript(), bootVm);
        assert.strictEqual(typeof bootVm.window.__bhfFastGetAuthStatus, 'function');

        const t0 = Date.now();
        const wsFallbackOut = await bootVm.window.__bhfFastGetAuthStatus(
          {},
          () => new Promise(() => {})
        );
        const elapsedWs = Date.now() - t0;
        assert.strictEqual(wsFallbackOut?.authResult?.hasValidAuth, true);
        assert.ok(elapsedWs < 3200, `Expected fast auth fallback <3200ms, got ${elapsedWs}ms`);

        // HTTP POST GetAuthStatus through proxy falls back cleanly AND destroys upstream socket (0 leaked sockets)
        const tHttp = Date.now();
        const httpAuthRes = await fetch(
          `${proxyUrl}/exa.language_server_pb.LanguageServerService/GetAuthStatus`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Connect-Protocol-Version': '1',
              'x-codeium-csrf-token': 'unit-test-csrf'
            },
            body: '{}'
          }
        );
        assert.strictEqual(httpAuthRes.status, 200);
        const httpAuthJson = await httpAuthRes.json();
        assert.strictEqual(httpAuthJson?.authResult?.hasValidAuth, true);
        assert.ok(Date.now() - tHttp < 4000, 'HTTP GetAuthStatus proxy fallback must complete promptly');
        await new Promise((r) => setTimeout(r, 150));
        assert.strictEqual(
          hungResponses.size,
          0,
          'POST GetAuthStatus fallback must destroy wedged upReq so zero upstream sockets leak'
        );

        // Oversized POST GetAuthStatus (>16KB) must return 413 immediately instead of hanging
        const oversizeRes = await fetch(
          `${proxyUrl}/exa.language_server_pb.LanguageServerService/GetAuthStatus`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Connect-Protocol-Version': '1',
              'x-codeium-csrf-token': 'unit-test-csrf'
            },
            body: JSON.stringify({ pad: 'x'.repeat(20000) })
          }
        );
        assert.strictEqual(oversizeRes.status, 413, 'Oversized GetAuthStatus body must return 413');

        // Dead-hub ECONNREFUSED recovery: restart mockHub on a new port & CSRF recorded in THEO_PERSISTENT_HUB_STATE_PATH
        await new Promise((r) => mockHub.close(r));
        hangGetAuthStatus = false;
        mockHub = createMockHubServer('restarted-csrf');
        await new Promise((resolve, reject) => {
          mockHub.once('error', reject);
          mockHub.listen(0, '127.0.0.1', resolve);
        });
        hubPort = mockHub.address().port;
        fs.writeFileSync(
          tmpHubStateFile,
          JSON.stringify({
            port: hubPort,
            csrfToken: 'restarted-csrf',
            serverUrl: `http://127.0.0.1:${hubPort}`
          }),
          'utf8'
        );
        const recoveredPostRes = await fetch(
          `${proxyUrl}/exa.language_server_pb.LanguageServerService/GetAuthStatus`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Connect-Protocol-Version': '1',
              'x-codeium-csrf-token': 'stale-csrf'
            },
            body: '{}'
          }
        );
        assert.strictEqual(
          recoveredPostRes.status,
          200,
          'POST GetAuthStatus must auto-recover new hub port/CSRF on ECONNREFUSED'
        );
        const recoveredPostJson = await recoveredPostRes.json();
        assert.strictEqual(recoveredPostJson?.authResult?.hasValidAuth, true);

        // Signed-out safety: when HasAuthToken=false / GetUserStatus=401, never synthesize valid auth
        hangGetAuthStatus = true;
        mockSignedIn = false;
        ctxWinMod.getProxyState()._localAuthProbeCache = null;
        const signedOutFast = await (await fetch(`${proxyUrl}/__bhf_auth_fastcheck`)).json();
        assert.strictEqual(
          signedOutFast.signedIn,
          false,
          'Signed-out hub must return signedIn=false on /__bhf_auth_fastcheck'
        );
        let rejectedAsExpected = false;
        try {
          await bootVm.window.__bhfFastGetAuthStatus(
            {},
            () => Promise.reject(new Error('deadline_exceeded'))
          );
        } catch {
          rejectedAsExpected = true;
        }
        assert.strictEqual(
          rejectedAsExpected,
          true,
          'Signed-out hub must propagate original getAuthStatus failure without faking auth'
        );

        // 17c. Production worker_threads mode: multi-tab broadcast + projectId->project normalization + post-TTL drain
        mockSignedIn = true;
        await ctxWinMod.stopContextProxy();
        delete process.env.THEO_DISABLE_PROXY_WORKER;
        const workerProxyUrl = await ctxWinMod.ensureContextProxy(
          {
            serverManager: {
              port: hubPort,
              serverUrl: `http://127.0.0.1:${hubPort}`,
              csrfToken: 'restarted-csrf'
            }
          },
          `http://127.0.0.1:${hubPort}`
        );
        assert.ok(Boolean(ctxWinMod.getProxyState().worker), 'Proxy must run in worker_threads mode when enabled');
        ctxWinMod.getProxyState().remoteActionQueue = [];
        const enqEntry = ctxWinMod.enqueueRemoteWebviewAction({
          id: '*',
          kind: 'refresh_auth',
          payload: { isGcpTos: true, projectId: 'proj-from-rpc', location: 'us-central1', grantedScopes: ['email'] },
          broadcastTtlMs: 2000
        });
        await new Promise((r) => setTimeout(r, 60));

        const pollTabA1 = await (
          await fetch(`${workerProxyUrl}/__bhf_remote_poll?tabId=tab-alpha&id=cid-1&approvals=%5B%5D`)
        ).json();
        const pollTabB1 = await (
          await fetch(`${workerProxyUrl}/__bhf_remote_poll?tabId=tab-beta&id=cid-2&approvals=%5B%5D`)
        ).json();
        const pollTabA2 = await (
          await fetch(`${workerProxyUrl}/__bhf_remote_poll?tabId=tab-alpha&id=cid-1&approvals=%5B%5D`)
        ).json();
        const matchA = pollTabA1.actions.find((a) => a.actionId === enqEntry.actionId);
        const matchB = pollTabB1.actions.find((a) => a.actionId === enqEntry.actionId);
        assert.ok(matchA, 'Worker Tab A must receive broadcast refresh_auth on first poll');
        assert.strictEqual(
          matchA?.payload?.project,
          'proj-from-rpc',
          'enqueueRemoteWebviewAction must normalize raw authResult projectId -> project'
        );
        assert.ok(matchB, 'Worker Tab B must ALSO receive broadcast refresh_auth despite Tab A polling first');
        assert.strictEqual(
          pollTabA2.actions.filter((a) => a.actionId === enqEntry.actionId).length,
          0,
          'Worker Tab A must not receive duplicate broadcast refresh_auth on subsequent polls'
        );

        // Wait past 2000ms broadcast TTL and verify worker drains the action from main-thread remoteActionQueue
        await new Promise((r) => setTimeout(r, 2150));
        await fetch(`${workerProxyUrl}/__bhf_remote_poll?tabId=tab-gamma&id=cid-3&approvals=%5B%5D`);
        await new Promise((r) => setTimeout(r, 80));
        assert.strictEqual(
          ctxWinMod.getProxyState().remoteActionQueue.some((a) => a.actionId === enqEntry.actionId),
          false,
          'Expired worker broadcast action must drain from main-thread getProxyState().remoteActionQueue'
        );
      } finally {
        for (const r of hungResponses) {
          try {
            r.destroy();
          } catch {}
        }
        await ctxWinMod.stopContextProxy();
        await new Promise((r) => mockHub.close(r));
      }
    } finally {
      if (prevDisableWorker === undefined) delete process.env.THEO_DISABLE_PROXY_WORKER;
      else process.env.THEO_DISABLE_PROXY_WORKER = prevDisableWorker;
      if (prevHubStatePath === undefined) delete process.env.THEO_PERSISTENT_HUB_STATE_PATH;
      else process.env.THEO_PERSISTENT_HUB_STATE_PATH = prevHubStatePath;
      try {
        fs.rmSync(tmpHubStateDir, { recursive: true, force: true, maxRetries: 5, retryDelay: 50 });
      } catch {}
    }
    console.log('[PASS] Adversarial #17: Antigravity GetAuthStatus fast-fallback, socket cleanup, origin/host gate & worker broadcast verified');
  }

  // Adversarial #18: Keepalive scanTrackedMemoryTree honors !cloudflare-memory/**/*.html negation while ignoring root *.html
  {
    const prevSmoke = process.env.THEO_SMOKE_TEST;
    process.env.THEO_SMOKE_TEST = '1';
    try {
      const keepaliveMod = require(path.join(ROOT, 'scripts', 'relay_keepalive.cjs'));
      const tmpMemDir = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-keepalive-gitignore-'));
      try {
        fs.writeFileSync(path.join(tmpMemDir, '.gitignore'), '*.html\n!cloudflare-memory/**/*.html\n', 'utf8');
        fs.writeFileSync(path.join(tmpMemDir, 'THEO.md'), '# THEO\n', 'utf8');
        fs.writeFileSync(path.join(tmpMemDir, 'deliverable.html'), '<html>ignored</html>\n', 'utf8');
        fs.mkdirSync(path.join(tmpMemDir, 'cloudflare-memory', 'sub'), { recursive: true });
        fs.writeFileSync(path.join(tmpMemDir, 'cloudflare-memory', 'index.html'), '<html>tracked-top</html>\n', 'utf8');
        fs.writeFileSync(path.join(tmpMemDir, 'cloudflare-memory', 'sub', 'page.html'), '<html>tracked-sub</html>\n', 'utf8');
        const scanned = keepaliveMod.scanTrackedMemoryTree(tmpMemDir);
        assert.strictEqual(scanned.fileSigMap.has('deliverable.html'), false, 'Root *.html deliverable must stay ignored');
        assert.strictEqual(scanned.fileSigMap.has('cloudflare-memory/index.html'), true, 'cloudflare-memory/index.html must be tracked');
        assert.strictEqual(scanned.fileSigMap.has('cloudflare-memory/sub/page.html'), true, 'cloudflare-memory/sub/page.html must be tracked');
      } finally {
        fs.rmSync(tmpMemDir, { recursive: true, force: true });
      }
    } finally {
      if (prevSmoke === undefined) delete process.env.THEO_SMOKE_TEST;
      else process.env.THEO_SMOKE_TEST = prevSmoke;
    }
    console.log('[PASS] Adversarial #18: Keepalive scanTrackedMemoryTree !cloudflare-memory/**/*.html negation verified');
  }

  // ---- Adversarial #19: Sidebar load limits (activity reload hold, fast tab sync spacing, render burst, clock-stamp post hold) ----
  {
    const { runHubLimitTests } = require('./hub-limits.test.cjs');
    await runHubLimitTests(ROOT);
    console.log('[PASS] Adversarial #19: Sidebar load limits hold clock-stamp reposts and coalesce activity reloads without dropping a real change');
  }

  // ---- Adversarial #20: Bundle patchers stay linear on long identifier runs (17.8 s / 11.6 s freezes on Antigravity 1.12.0) ----
  {
    const { runBundlePatchPerfTests } = require('./bundle-patch-perf.test.cjs');
    await runBundlePatchPerfTests(ROOT);
    console.log('[PASS] Adversarial #20: patchAntigravityExtensionSource and patchMainJsSource finish under 1.5 s on a 40k identifier run');
  }

  // ---- Adversarial #22: Bundle patching off the Extension Host thread (worker, queue, stamp skip, failure retry) ----
  {
    const { runBridgeWorkerTests } = require('./bridge-worker.test.cjs');
    await runBridgeWorkerTests(ROOT);
    console.log('[PASS] Adversarial #22: prepatch and ensureBridge patch in a worker thread with identical output, queued runs and retry on failure');
  }

  // ---- Adversarial #21: build_vsix.py release guard (dirty/unpushed refusal, bundle-only Pages push, no rollback, lock) ----
  {
    const { runBuildGuardTests } = require('./build-guard.test.cjs');
    await runBuildGuardTests();
    console.log('[PASS] Adversarial #21: build_vsix.py publishes only committed, pushed code and never rolls the fleet back');
  }

  console.log('ALL_SMOKE_TESTS_PASSED');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
