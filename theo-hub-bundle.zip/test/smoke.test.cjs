'use strict';

const assert = require('assert');
const fs = require('fs');
const http = require('http');
const net = require('net');
const os = require('os');
const path = require('path');
const vm = require('vm');

process.env.THEO_SMOKE_TEST = '1';
process.env.THEO_DISABLE_HUB_PROCESS_REAP = '1';

const ROOT = path.resolve(__dirname, '..');

async function main() {
  // 1. Syntax check all CJS/JS modules
  const cjsFiles = [
    'extension.js',
    'accounts.js',
    'session-tabs.js',
    'hub.js',
    'data.js',
    'store.js',
    'state.js',
    'bridge.js',
    'remote.js',
    'device-identity.js',
    'ws-server.js',
    'direct-runner.js',
    'edge-relay-client.js',
    'activity.js',
    'desktop-notify.js',
    'scripts/relay_keepalive.cjs',
    'scripts/theo_agent.cjs',
    'compat/antigravity-hub-bridge.cjs',
    'compat/antigravity-tab-state.cjs',
    'compat/antigravity-context-window.cjs',
    'compat/claude-hub-bridge.cjs',
    'compat/claude-webview-patches.cjs',
    'compat/excel-preview.cjs'
  ];
  for (const rel of cjsFiles) {
    const full = path.join(ROOT, rel);
    assert.ok(fs.existsSync(full), `Missing module ${rel}`);
    const code = fs.readFileSync(full, 'utf8');
    new vm.Script(code, { filename: full });
  }
  console.log(`[PASS] Syntax verified across ${cjsFiles.length} theo-hub modules`);

  // 2. Adversarial Check #1: Zero secrets in repo & pairing token roundtrip + hostile input rejection
  assert.strictEqual(
    fs.existsSync(path.join(ROOT, 'remote-relay.json')),
    false,
    'remote-relay.json must NOT exist inside theo-hub repo'
  );
  const devId = require(path.join(ROOT, 'device-identity.js'));
  const sampleToken = devId.buildPairTokenBase64Url({
    cloudUrl: 'https://example.invalid/relay',
    cloudKey: 'test-cloud-key',
    edgeAccessKey: 'a'.repeat(64),
    edgeRelayUrl: 'wss://theo-edge-relay.husseinbdeir.workers.dev/ws',
    port: 4318
  });
  assert.ok(sampleToken && !sampleToken.includes('+') && !sampleToken.includes('/'), 'URL-safe base64 token');
  const decoded = devId.parsePairTokenBase64Url(`https://husseinbdeir.github.io/theo/#pair=${sampleToken}&foo=1`);
  assert.strictEqual(decoded.edgeAccessKey, 'a'.repeat(64));
  assert.strictEqual(decoded.cloudKey, 'test-cloud-key');
  assert.strictEqual(devId.parsePairTokenBase64Url('not-a-valid-token-$$$'), null);
  assert.strictEqual(devId.parsePairTokenBase64Url(''), null);

  // Cross-host device attribution & localOnly snapshot symmetry invariant (#2 & Red-Team Finding #1/#5)
  const wsRow = devId.inferRowOwnerDevice(
    { cwd: 'C:\\Users\\HusseinBdeir\\bhfirms\\isabi-app' },
    { id: 'theo-laptop', name: 'THEO Laptop' }
  );
  assert.strictEqual(wsRow.id, 'main-workstation');
  assert.strictEqual(wsRow.deviceId, 'main-workstation');
  assert.strictEqual(wsRow.deviceName, 'Main Workstation');
  const lapRow = devId.inferRowOwnerDevice(
    { cwd: 'C:\\Users\\hbdei\\bhfirms\\theo' },
    { id: 'main-workstation', name: 'Main Workstation' }
  );
  assert.strictEqual(lapRow.id, 'theo-laptop');
  assert.strictEqual(lapRow.deviceId, 'theo-laptop');
  const nodeBinInfo = devId.resolveNodeBinaryInfo();
  assert.strictEqual(nodeBinInfo.executable, nodeBinInfo.nodeExe, 'resolveNodeBinaryInfo must expose nodeExe alias');
  assert.strictEqual(
    nodeBinInfo.electronRunAsNode,
    nodeBinInfo.useElectronRunAsNode,
    'resolveNodeBinaryInfo must expose useElectronRunAsNode alias'
  );

  const { TheoRemoteBridge } = require(path.join(ROOT, 'remote.js'));
  const mockBridge = new TheoRemoteBridge(null, {
    hub: {
      lastPosted: JSON.stringify({
        rows: [
          { id: 'loc-1', title: 'Laptop Local Thread', cwd: 'C:\\Users\\hbdei\\bhfirms\\theo', provider: 'antigravity', at: 200 },
          { id: 'rem-1', title: 'Workstation Synced Thread', cwd: 'C:\\Users\\HusseinBdeir\\bhfirms\\isabi-app', provider: 'claude', at: 300 }
        ]
      }),
      snapshot: {}
    }
  });
  if (mockBridge.edgeClient) mockBridge.edgeClient.stop();
  mockBridge.deviceInfo = { id: 'theo-laptop', name: 'Theo Laptop', role: 'secondary', capabilities: ['antigravity', 'claude'] };
  const localOnlySnap = await mockBridge.buildFullState({ localOnly: true });
  assert.deepStrictEqual(
    localOnlySnap.rows.map((r) => r.id),
    ['loc-1'],
    'buildFullState({ localOnly: true }) must retain local rows and exclude foreign-host rows'
  );
  const fullMergedSnap = await mockBridge.buildFullState({ localOnly: false });
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'loc-1')?.remotePeer, false);
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'rem-1')?.deviceId, 'main-workstation');
  assert.strictEqual(fullMergedSnap.rows.find((r) => r.id === 'rem-1')?.remotePeer, true);

  let capturedEdgeUrl = '';
  mockBridge.setEffectiveEdgeUrl = async (u) => {
    capturedEdgeUrl = u;
    return { ok: true };
  };
  for (const payload of [{ url: 'wss://a.example/ws' }, { edgeRelayUrl: 'wss://b.example/ws' }]) {
    const rawNextUrl = payload.edgeRelayUrl !== undefined ? payload.edgeRelayUrl : payload.url;
    await mockBridge.setEffectiveEdgeUrl(String(rawNextUrl || '').trim());
    assert.strictEqual(capturedEdgeUrl, payload.edgeRelayUrl || payload.url);
  }
  console.log('[PASS] Adversarial #1: Zero repo secrets, #pair= token roundtrip/hostile rejection, and cross-host attribution');

  // 3. Adversarial Check #2: RFC 6455 WS server Origin gate, Auth gate (4001), onConnect post-auth firing, & unmasked/continuation validation
  const { attachWebSocketServer } = require(path.join(ROOT, 'ws-server.js'));
  const expectedSecret = devId.deriveEdgeAuthToken('unit-test-secret-key');
  let onConnectFiredCount = 0;
  const srv = http.createServer((req, res) => {
    res.writeHead(200);
    res.end('ok');
  });
  const wss = attachWebSocketServer(srv, {
    path: '/ws',
    verifyUpgrade: (req) => {
      const origin = String(req.headers.origin || '');
      if (origin && origin !== 'http://127.0.0.1' && origin !== 'https://husseinbdeir.github.io') {
        return { ok: false, status: 403, message: 'Forbidden Origin' };
      }
      return { ok: true };
    },
    verifyToken: (tok) => tok === expectedSecret,
    onConnect: (conn) => {
      onConnectFiredCount += 1;
      conn.sendJson({ type: 'welcome', ok: true });
    }
  });
  await new Promise((resolve) => srv.listen(0, '127.0.0.1', resolve));
  const port = srv.address().port;

  try {
    // 3a. Hostile Origin must be rejected with HTTP 403 before WS upgrade completes
    const evilStatus = await new Promise((resolve, reject) => {
      const req = http.request({
        host: '127.0.0.1',
        port,
        path: '/ws',
        headers: {
          Connection: 'Upgrade',
          Upgrade: 'websocket',
          Origin: 'https://evil.attacker.example',
          'Sec-WebSocket-Version': '13',
          'Sec-WebSocket-Key': Buffer.from('1234567890123456').toString('base64')
        }
      });
      req.on('response', (res) => {
        res.resume();
        resolve(res.statusCode);
      });
      req.on('upgrade', (_, sock) => {
        sock.destroy();
        resolve(101);
      });
      req.on('error', reject);
      req.end();
    });
    assert.strictEqual(evilStatus, 403, 'Evil Origin must receive 403');

    // 3b. Wrong token over WS must be rejected with close code 4001
    const badCloseCode = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, {
        headers: { Origin: 'https://husseinbdeir.github.io' }
      });
      const t = setTimeout(() => reject(new Error('WS close timeout')), 4000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ type: 'auth', token: 'wrong-token' }));
      });
      ws.addEventListener('close', (ev) => {
        clearTimeout(t);
        resolve(ev.code);
      });
    });
    assert.strictEqual(badCloseCode, 4001, 'Invalid WS auth token must close with 4001');
    assert.strictEqual(onConnectFiredCount, 0, 'onConnect must NEVER fire before valid WS token auth');

    // 3c. Valid token succeeds, receives auth_ok AND welcome from onConnect fallback
    const authedOk = await new Promise((resolve, reject) => {
      const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`, {
        headers: { Origin: 'https://husseinbdeir.github.io' }
      });
      const seenTypes = new Set();
      const t = setTimeout(() => reject(new Error('WS auth_ok + welcome timeout')), 4000);
      ws.addEventListener('open', () => {
        ws.send(JSON.stringify({ type: 'auth', token: expectedSecret }));
      });
      ws.addEventListener('message', (ev) => {
        const msg = JSON.parse(String(ev.data));
        seenTypes.add(msg.type);
        if (seenTypes.has('auth_ok') && seenTypes.has('welcome')) {
          clearTimeout(t);
          ws.close();
          resolve(true);
        }
      });
    });
    assert.strictEqual(authedOk, true);
    assert.strictEqual(onConnectFiredCount, 1, 'onConnect must fire exactly once after valid WS auth');

    // 3d. Unexpected RFC 6455 continuation frame (opcode 0x0 with no fragmented message) closes cleanly without crashing
    const protoClose = await new Promise((resolve) => {
      const sock = net.connect(port, '127.0.0.1', () => {
        const key = Buffer.from('abcdefghijklmnop').toString('base64');
        sock.write(
          `GET /ws HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: ${key}\r\n\r\n`
        );
      });
      let upgraded = false;
      let buf = Buffer.alloc(0);
      sock.on('data', (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        if (!upgraded && buf.includes('\r\n\r\n')) {
          upgraded = true;
          // Masked FIN=1 opcode=0x0 (unexpected continuation) length=2 mask=0x11223344 payload=0x0000
          const badFrame = Buffer.from([0x80, 0x82, 0x11, 0x22, 0x33, 0x44, 0x11, 0x22]);
          sock.write(badFrame);
        }
      });
      sock.on('close', () => resolve(true));
    });
    assert.strictEqual(protoClose, true);
  } finally {
    wss.closeAll();
    await new Promise((resolve) => srv.close(resolve));
  }
  console.log('[PASS] Adversarial #2: WS Origin 403, invalid-token 4001, valid auth_ok, and RFC 6455 protocol-error guard');

  // 4. Adversarial Check #3: Cortex SQLite protobuf decoder & sidecar recovery + missing-ID safety
  const { AntigravityDataStore } = require(path.join(ROOT, 'store.js'));
  const store = new AntigravityDataStore();
  assert.strictEqual(store.readCliConversationDbDetail('../../etc/passwd'), null, 'Path traversal ID must return null');
  assert.strictEqual(store.readCliConversationDbDetail('00000000-0000-0000-0000-000000000000'), null);
  const cliConvDir = path.join(os.homedir(), '.gemini', 'antigravity-cli', 'conversations');
  if (fs.existsSync(cliConvDir)) {
    const dbFiles = fs.readdirSync(cliConvDir).filter((f) => f.endsWith('.db'));
    if (dbFiles.length > 0) {
      let decodedAny = 0;
      for (const f of dbFiles.slice(0, 5)) {
        const cid = f.replace(/\.db$/, '');
        const parsed = store.readCliConversationDbDetail(cid);
        if (parsed && Array.isArray(parsed.messages) && parsed.messages.length > 0) {
          decodedAny += 1;
        }
      }
      assert.ok(decodedAny > 0, 'Expected at least 1 CLI SQLite conversation to decode >0 messages');
      console.log(`[PASS] Adversarial #3: Decoded ${decodedAny}/${Math.min(5, dbFiles.length)} CLI SQLite conversations + rejected traversal IDs`);
    }
  } else {
    console.log('[PASS] Adversarial #3: Traversal & missing SQLite ID guards verified');
  }

  console.log('ALL_SMOKE_TESTS_PASSED');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
