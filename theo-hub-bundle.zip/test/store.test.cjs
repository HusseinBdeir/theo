// Behavioural tests for the THEO Store Durable Object (cloudflare-relay/src/store.js).
// Runs the real source in a vm with node:sqlite standing in for Durable Object SQLite and a recording fetch for Web Push.
// Run: node test/store.test.cjs
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const nodeCrypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const ROOT = path.resolve(__dirname, '..');
const src = fs.readFileSync(path.join(ROOT, 'cloudflare-relay', 'src', 'store.js'), 'utf8');

const cjs =
  src
    .replace(
      /import\s*\{\s*DurableObject\s*\}\s*from\s*["']cloudflare:workers["'];?/,
      'class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }'
    )
    .replace(/export\s+function\s+routeStoreRequest\b/, 'function routeStoreRequest')
    .replace(/export\s+class\s+TheoStoreRoom\b/, 'class TheoStoreRoom') +
  '\nmodule.exports = { TheoStoreRoom, routeStoreRequest, isAllowedPushEndpoint };\n';
assert.ok(!/^\s*export\s/m.test(cjs), 'every export in store.js must be covered by the test transform');

const cfSubtle = new Proxy(globalThis.crypto.subtle, {
  get(target, prop) {
    if (prop === 'timingSafeEqual') {
      return (a, b) => nodeCrypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
    }
    const val = target[prop];
    return typeof val === 'function' ? val.bind(target) : val;
  }
});
const cfCrypto = new Proxy(globalThis.crypto, {
  get(target, prop) {
    if (prop === 'subtle') return cfSubtle;
    const val = target[prop];
    return typeof val === 'function' ? val.bind(target) : val;
  }
});

// Recording Web Push fetch
const pushCalls = [];
let pushStatusFor = () => 201;
let onPushFetch = null; // async hook that runs while a push is "on the wire"
let clock =Date.parse('2026-11-10T13:20:00.000Z');
class FakeDate extends Date {
  constructor(...args) {
    if (args.length === 0) super(clock);
    else super(...args);
  }
  static now() {
    return clock;
  }
}

const mod = { exports: {} };
vm.runInNewContext(
  cjs,
  {
    module: mod,
    exports: mod.exports,
    crypto: cfCrypto,
    fetch: async (url, init = {}) => {
      const status = pushStatusFor(String(url));
      if (status === 'throw') throw new Error('network down');
      pushCalls.push({
        url: String(url),
        headers: { ...(init.headers || {}) },
        redirect: init.redirect,
        bytes: init.body ? Buffer.from(init.body).length : 0,
        rawBody: init.body ? Buffer.from(init.body) : Buffer.alloc(0)
      });
      if (onPushFetch) await onPushFetch(String(url), init);
      return new Response('', { status });
    },
    atob,
    AbortSignal,
    TextEncoder,
    TextDecoder,
    Uint8Array,
    URL,
    Request,
    Response,
    Headers,
    Date: FakeDate
  },
  { filename: 'cloudflare-relay-store.js' }
);
const { TheoStoreRoom, routeStoreRequest, isAllowedPushEndpoint } = mod.exports;

function makeRoom(env) {
  const db = new DatabaseSync(':memory:');
  const state = { alarmAt: 0 };
  const sql = {
    exec(query, ...params) {
      if (params.length === 0 && !/^\s*SELECT\b/i.test(query)) {
        db.exec(query);
        return [];
      }
      const stmt = db.prepare(query);
      if (/^\s*SELECT\b/i.test(query)) return stmt.all(...params);
      stmt.run(...params);
      return [];
    }
  };
  const room = new TheoStoreRoom(
    {
      storage: {
        sql,
        getAlarm: async () => state.alarmAt || null,
        setAlarm: async (ts) => {
          state.alarmAt = Number(ts || 0);
        },
        transactionSync: (fn) => {
          db.exec('BEGIN');
          try {
            const out = fn();
            db.exec('COMMIT');
            return out;
          } catch (err) {
            db.exec('ROLLBACK');
            throw err;
          }
        }
      }
    },
    env
  );
  return { room, state, db };
}

const THEO_KEY = nodeCrypto.createHash('sha256').update('theo-edge-v1:unit-test-secret').digest('hex');
const FIT_KEY = 'fitness-public-key-0123456789abcdef';
const ENV = { AUTH_TOKEN: THEO_KEY, FITNESS_KEY: FIT_KEY };
const APPLE = 'https://web.push.apple.com/QH-abc123';
const B64 = Buffer.from('encrypted-payload-bytes').toString('base64');

async function call(room, pathName, body, headers = {}) {
  const res = await room.fetch(
    new Request(`https://edge.example${pathName}`, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8', ...headers },
      body: typeof body === 'string' ? body : JSON.stringify(body)
    })
  );
  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {}
  return { status: res.status, json, text };
}

async function runAlarmAt(ctx, ts) {
  clock = ts;
  await ctx.room.alarm();
}

(async () => {
  // ---- 1. Worker routing ----
  assert.strictEqual(
    routeStoreRequest(new Request('https://edge.example/ws'), {}),
    null,
    'non-store paths must fall through to the relay'
  );
  assert.strictEqual(routeStoreRequest(new Request('https://edge.example/storefront'), {}), null);
  const routed = [];
  const forwarded = [];
  const fakeEnv = {
    ...ENV,
    THEO_STORE: {
      idFromName: (n) => {
        routed.push(n);
        return n;
      },
      get: () => ({
        fetch: async (req) => {
          forwarded.push({ url: req.url, body: await req.text(), origin: req.headers.get('Origin') });
          return new Response('{"ok":true}', { status: 200 });
        }
      })
    }
  };
  const route = (pathName, body, headers = {}, method = 'POST') =>
    routeStoreRequest(
      new Request(`https://edge.example${pathName}`, {
        method,
        headers,
        ...(method === 'POST' ? { body: typeof body === 'string' ? body : JSON.stringify(body) } : {})
      }),
      fakeEnv
    );
  await route('/store', { key: THEO_KEY, op: 'get_control' });
  await route('/store/fitness', { key: FIT_KEY, op: 'get' });
  assert.deepStrictEqual(routed, ['theo-store-v1', 'fitness-store-v1'], 'each namespace gets its own Durable Object');
  assert.strictEqual(JSON.parse(forwarded[0].body).op, 'get_control', 'the body is forwarded intact');
  assert.strictEqual((await route('/store', { key: THEO_KEY, op: 'get' }, { Origin: 'https://evil.example' })).status, 403, 'hostile Origin must be refused');
  assert.strictEqual((await route('/store', null, {}, 'GET')).status, 405);
  assert.strictEqual((await route('/store', null, {}, 'OPTIONS')).status, 204);
  assert.strictEqual((await route('/store/other', { key: THEO_KEY, op: 'get' })).status, 404);
  assert.strictEqual((await route('/store', { key: THEO_KEY, op: 'get' }, { Origin: 'https://husseinbdeir.github.io' })).status, 200);
  assert.strictEqual(forwarded[forwarded.length - 1].origin, 'https://husseinbdeir.github.io');

  // Red-team H2: nothing without a valid key, and nothing oversized, may reach (or wake) the Durable Object.
  let before = forwarded.length;
  let rr = await route('/store', { key: 'wrong-key-wrong-key-wrong-key', op: 'get_control' });
  assert.strictEqual(rr.status, 401);
  assert.deepStrictEqual(await rr.json(), { ok: false, error: 'bad key' });
  assert.strictEqual((await route('/store', { op: 'patch', patch: { a: 1 } })).status, 401);
  assert.strictEqual((await route('/store', { key: FIT_KEY, op: 'get' })).status, 401, 'fitness key is refused on the THEO path');
  assert.strictEqual((await route('/store/fitness', { key: THEO_KEY, op: 'get' })).status, 401, 'THEO key is refused on the fitness path');
  assert.strictEqual((await route('/store', 'not json')).status, 400);
  assert.strictEqual((await route('/store', '[1,2]')).status, 400);
  // Node's Request sends no Content-Length for a string body, so these exercise the streaming cap itself.
  assert.strictEqual((await route('/store', 'x'.repeat(9 * 1024 * 1024))).status, 413, 'oversized THEO body is cut off while streaming');
  assert.strictEqual((await route('/store/fitness', 'x'.repeat(1100 * 1024))).status, 413, 'oversized fitness body is cut off while streaming');
  assert.strictEqual((await route('/store', { key: THEO_KEY, op: 'get' }, { 'Content-Length': String(50 * 1024 * 1024) })).status, 413, 'a declared oversize is refused before reading');
  assert.strictEqual((await route('/store', { op: 'delegate_get', taskId: 'a', token: 'b', pad: 'x'.repeat(20000) })).status, 401, 'keyless requests must be small');
  assert.strictEqual((await route('/store/fitness', { op: 'delegate_get', taskId: 'a', token: 'b' })).status, 401, 'fitness has no keyless ops');
  assert.strictEqual((await route('/store', { op: 'push', key: 'wrong-key-wrong-key-wrong-key', taskId: 'a', token: 'b' })).status, 401, 'a wrong key is never downgraded to a staff request');
  assert.strictEqual(forwarded.length, before, 'none of the refused requests was forwarded to the Durable Object');
  // The three staff ops are the only keyless traffic that is forwarded.
  await route('/store', { op: 'delegate_get', taskId: 'a', token: 'b' });
  await route('/store', { op: 'delegate_update', taskId: 'a', token: 'b', status: 'seen' });
  await route('/store', { op: 'push', taskId: 'a', token: 'b', endpoint: 'https://web.push.apple.com/x' });
  assert.strictEqual(forwarded.length, before + 3);
  before = forwarded.length;
  assert.strictEqual((await route('/store', { op: 'get_control' }, { Authorization: `Bearer ${THEO_KEY}` })).status, 200, 'Bearer header works at the Worker');
  assert.strictEqual(forwarded.length, before + 1);
  assert.strictEqual((await routeStoreRequest(new Request('https://edge.example/store', { method: 'POST', body: JSON.stringify({ key: THEO_KEY, op: 'get' }) }), { THEO_STORE: fakeEnv.THEO_STORE })).status, 401, 'a Worker with no secret configured fails closed');

  // Worker entry (src/worker.js): store paths never reach the relay and relay paths never reach the store.
  {
    const workerSrc = fs.readFileSync(path.join(ROOT, 'cloudflare-relay', 'src', 'worker.js'), 'utf8');
    const workerCjs = workerSrc
      .replace(/import\s+relay\s*,\s*\{\s*TheoRelayRoom\s*\}\s*from\s*["']\.\/index\.js["'];?/, '')
      .replace(/import\s*\{\s*TheoStoreRoom\s*,\s*routeStoreRequest\s*\}\s*from\s*["']\.\/store\.js["'];?/, '')
      .replace(/export\s*\{[^}]*\};?/, '')
      .replace(/export\s+default\s+/, 'module.exports = ');
    assert.ok(!/^\s*(import|export)\s/m.test(workerCjs), 'worker.js transform must cover every import/export');
    const relayCalls = [];
    const wm = { exports: {} };
    vm.runInNewContext(workerCjs, {
      module: wm,
      relay: { fetch: async (req) => (relayCalls.push(new URL(req.url).pathname), new Response('relay', { status: 426 })) },
      TheoRelayRoom: class {},
      TheoStoreRoom,
      routeStoreRequest
    });
    const before2 = forwarded.length;
    let wr = await wm.exports.fetch(new Request('https://edge.example/ws'), fakeEnv);
    assert.strictEqual(wr.status, 426);
    wr = await wm.exports.fetch(new Request('https://edge.example/pair/claim', { method: 'POST', body: '{}' }), fakeEnv);
    assert.deepStrictEqual(relayCalls, ['/ws', '/pair/claim'], 'relay paths go to the unchanged relay');
    assert.strictEqual(forwarded.length, before2);
    wr = await wm.exports.fetch(new Request('https://edge.example/store', { method: 'POST', body: JSON.stringify({ key: THEO_KEY, op: 'get' }) }), fakeEnv);
    assert.strictEqual(wr.status, 200);
    assert.strictEqual(relayCalls.length, 2, 'store paths never reach the relay');
    assert.strictEqual(forwarded.length, before2 + 1);
  }

  // ---- 2. Auth ----
  const t = makeRoom(ENV);
  let r = await call(t.room, '/store', { key: 'wrong-key-wrong-key-wrong-key', op: 'get_control' });
  assert.strictEqual(r.status, 401);
  assert.deepStrictEqual(r.json, { ok: false, error: 'bad key' }, 'error shape must match the legacy relay');
  r = await call(t.room, '/store', { op: 'get_control' });
  assert.strictEqual(r.status, 401, 'missing key must be refused');
  r = await call(t.room, '/store', { key: '', op: 'patch', patch: { a: 1 } });
  assert.strictEqual(r.status, 401);
  r = await call(t.room, '/store', { key: FIT_KEY, op: 'get' });
  assert.strictEqual(r.status, 401, 'the fitness key must not open the THEO store');
  r = await call(t.room, '/store', 'not json');
  assert.strictEqual(r.status, 400);
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'nope' });
  assert.strictEqual(r.status, 400);
  r = await call(t.room, '/store', { op: 'get_control' }, { Authorization: `Bearer ${THEO_KEY}` });
  assert.strictEqual(r.status, 200, 'Bearer header is accepted as an alternative to body.key');
  const noSecretRoom = makeRoom({});
  r = await call(noSecretRoom.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.strictEqual(r.status, 401, 'a Worker with no secret configured must fail closed');

  // ---- 3. Documents: routing, shallow replace, ackOnly, delete, large docs ----
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.json.ok, true);
  assert.ok(r.json.serverTime && r.json.docs && Object.keys(r.json.docs).length === 0);

  r = await call(t.room, '/store', {
    key: THEO_KEY,
    op: 'patch',
    ackOnly: true,
    patch: { queue: { commands: [{ id: 'cmd-1' }], results: {} }, edge_relay: { url: 'wss://x/ws' } }
  });
  assert.deepStrictEqual(Object.keys(r.json).sort(), ['ok', 'serverTime'], 'ackOnly returns no docs');

  const bigThread = { messages: [] };
  for (let i = 0; i < 2600; i++) bigThread.messages.push({ i, text: '😀 ملاحظة résumé — ' + 'x'.repeat(390) + ' 🕌' });
  const statePatch = {
    meta: { v: 2, updatedAt: '2026-11-10T13:20:00.000Z' },
    state: { snapshot: { rows: [{ id: 'row-1' }] } },
    threads: { 'thread-a': bigThread }
  };
  assert.ok(JSON.stringify(statePatch).length > 1024 * 1024, 'fixture must span several storage chunks');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: statePatch });
  assert.strictEqual(r.status, 200);

  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.deepStrictEqual(Object.keys(r.json.docs).sort(), ['edge_relay', 'queue'], 'state patches never land in the control store');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get' });
  assert.deepStrictEqual(Object.keys(r.json.docs).sort(), ['edge_relay', 'queue'], 'legacy get returns control docs');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_theo' });
  assert.deepStrictEqual(Object.keys(r.json.docs).sort(), ['edge_relay', 'meta', 'queue', 'state', 'threads']);
  assert.deepStrictEqual(r.json.docs.threads, statePatch.threads, 'multi-chunk doc with emoji and Arabic must round-trip exactly');
  const chunkRows = t.db.prepare("SELECT COUNT(*) AS n, MAX(LENGTH(CAST(v AS BLOB))) AS maxBytes FROM doc_chunks WHERE k = 'threads'").get();
  assert.ok(chunkRows.n >= 3, 'large doc is stored in several rows');
  assert.ok(chunkRows.maxBytes < 2 * 1024 * 1024, 'every row stays under the 2 MB Durable Object row limit');

  // shallow top-level replace, control patch leaves state alone
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'patch', patch: { queue: { commands: [], results: { a: 1 } } } });
  assert.deepStrictEqual(r.json.docs.queue, { commands: [], results: { a: 1 } }, 'patch replaces the whole top-level doc');
  assert.ok(!('state' in r.json.docs), 'a control patch answers with control docs only');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { edge_relay: null } });
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.ok(!('edge_relay' in r.json.docs), 'null deletes a doc');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_theo' });
  assert.ok(r.json.docs.state && r.json.docs.threads, 'state store survives control writes');

  // meta in both stores: control wins in the union
  await call(t.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { meta: { v: 2, from: 'control' } } });
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_theo' });
  assert.strictEqual(r.json.docs.meta.from, 'control');

  r = await call(t.room, '/store', { key: THEO_KEY, op: 'patch', patch: [1, 2] });
  assert.strictEqual(r.status, 400);
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'patch', patch: { '': 1 } });
  assert.strictEqual(r.status, 400, 'empty doc key is refused');

  // ---- 4. Immediate push ----
  assert.ok(isAllowedPushEndpoint(APPLE));
  assert.ok(isAllowedPushEndpoint('https://fcm.googleapis.com/fcm/send/abc'));
  assert.ok(isAllowedPushEndpoint('https://wns2-par02p.notify.windows.com/w/?token=abc'));
  assert.ok(isAllowedPushEndpoint('https://updates.push.services.mozilla.com/wpush/v2/abc'));
  for (const bad of [
    'http://web.push.apple.com/x',
    'https://evil.example/x',
    'https://web.push.apple.com.evil.example/x',
    'https://user:pw@web.push.apple.com/x',
    'https://web.push.apple.com:8443/x',
    'https://169.254.169.254/latest/meta-data',
    'not a url'
  ]) {
    assert.ok(!isAllowedPushEndpoint(bad), `must refuse push endpoint ${bad}`);
  }
  pushCalls.length = 0;
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push', endpoint: APPLE, vapid: 'vapid t=abc, k=def', bodyB64: B64, ttl: '3600' });
  assert.deepStrictEqual(r.json, { ok: true, pushStatus: 201 });
  assert.strictEqual(pushCalls.length, 1);
  assert.strictEqual(pushCalls[0].headers.Authorization, 'vapid t=abc, k=def');
  assert.strictEqual(pushCalls[0].headers['Content-Encoding'], 'aes128gcm');
  assert.strictEqual(pushCalls[0].headers.TTL, '3600');
  assert.strictEqual(pushCalls[0].headers.Urgency, 'high');
  assert.strictEqual(pushCalls[0].bytes, Buffer.from(B64, 'base64').length);
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push', endpoint: APPLE, auth: 'vapid t=abc, k=def', bodyB64: B64 });
  assert.strictEqual(r.json.pushStatus, 201, 'legacy `auth` field is accepted for the VAPID header');
  pushCalls.length = 0;
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push', endpoint: 'https://evil.example/collect', vapid: 'vapid t=a', bodyB64: B64 });
  assert.strictEqual(r.status, 400);
  assert.strictEqual(pushCalls.length, 0, 'the store must never fetch a non push-service URL');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push', endpoint: APPLE, vapid: 'vapid t=a\r\nX-Injected: 1', bodyB64: B64 });
  assert.strictEqual(r.json.ok, false);
  assert.strictEqual(pushCalls.length, 0, 'header injection in the VAPID value is refused');
  pushStatusFor = () => 403;
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push', endpoint: APPLE, vapid: 'vapid t=a', bodyB64: B64 });
  assert.deepStrictEqual(r.json, { ok: false, pushStatus: 403 });
  pushStatusFor = () => 'throw';
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push', endpoint: APPLE, vapid: 'vapid t=a', bodyB64: B64 });
  assert.deepStrictEqual(r.json, { ok: false, pushStatus: 0 });
  pushStatusFor = () => 201;

  // ---- 5. Delayed push timers ----
  pushCalls.length = 0;
  const T0 = clock;
  r = await call(t.room, '/store', {
    key: THEO_KEY,
    op: 'push_delay',
    timerKey: 'prayer_d2_maghrib_dev1',
    timerId: '2026-11-10_maghrib_1__aaa',
    expSec: 1794365640,
    delaySec: 600,
    endpoint: APPLE,
    vapid: 'vapid t=p1',
    bodyB64: B64
  });
  assert.strictEqual(r.json.ok, true);
  assert.strictEqual(t.state.alarmAt, T0 + 600000, 'alarm is set to the timer deadline when it precedes the next hour');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.deepStrictEqual(r.json.docs.prayer_d2_maghrib_dev1, { id: '2026-11-10_maghrib_1__aaa', expSec: 1794365640 });

  // not due yet
  await runAlarmAt(t, T0 + 300000);
  assert.strictEqual(pushCalls.length, 0);
  // due
  await runAlarmAt(t, T0 + 600500);
  assert.strictEqual(pushCalls.length, 1);
  assert.strictEqual(pushCalls[0].headers.Authorization, 'vapid t=p1');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_control' });
  let doc = r.json.docs.prayer_d2_maghrib_dev1;
  assert.strictEqual(doc.id, 'fired_2026-11-10_maghrib_1__aaa');
  assert.strictEqual(doc.pushStatus, 201);
  assert.ok(doc.firedAt);
  // a second alarm never re-sends
  await runAlarmAt(t, T0 + 700000);
  assert.strictEqual(pushCalls.length, 1, 'a fired timer is sent exactly once');

  // cancelled before the deadline
  pushCalls.length = 0;
  await call(t.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'timer_rem_1_dev1', timerId: 'rem_1__a', delaySec: 60, endpoint: APPLE, vapid: 'vapid t=c', bodyB64: B64 });
  await call(t.room, '/store', { key: THEO_KEY, op: 'patch', patch: { timer_rem_1_dev1: { id: 'cancelled', updatedAt: 'x' } } });
  await runAlarmAt(t, clock + 61000);
  assert.strictEqual(pushCalls.length, 0, 'a cancelled timer never fires');

  // re-armed with a new nonce: only the newest id fires
  await call(t.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'timer_rem_2_dev1', timerId: 'rem_2__old', delaySec: 60, endpoint: APPLE, vapid: 'vapid t=old', bodyB64: B64 });
  await call(t.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'timer_rem_2_dev1', timerId: 'rem_2__new', delaySec: 120, endpoint: APPLE, vapid: 'vapid t=new', bodyB64: B64 });
  await runAlarmAt(t, clock + 61000);
  assert.strictEqual(pushCalls.length, 0, 'the superseded timer run is gone');
  await runAlarmAt(t, clock + 61000);
  assert.strictEqual(pushCalls.length, 1);
  assert.strictEqual(pushCalls[0].headers.Authorization, 'vapid t=new');

  // a host that takes over and stamps fired_ retires the pending timer
  pushCalls.length = 0;
  await call(t.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'timer_rem_3_dev1', timerId: 'rem_3__a', delaySec: 60, endpoint: APPLE, vapid: 'vapid t=h', bodyB64: B64 });
  await call(t.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { timer_rem_3_dev1: { id: 'fired_rem_3__a', pushStatus: 201 } } });
  await runAlarmAt(t, clock + 61000);
  assert.strictEqual(pushCalls.length, 0, 'bridge takeover stamp prevents a duplicate send');

  // failure stamps
  pushStatusFor = () => 403;
  await call(t.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'timer_rem_4_dev1', timerId: 'rem_4__a', delaySec: 30, endpoint: APPLE, vapid: 'vapid t=f', bodyB64: B64 });
  await runAlarmAt(t, clock + 31000);
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.strictEqual(r.json.docs.timer_rem_4_dev1.id, 'failed_403_rem_4__a', 'a refused push is stamped failed_<status>_ so the bridge can take over');
  pushStatusFor = () => 410;
  await call(t.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'timer_rem_5_dev1', timerId: 'rem_5__a', delaySec: 30, endpoint: APPLE, vapid: 'vapid t=g', bodyB64: B64 });
  await runAlarmAt(t, clock + 31000);
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.strictEqual(r.json.docs.timer_rem_5_dev1.id, 'fired_rem_5__a', '404 and 410 count as terminal, matching the legacy flow');
  pushStatusFor = () => 201;
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'k', timerId: 'i', delaySec: 30, endpoint: 'https://evil.example/x', vapid: 'v', bodyB64: B64 });
  assert.strictEqual(r.status, 400, 'delayed pushes obey the same endpoint allowlist');
  assert.strictEqual(t.db.prepare('SELECT COUNT(*) AS n FROM timers').get().n, 0, 'no timer rows are left behind');

  // ---- 6. Hourly slots (replaces the Daily Push flows) ----
  const h = makeRoom(ENV);
  clock = Date.parse('2026-11-10T13:20:00.000Z');
  const hRoom = makeRoom(ENV); // created at 13:20 -> hour 13 is already considered dispatched
  await call(hRoom.room, '/store', {
    key: THEO_KEY,
    op: 'patch',
    ackOnly: true,
    patch: {
      push_registry: {
        items: [
          { id: 'dev1', endpoint: APPLE, slots: { '2026-11-10T13': { vapid: 'vapid t=h13', bodyB64: B64 }, '2026-11-10T14': { vapid: 'vapid t=h14', bodyB64: B64 } } },
          { id: 'dev2', endpoint: 'https://web.push.apple.com/other', slots: { '2026-11-10T15': { vapid: 'vapid t=h15', bodyB64: B64 } } },
          { id: 'dev3', endpoint: APPLE }
        ]
      }
    }
  });
  assert.strictEqual(hRoom.state.alarmAt, Date.parse('2026-11-10T14:00:05.000Z'), 'with no timers the alarm waits for the next hour');
  pushCalls.length = 0;
  await runAlarmAt(hRoom, Date.parse('2026-11-10T13:40:00.000Z'));
  assert.strictEqual(pushCalls.length, 0, 'the hour in which the store was created is never dispatched');
  await runAlarmAt(hRoom, Date.parse('2026-11-10T14:00:05.000Z'));
  assert.strictEqual(pushCalls.length, 1);
  assert.strictEqual(pushCalls[0].headers.Authorization, 'vapid t=h14');
  await runAlarmAt(hRoom, Date.parse('2026-11-10T14:30:00.000Z'));
  assert.strictEqual(pushCalls.length, 1, 'an hour is dispatched once');
  await runAlarmAt(hRoom, Date.parse('2026-11-10T15:00:05.000Z'));
  assert.strictEqual(pushCalls.length, 2);
  assert.strictEqual(pushCalls[1].url, 'https://web.push.apple.com/other');
  assert.strictEqual(hRoom.state.alarmAt, Date.parse('2026-11-10T16:00:05.000Z'));
  void h;

  // ---- 7. Housekeeping ----
  const p = makeRoom(ENV);
  clock = Date.parse('2026-11-10T13:20:00.000Z');
  await call(p.room, '/store', {
    key: THEO_KEY,
    op: 'patch',
    ackOnly: true,
    patch: {
      timer_rem_old_dev: { id: 'fired_rem_old__x', pushStatus: 201 },
      timer_rem_cancelled_dev: { id: 'cancelled' },
      prayer_d1_fajr_dev: { id: '2026-11-09_fajr_1__live', expSec: 1 },
      personal_ledger: { id: 'fired_not_a_timer' }
    }
  });
  await runAlarmAt(p, Date.parse('2026-11-12T00:00:05.000Z'));
  r = await call(p.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.ok(r.json.docs.timer_rem_old_dev, 'recent terminal timer docs are kept (clients still read them)');
  await runAlarmAt(p, Date.parse('2026-11-30T00:00:05.000Z'));
  r = await call(p.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.ok(!r.json.docs.timer_rem_old_dev && !r.json.docs.timer_rem_cancelled_dev, 'terminal timer docs are purged after 14 days');
  assert.ok(r.json.docs.prayer_d1_fajr_dev, 'an armed timer doc is never purged');
  assert.ok(r.json.docs.personal_ledger, 'non-timer docs are never purged');

  // ---- 8. Delegated staff tasks ----
  clock = Date.parse('2026-11-10T13:20:00.000Z');
  const d = makeRoom(ENV);
  const OWNER_EP = 'https://web.push.apple.com/owner-device';
  await call(d.room, '/store', {
    key: THEO_KEY,
    op: 'patch',
    ackOnly: true,
    patch: {
      personal_ledger: { reminders: [{ id: 'private' }] },
      delegated_tasks: {
        rem_1: {
          id: 'rem_1',
          token: 'aabbccddeeff001122334455',
          title: 'Inspect filter press',
          delegationStatus: 'sent',
          staffNote: '',
          staffUpdatedAt: '',
          ownerPushTargets: [{ id: 'cmd', endpoint: OWNER_EP, keys: { p256dh: 'p', auth: 'a' } }],
          pushOnDone: null
        }
      }
    }
  });
  r = await call(d.room, '/store', { op: 'delegate_get', taskId: 'rem_1', token: 'wrong-token-wrong-token0' });
  assert.strictEqual(r.status, 403);
  assert.deepStrictEqual(r.json, { ok: false, error: 'Invalid or expired task link' });
  r = await call(d.room, '/store', { op: 'delegate_get', taskId: 'does-not-exist', token: 'aabbccddeeff001122334455' });
  assert.strictEqual(r.status, 403);
  r = await call(d.room, '/store', { op: 'delegate_get', taskId: '__proto__', token: 'aabbccddeeff001122334455' });
  assert.strictEqual(r.status, 403, 'prototype keys are not tasks');
  r = await call(d.room, '/store', { op: 'delegate_get', taskId: 'rem_1', token: 'aabbccddeeff001122334455' });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.json.task.title, 'Inspect filter press');
  r = await call(d.room, '/store', { op: 'delegate_update', taskId: 'rem_1', token: 'aabbccddeeff001122334455', status: 'working', staffNote: 'On it' });
  assert.strictEqual(r.json.ok, true);
  assert.strictEqual(r.json.task.delegationStatus, 'working');
  assert.strictEqual(r.json.task.staffNote, 'On it');
  assert.ok(r.json.task.staffUpdatedAt);
  r = await call(d.room, '/store', { op: 'delegate_update', taskId: 'rem_1', token: 'aabbccddeeff001122334455', status: 'owner' });
  assert.strictEqual(r.status, 400, 'unknown status values are refused');
  r = await call(d.room, '/store', { key: THEO_KEY, op: 'get_control' });
  assert.strictEqual(r.json.docs.delegated_tasks.rem_1.delegationStatus, 'working', 'owner sees the staff update');
  // a task token is not a store key
  r = await call(d.room, '/store', { op: 'get_control', taskId: 'rem_1', token: 'aabbccddeeff001122334455' });
  assert.strictEqual(r.status, 401, 'a task token must not read the store');
  r = await call(d.room, '/store', { op: 'patch', taskId: 'rem_1', token: 'aabbccddeeff001122334455', patch: { queue: {} } });
  assert.strictEqual(r.status, 401, 'a task token must not write the store');
  r = await call(d.room, '/store', { key: 'aabbccddeeff001122334455', op: 'get_control' });
  assert.strictEqual(r.status, 401);
  // staff push: owner devices of that task only
  pushCalls.length = 0;
  r = await call(d.room, '/store', { op: 'push', taskId: 'rem_1', token: 'aabbccddeeff001122334455', endpoint: OWNER_EP, vapid: 'vapid t=s', bodyB64: B64 });
  assert.deepStrictEqual(r.json, { ok: true, pushStatus: 201 });
  r = await call(d.room, '/store', { op: 'push', taskId: 'rem_1', token: 'aabbccddeeff001122334455', endpoint: APPLE, vapid: 'vapid t=s', bodyB64: B64 });
  assert.strictEqual(r.status, 403, 'a staff link cannot push to arbitrary devices');
  r = await call(d.room, '/store', { op: 'push', taskId: 'rem_1', token: 'wrong-token-wrong-token0', endpoint: OWNER_EP, vapid: 'vapid t=s', bodyB64: B64 });
  assert.strictEqual(r.status, 401);
  assert.strictEqual(pushCalls.length, 1);
  // pushOnDone pre-signed notification
  await call(d.room, '/store', {
    key: THEO_KEY,
    op: 'patch',
    ackOnly: true,
    patch: {
      delegated_tasks: {
        rem_2: { id: 'rem_2', token: 'ffeeddccbbaa998877665544', delegationStatus: 'sent', pushOnDone: { endpoint: OWNER_EP, vapid: 'vapid t=done', bodyB64: B64 } }
      }
    }
  });
  pushCalls.length = 0;
  await call(d.room, '/store', { op: 'delegate_update', taskId: 'rem_2', token: 'ffeeddccbbaa998877665544', status: 'seen' });
  assert.strictEqual(pushCalls.length, 0);
  await call(d.room, '/store', { op: 'delegate_update', taskId: 'rem_2', token: 'ffeeddccbbaa998877665544', status: 'done' });
  assert.strictEqual(pushCalls.length, 1, 'pushOnDone is sent when the task is completed');
  assert.strictEqual(pushCalls[0].headers.Authorization, 'vapid t=done');

  // ---- 9. Fitness namespace ----
  const f = makeRoom(ENV);
  r = await call(f.room, '/store/fitness', { key: THEO_KEY, op: 'get' });
  assert.strictEqual(r.status, 401, 'the THEO key must not open the fitness store');
  r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'get' });
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.json.ok, true);
  r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'patch', patch: { 'profiles/p1': { name: 'H' }, 'profiles/p1/sessions/s1': { ex: 1 } } });
  assert.deepStrictEqual(Object.keys(r.json.docs).sort(), ['profiles/p1', 'profiles/p1/sessions/s1'], 'fitness patch answers with all docs (its client replaces its cache from the response)');
  r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'patch', patch: { 'profiles/p1/sessions/s1': { _deleted: true } } });
  assert.deepStrictEqual(r.json.docs['profiles/p1/sessions/s1'], { _deleted: true }, 'tombstones are stored as sent');
  r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'patch', patch: { state: { a: 1 } } });
  r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'get' });
  assert.ok(r.json.docs.state, 'fitness has a single store: no state/control split');
  r = await call(f.room, '/store/fitness', { op: 'delegate_get', taskId: 'x', token: 'aabbccddeeff001122334455' });
  assert.strictEqual(r.status, 401, 'fitness has no delegate ops');
  r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'patch', patch: { big: 'x'.repeat(700 * 1024) } });
  assert.strictEqual(r.status, 413, 'fitness doc size cap');
  r = await call(f.room, '/store/fitness', 'x'.repeat(1100 * 1024));
  assert.strictEqual(r.status, 413, 'fitness body size cap');
  pushCalls.length = 0;
  r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'push_delay', timerKey: 'push_timer/p1', timerId: 'rest__1', delaySec: 90, endpoint: APPLE, vapid: 'vapid t=fit', bodyB64: B64 });
  assert.strictEqual(r.json.ok, true);
  await runAlarmAt(f, clock + 91000);
  assert.strictEqual(pushCalls.length, 1);
  r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'get' });
  assert.strictEqual(r.json.docs['push_timer/p1'].id, 'fired_rest__1');

  // ---- 10. Red-team H1: delayed pushes obey the same caps as patches ----
  {
    const cap = makeRoom(ENV);
    clock = Date.parse('2026-11-10T13:20:00.000Z');
    for (let batch = 0; batch < 10; batch++) {
      const patch = {};
      for (let i = 0; i < 500; i++) patch[`profiles/p/sessions/s${batch}_${i}`] = { n: i };
      const pr = await call(cap.room, '/store/fitness', { key: FIT_KEY, op: 'patch', ackOnly: true, patch });
      assert.strictEqual(pr.status, 200);
    }
    assert.strictEqual(cap.db.prepare('SELECT COUNT(*) AS n FROM docs').get().n, 5000);
    r = await call(cap.room, '/store/fitness', { key: FIT_KEY, op: 'patch', ackOnly: true, patch: { 'profiles/p/sessions/extra': { n: 1 } } });
    assert.strictEqual(r.status, 507, 'doc cap applies to patches');
    r = await call(cap.room, '/store/fitness', { key: FIT_KEY, op: 'push_delay', timerKey: 'push_timer/new', timerId: 'x__1', delaySec: 60, endpoint: APPLE, vapid: 'vapid t=cap', bodyB64: B64 });
    assert.strictEqual(r.status, 507, 'a delayed push cannot create a doc past the cap');
    assert.strictEqual(cap.db.prepare('SELECT COUNT(*) AS n FROM docs').get().n, 5000, 'doc count never exceeds maxDocs');
    assert.strictEqual(cap.db.prepare('SELECT COUNT(*) AS n FROM timers').get().n, 0, 'and no timer row is left behind');

    const ep = makeRoom(ENV);
    r = await call(ep.room, '/store/fitness', { key: FIT_KEY, op: 'push_delay', timerKey: 'push_timer/p1', timerId: 'x__1', delaySec: 60, endpoint: `https://web.push.apple.com/${'a'.repeat(3000)}`, vapid: 'vapid t=cap', bodyB64: B64 });
    assert.strictEqual(r.status, 400, 'an oversized endpoint is refused');
    assert.strictEqual(ep.db.prepare('SELECT COUNT(*) AS n FROM timers').get().n, 0);
    r = await call(ep.room, '/store/fitness', { key: FIT_KEY, op: 'push', endpoint: `https://web.push.apple.com/${'a'.repeat(3000)}`, vapid: 'vapid t=cap', bodyB64: B64 });
    assert.strictEqual(r.status, 400);
    r = await call(ep.room, '/store/fitness', { key: FIT_KEY, op: 'push_delay', timerKey: 'anything/else', timerId: 'x__1', delaySec: 60, endpoint: APPLE, vapid: 'vapid t=cap', bodyB64: B64 });
    assert.strictEqual(r.status, 400, 'delayed pushes may only use the timer key families (which the purge reclaims)');
    r = await call(ep.room, '/store/fitness', { key: FIT_KEY, op: 'push_delay', timerKey: 'push_timer/p1', timerId: 'x__1', endpoint: APPLE, vapid: 'vapid t=cap', bodyB64: B64 });
    assert.strictEqual(r.status, 400, 'a missing delaySec is refused instead of firing at once');
    r = await call(ep.room, '/store/fitness', { key: FIT_KEY, op: 'push_delay', timerKey: 'push_timer/p1', timerId: 'x__1', delaySec: 'soon', endpoint: APPLE, vapid: 'vapid t=cap', bodyB64: B64 });
    assert.strictEqual(r.status, 400);
    // cancel + re-arm churn on one key never grows the store
    for (let i = 0; i < 40; i++) {
      await call(ep.room, '/store/fitness', { key: FIT_KEY, op: 'push_delay', timerKey: 'push_timer/p1', timerId: `x__${i}`, delaySec: 60, endpoint: APPLE, vapid: 'vapid t=cap', bodyB64: B64 });
      await call(ep.room, '/store/fitness', { key: FIT_KEY, op: 'patch', ackOnly: true, patch: { 'push_timer/p1': { id: 'cancelled' } } });
    }
    assert.strictEqual(ep.db.prepare('SELECT COUNT(*) AS n FROM docs').get().n, 1);
    assert.strictEqual(ep.db.prepare('SELECT COUNT(*) AS n FROM timers').get().n, 0);
    r = await call(ep.room, '/store/fitness', { key: FIT_KEY, op: 'patch', ackOnly: true, patch: { ['bad\ud800key']: 1 } });
    assert.strictEqual(r.status, 400, 'a doc key with a lone surrogate is refused');
  }

  // ---- 11. Red-team M3: push allowlist is exact Web Push endpoints, VAPID only, no redirects ----
  for (const bad of [
    'https://api.push.apple.com/3/device/abc',
    'https://api.sandbox.push.apple.com/3/device/abc',
    'https://fcm.googleapis.com/v1/projects/p/messages:send',
    'https://fcm.googleapis.com/',
    'https://web.push.apple.com/',
    'https://evil.push.services.mozilla.com/wpush/v2/x',
    'https://updates.push.services.mozilla.com/other',
    'https://x.notify.windows.com/other'
  ]) {
    assert.ok(!isAllowedPushEndpoint(bad), `must refuse provider API or non-subscription URL ${bad}`);
  }
  assert.ok(isAllowedPushEndpoint('https://fcm.googleapis.com/wp/abc'));
  pushCalls.length = 0;
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push', endpoint: APPLE, vapid: 'Bearer ya29.provider-token', bodyB64: B64 });
  assert.strictEqual(r.status, 400, 'a non-VAPID Authorization value is refused');
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'timer_x_dev', timerId: 'x__1', delaySec: 5, endpoint: APPLE, vapid: 'Bearer ya29.provider-token', bodyB64: B64 });
  assert.strictEqual(r.status, 400);
  assert.strictEqual(pushCalls.length, 0);
  r = await call(t.room, '/store', { key: THEO_KEY, op: 'push', endpoint: APPLE, vapid: 'vapid t=abc, k=def', bodyB64: B64 });
  assert.strictEqual(pushCalls[0].redirect, 'manual', 'push fetches never follow redirects');

  // ---- 12. Red-team M1: an alarm run that crosses an hour boundary still sends the new hour's slots ----
  {
    clock = Date.parse('2026-11-10T13:20:00.000Z');
    const x = makeRoom(ENV);
    await call(x.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: { push_registry: { items: [{ id: 'dev1', endpoint: 'https://web.push.apple.com/slot-device', slots: { '2026-11-10T14': { vapid: 'vapid t=h14', bodyB64: B64 } } }] } }
    });
    clock = Date.parse('2026-11-10T13:59:00.000Z');
    await call(x.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey: 'timer_edge_dev', timerId: 'edge__1', delaySec: 59, endpoint: APPLE, vapid: 'vapid t=edge', bodyB64: B64 });
    pushCalls.length = 0;
    onPushFetch = async (url) => {
      if (url === APPLE) clock += 1500; // the timer's push is slow and ends at 14:00:00.5
    };
    await runAlarmAt(x, Date.parse('2026-11-10T13:59:59.000Z'));
    onPushFetch = null;
    assert.deepStrictEqual(pushCalls.map((c) => c.headers.Authorization), ['vapid t=edge', 'vapid t=h14'], 'the hour that began during the run is dispatched in the same run');
    assert.strictEqual(x.state.alarmAt, Date.parse('2026-11-10T15:00:05.000Z'));
    await runAlarmAt(x, Date.parse('2026-11-10T14:30:00.000Z'));
    assert.strictEqual(pushCalls.length, 2, 'and is not dispatched again');
  }

  // ---- 13. Red-team M5: interleaving across the await inside a timer send ----
  {
    clock = Date.parse('2026-11-10T13:20:00.000Z');
    const y = makeRoom(ENV);
    const arm = (timerKey, timerId, delaySec, tag) =>
      call(y.room, '/store', { key: THEO_KEY, op: 'push_delay', timerKey, timerId, delaySec, endpoint: APPLE, vapid: `vapid t=${tag}`, bodyB64: B64 });
    await arm('timer_a_dev', 'a__1', 10, 'a1');
    await arm('timer_b_dev', 'b__1', 10, 'b1');
    pushCalls.length = 0;
    let reArmed = false;
    onPushFetch = async () => {
      if (reArmed) return;
      reArmed = true;
      await arm('timer_a_dev', 'a__2', 600, 'a2'); // re-arm the timer that is being sent
      await arm('timer_b_dev', 'b__2', 600, 'b2'); // and one that is already in this run's due list
    };
    await runAlarmAt(y, clock + 11000);
    onPushFetch = null;
    assert.deepStrictEqual(pushCalls.map((c) => c.headers.Authorization), ['vapid t=a1'], 'exactly one push in that run');
    r = await call(y.room, '/store', { key: THEO_KEY, op: 'get_control' });
    assert.strictEqual(r.json.docs.timer_a_dev.id, 'a__2', 'a re-arm during the send is not overwritten by the fired_ stamp');
    assert.strictEqual(r.json.docs.timer_b_dev.id, 'b__2');
    assert.strictEqual(y.db.prepare('SELECT COUNT(*) AS n FROM timers').get().n, 2, 'both re-armed timers are still pending');
    await runAlarmAt(y, clock + 601000);
    assert.deepStrictEqual(pushCalls.map((c) => c.headers.Authorization).sort(), ['vapid t=a1', 'vapid t=a2', 'vapid t=b2'], 'the new ids fire later, the superseded b__1 never does');

    // cancel while the push is on the wire: the doc stays cancelled
    await arm('timer_c_dev', 'c__1', 10, 'c1');
    onPushFetch = async () => {
      onPushFetch = null;
      await call(y.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { timer_c_dev: { id: 'cancelled' } } });
    };
    await runAlarmAt(y, clock + 11000);
    r = await call(y.room, '/store', { key: THEO_KEY, op: 'get_control' });
    assert.strictEqual(r.json.docs.timer_c_dev.id, 'cancelled');

    // a send that dies mid-flight is never sent a second time, and the stuck doc is purged later
    await arm('timer_d_dev', 'd__1', 10, 'd1');
    pushCalls.length = 0;
    const realSend = y.room._sendPush.bind(y.room);
    y.room._sendPush = async () => {
      throw new Error('object reset mid-send');
    };
    await runAlarmAt(y, clock + 11000);
    y.room._sendPush = realSend;
    r = await call(y.room, '/store', { key: THEO_KEY, op: 'get_control' });
    assert.strictEqual(r.json.docs.timer_d_dev.id, 'sending_d__1');
    await runAlarmAt(y, clock + 60000);
    assert.strictEqual(pushCalls.length, 0, 'an interrupted send is at-most-once: no re-send');
    await runAlarmAt(y, clock + 16 * 86400 * 1000);
    r = await call(y.room, '/store', { key: THEO_KEY, op: 'get_control' });
    assert.ok(!('timer_d_dev' in r.json.docs), 'a stuck sending_ doc is purged after the retention window');
  }

  // ---- 14. Staff view never exposes the pre-signed completion notice; it is sent once ----
  {
    clock = Date.parse('2026-11-10T13:20:00.000Z');
    const s = makeRoom(ENV);
    await call(s.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: { delegated_tasks: { rem_9: { id: 'rem_9', token: '112233445566778899aabbcc', delegationStatus: 'sent', pushOnDone: { endpoint: 'https://web.push.apple.com/owner', vapid: 'vapid t=done9', bodyB64: B64 } } } }
    });
    r = await call(s.room, '/store', { op: 'delegate_get', taskId: 'rem_9', token: '112233445566778899aabbcc' });
    assert.strictEqual(r.json.task.pushOnDone, true, 'staff see only that a completion notice exists');
    assert.ok(!r.text.includes('vapid t=done9'));
    pushCalls.length = 0;
    for (let i = 0; i < 3; i++) {
      r = await call(s.room, '/store', { op: 'delegate_update', taskId: 'rem_9', token: '112233445566778899aabbcc', status: 'done' });
      assert.ok(!r.text.includes('vapid t=done9'));
    }
    assert.strictEqual(pushCalls.length, 1, 'the completion notice is sent on the transition into done only');
    r = await call(s.room, '/store', { key: THEO_KEY, op: 'get_control' });
    assert.strictEqual(r.json.docs.delegated_tasks.rem_9.pushOnDone.vapid, 'vapid t=done9', 'the owner still sees the full task');
  }

  // ---- 15. Equal hosts: the store, not a PC, decides which host is the coordinator ----
  {
    clock = Date.parse('2026-11-10T15:00:00.000Z');
    const e = makeRoom(ENV);
    const poll = (deviceId) =>
      call(e.room, '/store', { key: THEO_KEY, op: 'get_control', ...(deviceId !== undefined ? { deviceId } : {}) });

    r = await poll(undefined);
    assert.ok(!('coordinator' in r.json), 'a phone names no device and takes no part in the duty');
    r = await poll('pc-a');
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a', 'the first host to poll holds the duty');
    assert.strictEqual(r.json.coordinator.ttlMs, 90000);
    const sinceA = r.json.coordinator.since;
    assert.strictEqual(sinceA, clock);
    clock += 5000;
    r = await poll('pc-b');
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a', 'a second host does not take the duty from a live holder');
    for (let i = 0; i < 40; i++) {
      clock += 4500;
      r = await poll('pc-a');
      assert.strictEqual(r.json.coordinator.deviceId, 'pc-a');
      r = await poll('pc-b');
      assert.strictEqual(r.json.coordinator.deviceId, 'pc-a', 'the duty does not flap between two live hosts');
    }
    assert.strictEqual(r.json.coordinator.since, sinceA, 'the holder keeps its original start time');
    // The holder goes quiet. The other host keeps polling and takes over only after the lease has run out.
    clock += 60000;
    r = await poll('pc-b');
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a', 'not before the holder has been silent for the full lease');
    clock += 31000;
    r = await poll('pc-b');
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-b', 'the duty moves to the host that is still polling');
    assert.strictEqual(r.json.coordinator.since, clock);
    clock += 1000;
    r = await poll('pc-a');
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-b', 'the old holder does not take it back when it returns');
    // With every host silent past the lease, nobody is named until a host polls again.
    clock += 200000;
    r = await poll('pc-a');
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a');
    assert.strictEqual(r.json.coordinator.since, clock);

    for (const bad of ['bad id!', 'x'.repeat(81), '', { id: 'pc-a' }, 42]) {
      r = await poll(bad);
      assert.strictEqual(r.status, 200);
      assert.ok(!('coordinator' in r.json), 'an invalid device id takes no part');
    }
    assert.ok(!('host_lease' in r.json.docs), 'the duty is not a document clients can patch');
    r = await call(e.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { host_lease: { deviceId: 'pc-evil' } } });
    r = await poll('pc-b');
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a', 'a document named host_lease does not move the duty');
    r = await call(e.room, '/store', { key: THEO_KEY, op: 'get_theo', deviceId: 'pc-b' });
    assert.ok(!('coordinator' in r.json), 'only get_control takes part in the duty');
    const fitE = makeRoom(ENV);
    r = await call(fitE.room, '/store/fitness', { key: FIT_KEY, op: 'get_control', deviceId: 'pc-a' });
    assert.ok(!('coordinator' in r.json), 'the fitness store has no hosts');

    // ---- command claims: a queued command runs on exactly one host ----
    const claim = (claimKey, deviceId, extra = {}) =>
      call(e.room, '/store', { key: THEO_KEY, op: 'claim', claimKey, deviceId, ...extra });
    r = await claim('cmd:abc', 'pc-a');
    assert.deepStrictEqual([r.status, r.json.claimed, r.json.by], [200, true, 'pc-a']);
    r = await claim('cmd:abc', 'pc-b');
    assert.deepStrictEqual([r.json.claimed, r.json.by], [false, 'pc-a'], 'the second host is told who owns it');
    r = await claim('cmd:abc', 'pc-a');
    assert.strictEqual(r.json.claimed, true, 'asking again as the owner is safe');
    await claim('cmd:abc', 'pc-b', { release: true });
    r = await claim('cmd:abc', 'pc-b');
    assert.strictEqual(r.json.claimed, false, 'only the owner can release a claim');
    await claim('cmd:abc', 'pc-a', { release: true });
    r = await claim('cmd:abc', 'pc-b');
    assert.strictEqual(r.json.claimed, true, 'a released command can be claimed by another host');
    const racers = await Promise.all(['pc-a', 'pc-b', 'pc-c'].map((id) => claim('cmd:race', id)));
    assert.strictEqual(racers.filter((x) => x.json.claimed).length, 1, 'three hosts racing: exactly one wins');
    assert.strictEqual((await claim('', 'pc-a')).status, 400);
    assert.strictEqual((await claim('cmd:x', '')).status, 400);
    assert.strictEqual((await claim('cmd:x', 'bad id')).status, 400);
    assert.strictEqual((await claim('x'.repeat(201), 'pc-a')).status, 400);
    assert.strictEqual((await call(e.room, '/store', { op: 'claim', claimKey: 'cmd:z', deviceId: 'pc-a' })).status, 401);
    assert.strictEqual((await call(e.room, '/store', { key: 'wrong-key-wrong-key-wrong-key', op: 'claim', claimKey: 'cmd:z', deviceId: 'pc-a' })).status, 401);
    assert.strictEqual((await call(fitE.room, '/store/fitness', { key: FIT_KEY, op: 'claim', claimKey: 'cmd:z', deviceId: 'pc-a' })).status, 400, 'the fitness store has no claims');
    r = await call(e.room, '/store', { key: THEO_KEY, op: 'get_theo' });
    assert.ok(!Object.keys(r.json.docs).some((k) => k.startsWith('cmd:')), 'claims are not documents');
    await runAlarmAt(e, clock + 2 * 86400 * 1000);
    r = await claim('cmd:race', 'pc-z');
    assert.strictEqual(r.json.claimed, false, 'a claim outlives any command that could still be in the queue');
    await runAlarmAt(e, clock + 31 * 86400 * 1000);
    r = await claim('cmd:race', 'pc-z');
    assert.strictEqual(r.json.claimed, true, 'claims older than 30 days are purged');

    // ---- a host on a build from before equal hosts is detected by what only it writes, on the store's clock ----
    clock = Date.parse('2026-12-20T09:00:00.000Z');
    const g = makeRoom(ENV);
    const pollG = (deviceId) => call(g.room, '/store', { key: THEO_KEY, op: 'get_control', deviceId });
    r = await pollG('pc-a');
    assert.strictEqual(r.json.coordinator.legacyLead, false);
    // The old build's cycle: state + primary_state + threads in one patch, with whatever clock that PC has.
    await call(g.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: { meta: { v: 3, updatedAt: '2020-01-01T00:00:00.000Z', deviceId: 'old-host' }, state: { snapshot: {} }, primary_state: { snapshot: { rows: [] } }, threads: {} }
    });
    r = await pollG('pc-a');
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a');
    assert.strictEqual(r.json.coordinator.legacyLead, true, 'the named coordinator is told to stand back');
    clock += 60000;
    r = await pollG('pc-a');
    assert.strictEqual(r.json.coordinator.legacyLead, true);
    clock += 31000;
    r = await pollG('pc-a');
    assert.strictEqual(r.json.coordinator.legacyLead, false, 'once that host has been silent for the lease, the duty is live again');
    // A host on the new build never writes primary_state, so its own patches do not raise the flag.
    await call(g.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { meta: { v: 4, deviceId: 'pc-a' }, state: { snapshot: {} }, threads: {} } });
    r = await pollG('pc-a');
    assert.strictEqual(r.json.coordinator.legacyLead, false);
  }

  // ---- 16. Equal hosts: device_states is merged per device, so one host can never overwrite another ----
  {
    clock = Date.parse('2026-11-10T15:00:00.000Z');
    const d = makeRoom(ENV);
    const patchDS = (ds) =>
      call(d.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { threads: {}, device_states: ds } });
    const readDS = async () => (await call(d.room, '/store', { key: THEO_KEY, op: 'get_theo' })).json.docs.device_states;
    const entry = (name, rowIds, updatedAt) => ({ device: { name }, snapshot: { rows: rowIds.map((id) => ({ id })) }, updatedAt });

    await patchDS({ 'pc-a': entry('A', ['a1'], clock) });
    await patchDS({ 'pc-b': entry('B', ['b1'], clock) });
    let ds = await readDS();
    assert.deepStrictEqual(Object.keys(ds).sort(), ['pc-a', 'pc-b'], 'a host that sends only its own entry leaves the others in place');

    clock += 10000;
    await patchDS({ 'pc-b': entry('B', ['b1', 'b2'], clock) });
    // pc-a (for example an older build) sends the whole map with a cached, older copy of pc-b.
    r = await patchDS({ 'pc-a': entry('A', ['a1', 'a2'], clock + 1000), 'pc-b': entry('B', ['b1'], clock - 10000) });
    assert.strictEqual(r.status, 200);
    ds = await readDS();
    assert.deepStrictEqual(ds['pc-b'].snapshot.rows.map((x) => x.id), ['b1', 'b2'], 'a stale copy never rolls a host back');
    assert.deepStrictEqual(ds['pc-a'].snapshot.rows.map((x) => x.id), ['a1', 'a2']);

    await patchDS({ 'pc-old': entry('Old', ['o1'], clock - 31 * 86400 * 1000) });
    ds = await readDS();
    assert.ok(!('pc-old' in ds), 'an entry past the retention window is refused');
    await patchDS({ 'pc-b': null });
    ds = await readDS();
    assert.deepStrictEqual(Object.keys(ds), ['pc-a'], 'null removes one device');
    await patchDS({ 'bad id': entry('X', [], clock), 'pc-d': 'nope', 'pc-e': [1, 2] });
    ds = await readDS();
    assert.deepStrictEqual(Object.keys(ds), ['pc-a'], 'invalid ids and non-object entries are ignored');
    await patchDS({ 'pc-f': { device: { name: 'F', lastSeen: clock } } });
    ds = await readDS();
    assert.ok('pc-f' in ds, 'device.lastSeen counts as the stamp when updatedAt is missing');

    clock += 31 * 86400 * 1000;
    await patchDS({ 'pc-c': entry('C', ['c1'], clock) });
    ds = await readDS();
    assert.deepStrictEqual(Object.keys(ds), ['pc-c'], 'a host not heard from for 30 days leaves the fleet');

    const many = {};
    for (let i = 0; i < 40; i++) many[`pc-n${i}`] = entry(`N${i}`, [], clock - i * 1000);
    await patchDS(many);
    ds = await readDS();
    assert.strictEqual(Object.keys(ds).length, 32, 'the fleet map is capped');
    assert.ok('pc-n0' in ds && !('pc-n39' in ds), 'the cap keeps the most recent hosts');

    // A host is the only authority on itself, and its entry is stamped on the store's clock, not the PC's.
    {
      const o = makeRoom(ENV);
      const patchAs = (ownerId, ds) =>
        call(o.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { meta: { deviceId: ownerId }, threads: {}, device_states: ds } });
      const readO = async () => (await call(o.room, '/store', { key: THEO_KEY, op: 'get_theo' })).json.docs.device_states;
      // pc-a's clock is a day ahead.
      await patchAs('pc-a', { 'pc-a': entry('A', ['a1'], clock + 86400 * 1000) });
      let os1 = await readO();
      assert.strictEqual(os1['pc-a'].updatedAt, clock, 'the sender\'s own entry carries the store\'s time');
      // Its clock is corrected (now a day behind what it sent before): the new write still wins.
      clock += 5000;
      await patchAs('pc-a', { 'pc-a': entry('A', ['a1', 'a2'], clock - 86400 * 1000) });
      os1 = await readO();
      assert.deepStrictEqual(os1['pc-a'].snapshot.rows.map((x) => x.id), ['a1', 'a2'], 'a host whose clock was wrong is never locked out of its own entry');
      assert.strictEqual(os1['pc-a'].updatedAt, clock);
      // Another host cannot overwrite pc-a with a copy claiming to be from the future...
      await patchAs('pc-b', { 'pc-b': entry('B', ['b1'], 1), 'pc-a': entry('A', ['forged'], 9e15) });
      os1 = await readO();
      assert.strictEqual(os1['pc-a'].updatedAt, clock, 'a stamp ahead of the store clock is not believed');
      assert.deepStrictEqual(os1['pc-a'].snapshot.rows.map((x) => x.id), ['a1', 'a2'], 'and the stored entry is left as it was');
      assert.strictEqual(os1['pc-b'].updatedAt, clock, 'the sender\'s own entry is taken whatever stamp it carries');
      // ...and pc-a takes its entry back on its next write.
      clock += 5000;
      await patchAs('pc-a', { 'pc-a': entry('A', ['a1', 'a2', 'a3'], clock) });
      os1 = await readO();
      assert.deepStrictEqual(os1['pc-a'].snapshot.rows.map((x) => x.id), ['a1', 'a2', 'a3']);
      // An entry stored with a future stamp ages out instead of staying "online" for ever.
      const p = makeRoom(ENV);
      await call(p.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { threads: {}, device_states: { 'pc-x': entry('X', [], clock + 400 * 86400 * 1000) } } });
      let ps = (await call(p.room, '/store', { key: THEO_KEY, op: 'get_theo' })).json.docs.device_states;
      assert.strictEqual(ps['pc-x'].updatedAt, clock);
      clock += 31 * 86400 * 1000;
      await call(p.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { threads: {}, device_states: { 'pc-y': entry('Y', [], clock) } } });
      ps = (await call(p.room, '/store', { key: THEO_KEY, op: 'get_theo' })).json.docs.device_states;
      assert.deepStrictEqual(Object.keys(ps), ['pc-y']);
    }

    // Every other document is still replaced whole.
    await call(d.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { queue: { a: 1 } } });
    await call(d.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { queue: { b: 2 } } });
    r = await call(d.room, '/store', { key: THEO_KEY, op: 'get_control' });
    assert.deepStrictEqual(r.json.docs.queue, { b: 2 });

    // The merge applies in whichever store the patch lands.
    const c = makeRoom(ENV);
    await call(c.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { device_states: { 'pc-a': entry('A', [], clock) } } });
    await call(c.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { device_states: { 'pc-b': entry('B', [], clock) } } });
    r = await call(c.room, '/store', { key: THEO_KEY, op: 'get_control' });
    assert.deepStrictEqual(Object.keys(r.json.docs.device_states).sort(), ['pc-a', 'pc-b']);
    await call(c.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, patch: { device_states: null } });
    r = await call(c.room, '/store', { key: THEO_KEY, op: 'get_control' });
    assert.ok(!('device_states' in r.json.docs), 'null still deletes the whole document');

    // The fitness store has no hosts: device_states there is an ordinary document.
    const f = makeRoom(ENV);
    await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'patch', ackOnly: true, patch: { device_states: { a: { updatedAt: clock } } } });
    await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'patch', ackOnly: true, patch: { device_states: { b: { updatedAt: clock } } } });
    r = await call(f.room, '/store/fitness', { key: FIT_KEY, op: 'get' });
    assert.deepStrictEqual(Object.keys(r.json.docs.device_states), ['b']);
  }

  // ---- 17. Self-arming Shia Ja'fari prayer Web Push timers (indefinite zero-PC operation) ----
  {
    clock = Date.parse('2026-11-10T01:00:00.000Z');
    const pr = makeRoom(ENV);
    const ecdhSub = nodeCrypto.createECDH('prime256v1');
    ecdhSub.generateKeys();
    const subPubB64u = ecdhSub.getPublicKey().toString('base64url');
    const subAuth = nodeCrypto.randomBytes(16);
    const subAuthB64u = subAuth.toString('base64url');
    const subEndpoint = 'https://web.push.apple.com/prayer-sub-1';

    function decryptAes128GcmPush(rawBody) {
      const salt = rawBody.subarray(0, 16);
      const idLen = rawBody[20];
      const serverPub = rawBody.subarray(21, 21 + idLen);
      const ciphertextWithTag = rawBody.subarray(21 + idLen);
      const sharedSecret = ecdhSub.computeSecret(serverPub);
      const hkdf = (s, ikm, info, len) => {
        const prk = nodeCrypto.createHmac('sha256', s.length ? s : Buffer.alloc(32)).update(ikm).digest();
        return nodeCrypto.createHmac('sha256', prk).update(Buffer.concat([info, Buffer.from([1])])).digest().subarray(0, len);
      };
      const keyInfo = Buffer.concat([Buffer.from('WebPush: info\0', 'utf8'), ecdhSub.getPublicKey(), serverPub]);
      const ikm = hkdf(subAuth, sharedSecret, keyInfo, 32);
      const cek = hkdf(salt, ikm, Buffer.from('Content-Encoding: aes128gcm\0', 'utf8'), 16);
      const nonce = hkdf(salt, ikm, Buffer.from('Content-Encoding: nonce\0', 'utf8'), 12);
      const tag = ciphertextWithTag.subarray(ciphertextWithTag.length - 16);
      const encData = ciphertextWithTag.subarray(0, ciphertextWithTag.length - 16);
      const decipher = nodeCrypto.createDecipheriv('aes-128-gcm', cek, nonce);
      decipher.setAuthTag(tag);
      const dec = Buffer.concat([decipher.update(encData), decipher.final()]);
      assert.strictEqual(dec[dec.length - 1], 0x02, 'RFC 8291 record delimiter must be 0x02');
      return JSON.parse(dec.subarray(0, dec.length - 1).toString('utf8'));
    }

    async function verifyVapidHeader(authHeader, expectedOrigin) {
      const m = /^vapid\s+t=([^,]+),\s*k=([A-Za-z0-9_-]+)$/.exec(authHeader || '');
      assert.ok(m, 'VAPID Authorization header format');
      const [hdrB64, pldB64, sigB64] = m[1].split('.');
      const pubBytes = Buffer.from(m[2], 'base64url');
      const verifyKey = await globalThis.crypto.subtle.importKey(
        'raw',
        pubBytes,
        { name: 'ECDSA', namedCurve: 'P-256' },
        false,
        ['verify']
      );
      const ok = await globalThis.crypto.subtle.verify(
        { name: 'ECDSA', hash: 'SHA-256' },
        verifyKey,
        Buffer.from(sigB64, 'base64url'),
        Buffer.from(`${hdrB64}.${pldB64}`, 'utf8')
      );
      assert.strictEqual(ok, true, 'VAPID ES256 signature must verify against public key k');
      const claims = JSON.parse(Buffer.from(pldB64, 'base64url').toString('utf8'));
      assert.strictEqual(claims.aud, expectedOrigin);
    }

    pushCalls.length = 0;
    await call(pr.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        personal_ledger: {
          prayerConfig: {
            enabled: true,
            lat: 33.8938,
            lon: 35.5018,
            tzOffsetMin: 120,
            locationName: 'Beirut',
            preRemindMin: 15,
            notifyFajr: true,
            notifyDhuhr: true,
            notifyMaghrib: true
          },
          updatedAt: clock
        },
        push_registry: {
          items: [
            {
              id: 'cmd_iphone1',
              app: 'command',
              endpoint: subEndpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, prayers: true }
            },
            // Duplicate physical endpoint under another id must be deduplicated so user never gets double alerts
            {
              id: 'cmd_iphone1_dup',
              app: 'command',
              endpoint: subEndpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, prayers: true }
            }
          ]
        }
      }
    });

    r = await call(pr.room, '/store', { key: THEO_KEY, op: 'get_control' });
    const initialPrayerKeys = Object.keys(r.json.docs).filter((k) => k.startsWith('prayer_d'));
    assert.strictEqual(initialPrayerKeys.length, 24, '4 days x 3 prayers x (pre + main) = 24 armed prayer slots for 1 deduped subscriber');

    // Step alarms across 8 full days with ZERO PC requests: days 5..8 must keep arming and firing!
    const startClock = clock;
    const dayCounts = new Array(8).fill(0);
    for (let h = 1; h <= 8 * 24; h++) {
      const targetTs = startClock + h * 3600 * 1000;
      const before = pushCalls.length;
      while (pr.state.alarmAt && pr.state.alarmAt <= targetTs) {
        await runAlarmAt(pr, pr.state.alarmAt);
      }
      await runAlarmAt(pr, targetTs);
      const firedNow = pushCalls.length - before;
      const dayIdx = Math.min(7, Math.floor(((h - 1) * 3600 * 1000) / (86400 * 1000)));
      dayCounts[dayIdx] += firedNow;
    }
    for (let dIdx = 0; dIdx < 8; dIdx++) {
      assert.strictEqual(
        dayCounts[dIdx],
        6,
        `Day ${dIdx + 1} with zero PCs online must fire all 6 Shia Ja'fari prayer pushes (3 pre + 3 main), got ${dayCounts[dIdx]}`
      );
    }
    // Decrypt and verify one of the fired Web Push payloads + VAPID JWT
    const samplePush = pushCalls.find((c) => c.url === subEndpoint && c.rawBody.length > 80);
    assert.ok(samplePush, 'must capture encrypted prayer push payload');
    await verifyVapidHeader(samplePush.headers.Authorization, 'https://web.push.apple.com');
    const sampleJson = decryptAes128GcmPush(samplePush.rawBody);
    assert.strictEqual(sampleJson.tab, 'prayers');
    assert.strictEqual(sampleJson.openPrayer, true);
    assert.ok(sampleJson.title.includes('Prayer') || sampleJson.title.includes('in 15 min'));

    // Disabling Fajr cancels pending Fajr slots while keeping Dhuhr & Maghrib armed
    await call(pr.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        personal_ledger: {
          prayerConfig: {
            enabled: true,
            lat: 33.8938,
            lon: 35.5018,
            tzOffsetMin: 120,
            locationName: 'Beirut',
            preRemindMin: 15,
            notifyFajr: false,
            notifyDhuhr: true,
            notifyMaghrib: true
          },
          updatedAt: clock + 1000
        }
      }
    });
    r = await call(pr.room, '/store', { key: THEO_KEY, op: 'get_control' });
    const fajrDocs = Object.entries(r.json.docs).filter(([k]) => k.includes('_fajr_'));
    const dhuhrDocs = Object.entries(r.json.docs).filter(([k, v]) => k.includes('_dhuhr_') && v.id !== 'cancelled' && !String(v.id).startsWith('fired_'));
    assert.ok(fajrDocs.every(([, v]) => v.id === 'cancelled' || String(v.id).startsWith('fired_')), 'pending Fajr timers must cancel when notifyFajr=false');
    assert.ok(dhuhrDocs.length >= 6, 'Dhuhr timers remain armed');

    // Disabling prayers entirely cancels all pending prayer timers
    await call(pr.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        personal_ledger: {
          prayerConfig: { enabled: false },
          updatedAt: clock + 2000
        }
      }
    });
    r = await call(pr.room, '/store', { key: THEO_KEY, op: 'get_control' });
    const stillArmed = Object.entries(r.json.docs).filter(
      ([k, v]) => k.startsWith('prayer_d') && v.id !== 'cancelled' && !String(v.id).startsWith('fired_')
    );
    assert.strictEqual(stillArmed.length, 0, 'disabling prayerConfig cancels every pending prayer timer');

    // Non-Beirut `lon` coordinate alias + multi-subscriber opt-out cleanup (Red-Team High #6)
    const multiPr = makeRoom(ENV);
    const sub2Endpoint = 'https://fcm.googleapis.com/fcm/send/android-tablet-2';
    clock = Date.parse('2026-11-10T01:00:00.000Z');
    await call(multiPr.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        personal_ledger: {
          prayerConfig: {
            enabled: true,
            lat: 33.8938,
            lon: 35.5018,
            timeZone: 'Asia/Beirut',
            locationName: 'Beirut',
            preRemindMin: 0,
            notifyFajr: true,
            notifyDhuhr: true,
            notifyMaghrib: true
          },
          updatedAt: clock
        },
        push_registry: {
          items: [
            {
              id: 'cmd_ios_keep',
              app: 'command',
              ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)',
              endpoint: subEndpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, prayers: true }
            },
            {
              id: 'cmd_and_drop',
              app: 'command',
              ua: 'Mozilla/5.0 (Linux; Android 15; Pixel 9)',
              endpoint: sub2Endpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, prayers: true }
            }
          ]
        }
      }
    });
    const beirutTimers = multiPr.db.prepare("SELECT timer_key, fire_at FROM timers WHERE timer_key GLOB 'prayer_d*'").all();
    assert.strictEqual(beirutTimers.length, 24, '2 distinct Planner devices x 4 days x 3 main prayers = 24 timers');
    const beirutDhuhrFire = beirutTimers.find((t) => t.timer_key.includes('_dhuhr_cmdioskeep')).fire_at;
    assert.ok(beirutDhuhrFire > 0);

    // Switch coordinates via `lon` (no `lng`) to New York: fire_at must shift by hours, proving `lon` is honoured
    await call(multiPr.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        personal_ledger: {
          prayerConfig: {
            enabled: true,
            lat: 40.7128,
            lon: -74.006,
            timeZone: 'America/New_York',
            locationName: 'New York',
            preRemindMin: 0,
            notifyFajr: true,
            notifyDhuhr: true,
            notifyMaghrib: true
          },
          updatedAt: clock + 500
        }
      }
    });
    const nyTimers = multiPr.db.prepare("SELECT timer_key, fire_at FROM timers WHERE timer_key GLOB 'prayer_d*'").all();
    const nyDhuhrFire = nyTimers.find((t) => t.timer_key.includes('_dhuhr_cmdioskeep')).fire_at;
    assert.ok(
      Math.abs(nyDhuhrFire - beirutDhuhrFire) > 5 * 3600 * 1000,
      `lon=-74.006 (New York) must shift Dhuhr fire_at by >5h vs Beirut (got delta ${nyDhuhrFire - beirutDhuhrFire}ms)`
    );

    // Second subscriber opts out (`prefs.prayers = false`) while first subscriber stays active:
    // opted-out device's pending timers must be immediately purged while active device's 12 stay armed!
    await call(multiPr.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        push_registry: {
          items: [
            {
              id: 'cmd_ios_keep',
              app: 'command',
              ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)',
              endpoint: subEndpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, prayers: true }
            },
            {
              id: 'cmd_and_drop',
              app: 'command',
              ua: 'Mozilla/5.0 (Linux; Android 15; Pixel 9)',
              endpoint: sub2Endpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, prayers: false }
            }
          ]
        }
      }
    });
    const afterOptOutTimers = multiPr.db.prepare("SELECT timer_key FROM timers WHERE timer_key GLOB 'prayer_d*'").all();
    assert.strictEqual(
      afterOptOutTimers.filter((t) => t.timer_key.endsWith('_cmdanddrop')).length,
      0,
      'opted-out device must have 0 pending prayer timers left'
    );
    assert.strictEqual(
      afterOptOutTimers.filter((t) => t.timer_key.endsWith('_cmdioskeep')).length,
      12,
      'remaining opted-in device keeps all 12 pending prayer timers'
    );

    // Fitness namespace never self-arms prayer timers
    const fitPr = makeRoom(ENV);
    await call(fitPr.room, '/store/fitness', {
      key: FIT_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        personal_ledger: { prayerConfig: { enabled: true } },
        push_registry: { items: [{ id: 'cmd_fit', app: 'command', endpoint: subEndpoint, keys: { p256dh: subPubB64u, auth: subAuthB64u } }] }
      }
    });
    r = await call(fitPr.room, '/store/fitness', { key: FIT_KEY, op: 'get' });
    assert.strictEqual(Object.keys(r.json.docs).filter((k) => k.startsWith('prayer_')).length, 0, 'fitness namespace never arms prayer timers');
  }

  // ---- 18. Activity-based coordinator handoff (last-typed PC wins with hysteresis) ----
  {
    clock = Date.parse('2026-11-10T18:00:00.000Z');
    const act = makeRoom(ENV);

    // pc-a connects without recent input (or idle) -> takes initial duty
    r = await call(act.room, '/store', { key: THEO_KEY, op: 'get_control', deviceId: 'pc-a', idleMs: 400000 });
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a');

    // pc-b reports fresh typing (idleMs: 1200ms <= 5min) -> immediately takes duty from idle pc-a
    clock += 2000;
    r = await call(act.room, '/store', { key: THEO_KEY, op: 'get_control', deviceId: 'pc-b', idleMs: 1200 });
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-b', 'newly typed-on PC takes coordinator duty');

    // Minor jitter within 15s hysteresis window does NOT flap duty back to pc-a
    clock += 3000;
    r = await call(act.room, '/store', { key: THEO_KEY, op: 'get_control', deviceId: 'pc-a', idleMs: 1000 });
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-b', '15s hysteresis prevents rapid flapping');

    // 25s later, user actively types on pc-a (idleMs: 400ms -> >15s fresher than pc-b) -> duty hands to pc-a
    clock += 25000;
    r = await call(act.room, '/store', { key: THEO_KEY, op: 'get_control', deviceId: 'pc-a', idleMs: 400 });
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a', 'sustained typing on pc-a takes coordinator duty');

    // Negative idleMs cannot forge a future lastActiveAt timestamp
    clock += 1000;
    r = await call(act.room, '/store', { key: THEO_KEY, op: 'get_control', deviceId: 'pc-b', idleMs: -99999999 });
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a', 'clamped negative idleMs cannot beat 15s hysteresis');

    // Once user walks away (>5m idle on both PCs), duty stays sticky on pc-a without flapping
    clock += 10 * 60 * 1000;
    await call(act.room, '/store', { key: THEO_KEY, op: 'get_control', deviceId: 'pc-a', idleMs: 600000 });
    r = await call(act.room, '/store', { key: THEO_KEY, op: 'get_control', deviceId: 'pc-b', idleMs: 600000 });
    assert.strictEqual(r.json.coordinator.deviceId, 'pc-a', 'duty remains sticky on last-typed PC when both go idle');
  }

  // ---- 19. Lease-bounded command claims (mid-run crash recovery + permanent completion seal) ----
  {
    clock = Date.parse('2026-11-10T19:00:00.000Z');
    const cl = makeRoom(ENV);
    const createdAt = 1762800000000;
    const cmdId = 'cmd-crash-recover-1';
    const claimKey = `cmd:${nodeCrypto.createHash('sha256').update(`${cmdId}:${createdAt}`, 'utf8').digest('hex')}`;

    // pc-a acquires a 60s in-flight lease
    r = await call(cl.room, '/store', { key: THEO_KEY, op: 'claim', claimKey, deviceId: 'pc-a', leaseMs: 60000 });
    assert.strictEqual(r.json.claimed, true);
    assert.strictEqual(r.json.leaseUntil, clock + 60000);

    // During lease, pc-b is blocked and told when the lease expires
    clock += 30000;
    r = await call(cl.room, '/store', { key: THEO_KEY, op: 'claim', claimKey, deviceId: 'pc-b', leaseMs: 60000 });
    assert.strictEqual(r.json.claimed, false);
    assert.strictEqual(r.json.by, 'pc-a');
    assert.strictEqual(r.json.leaseUntil, Date.parse('2026-11-10T19:00:00.000Z') + 60000);

    // pc-a crashes mid-run; once 60s lease expires, pc-b takes over the claim!
    clock += 31000;
    r = await call(cl.room, '/store', { key: THEO_KEY, op: 'claim', claimKey, deviceId: 'pc-b', leaseMs: 60000 });
    assert.strictEqual(r.json.claimed, true);
    assert.strictEqual(r.json.by, 'pc-b');

    // pc-b finishes and patches queue status='done' -> store seals the claim permanently (expires_at = 0)
    await call(cl.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        queue: {
          commands: [{ id: cmdId, createdAt, status: 'done', completedAt: clock }]
        }
      }
    });

    // Even 5 days later (long past 60s lease, within 30d retention), neither PC can re-claim a completed command
    clock += 5 * 86400 * 1000;
    r = await call(cl.room, '/store', { key: THEO_KEY, op: 'claim', claimKey, deviceId: 'pc-a', leaseMs: 60000 });
    assert.strictEqual(r.json.claimed, false);
    assert.strictEqual(r.json.by, 'pc-b');
    assert.strictEqual(r.json.leaseUntil, undefined, 'sealed completed claim has no leaseUntil');

    // Explicit sealClaims array on patch also seals direct-command claims permanently
    const directClaimKey = `cmd:${nodeCrypto.createHash('sha256').update('cmd-direct-seal:1', 'utf8').digest('hex')}`;
    r = await call(cl.room, '/store', { key: THEO_KEY, op: 'claim', claimKey: directClaimKey, deviceId: 'pc-a', leaseMs: 60000 });
    assert.strictEqual(r.json.claimed, true);
    await call(cl.room, '/store', { key: THEO_KEY, op: 'patch', ackOnly: true, sealClaims: [directClaimKey], patch: {} });
    clock += 120000;
    r = await call(cl.room, '/store', { key: THEO_KEY, op: 'claim', claimKey: directClaimKey, deviceId: 'pc-b', leaseMs: 60000 });
    assert.strictEqual(r.json.claimed, false);
    assert.strictEqual(r.json.leaseUntil, undefined);
  }

  // ---- 20. Self-arming Planner task due pushes + atomic mergeLedger (headless blind-spot delivery) ----
  {
    clock = Date.parse('2026-11-10T20:00:00.000Z');
    const healthRes = await routeStoreRequest(new Request('https://edge.example/store/health', { method: 'GET' }), ENV);
    const healthJson = await healthRes.json();
    assert.strictEqual(healthJson.ok, true);
    assert.ok(healthJson.version >= 3);
    assert.ok(Array.isArray(healthJson.capabilities) && healthJson.capabilities.includes('self_task_timers'));
    assert.ok(healthJson.capabilities.includes('ledger_merge'));

    const tk = makeRoom(ENV);
    const ecdhSub = nodeCrypto.createECDH('prime256v1');
    ecdhSub.generateKeys();
    const subPubB64u = ecdhSub.getPublicKey().toString('base64url');
    const subAuth = nodeCrypto.randomBytes(16);
    const subAuthB64u = subAuth.toString('base64url');
    const subEndpoint = 'https://web.push.apple.com/planner-task-sub-1';

    function decryptTaskPush(rawBody) {
      const salt = rawBody.subarray(0, 16);
      const idLen = rawBody[20];
      const serverPub = rawBody.subarray(21, 21 + idLen);
      const ciphertextWithTag = rawBody.subarray(21 + idLen);
      const sharedSecret = ecdhSub.computeSecret(serverPub);
      const hkdf = (s, ikm, info, len) => {
        const prk = nodeCrypto.createHmac('sha256', s.length ? s : Buffer.alloc(32)).update(ikm).digest();
        return nodeCrypto.createHmac('sha256', prk).update(Buffer.concat([info, Buffer.from([1])])).digest().subarray(0, len);
      };
      const keyInfo = Buffer.concat([Buffer.from('WebPush: info\0', 'utf8'), ecdhSub.getPublicKey(), serverPub]);
      const ikm = hkdf(subAuth, sharedSecret, keyInfo, 32);
      const cek = hkdf(salt, ikm, Buffer.from('Content-Encoding: aes128gcm\0', 'utf8'), 16);
      const nonce = hkdf(salt, ikm, Buffer.from('Content-Encoding: nonce\0', 'utf8'), 12);
      const tag = ciphertextWithTag.subarray(ciphertextWithTag.length - 16);
      const encData = ciphertextWithTag.subarray(0, ciphertextWithTag.length - 16);
      const decipher = nodeCrypto.createDecipheriv('aes-128-gcm', cek, nonce);
      decipher.setAuthTag(tag);
      const dec = Buffer.concat([decipher.update(encData), decipher.final()]);
      assert.strictEqual(dec[dec.length - 1], 0x02);
      return JSON.parse(dec.subarray(0, dec.length - 1).toString('utf8'));
    }

    // Seed Planner subscription (with prayers disabled so only task self-arming runs) + existing user ledger
    await call(tk.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        personal_ledger: {
          reminders: [{ id: 'rem_existing_user_1', title: 'Existing owner task', category: 'work', updatedAt: clock - 5000 }],
          deletedIds: ['rem_blindspot_deleted_earlier'],
          dailyScores: { '2026-11-10': 92 },
          prayerConfig: { enabled: false },
          updatedAt: clock - 5000
        },
        push_registry: {
          items: [
            {
              id: 'cmd_iphone_tasks',
              app: 'command',
              endpoint: subEndpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, prayers: false, tasks: true, timers: true }
            }
          ]
        }
      }
    });

    // Headless blind-spot script acquires weekly claim, then patches personal_ledger with mergeLedger=true while VS Code is closed
    const weekClaim = 'blindspot:2026-W46';
    r = await call(tk.room, '/store', { key: THEO_KEY, op: 'claim', claimKey: weekClaim, deviceId: 'pc-a', leaseMs: 600000 });
    assert.strictEqual(r.json.claimed, true);

    pushCalls.length = 0;
    const dueAt = clock + 120000;
    r = await call(tk.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      mergeLedger: true,
      sealClaims: [weekClaim],
      patch: {
        personal_ledger: {
          reminders: [
            {
              id: 'rem_blindspot_20261110_200000',
              title: 'Blind-spot review: 3 new ideas (10 Nov)',
              category: 'work',
              kind: 'task',
              hasAlarm: true,
              subTag: 'THEO',
              dueAt,
              updatedAt: clock,
              completed: false
            },
            // Attempting to re-add a tombstoned reminder must be ignored by mergeLedger
            {
              id: 'rem_blindspot_deleted_earlier',
              title: 'Should stay deleted',
              category: 'work',
              dueAt,
              updatedAt: clock + 9999,
              completed: false
            }
          ],
          updatedAt: clock
        },
        blindspot_review: {
          lastWeek: '2026-W46',
          lastRef: '20261110-200000',
          outcome: 'delivered',
          by: 'pc-a'
        }
      }
    });
    assert.strictEqual(r.status, 200);
    const mergedLedger = r.json.docs.personal_ledger;
    assert.strictEqual(mergedLedger.dailyScores['2026-11-10'], 92, 'mergeLedger preserves dailyScores');
    assert.deepStrictEqual(
      mergedLedger.reminders.map((x) => x.id).sort(),
      ['rem_blindspot_20261110_200000', 'rem_existing_user_1'],
      'mergeLedger preserves existing tasks, adds new task, and respects deletedIds tombstones'
    );

    // Claim must now be permanently sealed against other PCs
    const peerClaim = await call(tk.room, '/store', { key: THEO_KEY, op: 'claim', claimKey: weekClaim, deviceId: 'pc-b', leaseMs: 600000 });
    assert.strictEqual(peerClaim.json.claimed, false);
    assert.strictEqual(peerClaim.json.leaseUntil, undefined);

    // Store must have self-armed timer_rem_blindspot_20261110_200000_phonetasks
    const timerKey = 'timer_rem_blindspot_20261110_200000_phonetasks';
    assert.ok(r.json.docs[timerKey], 'Store self-armed canonical Planner task timer doc');
    assert.ok(String(r.json.docs[timerKey].id).startsWith(`rem_blindspot_20261110_200000_${dueAt}_phonetasks__`));
    assert.strictEqual(tk.state.alarmAt, dueAt, 'Durable Object alarm scheduled at exact task dueAt');

    // Advance clock 2 minutes with ZERO PCs online -> Web Push fires!
    await runAlarmAt(tk, dueAt);
    assert.strictEqual(pushCalls.length, 1, 'Store fires exactly one Planner Web Push when task falls due');
    assert.strictEqual(pushCalls[0].url, subEndpoint);
    const payload = decryptTaskPush(pushCalls[0].rawBody);
    assert.strictEqual(payload.title, '⏰ Task Due — Planner');
    assert.strictEqual(payload.body, 'Blind-spot review: 3 new ideas (10 Nov) (THEO)');
    assert.strictEqual(payload.taskId, 'rem_blindspot_20261110_200000');
    assert.strictEqual(payload.tab, 'tasks');

    // Completing another armed task before dueAt cancels its pending timer in SQLite
    const cancelDue = clock + 300000;
    await call(tk.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      mergeLedger: true,
      ackOnly: true,
      patch: {
        personal_ledger: {
          reminders: [{ id: 'rem_cancel_test', title: 'Cancel me', category: 'work', hasAlarm: true, dueAt: cancelDue, updatedAt: clock + 1, completed: false }]
        }
      }
    });
    let checkDocs = (await call(tk.room, '/store', { key: THEO_KEY, op: 'get_control' })).json.docs;
    assert.ok(String(checkDocs.timer_rem_cancel_test_phonetasks?.id || '').startsWith(`rem_cancel_test_${cancelDue}_`));

    await call(tk.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      mergeLedger: true,
      ackOnly: true,
      patch: {
        personal_ledger: {
          reminders: [{ id: 'rem_cancel_test', title: 'Cancel me', category: 'work', hasAlarm: true, dueAt: cancelDue, updatedAt: clock + 2, completed: true }]
        }
      }
    });
    checkDocs = (await call(tk.room, '/store', { key: THEO_KEY, op: 'get_control' })).json.docs;
    assert.strictEqual(checkDocs.timer_rem_cancel_test_phonetasks?.id, 'cancelled', 'completed task cancels pending store timer');
    pushCalls.length = 0;
    await runAlarmAt(tk, cancelDue + 1000);
    assert.strictEqual(pushCalls.length, 0, 'cancelled task timer never fires');

    // Red-Team #3: Subscriber opting out (`prefs.tasks = false`), removing subscription (`items: []`),
    // or reminder vanishing without tombstone must cancel pending SQLite task timers immediately.
    const optOutDue = clock + 420000;
    await call(tk.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        personal_ledger: {
          reminders: [{ id: 'rem_optout_test', title: 'Opt-out check', category: 'work', hasAlarm: true, dueAt: optOutDue, updatedAt: clock + 10, completed: false }]
        }
      }
    });
    checkDocs = (await call(tk.room, '/store', { key: THEO_KEY, op: 'get_control' })).json.docs;
    assert.ok(String(checkDocs.timer_rem_optout_test_phonetasks?.id || '').startsWith(`rem_optout_test_${optOutDue}_`));

    await call(tk.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        push_registry: {
          items: [
            {
              id: 'cmd_phone_tasks',
              app: 'command',
              endpoint: subEndpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, tasks: false, timers: true }
            }
          ]
        }
      }
    });
    checkDocs = (await call(tk.room, '/store', { key: THEO_KEY, op: 'get_control' })).json.docs;
    assert.strictEqual(checkDocs.timer_rem_optout_test_phonetasks?.id, 'cancelled', 'prefs.tasks=false cancels pending task timer');
    pushCalls.length = 0;
    await runAlarmAt(tk, optOutDue + 1000);
    assert.strictEqual(pushCalls.length, 0, 'opted-out subscriber receives zero task pushes');

    // Re-enable subscriber, re-arm, then clear push_registry.items -> timer cancelled & 0 pushes
    const unsubDue = clock + 480000;
    await call(tk.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: {
        push_registry: {
          items: [
            {
              id: 'cmd_phone_tasks',
              app: 'command',
              endpoint: subEndpoint,
              keys: { p256dh: subPubB64u, auth: subAuthB64u },
              prefs: { enabled: true, tasks: true, timers: true }
            }
          ]
        },
        personal_ledger: {
          reminders: [{ id: 'rem_unsub_test', title: 'Unsub check', category: 'work', hasAlarm: true, dueAt: unsubDue, updatedAt: clock + 20, completed: false }]
        }
      }
    });
    checkDocs = (await call(tk.room, '/store', { key: THEO_KEY, op: 'get_control' })).json.docs;
    assert.ok(String(checkDocs.timer_rem_unsub_test_phonetasks?.id || '').startsWith(`rem_unsub_test_${unsubDue}_`));

    await call(tk.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      ackOnly: true,
      patch: { push_registry: { items: [] } }
    });
    checkDocs = (await call(tk.room, '/store', { key: THEO_KEY, op: 'get_control' })).json.docs;
    assert.strictEqual(checkDocs.timer_rem_unsub_test_phonetasks?.id, 'cancelled', 'empty push_registry cancels pending task timer');
    pushCalls.length = 0;
    await runAlarmAt(tk, unsubDue + 1000);
    assert.strictEqual(pushCalls.length, 0, 'unsubscribed room dispatches zero pushes');

    // Red-Team #1: Concurrent un-merged workstation / Planner PWA `op: "patch"` (NO `mergeLedger` flag!)
    // carrying a stale pre-blind-spot snapshot must NEVER clobber the blind-spot task, newer dailyScores,
    // teamRoster entries, or newer prayerConfig!
    const raceRoom = makeRoom(ENV);
    await call(raceRoom.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      mergeLedger: true,
      patch: {
        personal_ledger: {
          reminders: [
            { id: 'rem_blindspot_20261116_080500', title: 'Blind-spot review: 3 new ideas', updatedAt: clock + 500, completed: false }
          ],
          dailyScores: { '2026-11-11': { score: 96, updatedAt: clock + 500 } },
          teamRoster: [{ id: 'tm_ali', name: 'Ali', updatedAt: clock + 500 }],
          prayerConfig: { enabled: true, locationName: 'Beirut', notifyFajr: false, updatedAt: clock + 500 },
          updatedAt: clock + 500
        }
      }
    });

    // Stale workstation sync arrives WITHOUT `mergeLedger: true`, missing the blind-spot task,
    // missing 2026-11-11 score, and carrying an older prayerConfig (`updatedAt: clock + 100`).
    const raceRes = await call(raceRoom.room, '/store', {
      key: THEO_KEY,
      op: 'patch',
      patch: {
        personal_ledger: {
          reminders: [
            { id: 'rem_workstation_task', title: 'Call supplier', updatedAt: clock + 300, completed: false }
          ],
          dailyScores: {
            '2026-11-10': { score: 88, updatedAt: clock + 300 },
            '2026-11-11': { score: 50, updatedAt: clock + 100 }
          },
          teamRoster: [{ id: 'tm_sara', name: 'Sara', updatedAt: clock + 300 }],
          prayerConfig: { enabled: true, locationName: 'OldSnapshot', notifyFajr: true, updatedAt: clock + 100 },
          updatedAt: clock + 300
        }
      }
    });
    assert.strictEqual(raceRes.status, 200);
    const racedLedger = raceRes.json.docs.personal_ledger;
    assert.deepStrictEqual(
      racedLedger.reminders.map((x) => x.id).sort(),
      ['rem_blindspot_20261116_080500', 'rem_workstation_task'],
      'un-merged workstation patch preserves concurrent blind-spot task'
    );
    assert.strictEqual(racedLedger.dailyScores['2026-11-10'].score, 88, 'merges distinct dailyScores dates');
    assert.strictEqual(racedLedger.dailyScores['2026-11-11'].score, 96, 'newer dailyScores updatedAt wins');
    assert.deepStrictEqual(
      racedLedger.teamRoster.map((m) => m.id).sort(),
      ['tm_ali', 'tm_sara'],
      'merges teamRoster members across concurrent patches'
    );
    assert.strictEqual(racedLedger.prayerConfig.notifyFajr, false, 'newer prayerConfig updatedAt wins over stale patch');
  }

  console.log('store.test.cjs: all THEO Store behaviour checks passed');
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
