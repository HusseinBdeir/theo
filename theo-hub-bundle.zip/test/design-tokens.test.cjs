'use strict';

// Tests for shared design tokens (tokens.json + scripts/generate_design_tokens.cjs + resources/hub.css).
// Run: node test/design-tokens.test.cjs (also executed inside test/smoke.test.cjs).

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const HUB_ROOT = path.resolve(__dirname, '..');
const GEN_PATH = path.join(HUB_ROOT, 'scripts', 'generate_design_tokens.cjs');
const gen = require(GEN_PATH);

function clone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

function collectLiteralsOutsideShared(tokens) {
  const seen = new Map();
  const walk = (node, p) => {
    if (p.startsWith('shared.')) return;
    if (typeof node === 'string') {
      // Check whole string as a literal colour (compound box-shadows handled separately from palette accents)
      const norm = node.trim().toLowerCase();
      if (/^#[0-9a-f]{3,8}$/i.test(norm) || /^rgba?\([^)]+\)$/i.test(norm)) {
        const canonical = /^#[0-9a-f]{3}$/i.test(norm)
          ? `#${norm[1]}${norm[1]}${norm[2]}${norm[2]}${norm[3]}${norm[3]}`
          : norm;
        if (!seen.has(canonical)) seen.set(canonical, []);
        seen.get(canonical).push(p);
      }
      return;
    }
    if (Array.isArray(node)) {
      node.forEach((item, idx) => walk(item, `${p}[${idx}]`));
      return;
    }
    if (node && typeof node === 'object') {
      for (const [k, v] of Object.entries(node)) {
        walk(v, p ? `${p}.${k}` : k);
      }
    }
  };
  walk(tokens, '');
  const dups = [];
  for (const [lit, paths] of seen.entries()) {
    if (paths.length > 1) dups.push({ lit, paths });
  }
  return dups;
}

function runDesignTokenTests() {
  // 1. Live tokens.json schema validity & deduplication
  const tokens = gen.loadTokens(HUB_ROOT);
  const dupLiterals = collectLiteralsOutsideShared(tokens);
  assert.deepStrictEqual(dupLiterals, [], `tokens.json must not duplicate colour literals outside shared: ${JSON.stringify(dupLiterals)}`);

  // 2. Live hub.css generated block integrity & exact match with tokens.json
  const hubCssPath = path.join(HUB_ROOT, 'resources', 'hub.css');
  const hubCss = fs.readFileSync(hubCssPath, 'utf8');
  const hubInteg = gen.verifyGeneratedBlockIntegrity(hubCss, 'hub.css');
  assert.strictEqual(hubInteg.ok, true, hubInteg.reason || 'hub.css generated block integrity failed');
  const expectedHubBlock = gen.renderHubHeaderBlock(tokens);
  assert.strictEqual(hubInteg.block, expectedHubBlock, 'hub.css generated block must equal renderHubHeaderBlock(tokens)');
  assert.ok(
    hubCss.includes(`var(--vscode-button-secondaryBackground, ${tokens.shared.vscodeInputBg})`) &&
    hubCss.includes(`var(--vscode-button-secondaryForeground, ${tokens.shared.vscodeFg})`),
    'hub.css .button fallback colours outside generated block must stay aligned with tokens.shared'
  );

  // 3. Hand-edit tamper detection on hub.css (both integrity stamp and tokens.json parity)
  const tamperChecks = [
    ['custom prop value edit', hubCss.replace('--progress-claude: #d97757;', '--progress-claude: #d97758;')],
    ['var(--vscode-*, fallback) edit', hubCss.replace('var(--vscode-foreground, #ccc)', 'var(--vscode-foreground, #ddd)')],
    ['nested var(--vscode-*, var(--vscode-*, fallback)) edit', hubCss.replace('#7f7f7f40', '#7f7f7f44')],
    ['light override edit', hubCss.replace('--pin-accent: #9a6b1f;', '--pin-accent: #9a6b1e;')],
    ['missing BEGIN marker', hubCss.replace(`${gen.BEGIN_MARKER}\n`, '')],
    ['missing END marker', hubCss.replace(`\n${gen.END_MARKER}`, '')],
    ['duplicate BEGIN marker', hubCss.replace(gen.BEGIN_MARKER, `${gen.BEGIN_MARKER}\n${gen.BEGIN_MARKER}`)],
    ['corrupted sha256 stamp', hubCss.replace(/(\/\* @tokens-sha256: )([0-9a-f]{64})( \*\/)/, (_, a, h, b) => `${a}${h[0] === '0' ? '1' : '0'}${h.slice(1)}${b}`)]
  ];
  for (const [label, tampered] of tamperChecks) {
    const res = gen.verifyGeneratedBlockIntegrity(tampered, `tampered(${label})`);
    assert.strictEqual(res.ok, false, `Expected tamper check "${label}" to fail`);
  }

  // 4. Schema validation rejects hostile / malformed tokens.json inputs
  const badSchemas = [
    ['wrong schemaVersion', (t) => { t.schemaVersion = 2; }],
    ['dangling $ref', (t) => { t.hub.root['--fg'].fallback = { $ref: 'shared.doesNotExist' }; }],
    ['circular $ref', (t) => { t.shared.a = { $ref: 'shared.b' }; t.shared.b = { $ref: 'shared.a' }; }],
    ['off-ladder $mix step', (t) => { t.theo.scales.rootTokens['--tint-1'] = { $mix: { token: '--tint', step: 37 } }; }],
    ['lossy shortLower hex', (t) => { t.hub.root['--active-fg'].fallback = { $ref: 'shared.agy', format: 'shortLower' }; }],
    ['invalid vscode variable name', (t) => { t.hub.root['--fg'].vscode = ['--not-vscode-var']; }],
    ['CSS injection with semicolon', (t) => { t.hub.root['--fg'].fallback = '#ccc; body { display: none'; }],
    ['CSS injection with comment close', (t) => { t.hub.root['--fg'].fallback = '#ccc */'; }],
    ['CSS injection with newline', (t) => { t.hub.root['--fg'].fallback = '#ccc\n}'; }],
    ['selector CSS injection', (t) => { t.theo.palettes[0].selectors = [':root { color: red; }']; }],
    ['comment breaking out of /* */', (t) => { t.theo.scales.comment = '/* ok */ body { display: none } /* */'; }],
    ['missing scales.comment', (t) => { delete t.theo.scales.comment; }],
    ['invalid custom property name', (t) => { t.hub.root.badProp = '#ccc'; }]
  ];
  for (const [label, mutate] of badSchemas) {
    const bad = clone(tokens);
    mutate(bad);
    assert.throws(() => gen.validateTokens(bad), `Expected validateTokens to reject "${label}"`);
  }

  // 5. Temp-dir CLI end-to-end tests: standalone theo-hub, --bootstrap, atomicity, sibling drift, and standalone theo
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'theo-tokens-test-'));
  try {
    const soloHub = path.join(tmp, 'solo', 'theo-hub');
    fs.mkdirSync(path.join(soloHub, 'scripts'), { recursive: true });
    fs.mkdirSync(path.join(soloHub, 'resources'), { recursive: true });
    fs.copyFileSync(path.join(HUB_ROOT, 'tokens.json'), path.join(soloHub, 'tokens.json'));
    fs.copyFileSync(GEN_PATH, path.join(soloHub, 'scripts', 'generate_design_tokens.cjs'));
    const hubWithSentinel = `${hubCss.replace(/\r\n/g, '\n')}\n/* outside-sentinel-must-survive */\n`;
    fs.writeFileSync(path.join(soloHub, 'resources', 'hub.css'), hubWithSentinel, 'utf8');

    // 5a. Standalone theo-hub (no ../theo) runs --check and idempotent generate without touching mtime
    execFileSync(process.execPath, [path.join(soloHub, 'scripts', 'generate_design_tokens.cjs'), '--check'], { stdio: 'pipe' });
    const mtimeBefore = fs.statSync(path.join(soloHub, 'resources', 'hub.css')).mtimeMs;
    execFileSync(process.execPath, [path.join(soloHub, 'scripts', 'generate_design_tokens.cjs')], { stdio: 'pipe' });
    const mtimeAfter = fs.statSync(path.join(soloHub, 'resources', 'hub.css')).mtimeMs;
    assert.strictEqual(mtimeAfter, mtimeBefore, 'Generator must not rewrite hub.css when bytes already match');
    assert.ok(fs.readFileSync(path.join(soloHub, 'resources', 'hub.css'), 'utf8').endsWith('/* outside-sentinel-must-survive */\n'));

    // 5b. Forged sha256 inside hub.css (valid internal hash, wrong vs tokens.json) fails --check
    const forgedHub = gen.replaceGeneratedBlock(
      hubWithSentinel,
      gen.wrapGeneratedBlock(hubInteg.innerBody.replace('--progress-claude: #d97757;', '--progress-claude: #d97758;')),
      { label: 'hub.css' }
    );
    fs.writeFileSync(path.join(soloHub, 'resources', 'hub.css'), forgedHub, 'utf8');
    assert.throws(
      () => execFileSync(process.execPath, [path.join(soloHub, 'scripts', 'generate_design_tokens.cjs'), '--check'], { stdio: 'pipe' }),
      'Generator --check must reject hand-edited hub.css even with recomputed @tokens-sha256'
    );
    execFileSync(process.execPath, [path.join(soloHub, 'scripts', 'generate_design_tokens.cjs')], { stdio: 'pipe' });
    assert.strictEqual(fs.readFileSync(path.join(soloHub, 'resources', 'hub.css'), 'utf8'), hubWithSentinel, 'Regenerating hub.css must restore exact header while leaving outside-marker bytes untouched');

    // 5c. --bootstrap and atomic multi-target failure check (synthetic unmarked theo.css; does not require sibling ../theo to be updated yet)
    {
      const bootHub = path.join(tmp, 'boot', 'theo-hub');
      const bootTheo = path.join(tmp, 'boot', 'theo');
      fs.mkdirSync(path.join(bootHub, 'scripts'), { recursive: true });
      fs.mkdirSync(path.join(bootHub, 'resources'), { recursive: true });
      fs.mkdirSync(path.join(bootTheo, 'css'), { recursive: true });
      fs.copyFileSync(path.join(HUB_ROOT, 'tokens.json'), path.join(bootHub, 'tokens.json'));
      fs.copyFileSync(GEN_PATH, path.join(bootHub, 'scripts', 'generate_design_tokens.cjs'));
      const editedBootTok = clone(tokens);
      editedBootTok.shared.agy = '#3186FD';
      fs.writeFileSync(path.join(bootHub, 'tokens.json'), JSON.stringify(editedBootTok, null, 2) + '\n', 'utf8');
      fs.writeFileSync(path.join(bootHub, 'resources', 'hub.css'), hubWithSentinel, 'utf8');
      const unmarkedTheo = `:root {\n  --old: #000;\n}\n${gen.THEO_BODY_ANCHOR}\n  box-sizing: border-box;\n}\n`;
      fs.writeFileSync(path.join(bootTheo, 'css', 'theo.css'), unmarkedTheo, 'utf8');

      // Without --bootstrap, unmarked theo.css fails AND hub.css must remain untouched (no half-update)
      assert.throws(
        () => execFileSync(process.execPath, [path.join(bootHub, 'scripts', 'generate_design_tokens.cjs')], { stdio: 'pipe' }),
        'Generator without --bootstrap must fail on unmarked theo.css'
      );
      assert.strictEqual(fs.readFileSync(path.join(bootTheo, 'css', 'theo.css'), 'utf8'), unmarkedTheo, 'Unmarked theo.css must stay untouched on refusal');
      assert.strictEqual(fs.readFileSync(path.join(bootHub, 'resources', 'hub.css'), 'utf8'), hubWithSentinel, 'hub.css must not be half-updated when theo.css fails');

      // With --bootstrap, only the generated header block is replaced and body outside markers is preserved
      execFileSync(process.execPath, [path.join(bootHub, 'scripts', 'generate_design_tokens.cjs'), '--bootstrap'], { stdio: 'pipe' });
      const bootTheoAfter = fs.readFileSync(path.join(bootTheo, 'css', 'theo.css'), 'utf8');
      assert.ok(bootTheoAfter.startsWith(`${gen.BEGIN_MARKER}\n`), '--bootstrap must wrap theo.css header in BEGIN/END GENERATED markers');
      assert.ok(bootTheoAfter.endsWith(`${gen.THEO_BODY_ANCHOR}\n  box-sizing: border-box;\n}\n`), '--bootstrap must preserve theo.css body byte-identically');
      execFileSync(process.execPath, [path.join(bootHub, 'scripts', 'generate_design_tokens.cjs'), '--check'], { stdio: 'pipe' });
    }

    // 5d. Sibling theo + theo-hub drift check & verify_design_tokens.cjs integration (when sibling ../theo already carries markers)
    const siblingTheo = path.resolve(HUB_ROOT, '..', 'theo');
    const siblingTheoCssPath = path.join(siblingTheo, 'css', 'theo.css');
    const siblingVerifyPath = path.join(siblingTheo, 'scripts', 'verify_design_tokens.cjs');
    const siblingHasMarkers = fs.existsSync(siblingTheoCssPath) &&
      fs.existsSync(siblingVerifyPath) &&
      fs.readFileSync(siblingTheoCssPath, 'utf8').includes(gen.BEGIN_MARKER) &&
      fs.readFileSync(siblingVerifyPath, 'utf8').includes('--hub-root');
    if (siblingHasMarkers) {
      // Check the real sibling ../theo checkout directly against live tokens.json first
      assert.doesNotThrow(
        () => gen.syncDesignTokens({ hubRoot: HUB_ROOT, theoRoot: siblingTheo, explicitTheo: true, check: true }),
        'Real sibling ../theo/css/theo.css must match live tokens.json'
      );

      const pairHub = path.join(tmp, 'pair', 'theo-hub');
      const pairTheo = path.join(tmp, 'pair', 'theo');
      fs.mkdirSync(path.join(pairHub, 'scripts'), { recursive: true });
      fs.mkdirSync(path.join(pairHub, 'resources'), { recursive: true });
      fs.mkdirSync(path.join(pairTheo, 'css'), { recursive: true });
      fs.mkdirSync(path.join(pairTheo, 'js'), { recursive: true });
      fs.mkdirSync(path.join(pairTheo, 'scripts'), { recursive: true });
      fs.copyFileSync(path.join(HUB_ROOT, 'tokens.json'), path.join(pairHub, 'tokens.json'));
      fs.copyFileSync(GEN_PATH, path.join(pairHub, 'scripts', 'generate_design_tokens.cjs'));
      fs.copyFileSync(hubCssPath, path.join(pairHub, 'resources', 'hub.css'));
      fs.copyFileSync(siblingTheoCssPath, path.join(pairTheo, 'css', 'theo.css'));
      fs.copyFileSync(path.join(siblingTheo, 'index.html'), path.join(pairTheo, 'index.html'));
      fs.copyFileSync(siblingVerifyPath, path.join(pairTheo, 'scripts', 'verify_design_tokens.cjs'));

      const cleanHubEnv = { ...process.env, THEO_HUB_ROOT: '' };
      execFileSync(process.execPath, [path.join(pairHub, 'scripts', 'generate_design_tokens.cjs')], { stdio: 'pipe' });
      execFileSync(process.execPath, [path.join(pairHub, 'scripts', 'generate_design_tokens.cjs'), '--check'], { stdio: 'pipe' });
      execFileSync(process.execPath, [path.join(pairTheo, 'scripts', 'verify_design_tokens.cjs')], { stdio: 'pipe', env: cleanHubEnv });

      // Explicit bogus --hub-root must fail rather than silently passing in standalone mode
      assert.throws(
        () => execFileSync(process.execPath, [path.join(pairTheo, 'scripts', 'verify_design_tokens.cjs'), '--hub-root', path.join(tmp, 'missing-hub')], { stdio: 'pipe', env: cleanHubEnv }),
        'verify_design_tokens.cjs must fail on an explicit nonexistent --hub-root'
      );

      // Mutate tokens.json without regenerating theo.css -> both checks must fail
      const editedTok = clone(tokens);
      editedTok.shared.agy = '#3186FE';
      fs.writeFileSync(path.join(pairHub, 'tokens.json'), JSON.stringify(editedTok, null, 2) + '\n', 'utf8');
      assert.throws(
        () => execFileSync(process.execPath, [path.join(pairHub, 'scripts', 'generate_design_tokens.cjs'), '--check'], { stdio: 'pipe' }),
        'generate_design_tokens.cjs --check must fail when tokens.json changes without regenerating CSS'
      );
      assert.throws(
        () => execFileSync(process.execPath, [path.join(pairTheo, 'scripts', 'verify_design_tokens.cjs')], { stdio: 'pipe', env: cleanHubEnv }),
        'verify_design_tokens.cjs must fail when committed theo.css differs from sibling tokens.json'
      );

      // Regenerate -> passes again
      execFileSync(process.execPath, [path.join(pairHub, 'scripts', 'generate_design_tokens.cjs')], { stdio: 'pipe' });
      execFileSync(process.execPath, [path.join(pairTheo, 'scripts', 'verify_design_tokens.cjs')], { stdio: 'pipe', env: cleanHubEnv });

      // Standalone theo (--hub-root __none__) passes when clean and fails on a hand edit inside the generated block
      execFileSync(process.execPath, [path.join(pairTheo, 'scripts', 'verify_design_tokens.cjs'), '--hub-root', '__none__'], { stdio: 'pipe', env: cleanHubEnv });
      const origPairTheoCss = fs.readFileSync(path.join(pairTheo, 'css', 'theo.css'), 'utf8');
      fs.writeFileSync(path.join(pairTheo, 'css', 'theo.css'), origPairTheoCss.replace('#3186FE', '#3186FD'), 'utf8');
      assert.throws(
        () => execFileSync(process.execPath, [path.join(pairTheo, 'scripts', 'verify_design_tokens.cjs'), '--hub-root', '__none__'], { stdio: 'pipe', env: cleanHubEnv }),
        'Standalone verify_design_tokens.cjs must fail on a hand edit inside generated theo.css block'
      );
    } else {
      console.log('[SKIP] design-tokens: sibling ../theo does not yet carry BEGIN GENERATED / --hub-root markers');
    }
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true, maxRetries: 10, retryDelay: 150 });
  }

  console.log('[PASS] design-tokens: tokens.json schema, hub.css generated block, tamper detection, and sibling parity verified');
}

module.exports = { runDesignTokenTests };

if (require.main === module) {
  runDesignTokenTests();
}
