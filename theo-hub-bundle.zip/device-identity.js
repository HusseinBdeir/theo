'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile, spawn } = require('child_process');

const CLAUDE_DIR = path.join(os.homedir(), '.claude');
const DEVICE_FILE = path.join(CLAUDE_DIR, 'theo-device.json');
const THEO_CRED_DIR = path.join(os.homedir(), '.theo');
const THEO_CRED_FILE = path.join(THEO_CRED_DIR, 'credentials.json');

// THEO_CRED_PATH and THEO_DEVICE_PATH point the tests at files of their own, so a test never reads or writes the
// credentials or the device identity of the PC it runs on.
function credFilePath() {
  return process.env.THEO_CRED_PATH || THEO_CRED_FILE;
}

function deviceFilePath() {
  return process.env.THEO_DEVICE_PATH || DEVICE_FILE;
}
const DEFAULT_EDGE_RELAY_URL = 'https://theo-edge-relay.husseinbdeir.workers.dev/ws';

function slugifyId(raw) {
  return String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

function getLanIps() {
  const out = [];
  try {
    const nets = os.networkInterfaces() || {};
    for (const [name, addrs] of Object.entries(nets)) {
      if (!Array.isArray(addrs)) continue;
      for (const addr of addrs) {
        if (!addr || addr.internal) continue;
        if (addr.family === 'IPv4' || addr.family === 4) {
          out.push({ name, address: addr.address });
        }
      }
    }
  } catch {}
  return out;
}

function resolveAgyBinaryPath() {
  const home = os.homedir();
  const candidates = [
    process.env.THEO_AGY_BIN,
    path.join(home, '.gemini', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'antigravity', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'antigravity-cli', 'bin', 'agy.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'Antigravity IDE', 'bin', 'agy.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'antigravity', 'resources', 'app', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'bin', 'agy')
  ].filter(Boolean);

  for (const c of candidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return c;
      }
    } catch {}
  }

  const pathDirs = String(process.env.PATH || '').split(path.delimiter);
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of process.platform === 'win32' ? ['agy.exe', 'agy.cmd', 'agy'] : ['agy']) {
      const full = path.join(dir, name);
      try {
        if (fs.existsSync(full) && fs.statSync(full).isFile()) {
          return full;
        }
      } catch {}
    }
  }
  return '';
}

function resolveClaudeBinaryPath() {
  const home = os.homedir();
  // Prefer native .exe binaries before .cmd wrappers to avoid Windows Node 22+ spawn EINVAL
  const directExeCandidates = [
    process.env.THEO_CLAUDE_BIN,
    path.join(home, '.local', 'bin', 'claude.exe'),
    path.join(home, '.claude', 'local', 'claude.exe'),
    path.join(home, '.local', 'bin', 'claude')
  ].filter(Boolean);

  for (const c of directExeCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return c;
      }
    } catch {}
  }

  // Check VS Code / Antigravity installed Claude Code extension native binary (numeric semver newest first)
  const extDirs = [
    path.join(home, '.vscode', 'extensions'),
    path.join(home, '.antigravity', 'extensions')
  ];
  for (const extRoot of extDirs) {
    try {
      if (!fs.existsSync(extRoot)) continue;
      const matches = fs
        .readdirSync(extRoot, { withFileTypes: true })
        .filter((d) => d.isDirectory() && /^anthropic\.claude-code-/i.test(d.name))
        .map((d) => d.name)
        .sort((a, b) => b.localeCompare(a, undefined, { numeric: true, sensitivity: 'base' }));
      for (const dirName of matches) {
        const binName = process.platform === 'win32' ? 'claude.exe' : 'claude';
        const binPath = path.join(extRoot, dirName, 'resources', 'native-binary', binName);
        if (fs.existsSync(binPath) && fs.statSync(binPath).isFile()) {
          return binPath;
        }
      }
    } catch {}
  }

  const npmCliJs = path.join(
    home,
    'AppData',
    'Roaming',
    'npm',
    'node_modules',
    '@anthropic-ai',
    'claude-code',
    'cli.js'
  );
  try {
    if (fs.existsSync(npmCliJs) && fs.statSync(npmCliJs).isFile()) {
      return npmCliJs;
    }
  } catch {}

  const npmCmd = path.join(home, 'AppData', 'Roaming', 'npm', 'claude.cmd');
  try {
    if (fs.existsSync(npmCmd) && fs.statSync(npmCmd).isFile()) {
      return npmCmd;
    }
  } catch {}

  const pathDirs = String(process.env.PATH || '').split(path.delimiter);
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of process.platform === 'win32' ? ['claude.exe', 'claude.cmd', 'claude'] : ['claude']) {
      const full = path.join(dir, name);
      try {
        if (fs.existsSync(full) && fs.statSync(full).isFile()) {
          return full;
        }
      } catch {}
    }
  }
  return '';
}

function resolveNodeBinaryInfo() {
  const wrapNodeInfo = (executable, electronRunAsNode) => ({
    executable,
    electronRunAsNode,
    nodeExe: executable,
    useElectronRunAsNode: electronRunAsNode
  });
  const home = os.homedir();
  const nodeCandidates = [
    path.join(home, '.local', 'node', 'node.exe'),
    'C:\\Program Files\\nodejs\\node.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'nodejs', 'node.exe'),
    '/usr/local/bin/node',
    '/opt/homebrew/bin/node',
    '/usr/bin/node'
  ];
  for (const c of nodeCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return wrapNodeInfo(c, false);
      }
    } catch {}
  }
  if (!process.versions?.electron && process.execPath && fs.existsSync(process.execPath)) {
    return wrapNodeInfo(process.execPath, false);
  }
  const electronCandidates = [
    path.join(home, 'AppData', 'Local', 'Programs', 'Microsoft VS Code', 'Code.exe'),
    'C:\\Program Files\\Microsoft VS Code\\Code.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'antigravity', 'Antigravity.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'Antigravity IDE', 'Antigravity.exe')
  ];
  for (const c of electronCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return wrapNodeInfo(c, true);
      }
    } catch {}
  }
  return wrapNodeInfo('node', false);
}

function resolveSpawnableCli(binPath, args = []) {
  const cleanBin = String(binPath || '').trim();
  if (!cleanBin) {
    return { command: '', args: [...args], envPatch: {} };
  }
  if (/\.m?js$/i.test(cleanBin)) {
    const nodeInfo = resolveNodeBinaryInfo();
    return {
      command: nodeInfo.executable,
      args: [cleanBin, ...args],
      envPatch: nodeInfo.electronRunAsNode ? { ELECTRON_RUN_AS_NODE: '1' } : {}
    };
  }
  if (process.platform === 'win32' && /\.(?:cmd|bat)$/i.test(cleanBin)) {
    const dir = path.dirname(cleanBin);
    const base = path.basename(cleanBin).replace(/\.(?:cmd|bat)$/i, '');
    const siblingCliJs =
      base.toLowerCase() === 'claude'
        ? path.join(dir, 'node_modules', '@anthropic-ai', 'claude-code', 'cli.js')
        : '';
    if (siblingCliJs && fs.existsSync(siblingCliJs)) {
      const nodeInfo = resolveNodeBinaryInfo();
      return {
        command: nodeInfo.executable,
        args: [siblingCliJs, ...args],
        envPatch: nodeInfo.electronRunAsNode ? { ELECTRON_RUN_AS_NODE: '1' } : {}
      };
    }
    const siblingExe = path.join(dir, `${base}.exe`);
    if (fs.existsSync(siblingExe)) {
      return { command: siblingExe, args: [...args], envPatch: {} };
    }
    // Safe Windows cmd.exe wrapper avoiding Node 22+ spawn EINVAL on bare .cmd
    const quoteWinArg = (val) => {
      const s = String(val ?? '');
      if (!/[\s"&|<>^()%!]/.test(s) && s.length > 0) return s;
      return `"${s.replace(/(\\*)"/g, '$1$1\\"').replace(/(\\+)$/, '$1$1').replace(/%/g, '%%')}"`;
    };
    const cmdLine = `"${quoteWinArg(cleanBin)} ${args.map(quoteWinArg).join(' ')}"`;
    return {
      command: process.env.ComSpec || 'C:\\Windows\\System32\\cmd.exe',
      args: ['/d', '/s', '/c', cmdLine],
      windowsVerbatimArguments: true,
      envPatch: {}
    };
  }
  return { command: cleanBin, args: [...args], envPatch: {} };
}

// Every PC is an equal host. Nothing here may depend on which PC the code runs on: a host's id and name come from
// its saved config or its computer name, and what the fleet knows about other hosts comes from what they publish.
const HOST_ROLE = 'host';

// Names that older builds assigned from the home folder. A saved config still carrying one is renamed to the
// computer name the first time this build reads it; a name the user chose is never touched.
const RETIRED_DEFAULT_DEVICE_NAMES = new Set(['main workstation', 'theo laptop']);

// The store and the relay accept device ids made of letters, digits, dot, underscore and hyphen, up to 80 long.
// An id outside that (a hand-edited config) is brought into shape instead of being silently ignored by them.
function cleanDeviceId(rawId) {
  const s = String(rawId || '').trim();
  if (!s) return '';
  if (/^[A-Za-z0-9._-]{1,80}$/.test(s)) return s;
  return slugifyId(s);
}

function inferDefaultDeviceIdentity() {
  const rawHost = String(os.hostname() || '').trim();
  let user = '';
  try {
    user = os.userInfo().username || '';
  } catch {}
  const slug = slugifyId(rawHost || user || 'device');
  return {
    id: `dev-${slug || crypto.randomBytes(3).toString('hex')}`,
    name: rawHost || 'Workstation',
    role: HOST_ROLE
  };
}

// ---- Fleet home folders: which host owns a session, learned from the hosts themselves ----
// Each host publishes its home folder with its device entry. A session whose working folder sits under another
// host's home folder belongs to that host (for example a transcript restored from it), so two PCs never both
// report the same session as their own. The map is data in ~/.claude, never a list in code.
const FLEET_HOMES_FILE = path.join(CLAUDE_DIR, 'theo-fleet-homes.json');
const FLEET_HOMES_RECHECK_MS = 5000;
let fleetHomesCache = null;
let fleetHomesCachePath = '';
let fleetHomesCheckedAt = 0;
let fleetHomesMtimeMs = -1;

// THEO_FLEET_HOMES_PATH points the tests at a file of their own.
function fleetHomesPath() {
  return process.env.THEO_FLEET_HOMES_PATH || FLEET_HOMES_FILE;
}

function selfHomeDir() {
  return process.env.THEO_SELF_HOMEDIR || os.homedir();
}

function normalizeHomePath(rawPath) {
  return String(rawPath || '')
    .trim()
    .replace(/\//g, '\\')
    .replace(/\\+$/, '')
    .toLowerCase();
}

const realPathCache = new Map();
const REALPATH_CACHE_MS = 60000;

function resolveRealHomeCached(rawPath) {
  const key = normalizeHomePath(rawPath);
  if (!key) return '';
  const now = Date.now();
  const hit = realPathCache.get(key);
  if (hit && now - hit.at < REALPATH_CACHE_MS) {
    return hit.real;
  }
  let real = '';
  try {
    const fn = fs.realpathSync.native || fs.realpathSync;
    real = normalizeHomePath(fn(rawPath));
  } catch {
    real = '';
  }
  if (realPathCache.size > 64) realPathCache.clear();
  realPathCache.set(key, { real, at: now });
  return real;
}

// True when `homeKey` (another host's published home path) is a local junction or symlink on this PC whose target
// resolves to this PC's own home folder. When so, a session under `homeKey` is only treated as the other host's if
// that host actually published the session id (restored transcript) and the session is not open/running here.
function isLocalHomeAlias(homeKey) {
  const cleanHome = normalizeHomePath(homeKey);
  const selfRaw = selfHomeDir();
  const selfNorm = normalizeHomePath(selfRaw);
  if (!cleanHome || !selfNorm || cleanHome === selfNorm) return false;
  const selfReal = resolveRealHomeCached(selfRaw) || selfNorm;
  const homeReal = resolveRealHomeCached(cleanHome);
  return Boolean(homeReal && selfReal && homeReal === selfReal);
}

const MAX_FLEET_HOME_ROW_IDS = 3000;
let fallbackPeerRowsMtime = -1;
let fallbackPeerRowsCheckedAt = 0;
let fallbackPeerRowsByDev = new Map();

function loadFallbackPeerRowIdsByDevice() {
  const now = Date.now();
  if (now - fallbackPeerRowsCheckedAt < FLEET_HOMES_RECHECK_MS) {
    return fallbackPeerRowsByDev;
  }
  fallbackPeerRowsCheckedAt = now;
  const cacheFile =
    process.env.THEO_PEER_CACHE_PATH || path.join(CLAUDE_DIR, '.theo-cloud-sessions-cache.json');
  let mtime = 0;
  try {
    mtime = fs.statSync(cacheFile).mtimeMs;
  } catch {
    mtime = 0;
  }
  if (mtime === fallbackPeerRowsMtime) {
    return fallbackPeerRowsByDev;
  }
  fallbackPeerRowsMtime = mtime;
  const map = new Map();
  if (mtime) {
    try {
      const selfId = String(getSelfDeviceRef().id || '').trim();
      const parsed = JSON.parse(fs.readFileSync(cacheFile, 'utf8')) || {};
      if (parsed.peerOnly === true) {
        for (const r of Array.isArray(parsed?.snapshot?.rows) ? parsed.snapshot.rows : []) {
          const devId = String(r?.deviceId || '').trim();
          const rid = String(r?.id || '').trim();
          if (!devId || !rid || devId === selfId) continue;
          if (!map.has(devId)) map.set(devId, new Set());
          map.get(devId).add(rid);
        }
      }
      if (parsed.deviceStates && typeof parsed.deviceStates === 'object') {
        for (const [devId, entry] of Object.entries(parsed.deviceStates)) {
          if (!devId || devId === selfId) continue;
          const rows = Array.isArray(entry?.snapshot?.rows)
            ? entry.snapshot.rows
            : Array.isArray(entry?.rows)
              ? entry.rows
              : [];
          for (const r of rows) {
            const rid = String(r?.id || '').trim();
            if (!rid) continue;
            if (!map.has(devId)) map.set(devId, new Set());
            map.get(devId).add(rid);
          }
        }
      }
    } catch {}
  }
  fallbackPeerRowsByDev = map;
  return map;
}

function loadFleetHomes() {
  const now = Date.now();
  const filePath = fleetHomesPath();
  if (filePath !== fleetHomesCachePath) {
    fleetHomesCache = null;
    fleetHomesCachePath = filePath;
  }
  if (fleetHomesCache && now - fleetHomesCheckedAt < FLEET_HOMES_RECHECK_MS) {
    return fleetHomesCache;
  }
  fleetHomesCheckedAt = now;
  let mtimeMs = 0;
  try {
    mtimeMs = fs.statSync(filePath).mtimeMs;
  } catch {
    mtimeMs = 0;
  }
  if (fleetHomesCache && mtimeMs === fleetHomesMtimeMs) {
    return fleetHomesCache;
  }
  const out = {};
  if (mtimeMs) {
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      const homes = parsed && typeof parsed === 'object' ? parsed.homes || parsed : {};
      for (const [home, dev] of Object.entries(homes || {})) {
        const key = normalizeHomePath(home);
        const id = String(dev?.id || '').trim();
        if (key && id) {
          const hasRowIds = Array.isArray(dev?.rowIds);
          const rowIds = hasRowIds
            ? dev.rowIds.map((x) => String(x || '').trim()).filter(Boolean).slice(0, MAX_FLEET_HOME_ROW_IDS)
            : [];
          out[key] = {
            id,
            name: String(dev?.name || '').trim(),
            hasRowIds,
            rowIds,
            rowIdsSet: hasRowIds ? new Set(rowIds) : null
          };
        }
      }
    } catch {}
  }
  fleetHomesCache = out;
  fleetHomesMtimeMs = mtimeMs;
  return out;
}

// Records the home folder each other host published. `devices` is a list of { id, name, homedir, rowIds? }.
function rememberFleetHomes(devices, selfId = '') {
  if (!Array.isArray(devices) || devices.length === 0) return false;
  const selfHome = normalizeHomePath(selfHomeDir());
  const cur = loadFleetHomes();
  const next = {};
  for (const [k, v] of Object.entries(cur)) {
    next[k] = {
      id: v.id,
      name: v.name,
      hasRowIds: Boolean(v.hasRowIds),
      rowIds: Array.isArray(v.rowIds) ? v.rowIds.slice() : [],
      rowIdsSet: v.rowIdsSet ? new Set(v.rowIdsSet) : null
    };
  }
  let changed = false;
  for (const dev of devices) {
    const id = String(dev?.id || '').trim();
    const home = normalizeHomePath(dev?.homedir);
    if (!id || !home || id === selfId || home === selfHome) continue;
    // A home folder is at least two folders deep (C:\Users\name, /home/name). Anything shallower, such as a drive
    // root, would claim every session on this PC for another host.
    if (!/^(?:[a-z]:)?(?:\\[^\\]+){2,}$/.test(home)) continue;
    const name = String(dev?.name || '').trim();
    const prev = next[home];
    let rowIdsChanged = false;
    let nextRowIds = prev?.rowIds || [];
    let nextHasRowIds = Boolean(prev?.hasRowIds);
    if (Array.isArray(dev?.rowIds)) {
      const seen = new Set();
      const mergedIds = [];
      for (const rawId of dev.rowIds) {
        const rid = String(rawId || '').trim();
        if (rid && !seen.has(rid)) {
          seen.add(rid);
          mergedIds.push(rid);
          if (mergedIds.length >= MAX_FLEET_HOME_ROW_IDS) break;
        }
      }
      // Keep previously seen restored session ids if the same device still owns this home folder.
      if (prev && prev.id === id && Array.isArray(prev.rowIds)) {
        for (const oldId of prev.rowIds) {
          if (mergedIds.length >= MAX_FLEET_HOME_ROW_IDS) break;
          if (oldId && !seen.has(oldId)) {
            seen.add(oldId);
            mergedIds.push(oldId);
          }
        }
      }
      const prevSet = prev?.rowIdsSet || new Set();
      if (!prev?.hasRowIds || mergedIds.length !== prevSet.size || mergedIds.some((x) => !prevSet.has(x))) {
        rowIdsChanged = true;
      }
      nextRowIds = mergedIds;
      nextHasRowIds = true;
    }
    if (!prev || prev.id !== id || (name && prev.name !== name) || rowIdsChanged) {
      next[home] = {
        id,
        name: name || prev?.name || '',
        hasRowIds: nextHasRowIds,
        rowIds: nextRowIds,
        rowIdsSet: nextHasRowIds ? new Set(nextRowIds) : null
      };
      changed = true;
    }
  }
  if (!changed) return false;
  const serializedHomes = {};
  for (const [k, v] of Object.entries(next)) {
    serializedHomes[k] = v.hasRowIds
      ? { id: v.id, name: v.name, rowIds: v.rowIds }
      : { id: v.id, name: v.name };
  }
  const filePath = fleetHomesPath();
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const tmp = `${filePath}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ homes: serializedHomes, updatedAt: Date.now() }, null, 2), 'utf8');
    fs.renameSync(tmp, filePath);
  } catch {}
  fleetHomesCache = next;
  fleetHomesCachePath = filePath;
  fleetHomesCheckedAt = Date.now();
  try {
    fleetHomesMtimeMs = fs.statSync(filePath).mtimeMs;
  } catch {
    fleetHomesMtimeMs = -1;
  }
  return true;
}

function findFleetHomeOwner(cwdLow) {
  if (!cwdLow) return null;
  const homes = loadFleetHomes();
  let best = null;
  let bestHome = '';
  let bestLen = 0;
  for (const home of Object.keys(homes)) {
    if (home.length > bestLen && (cwdLow === home || cwdLow.startsWith(`${home}\\`))) {
      best = homes[home];
      bestHome = home;
      bestLen = home.length;
    }
  }
  return best ? { ...best, homeKey: bestHome } : null;
}

function isRowPublishedByPeer(homeOwner, rowId, opts = {}) {
  const cleanId = String(rowId || '').trim();
  if (!cleanId || !homeOwner?.id) return false;
  if (opts?.peerOwnedRowIds instanceof Map) {
    const devSet = opts.peerOwnedRowIds.get(homeOwner.id);
    if (devSet instanceof Set) return devSet.has(cleanId);
  }
  if (homeOwner.hasRowIds && homeOwner.rowIdsSet instanceof Set) {
    return homeOwner.rowIdsSet.has(cleanId);
  }
  const fallbackMap = loadFallbackPeerRowIdsByDevice();
  const fallbackSet = fallbackMap.get(homeOwner.id);
  if (fallbackSet instanceof Set) {
    return fallbackSet.has(cleanId);
  }
  return false;
}

// This host's saved id and name, without the binary probing getDeviceIdentity() does. Cached briefly because it is
// asked once per session row.
let selfDeviceRefCache = null;
let selfDeviceRefAt = 0;
function getSelfDeviceRef() {
  const now = Date.now();
  if (selfDeviceRefCache && now - selfDeviceRefAt < FLEET_HOMES_RECHECK_MS) {
    return selfDeviceRefCache;
  }
  const saved = loadDeviceConfig() || {};
  const defaults = inferDefaultDeviceIdentity();
  const savedName = String(saved.name || '').trim();
  selfDeviceRefCache = {
    id: cleanDeviceId(saved.id) || defaults.id,
    name:
      savedName && !RETIRED_DEFAULT_DEVICE_NAMES.has(savedName.toLowerCase()) ? savedName : defaults.name
  };
  selfDeviceRefAt = now;
  return selfDeviceRefCache;
}

// Owner of a session row.
//  - A row another host published (opts.trustStamp, or a row marked as coming from the store or a peer) belongs to
//    the device id stamped on it: that host listed it as its own.
//  - A local row belongs, in this order, to the host whose published home folder contains its working folder
//    (unless that path is a local junction to this PC's own home and the session was started or opened here),
//    to this host when the folder is under its own home, to the device id stamped on it, then to the caller's fallback.
function inferRowOwnerDevice(rowOrCwd, fallbackDevice = null, opts = {}) {
  const makeOwner = (id, name) => ({ id, name: name || id, deviceId: id, deviceName: name || id });
  const r = typeof rowOrCwd === 'object' && rowOrCwd ? rowOrCwd : { cwd: String(rowOrCwd || '') };
  const explicitId = String(r.deviceId || '').trim();
  const explicitName = String(r.deviceName || '').trim();
  if (explicitId && (opts.trustStamp || r.source === 'cloud-relay' || r.remotePeer === true)) {
    return makeOwner(explicitId, explicitName);
  }
  const cwdLow = normalizeHomePath(r.cwd);
  const homeOwner = findFleetHomeOwner(cwdLow);
  let underLocalHomeAlias = false;
  if (homeOwner) {
    if (isLocalHomeAlias(homeOwner.homeKey)) {
      underLocalHomeAlias = true;
      const locallyActive = Boolean(r.open || r.active || r.directStreaming || r.status === 'working');
      if (!locallyActive && isRowPublishedByPeer(homeOwner, r.id, opts)) {
        return makeOwner(homeOwner.id, homeOwner.name || (explicitId === homeOwner.id ? explicitName : ''));
      }
    } else {
      return makeOwner(homeOwner.id, homeOwner.name || (explicitId === homeOwner.id ? explicitName : ''));
    }
  }
  const selfHome = normalizeHomePath(selfHomeDir());
  if (cwdLow && ((selfHome && (cwdLow === selfHome || cwdLow.startsWith(`${selfHome}\\`))) || underLocalHomeAlias)) {
    // For a local row the caller's fallback is this host (the running bridge's own identity).
    if (fallbackDevice && fallbackDevice.id) {
      return makeOwner(fallbackDevice.id, fallbackDevice.name || fallbackDevice.id);
    }
    const self = getSelfDeviceRef();
    return makeOwner(self.id, self.name);
  }
  if (explicitId) {
    return makeOwner(explicitId, explicitName);
  }
  if (r.source === 'cloud-relay') {
    // A row that arrived from the store without an owner stamp belongs to some other host, never to this one.
    return makeOwner('unknown-host', 'Another PC');
  }
  if (fallbackDevice && fallbackDevice.id) {
    return makeOwner(fallbackDevice.id, fallbackDevice.name || fallbackDevice.id);
  }
  const self = getSelfDeviceRef();
  return makeOwner(self.id, self.name);
}

function normalizePinTimestamp(rawVal) {
  const num = Number(rawVal || 0);
  if (!Number.isFinite(num) || num <= 0) {
    return 0;
  }
  return Math.floor(num < 1e11 ? num * 1000 : num);
}

function pruneUnpinnedMap(rawMap, maxEntries = 200) {
  if (!rawMap || typeof rawMap !== 'object') {
    return {};
  }
  const entries = [];
  for (const [k, v] of Object.entries(rawMap)) {
    const id = String(k || '').trim();
    const ts = normalizePinTimestamp(v);
    if (id && ts > 0) {
      entries.push([id, ts]);
    }
  }
  if (entries.length > maxEntries) {
    entries.sort((a, b) => b[1] - a[1]);
    entries.length = maxEntries;
  }
  return Object.fromEntries(entries);
}

function resolveRowPinState(row, pinnedMap = {}, unpinnedMap = {}) {
  const id = String(row?.id || '').trim();
  const isArchived = Boolean(row?.archived);
  const localPinAt = id ? normalizePinTimestamp(pinnedMap?.[id]) : 0;
  const localUnpinAt = id ? normalizePinTimestamp(unpinnedMap?.[id]) : 0;
  const localTs = Math.max(localPinAt, localUnpinAt);
  const localPinned = Boolean(localPinAt > 0 && localPinAt > localUnpinAt);

  const rowPinnedRaw = Boolean(row?.pinned);
  const rowPinAt = rowPinnedRaw ? normalizePinTimestamp(row?.pinnedAt || row?.pinUpdatedAt) || 1 : 0;
  const rowTs = normalizePinTimestamp(row?.pinUpdatedAt || rowPinAt);

  if (isArchived) {
    return {
      pinned: false,
      pinnedAt: 0,
      pinUpdatedAt: Math.max(localUnpinAt, rowTs)
    };
  }
  if (rowTs > localTs) {
    return {
      pinned: rowPinnedRaw,
      pinnedAt: rowPinnedRaw ? rowPinAt : 0,
      pinUpdatedAt: rowTs
    };
  }
  if (localTs > rowTs) {
    return {
      pinned: localPinned,
      pinnedAt: localPinned ? localPinAt : 0,
      pinUpdatedAt: localTs
    };
  }
  const tiedUnpinned = Boolean(localUnpinAt > 0 && localUnpinAt >= localPinAt && (!rowPinnedRaw || rowTs <= localUnpinAt));
  if (tiedUnpinned) {
    return { pinned: false, pinnedAt: 0, pinUpdatedAt: localTs };
  }
  const tiedPinned = Boolean(localPinned || rowPinnedRaw);
  const effPinAt = tiedPinned ? Math.max(localPinAt, rowPinAt) || 1 : 0;
  return {
    pinned: tiedPinned,
    pinnedAt: effPinAt,
    pinUpdatedAt: Math.max(localTs, rowTs, effPinAt)
  };
}

// Sessions, groups and workspaces of every host except this one, from the store's `device_states` map. Each row is
// stamped with the host that published it. This is what a host shows as "sessions on my other PCs".
function buildPeerSnapshot(deviceStates, selfId = '') {
  const rows = [];
  const groups = [];
  const workspaces = [];
  const seenRowById = new Map();
  const seenGroups = new Set();
  const seenWorkspaces = new Set();
  const entries = Object.entries(deviceStates && typeof deviceStates === 'object' ? deviceStates : {})
    .filter(([devId, entry]) => devId && devId !== selfId && entry && typeof entry === 'object')
    .sort((a, b) => Number(b[1].updatedAt || 0) - Number(a[1].updatedAt || 0));
  for (const [devId, entry] of entries) {
    const devName = String(entry.device?.name || devId).trim() || devId;
    const snap = entry.snapshot && typeof entry.snapshot === 'object' ? entry.snapshot : {};
    const entryRows = Array.isArray(snap.rows) ? snap.rows : Array.isArray(entry.rows) ? entry.rows : [];
    for (const r of entryRows) {
      if (!r || !r.id) continue;
      const prevRow = seenRowById.get(r.id);
      if (prevRow) {
        const curTs = normalizePinTimestamp(r.pinUpdatedAt || (r.pinned ? r.pinnedAt || 1 : 0));
        const prevTs = normalizePinTimestamp(prevRow.pinUpdatedAt || (prevRow.pinned ? prevRow.pinnedAt || 1 : 0));
        if (curTs > prevTs && !prevRow.archived) {
          prevRow.pinned = Boolean(r.pinned);
          prevRow.pinnedAt = r.pinned ? normalizePinTimestamp(r.pinnedAt || curTs) || 1 : 0;
          prevRow.pinUpdatedAt = curTs;
        }
        continue;
      }
      const nextRow = { ...r, deviceId: devId, deviceName: devName };
      seenRowById.set(r.id, nextRow);
      rows.push(nextRow);
    }
    for (const g of Array.isArray(snap.groups) ? snap.groups : []) {
      if (!g || !g.id || seenGroups.has(g.id)) continue;
      seenGroups.add(g.id);
      groups.push(g);
    }
    const entryWorkspaces = Array.isArray(entry.workspaces)
      ? entry.workspaces
      : Array.isArray(snap.workspaces)
        ? snap.workspaces
        : [];
    for (const w of entryWorkspaces) {
      if (!w || !w.id || seenWorkspaces.has(w.id)) continue;
      seenWorkspaces.add(w.id);
      workspaces.push(w);
    }
  }
  return { generatedAt: Date.now(), rows, groups, workspaces };
}

// The store lives behind the Edge relay this host is paired with: <edge origin>/store, opened with the same derived
// token as the relay. A paired host therefore needs no store address of its own.
function deriveStoreEndpoint(edgeRelayUrl) {
  const base = String(edgeRelayUrl || '')
    .trim()
    .replace(/^wss:/i, 'https:')
    .replace(/^ws:/i, 'http:')
    .replace(/[?#].*$/, '')
    .replace(/\/+$/, '')
    .replace(/\/ws$/i, '');
  if (!base || !isSafeCloudEndpointUrl(base)) return '';
  return `${base}/store`;
}

function decodeMaybeBase64(val) {
  const s = String(val || '').trim();
  if (!s) return '';
  if (/^https?:\/\//i.test(s) || /^[0-9a-f]{32,}$/i.test(s)) return s;
  try {
    const dec = Buffer.from(s, 'base64').toString('utf8').trim();
    if (dec && /^[\x20-\x7e]+$/.test(dec)) return dec;
  } catch {}
  return s;
}

function loadTheoCredentials(extraDir = '') {
  let fileCfg = {};
  try {
    if (fs.existsSync(credFilePath())) {
      const parsed = JSON.parse(fs.readFileSync(credFilePath(), 'utf8'));
      if (parsed && typeof parsed === 'object') {
        fileCfg = parsed;
      }
    }
  } catch {}

  let legacyCfg = {};
  const legacyCandidates = [
    extraDir ? path.join(extraDir, 'remote-relay.json') : '',
    path.join(__dirname, 'remote-relay.json')
  ].filter(Boolean);
  for (const p of legacyCandidates) {
    try {
      if (fs.existsSync(p)) {
        const parsed = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (parsed && typeof parsed === 'object') {
          legacyCfg = parsed;
          break;
        }
      }
    } catch {}
  }

  const edgeAccessKey = String(
    process.env.THEO_EDGE_KEY || fileCfg.edgeAccessKey || ''
  ).trim();
  const edgeRelayUrl = String(
    process.env.THEO_EDGE_RELAY_URL ||
      fileCfg.edgeRelayUrl ||
      legacyCfg.edgeUrl ||
      DEFAULT_EDGE_RELAY_URL
  ).trim();

  // Store address, in order: an explicit environment override, the store behind the paired Edge relay, then
  // whatever the credentials file holds. Deriving it means a host paired with the relay follows a store move
  // without any per-PC step. `cloudPinned: true` in the file keeps a hand-set address instead.
  const envCloudUrl = String(process.env.THEO_CLOUD_URL || '').trim();
  const envCloudKey = String(process.env.THEO_CLOUD_KEY || '').trim();
  const fileCloudUrl = decodeMaybeBase64(fileCfg.cloudUrl || fileCfg.u || legacyCfg.u || '');
  const fileCloudKey = decodeMaybeBase64(fileCfg.cloudKey || fileCfg.k || legacyCfg.k || '');
  const derivedStoreUrl = edgeAccessKey ? deriveStoreEndpoint(edgeRelayUrl) : '';
  let cloudUrl = '';
  let cloudKey = '';
  let cloudSource = 'none';
  if (envCloudUrl || envCloudKey) {
    cloudUrl = decodeMaybeBase64(envCloudUrl) || fileCloudUrl;
    cloudKey = decodeMaybeBase64(envCloudKey) || fileCloudKey;
    cloudSource = 'env';
  } else if (derivedStoreUrl && fileCfg.cloudPinned !== true) {
    cloudUrl = derivedStoreUrl;
    cloudKey = deriveEdgeAuthToken(edgeAccessKey);
    cloudSource = 'edge';
  } else if (fileCloudUrl || fileCloudKey) {
    cloudUrl = fileCloudUrl;
    cloudKey = fileCloudKey;
    cloudSource = 'file';
  }

  const port = Number(process.env.THEO_BRIDGE_PORT || fileCfg.port || legacyCfg.port || 4318) || 4318;
  const allowLan = Boolean(
    process.env.THEO_ALLOW_LAN === '1' || fileCfg.allowLan === true
  );

  return {
    cloudUrl,
    cloudKey,
    cloudSource,
    cloudPinned: fileCfg.cloudPinned === true,
    // What the credentials file itself holds, which differs from the address in use when that one is derived.
    fileCloudUrl,
    fileCloudKey,
    u: cloudUrl ? Buffer.from(cloudUrl, 'utf8').toString('base64') : '',
    k: cloudKey ? Buffer.from(cloudKey, 'utf8').toString('base64') : '',
    edgeAccessKey,
    // Fallback to cloudKey only if edgeAccessKey has not been minted on a host yet
    effectiveEdgeSecret: edgeAccessKey || cloudKey,
    edgeRelayUrl,
    port,
    allowLan
  };
}

function saveTheoCredentials(patch = {}) {
  const cur = loadTheoCredentials();
  // The file keeps what it held: a derived (or environment) store address is never written over a hand-set one,
  // so saving an unrelated field cannot lose it.
  const nextCloudUrl =
    patch.cloudUrl !== undefined ? decodeMaybeBase64(patch.cloudUrl) : cur.fileCloudUrl;
  const nextCloudKey =
    patch.cloudKey !== undefined ? decodeMaybeBase64(patch.cloudKey) : cur.fileCloudKey;
  const next = {
    u: nextCloudUrl ? Buffer.from(nextCloudUrl, 'utf8').toString('base64') : '',
    k: nextCloudKey ? Buffer.from(nextCloudKey, 'utf8').toString('base64') : '',
    edgeAccessKey:
      patch.edgeAccessKey !== undefined
        ? String(patch.edgeAccessKey || '').trim()
        : cur.edgeAccessKey || '',
    edgeRelayUrl:
      patch.edgeRelayUrl !== undefined
        ? String(patch.edgeRelayUrl || '').trim()
        : cur.edgeRelayUrl || DEFAULT_EDGE_RELAY_URL,
    port: Number(patch.port || cur.port || 4318) || 4318,
    allowLan: patch.allowLan !== undefined ? Boolean(patch.allowLan) : Boolean(cur.allowLan),
    ...(patch.cloudPinned !== undefined
      ? patch.cloudPinned
        ? { cloudPinned: true }
        : {}
      : cur.cloudPinned
        ? { cloudPinned: true }
        : {}),
    updatedAt: Date.now()
  };
  try {
    fs.mkdirSync(path.dirname(credFilePath()), { recursive: true });
    fs.writeFileSync(credFilePath(), JSON.stringify(next, null, 2), { encoding: 'utf8', mode: 0o600 });
  } catch {}
  return loadTheoCredentials();
}

function buildPairTokenBase64Url(creds = null) {
  const c = creds || loadTheoCredentials();
  const edgeKey = String(c.edgeAccessKey || c.effectiveEdgeSecret || '').trim();
  const cloudUrl = decodeMaybeBase64(c.cloudUrl || c.u || '');
  const cloudKey = decodeMaybeBase64(c.cloudKey || c.k || '');
  if (!edgeKey && !cloudUrl && !cloudKey) return '';
  const payload = {
    v: 1,
    e: edgeKey,
    r: String(c.edgeRelayUrl || c.w || DEFAULT_EDGE_RELAY_URL).trim(),
    u: cloudUrl,
    k: cloudKey,
    p: Number(c.port || c.p || 4318) || 4318
  };
  return Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
}

function isSafeCloudEndpointUrl(rawUrl) {
  const u = String(rawUrl || '').trim();
  if (!u) return true;
  return /^https:\/\/[^\s]+$/i.test(u) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/|$)/i.test(u);
}

function isSafeEdgeEndpointUrl(rawUrl) {
  const u = String(rawUrl || '').trim();
  if (!u) return true;
  return (
    /^(wss|https):\/\/[^\s]+$/i.test(u) ||
    /^(ws|http):\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/|$)/i.test(u)
  );
}

function parsePairTokenBase64Url(rawToken) {
  const text = String(rawToken || '').trim();
  if (!text) return null;
  const hashMatch = text.match(/#pair=([A-Za-z0-9_=-]{16,8192})/i);
  const envMatch =
    !hashMatch && text.match(/THEO_PAIR_TOKEN\s*=\s*['"]?([A-Za-z0-9_=-]{16,8192})['"]?/i);
  const clean = hashMatch
    ? hashMatch[1]
    : envMatch
      ? envMatch[1]
      : text
          .replace(/^#?pair=/i, '')
          .split(/[\s&'"]+/)[0]
          .trim();
  if (!clean) return null;
  try {
    const jsonStr = Buffer.from(clean, 'base64url').toString('utf8');
    const obj = JSON.parse(jsonStr);
    if (!obj || typeof obj !== 'object') return null;
    const edgeAccessKey = String(obj.e || obj.edgeAccessKey || '').trim();
    const cloudUrl = decodeMaybeBase64(obj.u || obj.cloudUrl || '');
    const cloudKey = decodeMaybeBase64(obj.k || obj.cloudKey || '');
    const rawEdgeUrl = String(obj.r || obj.w || obj.edgeRelayUrl || '').trim();
    if (!edgeAccessKey && !cloudKey) return null;
    if (cloudUrl && !cloudKey) return null;
    if (!isSafeCloudEndpointUrl(cloudUrl) || !isSafeEdgeEndpointUrl(rawEdgeUrl)) return null;
    return {
      edgeAccessKey,
      edgeRelayUrl: rawEdgeUrl || DEFAULT_EDGE_RELAY_URL,
      cloudUrl,
      cloudKey,
      port: Number(obj.p || obj.port || 4318) || 4318
    };
  } catch {
    if (/^[a-fA-F0-9]{32,128}$/.test(clean)) {
      return {
        edgeAccessKey: clean,
        edgeRelayUrl: DEFAULT_EDGE_RELAY_URL,
        cloudUrl: '',
        cloudKey: '',
        port: 4318
      };
    }
    return null;
  }
}

function loadBundledEdgeRelayUrl() {
  return loadTheoCredentials().edgeRelayUrl;
}

function loadDeviceConfig() {
  try {
    if (fs.existsSync(deviceFilePath())) {
      const parsed = JSON.parse(fs.readFileSync(deviceFilePath(), 'utf8'));
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    }
  } catch {}
  return null;
}

function saveDeviceConfig(cfg) {
  try {
    fs.mkdirSync(path.dirname(deviceFilePath()), { recursive: true });
    fs.writeFileSync(deviceFilePath(), JSON.stringify(cfg, null, 2), 'utf8');
  } catch {}
  selfDeviceRefCache = null;
}

function getDeviceIdentity(overrides = {}) {
  const defaults = inferDefaultDeviceIdentity();
  const saved = loadDeviceConfig() || {};
  const agyBin = resolveAgyBinaryPath();
  const claudeBin = resolveClaudeBinaryPath();
  const capabilities = [];
  if (agyBin) capabilities.push('antigravity');
  if (claudeBin) capabilities.push('claude');

  let username = '';
  try {
    username = os.userInfo().username || '';
  } catch {}

  // A saved id is kept as it is (it is only a stable key). A saved name is kept unless it is one an older build
  // assigned from the home folder, and the old primary / secondary role is retired: every host is `host`.
  const savedName = String(saved.name || '').trim();
  const savedNameIsRetired = Boolean(savedName) && RETIRED_DEFAULT_DEVICE_NAMES.has(savedName.toLowerCase());
  const savedRoleIsRetired = Boolean(saved.id) && saved.role !== HOST_ROLE;
  const resolvedId = cleanDeviceId(overrides.id) || cleanDeviceId(saved.id) || defaults.id;
  const savedIdNeedsRewrite = Boolean(saved.id) && saved.id !== resolvedId && !overrides.id;
  const identity = {
    id: resolvedId,
    name: String(overrides.name || (savedNameIsRetired ? '' : savedName) || defaults.name).trim(),
    role: HOST_ROLE,
    hostname: os.hostname(),
    username,
    homedir: os.homedir(),
    platform: process.platform,
    arch: process.arch,
    lanIps: getLanIps(),
    capabilities,
    binaries: {
      agy: agyBin,
      claude: claudeBin
    },
    edgeRelayUrl: String(
      overrides.edgeRelayUrl !== undefined
        ? overrides.edgeRelayUrl
        : process.env.THEO_EDGE_RELAY_URL || saved.edgeRelayUrl || loadBundledEdgeRelayUrl() || ''
    ).trim(),
    updatedAt: Date.now()
  };

  if (
    !saved.id ||
    overrides.name ||
    overrides.edgeRelayUrl !== undefined ||
    savedNameIsRetired ||
    savedRoleIsRetired ||
    savedIdNeedsRewrite
  ) {
    saveDeviceConfig({
      id: identity.id,
      name: identity.name,
      role: identity.role,
      hostname: identity.hostname,
      edgeRelayUrl: identity.edgeRelayUrl,
      createdAt: saved.createdAt || Date.now(),
      updatedAt: Date.now()
    });
  }

  return identity;
}

function updateDeviceConfig(patch = {}) {
  const current = getDeviceIdentity();
  const merged = {
    ...(loadDeviceConfig() || {}),
    id: patch.id ? slugifyId(patch.id) : current.id,
    name: patch.name ? String(patch.name).trim().slice(0, 48) : current.name,
    role: HOST_ROLE,
    edgeRelayUrl:
      patch.edgeRelayUrl !== undefined
        ? String(patch.edgeRelayUrl || '').trim()
        : current.edgeRelayUrl,
    updatedAt: Date.now()
  };
  saveDeviceConfig(merged);
  return getDeviceIdentity();
}

function deriveEdgeAuthToken(relayKey) {
  const cleanKey = String(relayKey || '').trim();
  if (!cleanKey) return '';
  return crypto
    .createHash('sha256')
    .update(`theo-edge-v1:${cleanKey}`, 'utf8')
    .digest('hex');
}

// Domain-separated 32-byte signing key for self-updating `theo-hub` bundles, derived from `edgeAccessKey` (never from
// the derived `AUTH_TOKEN` stored on the Worker), so only a paired PC holding `edgeAccessKey` can sign `hub_release`.
function deriveBundleSignKey(edgeAccessKey) {
  const cleanKey = String(edgeAccessKey || '').trim();
  if (!cleanKey || cleanKey.length < 24) return null;
  return crypto
    .createHash('sha256')
    .update(`theo-bundle-sign-v1:${cleanKey}`, 'utf8')
    .digest();
}

// ---- Host user-activity tracking (last-typed PC wins untargeted commands & coordinator duty) ----
let lastInProcessUserActivityAt = 0;
let cachedOsInputAt = 0;
let osIdlePollInFlight = false;
let lastOsIdlePollAt = 0;
let launcherIdleCapCache = { key: '', supported: false };
const OS_IDLE_POLL_INTERVAL_MS = 10000;

function noteLocalUserActivity(atMs = Date.now()) {
  const n = Number(atMs);
  if (Number.isFinite(n) && n > lastInProcessUserActivityAt) {
    lastInProcessUserActivityAt = n;
  }
}

// Windows 11 Smart App Control (VerifiedAndReputablePolicyState = 1) blocks the unsigned csc-built THEO.exe and
// raises a "Part of this app has been blocked" toast on EVERY attempt. Before this guard the 10 s idle poll retried
// forever (175 Code Integrity blocks overnight on 2026-11-17/18). State lives on globalThis so a module reload
// does not re-probe. Read once per process with signed reg.exe.
const LAUNCHER_GUARD_KEY = Symbol.for('theo.deviceIdentity.launcherGuard');
const launcherGuard =
  globalThis[LAUNCHER_GUARD_KEY] ||
  (globalThis[LAUNCHER_GUARD_KEY] = { sac: null, sacPending: false, blockKey: '', blockFailures: 0, blockedUntil: 0 });
const LAUNCHER_POLICY_BLOCK_CODES = /^(UNKNOWN|EACCES|EPERM)$/i;
const LAUNCHER_POLICY_BLOCK_THRESHOLD = 2;
const LAUNCHER_POLICY_BLOCK_BACKOFF_MS = 6 * 60 * 60 * 1000;

function detectSmartAppControlEnforced(opts, done) {
  opts = opts || {};
  if (typeof opts.sacEnforced === 'boolean') {
    done(opts.sacEnforced);
    return;
  }
  const hasMockReg = typeof opts.regExecFile === 'function';
  // Sandboxed tests mock child_process.execFile; never spend a scripted response on reg.exe there unless injected.
  if (
    !hasMockReg &&
    (process.env.THEO_SMOKE_TEST === '1' || process.env.THEO_HEADLESS_TEST === '1' || process.platform !== 'win32')
  ) {
    done(false);
    return;
  }
  if (launcherGuard.sac !== null) {
    done(launcherGuard.sac);
    return;
  }
  if (launcherGuard.sacPending) {
    done(true); // treat as enforced until the one-time read lands: never spawn THEO.exe blind
    return;
  }
  launcherGuard.sacPending = true;
  const execFn = hasMockReg ? opts.regExecFile : execFile;
  const regExe = path.join(process.env.SystemRoot || process.env.WINDIR || 'C:\\Windows', 'System32', 'reg.exe');
  try {
    execFn(
      regExe,
      ['query', 'HKLM\\SYSTEM\\CurrentControlSet\\Control\\CI\\Policy', '/v', 'VerifiedAndReputablePolicyState'],
      { timeout: 5000, windowsHide: true },
      (err, stdout) => {
        launcherGuard.sacPending = false;
        if (!err) {
          launcherGuard.sac = /VerifiedAndReputablePolicyState\s+REG_DWORD\s+0x1\b/i.test(String(stdout || ''));
          done(launcherGuard.sac);
          return;
        }
        // Only cache false when reg.exe ran to exit code 1 (value/key genuinely absent on non-SAC Windows).
        if (!err.killed && !err.signal && err.code === 1) {
          launcherGuard.sac = false;
          done(false);
          return;
        }
        // Timeout or spawn error: fail closed to the signed watcher without poisoning cache.
        done(true);
      }
    );
  } catch {
    launcherGuard.sacPending = false;
    done(true);
  }
}

// Probes `THEO.exe --verify-config` once per (path, mtimeMs, size). Pre-upgrade THEO.exe binaries only understand
// `--verify-config` (side-effect-free on all versions) and treat unknown flags like `--idle-ms` as a normal GUI launch.
function probeLauncherSupportsIdleMs(exePath, done) {
  let st;
  try {
    st = fs.statSync(exePath);
  } catch {
    done(false, 'exec_error');
    return;
  }
  const statKey = `${exePath}|${st.mtimeMs}|${st.size}`;
  if (launcherIdleCapCache.key === statKey) {
    done(launcherIdleCapCache.supported);
    return;
  }
  if (launcherGuard.blockKey === statKey && Date.now() < launcherGuard.blockedUntil) {
    done(false, 'policy_blocked');
    return;
  }
  try {
    execFile(
      exePath,
      ['--verify-config'],
      { timeout: 2500, windowsHide: true },
      (err, stdout) => {
        if (err && !err.killed && LAUNCHER_POLICY_BLOCK_CODES.test(String(err.code || ''))) {
          // Code Integrity / AV refused to start the binary. Retry once (a scan lock clears), then back off for this
          // exact file so Windows does not toast on every 10 s poll; a recompiled THEO.exe gets a fresh statKey.
          if (launcherGuard.blockKey !== statKey) {
            launcherGuard.blockKey = statKey;
            launcherGuard.blockFailures = 0;
          }
          launcherGuard.blockFailures += 1;
          if (launcherGuard.blockFailures >= LAUNCHER_POLICY_BLOCK_THRESHOLD) {
            launcherGuard.blockedUntil = Date.now() + LAUNCHER_POLICY_BLOCK_BACKOFF_MS;
            launcherGuard.blockFailures = 0;
            done(false, 'policy_blocked');
            return;
          }
          done(false, 'exec_error');
          return;
        }
        if (err && (err.killed || /^(EBUSY|ENOENT|ETIMEDOUT)$/i.test(String(err.code || '')))) {
          // Transient AV/scan lock or killed timeout on THEO.exe: do not cache supported=false.
          done(false, 'exec_error');
          return;
        }
        let supported = false;
        if (!err && stdout) {
          try {
            const parsed = JSON.parse(String(stdout).trim());
            supported = Boolean(parsed && parsed.ok === true && parsed.supportsIdleMs === true);
          } catch {}
        }
        launcherIdleCapCache = { key: statKey, supported };
        done(supported);
      }
    );
  } catch {
    done(false, 'exec_error');
  }
}

function refreshOsIdleMsAsync(opts = {}) {
  if (process.platform !== 'win32' && !opts.forcePlatform) return;
  if (
    !opts.allowInSmokeTest &&
    (process.env.THEO_SMOKE_TEST === '1' || process.env.THEO_HEADLESS_TEST === '1')
  ) {
    return;
  }
  const now = Date.now();
  if (osIdlePollInFlight || (!opts.ignoreInterval && now - lastOsIdlePollAt < OS_IDLE_POLL_INTERVAL_MS)) {
    return;
  }
  const exePath =
    opts.exePath ||
    process.env.THEO_LAUNCHER_EXE_PATH ||
    path.join(os.homedir(), '.theo', 'THEO.exe');
  let exeExists = false;
  try {
    exeExists = fs.existsSync(exePath);
  } catch {}
  lastOsIdlePollAt = now;
  if (!exeExists) {
    // Script-mode launcher hosts (Smart App Control) delete THEO.exe: read the shared signed watcher instead.
    pollIdleWatcher(opts);
    return;
  }
  osIdlePollInFlight = true;
  detectSmartAppControlEnforced(opts, (sacEnforced) => {
    if (sacEnforced) {
      // Never spawn the unsigned THEO.exe here (every attempt raises a Windows toast); use the signed watcher.
      osIdlePollInFlight = false;
      pollIdleWatcher(opts);
      return;
    }
    runLauncherIdlePoll(exePath, opts);
  });
}

// ---- Signed OS idle watcher (hosts where THEO.exe cannot run) ----
// One hidden powershell.exe per PC (signed, so Smart App Control allows it) compiles GetLastInputInfo in memory and
// writes `~/.theo/os-input.json` every 5 s (on change, else a 20 s heartbeat). Every THEO process reads the file;
// whichever finds it stale spawns a watcher it owns (a named mutex per file keeps one alive; it exits with its owner).
const IDLE_WATCH_KEY = Symbol.for('theo.deviceIdentity.idleWatch');
const idleWatch = globalThis[IDLE_WATCH_KEY] || (globalThis[IDLE_WATCH_KEY] = { lastSpawnAt: 0, failedSpawns: 0 });
const IDLE_WATCH_FILE_NAME = 'os-input.json';
const IDLE_WATCH_PS1_NAME = 'theo-idle-watch.ps1';
const IDLE_WATCH_STALE_MS = 45000;
const IDLE_WATCH_RESPAWN_MS = 60000;
const IDLE_WATCH_RESPAWN_MAX_MS = 60 * 60 * 1000;
const IDLE_WATCH_PS1 = [
  'param([string]$OutFile, [int]$OwnerPid, [string]$MutexName, [int]$IntervalMs = 5000, [int]$HeartbeatMs = 20000)',
  '$ErrorActionPreference = "Stop"',
  '$created = $false',
  '$mutex = New-Object System.Threading.Mutex($true, $MutexName, [ref]$created)',
  'if (-not $created) { exit 0 }',
  'try {',
  '  $owner = $null',
  '  try { $owner = [Diagnostics.Process]::GetProcessById($OwnerPid); $null = $owner.Handle } catch { exit 0 }',
  '  Add-Type -IgnoreWarnings -WarningAction SilentlyContinue -TypeDefinition @"',
  'using System;',
  'using System.Runtime.InteropServices;',
  'public static class TheoIdleWatch {',
  '  [StructLayout(LayoutKind.Sequential)] struct LastInput { public uint cbSize; public uint dwTime; }',
  '  [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LastInput info);',
  '  public static long IdleMs() {',
  '    LastInput li = new LastInput();',
  '    li.cbSize = (uint)Marshal.SizeOf(typeof(LastInput));',
  '    if (!GetLastInputInfo(ref li)) return -1;',
  '    return (long)unchecked((uint)Environment.TickCount - li.dwTime);',
  '  }',
  '}',
  '"@',
  '  $lastAt = [long]0; $lastWrite = [long]0; $writeErrLogged = $false',
  '  $tmp = $OutFile + ".tmp"',
  '  while (-not $owner.HasExited) {',
  '    $idle = [TheoIdleWatch]::IdleMs()',
  '    $now = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()',
  '    $at = $lastAt',
  '    if ($idle -ge 0) { $at = $now - $idle }',
  '    if ($at -gt 0 -and ([Math]::Abs($at - $lastAt) -gt 1000 -or ($now - $lastWrite) -ge $HeartbeatMs)) {',
  '      $json = \'{"pid":\' + $PID + \',"lastInputAt":\' + $at + \',"writtenAt":\' + $now + \'}\'',
  '      try {',
  '        [IO.File]::WriteAllText($tmp, $json)',
  '        if ([IO.File]::Exists($OutFile)) { [IO.File]::Replace($tmp, $OutFile, [NullString]::Value) } else { [IO.File]::Move($tmp, $OutFile) }',
  '        $lastAt = $at; $lastWrite = $now',
  '      } catch {',
  '        if (-not $writeErrLogged) {',
  '          $writeErrLogged = $true',
  '          try { Add-Content -LiteralPath ($OutFile + ".error.log") -Value ((Get-Date -Format o) + " write failed: " + $_.Exception.Message) } catch {}',
  '        }',
  '      }',
  '    }',
  '    Start-Sleep -Milliseconds $IntervalMs',
  '  }',
  '} catch {',
  '  try {',
  '    $log = $OutFile + ".error.log"',
  '    if ((Test-Path -LiteralPath $log) -and (Get-Item -LiteralPath $log).Length -gt 65536) { Remove-Item -LiteralPath $log -Force }',
  '    Add-Content -LiteralPath $log -Value ((Get-Date -Format o) + " " + $_.Exception.Message)',
  '  } catch {}',
  '} finally {',
  '  try { $mutex.ReleaseMutex() } catch {}',
  '}',
  ''
].join('\r\n');

function readIdleWatchFile(file) {
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    const lastInputAt = Number(parsed && parsed.lastInputAt);
    const writtenAt = Number(parsed && parsed.writtenAt);
    if (!Number.isFinite(lastInputAt) || !Number.isFinite(writtenAt) || lastInputAt <= 0) return null;
    return { lastInputAt, writtenAt };
  } catch {
    return null;
  }
}

function ensureIdleWatchScript(dir) {
  const ps1 = path.join(dir, IDLE_WATCH_PS1_NAME);
  let current = null;
  try {
    current = fs.readFileSync(ps1, 'utf8');
  } catch {}
  if (current !== IDLE_WATCH_PS1) {
    // tmp + rename: a watcher another process just started never reads a half-written script.
    fs.mkdirSync(dir, { recursive: true });
    const tmp = `${ps1}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, IDLE_WATCH_PS1, 'utf8');
    fs.renameSync(tmp, ps1);
  }
  return ps1;
}

function idleWatchMutexName(file) {
  const digest = crypto.createHash('sha256').update(path.resolve(file).toLowerCase(), 'utf8').digest('hex');
  return `Local\\THEO-idle-watch-${digest.slice(0, 16)}`;
}

function spawnIdleWatcher(dir, file, opts) {
  const ps1 = ensureIdleWatchScript(dir);
  const psExe = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const args = [
    '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
    '-File', ps1, '-OutFile', file, '-OwnerPid', String(process.pid), '-MutexName', idleWatchMutexName(file)
  ];
  // Never `detached: true` on Windows (DETACHED_PROCESS pops a console); the watcher exits with its owner instead.
  const child = (opts.idleWatchSpawn || spawn)(psExe, args, { detached: false, windowsHide: true, stdio: 'ignore' });
  if (child && typeof child.on === 'function') child.on('error', () => {});
  if (child && typeof child.unref === 'function') child.unref();
}

function pollIdleWatcher(opts) {
  const done = typeof opts.onDone === 'function' ? opts.onDone : () => {};
  const dir = opts.theoDir || path.join(os.homedir(), '.theo');
  const file = opts.idleWatchFile || path.join(dir, IDLE_WATCH_FILE_NAME);
  const now = Date.now();
  const rec = readIdleWatchFile(file);
  if (rec && now - rec.writtenAt <= IDLE_WATCH_STALE_MS) {
    const observedAt = Math.min(rec.lastInputAt, now);
    if (observedAt > cachedOsInputAt) cachedOsInputAt = observedAt;
    idleWatch.failedSpawns = 0;
    done({ polled: true, idleMs: Math.max(0, Math.floor(now - observedAt)), source: 'watcher' });
    return;
  }
  // Each spawn that never produced a fresh file doubles the wait (60 s up to 1 h), so a watcher that cannot start
  // (ExecutionPolicy pinned by MachinePolicy, AMSI, ...) costs one powershell.exe an hour per process, not one a minute.
  const failed = Math.max(0, Number(idleWatch.failedSpawns) || 0);
  const respawnMs = Math.min(IDLE_WATCH_RESPAWN_MAX_MS, IDLE_WATCH_RESPAWN_MS * 2 ** Math.min(failed, 6));
  if (now - idleWatch.lastSpawnAt < respawnMs) {
    done({ polled: false, reason: 'watcher_starting' });
    return;
  }
  if (idleWatch.lastSpawnAt > 0) idleWatch.failedSpawns = failed + 1;
  idleWatch.lastSpawnAt = now;
  try {
    spawnIdleWatcher(dir, file, opts);
    done({ polled: false, reason: 'watcher_spawned' });
  } catch {
    done({ polled: false, reason: 'watcher_error' });
  }
}

function runLauncherIdlePoll(exePath, opts) {
  probeLauncherSupportsIdleMs(exePath, (supported, errReason) => {
    if (!supported) {
      osIdlePollInFlight = false;
      if (typeof opts.onDone === 'function') opts.onDone({ polled: false, reason: errReason || 'unsupported_launcher' });
      return;
    }
    try {
      execFile(
        exePath,
        ['--idle-ms'],
        { timeout: 1500, windowsHide: true },
        (err, stdout) => {
          osIdlePollInFlight = false;
          if (err) {
            if (typeof opts.onDone === 'function') opts.onDone({ polled: false, reason: 'exec_error' });
            return;
          }
          const parsed = Number(String(stdout || '').trim());
          if (Number.isFinite(parsed) && parsed >= 0) {
            const observedAt = Date.now() - Math.floor(parsed);
            if (observedAt > cachedOsInputAt) {
              cachedOsInputAt = observedAt;
            }
            if (typeof opts.onDone === 'function') opts.onDone({ polled: true, idleMs: Math.floor(parsed) });
          } else if (typeof opts.onDone === 'function') {
            opts.onDone({ polled: false, reason: 'bad_output' });
          }
        }
      );
    } catch {
      osIdlePollInFlight = false;
      if (typeof opts.onDone === 'function') opts.onDone({ polled: false, reason: 'exec_error' });
    }
  });
}

const _legacyBridgePrefCache = new Map();

// Determine whether the legacy in-process VS Code phone bridge override is active.
function isLegacyVsCodePhoneBridgeEnabled(opts = {}) {
  if (typeof opts?.legacyVsCodePhoneBridge === 'boolean') {
    return opts.legacyVsCodePhoneBridge;
  }
  const envRaw = process.env.THEO_LEGACY_VSCODE_BRIDGE;
  if (envRaw !== undefined && String(envRaw).trim() !== '') {
    const normalized = String(envRaw).trim().toLowerCase();
    if (normalized === '1' || normalized === 'true' || normalized === 'yes' || normalized === 'on') {
      return true;
    }
    if (normalized === '0' || normalized === 'false' || normalized === 'no' || normalized === 'off') {
      return false;
    }
  }
  const nodeFs = require('fs');
  const nodePath = require('path');
  const nodeOs = require('os');
  const home = String(
    opts?.homeDir ||
      opts?.home ||
      process.env.THEO_HOME ||
      process.env.HOME ||
      process.env.USERPROFILE ||
      nodeOs.homedir() ||
      ''
  ).trim();
  const hubStateFile = String(
    opts?.hubStateFile ||
      opts?.hubStateBackupPath ||
      opts?.diskBackupPath ||
      process.env.THEO_HUB_STATE_PATH ||
      (home ? nodePath.join(home, '.claude', '.theo-hub-state.json') : '')
  ).trim();
  if (!hubStateFile) return false;
  try {
    const st = nodeFs.statSync(hubStateFile);
    const cached = _legacyBridgePrefCache.get(hubStateFile);
    if (
      cached &&
      cached.mtimeMs === st.mtimeMs &&
      cached.ctimeMs === st.ctimeMs &&
      cached.size === st.size
    ) {
      return cached.value;
    }
    const raw = nodeFs.readFileSync(hubStateFile, 'utf8');
    const parsed = JSON.parse(raw);
    const value = Boolean(parsed?.preferences?.legacyVsCodePhoneBridge);
    if (_legacyBridgePrefCache.size > 32) {
      _legacyBridgePrefCache.clear();
    }
    _legacyBridgePrefCache.set(hubStateFile, {
      mtimeMs: st.mtimeMs,
      ctimeMs: st.ctimeMs,
      size: st.size,
      value
    });
    return value;
  } catch {
    _legacyBridgePrefCache.delete(hubStateFile);
    return false;
  }
}

const SERVICE_CUTOVER_KINDS = [
  'uiRpcTimeouts',
  'uiRpcDisconnects',
  'detachedUiPromptRefusals',
  'legacyBridgeFlips',
  'legacyYields'
];
const SERVICE_CUTOVER_KIND_SET = new Set(SERVICE_CUTOVER_KINDS);

function emptyServiceCutoverCounts() {
  return {
    uiRpcTimeouts: 0,
    uiRpcDisconnects: 0,
    detachedUiPromptRefusals: 0,
    legacyBridgeFlips: 0,
    legacyYields: 0
  };
}

let _cutoverTmpSeq = 0;

function getServiceCutoverStatsPath(opts = {}) {
  const nodeOs = require('os');
  const nodePath = require('path');
  const explicit = String(opts?.statsPath || process.env.THEO_CUTOVER_STATS_PATH || '').trim();
  if (explicit) return explicit;
  if (!opts?.homeDir && !opts?.home && opts?.hubStateFile) {
    return nodePath.join(nodePath.dirname(String(opts.hubStateFile)), '.theo-service-cutover-stats.json');
  }
  const home = String(
    opts?.homeDir ||
      opts?.home ||
      process.env.THEO_HOME ||
      process.env.HOME ||
      process.env.USERPROFILE ||
      nodeOs.homedir() ||
      ''
  ).trim();
  return home ? nodePath.join(home, '.claude', '.theo-service-cutover-stats.json') : '';
}

function canWriteServiceCutoverStats(opts = {}) {
  if (opts?.allowInSmokeTest === true || opts?.statsPath || process.env.THEO_CUTOVER_STATS_PATH) {
    return true;
  }
  return process.env.THEO_SMOKE_TEST !== '1';
}

function sanitizeCutoverAction(action) {
  const clean = String(action || '').trim();
  return /^[A-Za-z0-9_.:-]{1,48}$/.test(clean) ? clean : '';
}

function writeCutoverStatsAtomicSync(filePath, data) {
  const nodeFs = require('fs');
  const nodePath = require('path');
  if (!filePath || !data || typeof data !== 'object') return false;
  _cutoverTmpSeq = (_cutoverTmpSeq + 1) % 1000000;
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}-${_cutoverTmpSeq}`;
  try {
    nodeFs.mkdirSync(nodePath.dirname(filePath), { recursive: true });
    nodeFs.writeFileSync(tmp, JSON.stringify(data, null, 2) + '\n', 'utf8');
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        nodeFs.renameSync(tmp, filePath);
        return true;
      } catch (err) {
        if ((err?.code === 'EPERM' || err?.code === 'EBUSY') && attempt < 2) {
          try {
            const sab = new SharedArrayBuffer(4);
            Atomics.wait(new Int32Array(sab), 0, 0, 10);
          } catch {}
          continue;
        }
        throw err;
      }
    }
    return true;
  } catch {
    try {
      nodeFs.unlinkSync(tmp);
    } catch {}
    return false;
  }
}

function withCutoverStatsLock(statsPath, fn) {
  const nodeFs = require('fs');
  const nodePath = require('path');
  const lockPath = `${statsPath}.lock`;
  let acquired = false;
  try {
    nodeFs.mkdirSync(nodePath.dirname(statsPath), { recursive: true });
    for (let attempt = 0; attempt < 10; attempt += 1) {
      try {
        nodeFs.writeFileSync(lockPath, `${process.pid}:${Date.now()}`, { encoding: 'utf8', flag: 'wx' });
        acquired = true;
        break;
      } catch (err) {
        if (err?.code === 'EEXIST') {
          try {
            if (Date.now() - nodeFs.statSync(lockPath).mtimeMs > 5000) {
              nodeFs.unlinkSync(lockPath);
              continue;
            }
          } catch {}
          try {
            const sab = new SharedArrayBuffer(4);
            Atomics.wait(new Int32Array(sab), 0, 0, 12);
          } catch {}
          continue;
        }
        break;
      }
    }
    return fn();
  } finally {
    if (acquired) {
      try {
        nodeFs.unlinkSync(lockPath);
      } catch {}
    }
  }
}

function normalizeCutoverStatsDoc(raw) {
  const counts = emptyServiceCutoverCounts();
  const rawCounts = raw?.counts && typeof raw.counts === 'object' ? raw.counts : {};
  for (const k of SERVICE_CUTOVER_KINDS) {
    const n = Number(rawCounts[k] || 0);
    counts[k] = Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
  }
  const startedAt = Number(raw?.startedAt || 0);
  const updatedAt = Number(raw?.updatedAt || startedAt || 0);
  const rawLast = raw?.lastEvent && typeof raw.lastEvent === 'object' ? raw.lastEvent : null;
  const lastEvent =
    rawLast && SERVICE_CUTOVER_KIND_SET.has(rawLast.kind)
      ? {
          kind: rawLast.kind,
          action: sanitizeCutoverAction(rawLast.action),
          at: Number(rawLast.at || 0) || 0
        }
      : null;
  return {
    version: 1,
    startedAt: Number.isFinite(startedAt) && startedAt > 0 ? startedAt : 0,
    updatedAt: Number.isFinite(updatedAt) && updatedAt > 0 ? updatedAt : 0,
    counts,
    lastEvent
  };
}

function formatCutoverStatsSummary(doc, statsPath, nowMs = Date.now()) {
  const initialized = doc.startedAt > 0;
  const elapsedMs = initialized ? Math.max(0, Number(nowMs || Date.now()) - doc.startedAt) : 0;
  const elapsedDays = Number((elapsedMs / 86400000).toFixed(2));
  const totalIncidents = SERVICE_CUTOVER_KINDS.reduce((sum, k) => sum + Number(doc.counts[k] || 0), 0);
  const readyForThread3 = initialized && elapsedMs >= 7 * 86400 * 1000 && totalIncidents === 0;
  return {
    initialized,
    statsPath,
    startedAt: doc.startedAt,
    updatedAt: doc.updatedAt,
    elapsedMs,
    elapsedDays,
    totalIncidents,
    readyForThread3,
    counts: doc.counts,
    lastEvent: doc.lastEvent
  };
}

function readServiceCutoverStats(opts = {}) {
  const nodeFs = require('fs');
  const statsPath = getServiceCutoverStatsPath(opts);
  const nowMs = Number(opts?.nowMs || Date.now());
  if (!statsPath) {
    return formatCutoverStatsSummary(normalizeCutoverStatsDoc(null), '', nowMs);
  }
  try {
    if (nodeFs.existsSync(statsPath)) {
      const parsed = JSON.parse(nodeFs.readFileSync(statsPath, 'utf8'));
      return formatCutoverStatsSummary(normalizeCutoverStatsDoc(parsed), statsPath, nowMs);
    }
  } catch {}
  return formatCutoverStatsSummary(normalizeCutoverStatsDoc(null), statsPath, nowMs);
}

function ensureServiceCutoverStatsInitialized(opts = {}) {
  const nodeFs = require('fs');
  const statsPath = getServiceCutoverStatsPath(opts);
  const nowMs = Number(opts?.nowMs || Date.now());
  if (!statsPath || !canWriteServiceCutoverStats(opts)) {
    return readServiceCutoverStats(opts);
  }
  return withCutoverStatsLock(statsPath, () => {
    try {
      if (nodeFs.existsSync(statsPath)) {
        const parsed = JSON.parse(nodeFs.readFileSync(statsPath, 'utf8'));
        const norm = normalizeCutoverStatsDoc(parsed);
        if (norm.startedAt > 0) {
          return formatCutoverStatsSummary(norm, statsPath, nowMs);
        }
      }
    } catch {}
    const fresh = {
      version: 1,
      startedAt: nowMs,
      updatedAt: nowMs,
      counts: emptyServiceCutoverCounts(),
      lastEvent: null
    };
    writeCutoverStatsAtomicSync(statsPath, fresh);
    return formatCutoverStatsSummary(fresh, statsPath, nowMs);
  });
}

function recordServiceCutoverEvent(kind, action = '', opts = {}) {
  if (!SERVICE_CUTOVER_KIND_SET.has(kind)) {
    return { recorded: false, reason: 'invalid_kind' };
  }
  if (!canWriteServiceCutoverStats(opts)) {
    return { recorded: false, reason: 'smoke_test' };
  }
  const nodeFs = require('fs');
  const statsPath = getServiceCutoverStatsPath(opts);
  if (!statsPath) {
    return { recorded: false, reason: 'missing_path' };
  }
  const nowMs = Number(opts?.nowMs || Date.now());
  return withCutoverStatsLock(statsPath, () => {
    let current = normalizeCutoverStatsDoc(null);
    try {
      if (nodeFs.existsSync(statsPath)) {
        current = normalizeCutoverStatsDoc(JSON.parse(nodeFs.readFileSync(statsPath, 'utf8')));
      }
    } catch {}
    if (current.startedAt <= 0) current.startedAt = nowMs;
    current.updatedAt = nowMs;
    current.counts[kind] = Number(current.counts[kind] || 0) + 1;
    current.lastEvent = {
      kind,
      action: sanitizeCutoverAction(action),
      at: nowMs
    };
    const written = writeCutoverStatsAtomicSync(statsPath, current);
    return {
      recorded: written,
      kind,
      stats: formatCutoverStatsSummary(current, statsPath, nowMs)
    };
  });
}

// Milliseconds since the user last typed or clicked on this host, or null if not yet observed.
function getHostIdleMs(nowMs = Date.now()) {
  if (process.env.THEO_IDLE_MS_OVERRIDE !== undefined && process.env.THEO_IDLE_MS_OVERRIDE !== '') {
    const ov = Number(process.env.THEO_IDLE_MS_OVERRIDE);
    return Number.isFinite(ov) && ov >= 0 ? Math.floor(ov) : null;
  }
  refreshOsIdleMsAsync();
  const latestAt = Math.max(lastInProcessUserActivityAt, cachedOsInputAt);
  if (latestAt <= 0) return null;
  return Math.max(0, Math.floor(nowMs - latestAt));
}

module.exports = {
  DEVICE_FILE,
  THEO_CRED_FILE,
  DEFAULT_EDGE_RELAY_URL,
  getLanIps,
  resolveAgyBinaryPath,
  resolveClaudeBinaryPath,
  resolveNodeBinaryInfo,
  resolveSpawnableCli,
  HOST_ROLE,
  cleanDeviceId,
  FLEET_HOMES_FILE,
  isLocalHomeAlias,
  inferRowOwnerDevice,
  rememberFleetHomes,
  getSelfDeviceRef,
  buildPeerSnapshot,
  normalizePinTimestamp,
  pruneUnpinnedMap,
  resolveRowPinState,
  deriveStoreEndpoint,
  loadTheoCredentials,
  saveTheoCredentials,
  buildPairTokenBase64Url,
  parsePairTokenBase64Url,
  getDeviceIdentity,
  updateDeviceConfig,
  deriveEdgeAuthToken,
  deriveBundleSignKey,
  noteLocalUserActivity,
  detectSmartAppControlEnforced,
  probeLauncherSupportsIdleMs,
  refreshOsIdleMsAsync,
  pollIdleWatcher,
  idleWatchMutexName,
  IDLE_WATCH_PS1,
  getHostIdleMs,
  isLegacyVsCodePhoneBridgeEnabled,
  SERVICE_CUTOVER_KINDS,
  getServiceCutoverStatsPath,
  readServiceCutoverStats,
  ensureServiceCutoverStatsInitialized,
  recordServiceCutoverEvent
};
