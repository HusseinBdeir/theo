'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const CLAUDE_DIR = path.join(os.homedir(), '.claude');
const DEVICE_FILE = path.join(CLAUDE_DIR, 'theo-device.json');

function slugifyId(raw) {
  return String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

function getLanIps() {
  const out = [];
  try {
    const nets = os.networkInterfaces() || {};
    for (const [name, addrs] of Object.entries(nets)) {
      if (!Array.isArray(addrs)) continue;
      for (const addr of addrs) {
        if (!addr || addr.internal) continue;
        if (addr.family === 'IPv4' || addr.family === 4) {
          out.push({ name, address: addr.address });
        }
      }
    }
  } catch {}
  return out;
}

function resolveAgyBinaryPath() {
  const home = os.homedir();
  const candidates = [
    process.env.THEO_AGY_BIN,
    path.join(home, '.gemini', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'antigravity', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'antigravity-cli', 'bin', 'agy.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'Antigravity IDE', 'bin', 'agy.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'antigravity', 'resources', 'app', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'bin', 'agy')
  ].filter(Boolean);

  for (const c of candidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return c;
      }
    } catch {}
  }

  const pathDirs = String(process.env.PATH || '').split(path.delimiter);
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of process.platform === 'win32' ? ['agy.exe', 'agy.cmd', 'agy'] : ['agy']) {
      const full = path.join(dir, name);
      try {
        if (fs.existsSync(full) && fs.statSync(full).isFile()) {
          return full;
        }
      } catch {}
    }
  }
  return '';
}

function resolveClaudeBinaryPath() {
  const home = os.homedir();
  const directCandidates = [
    process.env.THEO_CLAUDE_BIN,
    path.join(home, '.local', 'bin', 'claude.exe'),
    path.join(home, '.claude', 'local', 'claude.exe'),
    path.join(home, 'AppData', 'Roaming', 'npm', 'claude.cmd'),
    path.join(home, '.local', 'bin', 'claude')
  ].filter(Boolean);

  for (const c of directCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return c;
      }
    } catch {}
  }

  // Check VS Code installed Claude Code extension native binary (newest version first)
  const extDirs = [
    path.join(home, '.vscode', 'extensions'),
    path.join(home, '.antigravity', 'extensions')
  ];
  for (const extRoot of extDirs) {
    try {
      if (!fs.existsSync(extRoot)) continue;
      const matches = fs
        .readdirSync(extRoot, { withFileTypes: true })
        .filter((d) => d.isDirectory() && /^anthropic\.claude-code-/i.test(d.name))
        .map((d) => d.name)
        .sort()
        .reverse();
      for (const dirName of matches) {
        const binName = process.platform === 'win32' ? 'claude.exe' : 'claude';
        const binPath = path.join(extRoot, dirName, 'resources', 'native-binary', binName);
        if (fs.existsSync(binPath) && fs.statSync(binPath).isFile()) {
          return binPath;
        }
      }
    } catch {}
  }

  const pathDirs = String(process.env.PATH || '').split(path.delimiter);
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of process.platform === 'win32' ? ['claude.exe', 'claude.cmd', 'claude'] : ['claude']) {
      const full = path.join(dir, name);
      try {
        if (fs.existsSync(full) && fs.statSync(full).isFile()) {
          return full;
        }
      } catch {}
    }
  }
  return '';
}

function resolveNodeBinaryInfo() {
  const home = os.homedir();
  const nodeCandidates = [
    path.join(home, '.local', 'node', 'node.exe'),
    'C:\\Program Files\\nodejs\\node.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'nodejs', 'node.exe'),
    '/usr/local/bin/node',
    '/opt/homebrew/bin/node',
    '/usr/bin/node'
  ];
  for (const c of nodeCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return { executable: c, electronRunAsNode: false };
      }
    } catch {}
  }
  if (!process.versions?.electron && process.execPath && fs.existsSync(process.execPath)) {
    return { executable: process.execPath, electronRunAsNode: false };
  }
  const electronCandidates = [
    path.join(home, 'AppData', 'Local', 'Programs', 'Microsoft VS Code', 'Code.exe'),
    'C:\\Program Files\\Microsoft VS Code\\Code.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'antigravity', 'Antigravity.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'Antigravity IDE', 'Antigravity.exe')
  ];
  for (const c of electronCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return { executable: c, electronRunAsNode: true };
      }
    } catch {}
  }
  return { executable: 'node', electronRunAsNode: false };
}

function inferDefaultDeviceIdentity() {
  const homeLow = os.homedir().toLowerCase();
  const rawHost = os.hostname() || 'workstation';
  const hostLow = rawHost.toLowerCase();
  let user = '';
  try {
    user = os.userInfo().username || '';
  } catch {}

  if (homeLow === 'c:\\users\\husseinbdeir') {
    return {
      id: 'main-workstation',
      name: 'Main Workstation',
      role: 'primary'
    };
  }
  if (hostLow === 'theo' || homeLow === 'c:\\users\\hbdei') {
    return {
      id: 'theo-laptop',
      name: 'Theo Laptop',
      role: 'secondary'
    };
  }
  const slug = slugifyId(rawHost || user || 'device');
  return {
    id: `dev-${slug || crypto.randomBytes(3).toString('hex')}`,
    name: rawHost || 'Workstation',
    role: 'secondary'
  };
}

function loadDeviceConfig() {
  try {
    if (fs.existsSync(DEVICE_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(DEVICE_FILE, 'utf8'));
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    }
  } catch {}
  return null;
}

function saveDeviceConfig(cfg) {
  try {
    fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    fs.writeFileSync(DEVICE_FILE, JSON.stringify(cfg, null, 2), 'utf8');
  } catch {}
}

function getDeviceIdentity(overrides = {}) {
  const defaults = inferDefaultDeviceIdentity();
  const saved = loadDeviceConfig() || {};
  const agyBin = resolveAgyBinaryPath();
  const claudeBin = resolveClaudeBinaryPath();
  const capabilities = [];
  if (agyBin) capabilities.push('antigravity');
  if (claudeBin) capabilities.push('claude');

  let username = '';
  try {
    username = os.userInfo().username || '';
  } catch {}

  const identity = {
    id: String(overrides.id || saved.id || defaults.id).trim(),
    name: String(overrides.name || saved.name || defaults.name).trim(),
    role: String(overrides.role || saved.role || defaults.role || 'secondary').trim(),
    hostname: os.hostname(),
    username,
    homedir: os.homedir(),
    platform: process.platform,
    arch: process.arch,
    lanIps: getLanIps(),
    capabilities,
    binaries: {
      agy: agyBin,
      claude: claudeBin
    },
    edgeRelayUrl: String(
      overrides.edgeRelayUrl !== undefined
        ? overrides.edgeRelayUrl
        : process.env.THEO_EDGE_RELAY_URL || saved.edgeRelayUrl || ''
    ).trim(),
    updatedAt: Date.now()
  };

  if (!saved.id || overrides.name || overrides.edgeRelayUrl !== undefined) {
    saveDeviceConfig({
      id: identity.id,
      name: identity.name,
      role: identity.role,
      hostname: identity.hostname,
      edgeRelayUrl: identity.edgeRelayUrl,
      createdAt: saved.createdAt || Date.now(),
      updatedAt: Date.now()
    });
  }

  return identity;
}

function updateDeviceConfig(patch = {}) {
  const current = getDeviceIdentity();
  const merged = {
    ...(loadDeviceConfig() || {}),
    id: patch.id ? slugifyId(patch.id) : current.id,
    name: patch.name ? String(patch.name).trim().slice(0, 48) : current.name,
    role: patch.role || current.role,
    edgeRelayUrl:
      patch.edgeRelayUrl !== undefined
        ? String(patch.edgeRelayUrl || '').trim()
        : current.edgeRelayUrl,
    updatedAt: Date.now()
  };
  saveDeviceConfig(merged);
  return getDeviceIdentity();
}

function deriveEdgeAuthToken(relayKey) {
  const cleanKey = String(relayKey || '').trim();
  if (!cleanKey) return '';
  return crypto
    .createHash('sha256')
    .update(`theo-edge-v1:${cleanKey}`, 'utf8')
    .digest('hex');
}

module.exports = {
  DEVICE_FILE,
  getLanIps,
  resolveAgyBinaryPath,
  resolveClaudeBinaryPath,
  resolveNodeBinaryInfo,
  getDeviceIdentity,
  updateDeviceConfig,
  deriveEdgeAuthToken
};
