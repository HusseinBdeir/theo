'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const CLAUDE_DIR = path.join(os.homedir(), '.claude');
const DEVICE_FILE = path.join(CLAUDE_DIR, 'theo-device.json');
const THEO_CRED_DIR = path.join(os.homedir(), '.theo');
const THEO_CRED_FILE = path.join(THEO_CRED_DIR, 'credentials.json');
const DEFAULT_EDGE_RELAY_URL = 'https://theo-edge-relay.husseinbdeir.workers.dev/ws';

function slugifyId(raw) {
  return String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

function getLanIps() {
  const out = [];
  try {
    const nets = os.networkInterfaces() || {};
    for (const [name, addrs] of Object.entries(nets)) {
      if (!Array.isArray(addrs)) continue;
      for (const addr of addrs) {
        if (!addr || addr.internal) continue;
        if (addr.family === 'IPv4' || addr.family === 4) {
          out.push({ name, address: addr.address });
        }
      }
    }
  } catch {}
  return out;
}

function resolveAgyBinaryPath() {
  const home = os.homedir();
  const candidates = [
    process.env.THEO_AGY_BIN,
    path.join(home, '.gemini', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'antigravity', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'antigravity-cli', 'bin', 'agy.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'Antigravity IDE', 'bin', 'agy.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'antigravity', 'resources', 'app', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'bin', 'agy')
  ].filter(Boolean);

  for (const c of candidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return c;
      }
    } catch {}
  }

  const pathDirs = String(process.env.PATH || '').split(path.delimiter);
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of process.platform === 'win32' ? ['agy.exe', 'agy.cmd', 'agy'] : ['agy']) {
      const full = path.join(dir, name);
      try {
        if (fs.existsSync(full) && fs.statSync(full).isFile()) {
          return full;
        }
      } catch {}
    }
  }
  return '';
}

function resolveClaudeBinaryPath() {
  const home = os.homedir();
  // Prefer native .exe binaries before .cmd wrappers to avoid Windows Node 22+ spawn EINVAL
  const directExeCandidates = [
    process.env.THEO_CLAUDE_BIN,
    path.join(home, '.local', 'bin', 'claude.exe'),
    path.join(home, '.claude', 'local', 'claude.exe'),
    path.join(home, '.local', 'bin', 'claude')
  ].filter(Boolean);

  for (const c of directExeCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return c;
      }
    } catch {}
  }

  // Check VS Code / Antigravity installed Claude Code extension native binary (numeric semver newest first)
  const extDirs = [
    path.join(home, '.vscode', 'extensions'),
    path.join(home, '.antigravity', 'extensions')
  ];
  for (const extRoot of extDirs) {
    try {
      if (!fs.existsSync(extRoot)) continue;
      const matches = fs
        .readdirSync(extRoot, { withFileTypes: true })
        .filter((d) => d.isDirectory() && /^anthropic\.claude-code-/i.test(d.name))
        .map((d) => d.name)
        .sort((a, b) => b.localeCompare(a, undefined, { numeric: true, sensitivity: 'base' }));
      for (const dirName of matches) {
        const binName = process.platform === 'win32' ? 'claude.exe' : 'claude';
        const binPath = path.join(extRoot, dirName, 'resources', 'native-binary', binName);
        if (fs.existsSync(binPath) && fs.statSync(binPath).isFile()) {
          return binPath;
        }
      }
    } catch {}
  }

  const npmCliJs = path.join(
    home,
    'AppData',
    'Roaming',
    'npm',
    'node_modules',
    '@anthropic-ai',
    'claude-code',
    'cli.js'
  );
  try {
    if (fs.existsSync(npmCliJs) && fs.statSync(npmCliJs).isFile()) {
      return npmCliJs;
    }
  } catch {}

  const npmCmd = path.join(home, 'AppData', 'Roaming', 'npm', 'claude.cmd');
  try {
    if (fs.existsSync(npmCmd) && fs.statSync(npmCmd).isFile()) {
      return npmCmd;
    }
  } catch {}

  const pathDirs = String(process.env.PATH || '').split(path.delimiter);
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of process.platform === 'win32' ? ['claude.exe', 'claude.cmd', 'claude'] : ['claude']) {
      const full = path.join(dir, name);
      try {
        if (fs.existsSync(full) && fs.statSync(full).isFile()) {
          return full;
        }
      } catch {}
    }
  }
  return '';
}

function resolveNodeBinaryInfo() {
  const wrapNodeInfo = (executable, electronRunAsNode) => ({
    executable,
    electronRunAsNode,
    nodeExe: executable,
    useElectronRunAsNode: electronRunAsNode
  });
  const home = os.homedir();
  const nodeCandidates = [
    path.join(home, '.local', 'node', 'node.exe'),
    'C:\\Program Files\\nodejs\\node.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'nodejs', 'node.exe'),
    '/usr/local/bin/node',
    '/opt/homebrew/bin/node',
    '/usr/bin/node'
  ];
  for (const c of nodeCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return wrapNodeInfo(c, false);
      }
    } catch {}
  }
  if (!process.versions?.electron && process.execPath && fs.existsSync(process.execPath)) {
    return wrapNodeInfo(process.execPath, false);
  }
  const electronCandidates = [
    path.join(home, 'AppData', 'Local', 'Programs', 'Microsoft VS Code', 'Code.exe'),
    'C:\\Program Files\\Microsoft VS Code\\Code.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'antigravity', 'Antigravity.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'Antigravity IDE', 'Antigravity.exe')
  ];
  for (const c of electronCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return wrapNodeInfo(c, true);
      }
    } catch {}
  }
  return wrapNodeInfo('node', false);
}

function resolveSpawnableCli(binPath, args = []) {
  const cleanBin = String(binPath || '').trim();
  if (!cleanBin) {
    return { command: '', args: [...args], envPatch: {} };
  }
  if (/\.m?js$/i.test(cleanBin)) {
    const nodeInfo = resolveNodeBinaryInfo();
    return {
      command: nodeInfo.executable,
      args: [cleanBin, ...args],
      envPatch: nodeInfo.electronRunAsNode ? { ELECTRON_RUN_AS_NODE: '1' } : {}
    };
  }
  if (process.platform === 'win32' && /\.(?:cmd|bat)$/i.test(cleanBin)) {
    const dir = path.dirname(cleanBin);
    const base = path.basename(cleanBin).replace(/\.(?:cmd|bat)$/i, '');
    const siblingCliJs =
      base.toLowerCase() === 'claude'
        ? path.join(dir, 'node_modules', '@anthropic-ai', 'claude-code', 'cli.js')
        : '';
    if (siblingCliJs && fs.existsSync(siblingCliJs)) {
      const nodeInfo = resolveNodeBinaryInfo();
      return {
        command: nodeInfo.executable,
        args: [siblingCliJs, ...args],
        envPatch: nodeInfo.electronRunAsNode ? { ELECTRON_RUN_AS_NODE: '1' } : {}
      };
    }
    const siblingExe = path.join(dir, `${base}.exe`);
    if (fs.existsSync(siblingExe)) {
      return { command: siblingExe, args: [...args], envPatch: {} };
    }
    // Safe Windows cmd.exe wrapper avoiding Node 22+ spawn EINVAL on bare .cmd
    const quoteWinArg = (val) => {
      const s = String(val ?? '');
      if (!/[\s"&|<>^()%!]/.test(s) && s.length > 0) return s;
      return `"${s.replace(/(\\*)"/g, '$1$1\\"').replace(/(\\+)$/, '$1$1').replace(/%/g, '%%')}"`;
    };
    const cmdLine = `"${quoteWinArg(cleanBin)} ${args.map(quoteWinArg).join(' ')}"`;
    return {
      command: process.env.ComSpec || 'C:\\Windows\\System32\\cmd.exe',
      args: ['/d', '/s', '/c', cmdLine],
      windowsVerbatimArguments: true,
      envPatch: {}
    };
  }
  return { command: cleanBin, args: [...args], envPatch: {} };
}

function inferDefaultDeviceIdentity() {
  const homeLow = os.homedir().toLowerCase();
  const rawHost = os.hostname() || 'workstation';
  const hostLow = rawHost.toLowerCase();
  let user = '';
  try {
    user = os.userInfo().username || '';
  } catch {}

  if (homeLow === 'c:\\users\\husseinbdeir') {
    return {
      id: 'main-workstation',
      name: 'Main Workstation',
      role: 'primary'
    };
  }
  if (hostLow === 'theo' || homeLow === 'c:\\users\\hbdei') {
    return {
      id: 'theo-laptop',
      name: 'Theo Laptop',
      role: 'secondary'
    };
  }
  const slug = slugifyId(rawHost || user || 'device');
  return {
    id: `dev-${slug || crypto.randomBytes(3).toString('hex')}`,
    name: rawHost || 'Workstation',
    role: 'secondary'
  };
}

function inferRowOwnerDevice(rowOrCwd, fallbackDevice = null) {
  const makeOwner = (id, name) => ({ id, name, deviceId: id, deviceName: name });
  const r = typeof rowOrCwd === 'object' && rowOrCwd ? rowOrCwd : { cwd: String(rowOrCwd || '') };
  const explicitId = String(r.deviceId || '').trim();
  const explicitName = String(r.deviceName || '').trim();
  const cwdLow = String(r.cwd || '').trim().toLowerCase();
  if (cwdLow.startsWith('c:\\users\\husseinbdeir\\') || cwdLow === 'c:\\users\\husseinbdeir') {
    return makeOwner('main-workstation', 'Main Workstation');
  }
  if (cwdLow.startsWith('c:\\users\\hbdei\\') || cwdLow === 'c:\\users\\hbdei') {
    return makeOwner('theo-laptop', 'Theo Laptop');
  }
  if (explicitId) {
    return makeOwner(
      explicitId,
      explicitName ||
        (explicitId === 'main-workstation'
          ? 'Main Workstation'
          : explicitId === 'theo-laptop'
            ? 'Theo Laptop'
            : explicitId)
    );
  }
  if (r.source === 'cloud-relay') {
    return makeOwner('main-workstation', 'Main Workstation');
  }
  if (fallbackDevice && fallbackDevice.id) {
    return makeOwner(fallbackDevice.id, fallbackDevice.name || fallbackDevice.id);
  }
  const def = inferDefaultDeviceIdentity();
  return makeOwner(def.id, def.name);
}

function decodeMaybeBase64(val) {
  const s = String(val || '').trim();
  if (!s) return '';
  if (/^https?:\/\//i.test(s) || /^[0-9a-f]{32,}$/i.test(s)) return s;
  try {
    const dec = Buffer.from(s, 'base64').toString('utf8').trim();
    if (dec && /^[\x20-\x7e]+$/.test(dec)) return dec;
  } catch {}
  return s;
}

function loadTheoCredentials(extraDir = '') {
  let fileCfg = {};
  try {
    if (fs.existsSync(THEO_CRED_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(THEO_CRED_FILE, 'utf8'));
      if (parsed && typeof parsed === 'object') {
        fileCfg = parsed;
      }
    }
  } catch {}

  let legacyCfg = {};
  const legacyCandidates = [
    extraDir ? path.join(extraDir, 'remote-relay.json') : '',
    path.join(__dirname, 'remote-relay.json')
  ].filter(Boolean);
  for (const p of legacyCandidates) {
    try {
      if (fs.existsSync(p)) {
        const parsed = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (parsed && typeof parsed === 'object') {
          legacyCfg = parsed;
          break;
        }
      }
    } catch {}
  }

  const cloudUrl = decodeMaybeBase64(
    process.env.THEO_CLOUD_URL || fileCfg.cloudUrl || fileCfg.u || legacyCfg.u || ''
  );
  const cloudKey = decodeMaybeBase64(
    process.env.THEO_CLOUD_KEY || fileCfg.cloudKey || fileCfg.k || legacyCfg.k || ''
  );
  const edgeAccessKey = String(
    process.env.THEO_EDGE_KEY || fileCfg.edgeAccessKey || ''
  ).trim();
  const edgeRelayUrl = String(
    process.env.THEO_EDGE_RELAY_URL ||
      fileCfg.edgeRelayUrl ||
      legacyCfg.edgeUrl ||
      DEFAULT_EDGE_RELAY_URL
  ).trim();
  const port = Number(process.env.THEO_BRIDGE_PORT || fileCfg.port || legacyCfg.port || 4318) || 4318;
  const allowLan = Boolean(
    process.env.THEO_ALLOW_LAN === '1' || fileCfg.allowLan === true
  );

  return {
    cloudUrl,
    cloudKey,
    u: fileCfg.u || (cloudUrl ? Buffer.from(cloudUrl, 'utf8').toString('base64') : ''),
    k: fileCfg.k || (cloudKey ? Buffer.from(cloudKey, 'utf8').toString('base64') : ''),
    edgeAccessKey,
    // Fallback to cloudKey only if edgeAccessKey has not been minted on a host yet
    effectiveEdgeSecret: edgeAccessKey || cloudKey,
    edgeRelayUrl,
    port,
    allowLan
  };
}

function saveTheoCredentials(patch = {}) {
  const cur = loadTheoCredentials();
  const nextCloudUrl =
    patch.cloudUrl !== undefined ? decodeMaybeBase64(patch.cloudUrl) : cur.cloudUrl;
  const nextCloudKey =
    patch.cloudKey !== undefined ? decodeMaybeBase64(patch.cloudKey) : cur.cloudKey;
  const next = {
    u: nextCloudUrl ? Buffer.from(nextCloudUrl, 'utf8').toString('base64') : cur.u || '',
    k: nextCloudKey ? Buffer.from(nextCloudKey, 'utf8').toString('base64') : cur.k || '',
    edgeAccessKey:
      patch.edgeAccessKey !== undefined
        ? String(patch.edgeAccessKey || '').trim()
        : cur.edgeAccessKey || '',
    edgeRelayUrl:
      patch.edgeRelayUrl !== undefined
        ? String(patch.edgeRelayUrl || '').trim()
        : cur.edgeRelayUrl || DEFAULT_EDGE_RELAY_URL,
    port: Number(patch.port || cur.port || 4318) || 4318,
    allowLan: patch.allowLan !== undefined ? Boolean(patch.allowLan) : Boolean(cur.allowLan),
    updatedAt: Date.now()
  };
  try {
    fs.mkdirSync(THEO_CRED_DIR, { recursive: true });
    fs.writeFileSync(THEO_CRED_FILE, JSON.stringify(next, null, 2), { encoding: 'utf8', mode: 0o600 });
  } catch {}
  return loadTheoCredentials();
}

function buildPairTokenBase64Url(creds = null) {
  const c = creds || loadTheoCredentials();
  const edgeKey = String(c.edgeAccessKey || c.effectiveEdgeSecret || '').trim();
  const cloudUrl = decodeMaybeBase64(c.cloudUrl || c.u || '');
  const cloudKey = decodeMaybeBase64(c.cloudKey || c.k || '');
  if (!edgeKey && !cloudUrl && !cloudKey) return '';
  const payload = {
    v: 1,
    e: edgeKey,
    r: String(c.edgeRelayUrl || c.w || DEFAULT_EDGE_RELAY_URL).trim(),
    u: cloudUrl,
    k: cloudKey,
    p: Number(c.port || c.p || 4318) || 4318
  };
  return Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
}

function isSafeCloudEndpointUrl(rawUrl) {
  const u = String(rawUrl || '').trim();
  if (!u) return true;
  return /^https:\/\/[^\s]+$/i.test(u) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/|$)/i.test(u);
}

function isSafeEdgeEndpointUrl(rawUrl) {
  const u = String(rawUrl || '').trim();
  if (!u) return true;
  return (
    /^(wss|https):\/\/[^\s]+$/i.test(u) ||
    /^(ws|http):\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/|$)/i.test(u)
  );
}

function parsePairTokenBase64Url(rawToken) {
  const text = String(rawToken || '').trim();
  if (!text) return null;
  const hashMatch = text.match(/#pair=([A-Za-z0-9_=-]{16,8192})/i);
  const envMatch =
    !hashMatch && text.match(/THEO_PAIR_TOKEN\s*=\s*['"]?([A-Za-z0-9_=-]{16,8192})['"]?/i);
  const clean = hashMatch
    ? hashMatch[1]
    : envMatch
      ? envMatch[1]
      : text
          .replace(/^#?pair=/i, '')
          .split(/[\s&'"]+/)[0]
          .trim();
  if (!clean) return null;
  try {
    const jsonStr = Buffer.from(clean, 'base64url').toString('utf8');
    const obj = JSON.parse(jsonStr);
    if (!obj || typeof obj !== 'object') return null;
    const edgeAccessKey = String(obj.e || obj.edgeAccessKey || '').trim();
    const cloudUrl = decodeMaybeBase64(obj.u || obj.cloudUrl || '');
    const cloudKey = decodeMaybeBase64(obj.k || obj.cloudKey || '');
    const rawEdgeUrl = String(obj.r || obj.w || obj.edgeRelayUrl || '').trim();
    if (!edgeAccessKey && !cloudKey) return null;
    if (cloudUrl && !cloudKey) return null;
    if (!isSafeCloudEndpointUrl(cloudUrl) || !isSafeEdgeEndpointUrl(rawEdgeUrl)) return null;
    return {
      edgeAccessKey,
      edgeRelayUrl: rawEdgeUrl || DEFAULT_EDGE_RELAY_URL,
      cloudUrl,
      cloudKey,
      port: Number(obj.p || obj.port || 4318) || 4318
    };
  } catch {
    if (/^[a-fA-F0-9]{32,128}$/.test(clean)) {
      return {
        edgeAccessKey: clean,
        edgeRelayUrl: DEFAULT_EDGE_RELAY_URL,
        cloudUrl: '',
        cloudKey: '',
        port: 4318
      };
    }
    return null;
  }
}

function loadBundledEdgeRelayUrl() {
  return loadTheoCredentials().edgeRelayUrl;
}

function loadDeviceConfig() {
  try {
    if (fs.existsSync(DEVICE_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(DEVICE_FILE, 'utf8'));
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    }
  } catch {}
  return null;
}

function saveDeviceConfig(cfg) {
  try {
    fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    fs.writeFileSync(DEVICE_FILE, JSON.stringify(cfg, null, 2), 'utf8');
  } catch {}
}

function getDeviceIdentity(overrides = {}) {
  const defaults = inferDefaultDeviceIdentity();
  const saved = loadDeviceConfig() || {};
  const agyBin = resolveAgyBinaryPath();
  const claudeBin = resolveClaudeBinaryPath();
  const capabilities = [];
  if (agyBin) capabilities.push('antigravity');
  if (claudeBin) capabilities.push('claude');

  let username = '';
  try {
    username = os.userInfo().username || '';
  } catch {}

  const identity = {
    id: String(overrides.id || saved.id || defaults.id).trim(),
    name: String(overrides.name || saved.name || defaults.name).trim(),
    role: String(overrides.role || saved.role || defaults.role || 'secondary').trim(),
    hostname: os.hostname(),
    username,
    homedir: os.homedir(),
    platform: process.platform,
    arch: process.arch,
    lanIps: getLanIps(),
    capabilities,
    binaries: {
      agy: agyBin,
      claude: claudeBin
    },
    edgeRelayUrl: String(
      overrides.edgeRelayUrl !== undefined
        ? overrides.edgeRelayUrl
        : process.env.THEO_EDGE_RELAY_URL || saved.edgeRelayUrl || loadBundledEdgeRelayUrl() || ''
    ).trim(),
    updatedAt: Date.now()
  };

  if (!saved.id || overrides.name || overrides.edgeRelayUrl !== undefined) {
    saveDeviceConfig({
      id: identity.id,
      name: identity.name,
      role: identity.role,
      hostname: identity.hostname,
      edgeRelayUrl: identity.edgeRelayUrl,
      createdAt: saved.createdAt || Date.now(),
      updatedAt: Date.now()
    });
  }

  return identity;
}

function updateDeviceConfig(patch = {}) {
  const current = getDeviceIdentity();
  const merged = {
    ...(loadDeviceConfig() || {}),
    id: patch.id ? slugifyId(patch.id) : current.id,
    name: patch.name ? String(patch.name).trim().slice(0, 48) : current.name,
    role: patch.role || current.role,
    edgeRelayUrl:
      patch.edgeRelayUrl !== undefined
        ? String(patch.edgeRelayUrl || '').trim()
        : current.edgeRelayUrl,
    updatedAt: Date.now()
  };
  saveDeviceConfig(merged);
  return getDeviceIdentity();
}

function deriveEdgeAuthToken(relayKey) {
  const cleanKey = String(relayKey || '').trim();
  if (!cleanKey) return '';
  return crypto
    .createHash('sha256')
    .update(`theo-edge-v1:${cleanKey}`, 'utf8')
    .digest('hex');
}

module.exports = {
  DEVICE_FILE,
  THEO_CRED_FILE,
  DEFAULT_EDGE_RELAY_URL,
  getLanIps,
  resolveAgyBinaryPath,
  resolveClaudeBinaryPath,
  resolveNodeBinaryInfo,
  resolveSpawnableCli,
  inferRowOwnerDevice,
  loadTheoCredentials,
  saveTheoCredentials,
  buildPairTokenBase64Url,
  parsePairTokenBase64Url,
  getDeviceIdentity,
  updateDeviceConfig,
  deriveEdgeAuthToken
};
