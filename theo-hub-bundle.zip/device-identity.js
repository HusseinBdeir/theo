'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

const CLAUDE_DIR = path.join(os.homedir(), '.claude');
const DEVICE_FILE = path.join(CLAUDE_DIR, 'theo-device.json');
const THEO_CRED_DIR = path.join(os.homedir(), '.theo');
const THEO_CRED_FILE = path.join(THEO_CRED_DIR, 'credentials.json');

// THEO_CRED_PATH and THEO_DEVICE_PATH point the tests at files of their own, so a test never reads or writes the
// credentials or the device identity of the PC it runs on.
function credFilePath() {
  return process.env.THEO_CRED_PATH || THEO_CRED_FILE;
}

function deviceFilePath() {
  return process.env.THEO_DEVICE_PATH || DEVICE_FILE;
}
const DEFAULT_EDGE_RELAY_URL = 'https://theo-edge-relay.husseinbdeir.workers.dev/ws';

function slugifyId(raw) {
  return String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
}

function getLanIps() {
  const out = [];
  try {
    const nets = os.networkInterfaces() || {};
    for (const [name, addrs] of Object.entries(nets)) {
      if (!Array.isArray(addrs)) continue;
      for (const addr of addrs) {
        if (!addr || addr.internal) continue;
        if (addr.family === 'IPv4' || addr.family === 4) {
          out.push({ name, address: addr.address });
        }
      }
    }
  } catch {}
  return out;
}

function resolveAgyBinaryPath() {
  const home = os.homedir();
  const candidates = [
    process.env.THEO_AGY_BIN,
    path.join(home, '.gemini', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'antigravity', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'antigravity-cli', 'bin', 'agy.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'Antigravity IDE', 'bin', 'agy.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'antigravity', 'resources', 'app', 'bin', 'agy.exe'),
    path.join(home, '.gemini', 'bin', 'agy')
  ].filter(Boolean);

  for (const c of candidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return c;
      }
    } catch {}
  }

  const pathDirs = String(process.env.PATH || '').split(path.delimiter);
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of process.platform === 'win32' ? ['agy.exe', 'agy.cmd', 'agy'] : ['agy']) {
      const full = path.join(dir, name);
      try {
        if (fs.existsSync(full) && fs.statSync(full).isFile()) {
          return full;
        }
      } catch {}
    }
  }
  return '';
}

function resolveClaudeBinaryPath() {
  const home = os.homedir();
  // Prefer native .exe binaries before .cmd wrappers to avoid Windows Node 22+ spawn EINVAL
  const directExeCandidates = [
    process.env.THEO_CLAUDE_BIN,
    path.join(home, '.local', 'bin', 'claude.exe'),
    path.join(home, '.claude', 'local', 'claude.exe'),
    path.join(home, '.local', 'bin', 'claude')
  ].filter(Boolean);

  for (const c of directExeCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return c;
      }
    } catch {}
  }

  // Check VS Code / Antigravity installed Claude Code extension native binary (numeric semver newest first)
  const extDirs = [
    path.join(home, '.vscode', 'extensions'),
    path.join(home, '.antigravity', 'extensions')
  ];
  for (const extRoot of extDirs) {
    try {
      if (!fs.existsSync(extRoot)) continue;
      const matches = fs
        .readdirSync(extRoot, { withFileTypes: true })
        .filter((d) => d.isDirectory() && /^anthropic\.claude-code-/i.test(d.name))
        .map((d) => d.name)
        .sort((a, b) => b.localeCompare(a, undefined, { numeric: true, sensitivity: 'base' }));
      for (const dirName of matches) {
        const binName = process.platform === 'win32' ? 'claude.exe' : 'claude';
        const binPath = path.join(extRoot, dirName, 'resources', 'native-binary', binName);
        if (fs.existsSync(binPath) && fs.statSync(binPath).isFile()) {
          return binPath;
        }
      }
    } catch {}
  }

  const npmCliJs = path.join(
    home,
    'AppData',
    'Roaming',
    'npm',
    'node_modules',
    '@anthropic-ai',
    'claude-code',
    'cli.js'
  );
  try {
    if (fs.existsSync(npmCliJs) && fs.statSync(npmCliJs).isFile()) {
      return npmCliJs;
    }
  } catch {}

  const npmCmd = path.join(home, 'AppData', 'Roaming', 'npm', 'claude.cmd');
  try {
    if (fs.existsSync(npmCmd) && fs.statSync(npmCmd).isFile()) {
      return npmCmd;
    }
  } catch {}

  const pathDirs = String(process.env.PATH || '').split(path.delimiter);
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of process.platform === 'win32' ? ['claude.exe', 'claude.cmd', 'claude'] : ['claude']) {
      const full = path.join(dir, name);
      try {
        if (fs.existsSync(full) && fs.statSync(full).isFile()) {
          return full;
        }
      } catch {}
    }
  }
  return '';
}

function resolveNodeBinaryInfo() {
  const wrapNodeInfo = (executable, electronRunAsNode) => ({
    executable,
    electronRunAsNode,
    nodeExe: executable,
    useElectronRunAsNode: electronRunAsNode
  });
  const home = os.homedir();
  const nodeCandidates = [
    path.join(home, '.local', 'node', 'node.exe'),
    'C:\\Program Files\\nodejs\\node.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'nodejs', 'node.exe'),
    '/usr/local/bin/node',
    '/opt/homebrew/bin/node',
    '/usr/bin/node'
  ];
  for (const c of nodeCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return wrapNodeInfo(c, false);
      }
    } catch {}
  }
  if (!process.versions?.electron && process.execPath && fs.existsSync(process.execPath)) {
    return wrapNodeInfo(process.execPath, false);
  }
  const electronCandidates = [
    path.join(home, 'AppData', 'Local', 'Programs', 'Microsoft VS Code', 'Code.exe'),
    'C:\\Program Files\\Microsoft VS Code\\Code.exe',
    path.join(home, 'AppData', 'Local', 'Programs', 'antigravity', 'Antigravity.exe'),
    path.join(home, 'AppData', 'Local', 'Programs', 'Antigravity IDE', 'Antigravity.exe')
  ];
  for (const c of electronCandidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) {
        return wrapNodeInfo(c, true);
      }
    } catch {}
  }
  return wrapNodeInfo('node', false);
}

function resolveSpawnableCli(binPath, args = []) {
  const cleanBin = String(binPath || '').trim();
  if (!cleanBin) {
    return { command: '', args: [...args], envPatch: {} };
  }
  if (/\.m?js$/i.test(cleanBin)) {
    const nodeInfo = resolveNodeBinaryInfo();
    return {
      command: nodeInfo.executable,
      args: [cleanBin, ...args],
      envPatch: nodeInfo.electronRunAsNode ? { ELECTRON_RUN_AS_NODE: '1' } : {}
    };
  }
  if (process.platform === 'win32' && /\.(?:cmd|bat)$/i.test(cleanBin)) {
    const dir = path.dirname(cleanBin);
    const base = path.basename(cleanBin).replace(/\.(?:cmd|bat)$/i, '');
    const siblingCliJs =
      base.toLowerCase() === 'claude'
        ? path.join(dir, 'node_modules', '@anthropic-ai', 'claude-code', 'cli.js')
        : '';
    if (siblingCliJs && fs.existsSync(siblingCliJs)) {
      const nodeInfo = resolveNodeBinaryInfo();
      return {
        command: nodeInfo.executable,
        args: [siblingCliJs, ...args],
        envPatch: nodeInfo.electronRunAsNode ? { ELECTRON_RUN_AS_NODE: '1' } : {}
      };
    }
    const siblingExe = path.join(dir, `${base}.exe`);
    if (fs.existsSync(siblingExe)) {
      return { command: siblingExe, args: [...args], envPatch: {} };
    }
    // Safe Windows cmd.exe wrapper avoiding Node 22+ spawn EINVAL on bare .cmd
    const quoteWinArg = (val) => {
      const s = String(val ?? '');
      if (!/[\s"&|<>^()%!]/.test(s) && s.length > 0) return s;
      return `"${s.replace(/(\\*)"/g, '$1$1\\"').replace(/(\\+)$/, '$1$1').replace(/%/g, '%%')}"`;
    };
    const cmdLine = `"${quoteWinArg(cleanBin)} ${args.map(quoteWinArg).join(' ')}"`;
    return {
      command: process.env.ComSpec || 'C:\\Windows\\System32\\cmd.exe',
      args: ['/d', '/s', '/c', cmdLine],
      windowsVerbatimArguments: true,
      envPatch: {}
    };
  }
  return { command: cleanBin, args: [...args], envPatch: {} };
}

// Every PC is an equal host. Nothing here may depend on which PC the code runs on: a host's id and name come from
// its saved config or its computer name, and what the fleet knows about other hosts comes from what they publish.
const HOST_ROLE = 'host';

// Names that older builds assigned from the home folder. A saved config still carrying one is renamed to the
// computer name the first time this build reads it; a name the user chose is never touched.
const RETIRED_DEFAULT_DEVICE_NAMES = new Set(['main workstation', 'theo laptop']);

// The store and the relay accept device ids made of letters, digits, dot, underscore and hyphen, up to 80 long.
// An id outside that (a hand-edited config) is brought into shape instead of being silently ignored by them.
function cleanDeviceId(rawId) {
  const s = String(rawId || '').trim();
  if (!s) return '';
  if (/^[A-Za-z0-9._-]{1,80}$/.test(s)) return s;
  return slugifyId(s);
}

function inferDefaultDeviceIdentity() {
  const rawHost = String(os.hostname() || '').trim();
  let user = '';
  try {
    user = os.userInfo().username || '';
  } catch {}
  const slug = slugifyId(rawHost || user || 'device');
  return {
    id: `dev-${slug || crypto.randomBytes(3).toString('hex')}`,
    name: rawHost || 'Workstation',
    role: HOST_ROLE
  };
}

// ---- Fleet home folders: which host owns a session, learned from the hosts themselves ----
// Each host publishes its home folder with its device entry. A session whose working folder sits under another
// host's home folder belongs to that host (for example a transcript restored from it), so two PCs never both
// report the same session as their own. The map is data in ~/.claude, never a list in code.
const FLEET_HOMES_FILE = path.join(CLAUDE_DIR, 'theo-fleet-homes.json');
const FLEET_HOMES_RECHECK_MS = 5000;
let fleetHomesCache = null;
let fleetHomesCachePath = '';
let fleetHomesCheckedAt = 0;
let fleetHomesMtimeMs = -1;

// THEO_FLEET_HOMES_PATH points the tests at a file of their own.
function fleetHomesPath() {
  return process.env.THEO_FLEET_HOMES_PATH || FLEET_HOMES_FILE;
}

function selfHomeDir() {
  return process.env.THEO_SELF_HOMEDIR || os.homedir();
}

function normalizeHomePath(rawPath) {
  return String(rawPath || '')
    .trim()
    .replace(/\//g, '\\')
    .replace(/\\+$/, '')
    .toLowerCase();
}

const realPathCache = new Map();
const REALPATH_CACHE_MS = 60000;

function resolveRealHomeCached(rawPath) {
  const key = normalizeHomePath(rawPath);
  if (!key) return '';
  const now = Date.now();
  const hit = realPathCache.get(key);
  if (hit && now - hit.at < REALPATH_CACHE_MS) {
    return hit.real;
  }
  let real = '';
  try {
    const fn = fs.realpathSync.native || fs.realpathSync;
    real = normalizeHomePath(fn(rawPath));
  } catch {
    real = '';
  }
  if (realPathCache.size > 64) realPathCache.clear();
  realPathCache.set(key, { real, at: now });
  return real;
}

// True when `homeKey` (another host's published home path) is a local junction or symlink on this PC whose target
// resolves to this PC's own home folder. When so, a session under `homeKey` is only treated as the other host's if
// that host actually published the session id (restored transcript) and the session is not open/running here.
function isLocalHomeAlias(homeKey) {
  const cleanHome = normalizeHomePath(homeKey);
  const selfRaw = selfHomeDir();
  const selfNorm = normalizeHomePath(selfRaw);
  if (!cleanHome || !selfNorm || cleanHome === selfNorm) return false;
  const selfReal = resolveRealHomeCached(selfRaw) || selfNorm;
  const homeReal = resolveRealHomeCached(cleanHome);
  return Boolean(homeReal && selfReal && homeReal === selfReal);
}

const MAX_FLEET_HOME_ROW_IDS = 3000;
let fallbackPeerRowsMtime = -1;
let fallbackPeerRowsCheckedAt = 0;
let fallbackPeerRowsByDev = new Map();

function loadFallbackPeerRowIdsByDevice() {
  const now = Date.now();
  if (now - fallbackPeerRowsCheckedAt < FLEET_HOMES_RECHECK_MS) {
    return fallbackPeerRowsByDev;
  }
  fallbackPeerRowsCheckedAt = now;
  const cacheFile =
    process.env.THEO_PEER_CACHE_PATH || path.join(CLAUDE_DIR, '.theo-cloud-sessions-cache.json');
  let mtime = 0;
  try {
    mtime = fs.statSync(cacheFile).mtimeMs;
  } catch {
    mtime = 0;
  }
  if (mtime === fallbackPeerRowsMtime) {
    return fallbackPeerRowsByDev;
  }
  fallbackPeerRowsMtime = mtime;
  const map = new Map();
  if (mtime) {
    try {
      const selfId = String(getSelfDeviceRef().id || '').trim();
      const parsed = JSON.parse(fs.readFileSync(cacheFile, 'utf8')) || {};
      if (parsed.peerOnly === true) {
        for (const r of Array.isArray(parsed?.snapshot?.rows) ? parsed.snapshot.rows : []) {
          const devId = String(r?.deviceId || '').trim();
          const rid = String(r?.id || '').trim();
          if (!devId || !rid || devId === selfId) continue;
          if (!map.has(devId)) map.set(devId, new Set());
          map.get(devId).add(rid);
        }
      }
      if (parsed.deviceStates && typeof parsed.deviceStates === 'object') {
        for (const [devId, entry] of Object.entries(parsed.deviceStates)) {
          if (!devId || devId === selfId) continue;
          const rows = Array.isArray(entry?.snapshot?.rows)
            ? entry.snapshot.rows
            : Array.isArray(entry?.rows)
              ? entry.rows
              : [];
          for (const r of rows) {
            const rid = String(r?.id || '').trim();
            if (!rid) continue;
            if (!map.has(devId)) map.set(devId, new Set());
            map.get(devId).add(rid);
          }
        }
      }
    } catch {}
  }
  fallbackPeerRowsByDev = map;
  return map;
}

function loadFleetHomes() {
  const now = Date.now();
  const filePath = fleetHomesPath();
  if (filePath !== fleetHomesCachePath) {
    fleetHomesCache = null;
    fleetHomesCachePath = filePath;
  }
  if (fleetHomesCache && now - fleetHomesCheckedAt < FLEET_HOMES_RECHECK_MS) {
    return fleetHomesCache;
  }
  fleetHomesCheckedAt = now;
  let mtimeMs = 0;
  try {
    mtimeMs = fs.statSync(filePath).mtimeMs;
  } catch {
    mtimeMs = 0;
  }
  if (fleetHomesCache && mtimeMs === fleetHomesMtimeMs) {
    return fleetHomesCache;
  }
  const out = {};
  if (mtimeMs) {
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      const homes = parsed && typeof parsed === 'object' ? parsed.homes || parsed : {};
      for (const [home, dev] of Object.entries(homes || {})) {
        const key = normalizeHomePath(home);
        const id = String(dev?.id || '').trim();
        if (key && id) {
          const hasRowIds = Array.isArray(dev?.rowIds);
          const rowIds = hasRowIds
            ? dev.rowIds.map((x) => String(x || '').trim()).filter(Boolean).slice(0, MAX_FLEET_HOME_ROW_IDS)
            : [];
          out[key] = {
            id,
            name: String(dev?.name || '').trim(),
            hasRowIds,
            rowIds,
            rowIdsSet: hasRowIds ? new Set(rowIds) : null
          };
        }
      }
    } catch {}
  }
  fleetHomesCache = out;
  fleetHomesMtimeMs = mtimeMs;
  return out;
}

// Records the home folder each other host published. `devices` is a list of { id, name, homedir, rowIds? }.
function rememberFleetHomes(devices, selfId = '') {
  if (!Array.isArray(devices) || devices.length === 0) return false;
  const selfHome = normalizeHomePath(selfHomeDir());
  const cur = loadFleetHomes();
  const next = {};
  for (const [k, v] of Object.entries(cur)) {
    next[k] = {
      id: v.id,
      name: v.name,
      hasRowIds: Boolean(v.hasRowIds),
      rowIds: Array.isArray(v.rowIds) ? v.rowIds.slice() : [],
      rowIdsSet: v.rowIdsSet ? new Set(v.rowIdsSet) : null
    };
  }
  let changed = false;
  for (const dev of devices) {
    const id = String(dev?.id || '').trim();
    const home = normalizeHomePath(dev?.homedir);
    if (!id || !home || id === selfId || home === selfHome) continue;
    // A home folder is at least two folders deep (C:\Users\name, /home/name). Anything shallower, such as a drive
    // root, would claim every session on this PC for another host.
    if (!/^(?:[a-z]:)?(?:\\[^\\]+){2,}$/.test(home)) continue;
    const name = String(dev?.name || '').trim();
    const prev = next[home];
    let rowIdsChanged = false;
    let nextRowIds = prev?.rowIds || [];
    let nextHasRowIds = Boolean(prev?.hasRowIds);
    if (Array.isArray(dev?.rowIds)) {
      const seen = new Set();
      const mergedIds = [];
      for (const rawId of dev.rowIds) {
        const rid = String(rawId || '').trim();
        if (rid && !seen.has(rid)) {
          seen.add(rid);
          mergedIds.push(rid);
          if (mergedIds.length >= MAX_FLEET_HOME_ROW_IDS) break;
        }
      }
      // Keep previously seen restored session ids if the same device still owns this home folder.
      if (prev && prev.id === id && Array.isArray(prev.rowIds)) {
        for (const oldId of prev.rowIds) {
          if (mergedIds.length >= MAX_FLEET_HOME_ROW_IDS) break;
          if (oldId && !seen.has(oldId)) {
            seen.add(oldId);
            mergedIds.push(oldId);
          }
        }
      }
      const prevSet = prev?.rowIdsSet || new Set();
      if (!prev?.hasRowIds || mergedIds.length !== prevSet.size || mergedIds.some((x) => !prevSet.has(x))) {
        rowIdsChanged = true;
      }
      nextRowIds = mergedIds;
      nextHasRowIds = true;
    }
    if (!prev || prev.id !== id || (name && prev.name !== name) || rowIdsChanged) {
      next[home] = {
        id,
        name: name || prev?.name || '',
        hasRowIds: nextHasRowIds,
        rowIds: nextRowIds,
        rowIdsSet: nextHasRowIds ? new Set(nextRowIds) : null
      };
      changed = true;
    }
  }
  if (!changed) return false;
  const serializedHomes = {};
  for (const [k, v] of Object.entries(next)) {
    serializedHomes[k] = v.hasRowIds
      ? { id: v.id, name: v.name, rowIds: v.rowIds }
      : { id: v.id, name: v.name };
  }
  const filePath = fleetHomesPath();
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const tmp = `${filePath}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ homes: serializedHomes, updatedAt: Date.now() }, null, 2), 'utf8');
    fs.renameSync(tmp, filePath);
  } catch {}
  fleetHomesCache = next;
  fleetHomesCachePath = filePath;
  fleetHomesCheckedAt = Date.now();
  try {
    fleetHomesMtimeMs = fs.statSync(filePath).mtimeMs;
  } catch {
    fleetHomesMtimeMs = -1;
  }
  return true;
}

function findFleetHomeOwner(cwdLow) {
  if (!cwdLow) return null;
  const homes = loadFleetHomes();
  let best = null;
  let bestHome = '';
  let bestLen = 0;
  for (const home of Object.keys(homes)) {
    if (home.length > bestLen && (cwdLow === home || cwdLow.startsWith(`${home}\\`))) {
      best = homes[home];
      bestHome = home;
      bestLen = home.length;
    }
  }
  return best ? { ...best, homeKey: bestHome } : null;
}

function isRowPublishedByPeer(homeOwner, rowId, opts = {}) {
  const cleanId = String(rowId || '').trim();
  if (!cleanId || !homeOwner?.id) return false;
  if (opts?.peerOwnedRowIds instanceof Map) {
    const devSet = opts.peerOwnedRowIds.get(homeOwner.id);
    if (devSet instanceof Set) return devSet.has(cleanId);
  }
  if (homeOwner.hasRowIds && homeOwner.rowIdsSet instanceof Set) {
    return homeOwner.rowIdsSet.has(cleanId);
  }
  const fallbackMap = loadFallbackPeerRowIdsByDevice();
  const fallbackSet = fallbackMap.get(homeOwner.id);
  if (fallbackSet instanceof Set) {
    return fallbackSet.has(cleanId);
  }
  return false;
}

// This host's saved id and name, without the binary probing getDeviceIdentity() does. Cached briefly because it is
// asked once per session row.
let selfDeviceRefCache = null;
let selfDeviceRefAt = 0;
function getSelfDeviceRef() {
  const now = Date.now();
  if (selfDeviceRefCache && now - selfDeviceRefAt < FLEET_HOMES_RECHECK_MS) {
    return selfDeviceRefCache;
  }
  const saved = loadDeviceConfig() || {};
  const defaults = inferDefaultDeviceIdentity();
  const savedName = String(saved.name || '').trim();
  selfDeviceRefCache = {
    id: cleanDeviceId(saved.id) || defaults.id,
    name:
      savedName && !RETIRED_DEFAULT_DEVICE_NAMES.has(savedName.toLowerCase()) ? savedName : defaults.name
  };
  selfDeviceRefAt = now;
  return selfDeviceRefCache;
}

// Owner of a session row.
//  - A row another host published (opts.trustStamp, or a row marked as coming from the store or a peer) belongs to
//    the device id stamped on it: that host listed it as its own.
//  - A local row belongs, in this order, to the host whose published home folder contains its working folder
//    (unless that path is a local junction to this PC's own home and the session was started or opened here),
//    to this host when the folder is under its own home, to the device id stamped on it, then to the caller's fallback.
function inferRowOwnerDevice(rowOrCwd, fallbackDevice = null, opts = {}) {
  const makeOwner = (id, name) => ({ id, name: name || id, deviceId: id, deviceName: name || id });
  const r = typeof rowOrCwd === 'object' && rowOrCwd ? rowOrCwd : { cwd: String(rowOrCwd || '') };
  const explicitId = String(r.deviceId || '').trim();
  const explicitName = String(r.deviceName || '').trim();
  if (explicitId && (opts.trustStamp || r.source === 'cloud-relay' || r.remotePeer === true)) {
    return makeOwner(explicitId, explicitName);
  }
  const cwdLow = normalizeHomePath(r.cwd);
  const homeOwner = findFleetHomeOwner(cwdLow);
  let underLocalHomeAlias = false;
  if (homeOwner) {
    if (isLocalHomeAlias(homeOwner.homeKey)) {
      underLocalHomeAlias = true;
      const locallyActive = Boolean(r.open || r.active || r.directStreaming || r.status === 'working');
      if (!locallyActive && isRowPublishedByPeer(homeOwner, r.id, opts)) {
        return makeOwner(homeOwner.id, homeOwner.name || (explicitId === homeOwner.id ? explicitName : ''));
      }
    } else {
      return makeOwner(homeOwner.id, homeOwner.name || (explicitId === homeOwner.id ? explicitName : ''));
    }
  }
  const selfHome = normalizeHomePath(selfHomeDir());
  if (cwdLow && ((selfHome && (cwdLow === selfHome || cwdLow.startsWith(`${selfHome}\\`))) || underLocalHomeAlias)) {
    // For a local row the caller's fallback is this host (the running bridge's own identity).
    if (fallbackDevice && fallbackDevice.id) {
      return makeOwner(fallbackDevice.id, fallbackDevice.name || fallbackDevice.id);
    }
    const self = getSelfDeviceRef();
    return makeOwner(self.id, self.name);
  }
  if (explicitId) {
    return makeOwner(explicitId, explicitName);
  }
  if (r.source === 'cloud-relay') {
    // A row that arrived from the store without an owner stamp belongs to some other host, never to this one.
    return makeOwner('unknown-host', 'Another PC');
  }
  if (fallbackDevice && fallbackDevice.id) {
    return makeOwner(fallbackDevice.id, fallbackDevice.name || fallbackDevice.id);
  }
  const self = getSelfDeviceRef();
  return makeOwner(self.id, self.name);
}

// Sessions, groups and workspaces of every host except this one, from the store's `device_states` map. Each row is
// stamped with the host that published it. This is what a host shows as "sessions on my other PCs".
function buildPeerSnapshot(deviceStates, selfId = '') {
  const rows = [];
  const groups = [];
  const workspaces = [];
  const seenRows = new Set();
  const seenGroups = new Set();
  const seenWorkspaces = new Set();
  const entries = Object.entries(deviceStates && typeof deviceStates === 'object' ? deviceStates : {})
    .filter(([devId, entry]) => devId && devId !== selfId && entry && typeof entry === 'object')
    .sort((a, b) => Number(b[1].updatedAt || 0) - Number(a[1].updatedAt || 0));
  for (const [devId, entry] of entries) {
    const devName = String(entry.device?.name || devId).trim() || devId;
    const snap = entry.snapshot && typeof entry.snapshot === 'object' ? entry.snapshot : {};
    const entryRows = Array.isArray(snap.rows) ? snap.rows : Array.isArray(entry.rows) ? entry.rows : [];
    for (const r of entryRows) {
      if (!r || !r.id || seenRows.has(r.id)) continue;
      seenRows.add(r.id);
      rows.push({ ...r, deviceId: devId, deviceName: devName });
    }
    for (const g of Array.isArray(snap.groups) ? snap.groups : []) {
      if (!g || !g.id || seenGroups.has(g.id)) continue;
      seenGroups.add(g.id);
      groups.push(g);
    }
    const entryWorkspaces = Array.isArray(entry.workspaces)
      ? entry.workspaces
      : Array.isArray(snap.workspaces)
        ? snap.workspaces
        : [];
    for (const w of entryWorkspaces) {
      if (!w || !w.id || seenWorkspaces.has(w.id)) continue;
      seenWorkspaces.add(w.id);
      workspaces.push(w);
    }
  }
  return { generatedAt: Date.now(), rows, groups, workspaces };
}

// The store lives behind the Edge relay this host is paired with: <edge origin>/store, opened with the same derived
// token as the relay. A paired host therefore needs no store address of its own.
function deriveStoreEndpoint(edgeRelayUrl) {
  const base = String(edgeRelayUrl || '')
    .trim()
    .replace(/^wss:/i, 'https:')
    .replace(/^ws:/i, 'http:')
    .replace(/[?#].*$/, '')
    .replace(/\/+$/, '')
    .replace(/\/ws$/i, '');
  if (!base || !isSafeCloudEndpointUrl(base)) return '';
  return `${base}/store`;
}

function decodeMaybeBase64(val) {
  const s = String(val || '').trim();
  if (!s) return '';
  if (/^https?:\/\//i.test(s) || /^[0-9a-f]{32,}$/i.test(s)) return s;
  try {
    const dec = Buffer.from(s, 'base64').toString('utf8').trim();
    if (dec && /^[\x20-\x7e]+$/.test(dec)) return dec;
  } catch {}
  return s;
}

function loadTheoCredentials(extraDir = '') {
  let fileCfg = {};
  try {
    if (fs.existsSync(credFilePath())) {
      const parsed = JSON.parse(fs.readFileSync(credFilePath(), 'utf8'));
      if (parsed && typeof parsed === 'object') {
        fileCfg = parsed;
      }
    }
  } catch {}

  let legacyCfg = {};
  const legacyCandidates = [
    extraDir ? path.join(extraDir, 'remote-relay.json') : '',
    path.join(__dirname, 'remote-relay.json')
  ].filter(Boolean);
  for (const p of legacyCandidates) {
    try {
      if (fs.existsSync(p)) {
        const parsed = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (parsed && typeof parsed === 'object') {
          legacyCfg = parsed;
          break;
        }
      }
    } catch {}
  }

  const edgeAccessKey = String(
    process.env.THEO_EDGE_KEY || fileCfg.edgeAccessKey || ''
  ).trim();
  const edgeRelayUrl = String(
    process.env.THEO_EDGE_RELAY_URL ||
      fileCfg.edgeRelayUrl ||
      legacyCfg.edgeUrl ||
      DEFAULT_EDGE_RELAY_URL
  ).trim();

  // Store address, in order: an explicit environment override, the store behind the paired Edge relay, then
  // whatever the credentials file holds. Deriving it means a host paired with the relay follows a store move
  // without any per-PC step. `cloudPinned: true` in the file keeps a hand-set address instead.
  const envCloudUrl = String(process.env.THEO_CLOUD_URL || '').trim();
  const envCloudKey = String(process.env.THEO_CLOUD_KEY || '').trim();
  const fileCloudUrl = decodeMaybeBase64(fileCfg.cloudUrl || fileCfg.u || legacyCfg.u || '');
  const fileCloudKey = decodeMaybeBase64(fileCfg.cloudKey || fileCfg.k || legacyCfg.k || '');
  const derivedStoreUrl = edgeAccessKey ? deriveStoreEndpoint(edgeRelayUrl) : '';
  let cloudUrl = '';
  let cloudKey = '';
  let cloudSource = 'none';
  if (envCloudUrl || envCloudKey) {
    cloudUrl = decodeMaybeBase64(envCloudUrl) || fileCloudUrl;
    cloudKey = decodeMaybeBase64(envCloudKey) || fileCloudKey;
    cloudSource = 'env';
  } else if (derivedStoreUrl && fileCfg.cloudPinned !== true) {
    cloudUrl = derivedStoreUrl;
    cloudKey = deriveEdgeAuthToken(edgeAccessKey);
    cloudSource = 'edge';
  } else if (fileCloudUrl || fileCloudKey) {
    cloudUrl = fileCloudUrl;
    cloudKey = fileCloudKey;
    cloudSource = 'file';
  }

  const port = Number(process.env.THEO_BRIDGE_PORT || fileCfg.port || legacyCfg.port || 4318) || 4318;
  const allowLan = Boolean(
    process.env.THEO_ALLOW_LAN === '1' || fileCfg.allowLan === true
  );

  return {
    cloudUrl,
    cloudKey,
    cloudSource,
    cloudPinned: fileCfg.cloudPinned === true,
    // What the credentials file itself holds, which differs from the address in use when that one is derived.
    fileCloudUrl,
    fileCloudKey,
    u: cloudUrl ? Buffer.from(cloudUrl, 'utf8').toString('base64') : '',
    k: cloudKey ? Buffer.from(cloudKey, 'utf8').toString('base64') : '',
    edgeAccessKey,
    // Fallback to cloudKey only if edgeAccessKey has not been minted on a host yet
    effectiveEdgeSecret: edgeAccessKey || cloudKey,
    edgeRelayUrl,
    port,
    allowLan
  };
}

function saveTheoCredentials(patch = {}) {
  const cur = loadTheoCredentials();
  // The file keeps what it held: a derived (or environment) store address is never written over a hand-set one,
  // so saving an unrelated field cannot lose it.
  const nextCloudUrl =
    patch.cloudUrl !== undefined ? decodeMaybeBase64(patch.cloudUrl) : cur.fileCloudUrl;
  const nextCloudKey =
    patch.cloudKey !== undefined ? decodeMaybeBase64(patch.cloudKey) : cur.fileCloudKey;
  const next = {
    u: nextCloudUrl ? Buffer.from(nextCloudUrl, 'utf8').toString('base64') : '',
    k: nextCloudKey ? Buffer.from(nextCloudKey, 'utf8').toString('base64') : '',
    edgeAccessKey:
      patch.edgeAccessKey !== undefined
        ? String(patch.edgeAccessKey || '').trim()
        : cur.edgeAccessKey || '',
    edgeRelayUrl:
      patch.edgeRelayUrl !== undefined
        ? String(patch.edgeRelayUrl || '').trim()
        : cur.edgeRelayUrl || DEFAULT_EDGE_RELAY_URL,
    port: Number(patch.port || cur.port || 4318) || 4318,
    allowLan: patch.allowLan !== undefined ? Boolean(patch.allowLan) : Boolean(cur.allowLan),
    ...(patch.cloudPinned !== undefined
      ? patch.cloudPinned
        ? { cloudPinned: true }
        : {}
      : cur.cloudPinned
        ? { cloudPinned: true }
        : {}),
    updatedAt: Date.now()
  };
  try {
    fs.mkdirSync(path.dirname(credFilePath()), { recursive: true });
    fs.writeFileSync(credFilePath(), JSON.stringify(next, null, 2), { encoding: 'utf8', mode: 0o600 });
  } catch {}
  return loadTheoCredentials();
}

function buildPairTokenBase64Url(creds = null) {
  const c = creds || loadTheoCredentials();
  const edgeKey = String(c.edgeAccessKey || c.effectiveEdgeSecret || '').trim();
  const cloudUrl = decodeMaybeBase64(c.cloudUrl || c.u || '');
  const cloudKey = decodeMaybeBase64(c.cloudKey || c.k || '');
  if (!edgeKey && !cloudUrl && !cloudKey) return '';
  const payload = {
    v: 1,
    e: edgeKey,
    r: String(c.edgeRelayUrl || c.w || DEFAULT_EDGE_RELAY_URL).trim(),
    u: cloudUrl,
    k: cloudKey,
    p: Number(c.port || c.p || 4318) || 4318
  };
  return Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
}

function isSafeCloudEndpointUrl(rawUrl) {
  const u = String(rawUrl || '').trim();
  if (!u) return true;
  return /^https:\/\/[^\s]+$/i.test(u) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/|$)/i.test(u);
}

function isSafeEdgeEndpointUrl(rawUrl) {
  const u = String(rawUrl || '').trim();
  if (!u) return true;
  return (
    /^(wss|https):\/\/[^\s]+$/i.test(u) ||
    /^(ws|http):\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/|$)/i.test(u)
  );
}

function parsePairTokenBase64Url(rawToken) {
  const text = String(rawToken || '').trim();
  if (!text) return null;
  const hashMatch = text.match(/#pair=([A-Za-z0-9_=-]{16,8192})/i);
  const envMatch =
    !hashMatch && text.match(/THEO_PAIR_TOKEN\s*=\s*['"]?([A-Za-z0-9_=-]{16,8192})['"]?/i);
  const clean = hashMatch
    ? hashMatch[1]
    : envMatch
      ? envMatch[1]
      : text
          .replace(/^#?pair=/i, '')
          .split(/[\s&'"]+/)[0]
          .trim();
  if (!clean) return null;
  try {
    const jsonStr = Buffer.from(clean, 'base64url').toString('utf8');
    const obj = JSON.parse(jsonStr);
    if (!obj || typeof obj !== 'object') return null;
    const edgeAccessKey = String(obj.e || obj.edgeAccessKey || '').trim();
    const cloudUrl = decodeMaybeBase64(obj.u || obj.cloudUrl || '');
    const cloudKey = decodeMaybeBase64(obj.k || obj.cloudKey || '');
    const rawEdgeUrl = String(obj.r || obj.w || obj.edgeRelayUrl || '').trim();
    if (!edgeAccessKey && !cloudKey) return null;
    if (cloudUrl && !cloudKey) return null;
    if (!isSafeCloudEndpointUrl(cloudUrl) || !isSafeEdgeEndpointUrl(rawEdgeUrl)) return null;
    return {
      edgeAccessKey,
      edgeRelayUrl: rawEdgeUrl || DEFAULT_EDGE_RELAY_URL,
      cloudUrl,
      cloudKey,
      port: Number(obj.p || obj.port || 4318) || 4318
    };
  } catch {
    if (/^[a-fA-F0-9]{32,128}$/.test(clean)) {
      return {
        edgeAccessKey: clean,
        edgeRelayUrl: DEFAULT_EDGE_RELAY_URL,
        cloudUrl: '',
        cloudKey: '',
        port: 4318
      };
    }
    return null;
  }
}

function loadBundledEdgeRelayUrl() {
  return loadTheoCredentials().edgeRelayUrl;
}

function loadDeviceConfig() {
  try {
    if (fs.existsSync(deviceFilePath())) {
      const parsed = JSON.parse(fs.readFileSync(deviceFilePath(), 'utf8'));
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    }
  } catch {}
  return null;
}

function saveDeviceConfig(cfg) {
  try {
    fs.mkdirSync(path.dirname(deviceFilePath()), { recursive: true });
    fs.writeFileSync(deviceFilePath(), JSON.stringify(cfg, null, 2), 'utf8');
  } catch {}
  selfDeviceRefCache = null;
}

function getDeviceIdentity(overrides = {}) {
  const defaults = inferDefaultDeviceIdentity();
  const saved = loadDeviceConfig() || {};
  const agyBin = resolveAgyBinaryPath();
  const claudeBin = resolveClaudeBinaryPath();
  const capabilities = [];
  if (agyBin) capabilities.push('antigravity');
  if (claudeBin) capabilities.push('claude');

  let username = '';
  try {
    username = os.userInfo().username || '';
  } catch {}

  // A saved id is kept as it is (it is only a stable key). A saved name is kept unless it is one an older build
  // assigned from the home folder, and the old primary / secondary role is retired: every host is `host`.
  const savedName = String(saved.name || '').trim();
  const savedNameIsRetired = Boolean(savedName) && RETIRED_DEFAULT_DEVICE_NAMES.has(savedName.toLowerCase());
  const savedRoleIsRetired = Boolean(saved.id) && saved.role !== HOST_ROLE;
  const resolvedId = cleanDeviceId(overrides.id) || cleanDeviceId(saved.id) || defaults.id;
  const savedIdNeedsRewrite = Boolean(saved.id) && saved.id !== resolvedId && !overrides.id;
  const identity = {
    id: resolvedId,
    name: String(overrides.name || (savedNameIsRetired ? '' : savedName) || defaults.name).trim(),
    role: HOST_ROLE,
    hostname: os.hostname(),
    username,
    homedir: os.homedir(),
    platform: process.platform,
    arch: process.arch,
    lanIps: getLanIps(),
    capabilities,
    binaries: {
      agy: agyBin,
      claude: claudeBin
    },
    edgeRelayUrl: String(
      overrides.edgeRelayUrl !== undefined
        ? overrides.edgeRelayUrl
        : process.env.THEO_EDGE_RELAY_URL || saved.edgeRelayUrl || loadBundledEdgeRelayUrl() || ''
    ).trim(),
    updatedAt: Date.now()
  };

  if (
    !saved.id ||
    overrides.name ||
    overrides.edgeRelayUrl !== undefined ||
    savedNameIsRetired ||
    savedRoleIsRetired ||
    savedIdNeedsRewrite
  ) {
    saveDeviceConfig({
      id: identity.id,
      name: identity.name,
      role: identity.role,
      hostname: identity.hostname,
      edgeRelayUrl: identity.edgeRelayUrl,
      createdAt: saved.createdAt || Date.now(),
      updatedAt: Date.now()
    });
  }

  return identity;
}

function updateDeviceConfig(patch = {}) {
  const current = getDeviceIdentity();
  const merged = {
    ...(loadDeviceConfig() || {}),
    id: patch.id ? slugifyId(patch.id) : current.id,
    name: patch.name ? String(patch.name).trim().slice(0, 48) : current.name,
    role: HOST_ROLE,
    edgeRelayUrl:
      patch.edgeRelayUrl !== undefined
        ? String(patch.edgeRelayUrl || '').trim()
        : current.edgeRelayUrl,
    updatedAt: Date.now()
  };
  saveDeviceConfig(merged);
  return getDeviceIdentity();
}

function deriveEdgeAuthToken(relayKey) {
  const cleanKey = String(relayKey || '').trim();
  if (!cleanKey) return '';
  return crypto
    .createHash('sha256')
    .update(`theo-edge-v1:${cleanKey}`, 'utf8')
    .digest('hex');
}

// Domain-separated 32-byte signing key for self-updating `theo-hub` bundles, derived from `edgeAccessKey` (never from
// the derived `AUTH_TOKEN` stored on the Worker), so only a paired PC holding `edgeAccessKey` can sign `hub_release`.
function deriveBundleSignKey(edgeAccessKey) {
  const cleanKey = String(edgeAccessKey || '').trim();
  if (!cleanKey || cleanKey.length < 24) return null;
  return crypto
    .createHash('sha256')
    .update(`theo-bundle-sign-v1:${cleanKey}`, 'utf8')
    .digest();
}

// ---- Host user-activity tracking (last-typed PC wins untargeted commands & coordinator duty) ----
let lastInProcessUserActivityAt = 0;
let cachedOsInputAt = 0;
let osIdlePollInFlight = false;
let lastOsIdlePollAt = 0;
let launcherIdleCapCache = { key: '', supported: false };
const OS_IDLE_POLL_INTERVAL_MS = 10000;

function noteLocalUserActivity(atMs = Date.now()) {
  const n = Number(atMs);
  if (Number.isFinite(n) && n > lastInProcessUserActivityAt) {
    lastInProcessUserActivityAt = n;
  }
}

// Probes `THEO.exe --verify-config` once per (path, mtimeMs, size). Pre-upgrade THEO.exe binaries only understand
// `--verify-config` (side-effect-free on all versions) and treat unknown flags like `--idle-ms` as a normal GUI launch.
function probeLauncherSupportsIdleMs(exePath, done) {
  let st;
  try {
    st = fs.statSync(exePath);
  } catch {
    done(false);
    return;
  }
  const statKey = `${exePath}|${st.mtimeMs}|${st.size}`;
  if (launcherIdleCapCache.key === statKey) {
    done(launcherIdleCapCache.supported);
    return;
  }
  execFile(
    exePath,
    ['--verify-config'],
    { timeout: 2500, windowsHide: true },
    (err, stdout) => {
      let supported = false;
      if (!err && stdout) {
        try {
          const parsed = JSON.parse(String(stdout).trim());
          supported = Boolean(parsed && parsed.ok === true && parsed.supportsIdleMs === true);
        } catch {}
      }
      launcherIdleCapCache = { key: statKey, supported };
      done(supported);
    }
  );
}

function refreshOsIdleMsAsync(opts = {}) {
  if (process.platform !== 'win32' && !opts.forcePlatform) return;
  if (
    !opts.allowInSmokeTest &&
    (process.env.THEO_SMOKE_TEST === '1' || process.env.THEO_HEADLESS_TEST === '1')
  ) {
    return;
  }
  const now = Date.now();
  if (osIdlePollInFlight || (!opts.ignoreInterval && now - lastOsIdlePollAt < OS_IDLE_POLL_INTERVAL_MS)) {
    return;
  }
  const exePath =
    opts.exePath ||
    process.env.THEO_LAUNCHER_EXE_PATH ||
    path.join(os.homedir(), '.theo', 'THEO.exe');
  try {
    if (!fs.existsSync(exePath)) return;
  } catch {
    return;
  }
  osIdlePollInFlight = true;
  lastOsIdlePollAt = now;
  probeLauncherSupportsIdleMs(exePath, (supported) => {
    if (!supported) {
      osIdlePollInFlight = false;
      if (typeof opts.onDone === 'function') opts.onDone({ polled: false, reason: 'unsupported_launcher' });
      return;
    }
    execFile(
      exePath,
      ['--idle-ms'],
      { timeout: 1500, windowsHide: true },
      (err, stdout) => {
        osIdlePollInFlight = false;
        if (err) {
          if (typeof opts.onDone === 'function') opts.onDone({ polled: false, reason: 'exec_error' });
          return;
        }
        const parsed = Number(String(stdout || '').trim());
        if (Number.isFinite(parsed) && parsed >= 0) {
          const observedAt = Date.now() - Math.floor(parsed);
          if (observedAt > cachedOsInputAt) {
            cachedOsInputAt = observedAt;
          }
          if (typeof opts.onDone === 'function') opts.onDone({ polled: true, idleMs: Math.floor(parsed) });
        } else if (typeof opts.onDone === 'function') {
          opts.onDone({ polled: false, reason: 'bad_output' });
        }
      }
    );
  });
}

// Milliseconds since the user last typed or clicked on this host, or null if not yet observed.
function getHostIdleMs(nowMs = Date.now()) {
  if (process.env.THEO_IDLE_MS_OVERRIDE !== undefined && process.env.THEO_IDLE_MS_OVERRIDE !== '') {
    const ov = Number(process.env.THEO_IDLE_MS_OVERRIDE);
    return Number.isFinite(ov) && ov >= 0 ? Math.floor(ov) : null;
  }
  refreshOsIdleMsAsync();
  const latestAt = Math.max(lastInProcessUserActivityAt, cachedOsInputAt);
  if (latestAt <= 0) return null;
  return Math.max(0, Math.floor(nowMs - latestAt));
}

module.exports = {
  DEVICE_FILE,
  THEO_CRED_FILE,
  DEFAULT_EDGE_RELAY_URL,
  getLanIps,
  resolveAgyBinaryPath,
  resolveClaudeBinaryPath,
  resolveNodeBinaryInfo,
  resolveSpawnableCli,
  HOST_ROLE,
  cleanDeviceId,
  FLEET_HOMES_FILE,
  isLocalHomeAlias,
  inferRowOwnerDevice,
  rememberFleetHomes,
  getSelfDeviceRef,
  buildPeerSnapshot,
  deriveStoreEndpoint,
  loadTheoCredentials,
  saveTheoCredentials,
  buildPairTokenBase64Url,
  parsePairTokenBase64Url,
  getDeviceIdentity,
  updateDeviceConfig,
  deriveEdgeAuthToken,
  deriveBundleSignKey,
  noteLocalUserActivity,
  probeLauncherSupportsIdleMs,
  refreshOsIdleMsAsync,
  getHostIdleMs
};
