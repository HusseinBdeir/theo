"""Package this folder as a VSIX + signed self-updating theo-hub-bundle.zip without vsce."""
import argparse
import atexit
import hashlib
import hmac
import io
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import time
import urllib.request
import zipfile

DEFAULT_BUNDLE_URL = "https://husseinbdeir.github.io/theo/theo-hub-bundle.zip"

parser = argparse.ArgumentParser(description="Build THEO Hub VSIX + signed self-updating bundle.")
parser.add_argument(
    "--no-publish-store",
    action="store_true",
    help="Build VSIX + theo-hub-bundle.zip + release meta without patching hub_release in the store.",
)
parser.add_argument(
    "--publish-only",
    action="store_true",
    help="Verify live bundle URL matches dist/theo-hub-release-meta.json and publish signed hub_release to store.",
)
parser.add_argument(
    "--bundle-url",
    default=DEFAULT_BUNDLE_URL,
    help="HTTPS URL where theo-hub-bundle.zip is served.",
)
parser.add_argument(
    "--out-dir",
    default="",
    help="Optional isolated output directory (for tests; skips copying to ../theo, Admin, and ~/.claude).",
)
parser.add_argument(
    "--allow-loopback-test",
    action="store_true",
    help="Allow loopback HTTP URLs during automated smoke testing.",
)
parser.add_argument(
    "--allow-dirty",
    action="store_true",
    help=(
        "Publish even when bundled files have uncommitted edits or the theo-hub branch is not in step "
        "with origin. Without it, a publish refuses and lists the files."
    ),
)
parser.add_argument(
    "--pages-repo",
    default="",
    help=(
        "git checkout whose upstream branch GitHub Pages serves the bundle from. Defaults to ../theo when "
        "--bundle-url is the default URL; set it explicitly to push elsewhere (tests)."
    ),
)
args = parser.parse_args()

root = pathlib.Path(__file__).parent
pkg = json.loads((root / "package.json").read_text(encoding="utf-8"))
version = pkg["version"]
isolated_out = bool(args.out_dir)
dist_dir = pathlib.Path(args.out_dir).resolve() if isolated_out else (root / "dist")
dist_dir.mkdir(parents=True, exist_ok=True)
out = dist_dir / f"{pkg['name']}-{version}.vsix"
release_meta_path = dist_dir / "theo-hub-release-meta.json"

files = [
    "package.json",
    "extension.js",
    "accounts.js",
    "session-tabs.js",
    "hub.js",
    "data.js",
    "store.js",
    "state.js",
    "bridge.js",
    "remote.js",
    "device-identity.js",
    "pc-setup.js",
    "bundle-updater.js",
    "ws-server.js",
    "direct-runner.js",
    "edge-relay-client.js",
    "README.md",
    "activity.js",
    "desktop-notify.js",
    "desktop-launcher.js",
    "compat/antigravity-hub-bridge.cjs",
    "compat/antigravity-tab-state.cjs",
    "compat/antigravity-context-window.cjs",
    "compat/claude-hub-bridge.cjs",
    "compat/claude-webview-patches.cjs",
    "compat/excel-preview.cjs",
    "resources/icon.png",
    "resources/theo.ico",
    "resources/TheoLauncher.cs",
    "resources/logo.svg",
    "resources/antigravity-logo-color.svg",
    "resources/antigravity-logo-done.svg",
    "resources/antigravity-logo-pending.svg",
    "resources/claude-logo.svg",
    "resources/claude-logo-done.svg",
    "resources/claude-logo-pending.svg",
    "resources/hub.html",
    "resources/hub.css",
    "resources/hub.js",
    "scripts/relay_keepalive.cjs",
    "scripts/relay_keepalive_start.ps1",
    "scripts/memory_cloud_sync.cjs",
    "scripts/theo_agent.cjs",
    "scripts/theo_agent_start.ps1",
    "scripts/install_desktop_shortcut.ps1",
]

BUNDLE_FILES = sorted(
    set(
        files
        + [
            "install_local.py",
            "build_vsix.py",
            "test/smoke.test.cjs",
            "test/store.test.cjs",
            "cloudflare-relay/deploy_edge_relay.ps1",
            "cloudflare-relay/src/index.js",
            "cloudflare-relay/src/store.js",
            "cloudflare-relay/src/worker.js",
            "cloudflare-relay/wrangler.toml",
        ]
    )
)
BUNDLE_NAME = "theo-hub-bundle.zip"
PAGES_WAIT_SECONDS = 600


def find_node_exe() -> tuple[str, dict]:
    portable_node = pathlib.Path.home() / ".local" / "node" / "node.exe"
    env = os.environ.copy()
    if portable_node.exists():
        return str(portable_node), env
    found = shutil.which("node")
    if found:
        return found, env
    for cand in (
        pathlib.Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / "Code.exe",
        pathlib.Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "Microsoft VS Code" / "Code.exe",
    ):
        if cand.exists():
            env["ELECTRON_RUN_AS_NODE"] = "1"
            return str(cand), env
    raise RuntimeError("Node executable not found for bundle verification.")


def load_theo_creds() -> dict:
    cred_path = pathlib.Path.home() / ".theo" / "credentials.json"
    if not cred_path.exists():
        return {}
    try:
        return json.loads(cred_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def sign_release_record(rec: dict, edge_access_key: str) -> str:
    clean_key = edge_access_key.strip()
    if len(clean_key) < 24:
        raise ValueError("edgeAccessKey too short to sign hub_release")
    sign_key = hashlib.sha256(f"theo-bundle-sign-v1:{clean_key}".encode("utf-8")).digest()
    canonical = "|".join(
        [
            "theo-hub-bundle-v1",
            str(rec["version"]).strip(),
            str(int(rec["builtAt"])),
            str(rec["sha256"]).strip().lower(),
            str(rec["url"]).strip(),
        ]
    )
    return hmac.new(sign_key, canonical.encode("utf-8"), hashlib.sha256).hexdigest()


def load_effective_theo_creds() -> dict:
    node_exe, node_env = find_node_exe()
    res = subprocess.run(
        [
            node_exe,
            "-e",
            (
                "const d=require(process.argv[1]);"
                "const c=d.loadTheoCredentials();"
                "process.stdout.write(JSON.stringify({"
                "edgeAccessKey:c.edgeAccessKey||'',"
                "cloudUrl:c.cloudUrl||'',"
                "cloudKey:c.cloudKey||'',"
                "cloudSource:c.cloudSource||''"
                "}));"
            ),
            str(root / "device-identity.js"),
        ],
        env=node_env,
        capture_output=True,
        text=True,
        check=True,
    )
    return json.loads(res.stdout.strip() or "{}")


# ---------------------------------------------------------------------------
# Release guard: publish only committed, pushed code, and push the bundle to
# GitHub Pages ourselves instead of waiting for a zip nobody committed.
# Several Claude sessions edit these working trees at once, so:
#   * the theo-hub tree is checked before the build and again after the zip
#     is written (an edit made mid-build cannot ship);
#   * the Pages commit is built with git plumbing on top of origin's branch
#     and pushed by hash, so only the bundle bytes can reach origin and the
#     theo working tree, index and local commits are never touched;
#   * one build at a time per dist folder (lock file).
# ---------------------------------------------------------------------------

GIT_ENV = dict(os.environ, GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="never")
LOCK_STALE_SECONDS = 1800
PUSH_ATTEMPTS = 3


def git(
    repo: pathlib.Path,
    *git_args: str,
    check: bool = True,
    timeout: int = 120,
    env: dict | None = None,
    raw: bool = False,
):
    """Run git with no stdin and file-backed output, so a killed git on Windows cannot hang on pipes."""
    with tempfile.TemporaryFile() as out_f, tempfile.TemporaryFile() as err_f:
        try:
            proc = subprocess.run(
                ["git", "-C", str(repo), *git_args],
                stdin=subprocess.DEVNULL,
                stdout=out_f,
                stderr=err_f,
                timeout=timeout,
                env=env or GIT_ENV,
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"git {' '.join(git_args)} timed out after {timeout} s in {repo}") from None
        out_f.seek(0)
        err_f.seek(0)
        out_bytes = out_f.read()
        stdout = out_bytes if raw else out_bytes.decode("utf-8", errors="replace")
        stderr = err_f.read().decode("utf-8", errors="replace")
    res = subprocess.CompletedProcess(proc.args, proc.returncode, stdout, stderr)
    if check and res.returncode != 0:
        detail = (stderr or ("" if raw else stdout) or "").strip()
        raise RuntimeError(f"git {' '.join(git_args)} failed in {repo}: {detail}")
    return res


def is_git_repo(repo: pathlib.Path) -> bool:
    return (repo / ".git").exists()


def porcelain_entries(repo: pathlib.Path) -> list[tuple[str, list[str]]]:
    """(XY status, paths) for every changed or untracked file. A rename or copy in either
    column carries both its new and its source path, so moving a bundled file away is seen."""
    out = git(repo, "status", "--porcelain=v1", "-z", "--untracked-files=all").stdout
    entries = out.split("\0")
    result = []
    i = 0
    while i < len(entries):
        entry = entries[i]
        i += 1
        if len(entry) < 4:
            continue
        code, paths = entry[:2], [entry[3:]]
        if ("R" in code or "C" in code) and i < len(entries):
            paths.append(entries[i])
            i += 1
        result.append((code, [p.replace("\\", "/") for p in paths]))
    return result


def dirty_bundled_files(repo: pathlib.Path) -> list[str]:
    bundled = set(BUNDLE_FILES)
    dirty = []
    for code, paths in porcelain_entries(repo):
        if any(p in bundled for p in paths):
            dirty.append(f"{code.strip() or '?'} {' <- '.join(paths)}")
    tracked = set(git(repo, "ls-files", "-z").stdout.split("\0"))
    for bf in BUNDLE_FILES:
        if bf in tracked and not (repo / bf).exists():
            dirty.append(f"missing {bf}")
    return sorted(set(dirty))


def upstream_divergence(repo: pathlib.Path) -> tuple:
    """(ahead, behind, fetched_ok); ahead/behind are None when the branch has no upstream."""
    fetched = git(repo, "fetch", "--quiet", check=False, timeout=90).returncode == 0
    up = git(repo, "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}", check=False)
    if up.returncode != 0:
        return None, None, fetched
    counts = git(repo, "rev-list", "--left-right", "--count", "HEAD...@{u}").stdout.split()
    return int(counts[0]), int(counts[1]), fetched


HUB_HEAD_AT_START = ""


def hub_tree_problems() -> list[str]:
    """Reasons the theo-hub tree must not be published to the fleet as-is."""
    global HUB_HEAD_AT_START
    if not is_git_repo(root):
        return [f"{root} is not a git repository, so the bundle cannot be tied to a pushed commit"]
    HUB_HEAD_AT_START = git(root, "rev-parse", "HEAD").stdout.strip()
    problems = []
    dirty = dirty_bundled_files(root)
    if dirty:
        problems.append("uncommitted edits in files that ship in the bundle:\n      " + "\n      ".join(dirty))
    ahead, behind, fetched = upstream_divergence(root)
    if not fetched:
        problems.append("git fetch failed for theo-hub, so it cannot be confirmed level with origin")
    if ahead is None:
        problems.append("the theo-hub branch has no upstream to compare against")
    else:
        if ahead:
            problems.append(f"{ahead} theo-hub commit(s) not pushed to origin yet (push them first)")
        if behind:
            problems.append(f"theo-hub is {behind} commit(s) behind origin (pull first, or the fleet gets older code)")
    return problems


def bundle_drift_problems(manifest_files_map: dict) -> list[str]:
    """After the zip is written: anything that changed on disk while we were building."""
    problems = []
    for bf in BUNDLE_FILES:
        bp = root / bf
        on_disk = file_sha256(bp) if bp.exists() else None
        if on_disk != manifest_files_map.get(bf):
            problems.append(f"{bf} changed on disk while the bundle was being built")
    if is_git_repo(root):
        dirty = dirty_bundled_files(root)
        if dirty:
            problems.append("uncommitted edits appeared during the build:\n      " + "\n      ".join(dirty))
        head_now = git(root, "rev-parse", "HEAD").stdout.strip()
        if HUB_HEAD_AT_START and head_now != HUB_HEAD_AT_START:
            problems.append(f"theo-hub HEAD moved during the build ({HUB_HEAD_AT_START[:7]} -> {head_now[:7]})")
        unpushed = git(root, "rev-list", "--count", "@{u}..HEAD", check=False).stdout.strip()
        if unpushed not in ("", "0"):
            problems.append(f"{unpushed} theo-hub commit(s) not pushed to origin (made during the build)")
    return problems


def bundle_built_at(zip_bytes: bytes) -> int | None:
    """builtAt from a bundle's .theo-bundle-manifest.json, or None when it is not a readable bundle."""
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            manifest = json.loads(zf.read(".theo-bundle-manifest.json").decode("utf-8"))
        return int(manifest["builtAt"])
    except Exception:
        return None


def pages_target(theo_dir: pathlib.Path) -> tuple[str, str]:
    """(remote, branch ref) that the theo checkout tracks, e.g. ('origin', 'refs/heads/main')."""
    if not is_git_repo(theo_dir):
        raise RuntimeError(f"{theo_dir} is not a git repository, so the bundle cannot be pushed to GitHub Pages")
    branch = git(theo_dir, "symbolic-ref", "--short", "HEAD", check=False).stdout.strip()
    remote = git(theo_dir, "config", "--get", f"branch.{branch}.remote", check=False).stdout.strip() if branch else ""
    merge = git(theo_dir, "config", "--get", f"branch.{branch}.merge", check=False).stdout.strip() if branch else ""
    if not remote or not merge.startswith("refs/heads/"):
        raise RuntimeError(f"{theo_dir} has no upstream branch to push the bundle to (branch '{branch}')")
    return remote, merge


def pages_repo_problems(theo_dir: pathlib.Path) -> list[str]:
    """Fail fast, before building, when the bundle could not be pushed."""
    try:
        remote, _merge = pages_target(theo_dir)
    except RuntimeError as err:
        return [str(err)]
    if git(theo_dir, "fetch", "--quiet", remote, check=False, timeout=120).returncode != 0:
        return [f"git fetch {remote} failed for the theo repo (offline?), so the bundle cannot be pushed"]
    return []


def refuse(title: str, problems: list[str], hint: str) -> None:
    lines = [f"[REFUSED] {title}:"] + [f"  - {p}" for p in problems] + [f"  {hint}"]
    raise SystemExit("\n".join(lines))


def file_sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().lower()


def acquire_build_lock(lock_dir: pathlib.Path) -> None:
    """One build_vsix.py run at a time per dist folder; a lock older than 30 min is treated as dead."""
    lock = lock_dir / ".build_vsix.lock"
    token = f"{os.getpid()}-{time.time_ns()}"
    for _ in range(3):
        try:
            fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            try:
                age = time.time() - lock.stat().st_mtime
            except FileNotFoundError:
                continue
            if age > LOCK_STALE_SECONDS:
                print(f"[WARN] Removing stale build lock {lock} ({int(age)} s old)")
                lock.unlink(missing_ok=True)
                continue
            raise SystemExit(
                f"[REFUSED] Another build_vsix.py run holds {lock} (started {int(age)} s ago). "
                "Wait for it to finish, or delete the file if that run died."
            )
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"pid": os.getpid(), "startedAt": int(time.time()), "token": token}))

        def release_lock() -> None:
            # Remove the lock only if it is still ours (a run that outlived the stale timeout must not
            # delete the lock a newer run has taken since).
            try:
                if json.loads(lock.read_text(encoding="utf-8")).get("token") == token:
                    lock.unlink(missing_ok=True)
            except Exception:
                pass

        atexit.register(release_lock)
        return
    raise SystemExit(f"[REFUSED] Could not take the build lock {lock}.")


def push_bundle_to_pages(bundle_path: pathlib.Path, meta: dict, theo_dir: pathlib.Path, label: str) -> None:
    """Commit the bundle on top of origin's branch with plumbing and push that commit by hash.

    Nothing local is used as the parent, so unpushed commits from other sessions can never ride
    along, and the working tree and index of the theo checkout are not touched (no rebase, no stash).
    """
    expected_sha = str(meta["sha256"]).lower()
    if not bundle_path.exists() or file_sha256(bundle_path) != expected_sha:
        raise RuntimeError(f"{bundle_path} does not match the release meta (sha256 {expected_sha[:16]}...); rebuild first.")
    remote, merge = pages_target(theo_dir)
    remote_ref = f"refs/remotes/{remote}/{merge[len('refs/heads/'):]}"
    blob = git(theo_dir, "hash-object", "-w", "--no-filters", str(bundle_path)).stdout.strip()
    msg = f"Update {BUNDLE_NAME} ({label})"
    for attempt in range(1, PUSH_ATTEMPTS + 1):
        fetch = git(theo_dir, "fetch", "--quiet", remote, check=False, timeout=120)
        if fetch.returncode != 0:
            raise RuntimeError(f"git fetch {remote} failed in {theo_dir}: {(fetch.stderr or fetch.stdout).strip()}")
        base = git(theo_dir, "rev-parse", "--verify", f"{remote_ref}^{{commit}}").stdout.strip()
        current = git(theo_dir, "rev-parse", "--verify", "--quiet", f"{base}:{BUNDLE_NAME}", check=False).stdout.strip()
        if current == blob:
            print(f"[OK] origin already has this {BUNDLE_NAME}")
            break
        if current:
            # Never roll the fleet back: a stale --publish-only, or a retry after another PC published,
            # must not replace a newer bundle on Pages.
            live_built_at = bundle_built_at(git(theo_dir, "cat-file", "blob", current, raw=True).stdout)
            if live_built_at is not None and live_built_at >= int(meta["builtAt"]):
                raise SystemExit(
                    f"[REFUSED] origin already serves a bundle built at {live_built_at}, not older than this one "
                    f"({int(meta['builtAt'])}); not rolling the fleet back. Rebuild from current code to publish."
                )
        with tempfile.TemporaryDirectory() as td:
            idx_env = dict(GIT_ENV, GIT_INDEX_FILE=str(pathlib.Path(td) / "index"))
            git(theo_dir, "read-tree", base, env=idx_env)
            git(theo_dir, "update-index", "--add", "--cacheinfo", f"100644,{blob},{BUNDLE_NAME}", env=idx_env)
            tree = git(theo_dir, "write-tree", env=idx_env).stdout.strip()
        commit = git(theo_dir, "commit-tree", tree, "-p", base, "-m", msg).stdout.strip()
        push = git(theo_dir, "push", "--porcelain", remote, f"{commit}:{merge}", check=False, timeout=180)
        if push.returncode == 0:
            print(f"[OK] Pushed {BUNDLE_NAME} to {remote} as {commit[:7]}: {msg}")
            break
        detail = f"{push.stdout}\n{push.stderr}".strip()
        if any(k in detail for k in ("[rejected]", "non-fast-forward", "fetch first", "stale info")):
            print(f"[INFO] Push rejected because {remote} moved on (attempt {attempt}/{PUSH_ATTEMPTS}); retrying on the new tip")
            continue
        raise RuntimeError(f"git push of {BUNDLE_NAME} failed (not a fast-forward race): {detail}")
    else:
        raise RuntimeError(
            f"git push of {BUNDLE_NAME} was rejected {PUSH_ATTEMPTS} times because {remote} kept moving; "
            "rerun build_vsix.py --publish-only."
        )
    fast_forward_local_checkout(theo_dir, remote_ref)


def fast_forward_local_checkout(theo_dir: pathlib.Path, remote_ref: str) -> None:
    """Best effort: bring the theo checkout up to origin when it has no local commits. git refuses
    on its own when another session's uncommitted edits would be overwritten; that is fine."""
    git(theo_dir, "fetch", "--quiet", check=False, timeout=120)
    if git(theo_dir, "merge-base", "--is-ancestor", "HEAD", remote_ref, check=False).returncode != 0:
        print(f"[INFO] {theo_dir} has local commits; left as is (origin already has the bundle)")
        return
    ff = git(theo_dir, "merge", "--ff-only", "--quiet", remote_ref, check=False)
    if ff.returncode == 0:
        print(f"[OK] Fast-forwarded {theo_dir} to origin")
    else:
        print(f"[INFO] {theo_dir} left behind origin (local edits in the way); origin already has the bundle")


def publish_hub_release(meta: dict) -> None:
    creds = load_effective_theo_creds()
    edge_access_key = str(creds.get("edgeAccessKey") or "").strip()
    cloud_key = str(creds.get("cloudKey") or "").strip()
    store_url = str(creds.get("cloudUrl") or "").strip()
    if not edge_access_key or not cloud_key or not store_url:
        raise RuntimeError(
            "Missing ~/.theo/credentials.json (edgeAccessKey / derived cloudKey / store URL) for publishing hub_release."
        )
    if cloud_key == edge_access_key:
        raise RuntimeError(
            "Refusing to send raw edgeAccessKey over the wire as store key; expected derived cloudKey."
        )

    expected_sha = str(meta["sha256"]).lower()
    target_url = str(meta["url"]).strip()
    print(f"[INFO] Waiting for {target_url} to serve sha256={expected_sha[:16]}...")
    started = time.time()
    deadline = started + (10 if args.allow_loopback_test else PAGES_WAIT_SECONDS)
    next_progress = started + 30
    matched = False
    last_sha = ""
    while time.time() < deadline:
        if time.time() >= next_progress:
            print(f"[INFO] Still waiting for GitHub Pages ({int(time.time() - started)} s, last saw {last_sha[:16]})")
            next_progress += 30
        try:
            req = urllib.request.Request(
                target_url,
                headers={
                    "User-Agent": "THEO-Bundle-Publisher/1.0",
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                },
            )
            with urllib.request.urlopen(req, timeout=20) as resp:
                if resp.status == 200:
                    data = resp.read()
                    got_sha = hashlib.sha256(data).hexdigest().lower()
                    last_sha = got_sha
                    if got_sha == expected_sha:
                        matched = True
                        break
        except Exception as err:
            last_sha = f"err:{err}"
        time.sleep(0.25 if args.allow_loopback_test else 4)

    if not matched:
        raise RuntimeError(
            f"Timed out waiting for {target_url} to match sha256 {expected_sha} (last saw {last_sha}). "
            "Check that the theo repo commit with the new bundle reached origin and that the GitHub Pages "
            "deploy finished, then run build_vsix.py --publish-only."
        )

    rec = {
        "version": str(meta["version"]),
        "builtAt": int(meta["builtAt"]),
        "size": int(meta["size"]),
        "sha256": expected_sha,
        "url": target_url,
        "publishedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    rec["sig"] = sign_release_record(rec, edge_access_key)

    node_exe, node_env = find_node_exe()
    subprocess.run(
        [
            node_exe,
            "-e",
            (
                "const bu=require(process.argv[1]);"
                "const rec=JSON.parse(process.argv[2]);"
                "const key=process.argv[3];"
                "const allowLoop=process.argv[4]==='1';"
                "const v=bu.verifyHubReleaseRecord(rec,key,{allowLoopbackTest:allowLoop});"
                "if(!v.ok){throw new Error('Self-verify failed: '+v.reason);}"
            ),
            str(root / "bundle-updater.js"),
            json.dumps(rec),
            edge_access_key,
            "1" if args.allow_loopback_test else "0",
        ],
        env=node_env,
        check=True,
    )

    payload = json.dumps(
        {
            "key": cloud_key,
            "op": "patch",
            "ackOnly": True,
            "patch": {"hub_release": rec},
        }
    ).encode("utf-8")
    store_req = urllib.request.Request(
        store_url,
        data=payload,
        method="POST",
        headers={
            "Content-Type": "text/plain;charset=UTF-8",
            "User-Agent": "THEO-Bundle-Publisher/1.0",
        },
    )
    with urllib.request.urlopen(store_req, timeout=20) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
        parsed = json.loads(raw) if raw else {}
        if not parsed.get("ok"):
            raise RuntimeError(f"Store rejected hub_release patch: {raw}")
    print(f"[OK] Published signed hub_release ({rec['version']} @ {rec['builtAt']}) to THEO Store")


will_publish = not args.no_publish_store and not args.publish_only
if args.pages_repo:
    pages_repo = pathlib.Path(args.pages_repo).resolve()
elif args.bundle_url == DEFAULT_BUNDLE_URL:
    pages_repo = root.parent / "theo"
else:
    pages_repo = None
pushes_to_pages = not isolated_out and pages_repo is not None
dirty_build = False
DIRTY_HINT = (
    "Commit and push your own changes (leave other sessions' edits to them), then rerun. "
    "Use --no-publish-store for a local-only build, or --allow-dirty to publish anyway."
)

if not isolated_out:
    # dist/ (release meta + zip) is shared by every session on this PC: one run at a time.
    acquire_build_lock(dist_dir)

if not args.publish_only and not isolated_out:
    hub_problems = hub_tree_problems()
    if hub_problems and will_publish and not args.allow_dirty:
        refuse("Not publishing theo-hub to the fleet", hub_problems, DIRTY_HINT)
    dirty_build = bool(hub_problems)
    if hub_problems and not will_publish:
        print(
            "[WARN] Local-only build from a tree that is not committed and pushed; marked not publishable and "
            "not copied to Admin, so it cannot ship by accident:\n  - " + "\n  - ".join(hub_problems)
        )
    elif hub_problems:
        print("[WARN] --allow-dirty: publishing despite:\n  - " + "\n  - ".join(hub_problems))
    if will_publish and pushes_to_pages:
        pages_problems = pages_repo_problems(pages_repo)
        if pages_problems:
            refuse("Cannot push the bundle to GitHub Pages", pages_problems, "Fix the theo repo, then rerun.")

if not args.publish_only:
    manifest = f"""<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011" xmlns:d="http://schemas.microsoft.com/developer/vsx-schema-design/2011">
  <Metadata>
    <Identity Language="en-US" Id="{pkg['name']}" Version="{version}" Publisher="{pkg['publisher']}" />
    <DisplayName>{pkg['displayName']}</DisplayName>
    <Description xml:space="preserve">{pkg['description']}</Description>
    <Tags>antigravity,claude,gemini,anthropic,google,sessions</Tags>
    <Categories>Other</Categories>
    <GalleryFlags>Public</GalleryFlags>
    <Properties>
      <Property Id="Microsoft.VisualStudio.Code.Engine" Value="{pkg['engines']['vscode']}" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionDependencies" Value="{','.join(pkg.get('extensionDependencies', []))}" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionPack" Value="" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionKind" Value="ui,workspace" />
      <Property Id="Microsoft.VisualStudio.Code.LocalizedLanguages" Value="" />
    </Properties>
    <License>extension/README.md</License>
    <Icon>extension/resources/icon.png</Icon>
  </Metadata>
  <Installation><InstallationTarget Id="Microsoft.VisualStudio.Code"/></Installation>
  <Dependencies/>
  <Assets>
    <Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Content.Details" Path="extension/README.md" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Icons.Default" Path="extension/resources/icon.png" Addressable="true" />
  </Assets>
</PackageManifest>"""

    ctypes = """<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension=".json" ContentType="application/json"/>
  <Default Extension=".js" ContentType="application/javascript"/>
  <Default Extension=".cjs" ContentType="application/javascript"/>
  <Default Extension=".md" ContentType="text/markdown"/>
  <Default Extension=".svg" ContentType="image/svg+xml"/>
  <Default Extension=".png" ContentType="image/png"/>
  <Default Extension=".ico" ContentType="image/x-icon"/>
  <Default Extension=".cs" ContentType="text/plain"/>
  <Default Extension=".ps1" ContentType="text/plain"/>
  <Default Extension=".html" ContentType="text/html"/>
  <Default Extension=".css" ContentType="text/css"/>
  <Default Extension=".vsixmanifest" ContentType="text/xml"/>
</Types>"""

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("extension.vsixmanifest", manifest)
        z.writestr("[Content_Types].xml", ctypes)
        for f in files:
            p = root / f
            if p.exists():
                z.write(p, "extension/" + f)

    print(out)

    built_at_ms = int(time.time() * 1000)
    bundle_files = BUNDLE_FILES
    # Read every bundled file exactly once: the bytes that are hashed are the bytes that are zipped.
    manifest_files_map = {}
    bundle_payload = {}
    for bf in bundle_files:
        bp = root / bf
        if bp.exists():
            data = bp.read_bytes()
            info = zipfile.ZipInfo.from_file(bp, bf)
            info.compress_type = zipfile.ZIP_DEFLATED
            bundle_payload[bf] = (info, data)
            manifest_files_map[bf] = hashlib.sha256(data).hexdigest().lower()

    bundle_manifest_json = json.dumps(
        {
            "formatVersion": 1,
            "version": version,
            "builtAt": built_at_ms,
            "files": manifest_files_map,
        },
        indent=2,
        sort_keys=True,
    )

    dist_bundle_zip = dist_dir / "theo-hub-bundle.zip"
    with zipfile.ZipFile(dist_bundle_zip, "w", zipfile.ZIP_DEFLATED) as bz:
        for bf, (info, data) in bundle_payload.items():
            bz.writestr(info, data)
        bz.writestr(".theo-bundle-manifest.json", bundle_manifest_json)

    node_exe, node_env = find_node_exe()
    subprocess.run(
        [
            node_exe,
            "-e",
            (
                "const fs=require('fs'),bu=require(process.argv[1]);"
                "const buf=fs.readFileSync(process.argv[2]);"
                "const out=bu.extractAndVerifyBundleZip(buf,Number(process.argv[3]));"
                "console.log(`[OK] Verified bundle archive (${out.files.size} files, builtAt=${out.manifest.builtAt})`);"
            ),
            str(root / "bundle-updater.js"),
            str(dist_bundle_zip),
            str(built_at_ms),
        ],
        env=node_env,
        check=True,
    )

    bundle_bytes = dist_bundle_zip.read_bytes()
    bundle_sha256 = hashlib.sha256(bundle_bytes).hexdigest().lower()

    if not isolated_out and not dirty_build:
        drift = bundle_drift_problems(manifest_files_map)
        if drift:
            dirty_build = True
            if will_publish and not args.allow_dirty:
                refuse("Not publishing theo-hub to the fleet", drift, DIRTY_HINT)
            print("[WARN] Files changed during the build; marked not publishable:\n  - " + "\n  - ".join(drift))

    # The Pages repo is never written here: the bundle reaches it only as a pushed commit.
    # Admin (new-PC bootstrap) gets a clean local build now, and a publish only once its push succeeded.
    def copy_to_admin() -> None:
        admin_dir = pathlib.Path.home() / "bhfirms" / "memory" / "Admin"
        if not admin_dir.is_dir():
            admin_dir = pathlib.Path.home() / "OneDrive - BHFIRMS" / "System" / "System" / "THEO" / "Admin"
        if admin_dir.is_dir():
            admin_bundle = admin_dir / "theo-hub-bundle.zip"
            shutil.copy2(dist_bundle_zip, admin_bundle)
            print(admin_bundle)

    admin_ok = not isolated_out and (not dirty_build or (will_publish and args.allow_dirty))
    if admin_ok and not will_publish:
        copy_to_admin()

    meta = {
        "version": version,
        "builtAt": built_at_ms,
        "size": len(bundle_bytes),
        "sha256": bundle_sha256,
        "url": args.bundle_url,
        # --publish-only trusts this flag: a dirty local build can never be published later by accident.
        "publishable": isolated_out or not dirty_build or (will_publish and args.allow_dirty),
    }
    if not isolated_out and is_git_repo(root):
        hub_label = git(root, "log", "-1", "--format=%h: %s").stdout.strip()
        if len(hub_label) > 90:
            hub_label = hub_label[:87].rstrip() + "..."
        meta["hubCommit"] = hub_label + (" + uncommitted edits" if dirty_build else "")
    release_meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    if not isolated_out:
        stamp_obj = {
            "version": version,
            "builtAt": built_at_ms,
            "sha256": bundle_sha256,
            "appliedAt": built_at_ms,
        }
        stamp_path = pathlib.Path.home() / ".claude" / ".theo-hub-bundle-stamp.json"
        stamp_path.parent.mkdir(parents=True, exist_ok=True)
        stamp_path.write_text(json.dumps(stamp_obj, indent=2), encoding="utf-8")

    if will_publish:
        if pushes_to_pages:
            push_bundle_to_pages(dist_bundle_zip, meta, pages_repo, meta.get("hubCommit") or f"theo-hub {version}")
        if admin_ok:
            copy_to_admin()
        publish_hub_release(meta)
else:
    # --publish-only: publish what the last build in this dist folder produced, never anything else.
    if not release_meta_path.exists():
        raise RuntimeError(f"Missing {release_meta_path}; run build_vsix.py --no-publish-store first.")
    meta = json.loads(release_meta_path.read_text(encoding="utf-8"))
    if args.bundle_url != DEFAULT_BUNDLE_URL or not meta.get("url"):
        meta["url"] = args.bundle_url
    if not isolated_out and meta.get("publishable") is not True and not args.allow_dirty:
        reason = (
            "was written by an older build_vsix.py that did not record whether the tree was clean"
            if "publishable" not in meta
            else f"comes from a build that was not marked publishable ({meta.get('hubCommit', 'unknown source')})"
        )
        refuse(
            "Not publishing the last build",
            [f"{release_meta_path} {reason}"],
            "Rebuild from a committed and pushed tree with python build_vsix.py, or pass --allow-dirty.",
        )
    # Push to Pages only a build made for the Pages URL (or when a Pages repo is named explicitly).
    pushes_to_pages = pushes_to_pages and (bool(args.pages_repo) or str(meta.get("url")) == DEFAULT_BUNDLE_URL)
    dist_bundle_zip = dist_dir / BUNDLE_NAME
    if not dist_bundle_zip.exists() or file_sha256(dist_bundle_zip) != str(meta.get("sha256", "")).lower():
        refuse(
            "Not publishing the last build",
            [f"{dist_bundle_zip} does not match {release_meta_path} (another build overwrote one of them)"],
            "Rebuild with python build_vsix.py.",
        )
    if pushes_to_pages:
        pages_problems = pages_repo_problems(pages_repo)
        if pages_problems:
            refuse("Cannot push the bundle to GitHub Pages", pages_problems, "Fix the theo repo, then rerun.")
        push_bundle_to_pages(dist_bundle_zip, meta, pages_repo, meta.get("hubCommit") or f"theo-hub {meta['version']}")
    publish_hub_release(meta)
