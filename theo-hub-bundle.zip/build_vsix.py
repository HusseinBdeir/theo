"""Package this folder as a VSIX + signed self-updating theo-hub-bundle.zip without vsce."""
import argparse
import hashlib
import hmac
import json
import os
import pathlib
import shutil
import subprocess
import time
import urllib.request
import zipfile

DEFAULT_BUNDLE_URL = "https://husseinbdeir.github.io/theo/theo-hub-bundle.zip"

parser = argparse.ArgumentParser(description="Build THEO Hub VSIX + signed self-updating bundle.")
parser.add_argument(
    "--no-publish-store",
    action="store_true",
    help="Build VSIX + theo-hub-bundle.zip + release meta without patching hub_release in the store.",
)
parser.add_argument(
    "--publish-only",
    action="store_true",
    help="Verify live bundle URL matches dist/theo-hub-release-meta.json and publish signed hub_release to store.",
)
parser.add_argument(
    "--bundle-url",
    default=DEFAULT_BUNDLE_URL,
    help="HTTPS URL where theo-hub-bundle.zip is served.",
)
parser.add_argument(
    "--out-dir",
    default="",
    help="Optional isolated output directory (for tests; skips copying to ../theo, Admin, and ~/.claude).",
)
parser.add_argument(
    "--allow-loopback-test",
    action="store_true",
    help="Allow loopback HTTP URLs during automated smoke testing.",
)
args = parser.parse_args()

root = pathlib.Path(__file__).parent
pkg = json.loads((root / "package.json").read_text(encoding="utf-8"))
version = pkg["version"]
isolated_out = bool(args.out_dir)
dist_dir = pathlib.Path(args.out_dir).resolve() if isolated_out else (root / "dist")
dist_dir.mkdir(parents=True, exist_ok=True)
out = dist_dir / f"{pkg['name']}-{version}.vsix"
release_meta_path = dist_dir / "theo-hub-release-meta.json"

files = [
    "package.json",
    "extension.js",
    "accounts.js",
    "session-tabs.js",
    "hub.js",
    "data.js",
    "store.js",
    "state.js",
    "bridge.js",
    "remote.js",
    "device-identity.js",
    "bundle-updater.js",
    "ws-server.js",
    "direct-runner.js",
    "edge-relay-client.js",
    "README.md",
    "activity.js",
    "desktop-notify.js",
    "desktop-launcher.js",
    "compat/antigravity-hub-bridge.cjs",
    "compat/antigravity-tab-state.cjs",
    "compat/antigravity-context-window.cjs",
    "compat/claude-hub-bridge.cjs",
    "compat/claude-webview-patches.cjs",
    "compat/excel-preview.cjs",
    "resources/icon.png",
    "resources/theo.ico",
    "resources/TheoLauncher.cs",
    "resources/logo.svg",
    "resources/antigravity-logo-color.svg",
    "resources/antigravity-logo-done.svg",
    "resources/antigravity-logo-pending.svg",
    "resources/claude-logo.svg",
    "resources/claude-logo-done.svg",
    "resources/claude-logo-pending.svg",
    "resources/hub.html",
    "resources/hub.css",
    "resources/hub.js",
    "scripts/relay_keepalive.cjs",
    "scripts/relay_keepalive_start.ps1",
    "scripts/theo_agent.cjs",
    "scripts/theo_agent_start.ps1",
    "scripts/install_desktop_shortcut.ps1",
]


def find_node_exe() -> tuple[str, dict]:
    portable_node = pathlib.Path.home() / ".local" / "node" / "node.exe"
    env = os.environ.copy()
    if portable_node.exists():
        return str(portable_node), env
    found = shutil.which("node")
    if found:
        return found, env
    for cand in (
        pathlib.Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / "Code.exe",
        pathlib.Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "Microsoft VS Code" / "Code.exe",
    ):
        if cand.exists():
            env["ELECTRON_RUN_AS_NODE"] = "1"
            return str(cand), env
    raise RuntimeError("Node executable not found for bundle verification.")


def load_theo_creds() -> dict:
    cred_path = pathlib.Path.home() / ".theo" / "credentials.json"
    if not cred_path.exists():
        return {}
    try:
        return json.loads(cred_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def sign_release_record(rec: dict, edge_access_key: str) -> str:
    clean_key = edge_access_key.strip()
    if len(clean_key) < 24:
        raise ValueError("edgeAccessKey too short to sign hub_release")
    sign_key = hashlib.sha256(f"theo-bundle-sign-v1:{clean_key}".encode("utf-8")).digest()
    canonical = "|".join(
        [
            "theo-hub-bundle-v1",
            str(rec["version"]).strip(),
            str(int(rec["builtAt"])),
            str(rec["sha256"]).strip().lower(),
            str(rec["url"]).strip(),
        ]
    )
    return hmac.new(sign_key, canonical.encode("utf-8"), hashlib.sha256).hexdigest()


def load_effective_theo_creds() -> dict:
    node_exe, node_env = find_node_exe()
    res = subprocess.run(
        [
            node_exe,
            "-e",
            (
                "const d=require(process.argv[1]);"
                "const c=d.loadTheoCredentials();"
                "process.stdout.write(JSON.stringify({"
                "edgeAccessKey:c.edgeAccessKey||'',"
                "cloudUrl:c.cloudUrl||'',"
                "cloudKey:c.cloudKey||'',"
                "cloudSource:c.cloudSource||''"
                "}));"
            ),
            str(root / "device-identity.js"),
        ],
        env=node_env,
        capture_output=True,
        text=True,
        check=True,
    )
    return json.loads(res.stdout.strip() or "{}")


def publish_hub_release(meta: dict) -> None:
    creds = load_effective_theo_creds()
    edge_access_key = str(creds.get("edgeAccessKey") or "").strip()
    cloud_key = str(creds.get("cloudKey") or "").strip()
    store_url = str(creds.get("cloudUrl") or "").strip()
    if not edge_access_key or not cloud_key or not store_url:
        raise RuntimeError(
            "Missing ~/.theo/credentials.json (edgeAccessKey / derived cloudKey / store URL) for publishing hub_release."
        )
    if cloud_key == edge_access_key:
        raise RuntimeError(
            "Refusing to send raw edgeAccessKey over the wire as store key; expected derived cloudKey."
        )

    expected_sha = str(meta["sha256"]).lower()
    target_url = str(meta["url"]).strip()
    print(f"[INFO] Waiting for {target_url} to serve sha256={expected_sha[:16]}...")
    deadline = time.time() + (10 if args.allow_loopback_test else 120)
    matched = False
    last_sha = ""
    while time.time() < deadline:
        try:
            req = urllib.request.Request(
                target_url,
                headers={
                    "User-Agent": "THEO-Bundle-Publisher/1.0",
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                },
            )
            with urllib.request.urlopen(req, timeout=20) as resp:
                if resp.status == 200:
                    data = resp.read()
                    got_sha = hashlib.sha256(data).hexdigest().lower()
                    last_sha = got_sha
                    if got_sha == expected_sha:
                        matched = True
                        break
        except Exception as err:
            last_sha = f"err:{err}"
        time.sleep(0.25 if args.allow_loopback_test else 4)

    if not matched:
        raise RuntimeError(
            f"Timed out waiting for {target_url} to match sha256 {expected_sha} (last saw {last_sha})."
        )

    rec = {
        "version": str(meta["version"]),
        "builtAt": int(meta["builtAt"]),
        "size": int(meta["size"]),
        "sha256": expected_sha,
        "url": target_url,
        "publishedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    rec["sig"] = sign_release_record(rec, edge_access_key)

    node_exe, node_env = find_node_exe()
    subprocess.run(
        [
            node_exe,
            "-e",
            (
                "const bu=require(process.argv[1]);"
                "const rec=JSON.parse(process.argv[2]);"
                "const key=process.argv[3];"
                "const allowLoop=process.argv[4]==='1';"
                "const v=bu.verifyHubReleaseRecord(rec,key,{allowLoopbackTest:allowLoop});"
                "if(!v.ok){throw new Error('Self-verify failed: '+v.reason);}"
            ),
            str(root / "bundle-updater.js"),
            json.dumps(rec),
            edge_access_key,
            "1" if args.allow_loopback_test else "0",
        ],
        env=node_env,
        check=True,
    )

    payload = json.dumps(
        {
            "key": cloud_key,
            "op": "patch",
            "ackOnly": True,
            "patch": {"hub_release": rec},
        }
    ).encode("utf-8")
    store_req = urllib.request.Request(
        store_url,
        data=payload,
        method="POST",
        headers={
            "Content-Type": "text/plain;charset=UTF-8",
            "User-Agent": "THEO-Bundle-Publisher/1.0",
        },
    )
    with urllib.request.urlopen(store_req, timeout=20) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
        parsed = json.loads(raw) if raw else {}
        if not parsed.get("ok"):
            raise RuntimeError(f"Store rejected hub_release patch: {raw}")
    print(f"[OK] Published signed hub_release ({rec['version']} @ {rec['builtAt']}) to THEO Store")


if not args.publish_only:
    manifest = f"""<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011" xmlns:d="http://schemas.microsoft.com/developer/vsx-schema-design/2011">
  <Metadata>
    <Identity Language="en-US" Id="{pkg['name']}" Version="{version}" Publisher="{pkg['publisher']}" />
    <DisplayName>{pkg['displayName']}</DisplayName>
    <Description xml:space="preserve">{pkg['description']}</Description>
    <Tags>antigravity,claude,gemini,anthropic,google,sessions</Tags>
    <Categories>Other</Categories>
    <GalleryFlags>Public</GalleryFlags>
    <Properties>
      <Property Id="Microsoft.VisualStudio.Code.Engine" Value="{pkg['engines']['vscode']}" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionDependencies" Value="{','.join(pkg.get('extensionDependencies', []))}" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionPack" Value="" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionKind" Value="ui,workspace" />
      <Property Id="Microsoft.VisualStudio.Code.LocalizedLanguages" Value="" />
    </Properties>
    <License>extension/README.md</License>
    <Icon>extension/resources/icon.png</Icon>
  </Metadata>
  <Installation><InstallationTarget Id="Microsoft.VisualStudio.Code"/></Installation>
  <Dependencies/>
  <Assets>
    <Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Content.Details" Path="extension/README.md" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Icons.Default" Path="extension/resources/icon.png" Addressable="true" />
  </Assets>
</PackageManifest>"""

    ctypes = """<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension=".json" ContentType="application/json"/>
  <Default Extension=".js" ContentType="application/javascript"/>
  <Default Extension=".cjs" ContentType="application/javascript"/>
  <Default Extension=".md" ContentType="text/markdown"/>
  <Default Extension=".svg" ContentType="image/svg+xml"/>
  <Default Extension=".png" ContentType="image/png"/>
  <Default Extension=".ico" ContentType="image/x-icon"/>
  <Default Extension=".cs" ContentType="text/plain"/>
  <Default Extension=".ps1" ContentType="text/plain"/>
  <Default Extension=".html" ContentType="text/html"/>
  <Default Extension=".css" ContentType="text/css"/>
  <Default Extension=".vsixmanifest" ContentType="text/xml"/>
</Types>"""

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("extension.vsixmanifest", manifest)
        z.writestr("[Content_Types].xml", ctypes)
        for f in files:
            p = root / f
            if p.exists():
                z.write(p, "extension/" + f)

    print(out)

    built_at_ms = int(time.time() * 1000)
    bundle_files = sorted(
        set(
            files
            + [
                "install_local.py",
                "build_vsix.py",
                "test/smoke.test.cjs",
                "test/store.test.cjs",
                "cloudflare-relay/deploy_edge_relay.ps1",
                "cloudflare-relay/src/index.js",
                "cloudflare-relay/src/store.js",
                "cloudflare-relay/src/worker.js",
                "cloudflare-relay/wrangler.toml",
            ]
        )
    )
    manifest_files_map = {}
    for bf in bundle_files:
        bp = root / bf
        if bp.exists():
            manifest_files_map[bf] = hashlib.sha256(bp.read_bytes()).hexdigest().lower()

    bundle_manifest_json = json.dumps(
        {
            "formatVersion": 1,
            "version": version,
            "builtAt": built_at_ms,
            "files": manifest_files_map,
        },
        indent=2,
        sort_keys=True,
    )

    dist_bundle_zip = dist_dir / "theo-hub-bundle.zip"
    with zipfile.ZipFile(dist_bundle_zip, "w", zipfile.ZIP_DEFLATED) as bz:
        for bf in bundle_files:
            bp = root / bf
            if bp.exists():
                bz.write(bp, bf)
        bz.writestr(".theo-bundle-manifest.json", bundle_manifest_json)

    node_exe, node_env = find_node_exe()
    subprocess.run(
        [
            node_exe,
            "-e",
            (
                "const fs=require('fs'),bu=require(process.argv[1]);"
                "const buf=fs.readFileSync(process.argv[2]);"
                "const out=bu.extractAndVerifyBundleZip(buf,Number(process.argv[3]));"
                "console.log(`[OK] Verified bundle archive (${out.files.size} files, builtAt=${out.manifest.builtAt})`);"
            ),
            str(root / "bundle-updater.js"),
            str(dist_bundle_zip),
            str(built_at_ms),
        ],
        env=node_env,
        check=True,
    )

    bundle_bytes = dist_bundle_zip.read_bytes()
    bundle_sha256 = hashlib.sha256(bundle_bytes).hexdigest().lower()

    if not isolated_out:
        theo_pwa_dir = root.parent / "theo"
        if theo_pwa_dir.is_dir():
            pwa_bundle = theo_pwa_dir / "theo-hub-bundle.zip"
            shutil.copy2(dist_bundle_zip, pwa_bundle)
            print(pwa_bundle)

        admin_dir = pathlib.Path.home() / "OneDrive - BHFIRMS" / "System" / "System" / "THEO" / "Admin"
        if admin_dir.is_dir():
            admin_bundle = admin_dir / "theo-hub-bundle.zip"
            shutil.copy2(dist_bundle_zip, admin_bundle)
            print(admin_bundle)

    meta = {
        "version": version,
        "builtAt": built_at_ms,
        "size": len(bundle_bytes),
        "sha256": bundle_sha256,
        "url": args.bundle_url,
    }
    release_meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    if not isolated_out:
        stamp_obj = {
            "version": version,
            "builtAt": built_at_ms,
            "sha256": bundle_sha256,
            "appliedAt": built_at_ms,
        }
        stamp_path = pathlib.Path.home() / ".claude" / ".theo-hub-bundle-stamp.json"
        stamp_path.parent.mkdir(parents=True, exist_ok=True)
        stamp_path.write_text(json.dumps(stamp_obj, indent=2), encoding="utf-8")

    if not args.no_publish_store:
        publish_hub_release(meta)
else:
    if not release_meta_path.exists():
        raise RuntimeError(f"Missing {release_meta_path}; run build_vsix.py --no-publish-store first.")
    meta = json.loads(release_meta_path.read_text(encoding="utf-8"))
    if args.bundle_url != DEFAULT_BUNDLE_URL or not meta.get("url"):
        meta["url"] = args.bundle_url
    publish_hub_release(meta)
