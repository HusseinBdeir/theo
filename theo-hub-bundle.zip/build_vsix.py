"""Package this folder as a VSIX without vsce (a VSIX is a zip with a manifest)."""
import json
import pathlib
import zipfile

root = pathlib.Path(__file__).parent
pkg = json.loads((root / "package.json").read_text(encoding="utf-8"))
out = root / "dist" / f"{pkg['name']}-{pkg['version']}.vsix"
out.parent.mkdir(exist_ok=True)

files = [
    "package.json",
    "extension.js",
    "accounts.js",
    "session-tabs.js",
    "hub.js",
    "data.js",
    "store.js",
    "state.js",
    "bridge.js",
    "remote.js",
    "remote-relay.json",
    "README.md",
    "activity.js",
    "desktop-notify.js",
    "compat/antigravity-hub-bridge.cjs",
    "compat/antigravity-tab-state.cjs",
    "compat/antigravity-context-window.cjs",
    "compat/claude-hub-bridge.cjs",
    "compat/claude-webview-patches.cjs",
    "compat/excel-preview.cjs",
    "resources/icon.png",
    "resources/logo.svg",
    "resources/antigravity-logo-color.svg",
    "resources/antigravity-logo-done.svg",
    "resources/antigravity-logo-pending.svg",
    "resources/claude-logo.svg",
    "resources/claude-logo-done.svg",
    "resources/claude-logo-pending.svg",
    "resources/hub.html",
    "resources/hub.css",
    "resources/hub.js",
]

manifest = f"""<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011" xmlns:d="http://schemas.microsoft.com/developer/vsx-schema-design/2011">
  <Metadata>
    <Identity Language="en-US" Id="{pkg['name']}" Version="{pkg['version']}" Publisher="{pkg['publisher']}" />
    <DisplayName>{pkg['displayName']}</DisplayName>
    <Description xml:space="preserve">{pkg['description']}</Description>
    <Tags>antigravity,claude,gemini,anthropic,google,sessions</Tags>
    <Categories>Other</Categories>
    <GalleryFlags>Public</GalleryFlags>
    <Properties>
      <Property Id="Microsoft.VisualStudio.Code.Engine" Value="{pkg['engines']['vscode']}" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionDependencies" Value="{','.join(pkg.get('extensionDependencies', []))}" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionPack" Value="" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionKind" Value="ui,workspace" />
      <Property Id="Microsoft.VisualStudio.Code.LocalizedLanguages" Value="" />
    </Properties>
    <License>extension/README.md</License>
    <Icon>extension/resources/icon.png</Icon>
  </Metadata>
  <Installation><InstallationTarget Id="Microsoft.VisualStudio.Code"/></Installation>
  <Dependencies/>
  <Assets>
    <Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Content.Details" Path="extension/README.md" Addressable="true" />
    <Asset Type="Microsoft.VisualStudio.Services.Icons.Default" Path="extension/resources/icon.png" Addressable="true" />
  </Assets>
</PackageManifest>"""

ctypes = """<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension=".json" ContentType="application/json"/>
  <Default Extension=".js" ContentType="application/javascript"/>
  <Default Extension=".cjs" ContentType="application/javascript"/>
  <Default Extension=".md" ContentType="text/markdown"/>
  <Default Extension=".svg" ContentType="image/svg+xml"/>
  <Default Extension=".png" ContentType="image/png"/>
  <Default Extension=".html" ContentType="text/html"/>
  <Default Extension=".css" ContentType="text/css"/>
  <Default Extension=".vsixmanifest" ContentType="text/xml"/>
</Types>"""

with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("extension.vsixmanifest", manifest)
    z.writestr("[Content_Types].xml", ctypes)
    for f in files:
        z.write(root / f, "extension/" + f)

print(out)
