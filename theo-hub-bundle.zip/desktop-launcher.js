'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { loadTheoCredentials } = require('./device-identity');

const DEFAULT_FALLBACK_PWA_URL = 'https://husseinbdeir.github.io/theo/';
const DEFAULT_SHORTCUT_HOTKEY = 'Ctrl+Alt+T';
const SHORTCUT_NAME = 'THEO.lnk';
const LEGACY_SHORTCUT_NAMES = ['THEO Remote.lnk', 'THEO Studio.lnk'];
const SHORTCUT_DESCRIPTION = 'THEO - AI Session Workbench';
const SHORTCUT_STATE_VERSION = 1;

function validateIcoBuffer(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 22) {
    return { valid: false, frameCount: 0, reason: 'Buffer too small for ICO header' };
  }
  const reserved = buf.readUInt16LE(0);
  const type = buf.readUInt16LE(2);
  const count = buf.readUInt16LE(4);
  if (reserved !== 0 || type !== 1 || count < 1 || count > 32) {
    return { valid: false, frameCount: 0, reason: 'Invalid ICO magic bytes or frame count' };
  }
  const minDirSize = 6 + count * 16;
  if (buf.length < minDirSize) {
    return { valid: false, frameCount: 0, reason: 'Truncated ICO directory entries' };
  }
  for (let i = 0; i < count; i++) {
    const entryOffset = 6 + i * 16;
    const bytesInRes = buf.readUInt32LE(entryOffset + 8);
    const imageOffset = buf.readUInt32LE(entryOffset + 12);
    if (bytesInRes < 8 || imageOffset < minDirSize || imageOffset + bytesInRes > buf.length) {
      return { valid: false, frameCount: 0, reason: `Out-of-bounds ICO frame at index ${i}` };
    }
  }
  return { valid: true, frameCount: count, reason: '' };
}

function validateDesktopAppUrl(rawUrl) {
  if (typeof rawUrl !== 'string') return null;
  const trimmed = rawUrl.trim();
  if (!trimmed || trimmed.length > 512) return null;
  if (/[\x00-\x20\x7f"'`$\\]/.test(trimmed)) return null;

  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return null;
  }

  if (parsed.username || parsed.password) return null;
  // Never allow #pair= or query/hash secrets in persistent desktop shortcut CLI args
  if (/pair=|cloudKey|edgeAccessKey|token=/i.test(parsed.search + parsed.hash)) {
    return null;
  }

  if (parsed.protocol === 'https:') {
    if (!parsed.hostname || parsed.hostname.includes('..')) return null;
    return parsed.toString();
  }

  if (parsed.protocol === 'http:') {
    const host = parsed.hostname.toLowerCase();
    if (host !== '127.0.0.1' && host !== 'localhost') {
      return null;
    }
    const portNum = parsed.port ? Number(parsed.port) : 80;
    if (!Number.isInteger(portNum) || portNum < 1 || portNum > 65535) {
      return null;
    }
    return parsed.toString();
  }

  return null;
}

function normalizeShortcutHotkey(rawHotkey) {
  if (rawHotkey === '' || rawHotkey === null || rawHotkey === false) return '';
  if (typeof rawHotkey === 'undefined') return DEFAULT_SHORTCUT_HOTKEY;
  if (typeof rawHotkey !== 'string') return null;
  const trimmed = rawHotkey.trim();
  if (!trimmed || /^none$/i.test(trimmed)) return '';
  if (/[\x00-\x1f\x7f"'`$;|&<>]/.test(trimmed)) return null;

  const parts = trimmed.split('+').map((p) => p.trim()).filter(Boolean);
  if (parts.length === 0 || parts.length !== trimmed.split('+').length) return null;

  if (parts.length === 1) {
    const fnMatch = parts[0].match(/^F([1-9]|1[0-2])$/i);
    return fnMatch ? `F${fnMatch[1]}` : null;
  }

  const keyPart = parts[parts.length - 1];
  const modParts = parts.slice(0, -1);
  let hasCtrl = false;
  let hasAlt = false;
  let hasShift = false;

  for (const mod of modParts) {
    if (/^(ctrl|control)$/i.test(mod)) {
      if (hasCtrl) return null;
      hasCtrl = true;
    } else if (/^alt$/i.test(mod)) {
      if (hasAlt) return null;
      hasAlt = true;
    } else if (/^shift$/i.test(mod)) {
      if (hasShift) return null;
      hasShift = true;
    } else {
      return null;
    }
  }

  const modCount = (hasCtrl ? 1 : 0) + (hasAlt ? 1 : 0) + (hasShift ? 1 : 0);
  let normalizedKey = '';
  if (/^[A-Za-z0-9]$/.test(keyPart)) {
    if (modCount < 2) return null;
    normalizedKey = keyPart.toUpperCase();
  } else if (/^F([1-9]|1[0-2])$/i.test(keyPart)) {
    if (modCount < 1) return null;
    normalizedKey = keyPart.toUpperCase();
  } else {
    return null;
  }

  const orderedMods = [];
  if (hasCtrl) orderedMods.push('Ctrl');
  if (hasAlt) orderedMods.push('Alt');
  if (hasShift) orderedMods.push('Shift');
  return `${orderedMods.join('+')}+${normalizedKey}`;
}

function resolveDesktopLaunchUrl(options = {}) {
  const {
    customUrl = '',
    pwaRoot = path.join(os.homedir(), 'bhfirms', 'theo'),
    port = 0,
    fallbackUrl = DEFAULT_FALLBACK_PWA_URL,
    existsSync = fs.existsSync
  } = options;

  if (customUrl) {
    const validatedCustom = validateDesktopAppUrl(customUrl);
    if (!validatedCustom) {
      throw new Error(`Invalid or unsafe desktop launch URL: ${customUrl}`);
    }
    return validatedCustom;
  }

  let effectivePort = Number(port || 0);
  if (!Number.isInteger(effectivePort) || effectivePort < 1 || effectivePort > 65535) {
    try {
      const creds = loadTheoCredentials();
      const credPort = Number(creds?.port || 4318);
      effectivePort = Number.isInteger(credPort) && credPort >= 1 && credPort <= 65535 ? credPort : 4318;
    } catch {
      effectivePort = 4318;
    }
  }

  const localIndex = pwaRoot ? path.join(pwaRoot, 'index.html') : '';
  if (localIndex && existsSync(localIndex)) {
    const loopbackUrl = validateDesktopAppUrl(`http://127.0.0.1:${effectivePort}/`);
    if (loopbackUrl) return loopbackUrl;
  }

  const safeFallback = validateDesktopAppUrl(fallbackUrl) || DEFAULT_FALLBACK_PWA_URL;
  return safeFallback;
}

function findDesktopBrowserExecutable(options = {}) {
  const {
    env = process.env,
    customBrowserPath = '',
    existsSync = fs.existsSync,
    statSync = fs.statSync
  } = options;

  const isSafeExe = (cand) => {
    if (!cand || typeof cand !== 'string') return false;
    const trimmed = cand.trim();
    if (!trimmed || /[\x00-\x1f\x7f"'`$;|&<>]/.test(trimmed)) return false;
    if (!/\.exe$/i.test(trimmed)) return false;
    try {
      return existsSync(trimmed) && statSync(trimmed).isFile();
    } catch {
      return false;
    }
  };

  if (customBrowserPath) {
    if (!isSafeExe(customBrowserPath)) {
      throw new Error(`Invalid browser executable path: ${customBrowserPath}`);
    }
    return customBrowserPath.trim();
  }

  const progFilesX86 = env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const progFiles = env.ProgramFiles || 'C:\\Program Files';
  const localAppData = env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');

  const candidates = [
    path.join(progFilesX86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(progFiles, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(localAppData, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(progFiles, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(progFilesX86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(localAppData, 'Google', 'Chrome', 'Application', 'chrome.exe')
  ];

  for (const cand of candidates) {
    if (isSafeExe(cand)) return cand;
  }
  return '';
}

function writeFileAtomicSync(targetPath, dataBufferOrString) {
  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const tmpPath = `${targetPath}.tmp-${process.pid}-${Date.now()}`;
  try {
    fs.writeFileSync(tmpPath, dataBufferOrString);
    fs.renameSync(tmpPath, targetPath);
  } finally {
    if (fs.existsSync(tmpPath)) {
      try {
        fs.unlinkSync(tmpPath);
      } catch {}
    }
  }
}

function ensureStableDesktopIcon(options = {}) {
  const {
    hubRoot = __dirname,
    homeDir = os.homedir()
  } = options;

  const srcIco = path.join(hubRoot, 'resources', 'theo.ico');
  if (!fs.existsSync(srcIco)) {
    throw new Error(`Missing source icon at ${srcIco}`);
  }
  const srcBytes = fs.readFileSync(srcIco);
  const check = validateIcoBuffer(srcBytes);
  if (!check.valid) {
    throw new Error(`Invalid source theo.ico (${check.reason})`);
  }

  const theoDir = path.join(homeDir, '.theo');
  const dstIco = path.join(theoDir, 'theo.ico');
  let needsWrite = true;
  if (fs.existsSync(dstIco)) {
    try {
      const existingBytes = fs.readFileSync(dstIco);
      if (existingBytes.equals(srcBytes)) {
        needsWrite = false;
      }
    } catch {}
  }

  if (needsWrite) {
    writeFileAtomicSync(dstIco, srcBytes);
  }
  return {
    iconPath: dstIco,
    iconLocation: `${dstIco},0`,
    frameCount: check.frameCount,
    updated: needsWrite
  };
}

function buildBrowserAppArguments(targetUrl) {
  const safeUrl = validateDesktopAppUrl(targetUrl);
  if (!safeUrl) {
    throw new Error(`Refusing to build browser --app arguments for invalid URL: ${targetUrl}`);
  }
  return `--app="${safeUrl}"`;
}

function resolveWindowsSpecialFolders() {
  try {
    const psCmd =
      '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; ' +
      '@{ desktop = [Environment]::GetFolderPath("Desktop"); programs = [Environment]::GetFolderPath("Programs") } | ConvertTo-Json -Compress';
    const res = spawnSync(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psCmd],
      { encoding: 'utf8', timeout: 8000, windowsHide: true }
    );
    if (res.status === 0 && res.stdout) {
      const parsed = JSON.parse(res.stdout.trim());
      if (parsed && parsed.desktop && parsed.programs) {
        return {
          desktopDir: String(parsed.desktop).trim(),
          programsDir: String(parsed.programs).trim()
        };
      }
    }
  } catch {}
  return {
    desktopDir: path.join(os.homedir(), 'Desktop'),
    programsDir: path.join(
      process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'),
      'Microsoft',
      'Windows',
      'Start Menu',
      'Programs'
    )
  };
}

function assertNotQuarantinedWithoutSandbox(desktopDir, programsDir) {
  const isTest =
    process.env.THEO_SMOKE_TEST === '1' ||
    process.env.THEO_HEADLESS_TEST === '1';
  if (!isTest) return;

  if (!desktopDir || !programsDir) {
    throw new Error(
      'Quarantine violation: THEO_SMOKE_TEST=1 requires explicit sandbox desktopDir and programsDir'
    );
  }
  const tmpRoot = path.resolve(os.tmpdir()).toLowerCase();
  const dNorm = path.resolve(desktopDir).toLowerCase();
  const pNorm = path.resolve(programsDir).toLowerCase();
  if (!dNorm.startsWith(tmpRoot) || !pNorm.startsWith(tmpRoot)) {
    throw new Error(
      `Quarantine violation: test shortcut paths must reside inside os.tmpdir() (${tmpRoot})`
    );
  }
}

function buildShortcutSpec(options = {}) {
  const {
    hubRoot = __dirname,
    homeDir = os.homedir(),
    desktopDir = '',
    programsDir = '',
    customUrl = '',
    pwaRoot = path.join(homeDir, 'bhfirms', 'theo'),
    port = 0,
    hotkey,
    customBrowserPath = ''
  } = options;

  const stateFilePath = path.join(homeDir, '.theo', 'desktop-shortcut.json');
  let savedState = null;
  if (fs.existsSync(stateFilePath)) {
    try {
      savedState = JSON.parse(fs.readFileSync(stateFilePath, 'utf8'));
    } catch {}
  }

  const effectiveRawHotkey =
    typeof hotkey !== 'undefined'
      ? hotkey
      : savedState && typeof savedState.hotkey === 'string'
        ? savedState.hotkey
        : DEFAULT_SHORTCUT_HOTKEY;

  const normalizedHotkey = normalizeShortcutHotkey(effectiveRawHotkey);
  if (normalizedHotkey === null) {
    throw new Error(`Invalid shortcut hotkey: ${effectiveRawHotkey}`);
  }

  const effectiveCustomUrl =
    customUrl ||
    (savedState && typeof savedState.customUrl === 'string' ? savedState.customUrl : '');

  const targetUrl = resolveDesktopLaunchUrl({
    customUrl: effectiveCustomUrl,
    pwaRoot,
    port
  });
  const browserExe = findDesktopBrowserExecutable({ customBrowserPath });
  if (!browserExe) {
    throw new Error('Could not locate Microsoft Edge (msedge.exe) or Google Chrome (chrome.exe)');
  }

  const iconInfo = ensureStableDesktopIcon({ hubRoot, homeDir });
  const appArgs = buildBrowserAppArguments(targetUrl);

  const folders =
    desktopDir && programsDir
      ? { desktopDir, programsDir }
      : resolveWindowsSpecialFolders();

  const resolvedDesktop = desktopDir || folders.desktopDir;
  const resolvedPrograms = programsDir || folders.programsDir;

  const desktopShortcutPath = path.join(resolvedDesktop, SHORTCUT_NAME);
  const startMenuShortcutPath = path.join(resolvedPrograms, SHORTCUT_NAME);

  return {
    version: SHORTCUT_STATE_VERSION,
    shortcutName: SHORTCUT_NAME,
    description: SHORTCUT_DESCRIPTION,
    targetPath: browserExe,
    arguments: appArgs,
    url: targetUrl,
    customUrl: effectiveCustomUrl ? targetUrl : '',
    workingDirectory: path.dirname(browserExe),
    iconPath: iconInfo.iconPath,
    iconLocation: iconInfo.iconLocation,
    iconFrameCount: iconInfo.frameCount,
    iconUpdated: Boolean(iconInfo.updated),
    hotkey: normalizedHotkey,
    desktopDir: resolvedDesktop,
    programsDir: resolvedPrograms,
    desktopShortcutPath,
    startMenuShortcutPath,
    stateFilePath
  };
}

function cleanupLegacyShortcuts(desktopDir, programsDir) {
  const removed = [];
  for (const dir of [desktopDir, programsDir]) {
    if (!dir || !fs.existsSync(dir)) continue;
    for (const legacyName of LEGACY_SHORTCUT_NAMES) {
      const cand = path.join(dir, legacyName);
      if (fs.existsSync(cand)) {
        try {
          fs.unlinkSync(cand);
          removed.push(cand);
        } catch {}
      }
    }
  }
  return removed;
}

function isDesktopShortcutUpToDate(spec) {
  try {
    if (spec.iconUpdated) return false;
    if (
      !fs.existsSync(spec.desktopShortcutPath) ||
      !fs.existsSync(spec.startMenuShortcutPath) ||
      !fs.existsSync(spec.iconPath) ||
      !fs.existsSync(spec.stateFilePath)
    ) {
      return false;
    }
    for (const dir of [spec.desktopDir, spec.programsDir]) {
      for (const legacyName of LEGACY_SHORTCUT_NAMES) {
        if (dir && fs.existsSync(path.join(dir, legacyName))) {
          return false;
        }
      }
    }
    const saved = JSON.parse(fs.readFileSync(spec.stateFilePath, 'utf8'));
    return (
      saved &&
      saved.version === SHORTCUT_STATE_VERSION &&
      saved.targetPath === spec.targetPath &&
      saved.arguments === spec.arguments &&
      saved.iconLocation === spec.iconLocation &&
      saved.hotkey === spec.hotkey &&
      saved.desktopShortcutPath === spec.desktopShortcutPath &&
      saved.startMenuShortcutPath === spec.startMenuShortcutPath
    );
  } catch {
    return false;
  }
}

function installDesktopShortcuts(options = {}) {
  assertNotQuarantinedWithoutSandbox(options.desktopDir, options.programsDir);
  const spec = buildShortcutSpec(options);

  if (!options.force && isDesktopShortcutUpToDate(spec)) {
    return {
      ok: true,
      skipped: true,
      removedLegacy: [],
      ...spec
    };
  }

  fs.mkdirSync(spec.desktopDir, { recursive: true });
  fs.mkdirSync(spec.programsDir, { recursive: true });

  const removedLegacy = cleanupLegacyShortcuts(spec.desktopDir, spec.programsDir);

  const psScript = [
    '$ErrorActionPreference = "Stop"',
    '$paths = $env:THEO_LNK_PATHS_JSON | ConvertFrom-Json',
    '$wsh = New-Object -ComObject WScript.Shell',
    'foreach ($lnkPath in $paths) {',
    '  $sc = $wsh.CreateShortcut($lnkPath)',
    '  $sc.TargetPath = $env:THEO_LNK_TARGET',
    '  $sc.Arguments = $env:THEO_LNK_ARGS',
    '  $sc.WorkingDirectory = $env:THEO_LNK_WORKDIR',
    '  $sc.IconLocation = $env:THEO_LNK_ICON',
    '  $sc.Description = $env:THEO_LNK_DESC',
    '  $sc.WindowStyle = 1',
    '  $sc.Hotkey = $(if ($env:THEO_LNK_HOTKEY) { $env:THEO_LNK_HOTKEY } else { "" })',
    '  $sc.Save()',
    '}'
  ].join('; ');

  const childEnv = {
    ...process.env,
    THEO_LNK_PATHS_JSON: JSON.stringify([
      spec.desktopShortcutPath,
      spec.startMenuShortcutPath
    ]),
    THEO_LNK_TARGET: spec.targetPath,
    THEO_LNK_ARGS: spec.arguments,
    THEO_LNK_WORKDIR: spec.workingDirectory,
    THEO_LNK_ICON: spec.iconLocation,
    THEO_LNK_DESC: spec.description,
    THEO_LNK_HOTKEY: spec.hotkey
  };

  const res = spawnSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psScript],
    {
      env: childEnv,
      encoding: 'utf8',
      timeout: 15000,
      windowsHide: true
    }
  );

  if (res.status !== 0) {
    throw new Error(
      `Failed to create Windows shortcut (${res.status}): ${(res.stderr || res.stdout || '').trim()}`
    );
  }

  writeFileAtomicSync(
    spec.stateFilePath,
    JSON.stringify(
      {
        version: spec.version,
        shortcutName: spec.shortcutName,
        targetPath: spec.targetPath,
        arguments: spec.arguments,
        url: spec.url,
        customUrl: spec.customUrl || '',
        iconPath: spec.iconPath,
        iconLocation: spec.iconLocation,
        hotkey: spec.hotkey,
        desktopShortcutPath: spec.desktopShortcutPath,
        startMenuShortcutPath: spec.startMenuShortcutPath,
        updatedAt: new Date().toISOString()
      },
      null,
      2
    )
  );

  return {
    ok: true,
    skipped: false,
    removedLegacy,
    ...spec
  };
}

function uninstallDesktopShortcuts(options = {}) {
  assertNotQuarantinedWithoutSandbox(options.desktopDir, options.programsDir);
  const homeDir = options.homeDir || os.homedir();
  const folders =
    options.desktopDir && options.programsDir
      ? { desktopDir: options.desktopDir, programsDir: options.programsDir }
      : resolveWindowsSpecialFolders();

  const removedShortcuts = [];
  for (const dir of [folders.desktopDir, folders.programsDir]) {
    if (!dir || !fs.existsSync(dir)) continue;
    for (const name of [SHORTCUT_NAME, ...LEGACY_SHORTCUT_NAMES]) {
      const target = path.join(dir, name);
      if (fs.existsSync(target)) {
        try {
          fs.unlinkSync(target);
          removedShortcuts.push(target);
        } catch {}
      }
    }
  }

  const stateFilePath = path.join(homeDir, '.theo', 'desktop-shortcut.json');
  let removedStateFile = false;
  if (fs.existsSync(stateFilePath)) {
    try {
      fs.unlinkSync(stateFilePath);
      removedStateFile = true;
    } catch {}
  }

  const iconFilePath = path.join(homeDir, '.theo', 'theo.ico');
  let removedIconFile = false;
  if (fs.existsSync(iconFilePath)) {
    try {
      fs.unlinkSync(iconFilePath);
      removedIconFile = true;
    } catch {}
  }

  return {
    ok: true,
    removedShortcuts,
    removedStateFile,
    removedIconFile
  };
}

module.exports = {
  DEFAULT_FALLBACK_PWA_URL,
  DEFAULT_SHORTCUT_HOTKEY,
  SHORTCUT_NAME,
  LEGACY_SHORTCUT_NAMES,
  SHORTCUT_DESCRIPTION,
  SHORTCUT_STATE_VERSION,
  validateIcoBuffer,
  validateDesktopAppUrl,
  normalizeShortcutHotkey,
  resolveDesktopLaunchUrl,
  findDesktopBrowserExecutable,
  ensureStableDesktopIcon,
  buildBrowserAppArguments,
  resolveWindowsSpecialFolders,
  buildShortcutSpec,
  isDesktopShortcutUpToDate,
  installDesktopShortcuts,
  uninstallDesktopShortcuts
};
