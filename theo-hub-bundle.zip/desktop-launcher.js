'use strict';

const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { loadTheoCredentials } = require('./device-identity');

const DEFAULT_FALLBACK_PWA_URL = 'https://husseinbdeir.github.io/theo/';
const DEFAULT_SHORTCUT_HOTKEY = 'Ctrl+Alt+T';
const DEFAULT_APP_USER_MODEL_ID = 'BHFIRMS.THEO.Desktop';
const SHORTCUT_NAME = 'THEO.lnk';
const LAUNCHER_EXE_NAME = 'THEO.exe';
const LEGACY_SHORTCUT_NAMES = ['THEO Remote.lnk', 'THEO Studio.lnk'];
const SHORTCUT_DESCRIPTION = 'THEO - AI Session Workbench';
const SHORTCUT_STATE_VERSION = 2;

function validateIcoBuffer(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 22) {
    return { valid: false, frameCount: 0, reason: 'Buffer too small for ICO header' };
  }
  const reserved = buf.readUInt16LE(0);
  const type = buf.readUInt16LE(2);
  const count = buf.readUInt16LE(4);
  if (reserved !== 0 || type !== 1 || count < 1 || count > 32) {
    return { valid: false, frameCount: 0, reason: 'Invalid ICO magic bytes or frame count' };
  }
  const minDirSize = 6 + count * 16;
  if (buf.length < minDirSize) {
    return { valid: false, frameCount: 0, reason: 'Truncated ICO directory entries' };
  }
  for (let i = 0; i < count; i++) {
    const entryOffset = 6 + i * 16;
    const bytesInRes = buf.readUInt32LE(entryOffset + 8);
    const imageOffset = buf.readUInt32LE(entryOffset + 12);
    if (bytesInRes < 8 || imageOffset < minDirSize || imageOffset + bytesInRes > buf.length) {
      return { valid: false, frameCount: 0, reason: `Out-of-bounds ICO frame at index ${i}` };
    }
  }
  return { valid: true, frameCount: count, reason: '' };
}

function validateDesktopAppUrl(rawUrl) {
  if (typeof rawUrl !== 'string') return null;
  const trimmed = rawUrl.trim();
  if (!trimmed || trimmed.length > 512) return null;
  if (/[\x00-\x20\x7f"'`$\\]/.test(trimmed)) return null;

  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return null;
  }

  if (parsed.username || parsed.password) return null;
  // Never allow #pair= or query/hash secrets in persistent desktop shortcut CLI args
  if (/pair=|cloudKey|edgeAccessKey|token=/i.test(parsed.search + parsed.hash)) {
    return null;
  }

  if (parsed.protocol === 'https:') {
    if (!parsed.hostname || parsed.hostname.includes('..')) return null;
    return parsed.toString();
  }

  if (parsed.protocol === 'http:') {
    const host = parsed.hostname.toLowerCase();
    if (host !== '127.0.0.1' && host !== 'localhost') {
      return null;
    }
    const portNum = parsed.port ? Number(parsed.port) : 80;
    if (!Number.isInteger(portNum) || portNum < 1 || portNum > 65535) {
      return null;
    }
    return parsed.toString();
  }

  return null;
}

function normalizeShortcutHotkey(rawHotkey) {
  if (rawHotkey === '' || rawHotkey === null || rawHotkey === false) return '';
  if (typeof rawHotkey === 'undefined') return DEFAULT_SHORTCUT_HOTKEY;
  if (typeof rawHotkey !== 'string') return null;
  const trimmed = rawHotkey.trim();
  if (!trimmed || /^none$/i.test(trimmed)) return '';
  if (/[\x00-\x1f\x7f"'`$;|&<>]/.test(trimmed)) return null;

  const parts = trimmed.split('+').map((p) => p.trim()).filter(Boolean);
  if (parts.length === 0 || parts.length !== trimmed.split('+').length) return null;

  if (parts.length === 1) {
    const fnMatch = parts[0].match(/^F([1-9]|1[0-2])$/i);
    return fnMatch ? `F${fnMatch[1]}` : null;
  }

  const keyPart = parts[parts.length - 1];
  const modParts = parts.slice(0, -1);
  let hasCtrl = false;
  let hasAlt = false;
  let hasShift = false;

  for (const mod of modParts) {
    if (/^(ctrl|control)$/i.test(mod)) {
      if (hasCtrl) return null;
      hasCtrl = true;
    } else if (/^alt$/i.test(mod)) {
      if (hasAlt) return null;
      hasAlt = true;
    } else if (/^shift$/i.test(mod)) {
      if (hasShift) return null;
      hasShift = true;
    } else {
      return null;
    }
  }

  const modCount = (hasCtrl ? 1 : 0) + (hasAlt ? 1 : 0) + (hasShift ? 1 : 0);
  let normalizedKey = '';
  if (/^[A-Za-z0-9]$/.test(keyPart)) {
    if (modCount < 2) return null;
    normalizedKey = keyPart.toUpperCase();
  } else if (/^F([1-9]|1[0-2])$/i.test(keyPart)) {
    if (modCount < 1) return null;
    normalizedKey = keyPart.toUpperCase();
  } else {
    return null;
  }

  const orderedMods = [];
  if (hasCtrl) orderedMods.push('Ctrl');
  if (hasAlt) orderedMods.push('Alt');
  if (hasShift) orderedMods.push('Shift');
  return `${orderedMods.join('+')}+${normalizedKey}`;
}

function resolveDesktopLaunchUrl(options = {}) {
  const {
    customUrl = '',
    pwaRoot = path.join(os.homedir(), 'bhfirms', 'theo'),
    port = 0,
    fallbackUrl = DEFAULT_FALLBACK_PWA_URL,
    existsSync = fs.existsSync
  } = options;

  if (customUrl) {
    const validatedCustom = validateDesktopAppUrl(customUrl);
    if (!validatedCustom) {
      throw new Error(`Invalid or unsafe desktop launch URL: ${customUrl}`);
    }
    return validatedCustom;
  }

  let effectivePort = Number(port || 0);
  if (!Number.isInteger(effectivePort) || effectivePort < 1 || effectivePort > 65535) {
    try {
      const creds = loadTheoCredentials();
      const credPort = Number(creds?.port || 4318);
      effectivePort = Number.isInteger(credPort) && credPort >= 1 && credPort <= 65535 ? credPort : 4318;
    } catch {
      effectivePort = 4318;
    }
  }

  const localIndex = pwaRoot ? path.join(pwaRoot, 'index.html') : '';
  if (localIndex && existsSync(localIndex)) {
    const loopbackUrl = validateDesktopAppUrl(`http://127.0.0.1:${effectivePort}/`);
    if (loopbackUrl) return loopbackUrl;
  }

  const safeFallback = validateDesktopAppUrl(fallbackUrl) || DEFAULT_FALLBACK_PWA_URL;
  return safeFallback;
}

function findDesktopBrowserExecutable(options = {}) {
  const {
    env = process.env,
    customBrowserPath = '',
    existsSync = fs.existsSync,
    statSync = fs.statSync
  } = options;

  const isSafeExe = (cand) => {
    if (!cand || typeof cand !== 'string') return false;
    const trimmed = cand.trim();
    if (!trimmed || /[\x00-\x1f\x7f"'`$;|&<>]/.test(trimmed)) return false;
    if (!/\.exe$/i.test(trimmed)) return false;
    try {
      return existsSync(trimmed) && statSync(trimmed).isFile();
    } catch {
      return false;
    }
  };

  if (customBrowserPath) {
    if (!isSafeExe(customBrowserPath)) {
      throw new Error(`Invalid browser executable path: ${customBrowserPath}`);
    }
    return customBrowserPath.trim();
  }

  const progFilesX86 = env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const progFiles = env.ProgramFiles || 'C:\\Program Files';
  const localAppData = env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');

  // Prefer Google Chrome over Microsoft Edge to avoid Edge Startup Boost (--no-startup-window)
  // and edge://sync-confirmation-dialog collisions.
  const candidates = [
    path.join(progFiles, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(progFilesX86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(localAppData, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(progFilesX86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(progFiles, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(localAppData, 'Microsoft', 'Edge', 'Application', 'msedge.exe')
  ];

  for (const cand of candidates) {
    if (isSafeExe(cand)) return cand;
  }
  return '';
}

function writeFileAtomicSync(targetPath, dataBufferOrString) {
  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const tmpPath = `${targetPath}.tmp-${process.pid}-${Date.now()}`;
  try {
    fs.writeFileSync(tmpPath, dataBufferOrString);
    fs.renameSync(tmpPath, targetPath);
  } finally {
    if (fs.existsSync(tmpPath)) {
      try {
        fs.unlinkSync(tmpPath);
      } catch {}
    }
  }
}

function ensureStableDesktopIcon(options = {}) {
  const {
    hubRoot = __dirname,
    homeDir = os.homedir()
  } = options;

  const srcIco = path.join(hubRoot, 'resources', 'theo.ico');
  if (!fs.existsSync(srcIco)) {
    throw new Error(`Missing source icon at ${srcIco}`);
  }
  const srcBytes = fs.readFileSync(srcIco);
  const check = validateIcoBuffer(srcBytes);
  if (!check.valid) {
    throw new Error(`Invalid source theo.ico (${check.reason})`);
  }

  const theoDir = path.join(homeDir, '.theo');
  const dstIco = path.join(theoDir, 'theo.ico');
  let needsWrite = true;
  if (fs.existsSync(dstIco)) {
    try {
      const existingBytes = fs.readFileSync(dstIco);
      if (existingBytes.equals(srcBytes)) {
        needsWrite = false;
      }
    } catch {}
  }

  if (needsWrite) {
    writeFileAtomicSync(dstIco, srcBytes);
  }
  return {
    iconPath: dstIco,
    iconLocation: `${dstIco},0`,
    frameCount: check.frameCount,
    updated: needsWrite
  };
}

function findDotNetCscCompiler(env = process.env) {
  const windir = env.WINDIR || env.SystemRoot || 'C:\\Windows';
  const candidates = [
    path.join(windir, 'Microsoft.NET', 'Framework64', 'v4.0.30319', 'csc.exe'),
    path.join(windir, 'Microsoft.NET', 'Framework', 'v4.0.30319', 'csc.exe')
  ];
  for (const cand of candidates) {
    if (fs.existsSync(cand)) return cand;
  }
  return '';
}

function ensureNativeLauncherExecutable(options = {}) {
  const {
    hubRoot = __dirname,
    homeDir = os.homedir(),
    iconPath = path.join(homeDir, '.theo', 'theo.ico'),
    savedHash = '',
    force = false
  } = options;

  const srcCs = path.join(hubRoot, 'resources', 'TheoLauncher.cs');
  if (!fs.existsSync(srcCs)) {
    throw new Error(`Missing native launcher source at ${srcCs}`);
  }
  if (!fs.existsSync(iconPath)) {
    throw new Error(`Missing icon for native launcher compilation at ${iconPath}`);
  }

  const csBytes = fs.readFileSync(srcCs);
  const icoBytes = fs.readFileSync(iconPath);
  const currentHash = crypto
    .createHash('sha256')
    .update(csBytes)
    .update(icoBytes)
    .digest('hex');

  const theoDir = path.join(homeDir, '.theo');
  const dstExe = path.join(theoDir, LAUNCHER_EXE_NAME);

  if (!force && fs.existsSync(dstExe) && savedHash === currentHash) {
    try {
      const st = fs.statSync(dstExe);
      if (st.isFile() && st.size > 4096) {
        return {
          launcherExePath: dstExe,
          launcherSourceHash: currentHash,
          updated: false
        };
      }
    } catch {}
  }

  const cscExe = findDotNetCscCompiler();
  if (!cscExe) {
    throw new Error('Could not locate .NET Framework csc.exe compiler to build THEO.exe');
  }

  fs.mkdirSync(theoDir, { recursive: true });
  const tmpExe = path.join(theoDir, `THEO.tmp-${process.pid}-${Date.now()}.exe`);
  try {
    const cscArgs = [
      '/nologo',
      '/optimize+',
      '/target:winexe',
      `/win32icon:${iconPath}`,
      '/r:System.dll',
      '/r:System.Core.dll',
      '/r:System.Web.Extensions.dll',
      `/out:${tmpExe}`,
      srcCs
    ];
    const res = spawnSync(cscExe, cscArgs, {
      encoding: 'utf8',
      timeout: 20000,
      windowsHide: true
    });
    if (res.status !== 0 || !fs.existsSync(tmpExe)) {
      throw new Error(
        `Failed to compile THEO.exe (${res.status}): ${(res.stderr || res.stdout || '').trim()}`
      );
    }
    try {
      fs.renameSync(tmpExe, dstExe);
    } catch {
      fs.copyFileSync(tmpExe, dstExe);
    }
  } finally {
    if (fs.existsSync(tmpExe)) {
      try {
        fs.unlinkSync(tmpExe);
      } catch {}
    }
  }

  return {
    launcherExePath: dstExe,
    launcherSourceHash: currentHash,
    updated: true
  };
}

function prepareIsolatedBrowserProfile(profileDir) {
  if (!profileDir) return;
  try {
    const defaultDir = path.join(profileDir, 'Default');
    fs.mkdirSync(defaultDir, { recursive: true });

    const firstRunSentinel = path.join(profileDir, 'First Run');
    if (!fs.existsSync(firstRunSentinel)) {
      fs.writeFileSync(firstRunSentinel, '', 'utf8');
    }

    const prefsPath = path.join(defaultDir, 'Preferences');
    if (!fs.existsSync(prefsPath)) {
      fs.writeFileSync(
        prefsPath,
        JSON.stringify({
          browser: { has_seen_welcome_page: true },
          background_mode: { enabled: false },
          sync: { suppress_start: true }
        }),
        'utf8'
      );
    }
  } catch {}
}

function buildBrowserAppArguments(targetUrl, profileDir = '') {
  const safeUrl = validateDesktopAppUrl(targetUrl);
  if (!safeUrl) {
    throw new Error(`Refusing to build browser --app arguments for invalid URL: ${targetUrl}`);
  }
  if (profileDir) {
    const trimmedProfile = String(profileDir).trim();
    if (!trimmedProfile || /[\x00-\x1f\x7f"'`$;|&<>]/.test(trimmedProfile)) {
      throw new Error(`Refusing to build browser --user-data-dir for unsafe path: ${profileDir}`);
    }
    return `--user-data-dir="${trimmedProfile}" --app="${safeUrl}" --no-first-run --no-default-browser-check --disable-background-mode --disable-sync`;
  }
  return `--app="${safeUrl}"`;
}

function resolveWindowsSpecialFolders() {
  const defaultTaskbarDir = path.join(
    process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'),
    'Microsoft',
    'Internet Explorer',
    'Quick Launch',
    'User Pinned',
    'TaskBar'
  );
  try {
    const psCmd =
      '[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; ' +
      '@{ desktop = [Environment]::GetFolderPath("Desktop"); programs = [Environment]::GetFolderPath("Programs") } | ConvertTo-Json -Compress';
    const res = spawnSync(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psCmd],
      { encoding: 'utf8', timeout: 8000, windowsHide: true }
    );
    if (res.status === 0 && res.stdout) {
      const parsed = JSON.parse(res.stdout.trim());
      if (parsed && parsed.desktop && parsed.programs) {
        return {
          desktopDir: String(parsed.desktop).trim(),
          programsDir: String(parsed.programs).trim(),
          taskbarDir: defaultTaskbarDir
        };
      }
    }
  } catch {}
  return {
    desktopDir: path.join(os.homedir(), 'Desktop'),
    programsDir: path.join(
      process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'),
      'Microsoft',
      'Windows',
      'Start Menu',
      'Programs'
    ),
    taskbarDir: defaultTaskbarDir
  };
}

function isTestQuarantineActive() {
  return (
    process.env.THEO_SMOKE_TEST === '1' ||
    process.env.THEO_HEADLESS_TEST === '1'
  );
}

function assertNotQuarantinedWithoutSandbox(desktopDir, programsDir, taskbarDir = '') {
  if (!isTestQuarantineActive()) return;

  if (!desktopDir || !programsDir) {
    throw new Error(
      'Quarantine violation: THEO_SMOKE_TEST=1 requires explicit sandbox desktopDir and programsDir'
    );
  }
  const tmpRoot = path.resolve(os.tmpdir()).toLowerCase();
  const dNorm = path.resolve(desktopDir).toLowerCase();
  const pNorm = path.resolve(programsDir).toLowerCase();
  if (!dNorm.startsWith(tmpRoot) || !pNorm.startsWith(tmpRoot)) {
    throw new Error(
      `Quarantine violation: test shortcut paths must reside inside os.tmpdir() (${tmpRoot})`
    );
  }
  if (taskbarDir) {
    const tNorm = path.resolve(taskbarDir).toLowerCase();
    if (!tNorm.startsWith(tmpRoot)) {
      throw new Error(
        `Quarantine violation: test taskbarDir must reside inside os.tmpdir() (${tmpRoot})`
      );
    }
  }
}

function buildShortcutSpec(options = {}) {
  const {
    hubRoot = __dirname,
    homeDir = os.homedir(),
    desktopDir = '',
    programsDir = '',
    taskbarDir = '',
    customUrl = '',
    pwaRoot = path.join(homeDir, 'bhfirms', 'theo'),
    port = 0,
    hotkey,
    customBrowserPath = '',
    force = false
  } = options;

  const theoDir = path.join(homeDir, '.theo');
  const stateFilePath = path.join(theoDir, 'desktop-shortcut.json');
  let savedState = null;
  if (fs.existsSync(stateFilePath)) {
    try {
      savedState = JSON.parse(fs.readFileSync(stateFilePath, 'utf8'));
    } catch {}
  }

  const effectiveRawHotkey =
    typeof hotkey !== 'undefined'
      ? hotkey
      : savedState && typeof savedState.hotkey === 'string'
        ? savedState.hotkey
        : DEFAULT_SHORTCUT_HOTKEY;

  const normalizedHotkey = normalizeShortcutHotkey(effectiveRawHotkey);
  if (normalizedHotkey === null) {
    throw new Error(`Invalid shortcut hotkey: ${effectiveRawHotkey}`);
  }

  const effectiveCustomUrl =
    customUrl ||
    (savedState && typeof savedState.customUrl === 'string' ? savedState.customUrl : '');

  const targetUrl = resolveDesktopLaunchUrl({
    customUrl: effectiveCustomUrl,
    pwaRoot,
    port
  });
  const browserExe = findDesktopBrowserExecutable({ customBrowserPath });
  if (!browserExe) {
    throw new Error('Could not locate Google Chrome (chrome.exe) or Microsoft Edge (msedge.exe)');
  }

  const iconInfo = ensureStableDesktopIcon({ hubRoot, homeDir });
  const launcherInfo = ensureNativeLauncherExecutable({
    hubRoot,
    homeDir,
    iconPath: iconInfo.iconPath,
    savedHash: savedState && typeof savedState.launcherSourceHash === 'string' ? savedState.launcherSourceHash : '',
    force
  });

  const profileDir = path.join(theoDir, 'app-profile');
  const browserArgs = buildBrowserAppArguments(targetUrl, profileDir);
  const keepaliveScriptPath = path.join(hubRoot, 'scripts', 'relay_keepalive_start.ps1');

  const folders =
    desktopDir && programsDir
      ? { desktopDir, programsDir, taskbarDir }
      : resolveWindowsSpecialFolders();

  const resolvedDesktop = desktopDir || folders.desktopDir;
  const resolvedPrograms = programsDir || folders.programsDir;
  const resolvedTaskbarDir = isTestQuarantineActive()
    ? taskbarDir
    : taskbarDir || folders.taskbarDir || '';

  const desktopShortcutPath = path.join(resolvedDesktop, SHORTCUT_NAME);
  const startMenuShortcutPath = path.join(resolvedPrograms, SHORTCUT_NAME);
  const candidateTaskbarShortcut = resolvedTaskbarDir
    ? path.join(resolvedTaskbarDir, SHORTCUT_NAME)
    : '';
  const taskbarShortcutPath =
    candidateTaskbarShortcut && fs.existsSync(candidateTaskbarShortcut)
      ? candidateTaskbarShortcut
      : '';

  return {
    version: SHORTCUT_STATE_VERSION,
    shortcutName: SHORTCUT_NAME,
    description: SHORTCUT_DESCRIPTION,
    appUserModelId: DEFAULT_APP_USER_MODEL_ID,
    targetPath: launcherInfo.launcherExePath,
    arguments: '',
    launcherExePath: launcherInfo.launcherExePath,
    launcherSourceHash: launcherInfo.launcherSourceHash,
    launcherUpdated: Boolean(launcherInfo.updated),
    browserPath: browserExe,
    browserArguments: browserArgs,
    profileDir,
    keepaliveScriptPath,
    url: targetUrl,
    customUrl: effectiveCustomUrl ? targetUrl : '',
    workingDirectory: theoDir,
    iconPath: iconInfo.iconPath,
    iconLocation: iconInfo.iconLocation,
    iconFrameCount: iconInfo.frameCount,
    iconUpdated: Boolean(iconInfo.updated),
    hotkey: normalizedHotkey,
    desktopDir: resolvedDesktop,
    programsDir: resolvedPrograms,
    taskbarDir: resolvedTaskbarDir,
    desktopShortcutPath,
    startMenuShortcutPath,
    taskbarShortcutPath,
    stateFilePath
  };
}

function cleanupLegacyShortcuts(desktopDir, programsDir, taskbarDir = '') {
  const removed = [];
  for (const dir of [desktopDir, programsDir, taskbarDir]) {
    if (!dir || !fs.existsSync(dir)) continue;
    for (const legacyName of LEGACY_SHORTCUT_NAMES) {
      const cand = path.join(dir, legacyName);
      if (fs.existsSync(cand)) {
        try {
          fs.unlinkSync(cand);
          removed.push(cand);
        } catch {}
      }
    }
  }
  return removed;
}

function isDesktopShortcutUpToDate(spec) {
  try {
    if (spec.iconUpdated || spec.launcherUpdated) return false;
    if (
      !fs.existsSync(spec.desktopShortcutPath) ||
      !fs.existsSync(spec.startMenuShortcutPath) ||
      !fs.existsSync(spec.iconPath) ||
      !fs.existsSync(spec.launcherExePath) ||
      !fs.existsSync(spec.stateFilePath)
    ) {
      return false;
    }
    for (const dir of [spec.desktopDir, spec.programsDir, spec.taskbarDir]) {
      for (const legacyName of LEGACY_SHORTCUT_NAMES) {
        if (dir && fs.existsSync(path.join(dir, legacyName))) {
          return false;
        }
      }
    }
    const saved = JSON.parse(fs.readFileSync(spec.stateFilePath, 'utf8'));
    return (
      saved &&
      saved.version === SHORTCUT_STATE_VERSION &&
      saved.appUserModelId === spec.appUserModelId &&
      saved.targetPath === spec.targetPath &&
      saved.arguments === spec.arguments &&
      saved.launcherExePath === spec.launcherExePath &&
      saved.launcherSourceHash === spec.launcherSourceHash &&
      saved.browserPath === spec.browserPath &&
      saved.profileDir === spec.profileDir &&
      saved.url === spec.url &&
      saved.iconLocation === spec.iconLocation &&
      saved.hotkey === spec.hotkey &&
      saved.desktopShortcutPath === spec.desktopShortcutPath &&
      saved.startMenuShortcutPath === spec.startMenuShortcutPath &&
      (saved.taskbarShortcutPath || '') === (spec.taskbarShortcutPath || '')
    );
  } catch {
    return false;
  }
}

function installDesktopShortcuts(options = {}) {
  assertNotQuarantinedWithoutSandbox(options.desktopDir, options.programsDir, options.taskbarDir);
  const spec = buildShortcutSpec(options);

  if (!options.force && isDesktopShortcutUpToDate(spec)) {
    return {
      ok: true,
      skipped: true,
      removedLegacy: [],
      ...spec
    };
  }

  fs.mkdirSync(spec.desktopDir, { recursive: true });
  fs.mkdirSync(spec.programsDir, { recursive: true });
  prepareIsolatedBrowserProfile(spec.profileDir);

  const removedLegacy = cleanupLegacyShortcuts(spec.desktopDir, spec.programsDir, spec.taskbarDir);

  // Persist state before writing shortcuts so THEO.exe immediately sees the resolved config
  const statePayload = {
    version: spec.version,
    shortcutName: spec.shortcutName,
    appUserModelId: spec.appUserModelId,
    targetPath: spec.targetPath,
    arguments: spec.arguments,
    launcherExePath: spec.launcherExePath,
    launcherSourceHash: spec.launcherSourceHash,
    browserPath: spec.browserPath,
    browserArguments: spec.browserArguments,
    profileDir: spec.profileDir,
    keepaliveScriptPath: spec.keepaliveScriptPath,
    url: spec.url,
    customUrl: spec.customUrl || '',
    iconPath: spec.iconPath,
    iconLocation: spec.iconLocation,
    hotkey: spec.hotkey,
    desktopShortcutPath: spec.desktopShortcutPath,
    startMenuShortcutPath: spec.startMenuShortcutPath,
    taskbarShortcutPath: spec.taskbarShortcutPath || '',
    updatedAt: new Date().toISOString()
  };
  writeFileAtomicSync(spec.stateFilePath, JSON.stringify(statePayload, null, 2));

  const shortcutTargets = [spec.desktopShortcutPath, spec.startMenuShortcutPath];
  if (spec.taskbarShortcutPath) {
    shortcutTargets.push(spec.taskbarShortcutPath);
  }

  const psScript = [
    '$ErrorActionPreference = "Stop"',
    'Add-Type -TypeDefinition @"',
    'using System;',
    'using System.Runtime.InteropServices;',
    'using System.Runtime.InteropServices.ComTypes;',
    'public static class TheoLnkPropertyStamper {',
    '  [ComImport, Guid("00021401-0000-0000-C000-000000000046")] internal class ShellLink {}',
    '  [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")]',
    '  internal interface IPropertyStore {',
    '    int GetCount(out uint cProps);',
    '    int GetAt(uint iProp, out PROPERTYKEY pkey);',
    '    int GetValue(ref PROPERTYKEY key, out PropVariant pv);',
    '    int SetValue(ref PROPERTYKEY key, ref PropVariant pv);',
    '    int Commit();',
    '  }',
    '  [StructLayout(LayoutKind.Sequential, Pack = 4)]',
    '  public struct PROPERTYKEY {',
    '    public Guid fmtid; public uint pid;',
    '    public PROPERTYKEY(string g, uint id) { fmtid = new Guid(g); pid = id; }',
    '  }',
    '  [StructLayout(LayoutKind.Sequential)]',
    '  public struct PropVariant {',
    '    public ushort vt; public ushort r1; public ushort r2; public ushort r3; public IntPtr ptr; public int d;',
    '    public static PropVariant FromString(string val) {',
    '      var pv = new PropVariant(); pv.vt = 31; pv.ptr = Marshal.StringToCoTaskMemUni(val ?? ""); return pv;',
    '    }',
    '    public void Free() {',
    '      if (vt == 31 && ptr != IntPtr.Zero) { Marshal.FreeCoTaskMem(ptr); ptr = IntPtr.Zero; vt = 0; }',
    '    }',
    '  }',
    '  [DllImport("shell32.dll", CharSet = CharSet.Unicode)]',
    '  public static extern void SHChangeNotify(int wEventId, uint uFlags, string dwItem1, IntPtr dwItem2);',
    '  public static void Stamp(string lnkPath, string aumid, string relaunchCmd, string relaunchIcon, string relaunchName) {',
    '    var link = new ShellLink();',
    '    ((IPersistFile)link).Load(lnkPath, 2);',
    '    var store = (IPropertyStore)link;',
    '    var pkAumid = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 5);',
    '    var pkCmd   = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 2);',
    '    var pkIcon  = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 3);',
    '    var pkName  = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 4);',
    '    var vId   = PropVariant.FromString(aumid);',
    '    var vCmd  = PropVariant.FromString(relaunchCmd);',
    '    var vIcon = PropVariant.FromString(relaunchIcon);',
    '    var vName = PropVariant.FromString(relaunchName);',
    '    try {',
    '      store.SetValue(ref pkAumid, ref vId);',
    '      store.SetValue(ref pkCmd, ref vCmd);',
    '      store.SetValue(ref pkIcon, ref vIcon);',
    '      store.SetValue(ref pkName, ref vName);',
    '      store.Commit();',
    '      ((IPersistFile)link).Save(lnkPath, true);',
    '    } finally {',
    '      vId.Free(); vCmd.Free(); vIcon.Free(); vName.Free();',
    '    }',
    '    SHChangeNotify(0x00002000, 0x1005, lnkPath, IntPtr.Zero);',
    '  }',
    '}',
    '"@',
    '$paths = $env:THEO_LNK_PATHS_JSON | ConvertFrom-Json',
    '$taskbarPath = $env:THEO_LNK_TASKBAR_PATH',
    '$wsh = New-Object -ComObject WScript.Shell',
    'foreach ($lnkPath in $paths) {',
    '  $sc = $wsh.CreateShortcut($lnkPath)',
    '  $sc.TargetPath = $env:THEO_LNK_TARGET',
    '  $sc.Arguments = $env:THEO_LNK_ARGS',
    '  $sc.WorkingDirectory = $env:THEO_LNK_WORKDIR',
    '  $sc.IconLocation = $env:THEO_LNK_ICON',
    '  $sc.Description = $env:THEO_LNK_DESC',
    '  $sc.WindowStyle = 1',
    '  if ($taskbarPath -and ($lnkPath -eq $taskbarPath)) {',
    '    $sc.Hotkey = ""',
    '  } else {',
    '    $sc.Hotkey = $(if ($env:THEO_LNK_HOTKEY) { $env:THEO_LNK_HOTKEY } else { "" })',
    '  }',
    '  $sc.Save()',
    '  [TheoLnkPropertyStamper]::Stamp($lnkPath, $env:THEO_LNK_AUMID, $env:THEO_LNK_RELAUNCH_CMD, $env:THEO_LNK_ICON, "THEO")',
    '}',
    'if ($env:THEO_LNK_REGISTER_AUMID -eq "1") {',
    '  $regPath = "HKCU:\\Software\\Classes\\AppUserModelId\\" + $env:THEO_LNK_AUMID',
    '  if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }',
    '  Set-ItemProperty -Path $regPath -Name "DisplayName" -Value "THEO" -Type String',
    '  Set-ItemProperty -Path $regPath -Name "IconUri" -Value $env:THEO_LNK_ICON_FILE -Type String',
    '  [TheoLnkPropertyStamper]::SHChangeNotify(0x08000000, 0x1000, $null, [IntPtr]::Zero)',
    '}'
  ].join('\n');

  const childEnv = {
    ...process.env,
    THEO_LNK_PATHS_JSON: JSON.stringify(shortcutTargets),
    THEO_LNK_TASKBAR_PATH: spec.taskbarShortcutPath || '',
    THEO_LNK_TARGET: spec.targetPath,
    THEO_LNK_ARGS: spec.arguments,
    THEO_LNK_WORKDIR: spec.workingDirectory,
    THEO_LNK_ICON: spec.iconLocation,
    THEO_LNK_ICON_FILE: spec.iconPath,
    THEO_LNK_DESC: spec.description,
    THEO_LNK_HOTKEY: spec.hotkey,
    THEO_LNK_AUMID: spec.appUserModelId,
    THEO_LNK_RELAUNCH_CMD: `"${spec.launcherExePath}"`,
    THEO_LNK_REGISTER_AUMID: isTestQuarantineActive() ? '0' : '1'
  };

  const res = spawnSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psScript],
    {
      env: childEnv,
      encoding: 'utf8',
      timeout: 20000,
      windowsHide: true
    }
  );

  if (res.status !== 0) {
    throw new Error(
      `Failed to create Windows shortcut (${res.status}): ${(res.stderr || res.stdout || '').trim()}`
    );
  }

  return {
    ok: true,
    skipped: false,
    removedLegacy,
    ...spec
  };
}

function uninstallDesktopShortcuts(options = {}) {
  assertNotQuarantinedWithoutSandbox(options.desktopDir, options.programsDir, options.taskbarDir);
  const homeDir = options.homeDir || os.homedir();
  const folders =
    options.desktopDir && options.programsDir
      ? {
          desktopDir: options.desktopDir,
          programsDir: options.programsDir,
          taskbarDir: options.taskbarDir || ''
        }
      : resolveWindowsSpecialFolders();

  const targetDirs = [folders.desktopDir, folders.programsDir];
  if (!isTestQuarantineActive() && folders.taskbarDir) {
    targetDirs.push(folders.taskbarDir);
  } else if (options.taskbarDir) {
    targetDirs.push(options.taskbarDir);
  }

  const removedShortcuts = [];
  for (const dir of targetDirs) {
    if (!dir || !fs.existsSync(dir)) continue;
    for (const name of [SHORTCUT_NAME, ...LEGACY_SHORTCUT_NAMES]) {
      const target = path.join(dir, name);
      if (fs.existsSync(target)) {
        try {
          fs.unlinkSync(target);
          removedShortcuts.push(target);
        } catch {}
      }
    }
  }

  const theoDir = path.join(homeDir, '.theo');
  const stateFilePath = path.join(theoDir, 'desktop-shortcut.json');
  let removedStateFile = false;
  if (fs.existsSync(stateFilePath)) {
    try {
      fs.unlinkSync(stateFilePath);
      removedStateFile = true;
    } catch {}
  }

  const winStatePath = path.join(theoDir, 'app-window.json');
  if (fs.existsSync(winStatePath)) {
    try {
      fs.unlinkSync(winStatePath);
    } catch {}
  }

  const iconFilePath = path.join(theoDir, 'theo.ico');
  let removedIconFile = false;
  if (fs.existsSync(iconFilePath)) {
    try {
      fs.unlinkSync(iconFilePath);
      removedIconFile = true;
    } catch {}
  }

  const launcherExePath = path.join(theoDir, LAUNCHER_EXE_NAME);
  let removedLauncherExe = false;
  if (fs.existsSync(launcherExePath)) {
    try {
      fs.unlinkSync(launcherExePath);
      removedLauncherExe = true;
    } catch {}
  }

  if (!isTestQuarantineActive()) {
    try {
      const cleanupPs = [
        '$regPath = "HKCU:\\Software\\Classes\\AppUserModelId\\" + $env:THEO_LNK_AUMID',
        'if (Test-Path $regPath) { Remove-Item -Path $regPath -Recurse -Force -ErrorAction SilentlyContinue }'
      ].join('; ');
      spawnSync(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', cleanupPs],
        {
          env: { ...process.env, THEO_LNK_AUMID: DEFAULT_APP_USER_MODEL_ID },
          encoding: 'utf8',
          timeout: 8000,
          windowsHide: true
        }
      );
    } catch {}
  }

  return {
    ok: true,
    removedShortcuts,
    removedStateFile,
    removedIconFile,
    removedLauncherExe
  };
}

module.exports = {
  DEFAULT_FALLBACK_PWA_URL,
  DEFAULT_SHORTCUT_HOTKEY,
  DEFAULT_APP_USER_MODEL_ID,
  SHORTCUT_NAME,
  LAUNCHER_EXE_NAME,
  LEGACY_SHORTCUT_NAMES,
  SHORTCUT_DESCRIPTION,
  SHORTCUT_STATE_VERSION,
  validateIcoBuffer,
  validateDesktopAppUrl,
  normalizeShortcutHotkey,
  resolveDesktopLaunchUrl,
  findDesktopBrowserExecutable,
  ensureStableDesktopIcon,
  ensureNativeLauncherExecutable,
  prepareIsolatedBrowserProfile,
  buildBrowserAppArguments,
  resolveWindowsSpecialFolders,
  buildShortcutSpec,
  isDesktopShortcutUpToDate,
  installDesktopShortcuts,
  uninstallDesktopShortcuts
};
