const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const https = require('https');
const net = require('net');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
// Resolved at call time: a store.js hot swap is applied in place without restarting this bridge
// (extension.js HOT_SWAP_RESTART_FILES), so a binding captured at load would keep the old code.
function buildClaudeToolPermissionQuestion(...args) {
  return require('./store').buildClaudeToolPermissionQuestion(...args);
}

// Which follow-up work a set of already-copied hub files needs (syncHotReloadedModules). Accepts repo-relative
// paths with either separator ('compat\\x.cjs', 'compat/x.cjs', './bridge.js').
function hotSwapChangeFlags(changedFiles) {
  const flags = { ctxWindowChanged: false, bridgePatchesChanged: false, webviewAssetsChanged: false };
  if (!Array.isArray(changedFiles)) return flags;
  for (const raw of changedFiles) {
    const rel = String(raw || '')
      .replace(/\\/g, '/')
      .replace(/^\.\//, '');
    if (!rel) continue;
    if (rel === 'compat/antigravity-context-window.cjs') flags.ctxWindowChanged = true;
    if (rel === 'bridge.js' || rel === 'compat/claude-webview-patches.cjs') flags.bridgePatchesChanged = true;
    // Only the sidebar page itself: theo.ico / TheoLauncher.cs must not reset webview.html.
    if (/^resources\/hub\.(js|css|html)$/.test(rel)) flags.webviewAssetsChanged = true;
  }
  return flags;
}

// Pre-sync companion v3 modules from ~/bhfirms/theo-hub into installed extension dir before require()
// so hot-reloads in already-running VS Code sessions never hit MODULE_NOT_FOUND.
(function ensureCompanionModulesSynced() {
  try {
    const repoRoot = path.join(os.homedir(), 'bhfirms', 'theo-hub');
    if (!fs.existsSync(repoRoot) || path.resolve(repoRoot) === path.resolve(__dirname)) return;
    for (const modFile of [
      'device-identity.js',
      'pc-setup.js',
      'unsaved-work.js',
      'bundle-updater.js',
      'ws-server.js',
      'direct-runner.js',
      'edge-relay-client.js'
    ]) {
      const src = path.join(repoRoot, modFile);
      const dst = path.join(__dirname, modFile);
      if (!fs.existsSync(src)) continue;
      if (fs.existsSync(dst)) {
        try {
          if (fs.statSync(dst).mtimeMs > fs.statSync(src).mtimeMs + 500) continue;
        } catch {}
      }
      const srcBuf = fs.readFileSync(src);
      const dstBuf = fs.existsSync(dst) ? fs.readFileSync(dst) : null;
      if (!dstBuf || !srcBuf.equals(dstBuf)) {
        fs.writeFileSync(dst, srcBuf);
        try {
          delete require.cache[require.resolve(`./${modFile}`)];
        } catch {}
      }
    }
  } catch {}
})();

const {
  getDeviceIdentity,
  updateDeviceConfig,
  deriveEdgeAuthToken,
  loadTheoCredentials,
  saveTheoCredentials,
  buildPairTokenBase64Url,
  inferRowOwnerDevice,
  rememberFleetHomes,
  buildPeerSnapshot,
  deriveStoreEndpoint,
  noteLocalUserActivity,
  getHostIdleMs,
  HOST_ROLE
} = require('./device-identity');
const { maybeApplyHubReleaseUpdate } = require('./bundle-updater');
const { readCachedPcSetupSummary, sanitizePublicPcSetupSummary } = require('./pc-setup');
const {
  readUnsavedWorkSummary,
  readFleetUnsavedWorkSummary,
  refreshUnsavedWork,
  formatUnsavedDigestLine,
  sanitizePeerUnsavedWork,
  unsavedWorkSig
} = require('./unsaved-work');

function withoutUnsavedWork(dev) {
  if (!dev || typeof dev !== 'object' || !('unsavedWork' in dev)) return dev;
  const { unsavedWork: _omit, ...rest } = dev;
  return rest;
}

// Equal hosts: a peer counts as online while its last published state is younger than this.
const PEER_FRESH_MS = 90000;

function isPeerEntryFresh(entry, nowMs = Date.now()) {
  const stamp = Number(entry?.updatedAt || entry?.device?.lastSeen || 0);
  return stamp > 0 && nowMs - stamp < PEER_FRESH_MS;
}

// Who acts for the fleet this cycle. Exactly one host answers phone commands addressed to no PC and writes the
// shared `state` snapshot. No PC holds that duty by name: the store hands it to one host (`storeCoordinator`, from
// the get_control answer) and moves it when that host goes quiet.
//   deviceStates: the fleet map (device id -> entry), this host's own entry is ignored.
function decideFleetDuty({ selfDevId, storeCoordinator = null, deviceStates = {}, nowMs = Date.now() }) {
  const peerEntries = Object.entries(deviceStates || {}).filter(
    ([devId, entry]) => devId && devId !== selfDevId && entry && typeof entry === 'object'
  );
  const freshPeerEntries = peerEntries.filter(([, entry]) => isPeerEntryFresh(entry, nowMs));
  // A host still on a build from before equal hosts decides by itself that it leads and answers every such command
  // on its own. While one is online this host stands back, exactly as it did before, so nothing runs twice; the
  // rule stops mattering once that host is updated. The store reports one from what only such a host writes,
  // timed on the store's clock (`legacyLead`); the role it publishes is a second, weaker sign.
  const legacyLeadOnline =
    storeCoordinator?.legacyLead === true ||
    freshPeerEntries.some(([, entry]) => entry?.device?.role === 'primary');
  const storeHolder =
    storeCoordinator && typeof storeCoordinator.deviceId === 'string' ? storeCoordinator.deviceId : '';
  let isCoordinator = false;
  let coordinatorDeviceId = '';
  if (legacyLeadOnline) {
    isCoordinator = false;
  } else if (storeHolder) {
    isCoordinator = storeHolder === selfDevId;
    coordinatorDeviceId = storeHolder;
  } else {
    // A store without the duty (older Worker): the lowest device id among the hosts that are online.
    const onlineIds = freshPeerEntries
      .map(([devId]) => devId)
      .concat(selfDevId)
      .sort();
    isCoordinator = onlineIds[0] === selfDevId;
    coordinatorDeviceId = onlineIds[0];
  }
  const onlinePeerThreadIds = new Set();
  for (const [, entry] of freshPeerEntries) {
    const peerRows = Array.isArray(entry?.snapshot?.rows)
      ? entry.snapshot.rows
      : Array.isArray(entry?.rows)
        ? entry.rows
        : [];
    for (const pr of peerRows) {
      if (pr && pr.id) onlinePeerThreadIds.add(String(pr.id));
    }
  }
  return { isCoordinator, coordinatorDeviceId, legacyLeadOnline, onlinePeerThreadIds };
}

// Is a queued phone command this host's to run?
//   - addressed to this host by id: yes; addressed to another host: no;
//   - about a session this host has: yes;
//   - addressed to no host: only the coordinator, and not when the session belongs to a peer that is online.
function classifyQueuedCommand(cmd, { selfDevId, localThreadIds, duty }) {
  const targetDev = String(cmd?.targetDeviceId || '').trim();
  const targetThread = String(cmd?.threadId || cmd?.sessionId || cmd?.id || '').trim();
  const explicitlyForMe = Boolean(targetDev) && targetDev === selfDevId;
  const explicitlyForOther = Boolean(targetDev) && targetDev !== 'auto' && targetDev !== selfDevId;
  const isSessionThread = Boolean(targetThread) && !targetThread.startsWith('cmd-');
  const ownsThread = isSessionThread && Boolean(localThreadIds?.has(targetThread));
  const onlinePeerOwnsThread =
    isSessionThread && !ownsThread && Boolean(duty?.onlinePeerThreadIds?.has(targetThread));
  const untargeted = !targetDev || targetDev === 'auto';
  const mine =
    !explicitlyForOther &&
    (explicitlyForMe || ownsThread || (untargeted && Boolean(duty?.isCoordinator) && !onlinePeerOwnsThread));
  return { mine, explicitlyForMe, ownsThread };
}
const { attachWebSocketServer } = require('./ws-server');
const {
  TheoDirectRunner,
  mirrorCliConversationToIde,
  hasIdeConversationOnDisk,
  VALID_CLAUDE_PERMISSION_MODES,
  normalizeExplicitClaudeMode,
  resolveClaudePermissionModePaths,
  readLocalClaudePermissionCache,
  readDiskSharedClaudePermissionFile,
  resolveSharedClaudePermissionModeInfo,
  writeSharedClaudePermissionMode
} = require('./direct-runner');
const { TheoEdgeRelayClient } = require('./edge-relay-client');

const execFileAsync = promisify(execFile);
const webcrypto = crypto.webcrypto || globalThis.crypto;

const DEFAULT_PORT = 4318;

const VAPID_KEYS = {
  pub: 'BKAC6gWORFSoi6Yf7XuS3voZnBgflXmG1GzW0K1pt4hcNoY7FNYPK-Jn-gAghKvphbSM_-ieA6U8w0E9yEgKB68',
  d: 'MS5ta1KAESpycusDW8d1NMaj3fxc_oNO_F0V23oh5aA',
  x: 'oALqBY5EVKiLph_te5Le-hmcGB-VeYbUbNbQrWm3iFw',
  y: 'NoY7FNYPK-Jn-gAghKvphbSM_-ieA6U8w0E9yEgKB68',
  sub: 'mailto:hussein@bhfirms.com'
};

function b64uEncBuf(buf) {
  return Buffer.from(buf)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function b64uDecBuf(str) {
  const s = String(str || '').replace(/-/g, '+').replace(/_/g, '/');
  return new Uint8Array(Buffer.from(s, 'base64'));
}

function concatU8(...arrs) {
  const total = arrs.reduce((acc, a) => acc + a.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const a of arrs) {
    out.set(a, off);
    off += a.length;
  }
  return out;
}

async function hkdfExtractAndExpandNode(salt, ikm, info, len) {
  const key = await webcrypto.subtle.importKey(
    'raw',
    salt.length ? salt : new Uint8Array(32),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const prk = new Uint8Array(await webcrypto.subtle.sign('HMAC', key, ikm));
  const prkKey = await webcrypto.subtle.importKey(
    'raw',
    prk,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const okm = new Uint8Array(
    await webcrypto.subtle.sign('HMAC', prkKey, concatU8(info, new Uint8Array([1])))
  );
  return okm.slice(0, len);
}

async function signVapidNode(endpointUrl, customExpSec = 0) {
  const u = new URL(endpointUrl);
  const aud = `${u.protocol}//${u.host}`;
  const exp =
    Number(customExpSec) > 0
      ? Math.floor(Number(customExpSec))
      : Math.floor(Date.now() / 1000) + 12 * 3600;
  const enc = new TextEncoder();
  const hdr = b64uEncBuf(enc.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const pld = b64uEncBuf(enc.encode(JSON.stringify({ aud, exp, sub: VAPID_KEYS.sub })));
  const unsigned = `${hdr}.${pld}`;
  const key = await webcrypto.subtle.importKey(
    'jwk',
    {
      kty: 'EC',
      crv: 'P-256',
      x: VAPID_KEYS.x,
      y: VAPID_KEYS.y,
      d: VAPID_KEYS.d,
      ext: true
    },
    { name: 'ECDSA', namedCurve: 'P-256' },
    false,
    ['sign']
  );
  const sig = new Uint8Array(
    await webcrypto.subtle.sign(
      { name: 'ECDSA', hash: 'SHA-256' },
      key,
      enc.encode(unsigned)
    )
  );
  return `vapid t=${unsigned}.${b64uEncBuf(sig)}, k=${VAPID_KEYS.pub}`;
}

async function encryptWebPushNode(subKeys, payloadObj) {
  const enc = new TextEncoder();
  const uaPub = b64uDecBuf(subKeys.p256dh);
  const authSecret = b64uDecBuf(subKeys.auth);
  const asKeyPair = await webcrypto.subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveBits']
  );
  const asPubRaw = new Uint8Array(
    await webcrypto.subtle.exportKey('raw', asKeyPair.publicKey)
  );
  const uaPubKey = await webcrypto.subtle.importKey(
    'raw',
    uaPub,
    { name: 'ECDH', namedCurve: 'P-256' },
    false,
    []
  );
  const ecdhSecret = new Uint8Array(
    await webcrypto.subtle.deriveBits(
      { name: 'ECDH', public: uaPubKey },
      asKeyPair.privateKey,
      256
    )
  );
  const keyInfo = concatU8(enc.encode('WebPush: info\0'), uaPub, asPubRaw);
  const ikm = await hkdfExtractAndExpandNode(authSecret, ecdhSecret, keyInfo, 32);
  const salt = webcrypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdfExtractAndExpandNode(
    salt,
    ikm,
    enc.encode('Content-Encoding: aes128gcm\0'),
    16
  );
  const nonce = await hkdfExtractAndExpandNode(
    salt,
    ikm,
    enc.encode('Content-Encoding: nonce\0'),
    12
  );
  const aesKey = await webcrypto.subtle.importKey(
    'raw',
    cek,
    { name: 'AES-GCM' },
    false,
    ['encrypt']
  );
  const plainBytes = enc.encode(JSON.stringify(payloadObj));
  const padded = concatU8(plainBytes, new Uint8Array([2]));
  const cipher = new Uint8Array(
    await webcrypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, aesKey, padded)
  );
  const rs = new Uint8Array(4);
  new DataView(rs.buffer).setUint32(0, 4096, false);
  const idlen = new Uint8Array([asPubRaw.length]);
  return Buffer.from(concatU8(salt, rs, idlen, asPubRaw, cipher)).toString('base64');
}

function httpsBinaryPushRequest(endpointUrl, vapidAuth, bodyB64, ttlSec = 14400) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(endpointUrl);
    } catch (err) {
      reject(err);
      return;
    }
    const bodyBuf = Buffer.from(bodyB64, 'base64');
    const req = https.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: parsed.pathname + parsed.search,
        method: 'POST',
        headers: {
          Authorization: vapidAuth,
          'Content-Encoding': 'aes128gcm',
          'Content-Type': 'application/octet-stream',
          'Content-Length': bodyBuf.length,
          TTL: String(ttlSec),
          Urgency: 'high'
        },
        timeout: 10000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const status = res.statusCode || 0;
          if (status >= 200 && status < 300) {
            resolve({ ok: true, status });
          } else {
            const text = Buffer.concat(chunks).toString('utf8').slice(0, 200);
            reject(new Error(`Push HTTP ${status}: ${text}`));
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error('Push request timeout')));
    req.on('error', reject);
    req.write(bodyBuf);
    req.end();
  });
}

const BHFIRMS_WORKSPACES = [
  { id: 'resort-operations', name: 'Hospitality Operations', rel: ['bhfirms', 'resort-operations'], group: 'Operations' },
  { id: 'trading-operations', name: 'Trading Operations', rel: ['bhfirms', 'trading-operations'], group: 'Operations' },
  { id: 'manufacturing-operations', name: 'Manufacturing Operations', rel: ['bhfirms', 'manufacturing-operations'], group: 'Operations' },
  { id: 'holding-operations', name: 'Holding Operations', rel: ['bhfirms', 'holding-operations'], group: 'Operations' },
  { id: 'realestate-operations', name: 'Real Estate Operations', rel: ['bhfirms', 'realestate-operations'], group: 'Operations' },
  { id: 'insurance-operations', name: 'Insurance Operations', rel: ['bhfirms', 'insurance-operations'], group: 'Operations' },
  { id: 'theo-hub', name: 'THEO Hub Extension', rel: ['bhfirms', 'theo-hub'], group: 'Platform' },
  { id: 'theo', name: 'THEO Remote PWA', rel: ['bhfirms', 'theo'], group: 'Platform' },
  { id: 'planner', name: 'Planner PWA', rel: ['bhfirms', 'command'], group: 'Platform' },
  { id: 'isabi', name: 'ISABI Systems PWA', rel: ['bhfirms', 'isabi'], group: 'Platform' },
  { id: 'isabi-app', name: 'ISABI Command Center', rel: ['bhfirms', 'isabi-app'], group: 'Platform' },
  { id: 'theo-memory', name: 'THEO Memory', rel: ['bhfirms', 'memory'], gitDirRel: ['.gitdirs', 'claude-memory'], group: 'Platform' },
  { id: 'codex-hub', name: 'Codex Hub Extension', rel: ['bhfirms', 'codex-hub'], group: 'Platform' },
  { id: 'agent-board', name: 'Agent Board Extension', rel: ['bhfirms', 'agent-board'], group: 'Platform' },
  { id: 'pos', name: 'Custom POS PWA', rel: ['bhfirms', 'pos'], group: 'Edge PWAs' },
  { id: 'attendance', name: 'Attendance Kiosk PWA', rel: ['bhfirms', 'attendance'], group: 'Edge PWAs' },
  { id: 'fitness', name: 'overeaten Fitness PWA', rel: ['bhfirms', 'fitness'], group: 'Edge PWAs' }
];

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json; charset=utf-8'
};

function getLanIps() {
  const out = [];
  try {
    const nets = os.networkInterfaces() || {};
    for (const [name, list] of Object.entries(nets)) {
      for (const iface of list || []) {
        if (iface && iface.family === 'IPv4' && !iface.internal && iface.address) {
          out.push({ name, address: iface.address });
        }
      }
    }
  } catch {}
  return out;
}

function loadRelayConfig(extensionPath) {
  const creds = loadTheoCredentials();
  if (creds.cloudUrl || creds.effectiveEdgeSecret) {
    return {
      url: creds.cloudUrl || '',
      key: creds.cloudKey || '',
      edgeAccessKey: creds.edgeAccessKey || '',
      effectiveEdgeSecret: creds.effectiveEdgeSecret || '',
      edgeUrl: String(creds.edgeRelayUrl || '').trim(),
      storeId: '',
      port: Number(creds.port || DEFAULT_PORT),
      allowLan: Boolean(creds.allowLan),
      pwaUrl: 'https://husseinbdeir.github.io/theo/'
    };
  }
  const candidates = [
    path.join(extensionPath || __dirname, 'remote-relay.json'),
    path.join(os.homedir(), 'bhfirms', 'theo-hub', 'remote-relay.json'),
    path.join(os.homedir(), 'bhfirms', 'antigravity-hub', 'remote-relay.json')
  ];
  for (const candidate of candidates) {
    try {
      if (fs.existsSync(candidate)) {
        const raw = JSON.parse(fs.readFileSync(candidate, 'utf8'));
        const url = raw.u ? Buffer.from(raw.u, 'base64').toString('utf8') : raw.url || '';
        const key = raw.k ? Buffer.from(raw.k, 'base64').toString('utf8') : raw.key || '';
        return {
          url,
          key,
          edgeAccessKey: '',
          effectiveEdgeSecret: key,
          edgeUrl: String(raw.edgeUrl || '').trim(),
          storeId: raw.storeId || '',
          port: Number(raw.port || DEFAULT_PORT),
          allowLan: Boolean(raw.allowLan),
          pwaUrl: raw.pwaUrl || 'https://husseinbdeir.github.io/theo/'
        };
      }
    } catch {}
  }
  return {
    url: '',
    key: '',
    edgeAccessKey: '',
    effectiveEdgeSecret: '',
    edgeUrl: '',
    storeId: '',
    port: DEFAULT_PORT,
    allowLan: false,
    pwaUrl: 'https://husseinbdeir.github.io/theo/'
  };
}

// Commands this host has taken, so the same command is never run twice here: once from the store queue and once
// directly, or again after a restart. Kept as long as the store keeps its own claims (30 days), which is longer than
// a command can sit in the queue. THEO_CLAIMED_CMDS_PATH points the tests at a file of their own.
const CLAIMED_CMDS_FILE = path.join(os.homedir(), '.theo', 'claimed-cmds.json');
const CLAIMED_CMDS_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const CLAIM_INFLIGHT_LEASE_MS = 120 * 1000;

function claimedCmdsPath() {
  return process.env.THEO_CLAIMED_CMDS_PATH || CLAIMED_CMDS_FILE;
}

function readAndPruneClaimedCmdsMap(filePath, now, ttlMs = CLAIMED_CMDS_TTL_MS) {
  let map = {};
  if (fs.existsSync(filePath)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        map = parsed;
      }
    } catch {
      map = {};
    }
  }
  for (const [k, entry] of Object.entries(map)) {
    if (typeof entry === 'number' && Number.isFinite(entry) && entry > 0) {
      if (now - entry > ttlMs) delete map[k];
    } else if (entry && typeof entry === 'object' && !Array.isArray(entry)) {
      const leaseUntil = Number(entry.leaseUntil || 0);
      if (!Number.isFinite(leaseUntil) || leaseUntil <= now) {
        delete map[k];
      }
    } else {
      delete map[k];
    }
  }
  return map;
}

function writeClaimedCmdsMapAtomic(filePath, map) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const tmp = `${filePath}.${process.pid}.${Math.random().toString(16).slice(2, 8)}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(map), { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(tmp, filePath);
}

function beginCloudCommandLease(cmdKey, leaseMs = CLAIM_INFLIGHT_LEASE_MS, ttlMs = CLAIMED_CMDS_TTL_MS) {
  const cleanKey = String(cmdKey || '').trim();
  if (!cleanKey) return false;
  const now = Date.now();
  const filePath = claimedCmdsPath();
  try {
    const map = readAndPruneClaimedCmdsMap(filePath, now, ttlMs);
    if (map[cleanKey]) {
      return false;
    }
    const safeLeaseMs = Math.max(50, Math.floor(Number(leaseMs) || CLAIM_INFLIGHT_LEASE_MS));
    map[cleanKey] = { at: now, leaseUntil: now + safeLeaseMs };
    writeClaimedCmdsMapAtomic(filePath, map);
    return true;
  } catch {
    return true;
  }
}

function completeCloudCommandOnce(cmdKey, ttlMs = CLAIMED_CMDS_TTL_MS) {
  const cleanKey = String(cmdKey || '').trim();
  if (!cleanKey) return false;
  const now = Date.now();
  const filePath = claimedCmdsPath();
  try {
    const map = readAndPruneClaimedCmdsMap(filePath, now, ttlMs);
    map[cleanKey] = now;
    writeClaimedCmdsMapAtomic(filePath, map);
    return true;
  } catch {
    return false;
  }
}

function isCloudCommandSealed(cmdKey, ttlMs = CLAIMED_CMDS_TTL_MS) {
  const cleanKey = String(cmdKey || '').trim();
  if (!cleanKey) return false;
  const now = Date.now();
  const filePath = claimedCmdsPath();
  try {
    const map = readAndPruneClaimedCmdsMap(filePath, now, ttlMs);
    return typeof map[cleanKey] === 'number' && map[cleanKey] > 0;
  } catch {
    return false;
  }
}

function claimCloudCommandOnce(cmdKey, ttlMs = CLAIMED_CMDS_TTL_MS) {
  const cleanKey = String(cmdKey || '').trim();
  if (!cleanKey) return false;
  const now = Date.now();
  const filePath = claimedCmdsPath();
  try {
    const map = readAndPruneClaimedCmdsMap(filePath, now, ttlMs);
    if (map[cleanKey]) {
      return false;
    }
    map[cleanKey] = now;
    writeClaimedCmdsMapAtomic(filePath, map);
    return true;
  } catch {
    return true;
  }
}

function unclaimCloudCommand(cmdKey) {
  const cleanKey = String(cmdKey || '').trim();
  if (!cleanKey) return;
  const filePath = claimedCmdsPath();
  try {
    if (!fs.existsSync(filePath)) return;
    const map = JSON.parse(fs.readFileSync(filePath, 'utf8')) || {};
    if (map[cleanKey]) {
      delete map[cleanKey];
      writeClaimedCmdsMapAtomic(filePath, map);
    }
  } catch {}
}

function constantTimeTokenMatch(candidate, expected) {
  const a = String(candidate || '').trim();
  const b = String(expected || '').trim();
  if (!a || !b) return false;
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function isPathInsideRoot(targetPath, rootDir) {
  const resolvedRoot = path.resolve(rootDir);
  const resolvedTarget = path.resolve(targetPath);
  const normRoot = process.platform === 'win32' ? resolvedRoot.toLowerCase() : resolvedRoot;
  const normTarget = process.platform === 'win32' ? resolvedTarget.toLowerCase() : resolvedTarget;
  return normTarget === normRoot || normTarget.startsWith(normRoot + path.sep);
}

function isRealPathInsideRoot(targetPath, rootDir) {
  if (!isPathInsideRoot(targetPath, rootDir)) return false;
  try {
    if (!fs.existsSync(rootDir) || !fs.existsSync(targetPath)) return false;
    const realRoot = fs.realpathSync(rootDir);
    const realTarget = fs.realpathSync(targetPath);
    const normRoot = process.platform === 'win32' ? realRoot.toLowerCase() : realRoot;
    const normTarget = process.platform === 'win32' ? realTarget.toLowerCase() : realTarget;
    return normTarget === normRoot || normTarget.startsWith(normRoot + path.sep);
  } catch {
    return false;
  }
}

const SENSITIVE_PREVIEW_SEGMENT_RE =
  /^(\.theo|\.claude|\.ssh|\.aws|\.git|\.gitdirs|\.gnupg|\.kube|\.azure|\.system_generated)$/i;
const SENSITIVE_PREVIEW_FILE_RE =
  /^(\.env(\..+)?|\.dev\.vars(\..+)?|\.npmrc|\.pypirc|\.netrc|.*\.tfstate(\.backup)?|.*credentials.*|.*secret.*|.*private[_-]?key.*|id_(rsa|dsa|ecdsa|ed25519)(\.pub)?|.*\.(pem|key|pfx|p12|kdbx|jks|keystore)|.*\.(sqlite|sqlite3|db)(-wal|-shm)?)$/i;

function isSensitivePreviewPath(candidatePath) {
  const raw = String(candidatePath || '').trim();
  if (!raw || raw.includes('\0')) return true;
  const clean = raw.replace(/^file:\/\/\/?/i, '').replace(/#.*$/, '');
  const segments = clean.split(/[\\/]+/).filter(Boolean);
  for (const seg of segments) {
    if (seg === '..') return true;
    if (SENSITIVE_PREVIEW_SEGMENT_RE.test(seg)) return true;
  }
  const base = segments[segments.length - 1] || '';
  if (!base || SENSITIVE_PREVIEW_FILE_RE.test(base)) return true;
  return false;
}

function parseFileTargetAndLineRange(rawInput) {
  let raw = String(rawInput || '').trim();
  let startLine = 0;
  let endLine = 0;
  const hashMatch = raw.match(/#L(\d+)(?:-L?(\d+))?$/i);
  if (hashMatch) {
    startLine = Math.max(1, parseInt(hashMatch[1], 10) || 0);
    endLine = Math.max(startLine, parseInt(hashMatch[2] || hashMatch[1], 10) || startLine);
    raw = raw.slice(0, hashMatch.index);
  } else {
    const colonMatch = raw.match(/:(\d+)(?:-(\d+))?$/);
    if (colonMatch && !/^[a-zA-Z]:$/.test(raw.slice(0, colonMatch.index + 1))) {
      startLine = Math.max(1, parseInt(colonMatch[1], 10) || 0);
      endLine = Math.max(startLine, parseInt(colonMatch[2] || colonMatch[1], 10) || startLine);
      raw = raw.slice(0, colonMatch.index);
    }
  }
  if (/^file:\/\//i.test(raw)) {
    try {
      raw = decodeURIComponent(raw.replace(/^file:\/\/\/?/i, ''));
      if (process.platform !== 'win32' && !raw.startsWith('/')) raw = '/' + raw;
    } catch {
      raw = raw.replace(/^file:\/\/\/?/i, '');
    }
  }
  return { cleanPath: raw.trim(), startLine, endLine };
}

function formatModelDisplayName(rawModel, provider = 'antigravity', effortHint = '') {
  const s = String(rawModel || '').trim();
  const low = s.toLowerCase();
  const effLow = String(effortHint || '').trim().toLowerCase();
  const inferredEffort =
    effLow === 'low' || low.includes('(low)') || low.endsWith('-low')
      ? 'Low'
      : effLow === 'medium' || low.includes('(medium)') || low.endsWith('-medium')
        ? 'Medium'
        : effLow === 'high' || low.includes('(high)') || low.endsWith('-high')
          ? 'High'
          : '';
  const suffix = inferredEffort ? ` (${inferredEffort})` : '';
  if (low === 'model_placeholder_m417' || low.includes('argon-high')) {
    return `Gemini 4 Argon (${inferredEffort || 'High'})`;
  }
  if (low === 'model_placeholder_m418' || low.includes('argon-medium')) {
    return `Gemini 4 Argon (${inferredEffort || 'Medium'})`;
  }
  if (low === 'model_placeholder_m419' || low.includes('argon-low')) {
    return `Gemini 4 Argon (${inferredEffort || 'Low'})`;
  }
  if (low === 'model_placeholder_m318' || low.includes('flash-high')) {
    return `Gemini 3.8 Flash (${inferredEffort || 'High'})`;
  }
  if (low === 'model_placeholder_m319' || low.includes('flash-medium')) {
    return `Gemini 3.8 Flash (${inferredEffort || 'Medium'})`;
  }
  if (low === 'model_placeholder_m320' || low.includes('flash-low')) {
    return `Gemini 3.8 Flash (${inferredEffort || 'Low'})`;
  }
  if (low === 'model_placeholder_m402' || low.includes('opus-5-5-high')) {
    return `Claude Opus 5.5 (${inferredEffort || 'High'})`;
  }
  if (low === 'model_placeholder_m401' || low.includes('opus-5-5-medium')) {
    return `Claude Opus 5.5 (${inferredEffort || 'Medium'})`;
  }
  if (low === 'model_placeholder_m400' || low.includes('opus-5-5-low')) {
    return `Claude Opus 5.5 (${inferredEffort || 'Low'})`;
  }
  if (low === 'model_placeholder_m405' || low.includes('sonnet-5-5-high')) {
    return `Claude Sonnet 5.5 (${inferredEffort || 'High'})`;
  }
  if (low === 'model_placeholder_m404' || low.includes('sonnet-5-5-medium')) {
    return `Claude Sonnet 5.5 (${inferredEffort || 'Medium'})`;
  }
  if (low === 'model_placeholder_m403' || low.includes('sonnet-5-5-low')) {
    return `Claude Sonnet 5.5 (${inferredEffort || 'Low'})`;
  }
  if (low === 'model_openai_gpt_oss_120b_medium' || low.includes('gpt-oss-120b')) {
    return 'GPT-OSS 120B (Medium)';
  }
  if (!s || low === 'antigravity' || low === 'gemini' || low.includes('3.1')) {
    return provider === 'claude' ? `Claude Opus 4.7 (1M)${suffix}` : `Gemini 4 Argon (${inferredEffort || 'High'})`;
  }
  if (low.includes('3.8') || low.includes('flash')) {
    return `Gemini 3.8 Flash (${inferredEffort || 'High'})`;
  }
  if (low.includes('argon')) {
    return `Gemini 4 Argon (${inferredEffort || 'High'})`;
  }
  if (low.includes('opus-5-5') || low.includes('opus 5.5')) {
    return `Claude Opus 5.5 (${inferredEffort || 'High'})`;
  }
  if (low.includes('sonnet-5-5') || low.includes('sonnet 5.5')) {
    return `Claude Sonnet 5.5 (${inferredEffort || 'High'})`;
  }
  if (low.includes('fable-5-1') || low.includes('fable 5.1') || low.includes('fable')) {
    return `Fable 5.1${suffix}`;
  }
  if (low.includes('opus-4-7') || low.includes('opus 4.7')) {
    return `Claude Opus 4.7 (1M)${suffix}`;
  }
  if (low.includes('sonnet-4-6') || low.includes('sonnet 4.6')) {
    return `Claude Sonnet 4.6${suffix}`;
  }
  if (low.includes('haiku-4-5') || low.includes('haiku 4.5')) {
    return `Claude Haiku 4.5${suffix}`;
  }
  return s;
}

function resolveAntigravityPlanModelEnum(rawModel, effortHint = '') {
  const s = String(rawModel || '').trim();
  if (!s && !effortHint) return '';
  if (/^MODEL_(?:PLACEHOLDER_M\d+|OPENAI_GPT_OSS_120B_MEDIUM)$/i.test(s)) {
    return s.toUpperCase();
  }
  const low = s.toLowerCase();
  const effLow = String(effortHint || '').trim().toLowerCase();
  const effort =
    effLow === 'low' || low.includes('(low)') || low.endsWith('-low')
      ? 'low'
      : effLow === 'medium' || low.includes('(medium)') || low.endsWith('-medium')
        ? 'medium'
        : 'high';
  if (low.includes('gpt-oss-120b')) return 'MODEL_OPENAI_GPT_OSS_120B_MEDIUM';
  if (low.includes('opus-5-5') || low.includes('opus 5.5')) {
    return effort === 'low'
      ? 'MODEL_PLACEHOLDER_M400'
      : effort === 'medium'
        ? 'MODEL_PLACEHOLDER_M401'
        : 'MODEL_PLACEHOLDER_M402';
  }
  if (low.includes('sonnet-5-5') || low.includes('sonnet 5.5')) {
    return effort === 'low'
      ? 'MODEL_PLACEHOLDER_M403'
      : effort === 'medium'
        ? 'MODEL_PLACEHOLDER_M404'
        : 'MODEL_PLACEHOLDER_M405';
  }
  if (low.includes('3.8') || low.includes('flash')) {
    return effort === 'low'
      ? 'MODEL_PLACEHOLDER_M320'
      : effort === 'medium'
        ? 'MODEL_PLACEHOLDER_M319'
        : 'MODEL_PLACEHOLDER_M318';
  }
  if (low.includes('argon') || low.includes('gemini')) {
    return effort === 'low'
      ? 'MODEL_PLACEHOLDER_M419'
      : effort === 'medium'
        ? 'MODEL_PLACEHOLDER_M418'
        : 'MODEL_PLACEHOLDER_M417';
  }
  return '';
}

function inferMaxContextTokens(provider, modelLabel = '') {
  if (provider !== 'claude') {
    return 256000;
  }
  const low = String(modelLabel || '').toLowerCase();
  if (!low) return 1000000;
  if (
    low.includes('[1m]') ||
    low.includes('1m') ||
    low.includes('fable') ||
    low.includes('mythos') ||
    low.includes('opus-4-7') ||
    low.includes('opus 4.7') ||
    low.includes('opus-4-8') ||
    low.includes('opus 4.8') ||
    low.includes('sonnet-5') ||
    low.includes('sonnet 5') ||
    low.includes('opus-5') ||
    low.includes('opus 5') ||
    /\b5\.[0-9]/.test(low)
  ) {
    return 1000000;
  }
  if (
    low.includes('haiku') ||
    low.includes('4-5') ||
    low.includes('4.5') ||
    low.includes('4-6') ||
    low.includes('4.6') ||
    low.includes('sonnet-4') ||
    low.includes('opus-4')
  ) {
    return 200000;
  }
  return 1000000;
}

function shortenPathForDisplay(rawPath) {
  const s = String(rawPath || '').trim().replace(/^file:\/\/\/?/i, '');
  if (!s) return { file: '', relPath: '' };
  const parts = s.split(/[\\/]/).filter(Boolean);
  const file = parts[parts.length - 1] || s;
  const relPath = parts.length > 2 ? parts.slice(-3).join('/') : parts.join('/');
  return { file, relPath };
}

function countLines(str) {
  if (!str) return 0;
  return String(str).split(/\r?\n/).length;
}

function buildCompactDiffSnippet(oldStr, newStr, maxLines = 14) {
  const oldLines = String(oldStr || '')
    .split(/\r?\n/)
    .filter((l) => l.trim().length > 0)
    .slice(0, Math.floor(maxLines / 2))
    .map((l) => `- ${l.slice(0, 110)}`);
  const newLines = String(newStr || '')
    .split(/\r?\n/)
    .filter((l) => l.trim().length > 0)
    .slice(0, Math.ceil(maxLines / 2))
    .map((l) => `+ ${l.slice(0, 110)}`);
  return [...oldLines, ...newLines].join('\n').slice(0, 900);
}

function enrichToolCall(rawName, args = {}, resultText = '') {
  const name = String(rawName || 'tool')
    .trim()
    .replace(/^default_api:/i, '');
  const low = name.toLowerCase();
  const rawPath =
    args.Path ||
    args.TargetFile ||
    args.AbsolutePath ||
    args.file_path ||
    args.path ||
    args.DirectoryPath ||
    args.SearchPath ||
    '';
  const { file, relPath } = shortenPathForDisplay(rawPath);

  let kind = 'tool';
  let label = args.toolAction || name;
  let summary =
    args.toolSummary ||
    args.Description ||
    args.Instruction ||
    args.description ||
    '';
  let lineRange = '';
  let addedLines = 0;
  let removedLines = 0;
  let snippet = '';
  let subagentRole = '';
  let subagentType = '';
  let subagentPrompt = '';
  let subagentConversationId = '';

  const startLine = Number(args.StartLine || args.offset || 0);
  const endLine = Number(args.EndLine || (startLine && args.limit ? startLine + Number(args.limit) : 0));
  if (startLine > 0 && endLine >= startLine) {
    lineRange = `L${startLine}–${endLine}`;
  } else if (startLine > 0) {
    lineRange = `L${startLine}`;
  }

  if (
    low === 'invoke_subagent' ||
    low === 'agent' ||
    low === 'task' ||
    low === 'dispatch_agent'
  ) {
    kind = 'subagent';
    label = 'Spawned Agent';
    subagentRole = String(
      args.Role || args.description || args.subagent_type || args.TypeName || 'Side Agent'
    ).trim();
    subagentType = String(args.TypeName || args.subagent_type || args.Model || 'agent').trim();
    subagentPrompt = String(args.Prompt || args.prompt || '').trim().slice(0, 800);
    const cidMatch =
      String(resultText || '').match(/"conversationId"\s*:\s*"([a-zA-Z0-9_-]{8,64})"/) ||
      String(resultText || '').match(/conversationId\s*[:=]\s*([a-zA-Z0-9_-]{8,64})/i) ||
      String(resultText || '').match(/agentId\s*[:=]\s*"?([a-zA-Z0-9_-]{6,64})"?/i);
    if (cidMatch) {
      subagentConversationId = cidMatch[1];
    }
    summary = subagentRole || `Subagent (${subagentType})`;
    const cleanRes = String(resultText || '')
      .replace(/^Created At:.*\n/gm, '')
      .replace(/^Completed At:.*\n/gm, '')
      .trim();
    snippet = [
      subagentPrompt ? `Task: ${subagentPrompt.slice(0, 460)}` : '',
      cleanRes ? `Result: ${cleanRes.slice(0, 380)}` : ''
    ]
      .filter(Boolean)
      .join('\n\n')
      .slice(0, 900);
  } else if (low === 'define_subagent') {
    kind = 'subagent';
    label = 'Defined Agent';
    subagentType = String(args.Name || 'custom').trim();
    subagentRole = String(args.Name || 'Custom Subagent').trim();
    summary = String(args.Description || args.Name || 'Defined custom subagent').slice(0, 120);
    snippet = String(args.Description || args.SystemPrompt || '').slice(0, 600);
  } else if (low === 'send_message' && (args.Recipient || args.Message)) {
    kind = 'subagent';
    label = 'Messaged Agent';
    subagentConversationId = String(args.Recipient || '').trim();
    subagentRole = subagentConversationId ? `Agent ${subagentConversationId.slice(0, 8)}` : 'Side Agent';
    subagentPrompt = String(args.Message || '').trim().slice(0, 600);
    summary = subagentPrompt.split(/\r?\n/)[0].slice(0, 110) || 'Messaged subagent';
    snippet = subagentPrompt;
  } else if (low === 'schedule') {
    kind = 'timer';
    label = 'Scheduled';
    const dur = args.DurationSeconds ? `${args.DurationSeconds}s timer` : args.CronExpression || 'schedule';
    summary = `${dur}: ${String(args.Prompt || '').slice(0, 96)}`;
    snippet = String(args.Prompt || '').slice(0, 500);
  } else if (
    low === 'edit_file' ||
    low === 'replace_file_content' ||
    low === 'multi_replace_file_content' ||
    low === 'edit' ||
    low === 'multiedit'
  ) {
    kind = 'edit';
    label = 'Edited';
    if (Array.isArray(args.ReplacementChunks)) {
      for (const ch of args.ReplacementChunks) {
        removedLines += countLines(ch?.TargetContent);
        addedLines += countLines(ch?.ReplacementContent);
      }
      const first = args.ReplacementChunks[0];
      if (first) {
        snippet = buildCompactDiffSnippet(first.TargetContent, first.ReplacementContent);
        if (!lineRange && first.StartLine) {
          lineRange = first.EndLine ? `L${first.StartLine}–${first.EndLine}` : `L${first.StartLine}`;
        }
      }
    } else {
      const oldTxt = args.Target ?? args.TargetContent ?? args.old_string ?? '';
      const newTxt = args.Replacement ?? args.ReplacementContent ?? args.new_string ?? '';
      removedLines = countLines(oldTxt);
      addedLines = countLines(newTxt);
      snippet = buildCompactDiffSnippet(oldTxt, newTxt);
    }
    if (!summary) summary = file ? `Updated ${file}` : 'Edited file';
  } else if (low === 'write_file' || low === 'write_to_file' || low === 'write') {
    kind = 'write';
    label = 'Created';
    const content = args.Content ?? args.CodeContent ?? args.content ?? '';
    addedLines = countLines(content);
    snippet = String(content)
      .split(/\r?\n/)
      .slice(0, 12)
      .map((l) => `+ ${l.slice(0, 110)}`)
      .join('\n')
      .slice(0, 800);
    if (!summary) summary = file ? `Wrote ${file}` : 'Created file';
  } else if (
    low === 'read_file' ||
    low === 'view_file' ||
    low === 'read' ||
    low === 'view_file_outline' ||
    low === 'view_code_item'
  ) {
    kind = 'read';
    label = 'Viewed';
    if (!summary) summary = file ? `Read ${file}${lineRange ? ` (${lineRange})` : ''}` : 'Read file';
  } else if (low === 'run_command' || low === 'bash' || low === 'manage_task') {
    kind = 'cmd';
    label = 'Ran command';
    const cmdLine = String(args.CommandLine || args.command || '').trim();
    if (!summary) {
      summary = cmdLine.split(/\r?\n/)[0].slice(0, 90) || 'Terminal command';
    }
    const cleanOut = String(resultText || '')
      .replace(/^Created At:.*\n/gm, '')
      .replace(/^Completed At:.*\n/gm, '')
      .trim();
    snippet = [cmdLine ? `$ ${cmdLine.slice(0, 320)}` : '', cleanOut ? cleanOut.slice(-500) : '']
      .filter(Boolean)
      .join('\n')
      .slice(0, 900);
  } else if (low === 'grep_search' || low === 'find_by_name' || low === 'grep' || low === 'glob') {
    kind = 'search';
    label = 'Searched';
    const pat = args.Query || args.Pattern || args.pattern || '';
    if (!summary) summary = pat ? `Pattern "${String(pat).slice(0, 50)}"` : 'Searched workspace';
  }

  if (!summary) {
    summary = file || args.CommandLine || args.Url || name;
  }

  return {
    id: '',
    name,
    kind,
    label,
    summary: String(summary).slice(0, 140),
    action: String(args.toolAction || label || '').slice(0, 80),
    file,
    relPath,
    lineRange,
    addedLines,
    removedLines,
    snippet,
    subagentRole: String(subagentRole || '').slice(0, 100),
    subagentType: String(subagentType || '').slice(0, 60),
    subagentPrompt: String(subagentPrompt || '').slice(0, 600),
    subagentConversationId: String(subagentConversationId || '').slice(0, 64),
    target: String(rawPath || args.CommandLine || args.Url || '').slice(0, 260)
  };
}

function normalizeQuestionItems(rawQuestions) {
  let qs = [];
  if (Array.isArray(rawQuestions)) {
    qs = rawQuestions;
  } else if (typeof rawQuestions === 'string' && rawQuestions.trim().startsWith('[')) {
    try {
      const parsed = JSON.parse(rawQuestions.trim());
      if (Array.isArray(parsed)) qs = parsed;
    } catch {}
  }
  return qs
    .map((q) => {
      if (!q || typeof q !== 'object') return null;
      const question = String(q.question || q.Question || q.header || '').trim();
      const header = String(q.header || '').trim();
      const isMultiSelect = Boolean(
        q.isMultiSelect || q.is_multi_select || q.IsMultiSelect || q.multiSelect
      );
      const rawOpts = Array.isArray(q.options || q.Options) ? q.options || q.Options : [];
      const options = rawOpts
        .map((o, idx) => {
          const text =
            typeof o === 'string'
              ? o.trim()
              : String(o?.label || o?.text || o?.Text || o?.id || '').trim();
          const description =
            typeof o === 'object' && o ? String(o.description || '').trim() : '';
          const id =
            typeof o === 'object' && o && (o.id || o.Id)
              ? String(o.id || o.Id)
              : String(idx + 1);
          return text ? { id, text, description } : null;
        })
        .filter(Boolean);
      if (!question && !options.length) return null;
      return {
        question: question || 'Select an option',
        header,
        isMultiSelect,
        options
      };
    })
    .filter(Boolean);
}

function coalesceAssistantTurns(rawMessages, maxTurns = 80) {
  const coalesced = [];
  for (const msg of rawMessages) {
    if (!msg) continue;
    if (msg.role === 'checkpoint') {
      coalesced.push({ ...msg });
      continue;
    }
    const prev = coalesced[coalesced.length - 1];
    const prevHasAnsweredQuestion =
      Array.isArray(prev?.questions) && prev.questions.some((q) => q && q.answered);
    if (msg.role === 'assistant' && prev && prev.role === 'assistant' && !prevHasAnsweredQuestion) {
      if (msg.text) {
        prev.text = prev.text ? `${prev.text}\n\n${msg.text}` : msg.text;
      }
      if (msg.thinking) {
        prev.latestThinking = msg.thinking.slice(-1400);
        prev.thinking = prev.thinking ? `${prev.thinking}\n\n${msg.thinking}` : msg.thinking;
        if (prev.thinking.length > 6000) {
          prev.thinking = prev.thinking.slice(-6000);
        }
        const durSec = Math.max(1, Number(msg.thinkingDurationSec || 0));
        prev.thinkingDurationSec = Number(prev.thinkingDurationSec || 0) + durSec;
        prev.totalThoughtCount = Number(prev.totalThoughtCount || (prev.thoughtBlocks || []).length) + 1;
        prev.thoughtBlocks = [
          ...(prev.thoughtBlocks || []),
          {
            id: msg.id || `th-${(prev.thoughtBlocks || []).length}`,
            text: String(msg.thinking).slice(0, 2400),
            durationSec: durSec,
            createdAt: msg.createdAt || ''
          }
        ].slice(-16);
      }
      if (Array.isArray(msg.toolCalls) && msg.toolCalls.length) {
        prev.totalTurnTools = Number(prev.totalTurnTools || (prev.toolCalls || []).length) + msg.toolCalls.length;
        prev.toolCalls = [...(prev.toolCalls || []), ...msg.toolCalls].slice(-32);
      }
      if (Array.isArray(msg.artifacts) && msg.artifacts.length) {
        const mergedArts = [...(prev.artifacts || [])];
        for (const art of msg.artifacts) {
          if (!art) continue;
          const idx = mergedArts.findIndex((a) => a && a.file === art.file);
          if (idx >= 0) mergedArts[idx] = art;
          else mergedArts.push(art);
        }
        prev.artifacts = mergedArts.slice(-6);
      }
      if (Array.isArray(msg.questions) && msg.questions.length) {
        prev.questions = [...(prev.questions || []), ...msg.questions].slice(-6);
      }
      if (msg.createdAt) {
        prev.createdAt = msg.createdAt;
        if (prev.startedAt) {
          const sMs = Date.parse(prev.startedAt);
          const eMs = Date.parse(msg.createdAt);
          if (Number.isFinite(sMs) && Number.isFinite(eMs) && eMs > sMs) {
            prev.turnDurationSec = Math.min(7200, Math.max(1, Math.round((eMs - sMs) / 1000)));
          }
        }
      }
      if (msg.status) prev.status = msg.status;
      if (msg.model) prev.model = msg.model;
      prev.id = msg.id || prev.id;
    } else {
      const tools = Array.isArray(msg.toolCalls) ? [...msg.toolCalls] : [];
      const arts = Array.isArray(msg.artifacts) ? [...msg.artifacts] : [];
      const qs = Array.isArray(msg.questions) ? [...msg.questions] : [];
      const initDur = msg.thinking ? Math.max(1, Number(msg.thinkingDurationSec || 2)) : 0;
      const initThoughts = msg.thinking
        ? [
            {
              id: msg.id || 'th-0',
              text: String(msg.thinking).slice(0, 2400),
              durationSec: initDur,
              createdAt: msg.createdAt || ''
            }
          ]
        : [];
      coalesced.push({
        ...msg,
        startedAt: msg.startedAt || msg.createdAt || '',
        turnDurationSec: Number(msg.turnDurationSec || initDur || 0),
        thinkingDurationSec: initDur,
        totalThoughtCount: initThoughts.length,
        thoughtBlocks: initThoughts,
        latestThinking: msg.thinking ? msg.thinking.slice(-1400) : '',
        totalTurnTools: tools.length,
        toolCalls: tools.slice(-32),
        artifacts: arts.slice(-6),
        questions: qs.slice(-6)
      });
    }
  }
  return coalesced.slice(-maxTurns);
}

function readTranscriptTailUtf8(filePath, maxBytes = 1024 * 1024) {
  let fd = null;
  try {
    fd = fs.openSync(filePath, 'r');
    const st = fs.fstatSync(fd);
    const totalSize = Number(st.size || 0);
    if (totalSize <= 0) {
      return '';
    }
    if (totalSize <= maxBytes) {
      const buf = Buffer.allocUnsafe(totalSize);
      const bytesRead = fs.readSync(fd, buf, 0, totalSize, 0);
      return buf.toString('utf8', 0, bytesRead);
    }
    const startOffset = totalSize - maxBytes;
    const buf = Buffer.allocUnsafe(maxBytes);
    const bytesRead = fs.readSync(fd, buf, 0, maxBytes, startOffset);
    const slice = buf.toString('utf8', 0, bytesRead);
    const firstNewline = slice.indexOf('\n');
    return firstNewline >= 0 ? slice.slice(firstNewline + 1) : slice;
  } finally {
    if (fd !== null) {
      try {
        fs.closeSync(fd);
      } catch {}
    }
  }
}

function parseAntigravityTranscriptFile(filePath, maxTurns = 80) {
  if (!filePath) {
    return { messages: [], stats: { steps: 0, toolCalls: 0, estTokens: 0 }, usage: null };
  }
  let resolvedPath = filePath;
  if (/transcript\.jsonl$/i.test(filePath)) {
    const fullCandidate = filePath.replace(/transcript\.jsonl$/i, 'transcript_full.jsonl');
    try {
      if (fs.existsSync(fullCandidate) && fs.statSync(fullCandidate).size > 0) {
        resolvedPath = fullCandidate;
      }
    } catch {}
  }
  if (!fs.existsSync(resolvedPath)) {
    return { messages: [], stats: { steps: 0, toolCalls: 0, estTokens: 0 }, usage: null };
  }
  let raw = '';
  try {
    raw = readTranscriptTailUtf8(resolvedPath, 2048 * 1024);
  } catch {
    return { messages: [], stats: { steps: 0, toolCalls: 0, estTokens: 0 }, usage: null };
  }
  const lines = raw.split(/\r?\n/).filter(Boolean);
  const parsedSteps = [];
  for (let i = 0; i < lines.length; i += 1) {
    try {
      parsedSteps.push(JSON.parse(lines[i]));
    } catch {}
  }

  const rawMessages = [];
  let totalToolCalls = 0;
  let lastTurnTokens = 0;
  let lastUsageObj = null;
  let postCheckpointChars = 0;
  let lastStepAtMs = 0;

  for (let i = 0; i < parsedSteps.length; i += 1) {
    const step = parsedSteps[i];
    const type = String(step.type || '');
    const createdAt = step.created_at || '';
    const status = String(step.status || 'DONE');
    const curStepMs = createdAt ? Date.parse(createdAt) : 0;
    const stepDurationSec =
      Number.isFinite(curStepMs) && curStepMs > 0 && lastStepAtMs > 0 && curStepMs >= lastStepAtMs
        ? Math.min(180, Math.max(1, Math.round((curStepMs - lastStepAtMs) / 1000)))
        : 2;
    if (Number.isFinite(curStepMs) && curStepMs > 0) {
      lastStepAtMs = curStepMs;
    }

    if (type === 'CHECKPOINT') {
      const cpSummary = String(step.content || '').trim();
      const prevTok = lastTurnTokens;
      postCheckpointChars = cpSummary.length;
      lastTurnTokens = 0;
      if (cpSummary) {
        rawMessages.push({
          id: `agy-cp-${step.step_index ?? i}`,
          role: 'checkpoint',
          createdAt,
          status: 'DONE',
          text: cpSummary.slice(0, 6000),
          prevTokens: prevTok
        });
      }
    } else {
      postCheckpointChars +=
        String(step.content || '').length +
        String(step.thinking || '').length +
        (Array.isArray(step.tool_calls) ? JSON.stringify(step.tool_calls).length : 0);
    }

    const stepIn = Number(step.input_tokens || 0);
    const stepCache = Number(step.cache_read_tokens || 0);
    const stepOut = Number(step.output_tokens || 0);
    if (stepIn > 0 || stepCache > 0) {
      lastTurnTokens = stepIn + stepCache + stepOut;
      lastUsageObj = {
        inputTokens: stepIn,
        cacheReadTokens: stepCache,
        outputTokens: stepOut
      };
    }

    if (type === 'USER_INPUT') {
      let text = String(step.content || '').trim();
      const match = text.match(/<USER_REQUEST>([\s\S]*?)<\/USER_REQUEST>/i);
      if (match) {
        text = match[1].trim();
      } else if (text.includes('<CONTEXT_SUMMARY>')) {
        continue;
      }
      if (text) {
        rawMessages.push({
          id: `agy-${step.step_index ?? i}`,
          role: 'user',
          createdAt,
          status,
          text: text.slice(0, 12000),
          thinking: '',
          toolCalls: []
        });
      }
    } else if (type === 'GENERIC') {
      // Detect user responses to ask_question modals (recorded as GENERIC with A1: ...)
      const c = String(step.content || '').trim();
      const cleaned = c
        .replace(/^Created At:.*\n/gm, '')
        .replace(/^Completed At:.*\n/gm, '')
        .trim();
      if (/^A\d+:\s+/m.test(cleaned)) {
        rawMessages.push({
          id: `agy-q-${step.step_index ?? i}`,
          role: 'user',
          createdAt,
          status: 'DONE',
          text: cleaned.slice(0, 4000),
          thinking: '',
          toolCalls: []
        });
      }
    } else if (type === 'PLANNER_RESPONSE') {
      let text = String(step.content || '').trim();
      const thinking = String(step.thinking || '').trim();
      const rawCalls = Array.isArray(step.tool_calls) ? step.tool_calls : [];

      // Look ahead for command/tool output across consecutive GENERIC / TOOL_RESPONSE steps
      const followingOutputs = [];
      const outputByToolId = new Map();
      for (let m = i + 1; m < parsedSteps.length; m += 1) {
        const futStep = parsedSteps[m];
        const futT = String(futStep?.type || '');
        if (futT !== 'GENERIC' && futT !== 'TOOL_RESPONSE') break;
        const futContent = String(futStep?.content || '');
        followingOutputs.push(futContent);
        const futTcId = String(futStep?.tool_call_id || futStep?.toolCallId || '').trim();
        if (futTcId) outputByToolId.set(futTcId, futContent);
      }
      const nextGenericOut = followingOutputs[0] || '';

      const extraBlocks = [];
      const artifacts = [];
      const questions = [];
      const toolCalls = rawCalls.map((tc, tcIdx) => {
        const args = tc.arguments || tc.args || {};
        const cleanTcName = String(tc.name || '')
          .trim()
          .replace(/^default_api:/i, '');
        // Surface UserFacing artifacts as dedicated VS Code-style Artifact Cards (Walkthrough / Implementation Plan)
        if (
          (cleanTcName === 'write_file' ||
            cleanTcName === 'write_to_file' ||
            cleanTcName === 'edit_file' ||
            cleanTcName === 'replace_file_content') &&
          args.ArtifactMetadata &&
          (args.ArtifactMetadata.UserFacing || args.ArtifactMetadata.Summary)
        ) {
          const targetPath = args.Path || args.TargetFile || '';
          const { file } = shortenPathForDisplay(targetPath);
          const baseTitle = file
            ? file
                .replace(/\.md$/i, '')
                .replace(/[_-]+/g, ' ')
                .replace(/\b\w/g, (c) => c.toUpperCase())
            : 'Walkthrough';
          const summaryHdr = String(args.ArtifactMetadata.Summary || '').trim();
          const previewMd = String(
            args.Content || args.CodeContent || args.Replacement || ''
          ).slice(0, 6000);
          artifacts.push({
            file: file || 'walkthrough.md',
            title: baseTitle,
            summary: summaryHdr,
            content: previewMd
          });
        } else if (cleanTcName === 'ask_question') {
          const qs = normalizeQuestionItems(args.questions);
          if (qs.length > 0) {
            let answerSummary = '';
            let isAnswered = false;
            let isSkipped = false;
            for (let k = i + 1; k < parsedSteps.length; k += 1) {
              const fut = parsedSteps[k];
              if (!fut) continue;
              const futType = String(fut.type || '');
              const futStatus = String(fut.status || '');
              if (futType === 'GENERIC') {
                const cleanedAns = String(fut.content || '')
                  .replace(/^Created At:.*\n/gm, '')
                  .replace(/^Completed At:.*\n/gm, '')
                  .trim();
                if (/^A\d+:/m.test(cleanedAns)) {
                  answerSummary = cleanedAns;
                  isAnswered = true;
                  break;
                }
                if (futStatus && futStatus !== 'RUNNING') {
                  isAnswered = true;
                  if (/skip|cancel|dismiss/i.test(cleanedAns)) {
                    isSkipped = true;
                    answerSummary = 'Skipped question';
                    break;
                  }
                }
              } else if (futType === 'USER_INPUT') {
                isAnswered = true;
                if (!answerSummary) {
                  let uTxt = String(fut.content || '');
                  const mReq = uTxt.match(/<USER_REQUEST>\s*([\s\S]*?)\s*<\/USER_REQUEST>/i);
                  uTxt = (mReq ? mReq[1] : uTxt).trim();
                  if (uTxt && uTxt.toLowerCase() !== 'continue') {
                    answerSummary = uTxt.slice(0, 600);
                  }
                }
                break;
              } else if (futType === 'PLANNER_RESPONSE') {
                isAnswered = true;
                break;
              }
            }
            for (const qItem of qs) {
              questions.push({
                ...qItem,
                stepIndex: Number(step.step_index ?? i),
                answered: isAnswered,
                skipped: isSkipped,
                answerSummary
              });
            }
            const qLines = qs.map((q, qIdx) => {
              const opts = Array.isArray(q.options)
                ? q.options
                    .map((o) => `- ${typeof o === 'string' ? o : o?.label || o?.text || ''}`)
                    .join('\n')
                : '';
              return `**Q${qIdx + 1}: ${q.question || ''}**\n${opts}`;
            });
            extraBlocks.push(qLines.join('\n\n'));
          }
        }
        const tcOut =
          (tc.id && outputByToolId.get(String(tc.id))) ||
          followingOutputs[tcIdx] ||
          nextGenericOut;
        const enriched = enrichToolCall(tc.name, args, tcOut);
        enriched.id = tc.id || '';
        return enriched;
      });

      if (extraBlocks.length > 0) {
        text = [text, ...extraBlocks].filter(Boolean).join('\n\n');
      }

      totalToolCalls += toolCalls.length;
      if (
        text ||
        thinking ||
        toolCalls.length > 0 ||
        artifacts.length > 0 ||
        questions.length > 0
      ) {
        rawMessages.push({
          id: `agy-${step.step_index ?? i}`,
          role: 'assistant',
          createdAt,
          status,
          text: text.slice(0, 24000),
          thinking: thinking.slice(0, 3500),
          thinkingDurationSec: thinking ? stepDurationSec : 0,
          toolCalls,
          artifacts,
          questions
        });
      }
    }
  }

  const effectiveTokens =
    lastTurnTokens > 0
      ? Math.min(256000, lastTurnTokens)
      : Math.min(248000, Math.max(22019, 22019 + Math.round(postCheckpointChars / 4.2)));

  return {
    messages: coalesceAssistantTurns(rawMessages, maxTurns),
    stats: {
      steps: parsedSteps.length,
      toolCalls: totalToolCalls,
      estTokens: effectiveTokens
    },
    usage: lastUsageObj
  };
}

function parseClaudeTranscriptFile(filePath, maxTurns = 80) {
  if (!filePath || !fs.existsSync(filePath)) {
    return { messages: [], stats: { steps: 0, toolCalls: 0, estTokens: 0 }, usage: null };
  }
  let raw = '';
  try {
    raw = readTranscriptTailUtf8(filePath, 1536 * 1024);
  } catch {
    return { messages: [], stats: { steps: 0, toolCalls: 0, estTokens: 0 }, usage: null };
  }
  const lines = raw.split(/\r?\n/).filter(Boolean);
  const rawMessages = [];
  let totalToolCalls = 0;
  let lastUsage = null;
  let lastModel = 'Fable 5.1';
  let lastPendingToolUse = null;
  let lastClaudeStepMs = 0;
  const openQuestionItemsByToolId = new Map();
  let openQuestionItems = [];

  for (let i = 0; i < lines.length; i += 1) {
    let entry;
    try {
      entry = JSON.parse(lines[i]);
    } catch {
      continue;
    }
    const type = String(entry.type || '');
    const createdAt = entry.timestamp || '';
    const curStepMs = createdAt ? Date.parse(createdAt) : 0;
    const claudeStepDurSec =
      Number.isFinite(curStepMs) && curStepMs > 0 && lastClaudeStepMs > 0 && curStepMs >= lastClaudeStepMs
        ? Math.min(180, Math.max(1, Math.round((curStepMs - lastClaudeStepMs) / 1000)))
        : 2;
    if (Number.isFinite(curStepMs) && curStepMs > 0) {
      lastClaudeStepMs = curStepMs;
    }
    const msg = entry.message || {};

    if (
      type === 'summary' ||
      entry.subtype === 'compact_boundary' ||
      (type === 'system' && entry.subtype === 'compact_boundary')
    ) {
      const sumText = String(entry.summary || entry.content || msg.content || 'Conversation context compacted').trim();
      if (sumText) {
        rawMessages.push({
          id: entry.uuid || `claude-cp-${i}`,
          role: 'checkpoint',
          createdAt,
          status: 'DONE',
          text: sumText.slice(0, 6000)
        });
      }
      continue;
    }

    if (msg.usage) {
      lastUsage = msg.usage;
    }
    if (msg.model && typeof msg.model === 'string' && !msg.model.startsWith('<')) {
      lastModel = formatModelDisplayName(msg.model, 'claude');
    }

    if (type === 'user') {
      lastPendingToolUse = null;
      if (Array.isArray(msg.content)) {
        const questionAnswerTexts = [];
        for (const part of msg.content) {
          if (!part || part.type !== 'tool_result') continue;
          const tId = String(part.tool_use_id || '').trim();
          const trackedQs = tId ? openQuestionItemsByToolId.get(tId) : null;
          if (!trackedQs || !trackedQs.length) continue;
          let resText = '';
          if (typeof part.content === 'string') {
            resText = part.content;
          } else if (Array.isArray(part.content)) {
            resText = part.content
              .map((p) => (typeof p === 'string' ? p : p?.text || ''))
              .filter(Boolean)
              .join('\n');
          }
          const cleanRes = String(resText || '')
            .replace(/^User has answered your questions:\s*/i, '')
            .trim();
          const isSkipped = Boolean(part.is_error) || /skip|cancel|dismiss|declin/i.test(cleanRes);
          for (const qObj of trackedQs) {
            qObj.answered = true;
            qObj.skipped = isSkipped && !cleanRes;
            if (cleanRes) qObj.answerSummary = cleanRes.slice(0, 1200);
          }
          openQuestionItemsByToolId.delete(tId);
          openQuestionItems = openQuestionItems.filter((q) => q.toolUseId !== tId);
          if (cleanRes && !part.is_error) {
            questionAnswerTexts.push(cleanRes);
          }
        }
        if (questionAnswerTexts.length > 0 && !entry.isMeta) {
          const hasPlainUserText = msg.content.some(
            (p) => (typeof p === 'string' && p.trim()) || (p && p.type === 'text' && String(p.text || '').trim())
          );
          if (!hasPlainUserText) {
            rawMessages.push({
              id: entry.uuid || `claude-qa-${i}`,
              role: 'user',
              createdAt,
              status: 'DONE',
              text: questionAnswerTexts.join('\n').slice(0, 4000),
              thinking: '',
              toolCalls: []
            });
          }
        }
      }
    }

    if (type === 'user' && msg.role === 'user' && !entry.isMeta) {
      const content = msg.content;
      let text = '';
      if (typeof content === 'string') {
        text = content;
      } else if (Array.isArray(content)) {
        for (const part of content) {
          if (typeof part === 'string') {
            text += `${part}\n`;
          } else if (part && part.type === 'text' && part.text) {
            text += `${part.text}\n`;
          }
        }
      }
      text = text
        .replace(/<browser_instruction>[\s\S]*?<\/browser_instruction>/gi, '')
        .replace(/<local-command-caveat>[\s\S]*?<\/local-command-caveat>/gi, '')
        .replace(/<system-reminder>[\s\S]*?<\/system-reminder>/gi, '')
        .replace(/<command-name>[\s\S]*?<\/command-name>/gi, '')
        .replace(/<command-message>[\s\S]*?<\/command-message>/gi, '')
        .replace(/<command-args>[\s\S]*?<\/command-args>/gi, '')
        .replace(/<local-command-stdout>[\s\S]*?<\/local-command-stdout>/gi, '')
        .replace(/<ide_opened_file>[\s\S]*?<\/ide_opened_file>/gi, '')
        .replace(/<ide_selection>[\s\S]*?<\/ide_selection>/gi, '')
        .replace(/\[Request interrupted[^\]]*\]/gi, '')
        .trim();
      if (text) {
        if (openQuestionItems.length > 0) {
          for (const qObj of openQuestionItems) {
            qObj.answered = true;
            if (!qObj.answerSummary) qObj.answerSummary = text.slice(0, 600);
          }
          openQuestionItems = [];
          openQuestionItemsByToolId.clear();
        }
        rawMessages.push({
          id: entry.uuid || `claude-u-${i}`,
          role: 'user',
          createdAt,
          status: 'DONE',
          text: text.slice(0, 12000),
          thinking: '',
          toolCalls: []
        });
      }
    } else if (type === 'assistant' && msg.role === 'assistant') {
      if (openQuestionItems.length > 0) {
        for (const qObj of openQuestionItems) {
          qObj.answered = true;
        }
        openQuestionItems = [];
        openQuestionItemsByToolId.clear();
      }
      const content = Array.isArray(msg.content) ? msg.content : [];
      let text = '';
      let thinking = '';
      const toolCalls = [];
      const questions = [];
      for (const block of content) {
        if (!block) continue;
        if (block.type === 'text' && block.text) {
          text += `${block.text}\n`;
        } else if (block.type === 'thinking' && block.thinking) {
          thinking += `${block.thinking}\n`;
        } else if (block.type === 'tool_use') {
          const inp = block.input || {};
          lastPendingToolUse = {
            stepIndex: i,
            toolUseId: String(block.id || ''),
            toolName: String(block.name || 'Tool'),
            inputs: inp
          };
          if (block.name === 'AskUserQuestion' || block.name === 'ask_question') {
            const normQs = normalizeQuestionItems(inp.questions);
            const tId = String(block.id || '');
            const createdList = [];
            for (const qItem of normQs) {
              const qObj = {
                ...qItem,
                toolUseId: tId,
                stepIndex: i,
                answered: false,
                skipped: false,
                answerSummary: ''
              };
              questions.push(qObj);
              createdList.push(qObj);
              openQuestionItems.push(qObj);
            }
            if (tId && createdList.length > 0) {
              openQuestionItemsByToolId.set(tId, createdList);
            }
          }
          const enriched = enrichToolCall(block.name || 'Tool', inp, '');
          enriched.id = block.id || '';
          toolCalls.push(enriched);
        }
      }
      totalToolCalls += toolCalls.length;
      if (text.trim() || thinking.trim() || toolCalls.length > 0 || questions.length > 0) {
        rawMessages.push({
          id: entry.uuid || `claude-a-${i}`,
          role: 'assistant',
          createdAt,
          status: 'DONE',
          model: lastModel,
          text: text.trim().slice(0, 24000),
          thinking: thinking.trim().slice(0, 3500),
          thinkingDurationSec: thinking.trim() ? claudeStepDurSec : 0,
          toolCalls,
          questions
        });
      }
    }
  }

  const usedTokens = lastUsage
    ? Number(lastUsage.input_tokens || 0) +
      Number(lastUsage.cache_creation_input_tokens || 0) +
      Number(lastUsage.cache_read_input_tokens || 0) +
      Number(lastUsage.output_tokens || 0)
    : Math.min(200000, Math.round(raw.length / 16));

  return {
    messages: coalesceAssistantTurns(rawMessages, maxTurns),
    stats: {
      steps: lines.length,
      toolCalls: totalToolCalls,
      estTokens: usedTokens
    },
    usage: lastUsage,
    model: lastModel,
    lastPendingToolUse
  };
}

function buildEstimatedContextStatus(parsed, provider, modelLabel) {
  const cleanModel = formatModelDisplayName(
    modelLabel || parsed?.model,
    provider === 'claude' ? 'claude' : 'antigravity'
  );
  const limitTokens = inferMaxContextTokens(provider, cleanModel);
  const usedTokens = Math.min(
    limitTokens,
    Math.max(0, Number(parsed?.stats?.estTokens || 0))
  );
  const pct =
    limitTokens > 0
      ? Math.min(100, Math.max(usedTokens > 0 ? 1 : 0, Math.round((usedTokens / limitTokens) * 100)))
      : 0;

  let breakdown = [];
  if (provider === 'claude' && parsed?.usage) {
    const u = parsed.usage;
    const cached =
      Number(u.cache_read_input_tokens || 0) + Number(u.cache_creation_input_tokens || 0);
    const freshIn = Number(u.input_tokens || 0);
    const out = Number(u.output_tokens || 0);
    if (cached > 0) {
      breakdown.push({
        key: 'cached',
        label: 'Cached Context (Prompt & History)',
        tokens: cached,
        color: '#6366F1'
      });
    }
    if (freshIn > 0) {
      breakdown.push({
        key: 'input',
        label: 'New Turn Input',
        tokens: freshIn,
        color: '#06B6D4'
      });
    }
    if (out > 0) {
      breakdown.push({
        key: 'output',
        label: 'Last Assistant Output',
        tokens: out,
        color: '#10B981'
      });
    }
  } else if (provider !== 'claude' && parsed?.usage) {
    const u = parsed.usage;
    const sysTokens = Math.min(usedTokens, 22019);
    const chatAndTools = Math.max(0, usedTokens - sysTokens);
    breakdown = [
      { key: 'system', label: 'System Prompt & Rules', tokens: Math.min(usedTokens, 10344), color: '#6366F1' },
      { key: 'tools', label: 'Tool Definitions', tokens: Math.min(Math.max(0, usedTokens - 10344), 11675), color: '#06B6D4' },
      { key: 'toolResults', label: 'Tool Outputs & Files', tokens: Math.round(chatAndTools * 0.56), color: '#10B981' },
      { key: 'assistant', label: 'Model Responses', tokens: Math.round(chatAndTools * 0.38), color: '#F59E0B' },
      { key: 'user', label: 'User & Checkpoints', tokens: Math.round(chatAndTools * 0.06), color: '#3B82F6' }
    ].filter((x) => x.tokens > 0);
  }

  if (breakdown.length === 0) {
    const sysTokens = Math.min(usedTokens, 14800);
    const rem = Math.max(0, usedTokens - sysTokens);
    breakdown = [
      { key: 'system', label: 'System Prompt & Rules', tokens: sysTokens, color: '#6366F1' },
      { key: 'tools', label: 'Tool Outputs & Files', tokens: Math.round(rem * 0.52), color: '#10B981' },
      { key: 'assistant', label: 'Model Responses', tokens: Math.round(rem * 0.36), color: '#F59E0B' },
      { key: 'user', label: 'User & Checkpoints', tokens: Math.round(rem * 0.12), color: '#3B82F6' }
    ].filter((x) => x.tokens > 0);
  }

  return {
    provider,
    modelLabel: cleanModel,
    usedTokens,
    limitTokens,
    remainingTokens: Math.max(0, limitTokens - usedTokens),
    pct,
    breakdown
  };
}

async function inspectWorkspaceGit(wsDef, includeDiff = false) {
  const fullPath = path.join(os.homedir(), ...wsDef.rel);
  const exists = fs.existsSync(fullPath);
  if (!exists) {
    return {
      id: wsDef.id,
      name: wsDef.name,
      group: wsDef.group,
      path: fullPath,
      exists: false,
      branch: '-',
      dirtyCount: 0,
      modifiedFiles: [],
      recentCommits: [],
      diffPatch: ''
    };
  }

  let branch = 'main';
  let modifiedFiles = [];
  let recentCommits = [];
  let diffPatch = '';

  const gitPrefix = wsDef.gitDirRel
    ? [
        `--git-dir=${path.join(os.homedir(), ...wsDef.gitDirRel)}`,
        `--work-tree=${fullPath}`
      ]
    : [];

  try {
    const { stdout: branchOut } = await execFileAsync(
      'git',
      [...gitPrefix, 'rev-parse', '--abbrev-ref', 'HEAD'],
      { cwd: fullPath, timeout: 2500, windowsHide: true }
    );
    branch = String(branchOut || '').trim() || 'main';
  } catch {}

  try {
    const { stdout: statusOut } = await execFileAsync(
      'git',
      [...gitPrefix, 'status', '--porcelain'],
      { cwd: fullPath, timeout: 3000, windowsHide: true }
    );
    modifiedFiles = String(statusOut || '')
      .split(/\r?\n/)
      .filter(Boolean)
      .slice(0, 40)
      .map((line) => ({
        status: line.slice(0, 2).trim() || 'M',
        path: line.slice(3).trim()
      }));
  } catch {}

  try {
    const { stdout: logOut } = await execFileAsync(
      'git',
      [...gitPrefix, 'log', '-n', '5', '--pretty=format:%h|%s|%cr|%an'],
      { cwd: fullPath, timeout: 3000, windowsHide: true }
    );
    recentCommits = String(logOut || '')
      .split(/\r?\n/)
      .filter(Boolean)
      .map((line) => {
        const [hash, subject, relativeTime, author] = line.split('|');
        return { hash, subject, relativeTime, author };
      });
  } catch {}

  if (includeDiff) {
    try {
      const { stdout: diffOut } = await execFileAsync(
        'git',
        [...gitPrefix, 'diff', '--no-color'],
        { cwd: fullPath, timeout: 3500, maxBuffer: 512 * 1024, windowsHide: true }
      );
      diffPatch = String(diffOut || '').slice(0, 32000);
    } catch {}
  }

  let topFiles = [];
  if (includeDiff) {
    try {
      const entries = fs.readdirSync(fullPath, { withFileTypes: true });
      topFiles = entries
        .filter((e) => !e.name.startsWith('.git') && e.name !== 'node_modules' && e.name !== '__pycache__')
        .slice(0, 40)
        .map((e) => ({
          name: e.name,
          type: e.isDirectory() ? 'dir' : 'file'
        }));
    } catch {}
  }

  return {
    id: wsDef.id,
    name: wsDef.name,
    group: wsDef.group,
    path: fullPath,
    exists: true,
    branch,
    dirtyCount: modifiedFiles.length,
    modifiedFiles,
    recentCommits,
    diffPatch,
    topFiles
  };
}

const STUDIO_PORT_RADAR_CANDIDATES = [
  { port: 3000, label: 'App Dev Server' },
  { port: 4173, label: 'Vite Preview' },
  { port: 4318, label: 'THEO Workstation Bridge' },
  { port: 5173, label: 'Vite Dev Server' },
  { port: 5500, label: 'Static Live Server' },
  { port: 8000, label: 'Python / Local HTTP' },
  { port: 8080, label: 'Local Web Server' },
  { port: 8765, label: 'ISABI Local Server' },
  { port: 8787, label: 'Edge Worker Dev' }
];

function probeSingleLoopbackPort(port, timeoutMs = 85) {
  return new Promise((resolve) => {
    let settled = false;
    const sock = new net.Socket();
    const finish = (open) => {
      if (settled) return;
      settled = true;
      try {
        sock.destroy();
      } catch {}
      resolve(Boolean(open));
    };
    sock.setTimeout(timeoutMs);
    sock.once('connect', () => finish(true));
    sock.once('timeout', () => finish(false));
    sock.once('error', () => finish(false));
    try {
      sock.connect(port, '127.0.0.1');
    } catch {
      finish(false);
    }
  });
}

async function probeLocalDevPorts() {
  const checks = await Promise.all(
    STUDIO_PORT_RADAR_CANDIDATES.map(async (entry) => {
      const open = await probeSingleLoopbackPort(entry.port, 85);
      return open
        ? {
            port: entry.port,
            label: entry.label,
            url: `http://127.0.0.1:${entry.port}/`
          }
        : null;
    })
  );
  return checks.filter(Boolean);
}

function parseSkillFrontmatter(rawMarkdown, fallbackName) {
  const head = String(rawMarkdown || '').slice(0, 4096);
  const fmMatch = head.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  let name = fallbackName;
  let description = '';
  if (fmMatch) {
    const body = fmMatch[1];
    const nameMatch = body.match(/^\s*name\s*:\s*(.+)$/m);
    const descMatch = body.match(/^\s*description\s*:\s*(.+)$/m);
    if (nameMatch) {
      name = nameMatch[1].trim().replace(/^['"]|['"]$/g, '') || fallbackName;
    }
    if (descMatch) {
      description = descMatch[1].trim().replace(/^['"]|['"]$/g, '');
    }
  }
  if (!description) {
    const firstPara = head
      .replace(/^---[\s\S]*?---\r?\n?/, '')
      .split(/\r?\n/)
      .map((l) => l.trim())
      .find((l) => l && !l.startsWith('#'));
    description = firstPara || 'Specialized AI workflow skill';
  }
  return {
    name: String(name || fallbackName).slice(0, 80),
    description: String(description || '').slice(0, 220)
  };
}

function discoverAvailableSkills(wsRoot) {
  const skills = [];
  const seen = new Set();
  const roots = [
    wsRoot ? { dir: path.join(wsRoot, '.agents', 'skills'), scope: 'workspace' } : null,
    wsRoot ? { dir: path.join(wsRoot, '.claude', 'skills'), scope: 'workspace' } : null,
    { dir: path.join(os.homedir(), '.gemini', 'config', 'skills'), scope: 'user' },
    { dir: path.join(os.homedir(), '.gemini', 'antigravity', 'builtin', 'skills'), scope: 'builtin' }
  ].filter(Boolean);

  for (const rootInfo of roots) {
    if (!fs.existsSync(rootInfo.dir)) continue;
    let entries = [];
    try {
      entries = fs.readdirSync(rootInfo.dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const ent of entries) {
      if (!ent.isDirectory() || ent.name.startsWith('.')) continue;
      const skillFile = path.join(rootInfo.dir, ent.name, 'SKILL.md');
      if (!fs.existsSync(skillFile)) continue;
      try {
        if (!isRealPathInsideRoot(skillFile, rootInfo.dir)) continue;
        const fd = fs.openSync(skillFile, 'r');
        const buf = Buffer.alloc(4096);
        const bytesRead = fs.readSync(fd, buf, 0, 4096, 0);
        fs.closeSync(fd);
        const meta = parseSkillFrontmatter(buf.slice(0, bytesRead).toString('utf8'), ent.name);
        const key = meta.name.toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        skills.push({
          id: ent.name,
          name: meta.name,
          description: meta.description,
          scope: rootInfo.scope
        });
        if (skills.length >= 28) return skills;
      } catch {}
    }
  }
  return skills;
}

function discoverWorkspaceChecks(wsRoot, gitPrefix = []) {
  if (!wsRoot || !fs.existsSync(wsRoot)) return [];
  const checks = [];
  const addedIds = new Set();
  const addCheck = (spec) => {
    if (!spec || !spec.id || addedIds.has(spec.id)) return;
    addedIds.add(spec.id);
    checks.push(spec);
  };

  const hasGit =
    gitPrefix.length > 0 ||
    fs.existsSync(path.join(wsRoot, '.git'));
  if (hasGit) {
    addCheck({
      id: 'git:status',
      label: 'Git Status & Branch',
      category: 'git',
      commandPreview: 'git status --short --branch',
      _bin: 'git',
      _args: [...gitPrefix, 'status', '--short', '--branch'],
      _timeoutMs: 5000
    });
    addCheck({
      id: 'git:diff-stat',
      label: 'Git Diff Summary',
      category: 'git',
      commandPreview: 'git diff --stat',
      _bin: 'git',
      _args: [...gitPrefix, 'diff', '--stat', '--no-color'],
      _timeoutMs: 5000
    });
  }

  for (const relSyntax of ['js/app.js', 'remote.js', 'sw.js', 'server.js', 'extension.js']) {
    const absTarget = path.resolve(wsRoot, relSyntax);
    if (
      fs.existsSync(absTarget) &&
      !isSensitivePreviewPath(relSyntax) &&
      isRealPathInsideRoot(absTarget, wsRoot)
    ) {
      addCheck({
        id: `syntax:${relSyntax}`,
        label: `Syntax Check · ${relSyntax}`,
        category: 'lint',
        commandPreview: `node --check ${relSyntax}`,
        _bin: process.execPath,
        _args: ['--check', relSyntax],
        _timeoutMs: 8000
      });
    }
  }

  const pkgPath = path.resolve(wsRoot, 'package.json');
  if (fs.existsSync(pkgPath) && isRealPathInsideRoot(pkgPath, wsRoot)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8')) || {};
      const scripts = pkg.scripts && typeof pkg.scripts === 'object' ? pkg.scripts : {};
      for (const [scriptName, scriptCmd] of Object.entries(scripts)) {
        if (!/^(test|smoke|check|lint|verify)(:[a-z0-9_-]+)?$/i.test(scriptName)) continue;
        const m = String(scriptCmd || '').trim().match(/^node\s+([a-zA-Z0-9_./-]+)$/);
        if (!m) continue;
        const relScript = m[1].replace(/\\/g, '/');
        const absScript = path.resolve(wsRoot, relScript);
        if (
          !isSensitivePreviewPath(relScript) &&
          fs.existsSync(absScript) &&
          isRealPathInsideRoot(absScript, wsRoot)
        ) {
          addCheck({
            id: `pkg:${scriptName}`,
            label: `Script · ${scriptName}`,
            category: 'test',
            commandPreview: `node ${relScript}`,
            _bin: process.execPath,
            _args: [relScript],
            _timeoutMs: 20000
          });
        }
      }
    } catch {}
  }

  const testDir = path.resolve(wsRoot, 'test');
  if (fs.existsSync(testDir) && isRealPathInsideRoot(testDir, wsRoot)) {
    try {
      const entries = fs.readdirSync(testDir, { withFileTypes: true });
      for (const ent of entries.slice(0, 8)) {
        if (!ent.isFile() || !/\.(test|spec)\.(cjs|mjs|js)$/i.test(ent.name)) continue;
        const relTest = `test/${ent.name}`;
        const absTest = path.resolve(wsRoot, relTest);
        if (!isSensitivePreviewPath(relTest) && isRealPathInsideRoot(absTest, wsRoot)) {
          addCheck({
            id: `test:${ent.name}`,
            label: `Test · ${ent.name}`,
            category: 'test',
            commandPreview: `node ${relTest}`,
            _bin: process.execPath,
            _args: [relTest],
            _timeoutMs: 20000
          });
        }
      }
    } catch {}
  }

  const auditI18nPy = path.resolve(wsRoot, 'build', 'audit_i18n.py');
  if (fs.existsSync(auditI18nPy) && isRealPathInsideRoot(auditI18nPy, wsRoot)) {
    const winLocalPy = path.join(os.homedir(), '.local', 'python312', 'python.exe');
    const pyBin = process.platform === 'win32' && fs.existsSync(winLocalPy) ? winLocalPy : 'python';
    addCheck({
      id: 'i18n:audit',
      label: 'i18n Trilingual Audit',
      category: 'lint',
      commandPreview: 'python build/audit_i18n.py',
      _bin: pyBin,
      _args: ['build/audit_i18n.py'],
      _timeoutMs: 12000
    });
  }

  return checks;
}

function parseCheckDiagnostics(rawOutput, wsRoot) {
  const lines = String(rawOutput || '').split(/\r?\n/);
  const diagnostics = [];
  const seen = new Set();
  const diagRe =
    /((?:[A-Za-z]:[\\/])?[a-zA-Z0-9_./\\-]+\.(?:js|cjs|mjs|ts|tsx|jsx|py|css|html|json)):(\d+)(?::(\d+))?/;

  for (let i = 0; i < lines.length; i += 1) {
    const lineText = String(lines[i] || '').trim();
    if (!lineText || lineText.includes('node:internal')) continue;
    const m = lineText.match(diagRe);
    if (!m) continue;
    const rawFile = m[1];
    const lineNum = Math.max(1, parseInt(m[2], 10) || 1);
    const colNum = Math.max(1, parseInt(m[3] || '1', 10) || 1);
    const absCandidate = path.isAbsolute(rawFile)
      ? path.resolve(rawFile)
      : wsRoot
        ? path.resolve(wsRoot, rawFile)
        : '';
    if (
      !absCandidate ||
      !wsRoot ||
      isSensitivePreviewPath(absCandidate) ||
      !isRealPathInsideRoot(absCandidate, wsRoot)
    ) {
      continue;
    }
    const relPath = path.relative(wsRoot, absCandidate).replace(/\\/g, '/');
    const dedupKey = `${relPath}:${lineNum}`;
    if (seen.has(dedupKey)) continue;
    seen.add(dedupKey);
    const nextLine = String(lines[i + 1] || '').trim();
    const message = (
      /error|fail|syntax|assert|typeerror|referenceerror/i.test(lineText)
        ? lineText
        : nextLine || lineText
    ).slice(0, 220);
    diagnostics.push({
      file: path.basename(absCandidate),
      relPath,
      line: lineNum,
      col: colNum,
      severity: /warn/i.test(message) ? 'warning' : 'error',
      message
    });
    if (diagnostics.length >= 20) break;
  }
  return diagnostics;
}

function withTimeout(promise, ms, fallbackVal = null) {
  return new Promise((resolve) => {
    let settled = false;
    const t = setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(fallbackVal);
      }
    }, ms);
    Promise.resolve(promise)
      .then((val) => {
        if (!settled) {
          settled = true;
          clearTimeout(t);
          resolve(val);
        }
      })
      .catch(() => {
        if (!settled) {
          settled = true;
          clearTimeout(t);
          resolve(fallbackVal);
        }
      });
  });
}

function httpsJsonRequest(urlString, options = {}) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(urlString);
    } catch (err) {
      reject(err);
      return;
    }
    const timeoutMs = Number(options.timeoutMs || 10000);
    let done = false;
    const finish = (err, val) => {
      if (done) return;
      done = true;
      clearTimeout(hardTimer);
      if (err) reject(err);
      else resolve(val);
    };
    const method = options.method || 'GET';
    const bodyText = options.body ? String(options.body) : '';
    const headers = {
      ...(options.headers || {})
    };
    if (bodyText) {
      headers['Content-Length'] = Buffer.byteLength(bodyText);
    }
    const req = https.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: parsed.pathname + parsed.search,
        method,
        headers,
        timeout: timeoutMs
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
            try {
              finish(null, text ? JSON.parse(text) : {});
            } catch {
              finish(null, { raw: text });
            }
          } else {
            finish(new Error(`HTTP ${res.statusCode}: ${text.slice(0, 200)}`));
          }
        });
        res.on('error', (err) => finish(err));
      }
    );
    const hardTimer = setTimeout(() => {
      try {
        req.destroy(new Error('Cloud Relay hard timeout'));
      } catch {}
      finish(new Error('Cloud Relay hard timeout'));
    }, timeoutMs + 2500);
    req.on('timeout', () => {
      try {
        req.destroy(new Error('Cloud Relay request timeout'));
      } catch {}
      finish(new Error('Cloud Relay request timeout'));
    });
    req.on('error', (err) => finish(err));
    if (bodyText) {
      req.write(bodyText);
    }
    req.end();
  });
}

function isThirdPartyQuotaBar(bar) {
  if (!bar || typeof bar !== 'object') return false;
  if (bar.pool === '3p') return true;
  if (/^3p-/i.test(String(bar.key || bar.bucketId || ''))) return true;
  return /claude\s*(?:&|and)\s*gpt/i.test(String(bar.label || ''));
}

function collectHighUsageQuotaAlerts(stateSnapshot, nowMs = Date.now()) {
  const highAlerts = [];
  const allActiveBuckets = [];
  if (!stateSnapshot || typeof stateSnapshot !== 'object') {
    return { highAlerts, allActiveBuckets };
  }
  const hideThirdParty = Boolean(stateSnapshot.hideThirdPartyQuota);

  for (const provKey of ['antigravity', 'claude']) {
    const provLabel = provKey === 'claude' ? 'Claude Code' : 'Antigravity';
    let provInfo = stateSnapshot.providers?.[provKey] || null;
    if (!provInfo && provKey === 'antigravity' && stateSnapshot.usage) {
      provInfo = {
        id: 'antigravity',
        label: 'Antigravity',
        account: stateSnapshot.account || {},
        usage: stateSnapshot.usage
      };
    }
    if (
      provKey === 'claude' &&
      (!provInfo?.usage?.limits || !provInfo.usage.limits.length) &&
      Number(stateSnapshot.claudeUsage?.fiveHourPct || 0) > 0
    ) {
      provInfo = {
        ...(provInfo || {}),
        id: 'claude',
        label: 'Claude Code',
        account: provInfo?.account || { name: 'Claude Account', email: '' },
        usage: {
          at: nowMs,
          limits: [
            {
              label: 'Session (5hr)',
              pct: Number(stateSnapshot.claudeUsage.fiveHourPct || 0),
              reset: Number(stateSnapshot.claudeUsage.fiveHourResetsAt || 0),
              resetText: ''
            }
          ]
        }
      };
    }
    if (!provInfo) continue;

    const rawAccounts =
      Array.isArray(provInfo.accounts) && provInfo.accounts.length > 0
        ? provInfo.accounts
        : null;
    const activeAccounts = rawAccounts
      ? rawAccounts.filter((a) => a && a.active)
      : [];
    const targetAccounts =
      activeAccounts.length > 0
        ? activeAccounts
        : rawAccounts
          ? [rawAccounts[0]]
          : [
              {
                id: provInfo.account?.email
                  ? `${provKey}:${String(provInfo.account.email).trim().toLowerCase()}`
                  : `${provKey}:default`,
                provider: provKey,
                label: provLabel,
                nickname: provInfo.account?.nickname || '',
                active: true,
                account: provInfo.account || {},
                usage: provInfo.usage
              }
            ];

    for (const acct of targetAccounts) {
      if (!acct) continue;
      const acctObj = acct.account || provInfo.account || {};
      const acctEmail = String(acctObj.email || '').trim();
      const acctNick = String(acct.nickname || acctObj.nickname || '').trim();
      const acctId = String(
        acct.id || (acctEmail ? `${provKey}:${acctEmail.toLowerCase()}` : `${provKey}:default`)
      )
        .trim()
        .toLowerCase();
      const acctSlug =
        acctId.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || provKey;
      const acctDisplay = acctNick
        ? acctEmail
          ? `${acctNick} (${acctEmail})`
          : acctNick
        : acctEmail || '';

      const rawLimits =
        Array.isArray(acct.usage?.limits) && acct.usage.limits.length > 0
          ? acct.usage.limits
          : Array.isArray(provInfo.usage?.limits)
            ? provInfo.usage.limits
            : [];

      for (const bar of rawLimits) {
        if (!bar || typeof bar !== 'object') continue;
        if (provKey === 'antigravity' && hideThirdParty && isThirdPartyQuotaBar(bar)) continue;
        const resetMs = Number(bar.reset || 0);
        const isExpired = Boolean(bar.expired || (resetMs > 0 && resetMs <= nowMs));
        const rawPct = bar.pct !== undefined ? bar.pct : bar.usedPercent;
        const pct = isExpired
          ? 0
          : Math.max(0, Math.min(100, Math.round(Number(rawPct || 0))));
        const barLabel = String(bar.label || 'Usage Quota').trim() || 'Usage Quota';
        const barSlug =
          barLabel.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'quota';
        const bucketKey = `${provKey}:${acctSlug}:${barSlug}`;
        const windowStamp =
          resetMs > 0
            ? Math.round(resetMs / 60000)
            : Math.floor(nowMs / (4 * 3600 * 1000)) * 240 + 240;
        const alertId = `quota90:${bucketKey}:${windowStamp}`;
        const tag = `theo-quota-${provKey}-${acctSlug}-${barSlug}`;
        const resetText = String(bar.resetText || '').trim();

        const bucketInfo = {
          id: alertId,
          tag,
          bucketKey,
          windowStamp,
          provider: provKey,
          providerLabel: provLabel,
          accountId: acctId,
          accountDisplay: acctDisplay,
          barLabel,
          pct,
          resetMs,
          resetText,
          expired: isExpired
        };
        allActiveBuckets.push(bucketInfo);

        if (!isExpired && pct >= 90) {
          const title = `⚠️ ${provLabel} Usage at ${pct}% — ${barLabel}`;
          const resetClause = resetText ? ` (${resetText})` : '';
          const acctPrefix = acctDisplay ? `${acctDisplay} · ` : '';
          const body = `${acctPrefix}${barLabel} reached ${pct}% usage${resetClause}. Tap to inspect quota & switch account if needed.`;
          highAlerts.push({
            ...bucketInfo,
            title,
            body,
            tab: 'pulse',
            url: './?tab=pulse'
          });
        }
      }
    }
  }

  return { highAlerts, allActiveBuckets };
}

function hasQuotaAlertForWindow(alertSet, bucketKey, windowStamp, nowMs = Date.now()) {
  if (!alertSet || typeof alertSet[Symbol.iterator] !== 'function') return false;
  const prefix = `quota90:${bucketKey}:`;
  const targetStamp = Number(windowStamp || 0);
  const nowMin = Math.floor(nowMs / 60000);
  for (const key of alertSet) {
    if (typeof key !== 'string' || !key.startsWith(prefix)) continue;
    const prevStamp = Number(key.slice(prefix.length));
    if (!Number.isFinite(prevStamp) || !Number.isFinite(targetStamp)) {
      if (key === `${prefix}${windowStamp}`) return true;
      continue;
    }
    if (prevStamp > 0 && prevStamp < nowMin) {
      continue;
    }
    if (Math.abs(targetStamp - prevStamp) <= 30) {
      return true;
    }
  }
  return false;
}

function isExpiredQuotaAlertKey(key, nowMs = Date.now()) {
  const s = String(key || '');
  if (!s.startsWith('quota90:')) return false;
  const lastColon = s.lastIndexOf(':');
  if (lastColon <= 7) return false;
  const stamp = Number(s.slice(lastColon + 1));
  if (!Number.isFinite(stamp) || stamp <= 0) return false;
  return stamp < Math.floor(nowMs / 60000);
}

class TheoRemoteBridge {
  constructor(context, deps = {}) {
    this.context = context;
    this.vscode = deps.vscode || null;
    this.hub = deps.hub || null;
    this.store = deps.store || null;
    this.stateStore = deps.stateStore || null;
    this.tabs = deps.tabs || null;
    this.accountVault = deps.accountVault || null;

    this.relayConfig = loadRelayConfig(context?.extensionPath || __dirname);
    this.port = this.relayConfig.port || DEFAULT_PORT;
    this.pwaRoot = path.join(os.homedir(), 'bhfirms', 'theo');
    this.cmdPwaRoot = path.join(os.homedir(), 'bhfirms', 'command');
    this.server = null;
    this.listening = false;
    this.sseClients = new Set();
    this.workspacesCache = [];
    this.workspacesCachedAt = 0;
    this.lastCloudSyncAt = 0;
    this.lastCloudAttemptAt = 0;
    this.lastCloudError = '';
    this.cloudSyncInFlight = false;
    this.cloudSyncTimer = null;
    this.processedCmdIds = new Set();
    this.foreignClaimHoldUntil = new Map();
    this.pendingSealClaims = new Set();
    this.claimInflightLeaseMs = CLAIM_INFLIGHT_LEASE_MS;
    this.codeMtime = Date.now();
    this.lastStateCachePath = path.join(os.homedir(), '.claude', '.theo-last-state.json');

    this.pushRegistryPath = path.join(os.homedir(), '.claude', '.theo-push-registry.json');
    this.pushDevices = this.loadLocalPushRegistry();
    this.personalLedgerPath = path.join(os.homedir(), '.claude', '.theo-personal-ledger.json');
    this.personalLedger = this.loadLocalPersonalLedger();
    this.pushStatePath = path.join(os.homedir(), '.claude', '.theo-push-state.json');
    this.pushedApprovalIds = new Set();
    this.pushedAlertIds = new Set();
    this.pendingDelegationAlerts = [];
    this.prevSessionStatusById = new Map();
    this.prevSessionStepById = new Map();
    this.prevCompletedStepById = new Map();
    this.prevSessionAtById = new Map();
    this.lastSessionPushAtById = new Map();
    this.lastSessionPushTextById = new Map();
    this.standbyBindTimer = null;
    this.recentNotifications = [];
    this.threadDetailCache = new Map();
    this.pendingUrgentCloudSync = false;
    this.urgentSyncDebounceTimer = null;
    this.lastSyncedStateSig = '';
    this.pushBaselineInitialized = false;
    this.pushEvalInFlight = false;
    this.deviceInfo = getDeviceIdentity();
    this.wsHub = null;
    this.remoteDeviceStates = {};
    this.cachedRemoteThreads = {};
    this.edgeStatePushTimer = null;
    this.attachmentUploadChunks = new Map();
    this.loadCachedFleetFromDisk();
    const runnerCallbacks = {
      onStreamEvent: (delta) => this.handleStreamDelta(delta),
      onRunFinished: () => {
        if (this.hub) {
          this.hub.refresh({ forceQuota: false }).catch(() => {});
        }
        this.notifyStateUpdated();
      }
    };
    if (
      globalThis.__theoSharedDirectRunner &&
      typeof globalThis.__theoSharedDirectRunner.rebindCallbacks === 'function'
    ) {
      globalThis.__theoSharedDirectRunner.rebindCallbacks(runnerCallbacks);
      this.directRunner = globalThis.__theoSharedDirectRunner;
    } else {
      this.directRunner = new TheoDirectRunner(runnerCallbacks);
      globalThis.__theoSharedDirectRunner = this.directRunner;
    }
    this.edgeClient = new TheoEdgeRelayClient({
      getRelayKey: () =>
        this.relayConfig?.effectiveEdgeSecret ||
        this.relayConfig?.edgeAccessKey ||
        this.relayConfig?.key ||
        '',
      getEdgeUrl: () => this.getEffectiveEdgeUrl(),
      buildHostState: () => this.buildCompactHostSnapshot(),
      onRpcCommand: (cmd) => this.handleWsOrEdgeRpc(cmd),
      onFleetDevicesUpdated: () => this.broadcastLocalFleetUpdate(),
      onPeerHostState: () => this.broadcastLocalFleetUpdate(),
      onPeerStreamDelta: (delta) => this.forwardStreamDeltaToLocalClients(delta),
      onClaudePermissionMode: (msg) => this.handleIncomingEdgeClaudeMode(msg)
    });
    this.loadPushStateFromDisk();
    this.syncHotReloadedModules({ changedFiles: deps.hotSwapChangedFiles });
  }

  loadCachedFleetFromDisk() {
    try {
      const cachePath = this.peerCachePath();
      if (fs.existsSync(cachePath)) {
        const parsed = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
        if (parsed && typeof parsed === 'object') {
          if (parsed.deviceStates && typeof parsed.deviceStates === 'object') {
            this.remoteDeviceStates = parsed.deviceStates;
          }
          if (parsed.threads && typeof parsed.threads === 'object') {
            this.cachedRemoteThreads = parsed.threads;
          }
        }
      }
    } catch {}
  }

  getEffectiveEdgeUrl() {
    return String(
      this.deviceInfo?.edgeRelayUrl ||
        this.relayConfig?.edgeUrl ||
        this.cloudControlDocs?.edge_relay?.url ||
        ''
    ).trim();
  }

  async setEffectiveEdgeUrl(rawUrl, options = {}) {
    const cleanUrl = String(rawUrl || '').trim();
    const previousEdgeUrl = this.getEffectiveEdgeUrl();
    this.deviceInfo = updateDeviceConfig({
      edgeRelayUrl: cleanUrl,
      ...(options.deviceName ? { name: options.deviceName } : {})
    });
    this.relayConfig.edgeUrl = cleanUrl;
    // The move is announced to the store this host was using, so hosts still polling it hear of it. After that this
    // host follows at once: its store is the one behind the relay it is paired with, without waiting for a restart.
    const previousStore = { url: this.relayConfig?.url || '', key: this.relayConfig?.key || '' };
    let nextCreds = null;
    try {
      nextCreds = saveTheoCredentials({ edgeRelayUrl: cleanUrl });
    } catch {}
    if (this.edgeClient) {
      this.edgeClient.updateUrlAndReconnect(true);
    }
    if (options.broadcastCloud && previousStore.url && previousStore.key) {
      await httpsJsonRequest(previousStore.url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        body: JSON.stringify({
          key: previousStore.key,
          op: 'patch',
          ackOnly: true,
          patch: {
            edge_relay: {
              url: cleanUrl,
              updatedAt: Date.now(),
              updatedBy: this.deviceInfo.id
            }
          }
        }),
        timeoutMs: 10000
      }).catch(() => {});
    }
    // This host's store is the one behind the relay it is paired with. It moves there once that store has answered
    // its key; until then it keeps working with the store it has and asks again later (settleStoreAddress). Nothing
    // is pinned in the credentials file, so correcting a wrong relay address is all it takes to recover.
    this.pendingStore = null;
    if (nextCreds && nextCreds.cloudUrl && nextCreds.cloudKey && nextCreds.cloudUrl !== previousStore.url) {
      this.pendingStore = {
        url: nextCreds.cloudUrl,
        key: nextCreds.cloudKey,
        edgeUrl: cleanUrl,
        fromEdgeUrl: previousEdgeUrl,
        checkedAt: 0
      };
      await this.settleStoreAddress();
    }
    this.broadcastLocalFleetUpdate();
    return this.getStatus();
  }

  // Moves this host to the store it is waiting on once that store answers. Asked at most once a minute.
  async settleStoreAddress() {
    const pending = this.pendingStore;
    if (!pending) return false;
    const now = Date.now();
    if (pending.checkedAt && now - pending.checkedAt < 60000) return false;
    pending.checkedAt = now;
    const answered = await this.probeStore(pending.url, pending.key);
    if (this.pendingStore !== pending || !answered) return false;
    this.relayConfig.url = pending.url;
    this.relayConfig.key = pending.key;
    this.pendingStore = null;
    // Record in the store just joined where the relay is, so an older announcement left there cannot send hosts
    // back. An announcement that points somewhere else again is left alone: the fleet has moved on since, and the
    // next sync cycle follows it.
    Promise.resolve(this.postStore({ op: 'get_control' }, 8000))
      .then((res) => {
        const announced = String(res?.docs?.edge_relay?.url || '').trim();
        if (announced && announced !== pending.edgeUrl && announced !== pending.fromEdgeUrl) return null;
        return this.postStore(
          {
            op: 'patch',
            ackOnly: true,
            patch: { edge_relay: { url: pending.edgeUrl, updatedAt: Date.now(), updatedBy: this.deviceInfo?.id || '' } }
          },
          10000
        );
      })
      .catch(() => {});
    return true;
  }

  // The store's `edge_relay` document announces a relay move to every host. A host follows it only after the store
  // behind the announced relay has answered this host's own key, so a wrong address in that document cannot strand
  // the fleet on a relay that does not exist. One check per address at a time; a refused address is retried later.
  async followAnnouncedEdgeRelay(announcedUrl) {
    const cleanUrl = String(announcedUrl || '').trim();
    if (!cleanUrl || this._edgeFollowInFlight) return false;
    const refused = this._edgeFollowRefused;
    if (refused && refused.url === cleanUrl && Date.now() - refused.at < 10 * 60 * 1000) return false;
    this._edgeFollowInFlight = true;
    try {
      const creds = loadTheoCredentials();
      // Only a host whose store address is derived from the relay moves its store with it; a host with a hand-set
      // or environment store address keeps that store and follows the relay as before.
      if (creds.cloudSource === 'edge' && creds.edgeAccessKey) {
        const storeUrl = deriveStoreEndpoint(cleanUrl);
        const storeKey = deriveEdgeAuthToken(creds.edgeAccessKey);
        if (!storeUrl || !(await this.probeStore(storeUrl, storeKey))) {
          this._edgeFollowRefused = { url: cleanUrl, at: Date.now() };
          return false;
        }
      }
      await this.setEffectiveEdgeUrl(cleanUrl, { broadcastCloud: false });
      return true;
    } finally {
      this._edgeFollowInFlight = false;
    }
  }

  // True when a store at `url` answers this key. Used before this host moves to a store it has not used yet.
  async probeStore(url, key) {
    try {
      const res = await httpsJsonRequest(url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        body: JSON.stringify({ key, op: 'get_control' }),
        timeoutMs: 8000
      });
      return Boolean(res && res.ok === true);
    } catch {
      return false;
    }
  }

  getClaudePermissionModeSnapshot() {
    return resolveSharedClaudePermissionModeInfo();
  }

  syncInMemoryClaudePermissionMode(frameDoc = {}, opts = {}) {
    const cleanMode =
      normalizeExplicitClaudeMode(frameDoc?.defaultMode || frameDoc?.mode) || 'bypassPermissions';
    const cleanRev = Math.max(0, Math.floor(Number(frameDoc?.rev || 0) || 0));
    const doc = {
      defaultMode: cleanMode,
      rev: cleanRev,
      updatedAt: Number(frameDoc?.updatedAt || Date.now()),
      updatedBy: String(frameDoc?.updatedBy || ''),
      source: String(frameDoc?.source || 'local'),
      ...(frameDoc?.dirtyToStore !== undefined ? { dirtyToStore: Boolean(frameDoc.dirtyToStore) } : {})
    };
    this._lastAppliedClaudeModeKey = `${cleanRev}:${cleanMode}`;
    const resetSessionOverrides = Boolean(opts.resetSessionOverrides);
    try {
      this.claudeBridge?.syncSharedClaudePermissionMode?.({
        force: true,
        resetSessionOverrides
      });
    } catch {}
    if (this.vscode?.commands) {
      this.vscode.commands
        .executeCommand('antigravityHub.claudeSyncPermissionMode', {
          force: true,
          resetSessionOverrides
        })
        .catch(() => {});
    }
    if (this.hub) {
      this.hub.lastPosted = null;
      try {
        this.hub.render?.();
      } catch {}
    }
    const alreadyStored =
      opts.alreadyStored !== undefined
        ? Boolean(opts.alreadyStored)
        : cleanRev > 0 && !doc.dirtyToStore;
    if (opts.pushEdge === true) {
      try {
        this.edgeClient?.pushClaudePermissionMode?.({
          ...doc,
          alreadyStored
        });
      } catch {}
    }
    if (this.wsHub && this.wsHub.clients.size > 0 && opts.broadcastWs !== false) {
      this.wsHub.broadcast({
        type: 'claude_permission_mode',
        alreadyStored,
        ...doc
      });
    }
    if (opts.notifyState !== false) {
      this.notifyStateUpdated();
    }
    return doc;
  }

  async applyLocalClaudePermissionMode(mode, meta = {}, opts = {}) {
    const written = writeSharedClaudePermissionMode(mode, meta, opts.writeOptions || {});
    if (!written || !written.ok) {
      return written || { ok: false, error: 'Failed to write Claude permission mode' };
    }
    const frameDoc = written.claudePermissionMode || written.cache || {
      defaultMode: written.defaultMode,
      rev: Math.max(0, Math.floor(Number(meta.rev || 0) || 0)),
      updatedAt: Number(meta.updatedAt || Date.now()),
      updatedBy: String(meta.updatedBy || ''),
      source: String(meta.source || 'local'),
      dirtyToStore: Boolean(meta.dirtyToStore)
    };
    this.syncInMemoryClaudePermissionMode(frameDoc, opts);
    return written;
  }

  delegateClaudeModeToPrimaryBridge(payload = {}, timeoutMs = 8500) {
    const port = Number(this.port || 0);
    if (port <= 0) return Promise.resolve(null);
    return new Promise((resolve) => {
      let settled = false;
      const done = (val) => {
        if (settled) return;
        settled = true;
        resolve(val);
      };
      try {
        const tok = this.getDerivedBridgeToken();
        const bodyBuf = Buffer.from(JSON.stringify(payload), 'utf8');
        const req = http.request(
          {
            hostname: '127.0.0.1',
            port,
            path: '/api/claude-permission-mode',
            method: 'POST',
            timeout: timeoutMs,
            headers: {
              'Content-Type': 'application/json',
              'Content-Length': bodyBuf.length,
              ...(tok ? { Authorization: `Bearer ${tok}` } : {})
            }
          },
          (res) => {
            const chunks = [];
            res.on('data', (c) => chunks.push(c));
            res.on('end', () => {
              const status = Number(res.statusCode || 0);
              if (status === 401 || status === 403 || status >= 500 || status <= 0) {
                done(null);
                return;
              }
              try {
                const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
                if (parsed && typeof parsed === 'object' && typeof parsed.ok === 'boolean') {
                  done(parsed);
                  return;
                }
              } catch {}
              done(null);
            });
          }
        );
        req.on('error', () => done(null));
        req.on('timeout', () => {
          try {
            req.destroy();
          } catch {}
          done(null);
        });
        req.end(bodyBuf);
      } catch {
        done(null);
      }
    });
  }

  async handleIncomingEdgeClaudeMode(msg = {}, opts = {}) {
    const mode = normalizeExplicitClaudeMode(msg?.defaultMode || msg?.mode);
    if (!mode) {
      return { ok: false, error: 'Invalid Claude permission mode' };
    }
    const fromLocalChannel = Boolean(opts.fromLocalChannel);
    const shouldPushEdge =
      fromLocalChannel &&
      Boolean(msg?.alreadyStored || msg?.loopbackFanout) &&
      msg?.edgeBroadcasted !== true &&
      msg?.skipEdgeBroadcast !== true;
    const incomingRev = Math.max(0, Math.floor(Number(msg?.rev || 0) || 0));
    const incomingUpdatedAt = Math.max(0, Math.floor(Number(msg?.updatedAt || 0) || 0));
    const localCache = readLocalClaudePermissionCache();
    if (localCache) {
      const localRev = Math.max(0, Math.floor(Number(localCache.rev || 0) || 0));
      if (incomingRev > 0 && localRev > 0 && incomingRev < localRev) {
        return { ok: true, skipped: 'stale_rev', claudePermissionMode: localCache };
      }
      if (incomingRev > 0 && incomingRev === localRev && localCache.defaultMode === mode) {
        const key = `${incomingRev}:${mode}`;
        if (this._lastAppliedClaudeModeKey !== key || Boolean(msg?.loopbackFanout)) {
          const syncedDoc = this.syncInMemoryClaudePermissionMode(
            {
              ...localCache,
              defaultMode: mode,
              rev: incomingRev,
              updatedAt: Number(localCache.updatedAt || incomingUpdatedAt || Date.now()),
              updatedBy: String(localCache.updatedBy || msg?.updatedBy || ''),
              source: String(localCache.source || msg?.source || 'local')
            },
            {
              resetSessionOverrides: true,
              broadcastWs: true,
              pushEdge: shouldPushEdge,
              alreadyStored: Boolean(msg?.alreadyStored || incomingRev > 0),
              notifyState: true
            }
          );
          return { ok: true, defaultMode: mode, fannedOut: true, claudePermissionMode: syncedDoc };
        }
        return { ok: true, skipped: 'same_rev', claudePermissionMode: localCache };
      }
      if (incomingRev === 0 && localRev > 0) {
        return { ok: true, skipped: 'unversioned_vs_store', claudePermissionMode: localCache };
      }
      if (
        incomingRev === 0 &&
        localRev === 0 &&
        incomingUpdatedAt > 0 &&
        incomingUpdatedAt + 1000 < Number(localCache.updatedAt || 0)
      ) {
        return { ok: true, skipped: 'stale_timestamp', claudePermissionMode: localCache };
      }
    }
    const needsStoreHeal = incomingRev === 0 && !msg?.alreadyStored;
    const written = await this.applyLocalClaudePermissionMode(
      mode,
      {
        rev: incomingRev > 0 ? incomingRev : Math.max(0, Math.floor(Number(localCache?.rev || 0) || 0)),
        updatedAt: incomingUpdatedAt || Date.now(),
        updatedBy: String(msg?.updatedBy || 'Edge Fleet').slice(0, 80),
        source: String(msg?.source || 'edge_ws').slice(0, 48),
        dirtyToStore: needsStoreHeal
      },
      {
        resetSessionOverrides: true,
        pushEdge: shouldPushEdge,
        alreadyStored: Boolean(msg?.alreadyStored)
      }
    );
    return {
      ok: Boolean(written?.ok),
      defaultMode: mode,
      claudePermissionMode:
        written?.claudePermissionMode || written?.cache || this.getClaudePermissionModeSnapshot()
    };
  }

  async setFleetClaudePermissionMode(rawMode, meta = {}) {
    const mode = normalizeExplicitClaudeMode(rawMode);
    if (!mode) {
      return {
        ok: false,
        statusCode: 400,
        error:
          'Invalid Claude permission mode. Expected bypassPermissions, auto, plan, acceptEdits, or default.'
      };
    }
    const updatedBy = String(
      meta.updatedBy || this.deviceInfo?.name || os.hostname() || ''
    )
      .trim()
      .slice(0, 80);
    const source = String(meta.source || 'theo-hub')
      .trim()
      .slice(0, 48);

    const isStandbyBridge = !this.listening && Boolean(this.standbyBindTimer);
    if (
      isStandbyBridge &&
      meta.skipPrimaryLoopback !== true &&
      meta.skipStorePatch !== true &&
      Number(this.port || 0) > 0
    ) {
      const delegated = await this.delegateClaudeModeToPrimaryBridge({
        defaultMode: mode,
        ...(meta.expectedRev !== undefined ? { expectedRev: meta.expectedRev } : {}),
        source,
        updatedBy
      });
      if (delegated && delegated.ok) {
        const appliedDoc = delegated.claudePermissionMode || {
          defaultMode: normalizeExplicitClaudeMode(delegated.defaultMode) || mode,
          rev: 0,
          updatedAt: Date.now(),
          updatedBy,
          source
        };
        this.syncInMemoryClaudePermissionMode(appliedDoc, {
          resetSessionOverrides: meta.resetSessionOverrides !== false,
          broadcastWs: false,
          pushEdge: false,
          notifyState: true
        });
        return delegated;
      }
      if (delegated && delegated.ok === false) {
        return delegated;
      }
    }

    const prevCache = readLocalClaudePermissionCache();
    const willPatchStore = meta.skipStorePatch !== true;
    let storeConfirmed = !willPatchStore && Number(meta.rev || 0) > 0;
    let finalDoc = {
      defaultMode: mode,
      rev: Math.max(
        Math.max(0, Math.floor(Number(prevCache?.rev || 0) || 0)),
        Math.max(0, Math.floor(Number(meta.rev || 0) || 0))
      ),
      updatedAt: Number(meta.updatedAt || Date.now()),
      updatedBy,
      source,
      dirtyToStore: willPatchStore
    };

    const hasStoreRelay = Boolean(willPatchStore && this.relayConfig?.url && this.relayConfig?.key);
    await this.applyLocalClaudePermissionMode(mode, finalDoc, {
      resetSessionOverrides: meta.resetSessionOverrides !== false,
      broadcastWs: false,
      notifyState: false,
      writeOptions: hasStoreRelay ? { skipSharedFile: true } : {}
    });

    if (hasStoreRelay) {
      const expectedRev = Math.max(
        0,
        Math.floor(
          Number(
            meta.expectedRev !== undefined
              ? meta.expectedRev
              : !prevCache?.dirtyToStore
                ? prevCache?.rev || 0
                : 0
          ) || 0
        )
      );
      try {
        const ack = await this.postStore(
          {
            key: this.relayConfig.key,
            op: 'patch',
            ackOnly: true,
            patch: {
              claude_permission_mode: {
                defaultMode: mode,
                ...(expectedRev > 0 ? { expectedRev } : {}),
                updatedBy,
                source
              }
            }
          },
          8000
        );
        const storeDoc = ack?.claude_permission_mode || ack?.docs?.claude_permission_mode;
        if (storeDoc && VALID_CLAUDE_PERMISSION_MODES.has(storeDoc.defaultMode)) {
          storeConfirmed = true;
          finalDoc = {
            defaultMode: storeDoc.defaultMode,
            rev: Math.max(0, Math.floor(Number(storeDoc.rev || 0) || 0)),
            updatedAt: Number(storeDoc.updatedAt || Date.now()),
            updatedBy: String(storeDoc.updatedBy || updatedBy),
            source: String(storeDoc.source || source),
            dirtyToStore: false
          };
          if (finalDoc.defaultMode !== mode) {
            await this.applyLocalClaudePermissionMode(finalDoc.defaultMode, finalDoc, {
              resetSessionOverrides: true,
              broadcastWs: false,
              notifyState: false
            });
          } else {
            const synced = writeSharedClaudePermissionMode(finalDoc.defaultMode, finalDoc);
            const syncedSummary = synced?.claudePermissionMode || synced?.cache;
            if (syncedSummary) {
              finalDoc = { ...finalDoc, ...syncedSummary };
            }
          }
        }
      } catch {}
      if (!storeConfirmed) {
        writeSharedClaudePermissionMode(finalDoc.defaultMode, finalDoc);
      }
    }

    const alreadyStored = storeConfirmed && Number(finalDoc.rev || 0) > 0 && !finalDoc.dirtyToStore;
    this._lastAppliedClaudeModeKey = `${Math.max(0, Math.floor(Number(finalDoc.rev || 0) || 0))}:${finalDoc.defaultMode}`;
    if (
      meta.skipPrimaryLoopback !== true &&
      ((!this.listening && Boolean(this.standbyBindTimer)) || meta.notifyPrimaryLoopback === true) &&
      Number(this.port || 0) > 0
    ) {
      try {
        const tok = this.getDerivedBridgeToken();
        const bodyBuf = Buffer.from(
          JSON.stringify({
            ...finalDoc,
            alreadyStored,
            loopbackFanout: true,
            skipStorePatch: alreadyStored
          }),
          'utf8'
        );
        const reqLoop = http.request(
          {
            hostname: '127.0.0.1',
            port: this.port,
            path: '/api/claude-permission-mode',
            method: 'POST',
            timeout: 1200,
            headers: {
              'Content-Type': 'application/json',
              'Content-Length': bodyBuf.length,
              ...(tok ? { Authorization: `Bearer ${tok}` } : {})
            }
          },
          (resLoop) => resLoop.resume()
        );
        reqLoop.on('error', () => {});
        reqLoop.on('timeout', () => {
          try {
            reqLoop.destroy();
          } catch {}
        });
        reqLoop.end(bodyBuf);
      } catch {}
    }
    if (meta.skipEdgeBroadcast !== true) {
      try {
        this.edgeClient?.pushClaudePermissionMode?.({
          ...finalDoc,
          alreadyStored
        });
      } catch {}
    }
    if (this.wsHub && this.wsHub.clients.size > 0) {
      this.wsHub.broadcast({
        type: 'claude_permission_mode',
        alreadyStored,
        ...finalDoc
      });
    }
    this.notifyStateUpdated();
    return {
      ok: true,
      defaultMode: finalDoc.defaultMode,
      claudePermissionMode: finalDoc
    };
  }

  async reconcileClaudePermissionModeWithStore(docs = {}) {
    const rawStoreDoc = docs?.claude_permission_mode;
    const storeDoc =
      rawStoreDoc &&
      typeof rawStoreDoc === 'object' &&
      VALID_CLAUDE_PERMISSION_MODES.has(rawStoreDoc.defaultMode)
        ? rawStoreDoc
        : null;
    const paths = resolveClaudePermissionModePaths();
    const localCache = readLocalClaudePermissionCache({ localCachePath: paths.cacheFile });
    const disk = readDiskSharedClaudePermissionFile(paths.sharedFile);

    if (storeDoc) {
      const storeRev = Math.max(0, Math.floor(Number(storeDoc.rev || 0) || 0));
      const storeUpdatedAt = Math.max(0, Math.floor(Number(storeDoc.updatedAt || 0) || 0));
      const localRev = Math.max(0, Math.floor(Number(localCache?.rev || 0) || 0));
      const refRev = Math.max(storeRev, localRev);
      const hasSyncedBaseline =
        refRev === 0 ||
        (Number(localCache?.lastSyncedDiskMtimeMs || 0) > 0 &&
          Boolean(localCache?.lastSyncedDiskMode));
      const isStaleSyncedDisk =
        !hasSyncedBaseline ||
        (disk.rev > 0 && disk.rev < refRev) ||
        (Number(localCache?.lastSyncedDiskRev || 0) > 0 &&
          disk.rev > 0 &&
          disk.rev < Number(localCache.lastSyncedDiskRev));
      const diskEditedLocally = Boolean(
        localCache &&
          disk.exists &&
          disk.valid &&
          !isStaleSyncedDisk &&
          disk.mode !== localCache.lastSyncedDiskMode &&
          disk.mtimeMs > Number(localCache.lastSyncedDiskMtimeMs || 0) + 50 &&
          disk.mtimeMs > storeUpdatedAt + 500
      );

      if (diskEditedLocally) {
        return this.setFleetClaudePermissionMode(disk.mode, {
          expectedRev: storeRev,
          source: 'disk_edit',
          updatedBy: this.deviceInfo?.name || os.hostname() || ''
        });
      }

      const offlineLocalNewer = Boolean(
        localCache &&
          localCache.dirtyToStore &&
          Number(localCache.updatedAt || 0) > storeUpdatedAt
      );
      if (offlineLocalNewer) {
        return this.setFleetClaudePermissionMode(localCache.defaultMode, {
          expectedRev: storeRev,
          source: localCache.source || 'offline_local',
          updatedBy: localCache.updatedBy || this.deviceInfo?.name || os.hostname() || '',
          updatedAt: Number(localCache.updatedAt || Date.now())
        });
      }

      if (
        !localCache ||
        storeRev > localRev ||
        (storeRev === localRev && localCache.defaultMode !== storeDoc.defaultMode)
      ) {
        await this.applyLocalClaudePermissionMode(
          storeDoc.defaultMode,
          { ...storeDoc, dirtyToStore: false },
          {
            resetSessionOverrides: Boolean(
              localCache && localCache.defaultMode !== storeDoc.defaultMode
            )
          }
        );
        return { ok: true, action: 'pulled_from_store', claudePermissionMode: storeDoc };
      }

      if (
        localCache.dirtyToStore ||
        (disk.exists &&
          (!disk.valid || disk.mode !== storeDoc.defaultMode || disk.hasLegacyMeta))
      ) {
        await this.applyLocalClaudePermissionMode(
          storeDoc.defaultMode,
          { ...storeDoc, dirtyToStore: false },
          {
            resetSessionOverrides: false
          }
        );
        return { ok: true, action: 'healed_disk_from_store', claudePermissionMode: storeDoc };
      }

      return { ok: true, action: 'in_sync', claudePermissionMode: storeDoc };
    }

    const cur = resolveSharedClaudePermissionModeInfo();
    if (this.relayConfig?.url && this.relayConfig?.key) {
      try {
        const seedAck = await this.postStore(
          {
            key: this.relayConfig.key,
            op: 'patch',
            ackOnly: true,
            patch: {
              claude_permission_mode: {
                defaultMode: cur.defaultMode,
                ifMissing: true,
                source: 'host_seed',
                updatedBy: this.deviceInfo?.name || os.hostname() || ''
              }
            }
          },
          8000
        );
        const seeded = seedAck?.claude_permission_mode || seedAck?.docs?.claude_permission_mode;
        if (seeded && VALID_CLAUDE_PERMISSION_MODES.has(seeded.defaultMode)) {
          await this.applyLocalClaudePermissionMode(seeded.defaultMode, seeded, {
            resetSessionOverrides: seeded.defaultMode !== cur.defaultMode
          });
          return { ok: true, action: 'seeded_store', claudePermissionMode: seeded };
        }
      } catch {}
    }
    return { ok: true, action: 'local_only', claudePermissionMode: cur };
  }

  forwardStreamDeltaToLocalClients(delta) {
    if (!delta) return;
    if (this.wsHub) {
      this.wsHub.broadcast(delta);
    }
    if (this.sseClients.size > 0) {
      const frame = `event: stream_delta\ndata: ${JSON.stringify(delta)}\n\n`;
      for (const client of Array.from(this.sseClients)) {
        try {
          client.write(frame);
        } catch {
          this.sseClients.delete(client);
        }
      }
    }
  }

  handleStreamDelta(delta) {
    this.forwardStreamDeltaToLocalClients(delta);
    if (this.edgeClient) {
      this.edgeClient.pushStreamDelta(delta);
    }
  }

  getUnifiedFleetDevices() {
    const byId = new Map();
    const selfPcSetup = readCachedPcSetupSummary() || null;
    const selfDev = {
      id: this.deviceInfo.id,
      name: this.deviceInfo.name,
      role: this.deviceInfo.role,
      hostname: this.deviceInfo.hostname,
      platform: this.deviceInfo.platform,
      capabilities: this.deviceInfo.capabilities,
      lanIps: this.deviceInfo.lanIps,
      online: true,
      isSelf: true,
      activeRuns: this.directRunner ? this.directRunner.getActiveRuns().length : 0,
      pcSetup: selfPcSetup,
      // Unsaved git working folders on this PC (theo-worktree-guard.py --report-json, hourly); travels
      // like pcSetup so the Workspaces tab of THEO Remote lists every PC's folders.
      unsavedWork: readFleetUnsavedWorkSummary(),
      lastSeen: Date.now()
    };
    byId.set(selfDev.id, selfDev);

    for (const [devId, ds] of Object.entries(this.remoteDeviceStates || {})) {
      if (!devId || devId === selfDev.id) continue;
      const d = ds?.device || {};
      const updatedAt = Number(ds?.updatedAt || d.lastSeen || 0);
      const dsRows = Array.isArray(ds?.snapshot?.rows)
        ? ds.snapshot.rows
        : Array.isArray(ds?.rows)
          ? ds.rows
          : [];
      byId.set(devId, {
        id: devId,
        name: d.name || devId,
        role: d.role || HOST_ROLE,
        hostname: d.hostname || '',
        platform: d.platform || 'win32',
        capabilities: Array.isArray(d.capabilities) ? d.capabilities : ['antigravity', 'claude'],
        online: Date.now() - updatedAt < 60000,
        isSelf: false,
        sessionCount: dsRows.length,
        pcSetup: sanitizePublicPcSetupSummary(d.pcSetup) || null,
        unsavedWork: sanitizePeerUnsavedWork(d.unsavedWork),
        lastSeen: updatedAt
      });
    }

    for (const ed of this.edgeClient ? this.edgeClient.getFleetDevices() : []) {
      if (!ed || !ed.id) continue;
      if (ed.id === selfDev.id) continue;
      const prev = byId.get(ed.id) || {};
      byId.set(ed.id, {
        ...prev,
        ...ed,
        pcSetup: sanitizePublicPcSetupSummary(ed.pcSetup) || prev.pcSetup || null,
        // The edge relay's device list carries no unsaved-work list: keep the copy from the store.
        unsavedWork: sanitizePeerUnsavedWork(ed.unsavedWork) || prev.unsavedWork || null,
        online: Boolean(ed.online || prev.online),
        isSelf: false,
        lastSeen: Math.max(Number(ed.lastSeen || 0), Number(prev.lastSeen || 0))
      });
    }

    return Array.from(byId.values()).sort((a, b) => {
      if (a.isSelf && !b.isSelf) return -1;
      if (!a.isSelf && b.isSelf) return 1;
      if (a.online && !b.online) return -1;
      if (!a.online && b.online) return 1;
      return (b.lastSeen || 0) - (a.lastSeen || 0);
    });
  }

  broadcastLocalFleetUpdate() {
    if (this.wsHub && this.wsHub.clients.size > 0) {
      this.wsHub.broadcast({
        type: 'devices_presence',
        devices: this.getUnifiedFleetDevices(),
        ts: Date.now()
      });
    }
    this.notifyStateUpdated();
  }

  async buildCompactHostSnapshot() {
    const full = await this.buildFullState({ localOnly: true });
    const slimRows = (full.rows || [])
      .filter((r) => r && !r.remotePeer && r.source !== 'cloud-relay')
      .slice(0, 100)
      .map((r) => ({
        ...r,
        lastAssistantText: String(r.lastAssistantText || '').slice(0, 220),
        bgTasks: Array.isArray(r.bgTasks) ? r.bgTasks.slice(-6) : []
      }));
    return {
      generatedAt: Date.now(),
      device: {
        id: this.deviceInfo.id,
        name: this.deviceInfo.name,
        role: this.deviceInfo.role,
        hostname: this.deviceInfo.hostname,
        homedir: os.homedir(),
        capabilities: this.deviceInfo.capabilities,
        pcSetup: readCachedPcSetupSummary() || null,
        unsavedWork: readFleetUnsavedWorkSummary()
      },
      rows: slimRows,
      groups: Array.isArray(full.groups) ? full.groups : [],
      summary: full.summary || null,
      summaryByProvider: full.summaryByProvider || null,
      topSessions: Array.isArray(full.topSessions) ? full.topSessions.slice(0, 10) : [],
      accountOrder: Array.isArray(full.accountOrder) ? full.accountOrder : [],
      approvals: full.approvals || [],
      workspaces: (full.workspaces || []).map((w) => ({
        ...w,
        diffPatch: undefined
      })),
      providers: full.providers || null,
      usage: full.usage || null,
      account: full.account || null,
      claudePermissionMode: full.claudePermissionMode || this.getClaudePermissionModeSnapshot()
    };
  }

  readLocalBgTaskLog(id, taskId, providerHint = '') {
    const cleanId = String(id || '').trim();
    const cleanTaskId = String(taskId || '').trim();
    if (!cleanId || !cleanTaskId) {
      return { ok: false, error: 'Missing id or taskId' };
    }
    const thread = (this.hub?.snapshot?.threads || []).find((t) => t.id === cleanId);
    const provider =
      providerHint ||
      thread?.provider ||
      (this.store?.claudeFileById?.has?.(cleanId) ? 'claude' : 'antigravity');
    let taskObj = (thread?.backgroundTasks || []).find(
      (t) => t.id === cleanTaskId || t.fullId === cleanTaskId
    );
    if (!taskObj && this.store) {
      const logPath = this.store.getTranscriptLogPath(cleanId, provider);
      if (logPath) {
        const storeParsed =
          provider === 'claude'
            ? this.store.parseClaudeSessionFile(logPath, cleanId)
            : this.store.parseTranscriptFile(logPath);
        taskObj = (storeParsed?.backgroundTasks || []).find(
          (t) => t.id === cleanTaskId || t.fullId === cleanTaskId
        );
      }
    }
    const output = this.store?.readBackgroundTaskOutput
      ? this.store.readBackgroundTaskOutput(
          cleanId,
          provider,
          taskObj || { id: cleanTaskId, fullId: cleanTaskId, kind: 'task' },
          10000
        )
      : taskObj?.outputPreview || '';
    return {
      ok: true,
      sessionId: cleanId,
      taskId: cleanTaskId,
      provider,
      state: taskObj?.state || 'completed',
      output
    };
  }

  getSafePreviewRoots(sessionId = '') {
    const roots = [];
    const seen = new Set();
    const addRoot = (dir, id = '', label = '') => {
      if (!dir) return;
      const resolved = path.resolve(dir);
      const key = process.platform === 'win32' ? resolved.toLowerCase() : resolved;
      if (seen.has(key) || !fs.existsSync(resolved)) return;
      seen.add(key);
      roots.push({ path: resolved, id: id || path.basename(resolved), label: label || path.basename(resolved) });
    };
    if (sessionId) {
      const thread = (this.hub?.snapshot?.threads || []).find((t) => t.id === sessionId);
      if (thread?.cwd && !isSensitivePreviewPath(thread.cwd)) {
        addRoot(thread.cwd, 'session-cwd', path.basename(thread.cwd));
      }
    }
    for (const wsDef of BHFIRMS_WORKSPACES) {
      addRoot(path.join(os.homedir(), ...wsDef.rel), wsDef.id, wsDef.name);
    }
    addRoot(path.join(os.homedir(), '.gemini', 'antigravity', 'brain'), 'agy-artifacts', 'Artifacts');
    return roots;
  }

  async readSafeFilePreview(opts = {}) {
    const rawTarget = String(opts.path || opts.uri || opts.file || '').trim();
    if (!rawTarget) {
      return { ok: false, status: 400, error: 'Missing file path' };
    }
    const parsed = parseFileTargetAndLineRange(rawTarget);
    const startLine = Number(opts.startLine || parsed.startLine || 0);
    const endLine = Number(opts.endLine || parsed.endLine || startLine || 0);
    if (!parsed.cleanPath || isSensitivePreviewPath(rawTarget) || isSensitivePreviewPath(parsed.cleanPath)) {
      return { ok: false, status: 403, error: 'Preview blocked: restricted or sensitive file path' };
    }

    const roots = this.getSafePreviewRoots(String(opts.sessionId || opts.threadId || '').trim());
    const preferredWs = String(opts.workspaceId || '').trim();
    if (preferredWs) {
      roots.sort((a, b) => (a.id === preferredWs ? -1 : b.id === preferredWs ? 1 : 0));
    }

    let matchedFile = '';
    let matchedRoot = null;
    const normInput = parsed.cleanPath.replace(/\//g, path.sep);

    if (path.isAbsolute(normInput)) {
      for (const r of roots) {
        if (isRealPathInsideRoot(normInput, r.path) && !isSensitivePreviewPath(normInput)) {
          try {
            if (fs.statSync(normInput).isFile()) {
              matchedFile = path.resolve(normInput);
              matchedRoot = r;
              break;
            }
          } catch {}
        }
      }
      if (!matchedFile) {
        return { ok: false, status: 403, error: 'File is outside authorized workspaces or does not exist' };
      }
    } else {
      const cleanRel = normInput.replace(/^[\\/]+/, '');
      for (const r of roots) {
        const candidate = path.resolve(r.path, cleanRel);
        if (isRealPathInsideRoot(candidate, r.path) && !isSensitivePreviewPath(candidate)) {
          try {
            if (fs.statSync(candidate).isFile()) {
              matchedFile = candidate;
              matchedRoot = r;
              break;
            }
          } catch {}
        }
      }
      // Fallback: single-level search inside workspace subdirs (e.g. js/app.js when only app.js was clicked)
      if (!matchedFile && !cleanRel.includes(path.sep)) {
        const commonDirs = ['', 'js', 'css', 'src', 'scripts', 'resources', 'build', 'test', 'compat'];
        outer: for (const r of roots) {
          for (const sub of commonDirs) {
            const candidate = sub ? path.resolve(r.path, sub, cleanRel) : path.resolve(r.path, cleanRel);
            if (isRealPathInsideRoot(candidate, r.path) && !isSensitivePreviewPath(candidate)) {
              try {
                if (fs.statSync(candidate).isFile()) {
                  matchedFile = candidate;
                  matchedRoot = r;
                  break outer;
                }
              } catch {}
            }
          }
        }
      }
      if (!matchedFile) {
        return { ok: false, status: 404, error: `File not found in active workspaces: ${parsed.cleanPath}` };
      }
    }

    if (isSensitivePreviewPath(matchedFile) || isSensitivePreviewPath(fs.realpathSync(matchedFile))) {
      return { ok: false, status: 403, error: 'Preview blocked: sensitive target resolved' };
    }

    let stat;
    try {
      stat = fs.statSync(matchedFile);
    } catch {
      return { ok: false, status: 404, error: 'Unable to stat file' };
    }

    const maxBytes = 160 * 1024;
    const truncated = stat.size > maxBytes;
    const readLen = Math.min(stat.size, maxBytes);
    const buf = Buffer.alloc(readLen);
    let fd = null;
    try {
      fd = fs.openSync(matchedFile, 'r');
      fs.readSync(fd, buf, 0, readLen, 0);
    } finally {
      if (fd !== null) {
        try {
          fs.closeSync(fd);
        } catch {}
      }
    }

    // Binary check in first 4 KB
    const probeLen = Math.min(readLen, 4096);
    for (let i = 0; i < probeLen; i++) {
      if (buf[i] === 0) {
        return {
          ok: true,
          isBinary: true,
          file: path.basename(matchedFile),
          relPath: path.relative(matchedRoot.path, matchedFile).replace(/\\/g, '/'),
          fullPath: matchedFile,
          workspaceId: matchedRoot.id,
          workspaceName: matchedRoot.label,
          size: stat.size,
          mtime: stat.mtimeMs
        };
      }
    }

    const content = buf.toString('utf8');
    const relPath = path.relative(matchedRoot.path, matchedFile).replace(/\\/g, '/');
    let gitDiff = '';
    if (matchedRoot.id !== 'agy-artifacts') {
      try {
        const wsDef = BHFIRMS_WORKSPACES.find((w) => w.id === matchedRoot.id);
        const gitPrefix = wsDef?.gitDirRel
          ? [
              `--git-dir=${path.join(os.homedir(), ...wsDef.gitDirRel)}`,
              `--work-tree=${matchedRoot.path}`
            ]
          : [];
        const { stdout: diffOut } = await execFileAsync(
          'git',
          [...gitPrefix, 'diff', '--no-color', 'HEAD', '--', relPath],
          { cwd: matchedRoot.path, timeout: 3000, maxBuffer: 256 * 1024, windowsHide: true }
        );
        gitDiff = String(diffOut || '').slice(0, 24000);
      } catch {}
    }

    return {
      ok: true,
      isBinary: false,
      truncated,
      file: path.basename(matchedFile),
      ext: path.extname(matchedFile).replace(/^\./, '').toLowerCase(),
      relPath,
      fullPath: matchedFile,
      workspaceId: matchedRoot.id,
      workspaceName: matchedRoot.label,
      size: stat.size,
      mtime: stat.mtimeMs,
      lineCount: countLines(content),
      startLine,
      endLine,
      content,
      gitDiff,
      diffPatch: gitDiff
    };
  }

  resolveSafeStudioWorkspace(opts = {}) {
    const requestedWs = String(opts.workspaceId || '').trim();
    const sessionId = String(opts.sessionId || opts.threadId || '').trim();

    if (requestedWs && requestedWs !== 'default' && requestedWs !== 'auto') {
      const wsDef = BHFIRMS_WORKSPACES.find(
        (w) =>
          w.id === requestedWs ||
          w.name.toLowerCase() === requestedWs.toLowerCase() ||
          w.rel[w.rel.length - 1] === requestedWs
      );
      if (!wsDef) {
        return { ok: false, status: 403, error: `Unauthorized or unknown workspace: ${requestedWs}` };
      }
      const fullPath = path.join(os.homedir(), ...wsDef.rel);
      if (!fs.existsSync(fullPath)) {
        return { ok: false, status: 404, error: `Workspace folder does not exist on this host: ${wsDef.name}` };
      }
      return { ok: true, wsDef, fullPath };
    }

    if (sessionId) {
      const thread = (this.hub?.snapshot?.threads || []).find((t) => t.id === sessionId);
      if (thread?.cwd && fs.existsSync(thread.cwd)) {
        const normCwd =
          process.platform === 'win32'
            ? path.resolve(thread.cwd).toLowerCase()
            : path.resolve(thread.cwd);
        const matchedDef = BHFIRMS_WORKSPACES.find((w) => {
          const p = path.join(os.homedir(), ...w.rel);
          const normP = process.platform === 'win32' ? path.resolve(p).toLowerCase() : path.resolve(p);
          return normCwd === normP || normCwd.startsWith(normP + path.sep);
        });
        if (matchedDef) {
          return {
            ok: true,
            wsDef: matchedDef,
            fullPath: path.join(os.homedir(), ...matchedDef.rel)
          };
        }
      }
    }

    const fallbackOrder = ['theo', 'theo-hub', 'isabi', 'planner'];
    for (const fbId of fallbackOrder) {
      const def = BHFIRMS_WORKSPACES.find((w) => w.id === fbId);
      if (def) {
        const p = path.join(os.homedir(), ...def.rel);
        if (fs.existsSync(p)) return { ok: true, wsDef: def, fullPath: p };
      }
    }
    for (const def of BHFIRMS_WORKSPACES) {
      const p = path.join(os.homedir(), ...def.rel);
      if (fs.existsSync(p)) return { ok: true, wsDef: def, fullPath: p };
    }
    return { ok: false, status: 404, error: 'No local workspaces found on host' };
  }

  async inspectStudioCapabilities(opts = {}) {
    const resolved = this.resolveSafeStudioWorkspace(opts);
    if (!resolved.ok) return resolved;
    const { wsDef, fullPath } = resolved;
    const gitPrefix = wsDef.gitDirRel
      ? [
          `--git-dir=${path.join(os.homedir(), ...wsDef.gitDirRel)}`,
          `--work-tree=${fullPath}`
        ]
      : [];

    const [gitInfo, ports] = await Promise.all([
      inspectWorkspaceGit(wsDef, Boolean(opts.includeDiff)),
      probeLocalDevPorts()
    ]);
    const rawChecks = discoverWorkspaceChecks(fullPath, gitPrefix);
    const checks = rawChecks.map((c) => ({
      id: c.id,
      label: c.label,
      category: c.category,
      commandPreview: c.commandPreview
    }));
    const skills = discoverAvailableSkills(fullPath);

    return {
      ok: true,
      device: {
        id: this.deviceInfo?.id || 'workstation',
        name: this.deviceInfo?.name || 'Workstation'
      },
      workspace: gitInfo,
      checks,
      skills,
      ports,
      updatedAt: Date.now()
    };
  }

  async runSafeStudioCheck(opts = {}) {
    const checkId = String(opts.checkId || '').trim();
    if (!checkId || checkId.length > 96 || /[\0\r\n;|&$`<>]/.test(checkId)) {
      return { ok: false, status: 403, error: 'Invalid or forbidden studio check identifier' };
    }
    const resolved = this.resolveSafeStudioWorkspace(opts);
    if (!resolved.ok) return resolved;
    const { wsDef, fullPath } = resolved;
    const gitPrefix = wsDef.gitDirRel
      ? [
          `--git-dir=${path.join(os.homedir(), ...wsDef.gitDirRel)}`,
          `--work-tree=${fullPath}`
        ]
      : [];

    const allowlist = discoverWorkspaceChecks(fullPath, gitPrefix);
    const spec = allowlist.find((c) => c.id === checkId);
    if (!spec) {
      return {
        ok: false,
        status: 403,
        error: `Check "${checkId}" is not in the authorized workspace allowlist`
      };
    }

    this.activeStudioChecksCount = Number(this.activeStudioChecksCount || 0);
    if (this.activeStudioChecksCount >= 2) {
      return {
        ok: false,
        status: 429,
        error: 'Maximum concurrent studio checks (2) already running; please wait.'
      };
    }

    this.activeStudioChecksCount += 1;
    const startedAt = Date.now();
    try {
      let stdout = '';
      let stderr = '';
      let exitCode = 0;
      try {
        const res = await execFileAsync(spec._bin, spec._args, {
          cwd: fullPath,
          timeout: Number(spec._timeoutMs || 15000),
          maxBuffer: 1024 * 1024,
          windowsHide: true,
          shell: false
        });
        stdout = String(res.stdout || '');
        stderr = String(res.stderr || '');
      } catch (err) {
        stdout = String(err?.stdout || '');
        stderr = String(err?.stderr || err?.message || '');
        exitCode = typeof err?.code === 'number' ? err.code : 1;
      }
      const durationMs = Math.max(1, Date.now() - startedAt);
      const combined = [stdout.trim(), stderr.trim()].filter(Boolean).join('\n');
      const truncated = combined.length > 48000;
      const output = truncated ? `${combined.slice(0, 48000)}\n...[truncated]` : combined;
      const diagnostics = parseCheckDiagnostics(combined, fullPath);

      return {
        ok: true,
        passed: exitCode === 0,
        exitCode,
        checkId: spec.id,
        label: spec.label,
        category: spec.category,
        commandPreview: spec.commandPreview,
        workspaceId: wsDef.id,
        workspaceName: wsDef.name,
        durationMs,
        truncated,
        output: output || (exitCode === 0 ? 'Check passed with 0 output.' : 'Check failed.'),
        diagnostics
      };
    } finally {
      this.activeStudioChecksCount = Math.max(0, (this.activeStudioChecksCount || 1) - 1);
    }
  }

  async handleWsOrEdgeRpc(msg = {}) {
    const action = String(msg.action || msg.type || '').trim();
    const targetDev = String(msg.targetDeviceId || '').trim();
    const isRemoteTarget =
      Boolean(targetDev) && targetDev !== 'auto' && targetDev !== this.deviceInfo.id;

    if (action === 'getState') {
      const st = await this.buildFullState();
      return { ok: true, state: st };
    }
    if (action === 'getDevices') {
      return {
        ok: true,
        self: this.deviceInfo,
        devices: this.getUnifiedFleetDevices(),
        edgeRelay: this.edgeClient?.getStatus() || null
      };
    }
    if (action === 'uploadAttachmentChunk') {
      if (isRemoteTarget) {
        if (this.edgeClient?.getStatus()?.connected) {
          return this.edgeClient.forwardRpcToDevice(targetDev, msg, 12000);
        }
        return { ok: false, error: `Target device (${targetDev}) is offline`, targetDeviceId: targetDev };
      }
      const uploadId = String(msg.uploadId || '').replace(/[^a-zA-Z0-9_-]/g, '');
      const chunkIndex = Number(msg.chunkIndex || 0);
      const totalChunks = Number(msg.totalChunks || 1);
      const data = String(msg.data || '');
      if (!uploadId || totalChunks < 1 || totalChunks > 64 || data.length > 750000) {
        return { ok: false, error: 'Invalid upload chunk parameters' };
      }
      const now = Date.now();
      for (const [k, entry] of this.attachmentUploadChunks.entries()) {
        if (now - entry.createdAt > 5 * 60 * 1000) this.attachmentUploadChunks.delete(k);
      }
      let entry = this.attachmentUploadChunks.get(uploadId);
      if (!entry) {
        entry = {
          name: String(msg.name || 'attachment'),
          mime: String(msg.mime || 'application/octet-stream'),
          totalChunks,
          chunks: new Array(totalChunks).fill(''),
          receivedCount: 0,
          createdAt: now
        };
        this.attachmentUploadChunks.set(uploadId, entry);
      }
      if (chunkIndex >= 0 && chunkIndex < entry.totalChunks && !entry.chunks[chunkIndex]) {
        entry.chunks[chunkIndex] = data;
        entry.receivedCount += 1;
      }
      return {
        ok: true,
        uploadId,
        receivedCount: entry.receivedCount,
        complete: entry.receivedCount >= entry.totalChunks
      };
    }
    if (action === 'getThread') {
      if (isRemoteTarget) {
        if (this.edgeClient?.getStatus()?.connected) {
          const peerRes = await this.edgeClient.forwardRpcToDevice(targetDev, msg, 10000);
          if (peerRes && peerRes.ok && peerRes.thread) return peerRes;
        }
        const reqId = String(msg.id || msg.threadId || '').trim();
        if (reqId && this.cachedRemoteThreads && this.cachedRemoteThreads[reqId]) {
          return { ok: true, thread: this.cachedRemoteThreads[reqId], cached: true };
        }
        return {
          ok: false,
          error: `Target device (${targetDev}) is offline and thread is not cached`,
          targetDeviceId: targetDev
        };
      }
      const detail = await this.getThreadDetail(msg.id || msg.threadId || '', msg.provider || '');
      return { ok: true, thread: detail };
    }
    if (action === 'getWorkspace') {
      if (isRemoteTarget) {
        if (this.edgeClient?.getStatus()?.connected) {
          const peerRes = await this.edgeClient.forwardRpcToDevice(targetDev, msg, 10000);
          if (peerRes && peerRes.ok) return peerRes;
        }
        return {
          ok: false,
          error: `Target device (${targetDev}) is offline`,
          targetDeviceId: targetDev
        };
      }
      const wsId = msg.id || 'theo-hub';
      const wsDef = BHFIRMS_WORKSPACES.find((w) => w.id === wsId) || BHFIRMS_WORKSPACES[0];
      const relFile = String(msg.file || '').trim();
      const info = await inspectWorkspaceGit(wsDef, true);
      let fileData = null;
      if (relFile && info.exists && !isSensitivePreviewPath(relFile)) {
        const safePath = path.resolve(info.path, relFile);
        if (
          isRealPathInsideRoot(safePath, info.path) &&
          !isSensitivePreviewPath(safePath) &&
          fs.existsSync(safePath)
        ) {
          const stat = fs.statSync(safePath);
          if (stat.isFile() && stat.size <= 200 * 1024) {
            fileData = {
              path: relFile,
              size: stat.size,
              mtime: stat.mtimeMs,
              content: fs.readFileSync(safePath, 'utf8')
            };
          }
        }
      }
      return { ok: true, workspace: info, file: fileData };
    }
    if (action === 'getFilePreview') {
      if (isRemoteTarget) {
        if (this.edgeClient?.getStatus()?.connected) {
          const peerRes = await this.edgeClient.forwardRpcToDevice(targetDev, msg, 10000);
          if (peerRes && peerRes.ok) return peerRes;
        }
        return {
          ok: false,
          error: `Target device (${targetDev}) is offline`,
          targetDeviceId: targetDev
        };
      }
      return this.readSafeFilePreview({
        path: msg.path || msg.uri || msg.file || '',
        workspaceId: msg.workspaceId || '',
        sessionId: msg.sessionId || msg.threadId || msg.id || '',
        startLine: msg.startLine || 0,
        endLine: msg.endLine || 0
      });
    }
    if (action === 'getBgTaskLog') {
      if (isRemoteTarget) {
        if (this.edgeClient?.getStatus()?.connected) {
          const peerRes = await this.edgeClient.forwardRpcToDevice(targetDev, msg, 10000);
          if (peerRes && peerRes.ok) return peerRes;
        }
        return {
          ok: false,
          error: `Target device (${targetDev}) is offline`,
          targetDeviceId: targetDev
        };
      }
      return this.readLocalBgTaskLog(
        msg.id || msg.sessionId || msg.threadId || '',
        msg.taskId || '',
        msg.provider || ''
      );
    }
    if (action === 'getStudioCapabilities') {
      if (isRemoteTarget) {
        if (this.edgeClient?.getStatus()?.connected) {
          const peerRes = await this.edgeClient.forwardRpcToDevice(targetDev, msg, 10000);
          if (peerRes && peerRes.ok) return peerRes;
        }
        return {
          ok: false,
          error: `Target device (${targetDev}) is offline`,
          targetDeviceId: targetDev
        };
      }
      return this.inspectStudioCapabilities({
        workspaceId: msg.workspaceId || '',
        sessionId: msg.sessionId || msg.threadId || msg.id || '',
        includeDiff: Boolean(msg.includeDiff)
      });
    }
    if (action === 'runStudioCheck') {
      if (isRemoteTarget) {
        if (this.edgeClient?.getStatus()?.connected) {
          const peerRes = await this.edgeClient.forwardRpcToDevice(targetDev, msg, 25000);
          if (peerRes) return peerRes;
        }
        return {
          ok: false,
          error: `Target device (${targetDev}) is offline`,
          targetDeviceId: targetDev
        };
      }
      return this.runSafeStudioCheck({
        workspaceId: msg.workspaceId || '',
        sessionId: msg.sessionId || msg.threadId || msg.id || '',
        checkId: msg.checkId || ''
      });
    }
    return this.executeDirectCommand(msg);
  }

  // `changedFiles`: repo-relative paths the caller already copied into this window's installed folder (the
  // extension.js hot swap, a signed bundle). Those copies make copyIfDifferent below find nothing to do, so
  // without the list an antigravity-context-window.cjs change would keep serving the stale patched /main.js
  // until the next window reload. A bridge.js change also asks for a forced re-patch, though the callers'
  // own prepatch run usually already covers it (the forced call then returns on prepatchInFlight).
  syncHotReloadedModules(opts = {}) {
    try {
      const extRoot = this.context?.extensionPath || __dirname;
      const preChanged = hotSwapChangeFlags(opts && opts.changedFiles);
      const repoRoot = path.join(os.homedir(), 'bhfirms', 'theo-hub');
      const copyIfDifferent = (srcPath, dstPath) => {
        if (!fs.existsSync(srcPath) || path.resolve(srcPath) === path.resolve(dstPath)) {
          return false;
        }
        try {
          const srcBuf = fs.readFileSync(srcPath);
          if (fs.existsSync(dstPath)) {
            try {
              if (fs.statSync(dstPath).mtimeMs > fs.statSync(srcPath).mtimeMs + 500) {
                return false;
              }
            } catch {}
            const dstBuf = fs.readFileSync(dstPath);
            if (srcBuf.equals(dstBuf)) {
              return false;
            }
          }
          fs.mkdirSync(path.dirname(dstPath), { recursive: true });
          fs.writeFileSync(dstPath, srcBuf);
          return true;
        } catch {
          return false;
        }
      };

      const syncList = [
        'bridge.js',
        'data.js',
        'accounts.js',
        'state.js',
        'store.js',
        'hub.js',
        'activity.js',
        'session-tabs.js',
        'desktop-notify.js',
        'device-identity.js',
        'bundle-updater.js',
        'pc-setup.js',
        'unsaved-work.js',
        'ws-server.js',
        'direct-runner.js',
        'edge-relay-client.js',
        path.join('compat', 'antigravity-tab-state.cjs'),
        path.join('compat', 'antigravity-hub-bridge.cjs'),
        path.join('compat', 'antigravity-context-window.cjs'),
        path.join('compat', 'claude-webview-patches.cjs'),
        path.join('compat', 'claude-hub-bridge.cjs'),
        path.join('compat', 'excel-preview.cjs'),
        path.join('resources', 'hub.js'),
        path.join('resources', 'hub.css'),
        path.join('resources', 'hub.html')
      ];
      let ctxWindowChanged = preChanged.ctxWindowChanged;
      let webviewAssetsChanged = preChanged.webviewAssetsChanged;
      let bridgePatchesChanged = preChanged.bridgePatchesChanged;
      for (const rel of syncList) {
        const src = path.join(repoRoot, rel);
        const dst = path.join(extRoot, rel);
        if (copyIfDifferent(src, dst)) {
          if (rel.endsWith('antigravity-context-window.cjs')) {
            ctxWindowChanged = true;
          }
          if (rel === 'bridge.js' || rel.endsWith('claude-webview-patches.cjs')) {
            bridgePatchesChanged = true;
          }
          if (rel.startsWith(`resources${path.sep}`)) {
            webviewAssetsChanged = true;
          }
        }
      }
      // Also sync compat bridges into any installed anthropic.claude-code or google.google-antigravity extension folder
      try {
        const claudeBridgeFiles = ['claude-hub-bridge.cjs', 'excel-preview.cjs'];
        const agyBridgeFiles = ['antigravity-hub-bridge.cjs', 'antigravity-context-window.cjs', 'antigravity-tab-state.cjs', 'excel-preview.cjs'];
        const extsDir = path.join(os.homedir(), '.vscode', 'extensions');
        if (fs.existsSync(extsDir)) {
          for (const entry of fs.readdirSync(extsDir, { withFileTypes: true })) {
            if (!entry.isDirectory()) continue;
            if (/^anthropic\.claude-code-/i.test(entry.name)) {
              for (const cf of claudeBridgeFiles) {
                const srcCf = path.join(repoRoot, 'compat', cf);
                if (fs.existsSync(srcCf)) {
                  copyIfDifferent(srcCf, path.join(extsDir, entry.name, cf));
                }
              }
            } else if (/^google\.google-antigravity-/i.test(entry.name)) {
              for (const bf of agyBridgeFiles) {
                const srcBf = path.join(repoRoot, 'compat', bf);
                if (fs.existsSync(srcBf)) {
                  if (
                    copyIfDifferent(srcBf, path.join(extsDir, entry.name, bf)) &&
                    bf === 'antigravity-context-window.cjs'
                  ) {
                    ctxWindowChanged = true;
                  }
                }
              }
            }
          }
        }
      } catch {}
      for (const modName of [
        './compat/claude-webview-patches.cjs',
        './bridge',
        './data',
        './accounts',
        './state',
        './store',
        './activity',
        './session-tabs',
        './desktop-notify',
        './bundle-updater',
        './direct-runner',
        './edge-relay-client',
        './hub',
        './compat/antigravity-tab-state.cjs',
        './compat/antigravity-hub-bridge.cjs',
        './compat/antigravity-context-window.cjs',
        './compat/claude-hub-bridge.cjs',
        './compat/excel-preview.cjs'
      ]) {
        try {
          delete require.cache[require.resolve(modName)];
        } catch {}
      }
      if (bridgePatchesChanged) {
        try {
          const freshBridge = require('./bridge');
          // Worker thread when the loaded bridge.js offers it, so a forced re-patch never blocks this host.
          const prepatch =
            freshBridge?.prepatchInstalledExtensionsAsync || freshBridge?.prepatchInstalledExtensions;
          if (typeof prepatch === 'function') {
            Promise.resolve(prepatch(extRoot, { force: true })).catch(() => {});
          }
        } catch {}
      }
      for (const cacheKey of Object.keys(require.cache)) {
        if (
          /google\.google-antigravity-.*(antigravity-(hub-bridge|context-window|tab-state)|excel-preview)\.cjs$/i.test(
            cacheKey
          ) ||
          /anthropic\.claude-code-.*(claude-hub-bridge|excel-preview)\.cjs$/i.test(cacheKey)
        ) {
          delete require.cache[cacheKey];
        }
      }
      try {
        const { TheoDirectRunner: FreshDirectRunner } = require('./direct-runner');
        if (this.directRunner && FreshDirectRunner?.prototype) {
          Object.setPrototypeOf(this.directRunner, FreshDirectRunner.prototype);
        }
      } catch {}
      try {
        const { TheoEdgeRelayClient: FreshEdgeRelayClient } = require('./edge-relay-client');
        if (this.edgeClient && FreshEdgeRelayClient?.prototype) {
          Object.setPrototypeOf(this.edgeClient, FreshEdgeRelayClient.prototype);
          this.edgeClient.onClaudePermissionMode = (msg) =>
            this.handleIncomingEdgeClaudeMode(msg);
        }
      } catch {}
      try {
        const epMod = require('./compat/excel-preview.cjs');
        if (this.vscode && epMod?.ensureExcelPreviewRegistered) {
          epMod.ensureExcelPreviewRegistered(this.vscode, this.context);
        }
      } catch {}
      try {
        this.claudeBridge = require('./compat/claude-hub-bridge.cjs');
        this.claudeBridge?.hotUpgradeLiveState?.();
      } catch {}
      try {
        const ctxMod = require('./compat/antigravity-context-window.cjs');
        this.agyBridge = require('./compat/antigravity-hub-bridge.cjs');
        const liveAgyState = this.agyBridge?.getBridgeState?.();
        if (liveAgyState) {
          ctxMod?.installContextWindowSupport?.(liveAgyState);
          this.agyBridge?.hotUpgradeLiveState?.(liveAgyState, this.vscode, this.hub);
          this.agyBridge?.installNotificationDedupeSupport?.(liveAgyState);
        }
        const proxySt = globalThis[Symbol.for('bhfirms.antigravityHub.contextWindowProxyState')];
        if (proxySt) {
          if (typeof ctxMod?.patchMainJsSource === 'function') {
            proxySt.patchMainJsSource = ctxMod.patchMainJsSource;
          }
          if (ctxWindowChanged) {
            proxySt.mainJsCache = null;
            proxySt.mainJsInFlight = null;
          }
        }
      } catch {}
      const {
        AccountVaultManager: FreshAccountVault,
        defaultHttpsJsonRequest: freshHttpsJsonRequest
      } = require('./accounts');
      const { HubStateStore: FreshStateStore } = require('./state');
      const { AntigravityDataStore: FreshStore } = require('./store');
      const { SessionActivityTracker: FreshActivity } = require('./activity');
      const { SessionTabManager: FreshTabs } = require('./session-tabs');
      const { HubProvider: FreshHub } = require('./hub');
      if (!this.accountVault) {
        this.accountVault = new FreshAccountVault({
          onStateChange: () => {
            this.hub?.refresh?.({ forceQuota: false }).catch(() => {});
            this.notifyStateUpdated();
          }
        });
      } else {
        Object.setPrototypeOf(this.accountVault, FreshAccountVault.prototype);
        if (!this.accountVault.hasCustomHttpsJsonRequest && freshHttpsJsonRequest) {
          this.accountVault.httpsJsonRequest = freshHttpsJsonRequest;
        }
        this.accountVault.agyQuotaInFlightById?.clear?.();
        this.accountVault.claudeQuotaInFlightById?.clear?.();
      }
      if (this.state && FreshStateStore?.prototype) {
        Object.setPrototypeOf(this.state, FreshStateStore.prototype);
      }
      if (this.hub?.stateStore && FreshStateStore?.prototype) {
        Object.setPrototypeOf(this.hub.stateStore, FreshStateStore.prototype);
      }
      if (this.store) {
        Object.setPrototypeOf(this.store, FreshStore.prototype);
        this.store.cachedSqliteMtimeMs = 0;
        this.store.cachedClaudeVscMtimeMs = 0;
        if (
          FreshStore?.PARSE_CACHE_VERSION &&
          Number(this.store.parseCacheVersion || 0) !== Number(FreshStore.PARSE_CACHE_VERSION)
        ) {
          this.store.transcriptCache?.clear?.();
          this.store.claudeSessionCache?.clear?.();
          this.store.parseCacheVersion = Number(FreshStore.PARSE_CACHE_VERSION);
        }
        if (
          (this.store.transcriptCache?.size || 0) === 0 &&
          (this.store.claudeSessionCache?.size || 0) === 0
        ) {
          this.store.readPersistedParseCache?.();
        }
      }
      if (this.tabs) {
        Object.setPrototypeOf(this.tabs, FreshTabs.prototype);
      }
      if (this.hub?.activity) {
        Object.setPrototypeOf(this.hub.activity, FreshActivity.prototype);
      }
      if (this.hub) {
        Object.setPrototypeOf(this.hub, FreshHub.prototype);
        this.hub.accountVault = this.accountVault;
        if (
          this.hub.refreshInFlight &&
          (!this.hub.refreshStartedAt || Date.now() - Number(this.hub.refreshStartedAt || 0) > 10000)
        ) {
          this.hub.refreshInFlight = null;
          setTimeout(() => {
            this.hub?.refresh?.({ force: true, forceQuota: true }).catch(() => {});
          }, 50);
        }
        let maxWebviewAssetMtime = 0;
        for (const assetRel of ['hub.js', 'hub.css', 'hub.html']) {
          try {
            const st = fs.statSync(path.join(extRoot, 'resources', assetRel));
            if (st.mtimeMs > maxWebviewAssetMtime) {
              maxWebviewAssetMtime = Math.floor(st.mtimeMs);
            }
          } catch {}
        }
        const needsInitialMultiAcctUpgrade = !this.hub.__multiAcctWebviewV1;
        const needsWebviewMtimeUpgrade =
          maxWebviewAssetMtime > 0 &&
          maxWebviewAssetMtime !== Number(this.hub.__webviewAssetsMtime || 0);
        if (
          (webviewAssetsChanged || needsInitialMultiAcctUpgrade || needsWebviewMtimeUpgrade) &&
          this.vscode &&
          this.hub.views &&
          this.hub.views.size > 0
        ) {
          const tplPath = path.join(extRoot, 'resources', 'hub.html');
          if (fs.existsSync(tplPath)) {
            const tpl = fs.readFileSync(tplPath, 'utf8');
            const bust = Date.now();
            for (const view of this.hub.views) {
              try {
                const webview = view.webview;
                const nonce = crypto.randomBytes(18).toString('hex');
                const uri = (name) =>
                  `${webview.asWebviewUri(this.vscode.Uri.joinPath(this.context.extensionUri, 'resources', name)).toString()}?v=${bust}`;
                webview.html = tpl
                  .replaceAll('{{cspSource}}', webview.cspSource)
                  .replaceAll('{{nonce}}', nonce)
                  .replaceAll('{{css}}', uri('hub.css'))
                  .replaceAll('{{js}}', uri('hub.js'));
              } catch {}
            }
            this.hub.__multiAcctWebviewV1 = true;
            this.hub.__webviewAssetsMtime = maxWebviewAssetMtime;
            this.hub.lastPosted = null;
          }
        }
        setTimeout(() => {
          this.hub.refresh({ forceQuota: false }).catch(() => {});
        }, 80);
      }
      let maxSeenMtime = Date.now();
      for (const rel of ['remote.js', ...syncList]) {
        for (const root of [repoRoot, extRoot]) {
          try {
            const st = fs.statSync(path.join(root, rel));
            const m = Math.floor(st.mtimeMs);
            if (m > maxSeenMtime) maxSeenMtime = m;
          } catch {}
        }
      }
      this.codeMtime = maxSeenMtime;
    } catch {}
  }

  loadLocalPersonalLedger() {
    const base = { reminders: [], deletedIds: [], dailyScores: {}, teamRoster: [], updatedAt: 0 };
    try {
      if (fs.existsSync(this.personalLedgerPath)) {
        const raw = JSON.parse(fs.readFileSync(this.personalLedgerPath, 'utf8'));
        if (raw && typeof raw === 'object') {
          this.personalLedger = base;
          this.mergePersonalLedger(raw, { skipSave: true });
          return this.personalLedger;
        }
      }
    } catch {}
    return base;
  }

  syncFromDiskPersonalLedger() {
    try {
      if (fs.existsSync(this.personalLedgerPath)) {
        const raw = JSON.parse(fs.readFileSync(this.personalLedgerPath, 'utf8'));
        if (raw && typeof raw === 'object') {
          this.mergePersonalLedger(raw, { skipSave: true });
        }
      }
    } catch {}
  }

  saveLocalPersonalLedger() {
    try {
      const dir = path.dirname(this.personalLedgerPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(
        this.personalLedgerPath,
        JSON.stringify(this.personalLedger, null, 2),
        'utf8'
      );
    } catch {}
  }

  normalizeDayScoreRecord(rec, isoKey = '') {
    const r = rec && typeof rec === 'object' ? rec : {};
    const iso = String(isoKey || r.iso || r.date || '').trim();
    const rawDos = r.dos && typeof r.dos === 'object' ? r.dos : {};
    const rawDonts = r.donts && typeof r.donts === 'object' ? r.donts : {};

    const normDo = (v) => (v === 'full' || v === 'half' ? v : 'none');
    const pickDo = (a, b) => {
      const na = normDo(a);
      const nb = normDo(b);
      if (na !== 'none') return na;
      return nb;
    };

    const normDont = (v) => {
      if (v === 'slip' || v === 'broken') return 'slip';
      if (v === 'half') return 'half';
      return 'intact';
    };
    const pickDont = (a, b) => {
      const na = normDont(a);
      const nb = normDont(b);
      if (na !== 'intact') return na;
      return nb;
    };

    const socialVal = pickDo(rawDos.social, rawDos.socializing);
    const gamesVal = pickDont(rawDonts.games, rawDonts.videogames);
    const seriesVal = normDont(rawDonts.series);
    const musicVal = normDont(rawDonts.music);
    const socialMediaVal = normDont(rawDonts.socialmedia);
    const nsfwVal = pickDont(rawDonts.nsfw, rawDonts.adult18);

    return {
      iso,
      date: iso,
      dos: {
        wake: normDo(rawDos.wake),
        work: normDo(rawDos.work),
        skills: normDo(rawDos.skills),
        fitness: normDo(rawDos.fitness),
        social: socialVal,
        socializing: socialVal
      },
      donts: {
        games: gamesVal,
        videogames: gamesVal,
        series: seriesVal,
        music: musicVal,
        socialmedia: socialMediaVal,
        nsfw: nsfwVal,
        adult18: nsfwVal
      },
      updatedAt: Number(r.updatedAt || 0)
    };
  }

  normalizeReminderItem(rem) {
    if (!rem || typeof rem !== 'object') return null;
    const item = { ...rem };
    item.title = String(item.title || '').trim();
    if (!item.id || !item.title) return null;

    if (!item.subTag && item.subGroup) {
      item.subTag = item.subGroup;
    }
    if (!item.assigneeName && item.subTag && String(item.subTag).startsWith('👤')) {
      item.assigneeName = String(item.subTag).replace(/^👤\s*/, '').trim();
    }
    if (item.assigneeName && !item.isDelegated) {
      item.isDelegated = true;
    }
    if (item.isDelegated && !item.delegationStatus) {
      item.delegationStatus = 'assigned';
    }
    if (item.category === 'ideas' || item.category === 'want_to_do') {
      if (
        item.kind !== 'wait' &&
        !item.matureAt &&
        !item.planDate &&
        !item.hasAlarm &&
        item.horizon !== 'today' &&
        item.horizon !== 'tomorrow'
      ) {
        item.kind = 'parked';
        item.dueAt = 0;
        item.matureAt = 0;
        item.recur = 'none';
      }
    }
    const isHold =
      item.kind === 'wait' ||
      item.kind === 'payment' ||
      item.category === 'verify' ||
      item.category === 'shipping' ||
      item.category === 'payments';
    if (isHold) {
      const t = Number(item.matureAt || item.dueAt || 0);
      item.matureAt = t;
      item.dueAt = t;
    }
    return item;
  }

  mergePersonalLedger(incoming, opts = {}) {
    if (!incoming || typeof incoming !== 'object') return false;
    let changed = false;
    if (!this.personalLedger || typeof this.personalLedger !== 'object') {
      this.personalLedger = { reminders: [], deletedIds: [], dailyScores: {}, teamRoster: [], updatedAt: 0 };
    }
    if (!Array.isArray(this.personalLedger.reminders)) this.personalLedger.reminders = [];
    if (!Array.isArray(this.personalLedger.deletedIds)) this.personalLedger.deletedIds = [];
    if (!this.personalLedger.dailyScores || typeof this.personalLedger.dailyScores !== 'object') {
      this.personalLedger.dailyScores = {};
    }

    const PURGED_DEMO_IDS = [
      'tm_rami',
      'tm_nadine',
      'tm_jad',
      'tm_karim',
      'tm_maya',
      'rem_1792434196959_1u79',
      'rem_1792434196958_ar52',
      'rem_1792434196957_72fe',
      'rem_1792434196957_ynbs',
      'rem_1792434196955_f5yu',
      'rem_1792434196955_0h5v',
      'rem_1792434196954_908z',
      'rem_1792434196947_4xuc',
      'rem_1792434196946_xlrd',
      'rem_1792434196946_1scv'
    ];
    const PURGED_DEMO_TITLES = new Set([
      'idea for later: automated whatsapp daily briefing',
      'want to play padel in batroun this weekend',
      'family dinner with mom tonight',
      'hold wtc supplier wire $6,500',
      'review q4 bhfirms insurance renewal schedule',
      'shipping time for shacman brake pads order in 5 days',
      "paid $120 on whish for electricity and it didn't show up on the app",
      'check korri shacman customs clearance documents',
      'reconcile blanca resort october soa journal',
      'inspect wtc filter press cloths and send pressure reading tomorrow'
    ]);

    const delSet = new Set([...this.personalLedger.deletedIds, ...PURGED_DEMO_IDS]);
    if (Array.isArray(incoming.deletedIds)) {
      for (const dId of incoming.deletedIds) {
        if (dId && !delSet.has(dId)) {
          delSet.add(dId);
          changed = true;
        }
      }
    }
    const isDemoRem = (r) => {
      if (!r || !r.id) return false;
      if (delSet.has(r.id)) return true;
      const t = String(r.title || '').trim().toLowerCase();
      return PURGED_DEMO_TITLES.has(t);
    };
    for (const r of this.personalLedger.reminders) {
      if (r && r.id && (r.deleted || isDemoRem(r)) && !delSet.has(r.id)) {
        delSet.add(r.id);
        changed = true;
      }
    }
    if (Array.isArray(incoming.reminders)) {
      for (const r of incoming.reminders) {
        if (r && r.id && (r.deleted || isDemoRem(r)) && !delSet.has(r.id)) {
          delSet.add(r.id);
          changed = true;
        }
      }
    }

    if (Array.isArray(incoming.reminders) || delSet.size > 0) {
      const map = new Map();
      for (const rawR of this.personalLedger.reminders) {
        const r = this.normalizeReminderItem(rawR);
        if (r && r.id && !r.deleted && !delSet.has(r.id) && !isDemoRem(r)) map.set(r.id, r);
      }
      if (Array.isArray(incoming.reminders)) {
        for (const rawRem of incoming.reminders) {
          const rem = this.normalizeReminderItem(rawRem);
          if (!rem || !rem.id || rem.deleted || delSet.has(rem.id) || isDemoRem(rem)) continue;
          const cur = map.get(rem.id);
          if (!cur || Number(rem.updatedAt || 0) >= Number(cur.updatedAt || 0)) {
            map.set(rem.id, rem);
            changed = true;
          }
        }
      }
      const seenActiveTitle = new Map();
      const deduped = [];
      const sorted = Array.from(map.values()).sort(
        (a, b) => Number(b.updatedAt || b.createdAt || 0) - Number(a.updatedAt || a.createdAt || 0)
      );
      for (const item of sorted) {
        if (!item.completed) {
          const normTitle = String(item.title || '').trim().toLowerCase();
          if (seenActiveTitle.has(normTitle)) {
            delSet.add(item.id);
            changed = true;
            continue;
          }
          seenActiveTitle.set(normTitle, item.id);
        }
        deduped.push(item);
      }
      this.personalLedger.reminders = deduped
        .sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0))
        .slice(0, 300);
    }

    this.personalLedger.deletedIds = Array.from(delSet).slice(-400);

    // Normalize existing dailyScores in place
    for (const [iso, curRec] of Object.entries(this.personalLedger.dailyScores)) {
      this.personalLedger.dailyScores[iso] = this.normalizeDayScoreRecord(curRec, iso);
    }

    if (incoming.dailyScores && typeof incoming.dailyScores === 'object') {
      for (const [iso, rec] of Object.entries(incoming.dailyScores)) {
        if (!rec || typeof rec !== 'object') continue;
        const normInc = this.normalizeDayScoreRecord(rec, iso);
        const cur = this.personalLedger.dailyScores[iso];
        if (!cur || Number(normInc.updatedAt || 0) >= Number(cur.updatedAt || 0)) {
          this.personalLedger.dailyScores[iso] = normInc;
          changed = true;
        }
      }
    }

    if (!Array.isArray(this.personalLedger.teamRoster)) {
      this.personalLedger.teamRoster = [];
    }
    const prevRosterLen = this.personalLedger.teamRoster.length;
    this.personalLedger.teamRoster = this.personalLedger.teamRoster.filter(
      (m) => m && m.id && !delSet.has(m.id)
    );
    if (this.personalLedger.teamRoster.length !== prevRosterLen) changed = true;

    if (Array.isArray(incoming.teamRoster)) {
      const rMap = new Map();
      for (const m of this.personalLedger.teamRoster) {
        if (m && m.id && !delSet.has(m.id)) rMap.set(m.id, m);
      }
      for (const m of incoming.teamRoster) {
        if (m && m.id && !delSet.has(m.id)) {
          const prev = rMap.get(m.id);
          if (!prev || JSON.stringify(prev) !== JSON.stringify(m)) {
            rMap.set(m.id, m);
            changed = true;
          }
        }
      }
      this.personalLedger.teamRoster = Array.from(rMap.values());
    }

    if (incoming.prayerConfig && typeof incoming.prayerConfig === 'object') {
      const curTs = Number(this.personalLedger.prayerConfig?.updatedAt || 0);
      const incTs = Number(incoming.prayerConfig.updatedAt || 0);
      if (!this.personalLedger.prayerConfig || incTs >= curTs) {
        if (JSON.stringify(this.personalLedger.prayerConfig || null) !== JSON.stringify(incoming.prayerConfig)) {
          this.personalLedger.prayerConfig = incoming.prayerConfig;
          changed = true;
        }
      }
    }

    if (changed && !opts.skipSave) {
      this.personalLedger.updatedAt = Math.max(
        Number(this.personalLedger.updatedAt || 0),
        Number(incoming.updatedAt || Date.now())
      );
      this.saveLocalPersonalLedger();
    } else if (!opts.skipSave) {
      this.saveLocalPersonalLedger();
    }
    return changed;
  }

  mergeDelegatedTasksFromCloud(delegatedMap) {
    if (!delegatedMap || typeof delegatedMap !== 'object') return false;
    if (!this.personalLedger || !Array.isArray(this.personalLedger.reminders)) return false;
    let changed = false;
    if (!Array.isArray(this.pendingDelegationAlerts)) {
      this.pendingDelegationAlerts = [];
    }
    for (const rem of this.personalLedger.reminders) {
      if (!rem || !rem.id) continue;
      const dTask = delegatedMap[rem.id];
      if (!dTask || typeof dTask !== 'object') continue;
      const staffTs = dTask.staffUpdatedAt ? new Date(dTask.staffUpdatedAt).getTime() : 0;
      const prevStatus = rem.delegationStatus || 'assigned';
      const prevNote = rem.staffNote || '';
      const nextStatus = dTask.delegationStatus || prevStatus;
      const nextNote = dTask.staffNote || prevNote;
      const statusChanged =
        Boolean(dTask.delegationStatus) &&
        nextStatus !== prevStatus &&
        staffTs >= Number(rem.ownerStatusAt || 0);
      const noteChanged = Boolean(dTask.staffNote) && nextNote !== prevNote;

      if (statusChanged || noteChanged) {
        rem.delegationStatus = nextStatus;
        rem.staffNote = nextNote;
        rem.staffUpdatedAt = dTask.staffUpdatedAt || rem.staffUpdatedAt || new Date().toISOString();
        rem.updatedAt = Math.max(Number(rem.updatedAt || 0), staffTs || Date.now());
        changed = true;

        const hasPortalPushTargets =
          Array.isArray(dTask.ownerPushTargets) && dTask.ownerPushTargets.length > 0;
        if (
          !hasPortalPushTargets &&
          (nextStatus === 'seen' || nextStatus === 'working' || nextStatus === 'done' || noteChanged) &&
          staffTs > 0 &&
          Date.now() - staffTs < 12 * 3600 * 1000
        ) {
          const alertKey = `del-upd-${rem.id}-${nextStatus}-${staffTs || nextNote.slice(0, 24)}`;
          if (!this.pushedAlertIds.has(alertKey)) {
            this.pendingDelegationAlerts.push({
              key: alertKey,
              taskId: rem.id,
              title: rem.title || dTask.title || 'Delegated Task',
              assigneeName: rem.assigneeName || dTask.assigneeName || 'Team',
              status: nextStatus,
              staffNote: nextNote,
              subTag: rem.subTag || dTask.subTag || ''
            });
          }
        }
      }
    }
    if (changed) {
      this.personalLedger.updatedAt = Date.now();
      this.saveLocalPersonalLedger();
    }
    return changed;
  }

  isPlannerDevice(d) {
    if (!d || typeof d !== 'object') return false;
    const app = String(d.app || '').trim().toLowerCase();
    const id = String(d.id || '').trim().toLowerCase();
    return app === 'command' || app === 'planner' || id.startsWith('cmd_') || id.startsWith('pln_');
  }

  isTheoDevice(d) {
    if (!d || typeof d !== 'object') return false;
    return !this.isPlannerDevice(d);
  }

  smartClassifyReminder(rem) {
    if (!rem || typeof rem !== 'object') return rem;
    const text = String(rem.title || '').trim();
    const s = text.toLowerCase();
    const tags = [];

    const personMatch = text.match(
      /\b(?:talk to|call|text|message|whatsapp|ask|meet|with|remind|ping|email|check with|follow up with|speak to)\s+([A-Z][a-z]{2,15}(?:\s+[A-Z][a-z]{2,15})?)\b/
    );
    const STOP_NAMES = new Set(['The', 'And', 'For', 'About', 'Tomorrow', 'Today', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Work', 'App', 'Bank', 'Payment', 'Shipping', 'Order', 'Someone']);
    if (personMatch && personMatch[1] && !STOP_NAMES.has(personMatch[1].split(/\s+/)[0])) {
      tags.push({ type: 'person', label: `👤 ${personMatch[1]}`, raw: personMatch[1] });
    }

    const appRules = [
      { label: '📱 Whish', rx: /\b(whish|wish money)\b/i },
      { label: '📱 OMT', rx: /\b(omt)\b/i },
      { label: '📱 Bank / Statement', rx: /\b(bank|audi|blom|byblos|fransabank|neo|statement|wire)\b/i },
      { label: '📱 Stripe / Wise', rx: /\b(stripe|paypal|wise|revolut)\b/i },
      { label: '📱 Power BI', rx: /\b(power\s*bi|pbi)\b/i },
      { label: '📱 Dataverse / ERP', rx: /\b(dataverse|dynamics|erp|sharepoint|tally)\b/i },
      { label: '📱 App Sync', rx: /\b(on the app|certain app|in the app|show up|didn'?t show|not showing)\b/i }
    ];
    for (const a of appRules) {
      if (a.rx.test(text)) {
        tags.push({ type: 'app', label: a.label });
        break;
      }
    }

    const workRules = [
      { label: '🏖️ Resorts', rx: /\b(blanca|la\s*una|palms|voile|platinum|resort|hospitality|beach|cabana|kitchen|pos)\b/i },
      { label: '🏗️ WTC · Mfg', rx: /\b(wtc|bbc|bbconstruction|lions|concrete|batch|cement|quarry|filter\s*press|mixer|manufacturing)\b/i },
      { label: '🚛 Korri · Trading', rx: /\b(korri|shacman|truck|vin|customs|spare\s*part|workshop|trading)\b/i },
      { label: '🏢 Real Estate · Ins', rx: /\b(real\s*estate|tenant|lease|rent|unit|insurance|policy|brokerage|claim|underwrit)\b/i },
      { label: '🏛️ Holding · Finance', rx: /\b(holding|vat|tax|audit|coa|payroll|accounting|journal|soa)\b/i },
      { label: '⚡ Tech · THEO', rx: /\b(theo|claude|antigravity|pwa|flow|power\s*automate|script|github|vscode)\b/i }
    ];
    for (const w of workRules) {
      if (w.rx.test(text)) {
        tags.push({ type: 'work_sub', label: w.label });
        break;
      }
    }

    let category = rem.category || 'work';
    if (!rem.customGroup) {
      if (
        /\b(didn'?t show|did not show|not showing|show up|showed up|on the app|in the app|certain app|pending transaction|verify|reconcile|cleared|reflected|balance|charge|refund)\b/i.test(s) ||
        (/\b(paid|sent|transferred)\b/i.test(s) && /\b(app|account|show|check|pending|yet|still)\b/i.test(s))
      ) {
        category = 'verify';
      } else if (/\b(ship|shipping|shipment|delivery|deliver|package|parcel|courier|tracking|dhl|aramex|fedex|cargo|container|arrival|arrive|ordered|order status|freight|transit)\b/i.test(s)) {
        category = 'shipping';
      } else if (/\b(family|mom|mother|dad|father|parents|wife|kids|brother|sister|uncle|aunt|cousin|home|house|groceries|dinner|lunch with|birthday|doctor|dentist|school|pharmacy|gift)\b/i.test(s)) {
        category = 'family';
      } else if (/\b(talk to|call|text|whatsapp|message|follow up|reach out|check in with|speak with|speak to|ask |meet with|remind |reply to|contact |catch up)\b/i.test(s)) {
        category = 'people';
      } else if (/\b(idea|concept|maybe build|brainstorm|feature idea|automation idea|side project|someday|what if|prototype|experiment|for later)\b/i.test(s)) {
        category = 'ideas';
      } else if (/\b(want to|wanna|bucket list|try out|visit|travel|trip|watch|read|buy for myself|weekend|hobby|learn|explore|plan to do|things to do)\b/i.test(s)) {
        category = 'want_to_do';
      } else if (rem.kind === 'wait' || /\b(pay|payment|invoice|supplier|vendor|installment|transfer|settle|wire|deposit|cheque|check|hold payment|wait to pay)\b/i.test(s)) {
        category = 'payments';
      } else {
        category = 'work';
      }
    }

    const subTag = tags.find((t) => t.type === 'work_sub' || t.type === 'person' || t.type === 'app');
    return {
      ...rem,
      category,
      contextTags: tags,
      subGroup: rem.customGroup || (subTag ? subTag.label : ''),
      updatedAt: Date.now()
    };
  }

  normalizePushDevice(d) {
    if (!d || typeof d !== 'object') return null;
    const raw = d.device && typeof d.device === 'object' ? d.device : d;
    const endpoint = String(raw.endpoint || '').trim();
    const p256dh = String(raw.keys?.p256dh || raw.p256dh || '').trim();
    const auth = String(raw.keys?.auth || raw.auth || '').trim();
    if (!endpoint || !p256dh || !auth) {
      return null;
    }
    const id = String(raw.id || endpoint.slice(-24)).trim();
    const idLower = id.toLowerCase();
    const app = String(
      raw.app || (idLower.startsWith('cmd_') || idLower.startsWith('pln_') ? 'command' : '')
    ).trim();
    const entry = {
      id,
      ...(app ? { app } : {}),
      endpoint,
      p256dh,
      auth,
      keys: { p256dh, auth },
      prefs:
        raw.prefs && typeof raw.prefs === 'object'
          ? raw.prefs
          : {
              enabled: true,
              approvals: true,
              completed: true,
              quota: true,
              morningBriefing: true,
              morningHour: 9,
              eveningDigest: true,
              eveningHour: 20
            },
      ua: raw.ua || '',
      updatedAt: raw.updatedAt || new Date().toISOString()
    };
    if (raw.slots && typeof raw.slots === 'object') {
      entry.slots = raw.slots;
    }
    if (raw.armedPrayers && typeof raw.armedPrayers === 'object') {
      entry.armedPrayers = raw.armedPrayers;
    }
    if (raw.armedTimers && typeof raw.armedTimers === 'object') {
      entry.armedTimers = raw.armedTimers;
    }
    return entry;
  }

  getDevicePlatformClass(d) {
    const ua = String(d?.ua || '').toLowerCase();
    if (ua.includes('iphone')) return 'iphone';
    if (ua.includes('ipad')) return 'ipad';
    if (ua.includes('android')) return 'android';
    if (ua.includes('macintosh') || ua.includes('mac os x')) return 'mac';
    if (ua.includes('windows')) return 'windows';
    const ep = String(d?.endpoint || '').toLowerCase();
    if (ep.includes('web.push.apple.com')) return 'apple';
    return ua ? ua.slice(0, 32) : 'default';
  }

  dedupePushDevices(items) {
    if (!Array.isArray(items)) return [];
    const normalized = items.map((d) => this.normalizePushDevice(d)).filter(Boolean);
    // Sort oldest to newest so newest wins on collision
    normalized.sort(
      (a, b) => (Date.parse(a.updatedAt || '') || 0) - (Date.parse(b.updatedAt || '') || 0)
    );
    const byEndpoint = new Map();
    for (const d of normalized) {
      byEndpoint.set(d.endpoint, d);
    }
    const byId = new Map();
    for (const d of byEndpoint.values()) {
      byId.set(d.id, d);
    }
    const byAppAndClass = new Map();
    for (const d of byId.values()) {
      const appKey = this.isPlannerDevice(d) ? 'command' : 'theo';
      const cls = this.getDevicePlatformClass(d);
      const compositeKey = `${appKey}::${cls}`;
      const prev = byAppAndClass.get(compositeKey);
      if (prev) {
        if (!d.slots && prev.slots) d.slots = prev.slots;
        if (!d.armedPrayers && prev.armedPrayers) d.armedPrayers = prev.armedPrayers;
        if (!d.armedTimers && prev.armedTimers) d.armedTimers = prev.armedTimers;
      }
      byAppAndClass.set(compositeKey, d);
    }
    return Array.from(byAppAndClass.values()).slice(-8);
  }

  getCloudPrayerTimerKey(d, isoDate, prayerId, isPre = false) {
    const [yy, mm, dd] = String(isoDate || '').split('-').map(Number);
    const dow = new Date(Date.UTC(yy || 2026, (mm || 1) - 1, dd || 1)).getUTCDay();
    const devShort = String(d?.id || String(d?.endpoint || '').slice(-12))
      .replace(/[^a-zA-Z0-9]/g, '')
      .slice(-12);
    return isPre
      ? `prayer_d${dow}_pre_${prayerId}_${devShort}`
      : `prayer_d${dow}_${prayerId}_${devShort}`;
  }

  hasValidCloudTimerExp(doc, targetMs) {
    const expSec = Number(doc?.expSec || 0);
    const baseSec = Math.floor(Number(targetMs || 0) / 1000);
    if (!baseSec || !expSec) return false;
    return expSec >= baseSec + 600 && expSec <= baseSec + 23 * 3600 + 1800;
  }

  getCloudPrayerTimerState(d, isoDate, prayerId, isPre = false, targetEpochMs = 0, nowMs = Date.now()) {
    if (!d || typeof d !== 'object') return { state: 'skip', timerKey: '', cloudId: '' };
    const timerKey = this.getCloudPrayerTimerKey(d, isoDate, prayerId, isPre);
    const specPrefix = isPre ? `${isoDate}_pre_${prayerId}_` : `${isoDate}_${prayerId}_`;
    const hasLiveDocs = Boolean(this.cloudControlDocs && typeof this.cloudControlDocs === 'object');
    const cloudDoc = hasLiveDocs ? this.cloudControlDocs?.[timerKey] : null;
    const cloudId = hasLiveDocs ? String(cloudDoc?.id || '') : '';

    if (cloudId.startsWith(`fired_${specPrefix}`)) {
      return { state: 'fired', timerKey, cloudId };
    }
    if (cloudId.startsWith('failed_')) {
      return { state: 'takeover', timerKey, cloudId };
    }
    if (cloudId.startsWith(`sending_${specPrefix}`)) {
      if (targetEpochMs > 0 && nowMs - targetEpochMs < 75000) {
        return { state: 'armed_waiting', timerKey, cloudId };
      }
      return { state: 'takeover', timerKey, cloudId };
    }
    if (cloudId.startsWith(specPrefix)) {
      const curExpSec = Number(cloudDoc?.expSec || 0);
      if (curExpSec > 0 && curExpSec < Math.floor(nowMs / 1000)) {
        return { state: 'takeover', timerKey, cloudId };
      }
      if (targetEpochMs > 0 && nowMs - targetEpochMs < 75000) {
        return { state: 'armed_waiting', timerKey, cloudId };
      }
      return { state: 'takeover', timerKey, cloudId };
    }
    if (!hasLiveDocs && d.armedPrayers && typeof d.armedPrayers === 'object') {
      const fallbackId = String(d.armedPrayers[timerKey] || '');
      if (fallbackId.startsWith(`fired_${specPrefix}`)) {
        return { state: 'fired', timerKey, cloudId: fallbackId };
      }
      if (fallbackId.startsWith(specPrefix) && targetEpochMs > 0 && nowMs - targetEpochMs < 75000) {
        return { state: 'armed_waiting', timerKey, cloudId: fallbackId };
      }
    }
    return { state: 'missing', timerKey, cloudId };
  }

  getCloudTaskTimerState(d, remId, targetMs, nowMs = Date.now()) {
    if (!d || typeof d !== 'object' || !remId) return { state: 'skip', timerKey: '', cloudId: '' };
    const devShort = String(d?.id || String(d?.endpoint || '').slice(-10))
      .replace(/[^a-zA-Z0-9]/g, '')
      .slice(-10);
    const timerKey = `timer_${remId}_${devShort}`;
    const specPrefix = `${remId}_${targetMs}_`;
    const hasLiveDocs = Boolean(this.cloudControlDocs && typeof this.cloudControlDocs === 'object');
    const cloudDoc = hasLiveDocs ? this.cloudControlDocs?.[timerKey] : null;
    const cloudId = hasLiveDocs ? String(cloudDoc?.id || '') : '';

    if (cloudId.startsWith(`fired_${specPrefix}`)) {
      return { state: 'fired', timerKey, cloudId };
    }
    if (cloudId.startsWith('failed_')) {
      return { state: 'takeover', timerKey, cloudId };
    }
    if (cloudId.startsWith(`sending_${specPrefix}`)) {
      if (targetMs > 0 && nowMs - targetMs < 75000) {
        return { state: 'armed_waiting', timerKey, cloudId };
      }
      return { state: 'takeover', timerKey, cloudId };
    }
    if (cloudId.startsWith(specPrefix)) {
      const curExpSec = Number(cloudDoc?.expSec || 0);
      if (curExpSec > 0 && curExpSec < Math.floor(nowMs / 1000)) {
        return { state: 'takeover', timerKey, cloudId };
      }
      if (targetMs > 0 && nowMs - targetMs < 75000) {
        return { state: 'armed_waiting', timerKey, cloudId };
      }
      return { state: 'takeover', timerKey, cloudId };
    }
    if (!hasLiveDocs && d.armedTimers && typeof d.armedTimers === 'object') {
      const fallbackId = String(d.armedTimers[timerKey] || '');
      if (fallbackId.startsWith(`fired_${specPrefix}`)) {
        return { state: 'fired', timerKey, cloudId: fallbackId };
      }
      if (fallbackId.startsWith(specPrefix) && targetMs > 0 && nowMs - targetMs < 75000) {
        return { state: 'armed_waiting', timerKey, cloudId: fallbackId };
      }
    }
    return { state: 'missing', timerKey, cloudId };
  }

  async refreshCloudControlDocsIfStale(maxAgeMs = 10000) {
    if (!this.relayConfig?.url || !this.relayConfig?.key) return this.cloudControlDocs || null;
    if (this.cloudControlDocs && Date.now() - Number(this.cloudControlDocsAt || 0) <= maxAgeMs) {
      return this.cloudControlDocs;
    }
    try {
      const remoteStore = await httpsJsonRequest(this.relayConfig.url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        body: JSON.stringify({ key: this.relayConfig.key, op: 'get_control' }),
        timeoutMs: 8000
      });
      const docs =
        remoteStore?.docs && typeof remoteStore.docs === 'object'
          ? remoteStore.docs
          : remoteStore || null;
      if (docs && typeof docs === 'object') {
        this.cloudControlDocs = docs;
        this.cloudControlDocsAt = Date.now();
      }
    } catch {}
    return this.cloudControlDocs || null;
  }

  async stampCloudTimersFiredByBridge(patchEntries) {
    if (!patchEntries || typeof patchEntries !== 'object' || !Object.keys(patchEntries).length) return;
    if (!this.cloudControlDocs || typeof this.cloudControlDocs !== 'object') {
      this.cloudControlDocs = {};
    }
    Object.assign(this.cloudControlDocs, patchEntries);
    if (!this.relayConfig?.url || !this.relayConfig?.key) return;
    try {
      await httpsJsonRequest(this.relayConfig.url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
        body: JSON.stringify({
          key: this.relayConfig.key,
          op: 'patch',
          ackOnly: true,
          patch: patchEntries
        }),
        timeoutMs: 8000
      });
    } catch {}
  }

  async ensureCloudPrayerTimersArmed(docs = null) {
    if (this._armingCloudPrayers || (this.server && !this.listening)) return 0;
    if (!this.relayConfig?.url || !this.relayConfig?.key) return 0;
    const nowMs = Date.now();
    if (this._lastCloudPrayerArmCheckAt && nowMs - this._lastCloudPrayerArmCheckAt < 180000) {
      return 0;
    }
    const pCfg = this.personalLedger?.prayerConfig || {};
    if (pCfg.enabled === false) return 0;
    if (!this.pushDevices.length) {
      this.pushDevices = this.loadLocalPushRegistry();
    }
    const subs = this.pushDevices
      .map((d) => this.normalizePushDevice(d))
      .filter((d) => d && this.isPlannerDevice(d) && d.prefs?.enabled !== false && d.prefs?.prayers !== false);
    if (!subs.length) return 0;

    const liveDocs = docs || this.cloudControlDocs;
    if (!liveDocs || typeof liveDocs !== 'object') return 0;

    this._armingCloudPrayers = true;
    this._lastCloudPrayerArmCheckAt = nowMs;
    let armedCount = 0;
    try {
      const todaySched = this.computeShiaPrayersForToday(pCfg);
      if (!todaySched?.isoDate) return 0;
      const [by, bm, bd] = todaySched.isoDate.split('-').map(Number);
      const preMin = Number(pCfg.preRemindMin || 0);

      for (let dayOffset = 0; dayOffset < 4; dayOffset++) {
        const dt = new Date(Date.UTC(by, bm - 1, bd + dayOffset));
        const iso = `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}-${String(dt.getUTCDate()).padStart(2, '0')}`;
        const sched = dayOffset === 0 ? todaySched : this.computeShiaPrayersForToday(pCfg, iso);
        if (!sched || !Array.isArray(sched.prayers)) continue;

        for (const p of sched.prayers) {
          if (!p.enabled) continue;
          for (const sub of subs) {
            if (preMin > 0) {
              const preTargetMs = p.epochMs - preMin * 60000;
              const preDelaySec = Math.round((preTargetMs - Date.now()) / 1000);
              if (preDelaySec >= 20 && preDelaySec <= 4 * 86400) {
                const preKey = this.getCloudPrayerTimerKey(sub, iso, p.id, true);
                const prePrefix = `${iso}_pre_${p.id}_${preTargetMs}`;
                const curPreDoc = liveDocs?.[preKey];
                const curPreId = String(curPreDoc?.id || '');
                const preAlreadyValid =
                  curPreId.startsWith(`fired_${prePrefix}`) ||
                  curPreId.startsWith(`sending_${prePrefix}`) ||
                  ((curPreId === prePrefix || curPreId.startsWith(`${prePrefix}__`)) &&
                    this.hasValidCloudTimerExp(curPreDoc, preTargetMs));
                if (!preAlreadyValid) {
                  const timerId = `${prePrefix}__${crypto.randomBytes(6).toString('hex')}`;
                  const expSec = Math.floor(preTargetMs / 1000) + 12 * 3600;
                  const vapid = await signVapidNode(sub.endpoint, expSec);
                  const bodyB64 = await encryptWebPushNode(sub.keys, {
                    title: `${p.icon} ${p.label} in ${preMin} min · ${p.time24}`,
                    body: `${p.arabic} at ${p.time24} in ${sched.locationName}. ${p.windowNote}`,
                    tag: `prayer-${iso}-${p.id}-pre`,
                    tab: 'prayers',
                    openPrayer: true,
                    url: './?tab=prayers',
                    ts: preTargetMs
                  });
                  const r = await httpsJsonRequest(this.relayConfig.url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
                    body: JSON.stringify({
                      key: this.relayConfig.key,
                      op: 'push_delay',
                      timerKey: preKey,
                      timerId,
                      expSec,
                      delaySec: preDelaySec,
                      endpoint: sub.endpoint,
                      vapid,
                      bodyB64
                    }),
                    timeoutMs: 12000
                  });
                  if (r?.ok) {
                    liveDocs[preKey] = { id: timerId, expSec };
                    armedCount++;
                  }
                }
              }
            }

            const delaySec = Math.round((p.epochMs - Date.now()) / 1000);
            if (delaySec >= 15 && delaySec <= 4 * 86400) {
              const timerKey = this.getCloudPrayerTimerKey(sub, iso, p.id, false);
              const specPrefix = `${iso}_${p.id}_${p.epochMs}`;
              const curDoc = liveDocs?.[timerKey];
              const curId = String(curDoc?.id || '');
              const alreadyValid =
                curId.startsWith(`fired_${specPrefix}`) ||
                curId.startsWith(`sending_${specPrefix}`) ||
                ((curId === specPrefix || curId.startsWith(`${specPrefix}__`)) &&
                  this.hasValidCloudTimerExp(curDoc, p.epochMs));
              if (!alreadyValid) {
                const timerId = `${specPrefix}__${crypto.randomBytes(6).toString('hex')}`;
                const expSec = Math.floor(p.epochMs / 1000) + 12 * 3600;
                const vapid = await signVapidNode(sub.endpoint, expSec);
                const bodyB64 = await encryptWebPushNode(sub.keys, {
                  title: `🕌 ${p.label} Prayer Time · ${p.time24} (${p.arabic})`,
                  body: `${p.label} has entered in ${sched.locationName}. ${p.windowNote}. Hayya 'ala Khayr al-'Amal.`,
                  tag: `prayer-${iso}-${p.id}`,
                  tab: 'prayers',
                  openPrayer: true,
                  url: './?tab=prayers',
                  requireInteraction: true,
                  ts: p.epochMs
                });
                const r = await httpsJsonRequest(this.relayConfig.url, {
                  method: 'POST',
                  headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
                  body: JSON.stringify({
                    key: this.relayConfig.key,
                    op: 'push_delay',
                    timerKey,
                    timerId,
                    expSec,
                    delaySec,
                    endpoint: sub.endpoint,
                    vapid,
                    bodyB64
                  }),
                  timeoutMs: 12000
                });
                if (r?.ok) {
                  liveDocs[timerKey] = { id: timerId, expSec };
                  armedCount++;
                }
              }
            }
          }
        }
      }

      // Also keep upcoming Planner task / wait-timer reminders armed with valid VAPID expSec
      const taskSubs = this.pushDevices
        .map((d) => this.normalizePushDevice(d))
        .filter((d) => d && this.isPlannerDevice(d) && d.prefs?.enabled !== false);
      const reminders = Array.isArray(this.personalLedger?.reminders) ? this.personalLedger.reminders : [];
      for (const rem of reminders) {
        if (!rem || !rem.id || rem.completed || rem.deleted) continue;
        const targetAt = Number(rem.matureAt || rem.dueAt || 0);
        if (!targetAt) continue;
        const remDelaySec = Math.round((targetAt - Date.now()) / 1000);
        if (remDelaySec < 15 || remDelaySec > 25 * 86400) continue;
        const isHold = Boolean(
          rem.matureAt > 0 ||
            rem.kind === 'wait' ||
            rem.category === 'verify' ||
            rem.category === 'shipping' ||
            rem.category === 'payments'
        );
        const isDel = Boolean(rem.isDelegated || rem.assigneeName || rem.category === 'people');
        const cat = String(rem.category || 'work');
        let pushTitle = '⏰ Task Due — Planner';
        if (cat === 'verify') pushTitle = '🔍 Verify on App — Planner';
        else if (cat === 'shipping') pushTitle = '📦 Shipping Timer Ready — Planner';
        else if (cat === 'payments') pushTitle = '💸 Payment Hold Matured — Planner';
        else if (isDel) pushTitle = `👤 Follow-Up Due: ${rem.assigneeName || 'Team'} — Planner`;
        else if (isHold) pushTitle = '⏳ Wait Timer Ready — Planner';
        else if (rem.recur && rem.recur !== 'none') pushTitle = `🔁 ${rem.recur === 'weekly' ? 'Weekly' : 'Daily'} Task Due — Planner`;
        const targetTab = isDel ? 'delegated' : 'tasks';
        const ctxTag = rem.subTag || rem.subGroup || (rem.assigneeName ? `👤 ${rem.assigneeName}` : '');
        const amtTag = Number(rem.amount || 0) > 0 ? ` · $${Number(rem.amount).toLocaleString('en-US')}` : '';

        for (const sub of taskSubs) {
          if (isHold && sub.prefs?.timers === false) continue;
          if (!isHold && sub.prefs?.tasks === false) continue;
          const devShort = String(sub.id || String(sub.endpoint || '').slice(-10))
            .replace(/[^a-zA-Z0-9]/g, '')
            .slice(-10);
          const timerKey = `timer_${rem.id}_${devShort}`;
          const specPrefix = `${rem.id}_${targetAt}_${devShort}`;
          const curDoc = liveDocs?.[timerKey];
          const curId = String(curDoc?.id || '');
          const alreadyValid =
            curId.startsWith(`fired_${specPrefix}`) ||
            curId.startsWith(`sending_${specPrefix}`) ||
            ((curId === specPrefix || curId.startsWith(`${specPrefix}__`)) &&
              this.hasValidCloudTimerExp(curDoc, targetAt));
          if (alreadyValid) continue;
          const timerId = `${specPrefix}__${crypto.randomBytes(6).toString('hex')}`;
          const expSec = Math.floor(targetAt / 1000) + 12 * 3600;
          const vapid = await signVapidNode(sub.endpoint, expSec);
          const bodyB64 = await encryptWebPushNode(sub.keys, {
            id: `rem-due-${rem.id}-${targetAt}`,
            title: pushTitle,
            body: `${rem.title}${ctxTag ? ` (${ctxTag})` : ''}${amtTag}`,
            tag: `cmd-timer-${rem.id}`,
            tab: targetTab,
            taskId: rem.id,
            reminderId: rem.id,
            url: `./?tab=${targetTab}&taskId=${encodeURIComponent(rem.id)}`,
            requireInteraction: true,
            ts: targetAt
          });
          const r = await httpsJsonRequest(this.relayConfig.url, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
            body: JSON.stringify({
              key: this.relayConfig.key,
              op: 'push_delay',
              timerKey,
              timerId,
              expSec,
              delaySec: remDelaySec,
              endpoint: sub.endpoint,
              vapid,
              bodyB64
            }),
            timeoutMs: 12000
          });
          if (r?.ok) {
            liveDocs[timerKey] = { id: timerId, expSec };
            armedCount++;
          }
        }
      }
    } catch {} finally {
      this._armingCloudPrayers = false;
    }
    return armedCount;
  }

  loadLocalPushRegistry() {
    try {
      if (fs.existsSync(this.pushRegistryPath)) {
        const raw = JSON.parse(fs.readFileSync(this.pushRegistryPath, 'utf8'));
        if (Array.isArray(raw?.items)) {
          return this.dedupePushDevices(raw.items);
        }
      }
    } catch {}
    return [];
  }

  saveLocalPushRegistry() {
    try {
      this.pushDevices = this.dedupePushDevices(this.pushDevices);
      const dir = path.dirname(this.pushRegistryPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(
        this.pushRegistryPath,
        JSON.stringify(
          { updatedAt: new Date().toISOString(), items: this.pushDevices },
          null,
          2
        ),
        'utf8'
      );
    } catch {}
  }

  upsertPushDevice(dev) {
    const entry = this.normalizePushDevice(dev);
    if (!entry) {
      return false;
    }
    this.pushDevices = this.dedupePushDevices([...this.pushDevices, entry]);
    this.saveLocalPushRegistry();
    return true;
  }

  mergeCloudPushRegistry(cloudItems) {
    if (!Array.isArray(cloudItems)) {
      return;
    }
    const validCloud = cloudItems.map((d) => this.normalizePushDevice(d)).filter(Boolean);
    if (validCloud.length === 0 && this.pushDevices.length > 0) {
      return;
    }
    this.pushDevices = this.dedupePushDevices([...this.pushDevices, ...validCloud]);
    this.saveLocalPushRegistry();
  }

  loadPushStateFromDisk() {
    try {
      if (!this.pushStatePath || !fs.existsSync(this.pushStatePath)) {
        return;
      }
      const raw = JSON.parse(fs.readFileSync(this.pushStatePath, 'utf8'));
      if (!raw || typeof raw !== 'object') return;
      if (raw.sessionStatus && typeof raw.sessionStatus === 'object') {
        for (const [k, v] of Object.entries(raw.sessionStatus)) {
          if (k && typeof v === 'string' && !this.prevSessionStatusById.has(k)) {
            this.prevSessionStatusById.set(k, v);
          }
        }
        if (this.prevSessionStatusById.size > 0) {
          this.pushBaselineInitialized = true;
        }
      }
      if (raw.sessionStep && typeof raw.sessionStep === 'object') {
        for (const [k, v] of Object.entries(raw.sessionStep)) {
          if (k && Number(v) > 0) {
            this.prevSessionStepById.set(k, Math.max(Number(this.prevSessionStepById.get(k) || 0), Number(v)));
          }
        }
      }
      if (raw.sessionCompletedStep && typeof raw.sessionCompletedStep === 'object') {
        for (const [k, v] of Object.entries(raw.sessionCompletedStep)) {
          if (k && Number(v) > 0) {
            this.prevCompletedStepById.set(k, Math.max(Number(this.prevCompletedStepById.get(k) || 0), Number(v)));
          }
        }
      } else if (raw.sessionStep && typeof raw.sessionStep === 'object') {
        for (const [k, v] of Object.entries(raw.sessionStep)) {
          const st = this.prevSessionStatusById.get(k) || raw.sessionStatus?.[k] || 'idle';
          if (k && Number(v) > 0 && st !== 'working' && !this.prevCompletedStepById.has(k)) {
            this.prevCompletedStepById.set(k, Number(v));
          }
        }
      }
      if (raw.sessionAt && typeof raw.sessionAt === 'object') {
        for (const [k, v] of Object.entries(raw.sessionAt)) {
          if (k && Number(v) > 0) {
            this.prevSessionAtById.set(k, Math.max(Number(this.prevSessionAtById.get(k) || 0), Number(v)));
          }
        }
      }
      if (raw.lastSessionPushAt && typeof raw.lastSessionPushAt === 'object') {
        for (const [k, v] of Object.entries(raw.lastSessionPushAt)) {
          if (k && Number(v) > 0) {
            this.lastSessionPushAtById.set(k, Math.max(Number(this.lastSessionPushAtById.get(k) || 0), Number(v)));
          }
        }
      }
      if (raw.lastSessionPushText && typeof raw.lastSessionPushText === 'object') {
        for (const [k, v] of Object.entries(raw.lastSessionPushText)) {
          if (!k || typeof v !== 'string' || !v) continue;
          const diskPushAt = Number(raw.lastSessionPushAt?.[k] || 0);
          const memPushAt = Number(this.lastSessionPushAtById.get(k) || 0);
          if (!this.lastSessionPushTextById.has(k) || diskPushAt >= memPushAt) {
            this.lastSessionPushTextById.set(k, v);
          }
        }
      }
      if (Array.isArray(raw.pushedApprovalIds)) {
        for (const id of raw.pushedApprovalIds) {
          if (id) this.pushedApprovalIds.add(String(id));
        }
      }
      if (Array.isArray(raw.pushedAlertIds)) {
        const nowCheck = Date.now();
        for (const id of raw.pushedAlertIds) {
          if (id && !isExpiredQuotaAlertKey(id, nowCheck)) {
            this.pushedAlertIds.add(String(id));
          }
        }
      }
      if (raw.lastNotification && typeof raw.lastNotification === 'object') {
        if (!this.lastNotification || Number(raw.lastNotification.ts || 0) >= Number(this.lastNotification.ts || 0)) {
          this.lastNotification = raw.lastNotification;
        }
      }
      if (Array.isArray(raw.recentNotifications)) {
        const mergedNotifs = [
          ...(Array.isArray(this.recentNotifications) ? this.recentNotifications : []),
          ...raw.recentNotifications
        ].filter((n) => n && typeof n === 'object' && (n.id || n.tag));
        const seenKeys = new Set();
        const deduped = [];
        for (const n of mergedNotifs.sort((a, b) => Number(b.ts || 0) - Number(a.ts || 0))) {
          const k = `${n.id || ''}|${n.tag || ''}`;
          if (!seenKeys.has(k)) {
            seenKeys.add(k);
            deduped.push(n);
          }
        }
        this.recentNotifications = deduped.slice(0, 15);
      } else if (this.lastNotification && (!this.recentNotifications || !this.recentNotifications.length)) {
        this.recentNotifications = [this.lastNotification];
      }
    } catch {}
  }

  savePushStateToDisk() {
    try {
      if (!this.pushStatePath) return;
      // Union pushedApprovalIds/pushedAlertIds and monotonic completion watermarks from disk so keepalive & extension never clobber each other
      if (fs.existsSync(this.pushStatePath)) {
        try {
          const diskRaw = JSON.parse(fs.readFileSync(this.pushStatePath, 'utf8'));
          if (Array.isArray(diskRaw?.pushedApprovalIds)) {
            for (const id of diskRaw.pushedApprovalIds) {
              if (id) this.pushedApprovalIds.add(String(id));
            }
          }
          if (Array.isArray(diskRaw?.pushedAlertIds)) {
            const nowCheck = Date.now();
            for (const id of diskRaw.pushedAlertIds) {
              if (id && !isExpiredQuotaAlertKey(id, nowCheck)) {
                this.pushedAlertIds.add(String(id));
              }
            }
          }
          if (diskRaw?.sessionCompletedStep && typeof diskRaw.sessionCompletedStep === 'object') {
            for (const [k, v] of Object.entries(diskRaw.sessionCompletedStep)) {
              if (k && Number(v) > 0) {
                this.prevCompletedStepById.set(
                  k,
                  Math.max(Number(this.prevCompletedStepById.get(k) || 0), Number(v))
                );
              }
            }
          }
          if (diskRaw?.lastSessionPushAt && typeof diskRaw.lastSessionPushAt === 'object') {
            for (const [k, v] of Object.entries(diskRaw.lastSessionPushAt)) {
              const diskAt = Number(v || 0);
              const memAt = Number(this.lastSessionPushAtById.get(k) || 0);
              if (k && diskAt > memAt) {
                this.lastSessionPushAtById.set(k, diskAt);
                if (typeof diskRaw.lastSessionPushText?.[k] === 'string' && diskRaw.lastSessionPushText[k]) {
                  this.lastSessionPushTextById.set(k, diskRaw.lastSessionPushText[k]);
                }
              }
            }
          }
          if (diskRaw?.lastSessionPushText && typeof diskRaw.lastSessionPushText === 'object') {
            for (const [k, v] of Object.entries(diskRaw.lastSessionPushText)) {
              if (k && typeof v === 'string' && v && !this.lastSessionPushTextById.has(k)) {
                this.lastSessionPushTextById.set(k, v);
              }
            }
          }
        } catch {}
      }
      const dir = path.dirname(this.pushStatePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      // Keep the 600 most recently updated sessions (sorted by sessionAt descending)
      const allSessionIds = new Set([
        ...this.prevSessionStatusById.keys(),
        ...this.prevSessionStepById.keys(),
        ...this.prevCompletedStepById.keys(),
        ...this.prevSessionAtById.keys()
      ]);
      const sortedIds = Array.from(allSessionIds)
        .sort((a, b) => Number(this.prevSessionAtById.get(b) || 0) - Number(this.prevSessionAtById.get(a) || 0))
        .slice(0, 600);

      const sessionStatus = {};
      const sessionStep = {};
      const sessionCompletedStep = {};
      const sessionAt = {};
      const lastSessionPushAt = {};
      const lastSessionPushText = {};
      for (const k of sortedIds) {
        if (this.prevSessionStatusById.has(k)) sessionStatus[k] = this.prevSessionStatusById.get(k);
        if (this.prevSessionStepById.has(k)) sessionStep[k] = this.prevSessionStepById.get(k);
        if (this.prevCompletedStepById.has(k)) sessionCompletedStep[k] = this.prevCompletedStepById.get(k);
        if (this.prevSessionAtById.has(k)) sessionAt[k] = this.prevSessionAtById.get(k);
        if (this.lastSessionPushAtById.has(k)) lastSessionPushAt[k] = this.lastSessionPushAtById.get(k);
        if (this.lastSessionPushTextById.has(k)) lastSessionPushText[k] = this.lastSessionPushTextById.get(k);
      }
      const payload = {
        updatedAt: Date.now(),
        sessionStatus,
        sessionStep,
        sessionCompletedStep,
        sessionAt,
        lastSessionPushAt,
        lastSessionPushText,
        pushedApprovalIds: Array.from(this.pushedApprovalIds).slice(-500),
        pushedAlertIds: Array.from(this.pushedAlertIds).slice(-500),
        lastNotification: this.lastNotification || null,
        recentNotifications: (this.recentNotifications || []).slice(0, 15)
      };
      fs.writeFileSync(this.pushStatePath, JSON.stringify(payload), 'utf8');
    } catch {}
  }

  async sendPushToDevice(device, payloadObj) {
    const norm = this.normalizePushDevice(device);
    if (!norm) {
      return { ok: false, error: 'Invalid device subscription' };
    }
    const threadId = String(payloadObj.threadId || '').trim();
    const provider = String(payloadObj.provider || '').trim();
    const reminderId = String(payloadObj.reminderId || '').trim();
    const tab = String(payloadObj.tab || (threadId ? 'chat' : reminderId ? 'discipline' : 'pulse')).trim();
    let autoUrl = payloadObj.url && payloadObj.url !== './' ? String(payloadObj.url) : '';
    if (!autoUrl) {
      if (threadId) {
        autoUrl = `./?tab=chat&thread=${encodeURIComponent(threadId)}${provider ? `&provider=${encodeURIComponent(provider)}` : ''}`;
      } else if (reminderId) {
        autoUrl = `./?tab=discipline&rem=${encodeURIComponent(reminderId)}`;
      } else if (tab) {
        autoUrl = `./?tab=${encodeURIComponent(tab)}`;
      } else {
        autoUrl = './';
      }
    }
    const tag = payloadObj.tag || `theo-${Date.now()}`;
    const fullPayload = {
      id: payloadObj.id || tag,
      title: payloadObj.title || 'THEO Remote',
      body: payloadObj.body || '',
      tag,
      tab,
      threadId,
      provider,
      reminderId,
      sessionTitle: payloadObj.sessionTitle || '',
      url: autoUrl,
      requireInteraction: Boolean(payloadObj.requireInteraction),
      ts: Date.now()
    };
    const vapidAuth = await signVapidNode(norm.endpoint);
    const bodyB64 = await encryptWebPushNode(norm.keys, fullPayload);
    try {
      const res = await httpsBinaryPushRequest(norm.endpoint, vapidAuth, bodyB64, 14400);
      if (res && (res.status === 410 || res.status === 404)) {
        this.pushDevices = this.pushDevices.filter((d) => d.endpoint !== norm.endpoint);
        this.saveLocalPushRegistry();
      }
      return res;
    } catch (directErr) {
      if (this.relayConfig.url && this.relayConfig.key) {
        try {
          const relayRes = await httpsJsonRequest(this.relayConfig.url, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
            body: JSON.stringify({
              key: this.relayConfig.key,
              op: 'push',
              endpoint: norm.endpoint,
              vapid: vapidAuth,
              auth: vapidAuth,
              bodyB64,
              ttl: '14400'
            }),
            timeoutMs: 12000
          });
          return { ok: Boolean(relayRes?.ok), status: relayRes?.pushStatus || 201, via: 'relay' };
        } catch {}
      }
      return { ok: false, error: String(directErr?.message || directErr) };
    }
  }

  async broadcastPush(filterFn, payloadObj) {
    if (!this.pushDevices.length) {
      this.pushDevices = this.loadLocalPushRegistry();
    }
    if (!this.pushDevices.length) {
      return [];
    }
    const targets = this.pushDevices.filter((d) => {
      try {
        if (d.prefs && d.prefs.enabled === false) return false;
        return filterFn ? filterFn(d) : true;
      } catch {
        return true;
      }
    });
    if (!targets.length) {
      return [];
    }
    return Promise.all(
      targets.map((d) => this.sendPushToDevice(d, payloadObj).catch(() => ({ ok: false })))
    );
  }

  async evaluateRealtimePushAlerts(stateSnapshot, opts = {}) {
    if (!stateSnapshot || this.pushEvalInFlight || (this.server && !this.listening)) {
      return;
    }
    this.pushEvalInFlight = true;
    try {
      this.loadPushStateFromDisk();
      if (!this.pushDevices.length) {
        this.pushDevices = this.loadLocalPushRegistry();
      }
      const approvals = Array.isArray(stateSnapshot.approvals) ? stateSnapshot.approvals : [];
      const rows = Array.isArray(stateSnapshot.rows) ? stateSnapshot.rows : [];
      const nowMs = Date.now();

      const wasBaselineInit = !this.pushBaselineInitialized;
      if (wasBaselineInit) {
        this.pushBaselineInitialized = true;
        for (const r of rows) {
          if (r && r.id) {
            this.prevSessionStatusById.set(r.id, r.status || 'idle');
            if (Number(r.stepCount || 0) > 0) {
              this.prevSessionStepById.set(r.id, Number(r.stepCount));
              if (r.status !== 'working' && r.status !== 'waiting') {
                this.prevCompletedStepById.set(r.id, Number(r.stepCount));
              }
            }
            if (Number(r.at || 0) > 0) {
              this.prevSessionAtById.set(r.id, Number(r.at));
            }
            if (r.reason && String(r.reason).includes('Stalled task')) {
              this.pushedAlertIds.add(`stalled-${r.id}`);
            }
          }
        }
        for (const a of approvals) {
          if (a && a.id) {
            this.pushedApprovalIds.add(a.id);
          }
        }
        this.savePushStateToDisk();
      }

      const newlyApprovedSessions = new Set();
      let triggeredUrgentSync = false;
      const recordNotif = (notifObj) => {
        const tId = String(notifObj.threadId || '').trim();
        const prov = String(notifObj.provider || '').trim();
        const rId = String(notifObj.reminderId || '').trim();
        const tb = String(notifObj.tab || (tId ? 'chat' : rId ? 'discipline' : 'pulse')).trim();
        const url = tId
          ? `./?tab=chat&thread=${encodeURIComponent(tId)}${prov ? `&provider=${encodeURIComponent(prov)}` : ''}`
          : rId
            ? `./?tab=discipline&rem=${encodeURIComponent(rId)}`
            : `./?tab=${encodeURIComponent(tb)}`;
        if (tId) {
          if (!this.requestedThreads) {
            this.requestedThreads = new Map();
          }
          this.requestedThreads.set(tId, { provider: prov || 'antigravity', requestedAt: Date.now() });
          if (this.threadDetailCache) {
            this.threadDetailCache.delete(`${tId}:antigravity`);
            this.threadDetailCache.delete(`${tId}:claude`);
          }
        }
        const entry = {
          id: notifObj.id || notifObj.tag || `theo-${Date.now()}`,
          tag: notifObj.tag || `theo-${Date.now()}`,
          title: notifObj.title || 'THEO Remote',
          body: notifObj.body || '',
          tab: tb,
          threadId: tId,
          provider: prov,
          reminderId: rId,
          sessionTitle: notifObj.sessionTitle || '',
          url,
          ts: Date.now()
        };
        this.lastNotification = entry;
        if (!Array.isArray(this.recentNotifications)) {
          this.recentNotifications = [];
        }
        this.recentNotifications = [
          entry,
          ...this.recentNotifications.filter((n) => n && n.id !== entry.id && n.tag !== entry.tag)
        ].slice(0, 15);
        stateSnapshot.lastNotification = this.lastNotification;
        stateSnapshot.recentNotifications = this.recentNotifications;
        this.savePushStateToDisk();
        if (!opts.fromCloudSync && !triggeredUrgentSync) {
          triggeredUrgentSync = true;
          this.triggerUrgentCloudSync();
        }
        return this.lastNotification;
      };

      // 1. Pending approvals / questions / newly waiting sessions
      for (const item of wasBaselineInit ? [] : approvals) {
        if (!item || !item.id || this.pushedApprovalIds.has(item.id)) {
          continue;
        }
        const isQuestion =
          item.kind === 'question' || /question/i.test(String(item.toolName || ''));
        if (item.kind === 'waiting_session' && !isQuestion) {
          const prevSt = this.prevSessionStatusById.get(item.sessionId);
          const prevStep = Number(this.prevSessionStepById.get(item.sessionId) || 0);
          const curRow = rows.find((r) => r && r.id === item.sessionId);
          const curStep = Number(curRow?.stepCount || 0);
          const recentUpdate = nowMs - Number(item.createdAt || curRow?.at || 0) < 90000;
          const lastSessPushAt = Number(this.lastSessionPushAtById.get(item.sessionId) || 0);
          if (
            (prevSt !== 'working' && !(prevStep > 0 && curStep > prevStep && recentUpdate)) ||
            (lastSessPushAt > 0 && nowMs - lastSessPushAt < 45000)
          ) {
            this.pushedApprovalIds.add(item.id);
            continue;
          }
        }
        this.pushedApprovalIds.add(item.id);
        if (item.sessionId) {
          newlyApprovedSessions.add(item.sessionId);
          this.lastSessionPushAtById.set(item.sessionId, nowMs);
        }
        const pushTitle = isQuestion
          ? `❓ Question from THEO — ${item.title || 'Session'}`
          : `⚡ Approval Needed — ${item.title || 'THEO'}`;
        const pushBody = isQuestion
          ? `${item.detail || 'THEO is waiting for your answer.'}`
          : `${item.toolName ? `${item.toolName}: ` : ''}${item.detail || 'Session waiting for confirmation'}`;
        const rec = recordNotif({
          id: `app-${item.id}`,
          title: pushTitle,
          body: pushBody,
          tag: `theo-app-${item.sessionId || item.id}`,
          tab: item.sessionId ? 'chat' : 'pulse',
          threadId: item.sessionId || '',
          provider: item.provider || 'antigravity',
          sessionTitle: item.title || 'Session'
        });
        await this.broadcastPush((d) => this.isTheoDevice(d) && d.prefs?.approvals !== false, {
          ...rec,
          requireInteraction: true
        });
      }

      // 2. Session transitions to completed/idle/done (or fast turn completions between polls) + stalled sessions
      for (const r of wasBaselineInit ? [] : rows) {
        if (!r || !r.id) continue;
        const prev = this.prevSessionStatusById.get(r.id);
        const prevStep = Number(this.prevSessionStepById.get(r.id) || 0);
        const curStep = Number(r.stepCount || 0);
        const prevAt = Number(this.prevSessionAtById.get(r.id) || 0);
        const curAt = Number(r.at || 0);
        const isDoneState =
          r.status === 'completed' || r.status === 'idle' || r.status === 'done';
        const lastText = String(r.lastAssistantText || '').trim();
        const isTurnTrulyComplete =
          isDoneState && r.turnComplete !== false && Boolean(lastText);
        let prevCompletedStep = Number(this.prevCompletedStepById.get(r.id) || 0);
        if (!prevCompletedStep && prev && prev !== 'working' && prevStep > 0 && (nowMs - curAt >= 180000 || curStep <= prevStep)) {
          prevCompletedStep = prevStep;
          this.prevCompletedStepById.set(r.id, prevStep);
        }
        const transitionedFromWorking = prev === 'working' && isTurnTrulyComplete;
        const completedNewStep =
          isTurnTrulyComplete &&
          prevCompletedStep > 0 &&
          curStep > prevCompletedStep &&
          nowMs - curAt >= 0 &&
          nowMs - curAt < 180000;
        const fastTurnCompleted =
          isTurnTrulyComplete &&
          prev !== 'working' &&
          ((prevStep > 0 && curStep > prevStep && curAt >= prevAt) ||
            (!prev && curStep > 0 && r.status === 'completed')) &&
          nowMs - curAt >= 0 &&
          nowMs - curAt < 180000;

        const doneKey = `done-${r.id}-${curStep || curAt}`;
        if (
          (transitionedFromWorking || completedNewStep || fastTurnCompleted) &&
          !newlyApprovedSessions.has(r.id) &&
          !this.pushedAlertIds.has(doneKey)
        ) {
          this.pushedAlertIds.add(doneKey);
          const lastSessPushAt = Number(this.lastSessionPushAtById.get(r.id) || 0);
          const prevPushedText = String(this.lastSessionPushTextById.get(r.id) || '').trim();
          const isCooldownOrDuplicateText =
            (lastSessPushAt > 0 && nowMs - lastSessPushAt < 25000) ||
            (lastText && prevPushedText && lastText === prevPushedText);
          if (!isCooldownOrDuplicateText) {
            this.lastSessionPushAtById.set(r.id, nowMs);
            if (lastText) {
              this.lastSessionPushTextById.set(r.id, lastText);
            }
            const endsWithQuestion = /\?\s*["')*\]]*\s*$/.test(lastText);
            const pushTitle = endsWithQuestion
              ? `❓ Question from THEO — ${r.title || 'Session'}`
              : `✓ Task Complete — ${r.title || 'Session'}`;
            const pushBody = lastText
              ? lastText.slice(0, 180)
              : `${r.folder ? `${r.folder} · ` : ''}${r.provider === 'claude' ? 'Claude Code' : 'Antigravity'} finished its turn and is ready.`;
            const rec = recordNotif({
              id: doneKey,
              title: pushTitle,
              body: pushBody,
              tag: `theo-done-${r.id}`,
              tab: 'chat',
              threadId: r.id,
              provider: r.provider || 'antigravity',
              sessionTitle: r.title || 'Session'
            });
            await this.broadcastPush(
              (d) =>
                this.isTheoDevice(d) &&
                (endsWithQuestion
                  ? d.prefs?.approvals !== false || d.prefs?.completed !== false
                  : d.prefs?.completed !== false),
              {
                ...rec,
                requireInteraction: endsWithQuestion
              }
            );
          }
        }

        if (
          r.reason &&
          String(r.reason).includes('Stalled task') &&
          !this.pushedAlertIds.has(`stalled-${r.id}`)
        ) {
          this.pushedAlertIds.add(`stalled-${r.id}`);
          const rec = recordNotif({
            id: `stalled-${r.id}`,
            title: `⚠️ Stalled Session — ${r.title || 'Session'}`,
            body: `${r.folder ? `${r.folder} · ` : ''}No progress detected recently. Tap to inspect.`,
            tag: `theo-stalled-${r.id}`,
            tab: 'chat',
            threadId: r.id,
            provider: r.provider || 'antigravity',
            sessionTitle: r.title || 'Session'
          });
          await this.broadcastPush((d) => this.isTheoDevice(d) && d.prefs?.quota !== false, rec);
        }

        this.prevSessionStatusById.set(r.id, r.status || 'idle');
        if (curStep > 0) {
          this.prevSessionStepById.set(r.id, curStep);
          if (isTurnTrulyComplete) {
            this.prevCompletedStepById.set(r.id, Math.max(prevCompletedStep, curStep));
          }
        }
        if (curAt > 0) {
          this.prevSessionAtById.set(r.id, curAt);
        }
      }

      // 3. High Antigravity & Claude Code usage rate / quota alert (>= 90%)
      const { highAlerts } = collectHighUsageQuotaAlerts(stateSnapshot, nowMs);
      for (const alert of highAlerts) {
        if (!hasQuotaAlertForWindow(this.pushedAlertIds, alert.bucketKey, alert.windowStamp, nowMs)) {
          this.pushedAlertIds.add(alert.id);
          const rec = recordNotif({
            id: alert.id,
            title: alert.title,
            body: alert.body,
            tag: alert.tag,
            tab: 'pulse',
            provider: alert.provider,
            url: './?tab=pulse'
          });
          await this.broadcastPush((d) => this.isTheoDevice(d) && d.prefs?.quota !== false, {
            ...rec,
            requireInteraction: true
          });
        }
      }

      if (wasBaselineInit) {
        return;
      }

      // Strict Planner-only subscription filter (NEVER fall back to THEO AI workbench endpoints)
      const isCommandSub = (d) => this.isPlannerDevice(d);

      // 4A. Personal Tasks, Reminders, Smart Wait Timers & Delegation Follow-Ups -> route exclusively to Planner PWA
      // Verify live bhf_theo_remote_control_store timer state: wait up to 75s if an active Wait_Timer is armed, skip if fired_, and take over atomically if missing or overdue!
      const cmdDevicesForTasks = this.pushDevices.filter(
        (d) => isCommandSub(d) && d.prefs?.enabled !== false && d.prefs?.tasks !== false
      );
      const rems = Array.isArray(this.personalLedger?.reminders) ? this.personalLedger.reminders : [];
      for (const rem of rems) {
        if (!rem || !rem.id || rem.status === 'done' || rem.completed || rem.deleted) continue;
        const target = Number(rem.targetAt || rem.matureAt || rem.dueAt || 0);
        if (!target || nowMs < target) continue;
        const remKey = `rem-due-${rem.id}-${target}`;
        if (this.pushedAlertIds.has(remKey)) continue;
        if (nowMs - target >= 6 * 3600 * 1000 || !cmdDevicesForTasks.length) {
          this.pushedAlertIds.add(remKey);
          continue;
        }

        let refreshedForTask = false;
        let hasWaitingTaskDevice = false;
        const readyTaskDevices = [];
        const taskFiredStampPatch = {};

        for (const d of cmdDevicesForTasks) {
          let st = this.getCloudTaskTimerState(d, rem.id, target, nowMs);
          if ((st.state === 'takeover' || st.state === 'missing') && !refreshedForTask) {
            refreshedForTask = true;
            await this.refreshCloudControlDocsIfStale(8000);
            st = this.getCloudTaskTimerState(d, rem.id, target, nowMs);
          }
          if (st.state === 'armed_waiting') {
            hasWaitingTaskDevice = true;
          } else if (st.state === 'missing' || st.state === 'takeover') {
            readyTaskDevices.push(d);
            if (st.timerKey) {
              const baseId = st.cloudId && !st.cloudId.startsWith('fired_') && st.cloudId !== 'cancelled'
                ? st.cloudId
                : `${rem.id}_${target}_bridge`;
              taskFiredStampPatch[st.timerKey] = {
                id: `fired_${baseId}`,
                firedAt: new Date().toISOString()
              };
            }
          }
        }

        if (readyTaskDevices.length > 0) {
          await this.stampCloudTimersFiredByBridge(taskFiredStampPatch);
          if (!hasWaitingTaskDevice) {
            this.pushedAlertIds.add(remKey);
          }
          const isDel = Boolean(rem.isDelegated || rem.assigneeName || rem.category === 'people');
          const cat = String(rem.category || 'work');
          let pushTitle = '⏰ Task Due — Planner';
          if (cat === 'verify') pushTitle = '🔍 Verify on App — Planner';
          else if (cat === 'shipping') pushTitle = '📦 Shipping Timer Ready — Planner';
          else if (cat === 'payments') pushTitle = '💸 Payment Hold Matured — Planner';
          else if (isDel) pushTitle = `👤 Follow-Up Due: ${rem.assigneeName || 'Team'} — Planner`;
          else if (rem.kind === 'wait' || Number(rem.matureAt || 0) > 0) pushTitle = '⏳ Wait Timer Ready — Planner';
          else if (rem.recur && rem.recur !== 'none') pushTitle = `🔁 ${rem.recur === 'weekly' ? 'Weekly' : 'Daily'} Task Due — Planner`;

          const targetTab = isDel ? 'delegated' : 'tasks';
          const ctxTag = rem.subTag || rem.subGroup || (rem.assigneeName ? `👤 ${rem.assigneeName}` : '');
          const amtTag = Number(rem.amount || 0) > 0 ? ` · $${Number(rem.amount).toLocaleString('en-US')}` : '';
          const payloadObj = {
            id: remKey,
            title: pushTitle,
            body: `${rem.title}${ctxTag ? ` (${ctxTag})` : ''}${amtTag}`,
            tag: `cmd-timer-${rem.id}`,
            tab: targetTab,
            taskId: rem.id,
            reminderId: rem.id,
            url: `./?tab=${targetTab}&taskId=${encodeURIComponent(rem.id)}`,
            requireInteraction: true
          };
          await Promise.all(
            readyTaskDevices.map((d) => this.sendPushToDevice(d, payloadObj).catch(() => ({ ok: false })))
          );
        } else if (!hasWaitingTaskDevice) {
          this.pushedAlertIds.add(remKey);
        }
      }

      // 4B. Live BHFIRMS Staff Delegation Status Updates (Seen / Working / Completed + Staff Note) -> route exclusively to Planner PWA
      if (Array.isArray(this.pendingDelegationAlerts) && this.pendingDelegationAlerts.length > 0) {
        const queued = this.pendingDelegationAlerts.splice(0, this.pendingDelegationAlerts.length);
        for (const upd of queued) {
          if (!upd || !upd.key || this.pushedAlertIds.has(upd.key)) continue;
          this.pushedAlertIds.add(upd.key);
          const stMap = {
            seen: `👀 ${upd.assigneeName} saw task — Planner`,
            working: `⚙️ ${upd.assigneeName} is working on task — Planner`,
            done: `✅ ${upd.assigneeName} completed task — Planner`
          };
          const title = stMap[upd.status] || `👤 ${upd.assigneeName} updated task — Planner`;
          const noteSuffix = upd.staffNote ? ` · 💬 "${upd.staffNote}"` : '';
          await this.broadcastPush(
            (d) => isCommandSub(d) && d.prefs?.delegations !== false,
            {
              id: upd.key,
              title,
              body: `${upd.title}${noteSuffix}`,
              tag: `cmd-del-${upd.taskId}-${upd.status}`,
              tab: 'delegated',
              taskId: upd.taskId,
              url: `./?tab=delegated&taskId=${encodeURIComponent(upd.taskId)}`,
              requireInteraction: upd.status === 'done'
            }
          );
        }
      }

      // 5. Daily Shia Prayer Time Alerts (Fajr, Dohor, Maghrib based on location & day-of-year) -> route exclusively to Planner PWA
      // Live control-store handshake: wait up to 75s when an un-fired cloud Wait_Timer is armed, skip when fired_, and atomically stamp fired_ + push immediately when missing or overdue!
      const pCfg = this.personalLedger?.prayerConfig || {};
      const cmdDevicesForPrayers = this.pushDevices.filter(
        (d) => isCommandSub(d) && d.prefs?.enabled !== false && d.prefs?.prayers !== false
      );
      if (pCfg.enabled !== false && cmdDevicesForPrayers.length > 0) {
        const prayerSched = this.computeShiaPrayersForToday(pCfg);
        if (prayerSched && Array.isArray(prayerSched.prayers)) {
          const preMin = Number(pCfg.preRemindMin || 0);
          for (const p of prayerSched.prayers) {
            if (!p.enabled) continue;
            if (preMin > 0) {
              const preMs = p.epochMs - preMin * 60000;
              const preKey = `prayer-pre-${prayerSched.isoDate}-${p.id}-${preMin}`;
              if (nowMs >= preMs && nowMs < p.epochMs && nowMs - preMs < 10 * 60000 && !this.pushedAlertIds.has(preKey)) {
                let refreshedPre = false;
                let waitingPre = false;
                const readyPreDevs = [];
                const preStampPatch = {};
                for (const d of cmdDevicesForPrayers) {
                  let st = this.getCloudPrayerTimerState(d, prayerSched.isoDate, p.id, true, preMs, nowMs);
                  if ((st.state === 'takeover' || st.state === 'missing') && !refreshedPre) {
                    refreshedPre = true;
                    await this.refreshCloudControlDocsIfStale(8000);
                    st = this.getCloudPrayerTimerState(d, prayerSched.isoDate, p.id, true, preMs, nowMs);
                  }
                  if (st.state === 'armed_waiting') {
                    waitingPre = true;
                  } else if (st.state === 'missing' || st.state === 'takeover') {
                    readyPreDevs.push(d);
                    if (st.timerKey) {
                      const baseId = st.cloudId && !st.cloudId.startsWith('fired_') && st.cloudId !== 'cancelled'
                        ? st.cloudId
                        : `${prayerSched.isoDate}_pre_${p.id}_${preMs}__bridge`;
                      preStampPatch[st.timerKey] = {
                        id: `fired_${baseId}`,
                        firedAt: new Date().toISOString()
                      };
                    }
                  }
                }
                if (readyPreDevs.length > 0) {
                  await this.stampCloudTimersFiredByBridge(preStampPatch);
                  if (!waitingPre) {
                    this.pushedAlertIds.add(preKey);
                  }
                  const prePayload = {
                    id: preKey,
                    title: `${p.icon} ${p.label} in ${preMin} min · ${p.time24}`,
                    body: `${p.arabic} at ${p.time24} in ${prayerSched.locationName}. ${p.windowNote}`,
                    tag: `prayer-${prayerSched.isoDate}-${p.id}-pre`,
                    tab: 'prayers',
                    openPrayer: true,
                    url: './?tab=prayers',
                    requireInteraction: false
                  };
                  await Promise.all(
                    readyPreDevs.map((d) => this.sendPushToDevice(d, prePayload).catch(() => ({ ok: false })))
                  );
                } else if (!waitingPre) {
                  this.pushedAlertIds.add(preKey);
                }
              }
            }
            const mainKey = `prayer-main-${prayerSched.isoDate}-${p.id}-${p.time24}`;
            if (nowMs >= p.epochMs && nowMs - p.epochMs < 45 * 60000 && !this.pushedAlertIds.has(mainKey)) {
              let refreshedMain = false;
              let waitingMain = false;
              const readyMainDevs = [];
              const mainStampPatch = {};
              for (const d of cmdDevicesForPrayers) {
                let st = this.getCloudPrayerTimerState(d, prayerSched.isoDate, p.id, false, p.epochMs, nowMs);
                if ((st.state === 'takeover' || st.state === 'missing') && !refreshedMain) {
                  refreshedMain = true;
                  await this.refreshCloudControlDocsIfStale(8000);
                  st = this.getCloudPrayerTimerState(d, prayerSched.isoDate, p.id, false, p.epochMs, nowMs);
                }
                if (st.state === 'armed_waiting') {
                  waitingMain = true;
                } else if (st.state === 'missing' || st.state === 'takeover') {
                  readyMainDevs.push(d);
                  if (st.timerKey) {
                    const baseId = st.cloudId && !st.cloudId.startsWith('fired_') && st.cloudId !== 'cancelled'
                      ? st.cloudId
                      : `${prayerSched.isoDate}_${p.id}_${p.epochMs}__bridge`;
                    mainStampPatch[st.timerKey] = {
                      id: `fired_${baseId}`,
                      firedAt: new Date().toISOString()
                    };
                  }
                }
              }
              if (readyMainDevs.length > 0) {
                await this.stampCloudTimersFiredByBridge(mainStampPatch);
                if (!waitingMain) {
                  this.pushedAlertIds.add(mainKey);
                }
                const mainPayload = {
                  id: mainKey,
                  title: `🕌 ${p.label} Prayer Time · ${p.time24} (${p.arabic})`,
                  body: `${p.label} has entered in ${prayerSched.locationName}. ${p.windowNote}. Hayya 'ala Khayr al-'Amal.`,
                  tag: `prayer-${prayerSched.isoDate}-${p.id}`,
                  tab: 'prayers',
                  openPrayer: true,
                  url: './?tab=prayers',
                  requireInteraction: true
                };
                await Promise.all(
                  readyMainDevs.map((d) => this.sendPushToDevice(d, mainPayload).catch(() => ({ ok: false })))
                );
              } else if (!waitingMain) {
                this.pushedAlertIds.add(mainKey);
              }
            }
          }
        }
      }

      // 6. Daily 100% Score & Executive Briefings (08:00 Morning Radar & 21:00 Evening Scorecard) -> route exclusively to Planner PWA
      const nowLocal = new Date(nowMs);
      const localIso = `${nowLocal.getFullYear()}-${String(nowLocal.getMonth() + 1).padStart(2, '0')}-${String(nowLocal.getDate()).padStart(2, '0')}`;
      const localHr = nowLocal.getHours();
      const localMin = nowLocal.getMinutes();
      const curUtcSlotKey = new Date(nowMs).toISOString().slice(0, 13);
      if (localHr === 8 && localMin < 20) {
        const mKey = `planner-morning-${localIso}`;
        if (!this.pushedAlertIds.has(mKey)) {
          this.pushedAlertIds.add(mKey);
          const openTasks = rems.filter((r) => r && !r.completed && !r.deleted && r.category !== 'ideas' && r.category !== 'want_to_do');
          const delCount = openTasks.filter((r) => r.isDelegated || r.assigneeName).length;
          const pSched = this.computeShiaPrayersForToday(pCfg);
          const pSummary = pSched
            ? ` · ☀️ Dohor ${pSched.prayers?.[1]?.time24 || ''} · 🌙 Maghrib ${pSched.prayers?.[2]?.time24 || ''}`
            : '';
          await this.broadcastPush(
            (d) =>
              isCommandSub(d) &&
              d.prefs?.score !== false &&
              !(d.slots && d.slots[curUtcSlotKey]),
            {
              id: mKey,
              title: '☀️ Morning Executive & Prayer Brief — Planner',
              body: `${openTasks.length} active tasks (${delCount} delegated)${pSummary}. Start at 50% baseline.`,
              tag: `cmd-morning-${localIso}`,
              tab: 'planning',
              url: './?tab=planning',
              requireInteraction: false
            }
          );
        }
      } else if (localHr === 21 && localMin < 20) {
        const eKey = `planner-evening-${localIso}`;
        if (!this.pushedAlertIds.has(eKey)) {
          this.pushedAlertIds.add(eKey);
          await this.broadcastPush(
            (d) =>
              isCommandSub(d) &&
              d.prefs?.score !== false &&
              !(d.slots && d.slots[curUtcSlotKey]),
            {
              id: eKey,
              title: '🛡️ Evening 100% Score Check-In — Planner',
              body: "Log today's 5 Do's (+50%) & 5 Don'ts (50% baseline) and review tomorrow's timers.",
              tag: `cmd-evening-${localIso}`,
              tab: 'score',
              url: './?tab=score',
              requireInteraction: false
            }
          );
        }
      }

      // 6B. THEO AI Workbench Daily Briefings (Morning Brief & Evening Git Digest) -> route exclusively to THEO AI Workbench PWA
      // Skip devices where Personal - THEO Remote Daily Push already has a slot populated for this UTC hour!
      const theoDevices = this.pushDevices.filter((d) => this.isTheoDevice(d) && d.prefs?.enabled !== false);
      // Unsaved work idle 24 h+ on THIS PC (each host reports its own folders; theo-worktree-guard.py
      // --report-json, refreshed hourly by unsaved-work.js). Owner idea 2026-11-13.
      const unsavedLine = formatUnsavedDigestLine(readUnsavedWorkSummary());
      const hostName = this.deviceInfo?.name || os.hostname();
      for (const td of theoDevices) {
        const amHr = Number(td.prefs?.morningHour ?? td.prefs?.morningBriefingHour ?? 8);
        const pmHr = Number(td.prefs?.eveningHour ?? td.prefs?.eveningDigestHour ?? 21);
        if (td.slots && td.slots[curUtcSlotKey]) {
          // The phone pre-built this hour's digest (sent by the store), so it cannot carry this PC's
          // unsaved-work line: send that line as its own short push, once per PC per evening.
          if (unsavedLine && td.prefs?.evening !== false && localHr === pmHr && localMin < 20) {
            const unsavedKey = `theo-unsaved-${localIso}-${td.id || 'dev'}`;
            if (!this.pushedAlertIds.has(unsavedKey)) {
              this.pushedAlertIds.add(unsavedKey);
              await this.sendPushToDevice(td, {
                id: unsavedKey,
                title: `Unsaved work on ${hostName}`,
                body: `${unsavedLine}. Push or clear it on purpose.`,
                tag: `theo-unsaved-${localIso}-${this.deviceInfo?.id || 'host'}`,
                tab: 'workspaces',
                url: './?tab=workspaces',
                requireInteraction: false
              }).catch(() => {});
            }
          }
          continue;
        }
        if (td.prefs?.morning !== false && localHr === amHr && localMin < 20) {
          const theoAmKey = `theo-am-${localIso}-${td.id || 'dev'}`;
          if (!this.pushedAlertIds.has(theoAmKey)) {
            this.pushedAlertIds.add(theoAmKey);
            const activeRows = rows.filter((r) => r && r.id && !r.archived);
            const openTabs = activeRows.filter((r) => r.open);
            const waitTxt =
              approvals.length > 0
                ? `${approvals.length} approval${approvals.length === 1 ? '' : 's'} waiting · `
                : '';
            await this.sendPushToDevice(td, {
              id: theoAmKey,
              title: 'THEO AI Workbench Morning Brief ⚡',
              body: `${waitTxt}${activeRows.length} active AI sessions (${openTabs.length} open in VS Code across Antigravity & Claude Code).`,
              tag: `theo-am-${localIso}`,
              tab: 'pulse',
              url: './?tab=pulse',
              requireInteraction: approvals.length > 0
            }).catch(() => {});
          }
        }
        if (td.prefs?.evening !== false && localHr === pmHr && localMin < 20) {
          const theoPmKey = `theo-pm-${localIso}-${td.id || 'dev'}`;
          if (!this.pushedAlertIds.has(theoPmKey)) {
            this.pushedAlertIds.add(theoPmKey);
            const activeRows = rows.filter((r) => r && r.id && !r.archived);
            const openTabs = activeRows.filter((r) => r.open);
            const workspaces = Array.isArray(stateSnapshot.workspaces) ? stateSnapshot.workspaces : [];
            const dirtyRepos = workspaces.filter((w) => Number(w?.dirtyCount || 0) > 0);
            const dirtyTxt =
              dirtyRepos.length > 0
                ? `${dirtyRepos.length} repo${dirtyRepos.length === 1 ? '' : 's'} with uncommitted changes`
                : 'All BHFIRMS git repos clean';
            const todayTok = Number(stateSnapshot.summary?.today?.tokens || 0);
            const tokTxt =
              todayTok > 0
                ? ` · ${todayTok >= 1000000 ? `${(todayTok / 1000000).toFixed(1)}M` : `${Math.round(todayTok / 1000)}k`} tokens today`
                : '';
            await this.sendPushToDevice(td, {
              id: theoPmKey,
              title: 'THEO Evening AI & Git Digest ⎇',
              body: `${dirtyTxt}${tokTxt}. ${activeRows.length} active sessions (${openTabs.length} open).${
                unsavedLine ? ` On ${hostName}: ${unsavedLine}.` : ''
              }`,
              tag: `theo-pm-${localIso}`,
              tab: 'workspaces',
              url: './?tab=workspaces',
              requireInteraction: false
            }).catch(() => {});
          }
        }
      }

      this.savePushStateToDisk();
    } catch {} finally {
      this.pushEvalInFlight = false;
    }
  }

  computeShiaPrayersForToday(rawCfg = {}, customIsoDate = '') {
    try {
      const lat = Number.isFinite(Number(rawCfg.lat)) ? Number(rawCfg.lat) : 33.8938;
      const rawLng = rawCfg.lng ?? rawCfg.lon;
      const lng = Number.isFinite(Number(rawLng)) ? Number(rawLng) : 35.5018;
      const timeZone = String(rawCfg.timeZone || 'Asia/Beirut').trim() || 'Asia/Beirut';
      const locationName = String(rawCfg.locationName || 'Beirut, Lebanon').trim() || 'Beirut, Lebanon';
      const methodMap = {
        jafari_leva: { fajrAngle: 16, maghribAngle: 4, dhuhrMin: 1 },
        jafari_lebanon: { fajrAngle: 18, maghribAngle: 4, dhuhrMin: 1 },
        jafari_tehran: { fajrAngle: 17.7, maghribAngle: 4.5, dhuhrMin: 1 }
      };
      const m = methodMap[rawCfg.method] || methodMap.jafari_leva;

      let year;
      let month;
      let day;
      const customMatch = String(customIsoDate || '').trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
      if (customMatch) {
        year = Number(customMatch[1]);
        month = Number(customMatch[2]);
        day = Number(customMatch[3]);
      } else {
        const now = new Date();
        const parts = new Intl.DateTimeFormat('en-US', {
          timeZone,
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false
        }).formatToParts(now);
        const pm = {};
        for (const p of parts) pm[p.type] = p.value;
        year = Number(pm.year);
        month = Number(pm.month);
        day = Number(pm.day);
      }
      const isoDate = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

      const utcNoon = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
      const noonParts = new Intl.DateTimeFormat('en-US', {
        timeZone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).formatToParts(utcNoon);
      const nm = {};
      for (const p of noonParts) nm[p.type] = p.value;
      const hr = Number(nm.hour === '24' ? 0 : nm.hour);
      const asUtc = Date.UTC(Number(nm.year), Number(nm.month) - 1, Number(nm.day), hr, Number(nm.minute), Number(nm.second));
      const tzOffsetHours = (asUtc - utcNoon.getTime()) / 3600000;

      const d2r = (d) => (d * Math.PI) / 180;
      const r2d = (r) => (r * 180) / Math.PI;
      let Y = year;
      let M = month;
      const D = day;
      if (M <= 2) {
        Y -= 1;
        M += 12;
      }
      const A = Math.floor(Y / 100);
      const B = 2 - A + Math.floor(A / 4);
      const JD = Math.floor(365.25 * (Y + 4716)) + Math.floor(30.6001 * (M + 1)) + D + B - 1524.5;

      const sunPos = (jd) => {
        const n = jd - 2451545.0;
        const g = d2r((357.529 + 0.98560028 * n) % 360);
        const q = (280.459 + 0.98564736 * n) % 360;
        const L = d2r((q + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)) % 360);
        const e = d2r(23.439 - 0.00000036 * n);
        const ra = r2d(Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L))) / 15;
        const decl = r2d(Math.asin(Math.sin(e) * Math.sin(L)));
        let eqt = q / 15 - ((ra + 24) % 24);
        if (eqt > 12) eqt -= 24;
        if (eqt < -12) eqt += 24;
        return { decl, eqt };
      };

      const baseJd = JD - lng / 360;
      const spNoon = sunPos(baseJd + 0.5);
      const noonUtc = 12 - spNoon.eqt - lng / 15;
      const ha = (angle, decl, nightHrs = 10) => {
        const num = -Math.sin(d2r(angle)) - Math.sin(d2r(lat)) * Math.sin(d2r(decl));
        const den = Math.cos(d2r(lat)) * Math.cos(d2r(decl));
        if (!den || Math.abs(num / den) > 1) return (angle / 60) * nightHrs;
        return r2d(Math.acos(num / den)) / 15;
      };

      const spRise = sunPos(baseJd + (noonUtc - ha(0.833, spNoon.decl)) / 24);
      const sunriseUtc = 12 - spRise.eqt - lng / 15 - ha(0.833, spRise.decl);
      const spSet = sunPos(baseJd + (noonUtc + ha(0.833, spNoon.decl)) / 24);
      const sunsetUtc = 12 - spSet.eqt - lng / 15 + ha(0.833, spSet.decl);
      const nightHrs = Math.max(4, Math.min(20, 24 - (sunsetUtc - sunriseUtc)));

      const spFajr = sunPos(baseJd + (noonUtc - ha(m.fajrAngle, spNoon.decl, nightHrs)) / 24);
      const fajrUtc = 12 - spFajr.eqt - lng / 15 - ha(m.fajrAngle, spFajr.decl, nightHrs) + Number(rawCfg.fajrOffsetMin || 0) / 60;
      const dhuhrUtc = noonUtc + (m.dhuhrMin + Number(rawCfg.dhuhrOffsetMin || 0)) / 60;
      const spMag = sunPos(baseJd + (noonUtc + ha(m.maghribAngle, spNoon.decl, nightHrs)) / 24);
      const maghribUtc = 12 - spMag.eqt - lng / 15 + ha(m.maghribAngle, spMag.decl, nightHrs) + Number(rawCfg.maghribOffsetMin || 0) / 60;

      const toSlot = (utcH) => {
        const rawMin = Math.round((utcH + tzOffsetHours) * 60);
        const wMin = ((rawMin % 1440) + 1440) % 1440;
        const hh = Math.floor(wMin / 60);
        const mm = wMin % 60;
        const time24 = `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
        const epochMs = Date.UTC(year, month - 1, day, 0, 0, 0) + Math.round((wMin - tzOffsetHours * 60) * 60000);
        return { time24, epochMs };
      };

      const fajrT = toSlot(fajrUtc);
      const riseT = toSlot(sunriseUtc);
      const dhuhrT = toSlot(dhuhrUtc);
      const setT = toSlot(sunsetUtc);
      const magT = toSlot(maghribUtc);

      return {
        isoDate,
        locationName,
        prayers: [
          {
            id: 'fajr',
            label: 'Fajr',
            arabic: 'صلاة الصبح',
            icon: '🌅',
            time24: fajrT.time24,
            epochMs: fajrT.epochMs,
            windowNote: `True Dawn (${m.fajrAngle}°) · Sunrise (الشروق) at ${riseT.time24}`,
            enabled: rawCfg.notifyFajr !== false
          },
          {
            id: 'dhuhr',
            label: 'Dohor',
            arabic: 'صلاة الظهرين',
            icon: '☀️',
            time24: dhuhrT.time24,
            epochMs: dhuhrT.epochMs,
            windowNote: `Solar Noon (Zawal) · Sunset at ${setT.time24}`,
            enabled: rawCfg.notifyDhuhr !== false
          },
          {
            id: 'maghrib',
            label: 'Maghrib',
            arabic: 'صلاة المغربين',
            icon: '🌙',
            time24: magT.time24,
            epochMs: magT.epochMs,
            windowNote: `Eastern Redness (${m.maghribAngle}° after Sunset ${setT.time24})`,
            enabled: rawCfg.notifyMaghrib !== false
          }
        ]
      };
    } catch {
      return null;
    }
  }

  getEffectiveBridgeSecret() {
    const fresh = loadTheoCredentials();
    return String(
      fresh.effectiveEdgeSecret ||
        this.relayConfig?.effectiveEdgeSecret ||
        this.relayConfig?.edgeAccessKey ||
        this.relayConfig?.key ||
        ''
    ).trim();
  }

  getDerivedBridgeToken() {
    const secret = this.getEffectiveBridgeSecret();
    return secret ? deriveEdgeAuthToken(secret) : '';
  }

  verifyBridgeToken(candidateToken) {
    const clean = String(candidateToken || '').trim();
    const secret = this.getEffectiveBridgeSecret();
    if (!secret) {
      return true;
    }
    if (!clean) return false;
    const derived = deriveEdgeAuthToken(secret);
    return (
      constantTimeTokenMatch(clean, derived) || constantTimeTokenMatch(clean, secret)
    );
  }

  extractRequestToken(req, parsedUrl = null) {
    const authHdr = String(req?.headers?.authorization || '').trim();
    if (/^Bearer\s+/i.test(authHdr)) {
      return authHdr.replace(/^Bearer\s+/i, '').trim();
    }
    const xKey = String(req?.headers?.['x-theo-key'] || '').trim();
    if (xKey) return xKey;
    const u = parsedUrl || new URL(req?.url || '/', `http://127.0.0.1:${this.port}`);
    return String(u.searchParams.get('token') || u.searchParams.get('key') || '').trim();
  }

  getAllowedOrigin(originHeader) {
    const origin = String(originHeader || '').trim();
    if (!origin) return '';
    const allowedExact = new Set([
      'https://husseinbdeir.github.io',
      `http://127.0.0.1:${this.port}`,
      `http://localhost:${this.port}`,
      `http://[::1]:${this.port}`
    ]);
    if (allowedExact.has(origin)) return origin;
    if (this.relayConfig?.allowLan) {
      for (const ip of getLanIps()) {
        if (origin === `http://${ip.address}:${this.port}`) {
          return origin;
        }
      }
    }
    return '';
  }

  isRequestOriginAllowed(req) {
    const origin = String(req?.headers?.origin || '').trim();
    if (!origin) {
      const secSite = String(req?.headers?.['sec-fetch-site'] || '').trim().toLowerCase();
      if (secSite === 'cross-site') return false;
      return true;
    }
    return Boolean(this.getAllowedOrigin(origin));
  }

  isTrustedLoopbackNavigation(req) {
    const remoteAddr = String(req?.socket?.remoteAddress || '');
    const isLoopback =
      remoteAddr === '127.0.0.1' ||
      remoteAddr === '::1' ||
      remoteAddr === '::ffff:127.0.0.1';
    if (!isLoopback) return false;
    const secSite = String(req?.headers?.['sec-fetch-site'] || '').trim().toLowerCase();
    if (secSite && secSite !== 'none' && secSite !== 'same-origin') {
      return false;
    }
    const hostHdr = String(req?.headers?.host || '').trim().toLowerCase();
    return (
      hostHdr === `127.0.0.1:${this.port}` ||
      hostHdr === `localhost:${this.port}` ||
      hostHdr === `[::1]:${this.port}`
    );
  }

  async start() {
    this.disposed = false;
    this.startHttpServer();
    this.refreshWorkspacesCache().catch(() => {});
    // Start periodic Cloud Relay sync & command polling every 4.5 seconds
    if (this.relayConfig.url && this.relayConfig.key) {
      this.startupSyncTimer = setTimeout(() => {
        this.startupSyncTimer = null;
        if (!this.disposed) {
          this.syncCloudRelay({ pushState: true }).catch(() => {});
        }
      }, 4500);
      this.cloudSyncTimer = setInterval(() => {
        if (!this.disposed) {
          this.syncCloudRelay({ pushState: true }).catch(() => {});
        }
      }, 4500);
    }
    return this.getStatus();
  }

  getStatus() {
    const allowLan = Boolean(this.relayConfig?.allowLan);
    const lanIps = allowLan ? getLanIps() : [];
    const primaryLan = lanIps[0]?.address || '127.0.0.1';
    const edgeStatus = this.edgeClient ? this.edgeClient.getStatus() : null;
    return {
      version: 3,
      codeMtime: this.codeMtime,
      listening: this.listening,
      standaloneMode: !this.vscode,
      port: this.port,
      allowLan,
      authRequired: Boolean(this.getEffectiveBridgeSecret()),
      hostname: os.hostname(),
      device: {
        id: this.deviceInfo?.id || 'workstation',
        name: this.deviceInfo?.name || os.hostname(),
        role: this.deviceInfo?.role || HOST_ROLE,
        capabilities: this.deviceInfo?.capabilities || [],
        pcSetup: readCachedPcSetupSummary() || null
      },
      // True while this host holds the duty the store hands to exactly one host at a time (see syncCloudRelay).
      coordinator: Boolean(this.isCoordinator),
      lanIps,
      localUrl: `http://127.0.0.1:${this.port}/`,
      wsUrl: `ws://127.0.0.1:${this.port}/ws`,
      lanUrl: allowLan ? `http://${primaryLan}:${this.port}/` : '',
      pwaUrl: this.relayConfig.pwaUrl || 'https://husseinbdeir.github.io/theo/',
      cloudConfigured: Boolean(this.relayConfig.url && this.relayConfig.key),
      edgeRelay: edgeStatus,
      edgeRelayUrl: edgeStatus?.url || this.getEffectiveEdgeUrl() || '',
      activeDirectRuns: this.directRunner ? this.directRunner.getActiveRuns().length : 0,
      lastCloudSyncAt: this.lastCloudSyncAt,
      lastCloudAttemptAt: this.lastCloudAttemptAt,
      cloudSyncInFlight: Boolean(this.cloudSyncInFlight),
      lastCloudError: this.lastCloudError || '',
      pushDeviceCount: this.pushDevices.length,
      claudePermissionMode: this.getClaudePermissionModeSnapshot()
    };
  }

  startHttpServer() {
    if (this.server) {
      return;
    }
    const bindHost = this.relayConfig?.allowLan ? '0.0.0.0' : '127.0.0.1';
    const srv = http.createServer(async (req, res) => {
      res.__theoReq = req;
      try {
        await this.handleHttpRequest(req, res);
      } catch (err) {
        const statusCode = err?.statusCode || 500;
        this.sendJson(res, statusCode, { ok: false, error: String(err?.message || err) });
      }
    });
    const handleWsClientReady = async (conn) => {
      conn.sendJson({
        type: 'welcome',
        device: this.deviceInfo,
        edgeRelayUrl: this.getEffectiveEdgeUrl(),
        status: this.getStatus(),
        devices: this.getUnifiedFleetDevices(),
        activeRuns: this.directRunner ? this.directRunner.getActiveRuns() : []
      });
      const st = await this.buildFullState().catch(() => null);
      if (st && !conn.closed) {
        conn.sendJson({ type: 'state', state: st });
      }
    };
    this.wsHub = attachWebSocketServer(srv, {
      path: '/ws',
      requireAuth: Boolean(this.getEffectiveBridgeSecret()),
      verifyUpgrade: (req) => this.isRequestOriginAllowed(req),
      verifyToken: (token) => this.verifyBridgeToken(token),
      onConnect: handleWsClientReady,
      onAuthenticated: handleWsClientReady,
      onMessage: async (msg, conn) => {
        if (!msg || typeof msg !== 'object') return;
        if (msg.type === 'claude_permission_mode') {
          const out = msg.alreadyStored
            ? await this.handleIncomingEdgeClaudeMode(msg, { fromLocalChannel: true })
            : await this.setFleetClaudePermissionMode(msg.defaultMode || msg.mode, {
                ...(msg.expectedRev !== undefined ? { expectedRev: msg.expectedRev } : {}),
                source: msg.source || 'theo-remote',
                updatedBy: msg.updatedBy || 'THEO Remote',
                skipPrimaryLoopback: true
              });
          if (msg.reqId) {
            conn.sendJson({
              type: 'rpc_res',
              reqId: msg.reqId,
              deviceId: this.deviceInfo.id,
              deviceName: this.deviceInfo.name,
              ok: out?.ok !== false,
              result: out
            });
          }
          return;
        }
        if (msg.type === 'rpc_cmd' || msg.reqId) {
          const payload = msg.cmd
            ? { ...msg.cmd, targetDeviceId: msg.targetDeviceId || msg.cmd.targetDeviceId }
            : msg;
          const out = await this.handleWsOrEdgeRpc(payload);
          if (msg.reqId) {
            conn.sendJson({
              type: 'rpc_res',
              reqId: msg.reqId,
              deviceId: this.deviceInfo.id,
              deviceName: this.deviceInfo.name,
              ok: out?.ok !== false,
              result: out
            });
          }
        }
      }
    });
    srv.on('error', (err) => {
      this.listening = false;
      if (this.edgeClient) {
        try {
          this.edgeClient.stop();
        } catch {}
      }
      if (err && err.code === 'EADDRINUSE' && this.server === srv) {
        if (!this.standbyBindTimer) {
          this.standbyBindTimer = setInterval(() => {
            if (!this.server || this.server !== srv || this.listening) {
              if (this.standbyBindTimer) {
                clearInterval(this.standbyBindTimer);
                this.standbyBindTimer = null;
              }
              return;
            }
            try {
              srv.listen(this.port, bindHost);
            } catch {}
          }, 5000);
        }
      }
    });
    srv.on('listening', () => {
      this.listening = true;
      if (this.standbyBindTimer) {
        clearInterval(this.standbyBindTimer);
        this.standbyBindTimer = null;
      }
      if (this.edgeClient && !this.disposed) {
        this.edgeClient.start();
      }
    });
    srv.listen(this.port, bindHost);
    this.server = srv;
  }

  setCorsHeaders(res) {
    const req = res.__theoReq || null;
    const allowedOrigin = this.getAllowedOrigin(req?.headers?.origin);
    if (allowedOrigin) {
      res.setHeader('Access-Control-Allow-Origin', allowedOrigin);
      res.setHeader('Vary', 'Origin');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Theo-Key');
    res.setHeader('Cache-Control', 'no-store');
  }

  sendJson(res, statusCode, obj) {
    this.setCorsHeaders(res);
    const body = JSON.stringify(obj);
    res.writeHead(statusCode, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(body)
    });
    res.end(body);
  }

  readJsonBody(req, maxBytes = 8 * 1024 * 1024) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      let totalBytes = 0;
      let aborted = false;
      req.on('data', (c) => {
        if (aborted) return;
        totalBytes += c.length;
        if (totalBytes > maxBytes) {
          aborted = true;
          const err = new Error('Payload too large');
          err.statusCode = 413;
          reject(err);
          try {
            req.destroy();
          } catch {}
          return;
        }
        chunks.push(c);
      });
      req.on('end', () => {
        if (aborted) return;
        const raw = Buffer.concat(chunks).toString('utf8').trim();
        if (!raw) {
          resolve({});
          return;
        }
        try {
          resolve(JSON.parse(raw));
        } catch {
          resolve({ raw });
        }
      });
      req.on('error', () => {
        if (!aborted) resolve({});
      });
    });
  }

  triggerUrgentCloudSync(delayMs = 0) {
    if (!this.relayConfig?.url || !this.relayConfig?.key) {
      return;
    }
    const fire = () => {
      if (this.cloudSyncInFlight) {
        this.pendingUrgentCloudSync = true;
        return;
      }
      this.syncCloudRelay({ pushState: true, urgent: true }).catch(() => {});
    };
    if (delayMs > 0) {
      if (this.urgentSyncDebounceTimer) {
        clearTimeout(this.urgentSyncDebounceTimer);
      }
      this.urgentSyncDebounceTimer = setTimeout(() => {
        this.urgentSyncDebounceTimer = null;
        fire();
      }, delayMs);
    } else {
      fire();
    }
  }

  notifyStateUpdated() {
    if (
      (this.wsHub && this.wsHub.clients.size > 0) ||
      this.sseClients.size > 0 ||
      this.pushDevices.length > 0 ||
      this.edgeClient?.getStatus()?.connected ||
      (this.relayConfig?.url && this.relayConfig?.key)
    ) {
      this.buildFullState()
        .then((stateObj) => {
          this.evaluateRealtimePushAlerts(stateObj).catch(() => {});
          if (this.relayConfig?.url && this.relayConfig?.key) {
            const topRows = Array.isArray(stateObj?.rows) ? stateObj.rows.slice(0, 24) : [];
            const sig =
              topRows
                .map(
                  (r) =>
                    `${r.id}:${r.status}:${r.stepCount || 0}:${r.bgRunningCount || 0}:${r.open ? 1 : 0}:${r.active ? 1 : 0}:${r.unread ? 1 : 0}`
                )
                .join('|') +
              '||' +
              (stateObj?.approvals || []).map((a) => a.id).join(',') +
              '||' +
              (stateObj?.claudePermissionMode?.defaultMode || '') +
              '||' +
              (stateObj?.hideThirdPartyQuota ? '1' : '0') +
              ':' +
              Number(stateObj?.hideThirdPartyQuotaUpdatedAt || 0);
            if (sig && sig !== this.lastSyncedStateSig) {
              this.lastSyncedStateSig = sig;
              this.triggerUrgentCloudSync(350);
            }
          }
          if (this.wsHub && this.wsHub.clients.size > 0) {
            this.wsHub.broadcast({ type: 'state', state: stateObj });
          }
          if (this.edgeClient?.getStatus()?.connected && !this.edgeStatePushTimer) {
            this.edgeStatePushTimer = setTimeout(() => {
              this.edgeStatePushTimer = null;
              this.edgeClient.pushHostState().catch(() => {});
            }, 250);
          }
          if (
            ((this.wsHub && this.wsHub.clients.size > 0) ||
              this.edgeClient?.getStatus()?.connected) &&
            !this.activeThreadBroadcastTimer
          ) {
            const workingLocalRows = (Array.isArray(stateObj?.rows) ? stateObj.rows : [])
              .filter((r) => r && !r.remotePeer && r.status === 'working' && r.id)
              .slice(0, 3);
            if (workingLocalRows.length > 0) {
              this.activeThreadBroadcastTimer = setTimeout(() => {
                this.activeThreadBroadcastTimer = null;
                for (const r of workingLocalRows) {
                  this.getThreadDetail(r.id, r.provider || '', {
                    skipLiveContext: true,
                    skipBgLogs: true
                  }).catch(() => {});
                }
              }, 420);
            }
          }
          if (this.sseClients.size > 0) {
            const frame = `event: state\ndata: ${JSON.stringify(stateObj)}\n\n`;
            for (const client of Array.from(this.sseClients)) {
              try {
                client.write(frame);
              } catch {
                this.sseClients.delete(client);
              }
            }
          }
        })
        .catch(() => {});
    }
  }

  async refreshWorkspacesCache(opts = {}) {
    const now = Date.now();
    if (this.workspacesCache.length > 0 && now - this.workspacesCachedAt < 45000) {
      return this.workspacesCache;
    }
    if (this.workspacesRefreshInFlight) {
      return this.workspacesCache;
    }
    this.workspacesRefreshInFlight = true;
    const runRefresh = async () => {
      try {
        const results = await Promise.all(
          BHFIRMS_WORKSPACES.map((w) => inspectWorkspaceGit(w, false))
        );
        this.workspacesCache = results.filter((r) => r.exists);
        this.workspacesCachedAt = Date.now();
      } catch {} finally {
        this.workspacesRefreshInFlight = false;
      }
      return this.workspacesCache;
    };
    if (this.workspacesCache.length > 0 || opts.nonBlocking) {
      runRefresh().catch(() => {});
      return this.workspacesCache;
    }
    return runRefresh();
  }

  readPersistentHubEndpoint() {
    const now = Date.now();
    if (this._hubEndpointCache && now - this._hubEndpointCachedAt < 8000) {
      return this._hubEndpointCache;
    }
    try {
      const hubFile = path.join(os.homedir(), '.gemini', 'antigravity', 'bhf-persistent-hub.json');
      if (fs.existsSync(hubFile)) {
        const data = JSON.parse(fs.readFileSync(hubFile, 'utf8'));
        if (data && data.port && data.csrfToken) {
          this._hubEndpointCache = {
            host: '127.0.0.1',
            port: Number(data.port),
            csrfToken: String(data.csrfToken)
          };
          this._hubEndpointCachedAt = now;
          return this._hubEndpointCache;
        }
      }
    } catch {}
    return null;
  }

  callHubLanguageServerRpc(method, bodyObj, timeoutMs = 2500) {
    return new Promise((resolve, reject) => {
      const ep = this.readPersistentHubEndpoint();
      if (!ep || !ep.port || !ep.csrfToken) {
        reject(new Error('Persistent hub endpoint not available'));
        return;
      }
      const payload = JSON.stringify(bodyObj || {});
      const req = http.request(
        {
          hostname: ep.host,
          port: ep.port,
          path: `/exa.language_server_pb.LanguageServerService/${method}`,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Connect-Protocol-Version': '1',
            'x-codeium-csrf-token': ep.csrfToken,
            'Content-Length': Buffer.byteLength(payload)
          },
          timeout: timeoutMs
        },
        (res) => {
          const chunks = [];
          res.on('data', (chunk) => chunks.push(chunk));
          res.on('end', () => {
            const text = Buffer.concat(chunks).toString('utf8');
            if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
              try {
                resolve(text ? JSON.parse(text) : {});
              } catch (err) {
                reject(err);
              }
            } else {
              reject(new Error(`RPC ${method} HTTP ${res.statusCode}`));
            }
          });
        }
      );
      req.on('timeout', () => req.destroy(new Error(`RPC ${method} timeout`)));
      req.on('error', reject);
      req.write(payload);
      req.end();
    });
  }

  async fetchGeneratorMetadataDirect(cascadeId) {
    const cleanId = String(cascadeId || '').trim();
    if (!cleanId || !/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(cleanId)) return null;
    if (!this.gmCacheById) {
      this.gmCacheById = new Map();
    }
    let cacheEntry = this.gmCacheById.get(cleanId);
    const now = Date.now();
    if (cacheEntry?.lastSummary && now - cacheEntry.fetchedAt < 3500) {
      return cacheEntry.lastSummary;
    }
    if (!cacheEntry) {
      cacheEntry = { offset: 0, lastGm: null, lastBaseOverhead: null, lastSummary: null, fetchedAt: 0 };
      this.gmCacheById.set(cleanId, cacheEntry);
    }
    try {
      let offset = Math.max(0, cacheEntry.offset > 0 ? cacheEntry.offset - 1 : 0);
      let latestChatGm = cacheEntry.lastGm;
      let latestBaseOverhead = cacheEntry.lastBaseOverhead || null;
      let totalCount = offset;

      for (let pageIdx = 0; pageIdx < 15; pageIdx += 1) {
        const resp = await this.callHubLanguageServerRpc(
          'GetCascadeTrajectoryGeneratorMetadata',
          { cascadeId: cleanId, generatorMetadataOffset: offset },
          2200
        );
        const list = Array.isArray(resp?.generatorMetadata) ? resp.generatorMetadata : [];
        if (list.length === 0) {
          if (offset > 0 && pageIdx === 0) {
            offset = 0;
            latestChatGm = null;
            totalCount = 0;
            continue;
          }
          break;
        }
        for (let i = 0; i < list.length; i += 1) {
          const grps = list[i]?.chatModel?.chatStartMetadata?.contextWindowMetadata?.tokenBreakdown?.groups;
          if (Array.isArray(grps) && grps.length > 0) {
            let bSys = 0;
            let bTools = 0;
            for (const g of grps) {
              const gt = String(g?.type || '');
              const gn = String(g?.name || '');
              const num = Number(g?.numTokens || 0);
              if (gt.includes('SYSTEM_PROMPT') || gn === 'System Prompt') bSys += num;
              else if (gt.includes('TOOLS') || gn === 'Tools' || gn === 'MCP Tools') bTools += num;
            }
            if (bSys > 0 || bTools > 0) {
              latestBaseOverhead = { systemPromptTokens: bSys, toolsTokens: bTools };
            }
          }
        }
        for (let i = list.length - 1; i >= 0; i -= 1) {
          if (list[i]?.chatModel) {
            latestChatGm = list[i];
            break;
          }
        }
        offset += list.length;
        totalCount = offset;
        if (list.length < 100) break;
      }

      cacheEntry.offset = totalCount;
      cacheEntry.lastGm = latestChatGm;
      cacheEntry.lastBaseOverhead = latestBaseOverhead;
      cacheEntry.fetchedAt = Date.now();
      if (!latestChatGm) return null;

      const chatModel = latestChatGm.chatModel || {};
      const plannerConfig = latestChatGm.plannerConfig || {};
      const retryInfos = Array.isArray(chatModel.retryInfos) ? chatModel.retryInfos : [];
      let usage = chatModel.usage || {};
      for (let i = retryInfos.length - 1; i >= 0; i -= 1) {
        if (retryInfos[i]?.usage) {
          usage = retryInfos[i].usage;
          break;
        }
      }
      const cwm = chatModel?.chatStartMetadata?.contextWindowMetadata || {};
      const maxContextTokens = Number(cwm.maxContextTokens || 256000);

      // Detect trailing /compact CHECKPOINT steps completed after latestChatGm
      const gmIndices = Array.isArray(latestChatGm.stepIndices) ? latestChatGm.stepIndices : [];
      let lastGmStepIdx = -1;
      for (const idx of gmIndices) {
        const n = Number(idx);
        if (Number.isFinite(n) && n > lastGmStepIdx) lastGmStepIdx = n;
      }
      if (lastGmStepIdx < 0) {
        const fb = Number(chatModel?.customMetadata?.last_step_index);
        if (Number.isFinite(fb) && fb >= 0) lastGmStepIdx = fb;
      }
      if (lastGmStepIdx >= 0) {
        try {
          const stepsResp = await this.callHubLanguageServerRpc(
            'GetCascadeTrajectorySteps',
            { cascadeId: cleanId, stepOffset: lastGmStepIdx + 1 },
            1500
          );
          const trailingSteps = Array.isArray(stepsResp?.steps) ? stepsResp.steps : [];
          let lastCpPos = -1;
          for (let i = trailingSteps.length - 1; i >= 0; i -= 1) {
            const st = trailingSteps[i];
            if (
              st?.type === 'CORTEX_STEP_TYPE_CHECKPOINT' &&
              (!st?.status || st.status === 'CORTEX_STEP_STATUS_DONE')
            ) {
              lastCpPos = i;
              break;
            }
          }
          if (lastCpPos >= 0) {
            const cpStep = trailingSteps[lastCpPos];
            const cpRetries = Array.isArray(cpStep?.metadata?.retryInfos) ? cpStep.metadata.retryInfos : [];
            let summaryOut = 0;
            for (let i = cpRetries.length - 1; i >= 0; i -= 1) {
              const u = cpRetries[i]?.usage;
              const ro = Number(u?.responseOutputTokens || u?.outputTokens || 0);
              if (ro > 0) {
                summaryOut = ro;
                break;
              }
            }
            if (!summaryOut) {
              const sTxt = String(cpStep?.checkpoint?.sessionSummary || '');
              summaryOut = sTxt.length > 0 ? Math.ceil(sTxt.length / 3.5) : 2500;
            }
            const sysT = Number(latestBaseOverhead?.systemPromptTokens || 12200);
            const toolsT = Number(latestBaseOverhead?.toolsTokens || 5400);
            const cpT = summaryOut + 850;
            let uT = 0;
            let aT = 0;
            let trT = 0;
            for (const st of trailingSteps.slice(lastCpPos + 1)) {
              const sType = String(st?.type || '');
              if (sType === 'CORTEX_STEP_TYPE_USER_INPUT') {
                const txt = String(st?.userInput?.userResponse || '');
                if (txt) uT += Math.max(20, Math.ceil(txt.length / 3.8));
                const items = Array.isArray(st?.userInput?.items) ? st.userInput.items : [];
                for (const it of items) {
                  if (it?.media || it?.item?.media) uT += 1100;
                }
              } else if (sType === 'CORTEX_STEP_TYPE_PLANNER_RESPONSE') {
                const th = String(st?.plannerResponse?.thinking || '') + String(st?.plannerResponse?.response || '');
                if (th) aT += Math.ceil(th.length / 3.8);
              } else if (sType && sType !== 'CORTEX_STEP_TYPE_CHECKPOINT') {
                const raw = JSON.stringify(st?.viewFile || st?.runCommand || st?.grepSearch || '');
                if (raw && raw.length > 2) trT += Math.min(12000, Math.ceil(raw.length / 4.2));
              }
            }
            const cpUsed = sysT + toolsT + cpT + uT + aT + trT;
            const cpSummary = {
              ok: true,
              compacted: true,
              usedTokens: cpUsed,
              estimatedTokensUsed: cpUsed,
              maxContextTokens,
              limitTokens: maxContextTokens || 256000,
              modelName: String(
                plannerConfig.modelName ||
                  plannerConfig.planModel ||
                  chatModel.modelDisplayName ||
                  usage.model ||
                  ''
              ),
              breakdown: {
                systemPromptTokens: sysT,
                toolsTokens: toolsT,
                userTokens: uT,
                assistantTokens: aT,
                toolResultsTokens: trT,
                checkpointTokens: cpT
              }
            };
            cacheEntry.lastSummary = cpSummary;
            return cpSummary;
          }
        } catch {}
      }

      const inputTokens = Number(usage.inputTokens || 0);
      const cacheReadTokens = Number(usage.cacheReadTokens || 0);
      const outputTokens = Number(usage.outputTokens || 0);
      const estimatedTokensUsed = Number(cwm.estimatedTokensUsed || 0);
      const promptPlusCache = inputTokens + cacheReadTokens;
      const usedTokens = estimatedTokensUsed > 0 ? estimatedTokensUsed : promptPlusCache + outputTokens;

      const groups = Array.isArray(cwm?.tokenBreakdown?.groups) ? cwm.tokenBreakdown.groups : [];
      let systemPromptTokens = 0;
      let toolsTokens = 0;
      let userTokens = 0;
      let assistantTokens = 0;
      let toolResultsTokens = 0;
      let checkpointTokens = 0;

      for (const grp of groups) {
        const gType = String(grp?.type || '');
        const gName = String(grp?.name || '');
        const gTokens = Number(grp?.numTokens || 0);
        const children = Array.isArray(grp?.children) ? grp.children : [];
        if (gType.includes('SYSTEM_PROMPT') || gName === 'System Prompt') {
          systemPromptTokens += gTokens;
        } else if (gType.includes('TOOLS') || gName === 'Tools' || gName === 'MCP Tools') {
          toolsTokens += gTokens;
        } else if (gType.includes('CHAT_MESSAGES') || gName === 'Chat Messages') {
          for (const ch of children) {
            const chTokens = Number(ch?.numTokens || 0);
            const rawName = String(ch?.name || '');
            const kind = rawName.includes(': ') ? rawName.split(': ').slice(1).join(': ') : rawName;
            if (kind === 'USER_INPUT') userTokens += chTokens;
            else if (kind === 'PLANNER_RESPONSE') assistantTokens += chTokens;
            else if (kind === 'CHECKPOINT') checkpointTokens += chTokens;
            else toolResultsTokens += chTokens;
          }
        }
      }

      if (groups.length === 0 && latestBaseOverhead && usedTokens > 0) {
        const bSys = Number(latestBaseOverhead.systemPromptTokens || 0);
        const bTools = Number(latestBaseOverhead.toolsTokens || 0);
        if (bSys + bTools > 0 && bSys + bTools < usedTokens) {
          systemPromptTokens = bSys;
          toolsTokens = bTools;
          toolResultsTokens = Math.max(0, usedTokens - bSys - bTools);
        }
      }

      const summary = {
        ok: true,
        usedTokens,
        estimatedTokensUsed,
        maxContextTokens,
        limitTokens: maxContextTokens || 256000,
        modelName: String(
          plannerConfig.modelName ||
            plannerConfig.planModel ||
            chatModel.modelDisplayName ||
            usage.model ||
            ''
        ),
        breakdown: {
          systemPromptTokens,
          toolsTokens,
          userTokens,
          assistantTokens,
          toolResultsTokens,
          checkpointTokens
        }
      };
      cacheEntry.lastSummary = summary;
      return summary;
    } catch {
      return cacheEntry?.lastSummary || null;
    }
  }

  async fetchLiveCascadeTailOverlay(cascadeId, diskStepCount = 0) {
    const cleanId = String(cascadeId || '').trim();
    if (!cleanId || !/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(cleanId)) return null;
    if (!this.liveCascadeTailCache) {
      this.liveCascadeTailCache = new Map();
    }
    const now = Date.now();
    const cached = this.liveCascadeTailCache.get(cleanId);
    if (cached && now - cached.fetchedAt < 750) {
      return cached.overlay;
    }
    try {
      const stepOffset = Math.max(0, Number(diskStepCount || 0) - 3);
      const resp = await this.callHubLanguageServerRpc(
        'GetCascadeTrajectorySteps',
        { cascadeId: cleanId, stepOffset, stepLimit: 8 },
        750
      );
      const steps = Array.isArray(resp?.steps) ? resp.steps : [];
      if (steps.length === 0) {
        this.liveCascadeTailCache.set(cleanId, { fetchedAt: now, overlay: null });
        return null;
      }
      let latestThinking = '';
      let latestText = '';
      let latestStatus = '';
      const extraTools = [];
      for (let i = 0; i < steps.length; i += 1) {
        const st = steps[i];
        if (!st || typeof st !== 'object') continue;
        const absIdx = stepOffset + i;
        const sType = String(st.type || '');
        const sStatus = String(st.status || '');
        const isLiveOrNew =
          absIdx >= Number(diskStepCount || 0) ||
          sStatus.includes('GENERATING') ||
          sStatus.includes('RUNNING') ||
          sStatus.includes('PENDING');
        if (!isLiveOrNew) continue;
        latestStatus = sStatus || latestStatus;
        if (sType === 'CORTEX_STEP_TYPE_PLANNER_RESPONSE' && st.plannerResponse) {
          const pr = st.plannerResponse;
          if (pr.thinking) latestThinking = String(pr.thinking).trim();
          if (pr.response) latestText = String(pr.response).trim();
          const prCalls = Array.isArray(pr.toolCalls) ? pr.toolCalls : [];
          for (const tc of prCalls) {
            const args = tc.arguments || tc.args || {};
            const enriched = enrichToolCall(tc.name || 'tool', args, '');
            enriched.id = tc.id || `live-tc-${absIdx}`;
            extraTools.push(enriched);
          }
        } else if (st.viewFile || st.readFile || sType.includes('VIEW_FILE') || sType.includes('READ_FILE')) {
          const vf = st.viewFile || st.readFile || {};
          const rawP = vf.absolutePathUri || vf.absolutePath || vf.path || vf.filePath || '';
          if (rawP) {
            extraTools.push(enrichToolCall('read_file', { Path: rawP, StartLine: vf.startLine, EndLine: vf.endLine }, ''));
          }
        } else if (st.editFile || st.replaceFileContent || sType.includes('EDIT_FILE') || sType.includes('REPLACE_FILE')) {
          const ef = st.editFile || st.replaceFileContent || {};
          const rawP = ef.absolutePathUri || ef.targetFile || ef.path || ef.filePath || '';
          if (rawP) {
            extraTools.push(enrichToolCall('edit_file', { Path: rawP }, ''));
          }
        } else if (st.writeToFile || sType.includes('WRITE_TO_FILE') || sType.includes('WRITE_FILE')) {
          const wf = st.writeToFile || {};
          const rawP = wf.targetFile || wf.absolutePathUri || wf.path || '';
          if (rawP) {
            extraTools.push(enrichToolCall('write_file', { Path: rawP }, ''));
          }
        } else if (st.runCommand || sType.includes('RUN_COMMAND')) {
          const rc = st.runCommand || {};
          const cmd = rc.commandLine || rc.command || '';
          if (cmd) {
            extraTools.push(enrichToolCall('run_command', { CommandLine: cmd }, ''));
          }
        } else if (st.grepSearch || st.findByName || sType.includes('GREP_SEARCH') || sType.includes('FIND_BY_NAME')) {
          const gs = st.grepSearch || st.findByName || {};
          const q = gs.query || gs.pattern || '';
          extraTools.push(enrichToolCall('grep_search', { Query: q, SearchPath: gs.searchPath || '' }, ''));
        }
      }
      const overlay =
        latestThinking || latestText || extraTools.length > 0
          ? {
              thinking: latestThinking,
              text: latestText,
              toolCalls: extraTools,
              stepStatus: latestStatus,
              totalSteps: stepOffset + steps.length,
              updatedAt: now
            }
          : null;
      this.liveCascadeTailCache.set(cleanId, { fetchedAt: now, overlay });
      if (this.liveCascadeTailCache.size > 40) {
        const fk = this.liveCascadeTailCache.keys().next().value;
        if (fk) this.liveCascadeTailCache.delete(fk);
      }
      return overlay;
    } catch {
      return null;
    }
  }

  deriveLiveActivityDescriptor(effectiveMessages, isWorking, liveTail = null) {
    if (!isWorking) {
      return { active: false };
    }
    const msgs = Array.isArray(effectiveMessages) ? effectiveMessages : [];
    let lastAsst = null;
    for (let i = msgs.length - 1; i >= 0; i -= 1) {
      if (msgs[i] && msgs[i].role === 'assistant') {
        lastAsst = msgs[i];
        break;
      }
      if (msgs[i] && msgs[i].role === 'user') {
        break;
      }
    }
    const toolCalls = Array.isArray(lastAsst?.toolCalls) ? lastAsst.toolCalls : [];
    const lastTc = toolCalls.length > 0 ? toolCalls[toolCalls.length - 1] : null;
    const rawThinking = String(
      liveTail?.thinking || lastAsst?.latestThinking || lastAsst?.thinking || ''
    ).trim();
    const cleanThoughtLines = rawThinking
      .replace(/```[\s\S]*?```/g, ' ')
      .replace(/[#>*_`~]/g, '')
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);
    const thoughtPreview =
      cleanThoughtLines.length > 0
        ? cleanThoughtLines[cleanThoughtLines.length - 1].slice(0, 220)
        : '';

    let verb = 'Thinking…';
    let target = '';
    let kind = 'thinking';
    const tailGeneratingThoughtOnly =
      liveTail &&
      String(liveTail.stepStatus || '').includes('GENERATING') &&
      liveTail.thinking &&
      (!Array.isArray(liveTail.toolCalls) || liveTail.toolCalls.length === 0);

    if (lastTc && !tailGeneratingThoughtOnly) {
      kind = String(lastTc.kind || 'tool');
      if (kind === 'read') {
        verb = 'Reading';
        target = lastTc.file || lastTc.summary || 'file';
      } else if (kind === 'edit') {
        verb = 'Editing';
        target = lastTc.file || lastTc.summary || 'file';
      } else if (kind === 'write') {
        verb = 'Creating';
        target = lastTc.file || lastTc.summary || 'file';
      } else if (kind === 'cmd') {
        verb = 'Running';
        target = lastTc.summary || 'command';
      } else if (kind === 'search') {
        verb = 'Searching';
        target = lastTc.summary || 'workspace';
      } else if (kind === 'subagent') {
        verb = 'Delegating';
        target = lastTc.subagentRole || lastTc.summary || 'subagent';
      } else {
        verb = 'Working on';
        target = lastTc.file || lastTc.summary || lastTc.label || 'step';
      }
    } else if (lastAsst?.activeTool) {
      verb = 'Running';
      target = String(lastAsst.activeTool);
      kind = 'tool';
    }

    const cleanTarget = String(target || '').replace(/^(Read|Updated|Wrote|Pattern)\s+/i, '').trim().slice(0, 120);
    return {
      active: true,
      verb,
      target: cleanTarget,
      file: String(lastTc?.file || '').slice(0, 100),
      relPath: String(lastTc?.relPath || lastTc?.file || '').slice(0, 180),
      lineRange: String(lastTc?.lineRange || '').slice(0, 32),
      kind,
      label: cleanTarget ? `${verb} ${cleanTarget}` : verb,
      thoughtPreview,
      stepCount: Number(lastAsst?.totalTurnTools || toolCalls.length || 0),
      thoughtCount: Number(lastAsst?.totalThoughtCount || (lastAsst?.thoughtBlocks || []).length || (rawThinking ? 1 : 0)),
      startedAt: lastAsst?.startedAt || lastAsst?.createdAt || '',
      updatedAt: Date.now()
    };
  }

  async collectPendingApprovals() {
    const approvals = [];
    const hubPayload = this.getHubLastPayload();
    const rowsById = new Map((hubPayload?.rows || []).map((r) => [r.id, r]));
    if (this.vscode?.commands) {
      try {
        const agyPending = await withTimeout(
          this.vscode.commands.executeCommand('antigravityHub.getPendingApprovals'),
          1500,
          []
        );
        if (Array.isArray(agyPending)) {
          for (const item of agyPending) {
            const rawBtns = Array.isArray(item.buttons) ? item.buttons : [];
            if (!rawBtns.length) continue;
            const row = rowsById.get(item.id);
            const firstBtn = rawBtns[0];
            const isObj = firstBtn && typeof firstBtn === 'object';
            const labels = rawBtns
              .map((b) => (typeof b === 'string' ? b : b?.label || ''))
              .filter(Boolean);
            const approveLabel =
              labels.find((l) => /^(Run|Accept|Approve|Proceed|Submit|Allow)$/i.test(l)) ||
              labels[0] ||
              'Approve';
            const hasQuestion = Boolean(row?.pendingQuestion);
            const stepKey = row?.pendingQuestion?.stepIndex || row?.stepCount || 0;
            const normQs =
              Array.isArray(row?.pendingQuestion?.questions) &&
              row.pendingQuestion.questions.length
                ? row.pendingQuestion.questions
                : [];
            approvals.push({
              id: hasQuestion
                ? `question-${item.id}-${stepKey}`
                : stepKey
                  ? `agy-app-${item.id}-${stepKey}`
                  : `agy-app-${item.id}`,
              approvalId: item.id,
              provider: 'antigravity',
              sessionId: item.id,
              title: item.title || row?.title || 'Antigravity Session',
              toolName: hasQuestion ? 'Question' : approveLabel,
              detail:
                row?.pendingQuestion?.questionText ||
                (isObj ? firstBtn.context : '') ||
                item.summary ||
                `${row?.folder || 'Workspace'} · Waiting for confirmation`,
              isMultiSelect: Boolean(
                row?.pendingQuestion?.isMultiSelect || normQs[0]?.isMultiSelect
              ),
              options: row?.pendingQuestion?.options || [],
              questions: normQs,
              stepIndex: stepKey,
              selector: isObj ? firstBtn.selector || '' : '',
              kind: hasQuestion ? 'question' : 'approve',
              createdAt: item.updatedAt || Date.now()
            });
          }
        }
      } catch {}
    }

    try {
      this.claudeBridge?.hotUpgradeLiveState?.();
    } catch {}
    const claudePerms =
      this.claudeBridge?.getPendingPermissionsSnapshot?.() ||
      this.hub?.snapshot?.claudeLive?.pendingPermissions ||
      [];
    for (const perm of claudePerms) {
      const builtPermQ = buildClaudeToolPermissionQuestion(
        {
          stepIndex: 0,
          toolUseId: perm.toolUseId || '',
          toolName: perm.toolName || 'Tool',
          inputs: perm.inputs || {},
          at: Math.floor((perm.createdAt || Date.now()) / 1000)
        },
        perm.suggestions || []
      );
      const isQuestionPerm =
        perm.toolName === 'AskUserQuestion' || perm.toolName === 'ask_question';
      const permQs =
        Array.isArray(builtPermQ?.questions) && builtPermQ.questions.length > 0
          ? builtPermQ.questions
          : isQuestionPerm
            ? normalizeQuestionItems(perm.inputs?.questions)
            : [];
      let inputPreview =
        builtPermQ?.questionText ||
        perm.inputs?.command ||
        perm.inputs?.file_path ||
        perm.inputs?.description ||
        '';
      if (!inputPreview && permQs[0]) {
        inputPreview = String(permQs[0].question || '').trim();
      }
      if (!inputPreview) {
        inputPreview = JSON.stringify(perm.inputs || {}).slice(0, 140);
      }
      approvals.push({
        id: perm.id,
        approvalId: perm.id,
        provider: 'claude',
        sessionId: perm.sessionId || '',
        title: perm.title || 'Claude Code',
        toolName: isQuestionPerm ? 'Question' : perm.toolName || 'Tool Permission',
        detail: inputPreview,
        codePreview: builtPermQ?.codePreview || '',
        description: builtPermQ?.description || '',
        isToolPermission: Boolean(builtPermQ?.isToolPermission),
        writeInPlaceholder: builtPermQ?.writeInPlaceholder || '',
        isMultiSelect: Boolean(builtPermQ?.isMultiSelect || permQs[0]?.isMultiSelect),
        options:
          Array.isArray(builtPermQ?.options) && builtPermQ.options.length > 0
            ? builtPermQ.options
            : permQs[0]
              ? permQs[0].options.map((o) => o.text)
              : [],
        questions: permQs,
        inputs: perm.inputs || {},
        suggestions: perm.suggestions || [],
        kind: permQs.length > 0 || isQuestionPerm ? 'question' : 'approve',
        createdAt: perm.createdAt || Date.now()
      });
    }

    // Also surface any session with a pending question or classified as 'waiting' so the user can jump in or reply with 1 tap
    for (const row of hubPayload?.rows || []) {
      if (row.pendingQuestion || row.status === 'waiting') {
        const alreadyListed = approvals.some((a) => a.sessionId === row.id);
        if (!alreadyListed) {
          const isQ = Boolean(row.pendingQuestion);
          const stepKey = row.pendingQuestion?.stepIndex || row.stepCount || 0;
          const normQs =
            Array.isArray(row.pendingQuestion?.questions) && row.pendingQuestion.questions.length
              ? row.pendingQuestion.questions
              : [];
          const itemId =
            row.pendingQuestion?.approvalId ||
            (isQ
              ? `question-${row.id}-${stepKey}`
              : stepKey
                ? `waiting-${row.id}-${stepKey}`
                : `waiting-${row.id}`);
          approvals.push({
            id: itemId,
            approvalId: itemId,
            provider: row.provider || 'antigravity',
            sessionId: row.id,
            title: row.title || 'Session waiting for input',
            toolName:
              row.pendingQuestion?.toolName ||
              (isQ ? 'Question' : row.reason || 'Waiting on user input'),
            detail:
              row.pendingQuestion?.questionText ||
              row.lastAssistantText ||
              `${row.folder || 'Workspace'} · ${row.model || ''}`.trim(),
            codePreview: row.pendingQuestion?.codePreview || '',
            description: row.pendingQuestion?.description || '',
            isToolPermission: Boolean(row.pendingQuestion?.isToolPermission),
            writeInPlaceholder: row.pendingQuestion?.writeInPlaceholder || '',
            isMultiSelect: Boolean(
              row.pendingQuestion?.isMultiSelect || normQs[0]?.isMultiSelect
            ),
            options: row.pendingQuestion?.options || [],
            questions: normQs,
            stepIndex: stepKey,
            kind: isQ ? 'question' : 'waiting_session',
            createdAt:
              (row.pendingQuestion?.at ? row.pendingQuestion.at * 1000 : row.at) || Date.now()
          });
        }
      }
    }

    return approvals;
  }

  getHubLastPayload() {
    if (this.hub?.lastPosted) {
      try {
        return JSON.parse(this.hub.lastPosted);
      } catch {}
    }
    return null;
  }

  async buildFullState(opts = {}) {
    this.syncFromDiskPersonalLedger();
    if (this.hub && !this.hub.snapshot) {
      await withTimeout(this.hub.refresh({ forceQuota: false }).catch(() => {}), 3000, null);
    }
    if (this.hub && !this.hub.lastPosted) {
      this.hub.render();
    }
    const basePayload = this.getHubLastPayload() || {};
    const [approvals, rawWorkspaces] = await Promise.all([
      this.collectPendingApprovals(),
      this.refreshWorkspacesCache({ nonBlocking: true })
    ]);
    // Hourly unsaved-work report for the evening digest; self-throttled, never awaited.
    refreshUnsavedWork().catch(() => {});

    const selfDevId = this.deviceInfo?.id || 'workstation';
    const selfDevName = this.deviceInfo?.name || os.hostname();
    const workspaces = (rawWorkspaces || []).map((w) => ({
      ...w,
      deviceId: selfDevId,
      deviceName: selfDevName
    }));

    const nowMs = Date.now();
    const peerOwnedRowIds = new Map();
    const recordPeerRows = (devId, list) => {
      if (!devId || devId === selfDevId || !Array.isArray(list)) return;
      let set = peerOwnedRowIds.get(devId);
      if (!set) {
        set = new Set();
        peerOwnedRowIds.set(devId, set);
      }
      for (const pr of list) {
        if (pr && pr.id) set.add(String(pr.id));
      }
    };
    if (this.edgeClient) {
      for (const [pDevId, pEntry] of Object.entries(this.edgeClient.getPeerSnapshots())) {
        recordPeerRows(pDevId, pEntry?.snapshot?.rows);
      }
    }
    for (const [rDevId, rEntry] of Object.entries(this.remoteDeviceStates || {})) {
      recordPeerRows(rDevId, rEntry?.snapshot?.rows || rEntry?.rows);
    }
    const rowById = new Map();
    const baseRows = Array.isArray(basePayload.rows) ? basePayload.rows : [];
    for (const r of baseRows) {
      if (!r || !r.id) continue;
      const ownerInfo = inferRowOwnerDevice(r, this.deviceInfo, { peerOwnedRowIds });
      const ownerDevId = ownerInfo.id || ownerInfo.deviceId;
      const ownerDevName = ownerInfo.name || ownerInfo.deviceName;
      const isForeignRow =
        ownerDevId !== selfDevId || r.source === 'cloud-relay' || Boolean(r.remotePeer);
      if (opts.localOnly && isForeignRow) continue;
      const stopped = this.userStoppedSessionsById?.get(r.id);
      const recentlyStopped = Boolean(stopped && nowMs - Number(stopped.at || 0) < 60000);
      const modelOverride = this.sessionModelOverrides?.get(r.id) || null;
      const effectiveModelLabel = modelOverride?.displayModel
        ? formatModelDisplayName(modelOverride.displayModel, r.provider, modelOverride.effort)
        : formatModelDisplayName(r.model, r.provider, modelOverride?.effort || r.effort || '');
      rowById.set(r.id, {
        ...r,
        deviceId: ownerDevId || selfDevId,
        deviceName: ownerDevName || selfDevName,
        remotePeer: isForeignRow,
        model: effectiveModelLabel,
        effort: modelOverride?.effort || r.effort || undefined,
        ...(recentlyStopped
          ? {
              status: 'completed',
              statusLabel: 'Stopped',
              turnComplete: false,
              dot: r.open ? 'idle' : null,
              category: 'completed',
              unread: false,
              elsewhere: false,
              reason: null,
              bgTask: null,
              bgRunningCount: 0,
              bgTasks: Array.isArray(r.bgTasks)
                ? r.bgTasks.map((t) => (t.state === 'running' ? { ...t, state: 'cancelled' } : t))
                : []
            }
          : {})
      });
    }

    // Overlay live DirectRunner CLI runs so newly launched or mid-stream sessions appear in <35ms
    if (this.directRunner) {
      for (const run of this.directRunner.getActiveRuns()) {
        const rid = run.threadId || run.id;
        if (!rid) continue;
        const existing = rowById.get(rid);
        const runOverride = this.sessionModelOverrides?.get(rid) || null;
        const runModelLabel = runOverride?.displayModel
          ? formatModelDisplayName(runOverride.displayModel, run.provider, runOverride.effort)
          : formatModelDisplayName(run.model || existing?.model, run.provider, runOverride?.effort || run.effort || '');
        if (existing) {
          rowById.set(rid, {
            ...existing,
            model: runModelLabel,
            effort: runOverride?.effort || run.effort || existing.effort || undefined,
            status: 'working',
            statusLabel: run.activeTool ? `Running ${run.activeTool}` : 'Streaming ⚡',
            dot: 'running',
            category: 'working',
            directStreaming: true,
            deviceId: selfDevId,
            deviceName: selfDevName,
            remotePeer: false,
            at: Math.max(Number(existing.at || 0), Number(run.updatedAt || nowMs)),
            lastAssistantText: run.fullText ? run.fullText.slice(-220) : existing.lastAssistantText
          });
        } else {
          rowById.set(rid, {
            id: rid,
            draftId: run.draftId || '',
            provider: run.provider,
            deviceId: selfDevId,
            deviceName: selfDevName,
            remotePeer: false,
            title: run.title || 'New Direct Session',
            cwd: run.cwd || '',
            folder: run.folder || 'Workspace',
            model: runModelLabel,
            effort: runOverride?.effort || run.effort || undefined,
            status: 'working',
            statusLabel: run.activeTool ? `Running ${run.activeTool}` : 'Streaming ⚡',
            dot: 'running',
            category: 'working',
            directStreaming: true,
            open: true,
            active: true,
            at: run.updatedAt || nowMs,
            lastAssistantText: (run.fullText || '').slice(-220)
          });
        }
      }
    }

    // Merge sessions from peer devices (Edge Relay live peer snapshots + Cloud Relay device_states)
    if (!opts.localOnly) {
      const peerSources = [];
      if (this.edgeClient) {
        const peerSnaps = this.edgeClient.getPeerSnapshots();
        for (const [pDevId, pEntry] of Object.entries(peerSnaps)) {
          if (pDevId && pDevId !== selfDevId && Array.isArray(pEntry?.snapshot?.rows)) {
            peerSources.push({
              deviceId: pDevId,
              deviceName: pEntry.deviceName || pDevId,
              rows: pEntry.snapshot.rows
            });
          }
        }
      }
      for (const [rDevId, rEntry] of Object.entries(this.remoteDeviceStates || {})) {
        const rRows = Array.isArray(rEntry?.snapshot?.rows)
          ? rEntry.snapshot.rows
          : Array.isArray(rEntry?.rows)
            ? rEntry.rows
            : null;
        if (!rDevId || rDevId === selfDevId || !rRows) continue;
        if (peerSources.some((p) => p.deviceId === rDevId)) continue;
        peerSources.push({
          deviceId: rDevId,
          deviceName: rEntry.device?.name || rDevId,
          rows: rRows
        });
      }
      for (const src of peerSources) {
        for (const pr of src.rows) {
          if (!pr || !pr.id || rowById.has(pr.id)) continue;
          // The peer listed this session as its own, so it is the owner whatever folder the session ran in.
          const prOwner = inferRowOwnerDevice(
            { ...pr, deviceId: src.deviceId, deviceName: src.deviceName },
            { id: src.deviceId, name: src.deviceName },
            { trustStamp: true }
          );
          rowById.set(pr.id, {
            ...pr,
            deviceId: prOwner.id || prOwner.deviceId || src.deviceId,
            deviceName: prOwner.name || prOwner.deviceName || src.deviceName,
            remotePeer: true,
            model: formatModelDisplayName(pr.model, pr.provider)
          });
        }
      }
    }

    const normalizedRows = Array.from(rowById.values()).sort(
      (a, b) => Number(b.at || 0) - Number(a.at || 0)
    );

    const topSessions = (this.hub?.snapshot?.usage?.topThreads || []).slice(0, 12);

    let fallbackHide3p = Boolean(basePayload.hideThirdPartyQuota);
    let fallbackHide3pAt = Number(basePayload.hideThirdPartyQuotaUpdatedAt || 0);
    if (typeof basePayload.hideThirdPartyQuota !== 'boolean') {
      try {
        const diskPath = this.hubStateBackupPath || path.join(os.homedir(), '.claude', '.theo-hub-state.json');
        if (fs.existsSync(diskPath)) {
          const diskRaw = JSON.parse(fs.readFileSync(diskPath, 'utf8'));
          if (typeof diskRaw?.preferences?.hideThirdPartyQuota === 'boolean') {
            fallbackHide3p = diskRaw.preferences.hideThirdPartyQuota;
            fallbackHide3pAt = Number(
              diskRaw.preferences.hideThirdPartyQuotaUpdatedAt || diskRaw.updatedAt || 0
            );
          }
        }
      } catch {}
    }

    const fullState = {
      ...basePayload,
      hideThirdPartyQuota: fallbackHide3p,
      hideThirdPartyQuotaUpdatedAt: fallbackHide3pAt,
      device: {
        id: selfDevId,
        name: selfDevName,
        role: this.deviceInfo?.role || HOST_ROLE,
        hostname: os.hostname(),
        homedir: os.homedir(),
        capabilities: this.deviceInfo?.capabilities || [],
        pcSetup: readCachedPcSetupSummary() || null,
        unsavedWork: readFleetUnsavedWorkSummary()
      },
      rows: normalizedRows,
      devices: this.getUnifiedFleetDevices(),
      activeDirectRuns: this.directRunner ? this.directRunner.getActiveRuns() : [],
      generatedAt: Date.now(),
      connection: this.getStatus(),
      approvals,
      workspaces,
      unsavedWork: readUnsavedWorkSummary(),
      topSessions,
      personalLedger: this.personalLedger,
      lastNotification: this.lastNotification || null,
      recentNotifications: (this.recentNotifications || []).slice(0, 15),
      claudePermissionMode: this.getClaudePermissionModeSnapshot()
    };
    if (this.hub && baseRows.length > 0 && this.lastStateCachePath && !opts.localOnly) {
      try {
        const dir = path.dirname(this.lastStateCachePath);
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(this.lastStateCachePath, JSON.stringify(fullState), 'utf8');
      } catch {}
    }
    return fullState;
  }

  async getThreadDetail(threadId, providerHint = '', options = {}) {
    const cleanId = String(threadId || '').trim();
    if (!cleanId) {
      return { error: 'Missing thread id' };
    }
    const thread = (this.hub?.snapshot?.threads || []).find((t) => t.id === cleanId);
    const provider =
      providerHint ||
      thread?.provider ||
      (this.store?.claudeFileById?.has(cleanId) ? 'claude' : 'antigravity');

    const logPath = this.store ? this.store.getTranscriptLogPath(cleanId, provider) : '';
    const liveOverlay = this.directRunner ? this.directRunner.getLiveThreadOverlay(cleanId) : null;
    const cliDbParsed =
      !logPath && provider === 'antigravity' && this.store?.readCliConversationDbDetail
        ? this.store.readCliConversationDbDetail(cleanId, 80)
        : null;
    if (
      !logPath &&
      !liveOverlay &&
      (!cliDbParsed || !Array.isArray(cliDbParsed.messages) || cliDbParsed.messages.length === 0) &&
      this.cachedRemoteThreads &&
      this.cachedRemoteThreads[cleanId]
    ) {
      return this.cachedRemoteThreads[cleanId];
    }
    if (!this.threadDetailCache) {
      this.threadDetailCache = new Map();
    }
    const cacheKey = `${cleanId}:${provider}`;
    let fileMtime = 0;
    let fileSize = 0;
    if (logPath) {
      try {
        const st = fs.statSync(logPath);
        fileMtime = Math.floor(st.mtimeMs || 0);
        fileSize = Number(st.size || 0);
      } catch {}
    }
    const cachedEntry = this.threadDetailCache.get(cacheKey);
    const transcriptUnchanged =
      Boolean(cachedEntry?.parsed) &&
      fileMtime > 0 &&
      cachedEntry.mtimeMs === fileMtime &&
      cachedEntry.size === fileSize;

    const parsed = cliDbParsed
      ? cliDbParsed
      : transcriptUnchanged
        ? cachedEntry.parsed
        : provider === 'claude'
          ? parseClaudeTranscriptFile(logPath, 80)
          : parseAntigravityTranscriptFile(logPath, 80);

    let effectiveMessages = Array.isArray(parsed?.messages) ? parsed.messages : [];
    if (provider === 'claude' && effectiveMessages.length > 0) {
      const lastMsg = effectiveMessages[effectiveMessages.length - 1];
      if (lastMsg && lastMsg.role === 'assistant' && (!Array.isArray(lastMsg.questions) || lastMsg.questions.length === 0)) {
        const liveSnap = this.claudeBridge?.getLiveSnapshot?.() || this.hub?.snapshot?.claudeLive || {};
        const livePerm = (liveSnap.pendingPermissions || []).find((p) => p && p.sessionId === cleanId);
        const liveSt = (liveSnap.sessionStates || []).find((s) => s && s.sessionId === cleanId);
        const isWaiting =
          Boolean(livePerm) ||
          liveSt?.state === 'waiting_input' ||
          liveSt?.state === 'waiting' ||
          Boolean(liveSt?.hasOutstandingRequest) ||
          thread?.status === 'WAITING_FOR_USER' ||
          Boolean(thread?.pendingQuestion);
        if (isWaiting) {
          let attachedQuestions = null;
          if (Array.isArray(thread?.pendingQuestion?.questions) && thread.pendingQuestion.questions.length > 0) {
            attachedQuestions = thread.pendingQuestion.questions;
          } else {
            const sourceTool = livePerm
              ? {
                  stepIndex: parsed.stats?.steps || 0,
                  toolUseId: livePerm.toolUseId || parsed.lastPendingToolUse?.toolUseId || '',
                  toolName: livePerm.toolName || parsed.lastPendingToolUse?.toolName || 'Tool',
                  inputs:
                    livePerm.inputs && Object.keys(livePerm.inputs).length > 0
                      ? livePerm.inputs
                      : parsed.lastPendingToolUse?.inputs || {}
                }
              : parsed.lastPendingToolUse;
            if (sourceTool) {
              const builtQ = buildClaudeToolPermissionQuestion(
                sourceTool,
                livePerm?.suggestions || []
              );
              if (Array.isArray(builtQ?.questions) && builtQ.questions.length > 0) {
                attachedQuestions = builtQ.questions;
              }
            }
          }
          if (attachedQuestions) {
            effectiveMessages = [
              ...effectiveMessages.slice(0, -1),
              { ...lastMsg, questions: attachedQuestions }
            ];
          }
        }
      }
    }

    let contextWindow = null;
    if (
      transcriptUnchanged &&
      cachedEntry?.contextWindow &&
      (options.skipLiveContext || Date.now() - (cachedEntry.ctxAt || 0) < 30000)
    ) {
      contextWindow = cachedEntry.contextWindow;
    } else if (provider === 'antigravity' && !options.skipLiveContext) {
      try {
        let liveCtx = await this.fetchGeneratorMetadataDirect(cleanId);
        if ((!liveCtx || !liveCtx.usedTokens) && this.vscode?.commands) {
          liveCtx = await withTimeout(
            this.vscode.commands.executeCommand('antigravityHub.getContextStatus', {
              id: cleanId
            }),
            1200,
            null
          );
        }
        if (liveCtx && liveCtx.usedTokens) {
          const usedTokens = Number(liveCtx.usedTokens || 0);
          const rawModel = liveCtx.modelLabel || liveCtx.modelName || thread?.model || parsed?.model || 'Gemini';
          const modelLabel = formatModelDisplayName(rawModel, 'antigravity');
          const limitTokens = Number(
            liveCtx.limitTokens || liveCtx.maxContextTokens || inferMaxContextTokens('antigravity', modelLabel)
          );
          const pct =
            typeof liveCtx.pct === 'number'
              ? liveCtx.pct
              : Math.min(100, Math.max(1, Math.round((usedTokens / limitTokens) * 100)));
          let breakdown = [];
          if (Array.isArray(liveCtx.breakdown)) {
            breakdown = liveCtx.breakdown;
          } else if (liveCtx.breakdown && typeof liveCtx.breakdown === 'object') {
            const bd = liveCtx.breakdown;
            const rawItems = [
              { key: 'system', label: 'System Prompt & Rules', tokens: Number(bd.systemPromptTokens || 0), color: '#D9A54A' },
              { key: 'tools', label: 'Tool Definitions', tokens: Number(bd.toolsTokens || 0), color: '#06B6D4' },
              { key: 'toolResults', label: 'Tool I/O & Files', tokens: Number(bd.toolResultsTokens || 0), color: '#10B981' },
              { key: 'assistant', label: 'Model Responses', tokens: Number(bd.assistantTokens || 0), color: '#4F8FD6' },
              { key: 'user', label: 'User & Checkpoints', tokens: Number(bd.userTokens || 0) + Number(bd.checkpointTokens || 0), color: '#3186FF' }
            ].filter((x) => x.tokens > 0);
            const rawSum = rawItems.reduce((acc, item) => acc + item.tokens, 0);
            const scale = rawSum > 0 && usedTokens > 0 ? usedTokens / rawSum : 1;
            breakdown = rawItems.map((item) => ({
              ...item,
              tokens: Math.round(item.tokens * scale)
            }));
          }
          contextWindow = {
            provider: 'antigravity',
            modelLabel,
            usedTokens,
            limitTokens,
            remainingTokens: Math.max(0, limitTokens - usedTokens),
            pct,
            breakdown: breakdown.length
              ? breakdown
              : buildEstimatedContextStatus(parsed, provider, modelLabel).breakdown
          };
        }
      } catch {}
    }
    if (!contextWindow) {
      contextWindow =
        cachedEntry?.contextWindow ||
        buildEstimatedContextStatus(
          parsed,
          provider,
          thread?.model || parsed?.model
        );
    }

    if (fileMtime > 0) {
      this.threadDetailCache.set(cacheKey, {
        mtimeMs: fileMtime,
        size: fileSize,
        parsed,
        contextWindow,
        ctxAt: Date.now()
      });
      if (this.threadDetailCache.size > 60) {
        const firstKey = this.threadDetailCache.keys().next().value;
        if (firstKey) this.threadDetailCache.delete(firstKey);
      }
    }

    const modelOverride = this.sessionModelOverrides?.get(cleanId) || null;
    const displayModel = formatModelDisplayName(
      modelOverride?.displayModel ||
        modelOverride?.model ||
        contextWindow?.modelLabel ||
        thread?.model ||
        parsed?.model,
      provider,
      modelOverride?.effort || ''
    );
    if (contextWindow && typeof contextWindow === 'object') {
      contextWindow = { ...contextWindow, modelLabel: displayModel };
    }

    let rawBgList = Array.isArray(thread?.backgroundTasks) ? thread.backgroundTasks : null;
    if (!rawBgList && this.store && logPath) {
      try {
        const storeParsed =
          provider === 'claude'
            ? this.store.parseClaudeSessionFile(logPath, cleanId)
            : this.store.parseTranscriptFile(logPath);
        if (Array.isArray(storeParsed?.backgroundTasks)) {
          rawBgList = storeParsed.backgroundTasks;
        }
      } catch {}
    }
    const backgroundTasks = Array.isArray(rawBgList)
      ? rawBgList.slice(-12).map((t) => {
          const previewChars = t.state === 'running' ? 1400 : 700;
          const liveOut =
            !options.skipBgLogs && this.store?.readBackgroundTaskOutput
              ? this.store.readBackgroundTaskOutput(cleanId, provider, t, previewChars)
              : t.outputPreview || '';
          return {
            id: t.id,
            fullId: t.fullId || t.id,
            subagentConversationId: t.subagentConversationId || '',
            kind: t.kind || 'task',
            subagentType: t.subagentType || '',
            summary: t.summary || t.id,
            command: String(t.command || '').slice(0, 420),
            state: t.state || 'completed',
            isDaemon: Boolean(t.isDaemon),
            startedAt:
              Number(t.startedAt || 0) > 0 && Number(t.startedAt || 0) < 1e12
                ? Number(t.startedAt) * 1000
                : Number(t.startedAt || 0),
            completedAt:
              Number(t.completedAt || 0) > 0 && Number(t.completedAt || 0) < 1e12
                ? Number(t.completedAt) * 1000
                : Number(t.completedAt || 0),
            stepIndex: typeof t.stepIndex === 'number' ? t.stepIndex : -1,
            outputPreview: String(liveOut || '').slice(-previewChars)
          };
        })
      : [];

    if (liveOverlay && liveOverlay.prompt) {
      const hasUserTurn = effectiveMessages.some(
        (m) => m.role === 'user' && String(m.text || '').trim() === String(liveOverlay.prompt).trim()
      );
      if (!hasUserTurn) {
        effectiveMessages = [
          ...effectiveMessages,
          {
            role: 'user',
            text: liveOverlay.prompt,
            at: Math.floor((liveOverlay.startedAt || Date.now()) / 1000)
          }
        ];
      }
      if (liveOverlay.fullText || liveOverlay.fullThinking || liveOverlay.status === 'working') {
        const lastMsg = effectiveMessages[effectiveMessages.length - 1];
        if (!lastMsg || lastMsg.role !== 'assistant' || liveOverlay.status === 'working') {
          if (lastMsg && lastMsg.role === 'assistant' && liveOverlay.status === 'working') {
            effectiveMessages = [
              ...effectiveMessages.slice(0, -1),
              {
                ...lastMsg,
                text: liveOverlay.fullText || lastMsg.text || '',
                thinking: liveOverlay.fullThinking || lastMsg.thinking || '',
                isStreaming: true,
                activeTool: liveOverlay.activeTool || ''
              }
            ];
          } else {
            effectiveMessages = [
              ...effectiveMessages,
              {
                role: 'assistant',
                text: liveOverlay.fullText || '',
                thinking: liveOverlay.fullThinking || '',
                isStreaming: liveOverlay.status === 'working',
                activeTool: liveOverlay.activeTool || '',
                toolCalls: (liveOverlay.toolSteps || []).map((ts) => ({
                  name: ts.name,
                  kind: 'tool',
                  label: ts.name,
                  summary: ts.state || ''
                })),
                at: Math.floor((liveOverlay.updatedAt || Date.now()) / 1000)
              }
            ];
          }
        }
      }
    }

    const isThreadWorking = Boolean(
      thread?.status === 'CASCADE_RUN_STATUS_RUNNING' ||
        thread?.status === 'working' ||
        thread?.notFullyIdle ||
        liveOverlay?.status === 'working'
    );
    let liveCascadeTail = null;
    if (provider === 'antigravity' && isThreadWorking) {
      liveCascadeTail = await this.fetchLiveCascadeTailOverlay(
        cleanId,
        Number(parsed?.stats?.steps || thread?.stepCount || 0)
      );
      if (liveCascadeTail) {
        const lastMsg = effectiveMessages[effectiveMessages.length - 1];
        if (lastMsg && lastMsg.role === 'assistant') {
          const existingTools = Array.isArray(lastMsg.toolCalls) ? [...lastMsg.toolCalls] : [];
          for (const extraTc of liveCascadeTail.toolCalls || []) {
            const dup = existingTools.some(
              (t) =>
                (extraTc.id && t.id === extraTc.id) ||
                (t.kind === extraTc.kind &&
                  t.file === extraTc.file &&
                  t.summary === extraTc.summary)
            );
            if (!dup) existingTools.push(extraTc);
          }
          let mergedThinking = lastMsg.thinking || '';
          let mergedThoughtBlocks = Array.isArray(lastMsg.thoughtBlocks)
            ? [...lastMsg.thoughtBlocks]
            : [];
          if (
            liveCascadeTail.thinking &&
            !String(mergedThinking).includes(liveCascadeTail.thinking.slice(0, 80))
          ) {
            mergedThinking = [mergedThinking, liveCascadeTail.thinking].filter(Boolean).join('\n\n');
            mergedThoughtBlocks.push({
              id: `live-th-${Date.now()}`,
              text: liveCascadeTail.thinking.slice(0, 2400),
              durationSec: 2,
              createdAt: new Date().toISOString()
            });
          }
          effectiveMessages = [
            ...effectiveMessages.slice(0, -1),
            {
              ...lastMsg,
              text: liveCascadeTail.text || lastMsg.text || '',
              thinking: mergedThinking,
              latestThinking: liveCascadeTail.thinking || lastMsg.latestThinking || mergedThinking.slice(-1400),
              thoughtBlocks: mergedThoughtBlocks,
              totalThoughtCount: Math.max(
                Number(lastMsg.totalThoughtCount || 0),
                mergedThoughtBlocks.length
              ),
              toolCalls: existingTools.slice(-32),
              totalTurnTools: Math.max(
                Number(lastMsg.totalTurnTools || 0),
                existingTools.length
              )
            }
          ];
        } else if (
          liveCascadeTail.thinking ||
          liveCascadeTail.text ||
          (liveCascadeTail.toolCalls || []).length > 0
        ) {
          effectiveMessages = [
            ...effectiveMessages,
            {
              id: `live-agy-${Date.now()}`,
              role: 'assistant',
              createdAt: new Date().toISOString(),
              startedAt: new Date().toISOString(),
              status: 'RUNNING',
              text: liveCascadeTail.text || '',
              thinking: liveCascadeTail.thinking || '',
              latestThinking: liveCascadeTail.thinking || '',
              thinkingDurationSec: liveCascadeTail.thinking ? 2 : 0,
              totalThoughtCount: liveCascadeTail.thinking ? 1 : 0,
              thoughtBlocks: liveCascadeTail.thinking
                ? [
                    {
                      id: `live-th-0`,
                      text: liveCascadeTail.thinking.slice(0, 2400),
                      durationSec: 2,
                      createdAt: new Date().toISOString()
                    }
                  ]
                : [],
              toolCalls: (liveCascadeTail.toolCalls || []).slice(-32),
              totalTurnTools: (liveCascadeTail.toolCalls || []).length
            }
          ];
        }
      }
    }

    const liveActivity = this.deriveLiveActivityDescriptor(
      effectiveMessages,
      isThreadWorking,
      liveCascadeTail
    );

    const detailPayload = {
      id: cleanId,
      provider,
      deviceId: this.deviceInfo?.id || 'workstation',
      deviceName: this.deviceInfo?.name || os.hostname(),
      title: thread?.title || liveOverlay?.title || 'Session',
      cwd: thread?.cwd || liveOverlay?.cwd || '',
      folder: thread?.workspaceLabel || liveOverlay?.folder || '',
      branch: thread?.branch || '',
      model: displayModel,
      status: isThreadWorking ? 'working' : thread?.status || 'idle',
      liveActivity,
      updatedAt:
        liveCascadeTail?.updatedAt ||
        liveOverlay?.updatedAt ||
        (thread?.updatedAt || Math.floor(Date.now() / 1000)) * 1000,
      messages: effectiveMessages,
      stats: parsed.stats,
      contextWindow,
      backgroundTasks
    };
    const hasWsClients = Boolean(this.wsHub && this.wsHub.clients.size > 0);
    const hasEdgeConn = Boolean(this.edgeClient?.getStatus()?.connected);
    if (hasWsClients || hasEdgeConn) {
      if (!this.edgePushedThreadStampById) this.edgePushedThreadStampById = new Map();
      const lastM = effectiveMessages[effectiveMessages.length - 1] || {};
      const stampKey = [
        detailPayload.updatedAt,
        effectiveMessages.length,
        displayModel,
        Number(lastM.totalTurnTools || (lastM.toolCalls || []).length || 0),
        Number(lastM.totalThoughtCount || (lastM.thoughtBlocks || []).length || 0),
        String(lastM.thinking || '').length,
        String(lastM.text || '').length,
        liveActivity?.active ? `${liveActivity.verb}:${liveActivity.target}` : 'idle'
      ].join(':');
      if (this.edgePushedThreadStampById.get(cleanId) !== stampKey) {
        this.edgePushedThreadStampById.set(cleanId, stampKey);
        if (this.edgePushedThreadStampById.size > 60) {
          const fk = this.edgePushedThreadStampById.keys().next().value;
          if (fk) this.edgePushedThreadStampById.delete(fk);
        }
        const detailFrame = {
          type: 'thread_detail',
          id: cleanId,
          threadId: cleanId,
          deviceId: detailPayload.deviceId,
          thread: { ok: true, id: cleanId, thread: detailPayload }
        };
        if (hasWsClients) {
          this.wsHub.broadcast(detailFrame);
        }
        if (hasEdgeConn) {
          this.edgeClient.sendJson(detailFrame);
        }
      }
    }
    return detailPayload;
  }

  async interruptSession(targetId, rawProvider = '') {
    const cleanId = String(targetId || '').trim();
    if (!cleanId) {
      return { ok: false, error: 'Missing session ID' };
    }
    if (this.directRunner) {
      this.directRunner.stopRun(cleanId);
    }
    const thread = (this.hub?.snapshot?.threads || []).find((t) => t.id === cleanId);
    const provider =
      rawProvider === 'claude' ||
      thread?.provider === 'claude' ||
      this.store?.claudeFileById?.has?.(cleanId)
        ? 'claude'
        : 'antigravity';

    if (!this.userStoppedSessionsById) {
      this.userStoppedSessionsById = new Map();
    }
    this.userStoppedSessionsById.set(cleanId, { at: Date.now(), provider });
    try {
      this.hub?.activity?.liveByThreadId?.delete?.(cleanId);
      if (thread) {
        thread.userCancelled = true;
        thread.status = 'CASCADE_RUN_STATUS_IDLE';
        thread.notFullyIdle = false;
        thread.bgTask = null;
      }
      await this.stateStore?.setUnread?.(
        cleanId,
        false,
        Math.max(Math.floor(Date.now() / 1000), Number(thread?.updatedAt) || 0)
      );
      this.hub?.syncOpenTabBadges?.();
      this.hub?.render?.();
    } catch {}

    let result = null;
    if (provider === 'claude') {
      if (this.vscode?.commands) {
        result = await this.vscode.commands
          .executeCommand('antigravityHub.claudeInterrupt', { id: cleanId })
          .catch(() => null);
      }
    } else {
      try {
        this.store?.markCascadeUserCancelled?.(cleanId, true);
      } catch {}
      try {
        const homeDir = path.join(os.homedir(), '.gemini', 'antigravity');
        const filePath = path.join(homeDir, 'bhf-resumed-cascades.json');
        const map = fs.existsSync(filePath)
          ? JSON.parse(fs.readFileSync(filePath, 'utf8'))
          : {};
        map[cleanId] = {
          stepIndex: 999999,
          reason: 'user_cancelled',
          resumedAt: Math.floor(Date.now() / 1000)
        };
        fs.writeFileSync(filePath, JSON.stringify(map, null, 2), 'utf8');
      } catch {}

      const rpcCalls = [
        this.callHubLanguageServerRpc(
          'CancelCascadeInvocation',
          { cascadeId: cleanId, killBackgroundTasks: true },
          2500
        ).catch(() => null),
        this.callHubLanguageServerRpc(
          'ForceStopCascadeTree',
          { conversationId: cleanId },
          2500
        ).catch(() => null)
      ];
      if (this.store?.cancelSessionOnServer) {
        rpcCalls.push(
          this.store.cancelSessionOnServer(cleanId, 'antigravity').catch(() => null)
        );
      }
      if (this.vscode?.commands) {
        rpcCalls.push(
          this.vscode.commands
            .executeCommand('antigravityHub.remoteAction', {
              id: cleanId,
              kind: 'cancel'
            })
            .catch(() => null)
        );
      }
      result = await Promise.allSettled(rpcCalls);
    }

    if (this.hub) {
      setTimeout(() => this.hub.refresh().catch(() => {}), 250);
    }
    this.notifyStateUpdated();
    return { ok: true, id: cleanId, provider, subAction: 'interrupt', result };
  }

  async enqueueCommandToCloudDevice(targetDeviceId, cmd = {}) {
    if (!this.relayConfig?.url || !this.relayConfig?.key) {
      return { ok: false, error: 'Cloud Relay not configured' };
    }
    const ctrl = await httpsJsonRequest(this.relayConfig.url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify({ key: this.relayConfig.key, op: 'get_control' }),
      timeoutMs: 8000
    });
    const docs = ctrl?.docs && typeof ctrl.docs === 'object' ? ctrl.docs : ctrl || {};
    const queue = docs?.queue || {};
    const commands = Array.isArray(queue.commands) ? queue.commands.slice(-15) : [];
    const cmdId = cmd.id && String(cmd.id).startsWith('cmd-') ? cmd.id : `cmd-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`;
    const queued = {
      ...cmd,
      id: cmdId,
      targetDeviceId,
      status: 'pending',
      createdAt: Date.now()
    };
    commands.push(queued);
    await httpsJsonRequest(this.relayConfig.url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify({
        key: this.relayConfig.key,
        op: 'patch',
        ackOnly: true,
        patch: {
          queue: {
            ...queue,
            commands
          }
        }
      }),
      timeoutMs: 8000
    });
    return {
      ok: true,
      queued: true,
      cmdId,
      targetDeviceId,
      message: `Dispatched to ${targetDeviceId} via Cloud Relay`
    };
  }

  isCliOwnedSession(sessionId) {
    const clean = String(sessionId || '').trim();
    if (!clean) return false;
    if (this.directRunner?.hasActiveRun(clean)) return true;
    try {
      const cliDir = path.join(os.homedir(), '.gemini', 'antigravity-cli', 'conversations');
      if (
        fs.existsSync(path.join(cliDir, `${clean}.pb`)) ||
        fs.existsSync(path.join(cliDir, `${clean}.db`))
      ) {
        return true;
      }
    } catch {}
    return false;
  }

  async assignGroupToSession(sessionId, groupId) {
    const sid = String(sessionId || '').trim();
    const gid = String(groupId || '').trim();
    if (!sid || !gid) return;
    if (this.stateStore && typeof this.stateStore.assignThreadGroup === 'function') {
      try {
        await this.stateStore.assignThreadGroup(sid, gid);
        return;
      } catch {}
    }
    try {
      const hubStatePath = path.join(os.homedir(), '.claude', '.theo-hub-state.json');
      const st = fs.existsSync(hubStatePath)
        ? JSON.parse(fs.readFileSync(hubStatePath, 'utf8'))
        : {};
      if (!st.threadGroups || typeof st.threadGroups !== 'object') st.threadGroups = {};
      if (!st.unassignedGroupThreads || typeof st.unassignedGroupThreads !== 'object') {
        st.unassignedGroupThreads = {};
      }
      st.threadGroups[sid] = gid;
      delete st.unassignedGroupThreads[sid];
      st.updatedAt = Date.now();
      fs.mkdirSync(path.dirname(hubStatePath), { recursive: true });
      fs.writeFileSync(hubStatePath, JSON.stringify(st, null, 2), 'utf8');
    } catch {}
  }

  // Where this host keeps the sessions the other hosts published (read by store.js and state.js).
  peerCachePath() {
    return this.peerCachePathOverride || path.join(os.homedir(), '.claude', '.theo-cloud-sessions-cache.json');
  }

  // A phone command that arrived directly (WebSocket or the local HTTP bridge). When a direct reply is slow the
  // phone also puts the command in the store queue, and may send it again over another direct path, so the same
  // command can arrive more than once. It is run once:
  //   - its id is noted here, and a second arrival of a noted id answers `duplicate` without running;
  //   - when it names no PC it is claimed in the store first, so the host that got the queued copy and this host
  //     cannot both run it;
  //   - once it has run, the queued copy is marked done on the next sync cycle (see syncCloudRelay);
  //   - a command that fails is un-noted, so another path or the queued copy can still run it.
  async executeDirectCommand(cmd = {}) {
    const cmdId = typeof cmd?.cmdId === 'string' && /^cmd-[\w.-]{1,120}$/.test(cmd.cmdId) ? cmd.cmdId : '';
    if (!cmdId) {
      return this.executeRemoteCommand(cmd);
    }
    const cmdKey = `${cmdId}:${cmd.createdAt || 0}`;
    const selfDevId = this.deviceInfo?.id || 'workstation';
    const targetDev = String(cmd.targetDeviceId || '').trim();
    const untargeted = !targetDev || targetDev === 'auto';
    // A repeat that arrives while the first is still running gets that run's own result (so a failure is not
    // reported as success); one that arrives after it finished gets the finished result back.
    if (!this.directInFlight) this.directInFlight = new Map();
    if (this.directInFlight.has(cmdKey)) {
      return this.directInFlight.get(cmdKey);
    }
    const finished = this.directDoneCmdKeys?.get(cmdKey);
    if (finished) {
      return { ...(finished.out && typeof finished.out === 'object' ? finished.out : { ok: true }), duplicate: true };
    }
    if (
      this.processedCmdIds.has(cmdKey) ||
      !beginCloudCommandLease(cmdKey, this.claimInflightLeaseMs || CLAIM_INFLIGHT_LEASE_MS)
    ) {
      return { ok: true, duplicate: true };
    }
    this.processedCmdIds.add(cmdKey);
    const run = this.runNotedDirectCommand(cmd, cmdKey, selfDevId, untargeted);
    this.directInFlight.set(cmdKey, run);
    run.then(
      () => this.directInFlight.delete(cmdKey),
      () => this.directInFlight.delete(cmdKey)
    );
    return run;
  }

  async runNotedDirectCommand(cmd, cmdKey, selfDevId, untargeted) {
    let storeClaimHeld = false;
    if (untargeted && this.storeHasEqualHosts && this.relayConfig?.url && this.relayConfig?.key) {
      const claimRes = await this.claimCommandInStore(cmdKey, selfDevId);
      if (claimRes && claimRes.claimed === false) {
        if (claimRes.leaseUntil > 0) {
          // Another host is mid-run on the queued copy: leave local state unsealed in case that host crashes mid-run.
          this.processedCmdIds.delete(cmdKey);
          unclaimCloudCommand(cmdKey);
          return { ok: true, duplicate: true, claimedElsewhere: true, leaseUntil: claimRes.leaseUntil };
        }
        // Permanently sealed by another host.
        completeCloudCommandOnce(cmdKey);
        return { ok: true, duplicate: true, claimedElsewhere: true };
      }
      // null: the store could not be asked. A direct command still runs, as it did before.
      storeClaimHeld = Boolean(claimRes && claimRes.claimed === true);
    }
    const forget = () => {
      this.processedCmdIds.delete(cmdKey);
      unclaimCloudCommand(cmdKey);
      if (storeClaimHeld) {
        this.releaseCommandInStore(cmdKey, selfDevId).catch(() => {});
      }
    };
    try {
      const out = await this.executeRemoteCommand(cmd);
      if (out && out.ok === false) {
        forget();
      } else {
        completeCloudCommandOnce(cmdKey);
        if (storeClaimHeld) {
          if (!this.pendingSealClaims) this.pendingSealClaims = new Set();
          this.pendingSealClaims.add(this.storeClaimKey(cmdKey));
        }
        if (!this.directDoneCmdKeys) this.directDoneCmdKeys = new Map();
        this.directDoneCmdKeys.set(cmdKey, { at: Date.now(), out });
        if (this.directDoneCmdKeys.size > 400) {
          this.directDoneCmdKeys.delete(this.directDoneCmdKeys.keys().next().value);
        }
      }
      return out;
    } catch (err) {
      forget();
      throw err;
    }
  }

  async executeRemoteCommand(cmd = {}) {
    const type = String(cmd.type || cmd.action || '').trim();
    const cleanTargetCandidate = (val) => {
      const s = String(val || '').trim();
      if (!s || s === '__new__' || s.startsWith('cmd-') || s.startsWith('draft-new-') || s.startsWith('draft-direct-')) {
        return '';
      }
      return s;
    };
    const targetId = cleanTargetCandidate(cmd.threadId) || cleanTargetCandidate(cmd.id);
    const targetDeviceId = String(cmd.targetDeviceId || '').trim();
    const selfDeviceId = this.deviceInfo?.id || 'workstation';

    if (targetDeviceId && targetDeviceId !== 'auto' && targetDeviceId !== selfDeviceId) {
      if (cmd._fromCloudQueue) {
        return { ok: false, deferCommand: true, wrongDevice: true, targetDeviceId };
      }
      if (this.edgeClient?.getStatus()?.connected) {
        const peerRes = await this.edgeClient.forwardRpcToDevice(targetDeviceId, cmd, 15000);
        if (peerRes && peerRes.ok !== false) {
          return peerRes;
        }
      }
      return this.enqueueCommandToCloudDevice(targetDeviceId, cmd);
    }

    if (
      type === 'setClaudePermissionMode' ||
      (type === 'sessionAction' &&
        String(cmd.subAction || cmd.action || '').trim() === 'setClaudePermissionMode')
    ) {
      if (cmd._fromCloudQueue && Number(cmd.createdAt || 0) > 0) {
        const localCache = readLocalClaudePermissionCache();
        if (localCache && Number(localCache.updatedAt || 0) > Number(cmd.createdAt) + 1000) {
          return {
            ok: true,
            skipped: 'superseded_by_newer_mode',
            claudePermissionMode: this.getClaudePermissionModeSnapshot()
          };
        }
      }
      return this.setFleetClaudePermissionMode(cmd.defaultMode || cmd.mode || cmd.value, {
        source: cmd.source || 'theo-remote',
        updatedBy: cmd.updatedBy || 'THEO Remote'
      });
    }

    if (type === 'interrupt' || type === 'stop' || type === 'cancel') {
      return this.interruptSession(targetId, cmd.provider);
    }

    if (type === 'cancelBgTask' || type === 'cancelAllBgTasks') {
      return this.executeRemoteCommand({
        ...cmd,
        type: 'sessionAction',
        subAction: type
      });
    }

    if (type === 'requestThread') {
      const id = targetId;
      const provider = cmd.provider === 'claude' ? 'claude' : 'antigravity';
      if (id) {
        if (!this.requestedThreads) {
          this.requestedThreads = new Map();
        }
        this.requestedThreads.set(id, { provider, requestedAt: Date.now() });
      }
      return { ok: true, id, provider };
    }

    if (type === 'send' || type === 'sendPrompt') {
      const provider = cmd.provider === 'claude' ? 'claude' : 'antigravity';
      let prompt = String(cmd.prompt || cmd.text || '').trim();
      const newSession = Boolean(cmd.newSession || !targetId);
      const id = newSession ? '' : targetId;
      const attachments = Array.isArray(cmd.attachments) ? cmd.attachments : [];
      if (attachments.length > 0) {
        try {
          let baseUploadDir = path.join(os.homedir(), '.claude', 'theo-uploads');
          const resolvedCwdCandidate = String(cmd.cwd || '').trim();
          if (resolvedCwdCandidate && fs.existsSync(resolvedCwdCandidate)) {
            baseUploadDir = path.join(resolvedCwdCandidate, '.theo-uploads');
          } else if (cmd.workspace || cmd.repoPrefix) {
            const wsKey = String(cmd.workspace || cmd.repoPrefix || '').trim();
            const wsCandidate = path.join(os.homedir(), 'bhfirms', wsKey);
            if (wsKey && fs.existsSync(wsCandidate)) {
              baseUploadDir = path.join(wsCandidate, '.theo-uploads');
            }
          }
          fs.mkdirSync(baseUploadDir, { recursive: true });
          const savedLines = [];
          for (let attIdx = 0; attIdx < attachments.length; attIdx++) {
            const att = attachments[attIdx];
            if (!att) continue;
            let resolvedDataUrl = String(att.dataUrl || '');
            let resolvedText = typeof att.textContent === 'string' ? att.textContent : '';
            if (att.uploadId && this.attachmentUploadChunks.has(att.uploadId)) {
              const upEntry = this.attachmentUploadChunks.get(att.uploadId);
              this.attachmentUploadChunks.delete(att.uploadId);
              if (upEntry && upEntry.receivedCount >= upEntry.totalChunks) {
                const joined = upEntry.chunks.join('');
                if (joined.startsWith('data:')) {
                  resolvedDataUrl = joined;
                } else {
                  resolvedDataUrl = `data:${upEntry.mime || 'application/octet-stream'};base64,${joined}`;
                }
              }
            }
            const rawName = String(att.name || 'attachment').replace(/[^a-zA-Z0-9._-]/g, '_');
            const uniqSuffix = `${Date.now()}-${attIdx}-${crypto.randomBytes(3).toString('hex')}`;
            const outPath = path.join(baseUploadDir, `${uniqSuffix}-${rawName}`);
            const b64Idx = resolvedDataUrl.indexOf(';base64,');
            if (b64Idx !== -1) {
              const b64 = resolvedDataUrl.slice(b64Idx + 8);
              fs.writeFileSync(outPath, Buffer.from(b64, 'base64'));
              savedLines.push(`- ${att.name || rawName}: \`${outPath}\``);
            } else if (resolvedText) {
              fs.writeFileSync(outPath, resolvedText, 'utf8');
              savedLines.push(`- ${att.name || rawName}: \`${outPath}\``);
            }
            if (resolvedText && resolvedText.length <= 12000) {
              savedLines.push(`\`\`\`\n${resolvedText}\n\`\`\``);
            }
          }
          if (savedLines.length > 0) {
            prompt = `${prompt ? prompt + '\n\n' : ''}[Attached Files saved on workstation]:\n${savedLines.join('\n')}`.trim();
          }
        } catch {}
      }
      if (!prompt) {
        return { ok: false, error: 'Prompt is empty' };
      }
      if (id) {
        if (!this.requestedThreads) {
          this.requestedThreads = new Map();
        }
        this.requestedThreads.set(id, { provider, requestedAt: Date.now() });
        if (this.userStoppedSessionsById) {
          this.userStoppedSessionsById.delete(id);
        }
        if (provider === 'antigravity') {
          try {
            this.store?.markCascadeUserCancelled?.(id, false);
          } catch {}
        }
      }
      let res = null;
      if (provider === 'antigravity' && id && !newSession && this.store?.answerAntigravityQuestion) {
        const hubPayload = this.getHubLastPayload();
        const row = (hubPayload?.rows || []).find((r) => r && r.id === id);
        if (row?.pendingQuestion) {
          const ansOut = await this.store
            .answerAntigravityQuestion(id, {
              writeInResponse: prompt,
              selectedTexts: [prompt]
            })
            .catch(() => null);
          if (ansOut?.ok) {
            if (this.hub) {
              setTimeout(() => this.hub.refresh().catch(() => {}), 400);
            }
            return { ok: true, provider, id, deviceId: selfDeviceId, result: ansOut };
          }
        }
      }

      // Smart Hybrid Routing (#1):
      // When replying to an existing Antigravity IDE session while IDE UI bridge is attached,
      // route via 'ide' so full multi-turn brain/context history stays unified unless forceDirect is requested.
      // When VS Code UI is closed (!this.vscode), try sending directly to the persistent agy.exe --hub
      // server (bhf-persistent-hub.json) via SendUserCascadeMessage RPC first before falling back to CLI.
      const savedModelOverride = id ? this.sessionModelOverrides?.get(id) || null : null;
      const effectivePlanModel =
        provider === 'antigravity'
          ? resolveAntigravityPlanModelEnum(
              cmd.model || cmd.displayModel || savedModelOverride?.model || savedModelOverride?.displayModel || '',
              cmd.effort || savedModelOverride?.effort || ''
            )
          : '';

      const isExistingIdeAgySession =
        provider === 'antigravity' &&
        Boolean(id && !newSession) &&
        hasIdeConversationOnDisk(id) &&
        !this.isCliOwnedSession(id);
      const ideUiAvailable = Boolean(this.vscode);
      const preferIdeForExistingAgy =
        isExistingIdeAgySession && ideUiAvailable && cmd.forceDirect !== true;

      if (isExistingIdeAgySession && !ideUiAvailable && cmd.forceDirect !== true) {
        const ep = this.readPersistentHubEndpoint();
        if (ep && ep.port && ep.csrfToken) {
          try {
            const { sendDirectCascadeRpcMessage } = require('./compat/antigravity-hub-bridge.cjs');
            const headlessRpcRes = await sendDirectCascadeRpcMessage(ep.port, ep.csrfToken, id, {
              prompt,
              planModel: effectivePlanModel
            });
            if (headlessRpcRes?.ok) {
              if (!this.requestedThreads) this.requestedThreads = new Map();
              this.requestedThreads.set(id, { provider, requestedAt: Date.now() });
              if (cmd.model || cmd.effort || cmd.displayModel) {
                if (!this.sessionModelOverrides) this.sessionModelOverrides = new Map();
                this.sessionModelOverrides.set(id, {
                  model: String(cmd.model || '').trim(),
                  effort: String(cmd.effort || '').trim(),
                  displayModel: String(cmd.displayModel || '').trim(),
                  at: Date.now()
                });
              }
              this.notifyStateUpdated();
              return {
                ok: true,
                provider,
                id,
                threadId: id,
                deviceId: selfDeviceId,
                deviceName: this.deviceInfo?.name || os.hostname(),
                executionMode: 'headless-hub-rpc',
                result: headlessRpcRes
              };
            }
          } catch {}
        }
      }

      const useDirectRunner =
        Boolean(this.directRunner) &&
        !preferIdeForExistingAgy &&
        (cmd.executionMode === 'direct' ||
          cmd.direct === true ||
          !this.vscode ||
          (id && this.isCliOwnedSession(id)));

      if (useDirectRunner) {
        const effectiveDraftId = cmd.draftId || cmd.draftThreadId || '';
        const directRes = await this.directRunner.startPromptRun({
          id,
          draftId: effectiveDraftId,
          prompt,
          newSession,
          provider,
          cwd: cmd.cwd || '',
          workspace: cmd.workspace || cmd.repoPrefix || '',
          effort: cmd.effort || '',
          model: cmd.model || '',
          mode: cmd.mode || ''
        });
        if (directRes?.ok) {
          const dId = String(directRes.threadId || directRes.id || id || '').trim();
          if (dId) {
            if (!this.requestedThreads) this.requestedThreads = new Map();
            this.requestedThreads.set(dId, { provider, requestedAt: Date.now() });
            if (cmd.model || cmd.effort || cmd.displayModel) {
              if (!this.sessionModelOverrides) this.sessionModelOverrides = new Map();
              this.sessionModelOverrides.set(dId, {
                model: String(cmd.model || '').trim(),
                effort: String(cmd.effort || '').trim(),
                displayModel: String(cmd.displayModel || '').trim(),
                at: Date.now()
              });
            }
            if (cmd.group) {
              await this.assignGroupToSession(dId, cmd.group);
            }
          }
          this.notifyStateUpdated();
          return {
            ok: true,
            provider,
            id: dId,
            threadId: dId,
            draftId: directRes.draftId || effectiveDraftId,
            deviceId: selfDeviceId,
            deviceName: this.deviceInfo?.name || os.hostname(),
            streaming: true,
            executionMode: 'direct',
            result: directRes
          };
        }
        if (!this.vscode) {
          return directRes || { ok: false, error: 'Direct runner failed' };
        }
      }

      if (provider === 'claude') {
        if (this.vscode?.commands) {
          res = await this.vscode.commands.executeCommand('antigravityHub.claudeSendPrompt', {
            id,
            prompt,
            newSession,
            preserveFocus: false,
            mode: cmd.mode || ''
          });
        }
      } else {
        if (typeof this.agyBridge?.sendPromptToAntigravity === 'function') {
          res = await this.agyBridge.sendPromptToAntigravity({
            id,
            prompt,
            newSession,
            preserveFocus: false,
            planModel: effectivePlanModel
          });
        } else if (this.vscode?.commands) {
          res = await this.vscode.commands.executeCommand('antigravityHub.sendPrompt', {
            id,
            prompt,
            newSession,
            preserveFocus: false,
            planModel: effectivePlanModel
          });
        }
      }
      let resolvedId = String(
        res?.id || res?.sessionId || res?.opened?.id || id || ''
      ).trim();

      // Fallback to headless DirectRunner if VS Code UI bridge was busy/unavailable on newSession
      if (!resolvedId && newSession && this.directRunner && cmd.executionMode !== 'ide-only') {
        const fbRes = await this.directRunner.startPromptRun({
          id: '',
          draftId: cmd.draftId || cmd.draftThreadId || '',
          prompt,
          newSession: true,
          provider,
          cwd: cmd.cwd || '',
          workspace: cmd.workspace || cmd.repoPrefix || '',
          effort: cmd.effort || '',
          model: cmd.model || '',
          mode: cmd.mode || ''
        });
        if (fbRes?.ok) {
          resolvedId = String(fbRes.threadId || fbRes.id || '').trim();
          res = fbRes;
        }
      }

      if (resolvedId) {
        if (!this.requestedThreads) {
          this.requestedThreads = new Map();
        }
        this.requestedThreads.set(resolvedId, { provider, requestedAt: Date.now() });
        if (cmd.model || cmd.effort || cmd.displayModel) {
          if (!this.sessionModelOverrides) this.sessionModelOverrides = new Map();
          this.sessionModelOverrides.set(resolvedId, {
            model: String(cmd.model || '').trim(),
            effort: String(cmd.effort || '').trim(),
            displayModel: String(cmd.displayModel || '').trim(),
            at: Date.now()
          });
        }
        if (cmd.group) {
          await this.assignGroupToSession(resolvedId, cmd.group);
        }
      }
      if (this.hub) {
        if (newSession) {
          await withTimeout(this.hub.refresh({ forceQuota: false }).catch(() => {}), 1800, null);
        } else {
          setTimeout(() => this.hub.refresh().catch(() => {}), 400);
        }
      }
      return {
        ok: true,
        provider,
        id: resolvedId,
        threadId: resolvedId,
        deviceId: selfDeviceId,
        executionMode: 'ide',
        result: res
      };
    }

    const isQuestionCmd =
      type === 'answerQuestion' ||
      ((type === 'approve' || type === 'respondApproval') &&
        (cmd.kind === 'question' ||
          cmd.decision === 'answer' ||
          cmd.decision === 'skip' ||
          Array.isArray(cmd.responses) ||
          Array.isArray(cmd.selectedOptionIds) ||
          Array.isArray(cmd.selectedTexts) ||
          Boolean(cmd.writeInResponse) ||
          Boolean(cmd.answers)));

    if (isQuestionCmd) {
      const provider = cmd.provider === 'claude' ? 'claude' : 'antigravity';
      const sessId = String(cmd.sessionId || targetId || cmd.approvalId || cmd.id || '').trim();
      const isSkip = Boolean(
        cmd.skipped || cmd.decision === 'skip' || cmd.decision === 'reject'
      );
      if (sessId) {
        if (!this.requestedThreads) {
          this.requestedThreads = new Map();
        }
        this.requestedThreads.set(sessId, { provider, requestedAt: Date.now() });
      }
      let res = null;
      if (provider === 'claude') {
        const selectedIds = Array.isArray(cmd.selectedOptionIds)
          ? cmd.selectedOptionIds.map((x) => String(x || '').trim())
          : [];
        const selectedTexts = Array.isArray(cmd.selectedTexts)
          ? cmd.selectedTexts.map((x) => String(x || '').trim())
          : [];
        const writeIn = String(cmd.writeInResponse || '').trim();
        const isDenyChoice =
          isSkip ||
          selectedIds.includes('deny') ||
          selectedTexts.some((t) => /^no\b/i.test(t));
        const isAllowAlways =
          Boolean(cmd.allowAlways || cmd.decision === 'allow_always') ||
          selectedIds.includes('allow_always') ||
          selectedTexts.some(
            (t) => /^yes,\s*allow\b/i.test(t) || /^yes,\s*and\s*manually/i.test(t)
          );
        const isAllowOnce =
          selectedIds.includes('allow') ||
          selectedTexts.some((t) => /^yes$/i.test(t) || /^yes,\s*and\s*auto/i.test(t));
        const isToolPerm = Boolean(
          cmd.isToolPermission || isAllowOnce || isAllowAlways || selectedIds.includes('deny')
        );
        // On a tool permission prompt, typing into "Tell Claude what to do instead" without selecting Yes rejects the tool with that instruction
        const effectiveApproved = isDenyChoice
          ? false
          : isToolPerm && writeIn && !isAllowOnce && !isAllowAlways
            ? false
            : true;

        const answersMap =
          cmd.answers && typeof cmd.answers === 'object' ? { ...cmd.answers } : {};
        if (Array.isArray(cmd.responses)) {
          for (const r of cmd.responses) {
            if (r && r.question && r.answerText) {
              answersMap[r.question] = r.answerText;
            }
          }
        }
        const permPayload = {
          id: cmd.approvalId || targetId || cmd.id,
          sessionId: sessId,
          approved: effectiveApproved,
          allowAlways: isAllowAlways,
          customReason: !effectiveApproved && writeIn ? writeIn : '',
          writeInResponse: writeIn,
          answers: answersMap,
          reason: !effectiveApproved && !writeIn ? 'Denied from THEO Remote' : undefined
        };
        if (this.claudeBridge?.respondClaudePermission) {
          res = await this.claudeBridge.respondClaudePermission(permPayload).catch(() => null);
        }
        if ((!res || !res.resolved) && this.vscode?.commands) {
          res = await this.vscode.commands
            .executeCommand('antigravityHub.claudeRespondPermission', permPayload)
            .catch(() => null);
        }
        if ((!res || !res.resolved) && (writeIn || (!isSkip && cmd.answerText)) && this.vscode?.commands) {
          const fallbackPrompt = writeIn || String(cmd.answerText || '').trim();
          if (fallbackPrompt) {
            res = await this.vscode.commands
              .executeCommand('antigravityHub.claudeSendPrompt', {
                id: sessId,
                prompt: fallbackPrompt,
                newSession: false,
                preserveFocus: false
              })
              .catch(() => null);
          }
        }
      } else {
        if (!cmd.plainQuestionFallback && this.store?.answerAntigravityQuestion && sessId) {
          res = await this.store
            .answerAntigravityQuestion(sessId, {
              ...cmd,
              skipped: isSkip
            })
            .catch(() => null);
        }
        if (!res?.ok) {
          if (!cmd.plainQuestionFallback && this.vscode?.commands) {
            res = await this.vscode.commands
              .executeCommand('antigravityHub.remoteAction', {
                type: 'answerQuestion',
                kind: 'answerQuestion',
                id: sessId,
                approvalId: cmd.approvalId || sessId,
                skipped: isSkip,
                selectedOptionIds: cmd.selectedOptionIds || [],
                selectedTexts: cmd.selectedTexts || [],
                writeInResponse: cmd.writeInResponse || '',
                responses: cmd.responses || []
              })
              .catch(() => null);
          }
          if (!isSkip && cmd.answerText && (cmd.plainQuestionFallback || !res?.ok)) {
            if (typeof this.agyBridge?.sendPromptToAntigravity === 'function') {
              res = await this.agyBridge
                .sendPromptToAntigravity({
                  id: sessId,
                  prompt: String(cmd.answerText).trim(),
                  newSession: false,
                  preserveFocus: false
                })
                .catch(() => null);
            } else if (this.vscode?.commands) {
              res = await this.vscode.commands
                .executeCommand('antigravityHub.sendPrompt', {
                  id: sessId,
                  prompt: String(cmd.answerText).trim(),
                  newSession: false,
                  preserveFocus: false
                })
                .catch(() => null);
            }
          }
        }
      }
      if (this.hub) {
        setTimeout(() => this.hub.refresh().catch(() => {}), 350);
      }
      return { ok: true, provider, sessionId: sessId, skipped: isSkip, result: res };
    }

    if (type === 'approve' || type === 'respondApproval') {
      const provider = cmd.provider === 'claude' ? 'claude' : 'antigravity';
      const approved = cmd.decision !== 'reject' && cmd.approved !== false;
      const allowAlways = Boolean(cmd.allowAlways || cmd.decision === 'allow_always');
      let res = null;
      if (provider === 'claude') {
        const permPayload = {
          id: cmd.approvalId || targetId || cmd.id,
          sessionId: cmd.sessionId || targetId,
          approved,
          allowAlways,
          customReason: String(cmd.writeInResponse || cmd.customReason || '').trim()
        };
        if (this.claudeBridge?.respondClaudePermission) {
          res = await this.claudeBridge.respondClaudePermission(permPayload).catch(() => null);
        }
        if ((!res || !res.resolved) && this.vscode?.commands) {
          res = await this.vscode.commands
            .executeCommand('antigravityHub.claudeRespondPermission', permPayload)
            .catch(() => null);
        }
      } else if (this.vscode?.commands) {
        res = await this.vscode.commands.executeCommand('antigravityHub.remoteAction', {
          type: 'clickApproval',
          id: cmd.sessionId || cmd.approvalId || targetId,
          approvalId: cmd.approvalId || cmd.sessionId || targetId,
          kind: approved ? 'approve' : 'reject',
          selector: cmd.selector || '',
          targetLabel: approved ? cmd.label || '' : '',
          label: approved ? cmd.label || 'Accept' : 'Reject'
        });
      }
      if (this.hub) {
        setTimeout(() => this.hub.refresh().catch(() => {}), 400);
      }
      return { ok: true, provider, approved, result: res };
    }

    if (type === 'open' || type === 'new' || type === 'openNew') {
      return this.executeRemoteCommand({
        ...cmd,
        type: 'sessionAction',
        subAction: type === 'open' && targetId ? 'open' : 'openNew'
      });
    }

    if (type === 'reconnect' || type === 'repair') {
      try {
        if (this.vscode?.commands) {
          await this.vscode.commands.executeCommand('antigravityHub.reconnectTabs', {
            forceRender: true
          });
        } else {
          this.agyBridge?.reconnectAllOpenTabs?.(this.agyBridge?.getBridgeState?.(), {
            forceRender: true
          });
        }
      } catch {}
      if (this.hub) {
        await this.hub.refresh({ forceQuota: false });
      }
      return { ok: true, action: type };
    }

    if (type === 'sessionAction') {
      const subAction = String(cmd.subAction || cmd.action || '').trim();
      if (subAction === 'reconnect' || subAction === 'repair') {
        return this.executeRemoteCommand({ ...cmd, type: 'reconnect' });
      }
      if (subAction === 'requestThread') {
        return this.executeRemoteCommand({
          type: 'requestThread',
          threadId: targetId,
          id: targetId,
          provider: cmd.provider
        });
      }
      if (subAction === 'setModel') {
        const sid = String(cmd.sessionId || targetId || cmd.id || '').trim();
        if (sid) {
          if (!this.sessionModelOverrides) this.sessionModelOverrides = new Map();
          this.sessionModelOverrides.set(sid, {
            model: String(cmd.model || '').trim().slice(0, 64),
            effort: String(cmd.effort || '').trim().slice(0, 16),
            displayModel: String(cmd.displayModel || '').trim().slice(0, 80),
            at: Date.now()
          });
          if (this.sessionModelOverrides.size > 200) {
            const firstK = this.sessionModelOverrides.keys().next().value;
            if (firstK) this.sessionModelOverrides.delete(firstK);
          }
          this.notifyStateUpdated();
        }
        return { ok: true, id: sid, model: cmd.model, effort: cmd.effort, displayModel: cmd.displayModel };
      }
      if (subAction === 'compact') {
        return this.executeRemoteCommand({
          type: 'send',
          provider: cmd.provider,
          threadId: targetId,
          id: targetId,
          prompt: '/compact'
        });
      }
      if (subAction === 'interrupt' || subAction === 'stop' || subAction === 'cancel') {
        return this.interruptSession(targetId, cmd.provider);
      }
      if (subAction === 'cancelBgTask') {
        const sid = String(cmd.sessionId || targetId || '').trim();
        const tid = String(cmd.taskId || '').trim();
        if (!sid || !tid) {
          return { ok: false, error: 'Missing sessionId or taskId' };
        }
        if (this.hub && typeof this.hub.handleMessage === 'function') {
          await this.hub.handleMessage({
            action: 'cancelBgTask',
            sessionId: sid,
            taskId: tid,
            provider: cmd.provider
          });
          this.notifyStateUpdated();
          return { ok: true, subAction: 'cancelBgTask', sessionId: sid, taskId: tid };
        }
        if (this.store?.cancelBackgroundTaskOnServer) {
          const out = await this.store.cancelBackgroundTaskOnServer(sid, cmd.provider || '', {
            id: tid,
            fullId: tid,
            kind: cmd.kind || 'task',
            stepIndex: typeof cmd.stepIndex === 'number' ? cmd.stepIndex : -1
          });
          this.notifyStateUpdated();
          return { ok: Boolean(out?.ok), subAction: 'cancelBgTask', sessionId: sid, taskId: tid };
        }
        return { ok: false, error: 'Store unavailable' };
      }
      if (subAction === 'cancelAllBgTasks') {
        const sid = String(cmd.sessionId || targetId || '').trim();
        if (this.hub && typeof this.hub.handleMessage === 'function') {
          await this.hub.handleMessage({
            action: 'cancelAllBgTasks',
            sessionId: sid
          });
          this.notifyStateUpdated();
          return { ok: true, subAction: 'cancelAllBgTasks', sessionId: sid };
        }
        if (this.store?.cancelBackgroundTaskOnServer) {
          const threads = this.hub?.snapshot?.threads || [];
          for (const th of threads) {
            if (sid && th.id !== sid) continue;
            for (const item of th.backgroundTasks || []) {
              if (item.state === 'running') {
                await this.store
                  .cancelBackgroundTaskOnServer(th.id, th.provider || '', item)
                  .catch(() => {});
              }
            }
          }
          this.notifyStateUpdated();
          return { ok: true, subAction: 'cancelAllBgTasks', sessionId: sid };
        }
        return { ok: false, error: 'Store unavailable' };
      }
      if (
        (subAction === 'openNew' || (subAction === 'open' && !targetId)) &&
        this.hub &&
        typeof this.hub.handleMessage === 'function'
      ) {
        await this.hub.handleMessage({
          action: 'new',
          provider: cmd.provider === 'claude' ? 'claude' : 'antigravity',
          group: cmd.group
        });
        return { ok: true, subAction: 'openNew' };
      }
      if (subAction === 'open' && targetId && cmd.provider !== 'claude') {
        try {
          if (!this.directRunner?.hasActiveRun(targetId)) {
            mirrorCliConversationToIde(targetId);
          }
        } catch {}
      }
      if (this.hub && typeof this.hub.handleMessage === 'function') {
        await this.hub.handleMessage({
          action: subAction,
          id: targetId,
          accountId: cmd.accountId || targetId,
          ids: cmd.ids,
          provider: cmd.provider,
          name: cmd.name,
          label: cmd.label ?? cmd.name,
          emailHint: cmd.emailHint || cmd.email,
          switchOnComplete: cmd.switchOnComplete,
          direction: cmd.direction,
          targetAccountId: cmd.targetAccountId,
          position: cmd.position,
          orderedIds: cmd.orderedIds,
          prompt: Boolean(cmd.prompt),
          confirm: Boolean(cmd.confirm),
          value: cmd.value,
          hide: cmd.hide,
          group: cmd.group
        });
        return { ok: true, subAction };
      }
      if (
        this.accountVault &&
        (subAction === 'accountSwitch' ||
          subAction === 'accountLabel' ||
          subAction === 'accountRemove' ||
          subAction === 'accountReorder')
      ) {
        const acctId = String(cmd.accountId || targetId || '').trim();
        const prov = cmd.provider === 'claude' ? 'claude' : 'antigravity';
        if (subAction === 'accountReorder') {
          return this.accountVault.reorderAccount({
            accountId: acctId,
            provider: cmd.provider || '',
            direction: cmd.direction || '',
            targetAccountId: String(cmd.targetAccountId || '').trim(),
            position: cmd.position || '',
            orderedIds: Array.isArray(cmd.orderedIds) ? cmd.orderedIds : null
          });
        }
        if (subAction === 'accountSwitch' && acctId) {
          return this.accountVault.switchActiveAccount({
            provider: prov,
            accountId: acctId,
            vscode: this.vscode
          });
        }
        if (subAction === 'accountLabel' && acctId) {
          return this.accountVault.setAccountLabel({
            provider: prov,
            accountId: acctId,
            label: cmd.label ?? cmd.name ?? ''
          });
        }
        if (subAction === 'accountRemove' && acctId) {
          return this.accountVault.removeAccount({
            provider: prov,
            accountId: acctId,
            vscode: this.vscode
          });
        }
      }
      try {
        const hubStatePath = this.hubStateBackupPath || path.join(os.homedir(), '.claude', '.theo-hub-state.json');
        const st = fs.existsSync(hubStatePath)
          ? JSON.parse(fs.readFileSync(hubStatePath, 'utf8'))
          : {};
        if (!Array.isArray(st.groups)) st.groups = [];
        if (!st.threadGroups || typeof st.threadGroups !== 'object') st.threadGroups = {};
        if (!st.unassignedGroupThreads || typeof st.unassignedGroupThreads !== 'object') {
          st.unassignedGroupThreads = {};
        }
        if (!Array.isArray(st.archivedIds)) st.archivedIds = [];
        if (!Array.isArray(st.unreadIds)) st.unreadIds = [];
        if (!Array.isArray(st.deletedGroups)) st.deletedGroups = [];
        if (!st.seenTurnTimestamps || typeof st.seenTurnTimestamps !== 'object') {
          st.seenTurnTimestamps = {};
        }
        if (!st.unarchivedAt || typeof st.unarchivedAt !== 'object') st.unarchivedAt = {};
        const nowSec = Math.floor(Date.now() / 1000);
        if (subAction === 'groupCreate') {
          const gId = cmd.group || `grp-${Date.now().toString(36)}`;
          const gName = String(cmd.name || 'New group').trim() || 'New group';
          if (!st.groups.some((g) => g.id === gId)) {
            st.groups.push({ id: gId, name: gName, color: 'blue', collapsed: false });
          }
          const ids = Array.isArray(cmd.ids) ? cmd.ids : targetId ? [targetId] : [];
          for (const tid of ids) {
            if (tid) {
              st.threadGroups[tid] = gId;
              delete st.unassignedGroupThreads[tid];
            }
          }
        } else if (subAction === 'groupRename' && cmd.group && cmd.name) {
          const g = st.groups.find((x) => x.id === cmd.group);
          if (g) g.name = String(cmd.name).trim();
        } else if (subAction === 'groupDelete' && cmd.group) {
          const victim = st.groups.find((x) => x.id === cmd.group);
          st.deletedGroups = st.deletedGroups
            .filter((d) => d && d.id !== cmd.group)
            .concat([
              { id: cmd.group, name: String(victim?.name || '').trim().toLowerCase(), at: nowSec }
            ])
            .slice(-60);
          st.groups = st.groups.filter((x) => x.id !== cmd.group);
          for (const [k, v] of Object.entries(st.threadGroups)) {
            if (v === cmd.group) {
              delete st.threadGroups[k];
              st.unassignedGroupThreads[k] = nowSec;
            }
          }
        } else if (subAction === 'unread') {
          const ids = Array.isArray(cmd.ids) ? cmd.ids : targetId ? [targetId] : [];
          const unreadSet = new Set(st.unreadIds);
          // Only a session open in a tab on this host can carry an unread mark (hub.js render).
          const openTabIds = new Set(
            (Array.isArray(this.hub?.openTabsList) ? this.hub.openTabsList : []).map((t) => t?.id).filter(Boolean)
          );
          for (const tid of ids) {
            if (!tid) continue;
            if (cmd.value) {
              if (openTabIds.has(tid)) unreadSet.add(tid);
            } else {
              unreadSet.delete(tid);
              st.seenTurnTimestamps[tid] = Math.max(
                Number(st.seenTurnTimestamps[tid] || 0),
                nowSec
              );
            }
          }
          st.unreadIds = Array.from(unreadSet);
        } else if (subAction === 'groupToggle' && cmd.group) {
          const g = st.groups.find((x) => x.id === cmd.group);
          if (g) g.collapsed = Boolean(cmd.value);
        } else if (subAction === 'groupAdd' && cmd.group) {
          const ids = Array.isArray(cmd.ids) ? cmd.ids : targetId ? [targetId] : [];
          for (const tid of ids) {
            if (tid) {
              st.threadGroups[tid] = cmd.group;
              delete st.unassignedGroupThreads[tid];
            }
          }
        } else if (subAction === 'groupRemove') {
          const ids = Array.isArray(cmd.ids) ? cmd.ids : targetId ? [targetId] : [];
          for (const tid of ids) {
            if (tid) {
              delete st.threadGroups[tid];
              st.unassignedGroupThreads[tid] = nowSec;
            }
          }
        } else if (subAction === 'archive') {
          const ids = Array.isArray(cmd.ids) ? cmd.ids : targetId ? [targetId] : [];
          const arcSet = new Set(st.archivedIds);
          for (const tid of ids) {
            if (!tid) continue;
            if (cmd.value) {
              arcSet.add(tid);
              delete st.unarchivedAt[tid];
              if (st.threadGroups[tid]) {
                delete st.threadGroups[tid];
                st.unassignedGroupThreads[tid] = nowSec;
              }
            } else {
              arcSet.delete(tid);
              st.unarchivedAt[tid] = nowSec;
            }
          }
          st.archivedIds = Array.from(arcSet);
        } else if (subAction === 'accountCollapse' && (cmd.accountId || targetId)) {
          if (!st.preferences || typeof st.preferences !== 'object') st.preferences = {};
          if (!st.preferences.collapsedAccounts || typeof st.preferences.collapsedAccounts !== 'object') {
            st.preferences.collapsedAccounts = {};
          }
          st.preferences.collapsedAccounts[String(cmd.accountId || targetId)] = Boolean(cmd.value);
        } else if (subAction === 'setHideThirdPartyQuota') {
          if (!st.preferences || typeof st.preferences !== 'object') st.preferences = {};
          st.preferences.hideThirdPartyQuota =
            typeof cmd.hide === 'boolean'
              ? cmd.hide
              : Boolean(cmd.value === true || cmd.value === 'true' || cmd.value === 'hide' || cmd.value === 1);
          st.preferences.hideThirdPartyQuotaUpdatedAt = Date.now();
        }
        st.updatedAt = Date.now();
        fs.mkdirSync(path.dirname(hubStatePath), { recursive: true });
        fs.writeFileSync(hubStatePath, JSON.stringify(st, null, 2), 'utf8');
        try {
          this.notifyStateUpdated();
        } catch {}
        return { ok: true, subAction, standalone: true };
      } catch {}
    }

    if (type === 'refresh') {
      if (this.hub) {
        await this.hub.refresh({ forceQuota: true });
      }
      return { ok: true };
    }

    return { ok: false, error: `Unknown command type: ${type}` };
  }

  // Store-side claim of a queued command: true = this host owns it, false = another host does,
  // null = the store could not be asked (the caller retries on its next cycle).
  // Every store request of the sync cycle goes through here, so the cycle can be driven against a stand-in store.
  postStore(payload, timeoutMs = 10000) {
    return httpsJsonRequest(this.relayConfig.url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify({ ...payload, key: this.relayConfig.key }),
      timeoutMs
    });
  }

  storeClaimKey(cmdKey) {
    return `cmd:${crypto.createHash('sha256').update(String(cmdKey || ''), 'utf8').digest('hex')}`;
  }

  async claimCommandInStore(cmdKey, deviceId, leaseMs = this.claimInflightLeaseMs || CLAIM_INFLIGHT_LEASE_MS) {
    try {
      const safeLeaseMs = Math.max(50, Math.floor(Number(leaseMs) || CLAIM_INFLIGHT_LEASE_MS));
      const res = await this.postStore({
          key: this.relayConfig.key,
          op: 'claim',
          claimKey: this.storeClaimKey(cmdKey),
          deviceId,
          leaseMs: safeLeaseMs
        }, 6000);
      if (!res || res.ok !== true || typeof res.claimed !== 'boolean') return null;
      const rawLeaseUntil = Number(res.leaseUntil || 0);
      return {
        claimed: res.claimed,
        by: typeof res.by === 'string' ? res.by : '',
        leaseUntil: Number.isFinite(rawLeaseUntil) && rawLeaseUntil > 0 ? rawLeaseUntil : 0
      };
    } catch {
      return null;
    }
  }

  async checkHubSelfUpdate(hubRelease) {
    if (this.disposed || !hubRelease || typeof hubRelease !== 'object') return null;
    if (process.env.THEO_SMOKE_TEST === '1' && !this.allowSmokeSelfUpdate) return null;
    if (this._hubSelfUpdateInFlight) return this._hubSelfUpdateInFlight;
    const sig = `${hubRelease.version || ''}:${hubRelease.builtAt || 0}:${hubRelease.sha256 || ''}`;
    if (
      sig === this._lastCheckedHubReleaseSig &&
      Date.now() - (this._lastCheckedHubReleaseAt || 0) < 10 * 60 * 1000
    ) {
      return null;
    }
    this._lastCheckedHubReleaseSig = sig;
    this._lastCheckedHubReleaseAt = Date.now();
    const creds = loadTheoCredentials(this.context?.extensionPath || __dirname);
    const edgeAccessKey = String(creds.edgeAccessKey || this.relayConfig?.edgeAccessKey || '').trim();
    if (!edgeAccessKey) return null;
    const run = maybeApplyHubReleaseUpdate(hubRelease, { edgeAccessKey })
      .then((res) => {
        if (res && res.updated) {
          // The file list describes the bundle's target folders; it applies here only when this window's
          // own folder was one of them (a version-bumped release lands in a new folder).
          const ownExtRoot = path.resolve(this.context?.extensionPath || __dirname).toLowerCase();
          const wroteOwnFolder = (res.updatedPaths || []).some(
            (p) => path.resolve(String(p)).toLowerCase() === ownExtRoot
          );
          this.syncHotReloadedModules({ changedFiles: wroteOwnFolder ? res.updatedFiles : undefined });
          if (typeof this.onSelfUpdateApplied === 'function') {
            try {
              this.onSelfUpdateApplied(res);
            } catch {}
          }
        }
        return res;
      })
      .catch(() => null)
      .finally(() => {
        this._hubSelfUpdateInFlight = null;
      });
    this._hubSelfUpdateInFlight = run;
    return run;
  }

  async releaseCommandInStore(cmdKey, deviceId) {
    try {
      await this.postStore({
          key: this.relayConfig.key,
          op: 'claim',
          release: true,
          claimKey: this.storeClaimKey(cmdKey),
          deviceId
        }, 6000);
    } catch {}
  }

  async syncCloudRelay(options = {}) {
    if (this.disposed || !this.relayConfig.url || !this.relayConfig.key) {
      return null;
    }
    if (this.server && !this.listening && !options.allowStandby) {
      return null;
    }
    const nowStart = Date.now();
    if (this.cloudSyncInFlight && nowStart - (this.cloudSyncStartedAt || 0) < 25000) {
      if (options.urgent) {
        this.pendingUrgentCloudSync = true;
      }
      return null;
    }
    this.cloudSyncInFlight = true;
    this.cloudSyncStartedAt = nowStart;
    this.lastCloudAttemptAt = nowStart;
    try {
      this.syncFromDiskPersonalLedger();
      if (this.pendingStore) {
        // A relay move is waiting for the store behind the new relay to answer: ask again (at most once a minute).
        await this.settleStoreAddress();
      }
      const selfDevId = this.deviceInfo?.id || 'workstation';
      const hostIdleMs = getHostIdleMs();
      // Naming this host on the poll enters it for the coordinator duty, which the store hands to one host at a time.
      const remoteStore = await this.postStore(
        {
          key: this.relayConfig.key,
          op: 'get_control', deviceId: selfDevId,
          ...(hostIdleMs !== null ? { idleMs: hostIdleMs } : {})
        },
        10000
      );
      const docs =
        remoteStore?.docs && typeof remoteStore.docs === 'object'
          ? remoteStore.docs
          : remoteStore || {};
      const storeCoordinator =
        remoteStore?.coordinator &&
        typeof remoteStore.coordinator === 'object' &&
        typeof remoteStore.coordinator.deviceId === 'string' &&
        remoteStore.coordinator.deviceId
          ? remoteStore.coordinator
          : null;
      // A store that answers with a coordinator also merges `device_states` per device and supports `claim`.
      const storeHasEqualHosts = Boolean(storeCoordinator);
      this.storeHasEqualHosts = storeHasEqualHosts;
      this.cloudControlDocs = docs;
      this.cloudControlDocsAt = Date.now();
      let pushRegistryNeedsCloudPatch = false;
      if (docs?.push_registry && Array.isArray(docs.push_registry.items)) {
        const prevCloudCount = docs.push_registry.items.length;
        pushRegistryNeedsCloudPatch = docs.push_registry.items.some(
          (d) => d && d.endpoint && (!d.keys || !d.keys.p256dh || !d.keys.auth)
        );
        this.mergeCloudPushRegistry(docs.push_registry.items);
        if (this.pushDevices.length !== prevCloudCount) {
          pushRegistryNeedsCloudPatch = true;
        }
      }
      if (docs?.personal_ledger && typeof docs.personal_ledger === 'object') {
        this.mergePersonalLedger(docs.personal_ledger);
      }
      if (docs?.delegated_tasks && typeof docs.delegated_tasks === 'object') {
        this.mergeDelegatedTasksFromCloud(docs.delegated_tasks);
      }
      await this.reconcileClaudePermissionModeWithStore(docs);
      if (
        docs?.edge_relay?.url &&
        String(docs.edge_relay.url).trim() &&
        String(docs.edge_relay.url).trim() !== this.getEffectiveEdgeUrl()
      ) {
        this.followAnnouncedEdgeRelay(String(docs.edge_relay.url).trim()).catch(() => {});
      }
      if (docs?.hub_release && typeof docs.hub_release === 'object') {
        this.checkHubSelfUpdate(docs.hub_release).catch(() => {});
      }
      this.ensureCloudPrayerTimersArmed(docs).catch(() => {});

      const queueObj = docs?.queue || remoteStore?.queue || {};
      const commands = Array.isArray(queueObj.commands) ? queueObj.commands : [];
      const resultsMap =
        queueObj.results && typeof queueObj.results === 'object'
          ? { ...queueObj.results }
          : {};

      if (!this.requestedThreads) {
        this.requestedThreads = new Map();
      }
      if (queueObj.activeThreadId) {
        this.requestedThreads.set(String(queueObj.activeThreadId), {
          provider: queueObj.activeThreadProvider || '',
          requestedAt: Date.now()
        });
      }

      // Refresh remote fleet state every ~25s so every host merges peer sessions without overwriting them
      const nowFollowMs = Date.now();
      if (!this._lastFleetFollowAt || nowFollowMs - this._lastFleetFollowAt > 25000) {
        try {
          const fullCloud = await this.postStore({ key: this.relayConfig.key, op: 'get_theo' }, 12000);
          this._lastFleetFollowAt = Date.now();
          const fullDocs =
            fullCloud?.docs && typeof fullCloud.docs === 'object' ? fullCloud.docs : fullCloud || {};
          if (fullDocs?.device_states && typeof fullDocs.device_states === 'object') {
            // The store's map is the fleet (it drops hosts not heard from for 30 days); this host's own entry is
            // the one it built itself.
            const ownEntry = this.remoteDeviceStates?.[selfDevId];
            this.remoteDeviceStates = {
              ...fullDocs.device_states,
              ...(ownEntry ? { [selfDevId]: ownEntry } : {})
            };
            // Learn which home folder belongs to which host from what each host published about itself.
            rememberFleetHomes(
              Object.entries(fullDocs.device_states).map(([devId, entry]) => ({
                id: devId,
                name: entry?.device?.name || '',
                homedir: entry?.device?.homedir || '',
                rowIds: (
                  Array.isArray(entry?.snapshot?.rows)
                    ? entry.snapshot.rows
                    : Array.isArray(entry?.rows)
                      ? entry.rows
                      : []
                )
                  .map((x) => x?.id)
                  .filter(Boolean)
              })),
              selfDevId
            );
            // Every host keeps the same thing on disk: the sessions the *other* hosts published. The sidebar
            // (store.js, state.js) shows them beside the local ones.
            const peerSnapshot = buildPeerSnapshot(fullDocs.device_states, selfDevId);
            const peerSig = `${peerSnapshot.rows.length}:${peerSnapshot.rows
              .slice(0, 40)
              .map((r) => `${r.id}:${r.status || ''}:${r.at || 0}:${r.group || ''}`)
              .join('|')}:${peerSnapshot.groups.map((g) => `${g.id}:${g.name || ''}`).join('|')}`;
            const cachePath = this.peerCachePath();
            fs.mkdirSync(path.dirname(cachePath), { recursive: true });
            fs.writeFileSync(
              cachePath,
              JSON.stringify({
                savedAt: Date.now(),
                peerOnly: true,
                snapshot: peerSnapshot,
                deviceStates: this.remoteDeviceStates,
                threads: fullDocs?.threads || {}
              }),
              'utf8'
            );
            if (peerSig !== this._lastPeerSnapshotSig) {
              this._lastPeerSnapshotSig = peerSig;
              this.hub?.refresh?.({ forceQuota: false })?.catch?.(() => {});
            }
          }
          if (fullDocs?.threads && typeof fullDocs.threads === 'object') {
            this.cachedRemoteThreads = { ...this.cachedRemoteThreads, ...fullDocs.threads };
          }
        } catch {}
      }

      // Who acts for the fleet this cycle (see decideFleetDuty).
      // A store with equal hosts stamps every fleet entry on its own clock, so "how long ago" is measured against
      // the store's time (from its answer), not this PC's: a PC whose clock is off still sees its peers correctly.
      const storeNowMs = storeHasEqualHosts ? Date.parse(String(remoteStore?.serverTime || '')) : NaN;
      const duty = decideFleetDuty({
        selfDevId,
        storeCoordinator,
        deviceStates: this.remoteDeviceStates,
        nowMs: Number.isFinite(storeNowMs) ? storeNowMs : Date.now()
      });
      const isCoordinator = duty.isCoordinator;
      this.isCoordinator = isCoordinator;
      this.coordinatorDeviceId = duty.coordinatorDeviceId;

      const localOwnedThreads = (this.hub?.snapshot?.threads || []).filter(
        (t) => t?.id && t.source !== 'cloud-relay' && !t.remotePeer
      );
      const localStoreClaudeIds = this.store?.claudeFileById
        ? Array.from(this.store.claudeFileById.keys())
        : [];
      const localThreadIds = new Set(
        localOwnedThreads
          .map((t) => t.id)
          .concat(localStoreClaudeIds)
          .concat((this.directRunner ? this.directRunner.getActiveRuns() : []).map((r) => r.id).filter(Boolean))
      );
      let executedAny = false;
      const updatedCommands = [];
      if (!this.foreignClaimHoldUntil) this.foreignClaimHoldUntil = new Map();
      if (!this.pendingSealClaims) this.pendingSealClaims = new Set();
      if (!this.pendingQueueClosures) this.pendingQueueClosures = new Map();
      const flushedClosureIds = [];
      for (const cmd of commands.slice(-20)) {
        if (!cmd || !cmd.id) continue;
        const cmdKey = `${cmd.id}:${cmd.createdAt || 0}`;
        if (cmd.status === 'pending' && this.pendingQueueClosures.has(cmd.id)) {
          const prevClosure = this.pendingQueueClosures.get(cmd.id);
          if (prevClosure && prevClosure.cmdKey === cmdKey) {
            resultsMap[cmd.id] = prevClosure.result;
            updatedCommands.push({ ...cmd, ...prevClosure.closedFields });
            flushedClosureIds.push(cmd.id);
            executedAny = true;
            continue;
          }
        }
        if (cmd.status === 'pending' && this.directDoneCmdKeys?.has(cmdKey)) {
          // The queued copy of a command this host already ran when it arrived directly: close it in the queue, so
          // it is not left pending for some later cycle, restart or other host to pick up.
          const ranAt = Number(this.directDoneCmdKeys.get(cmdKey)?.at || Date.now());
          this.directDoneCmdKeys.delete(cmdKey);
          this.processedCmdIds.add(cmdKey);
          completeCloudCommandOnce(cmdKey);
          this.foreignClaimHoldUntil.delete(cmdKey);
          const resultObj = { at: ranAt, ok: true, via: 'direct' };
          const closedFields = { status: 'done', completedAt: ranAt, via: 'direct' };
          this.pendingQueueClosures.set(cmd.id, { cmdKey, closedFields, result: resultObj });
          flushedClosureIds.push(cmd.id);
          resultsMap[cmd.id] = resultObj;
          updatedCommands.push({ ...cmd, ...closedFields });
          executedAny = true;
          continue;
        }
        if (cmd.status === 'pending' && !this.processedCmdIds.has(cmdKey)) {
          const holdUntil = Number(this.foreignClaimHoldUntil.get(cmdKey) || 0);
          if (holdUntil > Date.now()) {
            updatedCommands.push(cmd);
            continue;
          }
          if (holdUntil > 0) {
            this.foreignClaimHoldUntil.delete(cmdKey);
          }

          const cmdClass = classifyQueuedCommand(cmd, { selfDevId, localThreadIds, duty });
          const explicitlyForMe = cmdClass.explicitlyForMe;

          if (!cmdClass.mine) {
            updatedCommands.push(cmd);
            continue;
          }

          if (!beginCloudCommandLease(cmdKey, this.claimInflightLeaseMs || CLAIM_INFLIGHT_LEASE_MS)) {
            if (isCloudCommandSealed(cmdKey)) {
              this.processedCmdIds.add(cmdKey);
            }
            updatedCommands.push(cmd);
            continue;
          }

          // A command not addressed to this host by name is claimed in the store first: the first host to claim
          // it runs it, so it can never run on two PCs (a restored session can exist on both).
          let storeClaimHeld = false;
          if (!explicitlyForMe && storeHasEqualHosts) {
            const claimRes = await this.claimCommandInStore(cmdKey, selfDevId);
            if (claimRes === null) {
              // Store not reachable for the claim: leave the command for the next cycle.
              unclaimCloudCommand(cmdKey);
              updatedCommands.push(cmd);
              continue;
            }
            if (claimRes.claimed === false) {
              unclaimCloudCommand(cmdKey);
              if (claimRes.leaseUntil > 0) {
                const maxHoldMs = (this.claimInflightLeaseMs || CLAIM_INFLIGHT_LEASE_MS) * 2;
                const remainingMs = Number.isFinite(storeNowMs)
                  ? Math.min(maxHoldMs, Math.max(25, claimRes.leaseUntil - storeNowMs))
                  : Math.min(maxHoldMs, Math.max(25, claimRes.leaseUntil - Date.now()));
                this.foreignClaimHoldUntil.set(cmdKey, Date.now() + remainingMs);
              } else {
                completeCloudCommandOnce(cmdKey);
                this.processedCmdIds.add(cmdKey);
              }
              updatedCommands.push(cmd);
              continue;
            }
            storeClaimHeld = true;
          }

          this.processedCmdIds.add(cmdKey);
          try {
            const execRes = await withTimeout(
              this.executeRemoteCommand({ ...cmd, _fromCloudQueue: true }),
              16000,
              { ok: false, error: 'Command execution timed out' }
            );
            if (execRes && execRes.deferCommand) {
              this.processedCmdIds.delete(cmdKey);
              unclaimCloudCommand(cmdKey);
              if (storeClaimHeld) await this.releaseCommandInStore(cmdKey, selfDevId);
              updatedCommands.push(cmd);
              continue;
            }
            completeCloudCommandOnce(cmdKey);
            if (storeClaimHeld) {
              this.pendingSealClaims.add(this.storeClaimKey(cmdKey));
            }
            executedAny = true;
            const doneAt = Date.now();
            const resultObj = {
              at: doneAt,
              ok: true,
              ...execRes
            };
            const closedFields = { status: 'done', completedAt: doneAt };
            this.pendingQueueClosures.set(cmd.id, { cmdKey, closedFields, result: resultObj });
            flushedClosureIds.push(cmd.id);
            resultsMap[cmd.id] = resultObj;
            updatedCommands.push({ ...cmd, ...closedFields });
          } catch (err) {
            if (err && err.deferCommand) {
              this.processedCmdIds.delete(cmdKey);
              unclaimCloudCommand(cmdKey);
              if (storeClaimHeld) await this.releaseCommandInStore(cmdKey, selfDevId);
              updatedCommands.push(cmd);
              continue;
            }
            completeCloudCommandOnce(cmdKey);
            if (storeClaimHeld) {
              this.pendingSealClaims.add(this.storeClaimKey(cmdKey));
            }
            executedAny = true;
            const errAt = Date.now();
            const resultObj = {
              at: errAt,
              ok: false,
              error: String(err?.message || err)
            };
            const closedFields = { status: 'error', completedAt: errAt };
            this.pendingQueueClosures.set(cmd.id, { cmdKey, closedFields, result: resultObj });
            flushedClosureIds.push(cmd.id);
            resultsMap[cmd.id] = resultObj;
            updatedCommands.push({ ...cmd, ...closedFields });
          }
        } else {
          updatedCommands.push(cmd);
        }
      }

      const mergeFreshControlQueue = async () => {
        try {
          const latestCtrl = await this.postStore({ key: this.relayConfig.key, op: 'get_control' }, 6000);
          const latestDocs =
            latestCtrl?.docs && typeof latestCtrl.docs === 'object'
              ? latestCtrl.docs
              : latestCtrl || {};
          const latestQueue = latestDocs?.queue || latestCtrl?.queue || {};
          const latestCmds = Array.isArray(latestQueue.commands) ? latestQueue.commands : [];
          const byId = new Map();
          for (const c of updatedCommands) {
            if (c && c.id) byId.set(c.id, c);
          }
          for (const c of latestCmds) {
            if (!c || !c.id) continue;
            const existing = byId.get(c.id);
            if (!existing || (c.status === 'pending' && existing.status === 'pending')) {
              byId.set(c.id, c);
            }
          }
          return {
            activeThreadId: latestQueue.activeThreadId || queueObj.activeThreadId || '',
            activeThreadProvider:
              latestQueue.activeThreadProvider || queueObj.activeThreadProvider || '',
            commands: Array.from(byId.values()).slice(-16),
            results: { ...(latestQueue.results || {}), ...resultsMap }
          };
        } catch {
          return {
            activeThreadId: queueObj.activeThreadId || '',
            activeThreadProvider: queueObj.activeThreadProvider || '',
            commands: updatedCommands.slice(-16),
            results: resultsMap
          };
        }
      };

      const cloudLedgerUpdatedAt = Number(docs?.personal_ledger?.updatedAt || 0);
      const localLedgerUpdatedAt = Number(this.personalLedger?.updatedAt || 0);
      const personalLedgerNeedsCloudPatch =
        localLedgerUpdatedAt > 0 && localLedgerUpdatedAt > cloudLedgerUpdatedAt;

      const sealList = storeHasEqualHosts && this.pendingSealClaims?.size > 0
        ? Array.from(this.pendingSealClaims).slice(0, 64)
        : [];
      if (executedAny || pushRegistryNeedsCloudPatch || personalLedgerNeedsCloudPatch || sealList.length > 0) {
        const controlPatch = {};
        if (executedAny) {
          controlPatch.queue = await mergeFreshControlQueue();
        }
        if (pushRegistryNeedsCloudPatch && this.pushDevices.length > 0) {
          controlPatch.push_registry = {
            items: this.pushDevices,
            updatedAt: new Date().toISOString()
          };
        }
        if (personalLedgerNeedsCloudPatch) {
          controlPatch.personal_ledger = this.personalLedger;
        }
        const patchAck = await this.postStore({
            key: this.relayConfig.key,
            op: 'patch',
            ackOnly: true,
            ...(sealList.length > 0 ? { sealClaims: sealList } : {}),
            patch: controlPatch
          }, 10000).catch(() => null);
        if (patchAck && patchAck.ok !== false) {
          if (sealList.length > 0) {
            for (const sk of sealList) this.pendingSealClaims.delete(sk);
          }
          if (controlPatch.queue && flushedClosureIds.length > 0) {
            for (const cid of flushedClosureIds) this.pendingQueueClosures.delete(cid);
          }
          if (this.pendingQueueClosures.size > 200) {
            const drop = Array.from(this.pendingQueueClosures.keys()).slice(
              0,
              this.pendingQueueClosures.size - 200
            );
            for (const cid of drop) this.pendingQueueClosures.delete(cid);
          }
        }
      }

      if (options.pushState || executedAny) {
        const fullSnapshot = await this.buildFullState();
        await withTimeout(
          this.evaluateRealtimePushAlerts(fullSnapshot, { fromCloudSync: true }).catch(() => {}),
          4000,
          null
        );
        const allRows = fullSnapshot.rows || [];
        const priorityRowMap = new Map();
        for (const r of allRows) {
          if (!r || !r.id) continue;
          if (
            r.group ||
            r.open ||
            r.active ||
            r.unread ||
            r.status === 'waiting' ||
            r.status === 'working'
          ) {
            priorityRowMap.set(r.id, r);
          }
        }
        for (const r of allRows) {
          if (!r || !r.id || r.archived || priorityRowMap.has(r.id)) continue;
          if (priorityRowMap.size >= 280) break;
          priorityRowMap.set(r.id, r);
        }
        let archivedIncluded = 0;
        for (const r of allRows) {
          if (!r || !r.id || !r.archived || priorityRowMap.has(r.id)) continue;
          if (archivedIncluded >= 20) break;
          priorityRowMap.set(r.id, r);
          archivedIncluded++;
        }
        const selectedRows = Array.from(priorityRowMap.values());

        // Ensure recently notified threads are always prioritized in threadsMap
        const recentNotifs = [
          ...(this.lastNotification ? [this.lastNotification] : []),
          ...(Array.isArray(this.recentNotifications) ? this.recentNotifications.slice(0, 4) : [])
        ];
        for (const rn of recentNotifs) {
          if (rn && rn.threadId) {
            this.requestedThreads.set(String(rn.threadId), {
              provider: rn.provider || '',
              requestedAt: Date.now()
            });
          }
        }

        // Build threadsMap with transcripts for requested threads + top Antigravity & Claude sessions
        // Keep total payload well below Dataverse annotation.notetext 1MB (1,048,576 char) limit!
        const threadsMap = {};
        const candidateThreadMap = new Map();

        // Priority 1: Explicitly requested threads from mobile or recent notifications (keep for 15 minutes)
        const nowMs = Date.now();
        for (const [reqId, info] of Array.from(this.requestedThreads.entries())) {
          if (nowMs - (info.requestedAt || 0) > 15 * 60 * 1000) {
            this.requestedThreads.delete(reqId);
            continue;
          }
          const matchedRow = allRows.find((r) => r.id === reqId);
          candidateThreadMap.set(reqId, {
            id: reqId,
            provider: info.provider || matchedRow?.provider || '',
            maxMessages: 22,
            priority: true,
            isActive: Boolean(
              matchedRow?.open ||
                matchedRow?.active ||
                matchedRow?.status === 'working' ||
                matchedRow?.status === 'waiting'
            )
          });
        }

        // Priority 2: Top 10 Antigravity & Top 8 Claude Code sessions
        const topAgy = selectedRows
          .filter((r) => r.id && !r.draft && !r.archived && r.provider !== 'claude')
          .slice(0, 10);
        const topClaude = selectedRows
          .filter((r) => r.id && !r.draft && !r.archived && r.provider === 'claude')
          .slice(0, 8);

        for (const r of [...topAgy, ...topClaude]) {
          if (!candidateThreadMap.has(r.id)) {
            candidateThreadMap.set(r.id, {
              id: r.id,
              provider: r.provider,
              maxMessages: 14,
              priority: false,
              isActive: Boolean(
                r.open || r.active || r.status === 'working' || r.status === 'waiting'
              )
            });
          }
        }

        for (const item of candidateThreadMap.values()) {
          if (this.disposed) break;
          await new Promise((r) => setImmediate(r));
          try {
            const fullThread = await this.getThreadDetail(item.id, item.provider, {
              skipLiveContext: !item.priority && !item.isActive
            });
            const slicedMsgs = (fullThread.messages || []).slice(-item.maxMessages);
            threadsMap[item.id] = {
              ...fullThread,
              messages: slicedMsgs.map((m, idx) => {
                const isRecentTurn = idx >= slicedMsgs.length - 4;
                return {
                  ...m,
                  text: String(m.text || '').slice(0, item.priority ? 7500 : 4000),
                  thinking: String(m.thinking || '').slice(0, item.priority ? 1000 : 500),
                  latestThinking: String(m.latestThinking || '').slice(0, 450),
                  thinkingDurationSec: Number(m.thinkingDurationSec || 0),
                  turnDurationSec: Number(m.turnDurationSec || 0),
                  totalThoughtCount: Number(m.totalThoughtCount || 0),
                  thoughtBlocks: Array.isArray(m.thoughtBlocks)
                    ? m.thoughtBlocks.slice(-6).map((tb) => ({
                        id: tb.id || '',
                        durationSec: Number(tb.durationSec || 0),
                        createdAt: tb.createdAt || '',
                        text: String(tb.text || '').slice(0, item.priority ? 800 : 400)
                      }))
                    : undefined,
                  toolCalls: (m.toolCalls || []).slice(item.priority ? -18 : -10).map((tc) => ({
                    name: tc.name,
                    kind: tc.kind,
                    label: tc.label,
                    file: tc.file,
                    relPath: tc.relPath,
                    lineRange: tc.lineRange,
                    addedLines: tc.addedLines,
                    removedLines: tc.removedLines,
                    summary: String(tc.summary || '').slice(0, 140),
                    snippet: isRecentTurn ? String(tc.snippet || '').slice(0, 320) : '',
                    subagentRole: tc.subagentRole || undefined,
                    subagentType: tc.subagentType || undefined,
                    subagentPrompt: tc.subagentPrompt ? String(tc.subagentPrompt).slice(0, 260) : undefined,
                    subagentConversationId: tc.subagentConversationId || undefined
                  }))
                };
              })
            };
          } catch {}
        }

        const enrichedRows = selectedRows.map((r) => {
          const td = threadsMap[r.id];
          const compactBg = Array.isArray(r.bgTasks)
            ? r.bgTasks.slice(-8).map((bt) => ({
                id: bt.id,
                kind: bt.kind || 'task',
                subagentType: bt.subagentType || '',
                summary: String(bt.summary || '').slice(0, 140),
                command: String(bt.command || '').slice(0, 220),
                state: bt.state || 'completed',
                isDaemon: Boolean(bt.isDaemon),
                startedAt: bt.startedAt || 0,
                completedAt: bt.completedAt || 0,
                stepIndex: typeof bt.stepIndex === 'number' ? bt.stepIndex : -1
              }))
            : [];
          const baseRow = {
            ...r,
            bgTasks: compactBg,
            lastAssistantText: String(r.lastAssistantText || '').slice(0, 220)
          };
          if (!td) return baseRow;
          return {
            ...baseRow,
            model: td.model || r.model,
            contextPct: td.contextWindow?.pct ?? r.contextPct,
            usedTokens: td.contextWindow?.usedTokens ?? r.usedTokens,
            limitTokens: td.contextWindow?.limitTokens ?? r.limitTokens
          };
        });

        // Each PC's unsaved-work list travels once, on its own `device_states` entry: the shared `state` document
        // carries none (no extra copies to send, and no older copy of another PC's list for the phone to re-apply).
        const { unsavedWork: _stateUwOmit, ...fullSnapshotNoUw } = fullSnapshot;
        const stateSnapshot = {
          ...fullSnapshotNoUw,
          ...(fullSnapshot.device && typeof fullSnapshot.device === 'object'
            ? { device: withoutUnsavedWork(fullSnapshot.device) }
            : {}),
          ...(Array.isArray(fullSnapshot.devices) ? { devices: fullSnapshot.devices.map(withoutUnsavedWork) } : {}),
          rows: enrichedRows,
          lastNotification: this.lastNotification || fullSnapshot.lastNotification || null,
          recentNotifications: (this.recentNotifications || fullSnapshot.recentNotifications || []).slice(0, 15)
        };

        const workspacesDetail = this.workspacesDetailCache || {};
        if (
          !this.workspacesDetailRefreshInFlight &&
          (!this.workspacesDetailCachedAt || Date.now() - this.workspacesDetailCachedAt > 45000)
        ) {
          this.workspacesDetailRefreshInFlight = true;
          Promise.all(
            BHFIRMS_WORKSPACES.slice(0, 16).map(async (w) => {
              try {
                const detail = await inspectWorkspaceGit(w, true);
                if (detail.exists) {
                  return [
                    w.id,
                    {
                      ...detail,
                      diffPatch: String(detail.diffPatch || '').slice(0, 2000)
                    }
                  ];
                }
              } catch {}
              return null;
            })
          )
            .then((entries) => {
              const freshDetail = {};
              for (const pair of entries) {
                if (pair) freshDetail[pair[0]] = pair[1];
              }
              this.workspacesDetailCache = freshDetail;
              this.workspacesDetailCachedAt = Date.now();
            })
            .catch(() => {})
            .finally(() => {
              this.workspacesDetailRefreshInFlight = false;
            });
        }

        const localOnlyRows = enrichedRows.filter(
          (r) => !r.remotePeer && r.source !== 'cloud-relay' && r.deviceId === selfDevId
        );
        const selfPcSetup = readCachedPcSetupSummary() || null;
        const selfUnsavedWork = readFleetUnsavedWorkSummary();
        const selfDeviceObj = {
          id: selfDevId,
          name: this.deviceInfo?.name || os.hostname(),
          role: this.deviceInfo?.role || HOST_ROLE,
          hostname: os.hostname(),
          // Published so the other hosts can tell which sessions were started on this PC.
          homedir: os.homedir(),
          platform: process.platform,
          capabilities: this.deviceInfo?.capabilities || [],
          pcSetup: selfPcSetup,
          // This PC's unsaved git working folders, for the Workspaces tab of THEO Remote. Folder paths are
          // private host data: they travel only inside this authenticated store entry.
          unsavedWork: selfUnsavedWork,
          online: true,
          lastSeen: Date.now()
        };
        // The entry's `device` already carries the list; the snapshot's copy of the device leaves it out.
        const { unsavedWork: _uwOmit, ...selfSnapshotDeviceObj } = selfDeviceObj;
        // This host's own entry in the fleet map. With a store that merges the map per device the entry carries
        // every local session the snapshot selected, once; an older store gets the previous, smaller shape.
        const ownRowCap = storeHasEqualHosts ? 300 : 100;
        const selfCompactSnapshot = {
          generatedAt: Date.now(),
          device: selfSnapshotDeviceObj,
          rows: localOnlyRows.slice(0, ownRowCap),
          groups: Array.isArray(fullSnapshot.groups) ? fullSnapshot.groups : [],
          summary: fullSnapshot.summary || null,
          summaryByProvider: fullSnapshot.summaryByProvider || null,
          topSessions: Array.isArray(fullSnapshot.topSessions)
            ? fullSnapshot.topSessions.slice(0, 10)
            : [],
          accountOrder: Array.isArray(fullSnapshot.accountOrder) ? fullSnapshot.accountOrder : [],
          approvals: (fullSnapshot.approvals || []).slice(0, 30),
          workspaces: (fullSnapshot.workspaces || []).slice(0, 16),
          providers: fullSnapshot.providers || null,
          usage: fullSnapshot.usage || null,
          account: fullSnapshot.account || null,
          claudePermissionMode:
            fullSnapshot.claudePermissionMode || this.getClaudePermissionModeSnapshot()
        };
        const selfDeviceEntry = {
          device: selfDeviceObj,
          snapshot: selfCompactSnapshot,
          ...(storeHasEqualHosts ? {} : { rows: localOnlyRows.slice(0, 100) }),
          workspaces: (fullSnapshot.workspaces || []).slice(0, 16),
          updatedAt: Date.now()
        };
        const mergedDeviceStates = {
          ...(this.remoteDeviceStates || {}),
          [selfDevId]: selfDeviceEntry
        };
        this.remoteDeviceStates = mergedDeviceStates;

        // The coordinator writes every cycle; every other host writes when a command ran, its own sessions changed,
        // or 20 s have passed.
        const pcSetupSig = selfPcSetup
          ? `|pc:${selfPcSetup.okCount}/${selfPcSetup.totalCount}`
          : '';
        const localDevSig =
          localOnlyRows
            .slice(0, 20)
            .map((r) => `${r.id}:${r.status}:${r.stepCount || 0}:${r.at || 0}`)
            .join('|') + pcSetupSig + unsavedWorkSig(selfUnsavedWork);
        const shouldWriteNow =
          isCoordinator ||
          executedAny ||
          options.urgent ||
          localDevSig !== this._lastCloudLocalDevSig ||
          Date.now() - (this._lastCloudDeviceWriteAt || 0) > 20000;

        if (shouldWriteNow) {
          this._lastCloudLocalDevSig = localDevSig;
          this._lastCloudDeviceWriteAt = Date.now();

          const mergedThreads = { ...threadsMap };
          if (this.cachedRemoteThreads) {
            for (const [tid, tObj] of Object.entries(this.cachedRemoteThreads)) {
              if (!mergedThreads[tid] && Object.keys(mergedThreads).length < 28) {
                mergedThreads[tid] = tObj;
              }
            }
          }

          // Only the coordinator writes the shared `state` snapshot; every host always writes its own fleet entry.
          const shouldWriteGlobalState = isCoordinator;
          const patchObj = {
            meta: {
              v: 4,
              updatedAt: new Date().toISOString(),
              bridgeHost: os.hostname(),
              deviceId: selfDevId,
              coordinator: this.coordinatorDeviceId || '',
              port: this.port
            },
            // A store with equal hosts merges this map per device, so a host sends only its own entry and can
            // never overwrite another host's sessions. An older store replaces the map whole, so it gets all of it.
            device_states: storeHasEqualHosts ? { [selfDevId]: selfDeviceEntry } : mergedDeviceStates,
            ...(shouldWriteGlobalState
              ? {
                  state: {
                    snapshot: stateSnapshot,
                    workspacesDetail
                  }
                }
              : {}),
            threads: mergedThreads
          };
          const statePatchBody = { key: this.relayConfig.key, op: 'patch', ackOnly: true, patch: patchObj };

          await this.postStore(statePatchBody, 20000);
        }
        this.lastCloudSyncAt = Date.now();
        this.lastCloudError = '';
      }
      return { ok: true, executedAny, syncedAt: this.lastCloudSyncAt };
    } catch (err) {
      this.lastCloudError = String(err?.message || err);
      return null;
    } finally {
      this.cloudSyncInFlight = false;
      if (this.pendingUrgentCloudSync) {
        this.pendingUrgentCloudSync = false;
        setTimeout(() => {
          this.syncCloudRelay({ pushState: true }).catch(() => {});
        }, 60);
      }
    }
  }

  async handleHttpRequest(req, res) {
    if (!this.isRequestOriginAllowed(req)) {
      this.sendJson(res, 403, { ok: false, error: 'Origin not allowed' });
      return;
    }

    if (req.method === 'OPTIONS') {
      this.setCorsHeaders(res);
      res.writeHead(204);
      res.end();
      return;
    }

    const parsedUrl = new URL(req.url || '/', `http://127.0.0.1:${this.port}`);
    const pathname = parsedUrl.pathname;
    const reqToken = this.extractRequestToken(req, parsedUrl);
    const isAuthenticated = this.verifyBridgeToken(reqToken);

    if (pathname === '/api/ping') {
      if (isAuthenticated) {
        this.sendJson(res, 200, {
          ok: true,
          authenticated: true,
          service: 'THEO Remote Bridge',
          ...this.getStatus()
        });
      } else {
        this.sendJson(res, 200, {
          ok: true,
          authenticated: false,
          service: 'THEO Remote Bridge',
          version: 3,
          authRequired: true,
          listening: this.listening,
          standaloneMode: !this.vscode,
          port: this.port,
          device: {
            id: this.deviceInfo?.id || 'workstation',
            name: this.deviceInfo?.name || 'Workstation',
            role: this.deviceInfo?.role || HOST_ROLE
          }
        });
      }
      return;
    }

    if (pathname.startsWith('/api/') && !isAuthenticated) {
      this.sendJson(res, 401, {
        ok: false,
        authRequired: true,
        error: 'Unauthorized: valid THEO bridge token required'
      });
      return;
    }

    if (pathname === '/api/pairing-info' && req.method === 'GET') {
      const creds = loadTheoCredentials();
      const pairToken = buildPairTokenBase64Url(creds);
      const pwaBase = (this.relayConfig?.pwaUrl || 'https://husseinbdeir.github.io/theo/').replace(
        /#.*$/,
        ''
      );
      const pairUrl = pairToken ? `${pwaBase}#pair=${pairToken}` : '';
      const safeTok = pairToken.replace(/'/g, "''");
      const workstationCmd = pairToken
        ? `$env:THEO_PAIR_TOKEN='${safeTok}'; irm https://raw.githubusercontent.com/HusseinBdeir/theo/main/install.ps1 | iex`
        : '';
      this.sendJson(res, 200, {
        ok: true,
        pairToken,
        pairUrl,
        mobilePairUrl: pairUrl,
        workstationCmd,
        workstationBootstrapPs1: workstationCmd,
        allowLan: Boolean(creds.allowLan),
        edgeRelayUrl: this.getEffectiveEdgeUrl()
      });
      return;
    }

    if (pathname === '/api/pair-code' && req.method === 'POST') {
      let timer = null;
      try {
        const creds = loadTheoCredentials();
        const bundle = buildPairTokenBase64Url(creds);
        const bearer = deriveEdgeAuthToken(creds.effectiveEdgeSecret);
        const edgeUrl = String(this.getEffectiveEdgeUrl() || creds.edgeRelayUrl || '').trim();
        if (!bundle || !bearer || !edgeUrl) {
          this.sendJson(res, 400, {
            ok: false,
            error: 'Missing local Edge Relay credentials on this host.'
          });
          return;
        }
        const httpBase = edgeUrl
          .replace(/^wss:\/\//i, 'https://')
          .replace(/^ws:\/\//i, 'http://')
          .replace(/[?#].*$/, '')
          .replace(/\/+$/, '')
          .replace(/\/ws$/i, '')
          .replace(/\/+$/, '');
        const ctrl = new AbortController();
        timer = setTimeout(() => ctrl.abort(), 8000);
        const r = await fetch(`${httpBase}/pair/create`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${bearer}`
          },
          body: JSON.stringify({ bundle, ttlSec: 600 }),
          signal: ctrl.signal
        });
        const out = await r.json().catch(() => ({}));
        this.sendJson(res, r.ok ? 200 : r.status || 502, out);
      } catch (err) {
        this.sendJson(res, 502, {
          ok: false,
          error: String(err?.message || 'Failed to mint 6-digit pairing code')
        });
      } finally {
        if (timer) clearTimeout(timer);
      }
      return;
    }

    if (pathname === '/api/events') {
      this.setCorsHeaders(res);
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        Connection: 'keep-alive',
        'Cache-Control': 'no-cache'
      });
      res.write(`event: connected\ndata: ${JSON.stringify(this.getStatus())}\n\n`);
      this.sseClients.add(res);
      req.on('close', () => {
        this.sseClients.delete(res);
      });
      return;
    }

    if (pathname === '/api/state' && req.method === 'GET') {
      const stateObj = await this.buildFullState();
      this.sendJson(res, 200, { ok: true, state: stateObj });
      return;
    }

    if (pathname === '/api/claude-permission-mode' && req.method === 'GET') {
      this.sendJson(res, 200, {
        ok: true,
        claudePermissionMode: this.getClaudePermissionModeSnapshot()
      });
      return;
    }

    if (pathname === '/api/claude-permission-mode' && req.method === 'POST') {
      const body = await this.readJsonBody(req, 64 * 1024);
      const requestedMode = body?.defaultMode ?? body?.mode ?? body?.value ?? '';
      const out = body?.alreadyStored
        ? await this.handleIncomingEdgeClaudeMode(
            {
              defaultMode: requestedMode,
              rev: body?.rev,
              alreadyStored: true,
              loopbackFanout: Boolean(body?.loopbackFanout),
              edgeBroadcasted: Boolean(body?.edgeBroadcasted),
              skipEdgeBroadcast: Boolean(body?.skipEdgeBroadcast),
              updatedAt: body?.updatedAt,
              updatedBy: body?.updatedBy || 'THEO Remote',
              source: body?.source || 'http_api'
            },
            { fromLocalChannel: true }
          )
        : await this.setFleetClaudePermissionMode(requestedMode, {
            ...(body?.expectedRev !== undefined ? { expectedRev: body.expectedRev } : {}),
            source: body?.source || 'http_api',
            updatedBy: body?.updatedBy || 'THEO Remote',
            skipPrimaryLoopback: true
          });
      this.sendJson(res, out?.ok ? 200 : out?.statusCode || 400, out);
      return;
    }

    if (pathname === '/api/personal-ledger' && req.method === 'GET') {
      this.syncFromDiskPersonalLedger();
      this.sendJson(res, 200, { ok: true, personalLedger: this.personalLedger });
      return;
    }

    if (pathname === '/api/personal-ledger' && req.method === 'POST') {
      this.syncFromDiskPersonalLedger();
      const body = await this.readJsonBody(req);
      const incoming = body?.personalLedger || body;
      this.mergePersonalLedger(incoming);
      this.notifyStateUpdated();
      this.syncCloudRelay({ pushState: true }).catch(() => {});
      this.sendJson(res, 200, { ok: true, personalLedger: this.personalLedger });
      return;
    }

    if (pathname === '/api/ai-group-reminders' && req.method === 'POST') {
      const body = await this.readJsonBody(req);
      const inputRems = Array.isArray(body?.reminders)
        ? body.reminders
        : Array.isArray(this.personalLedger?.reminders)
          ? this.personalLedger.reminders
          : [];
      const classified = inputRems.map((r) => this.smartClassifyReminder(r));
      this.mergePersonalLedger({
        reminders: classified,
        updatedAt: Date.now()
      });
      this.notifyStateUpdated();
      this.syncCloudRelay({ pushState: true }).catch(() => {});
      this.sendJson(res, 200, {
        ok: true,
        reminders: this.personalLedger.reminders,
        personalLedger: this.personalLedger
      });
      return;
    }

    if (pathname === '/api/thread' && req.method === 'GET') {
      const id = parsedUrl.searchParams.get('id') || '';
      const provider = parsedUrl.searchParams.get('provider') || '';
      const detail = await this.getThreadDetail(id, provider);
      this.sendJson(res, 200, { ok: true, thread: detail });
      return;
    }

    if (pathname === '/api/bg-task-log' && req.method === 'GET') {
      const id = String(parsedUrl.searchParams.get('id') || parsedUrl.searchParams.get('threadId') || '').trim();
      const taskId = String(parsedUrl.searchParams.get('taskId') || '').trim();
      const providerHint = String(parsedUrl.searchParams.get('provider') || '').trim();
      const out = this.readLocalBgTaskLog(id, taskId, providerHint);
      this.sendJson(res, out.ok ? 200 : 400, out);
      return;
    }

    if (pathname === '/api/workspace' && req.method === 'GET') {
      const id = parsedUrl.searchParams.get('id') || 'theo-hub';
      const relFile = parsedUrl.searchParams.get('file') || '';
      const wsDef =
        BHFIRMS_WORKSPACES.find((w) => w.id === id) || BHFIRMS_WORKSPACES[0];
      const info = await inspectWorkspaceGit(wsDef, true);

      let fileData = null;
      if (relFile && info.exists && !isSensitivePreviewPath(relFile)) {
        const safePath = path.resolve(info.path, relFile);
        if (
          isRealPathInsideRoot(safePath, info.path) &&
          !isSensitivePreviewPath(safePath) &&
          fs.existsSync(safePath)
        ) {
          const stat = fs.statSync(safePath);
          if (stat.isFile() && stat.size <= 200 * 1024) {
            fileData = {
              path: relFile,
              size: stat.size,
              mtime: stat.mtimeMs,
              content: fs.readFileSync(safePath, 'utf8')
            };
          }
        }
      }
      this.sendJson(res, 200, { ok: true, workspace: info, file: fileData });
      return;
    }

    if (pathname === '/api/file-preview' && req.method === 'GET') {
      const out = await this.readSafeFilePreview({
        path: parsedUrl.searchParams.get('path') || parsedUrl.searchParams.get('uri') || parsedUrl.searchParams.get('file') || '',
        workspaceId: parsedUrl.searchParams.get('workspaceId') || '',
        sessionId: parsedUrl.searchParams.get('sessionId') || parsedUrl.searchParams.get('threadId') || '',
        startLine: Number(parsedUrl.searchParams.get('startLine') || 0),
        endLine: Number(parsedUrl.searchParams.get('endLine') || 0)
      });
      this.sendJson(res, out.ok ? 200 : out.status || 400, out);
      return;
    }

    if (pathname === '/api/studio-capabilities' && req.method === 'GET') {
      const out = await this.inspectStudioCapabilities({
        workspaceId: parsedUrl.searchParams.get('workspaceId') || '',
        sessionId: parsedUrl.searchParams.get('sessionId') || parsedUrl.searchParams.get('threadId') || '',
        includeDiff: parsedUrl.searchParams.get('diff') === '1'
      });
      this.sendJson(res, out.ok ? 200 : out.status || 400, out);
      return;
    }

    if (pathname === '/api/studio-check' && req.method === 'POST') {
      const body = await this.readJsonBody(req);
      const out = await this.runSafeStudioCheck({
        workspaceId: body?.workspaceId || '',
        sessionId: body?.sessionId || body?.threadId || '',
        checkId: body?.checkId || ''
      });
      this.sendJson(res, out.ok ? 200 : out.status || 400, out);
      return;
    }

    if (pathname === '/api/open-file' && req.method === 'POST') {
      const body = await this.readJsonBody(req);
      const rawTarget = String(body?.path || body?.uri || '').trim();
      if (!rawTarget) {
        this.sendJson(res, 400, { ok: false, error: 'Missing path or uri' });
        return;
      }
      if (!this.vscode) {
        this.sendJson(res, 503, { ok: false, error: 'VS Code UI host not attached' });
        return;
      }
      try {
        const epMod = require('./compat/excel-preview.cjs');
        const outcome = await epMod.openFileUriSmart(this.vscode, rawTarget);
        this.sendJson(res, 200, { ok: true, ...outcome });
      } catch (err) {
        this.sendJson(res, 500, { ok: false, error: err?.message || String(err) });
      }
      return;
    }

    if (pathname === '/api/devices' && req.method === 'GET') {
      this.sendJson(res, 200, {
        ok: true,
        self: this.deviceInfo,
        devices: this.getUnifiedFleetDevices(),
        edgeRelay: this.edgeClient ? this.edgeClient.getStatus() : null,
        activeDirectRuns: this.directRunner ? this.directRunner.getActiveRuns() : []
      });
      return;
    }

    if (pathname === '/api/edge-config' && req.method === 'POST') {
      const body = await this.readJsonBody(req);
      if (typeof body.allowLan === 'boolean') {
        try {
          saveTheoCredentials({ allowLan: body.allowLan });
          this.relayConfig.allowLan = body.allowLan;
        } catch {}
      }
      const rawNextUrl =
        body.edgeRelayUrl !== undefined ? body.edgeRelayUrl : body.url;
      const nextUrl =
        rawNextUrl !== undefined ? String(rawNextUrl || '').trim() : this.getEffectiveEdgeUrl();
      const status = await this.setEffectiveEdgeUrl(nextUrl, {
        deviceName: body.deviceName || '',
        broadcastCloud: body.broadcastCloud !== false
      });
      this.sendJson(res, 200, {
        ok: true,
        status,
        devices: this.getUnifiedFleetDevices()
      });
      return;
    }

    if (pathname === '/api/direct-send' && req.method === 'POST') {
      if (this.isTrustedLoopbackNavigation(req)) noteLocalUserActivity();
      const body = await this.readJsonBody(req);
      const out = await this.executeDirectCommand({
        ...body,
        type: 'send',
        executionMode: 'direct',
        direct: true
      });
      this.syncCloudRelay({ pushState: true }).catch(() => {});
      this.sendJson(res, 200, out);
      return;
    }

    if (pathname === '/api/yield-port' && req.method === 'POST') {
      if (!this.vscode && typeof this.onYieldPortRequested === 'function') {
        this.sendJson(res, 200, { ok: true, yielded: true });
        setImmediate(() => {
          Promise.resolve(this.onYieldPortRequested()).catch(() => {});
        });
        return;
      }
      this.sendJson(res, 200, { ok: true, yielded: false });
      return;
    }

    if (pathname === '/api/send' && req.method === 'POST') {
      if (this.isTrustedLoopbackNavigation(req)) noteLocalUserActivity();
      const body = await this.readJsonBody(req);
      const out = await this.executeDirectCommand({ ...body, type: 'send' });
      this.syncCloudRelay({ pushState: true }).catch(() => {});
      this.sendJson(res, 200, out);
      return;
    }

    if (pathname === '/api/approve' && req.method === 'POST') {
      if (this.isTrustedLoopbackNavigation(req)) noteLocalUserActivity();
      const body = await this.readJsonBody(req);
      const out = await this.executeDirectCommand({
        ...body,
        type: body?.type === 'answerQuestion' ? 'answerQuestion' : 'approve'
      });
      this.syncCloudRelay({ pushState: true }).catch(() => {});
      this.sendJson(res, 200, out);
      return;
    }

    if (pathname === '/api/session-action' && req.method === 'POST') {
      if (this.isTrustedLoopbackNavigation(req)) noteLocalUserActivity();
      const body = await this.readJsonBody(req);
      const out = await this.executeDirectCommand({
        ...body,
        type: 'sessionAction',
        subAction: body.action
      });
      this.syncCloudRelay({ pushState: true }).catch(() => {});
      this.sendJson(res, 200, out);
      return;
    }

    if (pathname === '/api/cloud-sync' && req.method === 'POST') {
      const resSync = await this.syncCloudRelay({ pushState: true });
      this.sendJson(res, 200, { ok: Boolean(resSync), sync: resSync });
      return;
    }

    if (pathname === '/api/push-register' && req.method === 'POST') {
      const body = await this.readJsonBody(req);
      const devId = body.id || body.device?.id || '';
      if ((body.disabled || body.enabled === false) && devId) {
        this.pushDevices = this.pushDevices.filter((d) => d.id !== devId);
        this.saveLocalPushRegistry();
        this.sendJson(res, 200, { ok: true, count: this.pushDevices.length });
        return;
      }
      const ok = this.upsertPushDevice(body.device || body);
      this.sendJson(res, 200, { ok, count: this.pushDevices.length });
      return;
    }

    if (pathname === '/api/push-test' && req.method === 'POST') {
      const body = await this.readJsonBody(req);
      const results = await this.broadcastPush(null, {
        title: body.title || 'THEO Remote — Bridge Push Active ⚡',
        body:
          body.body ||
          'Direct Web Push from your THEO Hub workstation bridge is active.',
        tag: `theo-bridge-test-${Date.now()}`,
        tab: body.tab || 'pulse'
      });
      this.sendJson(res, 200, { ok: true, results });
      return;
    }

    // Serve standalone Planner PWA from ~/bhfirms/command when /planner or /command is requested
    if (
      pathname === '/planner' ||
      pathname.startsWith('/planner/') ||
      pathname === '/command' ||
      pathname.startsWith('/command/')
    ) {
      const cmdRel =
        pathname === '/planner' ||
        pathname === '/planner/' ||
        pathname === '/command' ||
        pathname === '/command/'
          ? 'index.html'
          : pathname.replace(/^\/(planner|command)\/+/, '');
      const safeCmdTarget = path.resolve(this.cmdPwaRoot, cmdRel);
      if (
        !isSensitivePreviewPath(cmdRel) &&
        isRealPathInsideRoot(safeCmdTarget, this.cmdPwaRoot) &&
        fs.existsSync(safeCmdTarget) &&
        fs.statSync(safeCmdTarget).isFile()
      ) {
        const ext = path.extname(safeCmdTarget).toLowerCase();
        const mime = MIME_TYPES[ext] || 'application/octet-stream';
        this.setCorsHeaders(res);
        res.writeHead(200, { 'Content-Type': mime });
        fs.createReadStream(safeCmdTarget).pipe(res);
        return;
      }
    }

    // Serve static PWA files from ~/bhfirms/theo
    const relPath = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
    const safeTarget = path.resolve(this.pwaRoot, relPath);
    if (
      !isSensitivePreviewPath(relPath) &&
      isRealPathInsideRoot(safeTarget, this.pwaRoot) &&
      fs.existsSync(safeTarget) &&
      fs.statSync(safeTarget).isFile()
    ) {
      const ext = path.extname(safeTarget).toLowerCase();
      const mime = MIME_TYPES[ext] || 'application/octet-stream';
      if (
        (pathname === '/' || pathname === '/index.html') &&
        this.isTrustedLoopbackNavigation(req)
      ) {
        try {
          let html = fs.readFileSync(safeTarget, 'utf8');
          const bootPayload = {
            token: this.getDerivedBridgeToken(),
            edgeRelayUrl: this.getEffectiveEdgeUrl()
          };
          const safeJson = JSON.stringify(bootPayload).replace(/</g, '\\u003c');
          const scriptTag = `<script>window.__THEO_LOCAL_BOOT__=${safeJson};</script>`;
          html = html.includes('</head>')
            ? html.replace('</head>', `${scriptTag}\n</head>`)
            : `${scriptTag}\n${html}`;
          const buf = Buffer.from(html, 'utf8');
          this.setCorsHeaders(res);
          res.writeHead(200, {
            'Content-Type': mime,
            'Content-Length': buf.length,
            'Cache-Control': 'no-store, no-cache, must-revalidate'
          });
          res.end(buf);
          return;
        } catch {}
      }
      this.setCorsHeaders(res);
      res.writeHead(200, { 'Content-Type': mime });
      fs.createReadStream(safeTarget).pipe(res);
      return;
    }

    if (pathname === '/favicon.ico') {
      const fallbackIco = path.join(__dirname, 'resources', 'theo.ico');
      if (fs.existsSync(fallbackIco) && fs.statSync(fallbackIco).isFile()) {
        this.setCorsHeaders(res);
        res.writeHead(200, { 'Content-Type': 'image/x-icon' });
        fs.createReadStream(fallbackIco).pipe(res);
        return;
      }
    }

    if (
      (pathname === '/' || pathname === '/index.html') &&
      this.isTrustedLoopbackNavigation(req)
    ) {
      const pwaFallback = 'https://husseinbdeir.github.io/theo/';
      res.writeHead(302, {
        Location: pwaFallback,
        'Cache-Control': 'no-store, no-cache, must-revalidate'
      });
      res.end();
      return;
    }

    this.sendJson(res, 404, { ok: false, error: 'Not found' });
  }

  dispose() {
    this.disposed = true;
    if (this.startupSyncTimer) {
      clearTimeout(this.startupSyncTimer);
      this.startupSyncTimer = null;
    }
    if (this.urgentSyncDebounceTimer) {
      clearTimeout(this.urgentSyncDebounceTimer);
      this.urgentSyncDebounceTimer = null;
    }
    if (this.cloudSyncTimer) {
      clearInterval(this.cloudSyncTimer);
      this.cloudSyncTimer = null;
    }
    if (this.standbyBindTimer) {
      clearInterval(this.standbyBindTimer);
      this.standbyBindTimer = null;
    }
    if (this.edgeStatePushTimer) {
      clearTimeout(this.edgeStatePushTimer);
      this.edgeStatePushTimer = null;
    }
    if (this.edgeClient) {
      try {
        this.edgeClient.stop();
      } catch {}
    }
    if (this.wsHub) {
      try {
        this.wsHub.closeAll();
      } catch {}
      this.wsHub = null;
    }
    for (const client of this.sseClients) {
      try {
        client.end();
      } catch {}
    }
    this.sseClients.clear();
    if (this.server) {
      try {
        this.server.closeAllConnections?.();
      } catch {}
      try {
        this.server.close();
      } catch {}
      this.server = null;
      this.listening = false;
    }
  }
}

module.exports = {
  TheoRemoteBridge,
  hotSwapChangeFlags,
  BHFIRMS_WORKSPACES,
  formatModelDisplayName,
  resolveAntigravityPlanModelEnum,
  inferMaxContextTokens,
  readTranscriptTailUtf8,
  parseAntigravityTranscriptFile,
  parseClaudeTranscriptFile,
  buildEstimatedContextStatus,
  inspectWorkspaceGit,
  loadRelayConfig,
  decideFleetDuty,
  classifyQueuedCommand,
  CLAIM_INFLIGHT_LEASE_MS,
  beginCloudCommandLease,
  completeCloudCommandOnce,
  isCloudCommandSealed,
  claimCloudCommandOnce,
  unclaimCloudCommand,
  signVapidNode,
  encryptWebPushNode,
  collectHighUsageQuotaAlerts,
  hasQuotaAlertForWindow,
  isSensitivePreviewPath,
  parseFileTargetAndLineRange,
  discoverWorkspaceChecks,
  discoverAvailableSkills,
  probeLocalDevPorts,
  parseCheckDiagnostics
};

