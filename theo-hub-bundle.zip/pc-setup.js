'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');

const STEP_ID_RE = /^[a-z0-9][a-z0-9_-]{0,63}$/;
const DEFAULT_CHECK_TTL_MS = 5 * 60 * 1000;
const TOAST_COOLDOWN_MS = 12 * 60 * 60 * 1000;

let latestLocalView = null;
let latestPublicSummary = null;
let lastDiskReadAt = 0;
let lastWatchSig = '';
let lastCheckedAt = 0;
let checkInFlight = null;
let applyInFlight = false;

function getFileMtimeMs(filePath) {
  try {
    return Math.floor(fs.statSync(filePath).mtimeMs);
  } catch {
    return 0;
  }
}

function resolveEffectiveHome(opts = {}) {
  const env = opts.env || process.env;
  const sandbox = String(env.THEO_SETUP_HOME || env.THEO_GUARD_HOME || '').trim();
  return String(opts.homeDir || sandbox || os.homedir()).trim();
}

function resolveStatusCachePath(opts = {}) {
  if (opts.cachePath) return String(opts.cachePath);
  return path.join(resolveEffectiveHome(opts), '.claude', '.theo-pc-setup-status.json');
}

function resolveToastStampPath(opts = {}) {
  if (opts.stampPath) return String(opts.stampPath);
  return path.join(resolveEffectiveHome(opts), '.claude', '.theo-pc-setup-toast-stamp.json');
}

function resolveTheoMemoryRoot(opts = {}) {
  const env = opts.env || process.env;
  const homeDir = resolveEffectiveHome(opts);
  const explicit = String(opts.memoryRoot || env.THEO_MEMORY_ROOT || '').trim();
  if (explicit) {
    if (fs.existsSync(path.join(explicit, 'THEO.md'))) {
      return explicit;
    }
    return '';
  }
  // THEO memory lives only at ~/bhfirms/memory (moved off OneDrive 2026-11-11);
  // the old OneDrive folder holds only MOVED.txt and is never consulted.
  const bhfMem = path.join(homeDir, 'bhfirms', 'memory');
  if (fs.existsSync(path.join(bhfMem, 'THEO.md'))) {
    return bhfMem;
  }
  return '';
}

function isRealPythonBinary(exePath) {
  const s = String(exePath || '').trim();
  if (!s) return false;
  if (/\\windowsapps\\/i.test(s) || /\/windowsapps\//i.test(s)) return false;
  try {
    return fs.existsSync(s) && fs.statSync(s).isFile();
  } catch {
    return false;
  }
}

function findPythonExecutable(opts = {}) {
  if (Object.prototype.hasOwnProperty.call(opts, 'pythonExe')) {
    return isRealPythonBinary(opts.pythonExe) ? String(opts.pythonExe) : '';
  }
  const env = opts.env || process.env;
  const homeDir = resolveEffectiveHome(opts);
  const localAppData = String(env.LOCALAPPDATA || path.join(homeDir, 'AppData', 'Local'));
  const directCandidates = [
    path.join(homeDir, '.local', 'python312', 'python.exe'),
    path.join(os.homedir(), '.local', 'python312', 'python.exe'),
    path.join(localAppData, 'Programs', 'Python', 'Python314', 'python.exe'),
    path.join(localAppData, 'Programs', 'Python', 'Python313', 'python.exe'),
    path.join(localAppData, 'Programs', 'Python', 'Python312', 'python.exe'),
    'C:\\Python314\\python.exe',
    'C:\\Python313\\python.exe',
    'C:\\Python312\\python.exe'
  ];
  for (const cand of directCandidates) {
    if (isRealPythonBinary(cand)) return cand;
  }
  const pathDirs = String(env.PATH || '').split(path.delimiter);
  const binNames = process.platform === 'win32' ? ['python.exe', 'python3.exe'] : ['python3', 'python'];
  for (const dir of pathDirs) {
    if (!dir) continue;
    for (const name of binNames) {
      const full = path.join(dir.trim(), name);
      if (isRealPythonBinary(full)) return full;
    }
  }
  return '';
}

function findPowerShellExecutable(opts = {}) {
  const env = opts.env || process.env;
  const sysRoot = String(env.SystemRoot || 'C:\\Windows');
  const winPs = path.join(sysRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  if (fs.existsSync(winPs)) return winPs;
  return process.platform === 'win32' ? 'powershell.exe' : 'pwsh';
}

function computePcSetupWatchSig(memoryRoot, statusCachePath = '') {
  if (!memoryRoot) return '';
  const adminDir = path.join(memoryRoot, 'Admin');
  const parts = [
    getFileMtimeMs(path.join(memoryRoot, 'THEO.md')),
    getFileMtimeMs(path.join(adminDir, 'pc-setup-manifest.json')),
    getFileMtimeMs(path.join(adminDir, 'theo-pc-setup.py')),
    getFileMtimeMs(path.join(adminDir, 'bhfirms-memory-guard.py')),
    getFileMtimeMs(path.join(adminDir, 'bhfirms-memory-git.py')),
    getFileMtimeMs(path.join(adminDir, 'theo-memory-cloud.cjs')),
    getFileMtimeMs(path.join(adminDir, 'claude-automode-rules.json')),
    getFileMtimeMs(path.join(adminDir, 'claude-permission-mode.json')),
    getFileMtimeMs(path.join(adminDir, 'theo-hub-bundle.zip')),
    statusCachePath ? getFileMtimeMs(statusCachePath) : 0
  ];
  const dropinDir = path.join(adminDir, 'pc-setup.d');
  try {
    if (fs.existsSync(dropinDir)) {
      const names = fs
        .readdirSync(dropinDir)
        .filter((n) => n.toLowerCase().endsWith('.json'))
        .sort();
      for (const name of names) {
        parts.push(`${name}:${getFileMtimeMs(path.join(dropinDir, name))}`);
      }
    }
  } catch {}
  return parts.join('|');
}

function scrubLocalPathsForDisplay(text, homeDir, memoryRoot) {
  let out = String(text || '').trim();
  if (!out) return '';
  const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  if (memoryRoot) {
    const slashRoot = memoryRoot.replace(/\\/g, '/');
    out = out.replace(new RegExp(escapeRe(memoryRoot), 'gi'), 'THEO');
    out = out.replace(new RegExp(escapeRe(slashRoot), 'gi'), 'THEO');
  }
  if (homeDir) {
    const slashHome = homeDir.replace(/\\/g, '/');
    out = out.replace(new RegExp(escapeRe(homeDir), 'gi'), '~');
    out = out.replace(new RegExp(escapeRe(slashHome), 'gi'), '~');
  }
  return out.slice(0, 220);
}

function sanitizePublicPcSetupSummary(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const totalCount = Math.max(0, Math.min(64, Math.floor(Number(raw.totalCount || 0))));
  if (!totalCount) return null;
  const okCount = Math.max(0, Math.min(totalCount, Math.floor(Number(raw.okCount || 0))));
  const rawPending = Array.isArray(raw.pending) ? raw.pending : [];
  const cleanPending = [];
  for (const item of rawPending) {
    if (!item || typeof item !== 'object') continue;
    const id = String(item.id || '').trim();
    if (!STEP_ID_RE.test(id)) continue;
    const rawName = String(item.name || item.title || id)
      .replace(/[\r\n\t]+/g, ' ')
      .trim()
      .slice(0, 90);
    // Never include host file paths in public fleet metadata
    const safeName = /[a-zA-Z]:\\|\/Users\/|\/home\//.test(rawName) ? id : rawName;
    cleanPending.push({ id, name: safeName || id });
    if (cleanPending.length >= 24) break;
  }
  const pendingCount = Math.max(
    cleanPending.length,
    Math.min(totalCount, Math.floor(Number(raw.pendingCount ?? totalCount - okCount)))
  );
  const ready = Boolean(raw.ready) && pendingCount === 0 && okCount === totalCount;
  return {
    checkedAt: Math.max(0, Math.floor(Number(raw.checkedAt || Date.now()))),
    ready,
    okCount,
    totalCount,
    pendingCount: ready ? 0 : pendingCount,
    pending: ready ? [] : cleanPending
  };
}

function writeJsonAtomic(filePath, data) {
  const dir = path.dirname(filePath);
  fs.mkdirSync(dir, { recursive: true });
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  try {
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2) + '\n', 'utf8');
    fs.renameSync(tmp, filePath);
  } finally {
    try {
      if (fs.existsSync(tmp)) fs.unlinkSync(tmp);
    } catch {}
  }
}

function readCachedPcSetupSummary(opts = {}) {
  const custom = Boolean(opts.cachePath || opts.homeDir || opts.env);
  const now = Date.now();
  if (!custom && latestPublicSummary && now - lastDiskReadAt < 2000) {
    return latestPublicSummary;
  }
  const cachePath = resolveStatusCachePath(opts);
  try {
    if (!fs.existsSync(cachePath)) return custom ? null : latestPublicSummary;
    const parsed = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
    const sanitized = sanitizePublicPcSetupSummary(parsed);
    if (!custom) {
      latestPublicSummary = sanitized;
      lastDiskReadAt = now;
    }
    return sanitized;
  } catch {
    return custom ? null : latestPublicSummary;
  }
}

function getLocalPcSetupView(opts = {}) {
  const custom = Boolean(opts.cachePath || opts.homeDir || opts.env);
  if (custom || !latestLocalView) {
    const pub = readCachedPcSetupSummary(opts);
    if (!pub) {
      return {
        available: false,
        applying: Boolean(applyInFlight),
        checkedAt: 0,
        ready: true,
        okCount: 0,
        totalCount: 0,
        pendingCount: 0,
        pending: [],
        steps: []
      };
    }
    return {
      available: true,
      applying: Boolean(applyInFlight),
      checkedAt: pub.checkedAt,
      ready: pub.ready,
      okCount: pub.okCount,
      totalCount: pub.totalCount,
      pendingCount: pub.pendingCount,
      pending: pub.pending.map((p) => ({ id: p.id, title: p.name, userTerminal: false })),
      steps: []
    };
  }
  return {
    ...latestLocalView,
    applying: Boolean(applyInFlight)
  };
}

function execFileAsync(exe, args, options) {
  return new Promise((resolve) => {
    execFile(exe, args, options, (error, stdout, stderr) => {
      resolve({
        error,
        code: error && typeof error.code === 'number' ? error.code : error ? 1 : 0,
        stdout: String(stdout || ''),
        stderr: String(stderr || '')
      });
    });
  });
}

function buildManifestFallbackSteps(memoryRoot) {
  const steps = [];
  const seen = new Set();
  const pushStep = (raw, summaryDefault) => {
    if (!raw || typeof raw !== 'object') return;
    const id = String(raw.id || '').trim();
    if (!STEP_ID_RE.test(id) || seen.has(id)) return;
    seen.add(id);
    const title = String(raw.title || id).replace(/[\r\n\t]+/g, ' ').trim().slice(0, 90);
    const summary =
      id === 'runtimes'
        ? 'Python 3.12, Node.js 22 and Git will be installed automatically'
        : summaryDefault;
    steps.push({ id, title, ok: false, summary, userTerminal: Boolean(raw.requiresUserTerminal) });
  };
  try {
    const manPath = path.join(memoryRoot, 'Admin', 'pc-setup-manifest.json');
    if (fs.existsSync(manPath)) {
      const man = JSON.parse(fs.readFileSync(manPath, 'utf8'));
      for (const s of Array.isArray(man?.steps) ? man.steps : []) {
        pushStep(s, 'Ready to install once core runtimes are bootstrapped');
      }
    }
  } catch {}
  try {
    const dropDir = path.join(memoryRoot, 'Admin', 'pc-setup.d');
    if (fs.existsSync(dropDir)) {
      const files = fs
        .readdirSync(dropDir)
        .filter((f) => f.endsWith('.json'))
        .sort();
      for (const f of files) {
        try {
          const dj = JSON.parse(fs.readFileSync(path.join(dropDir, f), 'utf8'));
          const items = Array.isArray(dj?.steps) ? dj.steps : dj?.id ? [dj] : [];
          for (const s of items) {
            pushStep(s, 'Pending first-time setup on this PC');
          }
        } catch {}
      }
    }
  } catch {}
  return steps;
}

async function checkPcSetupStatus(opts = {}) {
  const env = opts.env || process.env;
  if (env.THEO_SMOKE_TEST === '1' && !opts.allowInSmokeTest) {
    return getLocalPcSetupView(opts);
  }
  const memoryRoot = resolveTheoMemoryRoot(opts);
  const homeDir = resolveEffectiveHome(opts);
  const statusCachePath = resolveStatusCachePath(opts);
  const customSandbox = Boolean(
    opts.homeDir ||
      opts.memoryRoot ||
      opts.cachePath ||
      opts.env ||
      Object.prototype.hasOwnProperty.call(opts, 'pythonExe')
  );
  if (!memoryRoot) {
    const checkedAt = Date.now();
    const bootstrapStep = {
      id: 'memory-bootstrap',
      title: 'Bootstrap ~/bhfirms/memory from Cloudflare Vault',
      ok: false,
      summary: 'Click Apply Setup (or wait ~60s for keepalive) to pull ~/bhfirms/memory from Cloudflare',
      userTerminal: false
    };
    const localView = {
      available: true,
      applying: Boolean(applyInFlight),
      checkedAt,
      ready: false,
      okCount: 0,
      totalCount: 1,
      pendingCount: 1,
      pending: [{ id: bootstrapStep.id, title: bootstrapStep.title, userTerminal: false }],
      steps: [bootstrapStep]
    };
    const pubSummary = sanitizePublicPcSetupSummary({
      checkedAt,
      ready: false,
      okCount: 0,
      totalCount: 1,
      pendingCount: 1,
      pending: [{ id: bootstrapStep.id, name: bootstrapStep.title }]
    });
    if (pubSummary) {
      try {
        writeJsonAtomic(statusCachePath, pubSummary);
      } catch {}
    }
    if (!customSandbox) {
      latestLocalView = localView;
      latestPublicSummary = pubSummary;
      lastDiskReadAt = checkedAt;
      lastWatchSig = '';
      lastCheckedAt = checkedAt;
    }
    return localView;
  }
  const setupPy = path.join(memoryRoot, 'Admin', 'theo-pc-setup.py');
  const manifestPath = path.join(memoryRoot, 'Admin', 'pc-setup-manifest.json');
  if (!fs.existsSync(manifestPath)) {
    return getLocalPcSetupView(opts);
  }

  const now = Date.now();
  const watchSig = computePcSetupWatchSig(memoryRoot, statusCachePath);
  const ttlMs = typeof opts.ttlMs === 'number' ? opts.ttlMs : DEFAULT_CHECK_TTL_MS;

  if (
    !opts.force &&
    !customSandbox &&
    latestLocalView &&
    watchSig === lastWatchSig &&
    now - lastCheckedAt < ttlMs
  ) {
    return getLocalPcSetupView();
  }

  if (!customSandbox && checkInFlight) {
    return checkInFlight;
  }

  const pyExe = findPythonExecutable(opts);

  const finalizeCheckResult = (steps, parsedOk) => {
    const pending = [];
    let okCount = 0;
    for (const s of steps) {
      if (s.ok) okCount += 1;
      else pending.push({ id: s.id, title: s.title, userTerminal: Boolean(s.userTerminal) });
    }
    const totalCount = steps.length;
    const pendingCount = pending.length;
    const ready = Boolean(parsedOk) && pendingCount === 0 && totalCount > 0;
    const checkedAt = Date.now();
    const localView = {
      available: totalCount > 0,
      applying: Boolean(applyInFlight),
      checkedAt,
      ready,
      okCount,
      totalCount,
      pendingCount,
      pending,
      steps
    };
    const pubSummary = sanitizePublicPcSetupSummary({
      checkedAt,
      ready,
      okCount,
      totalCount,
      pendingCount,
      pending: pending.map((p) => ({ id: p.id, name: p.title }))
    });
    if (pubSummary) {
      try {
        writeJsonAtomic(statusCachePath, pubSummary);
      } catch {}
    }
    if (!customSandbox) {
      latestLocalView = localView;
      latestPublicSummary = pubSummary;
      lastDiskReadAt = checkedAt;
      lastWatchSig = computePcSetupWatchSig(memoryRoot, statusCachePath);
      lastCheckedAt = checkedAt;
    }
    return localView;
  };

  if (!pyExe || !fs.existsSync(setupPy)) {
    const fallbackSteps = buildManifestFallbackSteps(memoryRoot);
    if (!fallbackSteps.length) {
      return getLocalPcSetupView(opts);
    }
    return finalizeCheckResult(fallbackSteps, false);
  }

  const runCheck = async () => {
    const childEnv = { ...env };
    if (opts.homeDir) childEnv.THEO_SETUP_HOME = String(opts.homeDir);
    if (opts.memoryRoot) childEnv.THEO_MEMORY_ROOT = String(opts.memoryRoot);
    const res = await execFileAsync(pyExe, [setupPy, '--check', '--json'], {
      timeout: opts.timeoutMs || 20000,
      windowsHide: true,
      maxBuffer: 1024 * 1024,
      env: childEnv
    });
    const trimmed = res.stdout.trim();
    if (!trimmed) {
      return getLocalPcSetupView();
    }
    let parsed = null;
    try {
      parsed = JSON.parse(trimmed);
    } catch {
      return getLocalPcSetupView();
    }
    if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.steps)) {
      return getLocalPcSetupView();
    }

    const steps = [];
    for (const s of parsed.steps) {
      if (!s || typeof s !== 'object') continue;
      const id = String(s.id || '').trim();
      if (!STEP_ID_RE.test(id)) continue;
      const title = String(s.title || id).replace(/[\r\n\t]+/g, ' ').trim().slice(0, 90);
      const ok = Boolean(s.ok);
      const userTerminal = Boolean(s.user_terminal || s.blocked_in_session);
      const summary = scrubLocalPathsForDisplay(s.summary || '', homeDir, memoryRoot);
      steps.push({ id, title, ok, summary, userTerminal });
    }

    return finalizeCheckResult(steps, Boolean(parsed.ok));
  };

  if (customSandbox) {
    return runCheck();
  }
  checkInFlight = runCheck().finally(() => {
    checkInFlight = null;
  });
  return checkInFlight;
}

function shouldPromptPcSetupToast(view, opts = {}) {
  if (!view || !view.available || view.ready || !view.pendingCount || view.applying) {
    return false;
  }
  const pendingKey = (view.pending || [])
    .map((p) => p.id)
    .filter((id) => STEP_ID_RE.test(id))
    .sort()
    .join(',');
  if (!pendingKey) return false;

  const stampPath = resolveToastStampPath(opts);
  const cooldownMs = typeof opts.cooldownMs === 'number' ? opts.cooldownMs : TOAST_COOLDOWN_MS;
  const now = typeof opts.now === 'number' ? opts.now : Date.now();
  try {
    if (fs.existsSync(stampPath)) {
      const prev = JSON.parse(fs.readFileSync(stampPath, 'utf8'));
      if (
        prev &&
        prev.pendingKey === pendingKey &&
        now - Number(prev.shownAt || 0) < cooldownMs
      ) {
        return false;
      }
    }
  } catch {}
  return true;
}

function recordPcSetupToastShown(view, opts = {}) {
  if (!view || !Array.isArray(view.pending)) return;
  const pendingKey = view.pending
    .map((p) => p.id)
    .filter((id) => STEP_ID_RE.test(id))
    .sort()
    .join(',');
  if (!pendingKey) return;
  try {
    writeJsonAtomic(resolveToastStampPath(opts), {
      pendingKey,
      shownAt: typeof opts.now === 'number' ? opts.now : Date.now()
    });
  } catch {}
}

async function applyPcSetupFromTrustedUi(opts = {}) {
  const { vscode, onStateChange } = opts;
  if (applyInFlight) {
    return { ok: false, busy: true, view: getLocalPcSetupView() };
  }
  let memoryRoot = resolveTheoMemoryRoot(opts);
  if (!memoryRoot && !opts.memoryRoot) {
    try {
      const cloudSync = require('./scripts/memory_cloud_sync.cjs');
      const env = opts.env || process.env;
      const homeDir = resolveEffectiveHome(opts);
      await cloudSync.runCloudSync({
        mode: 'bootstrap',
        homeDir,
        cloudUrl: env.THEO_MEMORY_CLOUD_URL || undefined,
        edgeAccessKey: env.THEO_EDGE_KEY || undefined
      });
      memoryRoot = resolveTheoMemoryRoot(opts);
    } catch {}
  }
  if (!memoryRoot) {
    return { ok: false, error: 'THEO folder not found on this PC.', view: getLocalPcSetupView(opts) };
  }
  const setupPs1 = path.join(memoryRoot, 'Admin', 'Setup-THEO-PC.ps1');
  if (!fs.existsSync(setupPs1)) {
    return { ok: false, error: 'Setup-THEO-PC.ps1 not found in Admin.', view: getLocalPcSetupView() };
  }

  let cleanOnly = '';
  if (opts.only) {
    const parts = String(opts.only)
      .split(',')
      .map((x) => x.trim())
      .filter((x) => STEP_ID_RE.test(x));
    if (!parts.length) {
      return { ok: false, error: 'Invalid setup step id.', view: getLocalPcSetupView() };
    }
    cleanOnly = parts.join(',');
  }

  applyInFlight = true;
  try {
    onStateChange?.(getLocalPcSetupView());
  } catch {}

  const runTask = async () => {
    const psExe = findPowerShellExecutable(opts);
    const args = [
      '-NoProfile',
      '-ExecutionPolicy',
      'Bypass',
      '-File',
      setupPs1,
      '-Headless'
    ];
    if (cleanOnly) {
      args.push('-Only', cleanOnly);
    }
    const childEnv = { ...(opts.env || process.env) };
    delete childEnv.CLAUDECODE;
    delete childEnv.CLAUDE_CODE_ENTRYPOINT;
    if (opts.homeDir) childEnv.THEO_SETUP_HOME = String(opts.homeDir);
    if (opts.memoryRoot) childEnv.THEO_MEMORY_ROOT = String(opts.memoryRoot);

    const execRes = await execFileAsync(psExe, args, {
      timeout: opts.timeoutMs || 180000,
      windowsHide: true,
      maxBuffer: 2 * 1024 * 1024,
      env: childEnv
    });
    applyInFlight = false;
    const view = await checkPcSetupStatus({
      ...opts,
      force: true
    });
    const ok = execRes.code === 0 && Boolean(view?.ready || cleanOnly);
    let errorMsg = '';
    if (!ok) {
      const homeDir = resolveEffectiveHome(opts);
      const rawTail =
        String(execRes.stderr || execRes.stdout || '')
          .split(/\r?\n/)
          .map((l) => l.trim())
          .filter(Boolean)
          .pop() || `PC setup exited with code ${execRes.code}.`;
      errorMsg = scrubLocalPathsForDisplay(rawTail, homeDir, memoryRoot);
    }
    return {
      ok,
      ...(errorMsg ? { error: errorMsg } : {}),
      exitCode: execRes.code,
      stdout: execRes.stdout,
      stderr: execRes.stderr,
      view
    };
  };

  try {
    let result;
    if (vscode?.window?.withProgress) {
      result = await vscode.window.withProgress(
        {
          location: vscode.ProgressLocation.Notification,
          title: 'THEO: Applying PC setup updates…',
          cancellable: false
        },
        runTask
      );
    } else {
      result = await runTask();
    }
    try {
      onStateChange?.(getLocalPcSetupView());
    } catch {}
    return result;
  } finally {
    applyInFlight = false;
    try {
      onStateChange?.(getLocalPcSetupView());
    } catch {}
  }
}

module.exports = {
  resolveTheoMemoryRoot,
  findPythonExecutable,
  computePcSetupWatchSig,
  sanitizePublicPcSetupSummary,
  readCachedPcSetupSummary,
  getLocalPcSetupView,
  checkPcSetupStatus,
  shouldPromptPcSetupToast,
  recordPcSetupToastShown,
  applyPcSetupFromTrustedUi
};
