const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');

const STATE_STORAGE_KEY = 'antigravity-hub.state.v1';
const GROUP_COLOR_SWATCHES = ['blue', 'green', 'amber', 'purple', 'rose', 'teal'];

function getDefaultStateBackupPath() {
  return path.join(os.homedir(), '.claude', '.theo-hub-state.json');
}

function makeGroupId() {
  if (typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `grp-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
}

function defaultState() {
  return {
    baseline: 0,
    customTitles: {},
    archivedIds: [],
    unarchivedAt: {},
    unreadIds: [],
    seenTurnTimestamps: {},
    groups: [],
    threadGroups: {},
    unassignedGroupThreads: {},
    deletedGroups: [],
    updatedAt: 0,
    preferences: {
      scope: 'all',
      providerFilter: 'all',
      statusFilter: 'all',
      tabFilter: 'all',
      sortBy: 'newest',
      groupBy: 'status',
      usageWindow: '5h',
      autoArchiveInactiveDays: 14,
      accountSectionCollapsed: false,
      antigravityUsageCollapsed: false,
      claudeUsageCollapsed: false,
      hideThirdPartyQuota: false,
      hideClaudeDesktopSessions: false,
      collapsedAccounts: {},
      bgTasksSectionCollapsed: false,
      sessionSectionCollapsed: false,
      activeCollapsed: false,
      recentCollapsed: false,
      notifyOnComplete: true,
      notifyOnWaiting: true,
      notifySound: true,
      onlyNotifyBackground: true
    }
  };
}

// Same on every host: groups the other hosts published, and the group each of their sessions sits in, are shown
// here too. `snap` is the peer-only snapshot ({ groups, rows }) from the fleet cache. A group deleted on this host is
// never brought back by another host that still has it, and a group this host already has under the same name is
// reused instead of being shown twice.
//
// What comes from other hosts is an overlay: it is shown here but belongs to the host that published it. The
// overlay is recorded on the state object (PEER_OVERLAY) so that write() leaves it out of what this host stores.
// A group therefore follows its owner: delete or move it there and it goes or moves here too. An overlay group
// becomes this host's own only when the user changes it here or files one of this host's sessions into it.
const PEER_OVERLAY = Symbol.for('theo.hubState.peerOverlay');

function groupFingerprint(g) {
  return JSON.stringify([g.id, g.name, g.color, Boolean(g.collapsed)]);
}

function mergePeerGroups(result, snap) {
  if (!result || !snap || typeof snap !== 'object') return result;
  const overlay = { groups: new Map(), threads: new Map() };
  Object.defineProperty(result, PEER_OVERLAY, { value: overlay, enumerable: false, configurable: true, writable: true });
  if (!Array.isArray(result.groups)) result.groups = [];
  if (!result.threadGroups || typeof result.threadGroups !== 'object') result.threadGroups = {};
  const unassigned =
    result.unassignedGroupThreads && typeof result.unassignedGroupThreads === 'object'
      ? result.unassignedGroupThreads
      : {};
  const deleted = Array.isArray(result.deletedGroups) ? result.deletedGroups : [];
  const existingGroupIds = new Set(result.groups.map((g) => g.id));
  const localIdByName = new Map(
    result.groups
      .map((g) => [String(g.name || '').trim().toLowerCase(), g.id])
      .filter(([nameLow]) => Boolean(nameLow))
  );
  const tombstoneIds = new Set(deleted.map((d) => d.id).filter(Boolean));
  const tombstoneNames = new Set(
    deleted.map((d) => String(d.name || '').trim().toLowerCase()).filter(Boolean)
  );
  // Other host's group id -> the group id it is shown under here ('' = deleted here, show ungrouped).
  const groupAlias = new Map();
  for (const g of Array.isArray(snap.groups) ? snap.groups : []) {
    if (!g || !g.id) continue;
    if (existingGroupIds.has(g.id)) {
      groupAlias.set(g.id, g.id);
      continue;
    }
    const nameLow = String(g.name || '').trim().toLowerCase();
    if (tombstoneIds.has(g.id) || (nameLow && tombstoneNames.has(nameLow))) {
      groupAlias.set(g.id, '');
      continue;
    }
    if (nameLow && localIdByName.has(nameLow)) {
      groupAlias.set(g.id, localIdByName.get(nameLow));
      continue;
    }
    existingGroupIds.add(g.id);
    if (nameLow) localIdByName.set(nameLow, g.id);
    groupAlias.set(g.id, g.id);
    const shown = {
      id: g.id,
      name: g.name || 'Group',
      color: g.color || 'blue',
      collapsed: Boolean(g.collapsed)
    };
    result.groups.push(shown);
    overlay.groups.set(g.id, groupFingerprint(shown));
  }
  for (const r of Array.isArray(snap.rows) ? snap.rows : []) {
    if (!r || !r.id || !r.group) continue;
    if (result.threadGroups[r.id] || unassigned[r.id]) continue;
    const localGroupId = groupAlias.has(r.group)
      ? groupAlias.get(r.group)
      : existingGroupIds.has(r.group)
        ? r.group
        : '';
    if (localGroupId) {
      result.threadGroups[r.id] = localGroupId;
      overlay.threads.set(r.id, localGroupId);
    }
  }
  return result;
}

// The state this host stores: `state` without what mergePeerGroups overlaid from other hosts. Returns `state`
// itself when it carries no overlay.
function withoutPeerOverlay(state) {
  const overlay = state && typeof state === 'object' ? state[PEER_OVERLAY] : null;
  if (!overlay || (overlay.groups.size === 0 && overlay.threads.size === 0)) return state;
  const threadGroups = { ...(state.threadGroups || {}) };
  for (const [threadId, groupId] of overlay.threads) {
    if (threadGroups[threadId] === groupId) delete threadGroups[threadId];
  }
  const usedGroupIds = new Set(Object.values(threadGroups));
  const groups = (Array.isArray(state.groups) ? state.groups : []).filter((g) => {
    const shownAs = g ? overlay.groups.get(g.id) : undefined;
    if (shownAs === undefined) return true;
    if (usedGroupIds.has(g.id)) return true;
    return groupFingerprint(g) !== shownAs;
  });
  return { ...state, groups, threadGroups };
}

let _peerGroupsOverlayCache = {
  path: '',
  mtimeMs: -1,
  size: -1,
  peerOnly: false,
  overlay: null
};

class HubStateStore {
  constructor(memento, options = {}) {
    this.memento = memento;
    this.diskBackupPath = options.diskBackup
      ? options.diskBackupPath || getDefaultStateBackupPath()
      : '';
    this._diskBackupCache = null;
    this.adoptedHideClaudeDesktopOnBoot = false;
    this.ensureBaseline();
  }

  readDiskBackup() {
    if (this._pendingDiskBackupState && typeof this._pendingDiskBackupState === 'object') {
      return this._pendingDiskBackupState;
    }
    if (!this.diskBackupPath) {
      return null;
    }
    try {
      const stat = fs.statSync(this.diskBackupPath);
      const cached = this._diskBackupCache;
      if (
        cached &&
        cached.path === this.diskBackupPath &&
        cached.mtimeMs === stat.mtimeMs &&
        cached.size === stat.size &&
        cached.data &&
        typeof cached.data === 'object'
      ) {
        return cached.data;
      }
      const parsed = JSON.parse(fs.readFileSync(this.diskBackupPath, 'utf8'));
      if (parsed && typeof parsed === 'object') {
        this._diskBackupCache = {
          path: this.diskBackupPath,
          mtimeMs: stat.mtimeMs,
          size: stat.size,
          data: parsed
        };
        return parsed;
      }
    } catch {
      this._diskBackupCache = null;
    }
    return null;
  }

  flushDiskBackupSync() {
    if (this._diskBackupTimer) {
      clearTimeout(this._diskBackupTimer);
      this._diskBackupTimer = null;
    }
    const stateObj = this._pendingDiskBackupState;
    this._pendingDiskBackupState = null;
    this._diskBackupCache = null;
    if (!this.diskBackupPath || !stateObj || typeof stateObj !== 'object') {
      return;
    }
    try {
      fs.mkdirSync(path.dirname(this.diskBackupPath), { recursive: true });
      fs.writeFileSync(this.diskBackupPath, JSON.stringify(stateObj), 'utf8');
      const stat = fs.statSync(this.diskBackupPath);
      this._diskBackupCache = {
        path: this.diskBackupPath,
        mtimeMs: stat.mtimeMs,
        size: stat.size,
        data: stateObj
      };
    } catch {}
  }

  writeDiskBackup(stateObj, { immediate = false } = {}) {
    if (!this.diskBackupPath || !stateObj || typeof stateObj !== 'object') {
      return;
    }
    this._pendingDiskBackupState = stateObj;
    if (immediate) {
      this.flushDiskBackupSync();
      return;
    }
    if (this._diskBackupTimer) {
      return;
    }
    this._diskBackupTimer = setTimeout(() => {
      this.flushDiskBackupSync();
    }, 180);
    if (typeof this._diskBackupTimer.unref === 'function') {
      this._diskBackupTimer.unref();
    }
  }

  ensureBaseline() {
    this.adoptedHideClaudeDesktopOnBoot = Boolean(this.adoptedHideClaudeDesktopOnBoot);
    let raw = this.memento?.get ? this.memento.get(STATE_STORAGE_KEY, null) : null;
    if ((!raw || typeof raw !== 'object' || !Number(raw.baseline)) && this.diskBackupPath) {
      const diskRaw = this.readDiskBackup();
      if (diskRaw && Number(diskRaw.baseline)) {
        raw = diskRaw;
        if (Number(diskRaw.preferences?.hideClaudeDesktopSessionsUpdatedAt || 0) > 0) {
          this.adoptedHideClaudeDesktopOnBoot = true;
        }
        if (this.memento?.update) {
          void this.memento.update(STATE_STORAGE_KEY, diskRaw);
        }
      }
    } else if (raw && typeof raw === 'object' && this.diskBackupPath) {
      // While VS Code is closed, the standalone relay (remote.js / relay_keepalive.cjs)
      // edits the disk backup directly (unread, archive, groups). Adopt it when it is
      // newer than the memento copy so those phone-side edits survive the next activation.
      const diskRaw = this.readDiskBackup();
      if (
        diskRaw &&
        Number(diskRaw.baseline) &&
        Number(diskRaw.updatedAt || 0) > Number(raw.updatedAt || 0)
      ) {
        if (
          Number(diskRaw.preferences?.hideClaudeDesktopSessionsUpdatedAt || 0) >
          Number(raw.preferences?.hideClaudeDesktopSessionsUpdatedAt || 0)
        ) {
          this.adoptedHideClaudeDesktopOnBoot = true;
        }
        raw = diskRaw;
        if (this.memento?.update) {
          void this.memento.update(STATE_STORAGE_KEY, diskRaw);
        }
      }
    }
    if (!raw || typeof raw !== 'object' || !Number(raw.baseline)) {
      const next = this.read();
      next.baseline = Math.floor(Date.now() / 1000);
      next.unreadIds = [];
      void this.write(next);
    } else if (this.diskBackupPath) {
      this.writeDiskBackup(raw);
    }
  }

  read() {
    let raw = this.memento?.get ? this.memento.get(STATE_STORAGE_KEY, null) : null;
    if ((!raw || typeof raw !== 'object') && this.diskBackupPath) {
      raw = this.readDiskBackup();
    }
    const base = defaultState();
    if (!raw || typeof raw !== 'object') {
      return base;
    }
    const result = {
      baseline: Number(raw.baseline) || 0,
      customTitles:
        raw.customTitles && typeof raw.customTitles === 'object' ? { ...raw.customTitles } : {},
      archivedIds: Array.isArray(raw.archivedIds) ? [...new Set(raw.archivedIds)] : [],
      unarchivedAt:
        raw.unarchivedAt && typeof raw.unarchivedAt === 'object' ? { ...raw.unarchivedAt } : {},
      unreadIds: Array.isArray(raw.unreadIds) ? [...new Set(raw.unreadIds)] : [],
      seenTurnTimestamps:
        raw.seenTurnTimestamps && typeof raw.seenTurnTimestamps === 'object'
          ? { ...raw.seenTurnTimestamps }
          : {},
      groups: Array.isArray(raw.groups) ? raw.groups.map((g) => ({ ...g })) : [],
      threadGroups:
        raw.threadGroups && typeof raw.threadGroups === 'object' ? { ...raw.threadGroups } : {},
      unassignedGroupThreads:
        raw.unassignedGroupThreads && typeof raw.unassignedGroupThreads === 'object'
          ? { ...raw.unassignedGroupThreads }
          : {},
      deletedGroups: Array.isArray(raw.deletedGroups)
        ? raw.deletedGroups
            .filter((d) => d && (d.id || d.name))
            .map((d) => ({ ...d }))
            .slice(-60)
        : [],
      updatedAt: Number(raw.updatedAt) || 0,
      preferences: {
        ...base.preferences,
        ...(raw.preferences && typeof raw.preferences === 'object' ? raw.preferences : {})
      }
    };
    // Sessions and groups of the other hosts (peer-only fleet cache written by the bridge). An older build's cache
    // is ignored: it could hold this host's own stale groups.
    try {
      const cloudCachePath = path.join(os.homedir(), '.claude', '.theo-cloud-sessions-cache.json');
      const stat = fs.statSync(cloudCachePath);
      if (
        _peerGroupsOverlayCache.path === cloudCachePath &&
        _peerGroupsOverlayCache.mtimeMs === stat.mtimeMs &&
        _peerGroupsOverlayCache.size === stat.size
      ) {
        if (_peerGroupsOverlayCache.peerOnly && _peerGroupsOverlayCache.overlay) {
          mergePeerGroups(result, _peerGroupsOverlayCache.overlay);
        }
      } else {
        const cloudParsed = JSON.parse(fs.readFileSync(cloudCachePath, 'utf8'));
        const peerOnly = cloudParsed?.peerOnly === true;
        const rawSnap = cloudParsed?.snapshot;
        const overlay =
          peerOnly && rawSnap && typeof rawSnap === 'object'
            ? {
                groups: Array.isArray(rawSnap.groups)
                  ? rawSnap.groups
                      .filter((g) => g && g.id)
                      .map((g) => ({
                        id: g.id,
                        name: g.name,
                        color: g.color,
                        collapsed: Boolean(g.collapsed)
                      }))
                  : [],
                rows: Array.isArray(rawSnap.rows)
                  ? rawSnap.rows
                      .filter((r) => r && r.id && r.group)
                      .map((r) => ({ id: r.id, group: r.group }))
                  : []
              }
            : null;
        _peerGroupsOverlayCache = {
          path: cloudCachePath,
          mtimeMs: stat.mtimeMs,
          size: stat.size,
          peerOnly,
          overlay
        };
        if (overlay) {
          mergePeerGroups(result, overlay);
        }
      }
    } catch (err) {
      if (err && err.code === 'ENOENT' && _peerGroupsOverlayCache.mtimeMs !== -1) {
        _peerGroupsOverlayCache = {
          path: '',
          mtimeMs: -1,
          size: -1,
          peerOnly: false,
          overlay: null
        };
      }
    }
    return result;
  }

  async write(nextState) {
    if (nextState && typeof nextState === 'object') {
      nextState.updatedAt = Date.now();
    }
    // Groups and group placements shown from other hosts are not this host's to store (see mergePeerGroups).
    const persistable = withoutPeerOverlay(nextState);
    this.writeDiskBackup(persistable);
    if (!this.memento?.update) {
      return nextState;
    }
    await this.memento.update(STATE_STORAGE_KEY, persistable);
    return nextState;
  }

  async setCustomTitle(threadId, title) {
    const id = String(threadId || '').trim();
    if (!id) {
      return;
    }
    const state = this.read();
    const clean = String(title || '').trim();
    if (clean) {
      state.customTitles[id] = clean;
    } else {
      delete state.customTitles[id];
    }
    await this.write(state);
  }

  async setArchived(threadId, archived = true) {
    const id = String(threadId || '').trim();
    if (!id) {
      return;
    }
    await this.setArchivedMany([id], archived);
  }

  async setArchivedMany(threadIds, archived = true, { manualUnarchive = true } = {}) {
    const ids = (Array.isArray(threadIds) ? threadIds : [threadIds])
      .map((x) => String(x || '').trim())
      .filter(Boolean);
    if (ids.length === 0) {
      return false;
    }
    const state = this.read();
    const set = new Set(state.archivedIds);
    const nowSec = Math.floor(Date.now() / 1000);
    let changed = false;

    for (const id of ids) {
      if (archived) {
        if (!set.has(id)) {
          set.add(id);
          changed = true;
        }
        if (state.unarchivedAt[id]) {
          delete state.unarchivedAt[id];
          changed = true;
        }
        if (state.threadGroups[id]) {
          delete state.threadGroups[id];
          state.unassignedGroupThreads[id] = nowSec;
          changed = true;
        }
      } else {
        if (set.has(id)) {
          set.delete(id);
          changed = true;
        }
        if (manualUnarchive && state.unarchivedAt[id] !== nowSec) {
          state.unarchivedAt[id] = nowSec;
          changed = true;
        }
      }
    }

    if (changed) {
      state.archivedIds = Array.from(set);
      await this.write(state);
    }
    return changed;
  }

  async syncClaudeNativeState(claudeLive = {}) {
    if (!claudeLive || typeof claudeLive !== 'object') {
      return false;
    }
    const state = this.read();
    const archivedSet = new Set(state.archivedIds);
    let changed = false;

    if (claudeLive.unarchivedAt && typeof claudeLive.unarchivedAt === 'object') {
      for (const [id, ts] of Object.entries(claudeLive.unarchivedAt)) {
        const num = Number(ts || 0);
        if (!id || !num) {
          continue;
        }
        const sec = num > 1e11 ? Math.floor(num / 1000) : Math.floor(num);
        if (sec > (state.unarchivedAt[id] || 0)) {
          state.unarchivedAt[id] = sec;
          changed = true;
        }
      }
    }

    if (Array.isArray(claudeLive.archivedIds)) {
      for (const rawId of claudeLive.archivedIds) {
        const id = String(rawId || '').trim();
        if (!id || state.unarchivedAt[id]) {
          continue;
        }
        if (!archivedSet.has(id)) {
          archivedSet.add(id);
          changed = true;
        }
      }
    }

    if (Array.isArray(claudeLive.sessionGroups)) {
      const existingById = new Map(state.groups.map((g) => [g.id, g]));
      const existingByName = new Map(state.groups.map((g) => [String(g.name || '').toLowerCase(), g]));
      const tombstoneIds = new Set((state.deletedGroups || []).map((d) => d.id).filter(Boolean));
      const tombstoneNames = new Set(
        (state.deletedGroups || []).map((d) => String(d.name || '').trim().toLowerCase()).filter(Boolean)
      );
      for (const cg of claudeLive.sessionGroups) {
        if (!cg || !cg.name) {
          continue;
        }
        const cleanName = String(cg.name).trim().slice(0, 48);
        if (!cleanName) {
          continue;
        }
        // A group the user deleted in THEO must never be re-imported from the native
        // Claude Code extension's per-workspace `sessionGroups:*` storage (stale copies
        // survive there for workspaces that are not open in VS Code).
        if (tombstoneIds.has(cg.id) || tombstoneNames.has(cleanName.toLowerCase())) {
          continue;
        }
        let targetGroup = existingById.get(cg.id) || existingByName.get(cleanName.toLowerCase());
        if (!targetGroup) {
          targetGroup = {
            id: cg.id || makeGroupId(),
            name: cleanName,
            color: GROUP_COLOR_SWATCHES[state.groups.length % GROUP_COLOR_SWATCHES.length],
            collapsed: Boolean(cg.collapsed)
          };
          state.groups.push(targetGroup);
          existingById.set(targetGroup.id, targetGroup);
          existingByName.set(cleanName.toLowerCase(), targetGroup);
          changed = true;
        }
        if (Array.isArray(cg.sessionIds)) {
          for (const sid of cg.sessionIds) {
            const cleanSid = String(sid || '').trim();
            if (
              cleanSid &&
              !state.threadGroups[cleanSid] &&
              !state.unassignedGroupThreads?.[cleanSid] &&
              !archivedSet.has(cleanSid)
            ) {
              state.threadGroups[cleanSid] = targetGroup.id;
              changed = true;
            }
          }
        }
      }
    }

    if (changed) {
      state.archivedIds = Array.from(archivedSet);
      await this.write(state);
    }
    return changed;
  }

  async markSeen(threadId, seenAt = 0, { clearUnread = true, contentUpdatedAt } = {}) {
    const id = String(threadId || '').trim();
    if (!id) {
      return;
    }
    const state = this.read();
    const nowSec = Math.floor(Date.now() / 1000);
    const prevSeen = Number(state.seenTurnTimestamps[id] || 0);
    const wasUnread = state.unreadIds.includes(id);
    if (
      !wasUnread &&
      typeof contentUpdatedAt === 'number' &&
      contentUpdatedAt > 0 &&
      prevSeen > 0 &&
      Number(seenAt || 0) <= Math.max(nowSec, contentUpdatedAt) &&
      prevSeen >= contentUpdatedAt
    ) {
      return;
    }
    const nextSeen = Math.max(prevSeen, Number(seenAt || 0), nowSec);
    let changed = false;
    if (nextSeen !== prevSeen) {
      state.seenTurnTimestamps[id] = nextSeen;
      changed = true;
    }
    if (clearUnread && wasUnread) {
      state.unreadIds = state.unreadIds.filter((item) => item !== id);
      changed = true;
    }
    if (changed) {
      await this.write(state);
    }
  }

  async setUnread(threadId, unread = true, seenAt = 0) {
    const id = String(threadId || '').trim();
    if (!id) {
      return;
    }
    const state = this.read();
    const set = new Set(state.unreadIds);
    const nowSec = Math.floor(Date.now() / 1000);
    if (unread) {
      set.add(id);
    } else {
      set.delete(id);
      const prevSeen = Number(state.seenTurnTimestamps[id] || 0);
      state.seenTurnTimestamps[id] = Math.max(prevSeen, Number(seenAt || 0), nowSec);
    }
    state.unreadIds = Array.from(set);
    await this.write(state);
  }

  isThreadUnread(state, thread, classifiedState, isActive = false) {
    if (!thread || !thread.id || isActive) {
      return false;
    }
    const id = thread.id;
    const unreadIds = Array.isArray(state?.unreadIds) ? state.unreadIds : [];
    if (unreadIds.includes(id)) {
      return true;
    }
    const seenAt = Math.max(
      Number(state?.seenTurnTimestamps?.[id] || 0),
      Number(state?.baseline || 0),
      Number(thread.lastUserViewAt || 0)
    );
    if (thread.claudeUnread && Number(thread.updatedAt || 0) > seenAt) {
      return true;
    }
    if (classifiedState !== 'completed' && classifiedState !== 'errored') {
      return false;
    }
    return Number(thread.updatedAt || 0) > seenAt + 2;
  }

  async createGroup(name, color = '', preferredId = '') {
    const cleanName = String(name || '').trim();
    if (!cleanName) {
      return null;
    }
    const state = this.read();
    const wantedId = String(preferredId || '').trim();
    const existing = wantedId ? state.groups.find((g) => g.id === wantedId) : null;
    if (existing) {
      return existing;
    }
    const chosenColor =
      GROUP_COLOR_SWATCHES.includes(color)
        ? color
        : GROUP_COLOR_SWATCHES[state.groups.length % GROUP_COLOR_SWATCHES.length];
    const group = {
      id: wantedId || makeGroupId(),
      name: cleanName.slice(0, 48),
      color: chosenColor,
      collapsed: false
    };
    state.groups.push(group);
    this.clearGroupTombstone(state, group.id, group.name);
    await this.write(state);
    return group;
  }

  clearGroupTombstone(state, groupId = '', name = '') {
    if (!state || !Array.isArray(state.deletedGroups)) {
      return;
    }
    const nameKey = String(name || '').trim().toLowerCase();
    state.deletedGroups = state.deletedGroups.filter(
      (d) =>
        !(
          d &&
          ((groupId && d.id === groupId) ||
            (nameKey && String(d.name || '').trim().toLowerCase() === nameKey))
        )
    );
  }

  async renameGroup(groupId, name) {
    const cleanName = String(name || '').trim();
    if (!groupId || !cleanName) {
      return;
    }
    const state = this.read();
    const target = state.groups.find((g) => g.id === groupId);
    if (!target) {
      return;
    }
    target.name = cleanName.slice(0, 48);
    this.clearGroupTombstone(state, '', target.name);
    await this.write(state);
  }

  async setGroupColor(groupId, color) {
    if (!groupId || !GROUP_COLOR_SWATCHES.includes(color)) {
      return;
    }
    const state = this.read();
    const target = state.groups.find((g) => g.id === groupId);
    if (!target) {
      return;
    }
    target.color = color;
    await this.write(state);
  }

  async toggleGroupCollapsed(groupId, collapsed) {
    const state = this.read();
    const target = state.groups.find((g) => g.id === groupId);
    if (!target) {
      return;
    }
    target.collapsed = typeof collapsed === 'boolean' ? collapsed : !target.collapsed;
    await this.write(state);
  }

  async deleteGroup(groupId) {
    if (!groupId) {
      return;
    }
    const state = this.read();
    const victim = state.groups.find((g) => g.id === groupId);
    if (!Array.isArray(state.deletedGroups)) {
      state.deletedGroups = [];
    }
    const nowSec = Math.floor(Date.now() / 1000);
    state.deletedGroups = state.deletedGroups
      .filter((d) => d && d.id !== groupId)
      .concat([
        {
          id: groupId,
          name: String(victim?.name || '').trim().toLowerCase(),
          at: nowSec
        }
      ])
      .slice(-60);
    state.groups = state.groups.filter((g) => g.id !== groupId);
    for (const [tid, gid] of Object.entries(state.threadGroups)) {
      if (gid === groupId) {
        delete state.threadGroups[tid];
        state.unassignedGroupThreads[tid] = nowSec;
      }
    }
    await this.write(state);
  }

  async assignThreadGroup(threadId, groupId = '') {
    const id = String(threadId || '').trim();
    if (!id) {
      return;
    }
    await this.assignThreadGroupsMany([id], groupId);
  }

  async assignThreadGroupsMany(threadIds, groupId = '') {
    const ids = (Array.isArray(threadIds) ? threadIds : [threadIds])
      .map((x) => String(x || '').trim())
      .filter(Boolean);
    if (ids.length === 0) {
      return false;
    }
    const state = this.read();
    const validGroup = Boolean(groupId && state.groups.some((g) => g.id === groupId));
    const nowSec = Math.floor(Date.now() / 1000);
    let changed = false;
    for (const id of ids) {
      if (validGroup) {
        if (state.threadGroups[id] !== groupId) {
          state.threadGroups[id] = groupId;
          changed = true;
        }
        if (state.unassignedGroupThreads[id]) {
          delete state.unassignedGroupThreads[id];
          changed = true;
        }
      } else {
        if (state.threadGroups[id]) {
          delete state.threadGroups[id];
          changed = true;
        }
        if (!state.unassignedGroupThreads[id]) {
          state.unassignedGroupThreads[id] = nowSec;
          changed = true;
        }
      }
    }
    if (changed) {
      await this.write(state);
    }
    return changed;
  }

  async updatePreferences(patch = {}) {
    const state = this.read();
    state.preferences = {
      ...state.preferences,
      ...patch
    };
    await this.write(state);
    return state.preferences;
  }
}

module.exports = {
  GROUP_COLOR_SWATCHES,
  HubStateStore,
  mergePeerGroups,
  withoutPeerOverlay
};

