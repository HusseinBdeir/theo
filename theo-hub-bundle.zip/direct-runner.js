'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const { StringDecoder } = require('string_decoder');
const {
  resolveAgyBinaryPath,
  resolveClaudeBinaryPath,
  resolveSpawnableCli,
  getDeviceIdentity
} = require('./device-identity');

const INACTIVITY_TIMEOUT_MS = 15 * 60 * 1000; // 15 min silence watchdog for hung interactive prompts
const VALID_CLAUDE_PERMISSION_MODES = new Set([
  'acceptEdits',
  'auto',
  'bypassPermissions',
  'default',
  'plan'
]);

const SHARED_CLAUDE_MODE_DEFAULT_DESCRIPTION =
  'Shared Claude Code permission mode for every PC. Valid values: bypassPermissions, auto, acceptEdits, plan, default.';

function normalizeExplicitClaudeMode(rawMode) {
  const clean = String(rawMode || '').trim();
  if (!clean) return '';
  if (clean === 'plan') return 'plan';
  if (clean === 'accept-edits' || clean === 'acceptEdits') return 'acceptEdits';
  if (
    clean === 'bypassPermissions' ||
    clean === 'bypass' ||
    clean === 'bypass-permissions'
  ) {
    return 'bypassPermissions';
  }
  if (clean === 'default' || clean === 'manual') return 'default';
  if (clean === 'auto') return 'auto';
  return '';
}

function resolveClaudePermissionModePaths(options = {}) {
  const opts = options && typeof options === 'object' ? options : {};
  const hasCustomHome = Boolean(opts.homeDir || process.env.THEO_GUARD_HOME);
  const homeDir = String(opts.homeDir || process.env.THEO_GUARD_HOME || os.homedir()).trim();
  const explicitModeFile = String(
    opts.modeFilePath || process.env.THEO_CLAUDE_PERMISSION_MODE_PATH || ''
  ).trim();
  const explicitCacheFile = String(
    opts.localCachePath ||
      opts.localCacheFile ||
      opts.cacheFile ||
      process.env.THEO_CLAUDE_PERMISSION_CACHE_PATH ||
      ''
  ).trim();
  const defaultMemoryRoot = (() => {
    const bhfMem = path.join(homeDir, 'bhfirms', 'memory');
    if (
      fs.existsSync(path.join(bhfMem, 'THEO.md')) ||
      fs.existsSync(path.join(bhfMem, 'Admin'))
    ) {
      return bhfMem;
    }
    const odMem = path.join(homeDir, 'OneDrive - BHFIRMS', 'System', 'System', 'THEO');
    if (
      fs.existsSync(path.join(odMem, 'THEO.md')) ||
      fs.existsSync(path.join(odMem, 'Admin'))
    ) {
      return odMem;
    }
    return bhfMem;
  })();
  const memoryRoot = String(
    opts.memoryRoot || process.env.THEO_MEMORY_ROOT || defaultMemoryRoot
  ).trim();
  const sharedFile =
    explicitModeFile || path.join(memoryRoot, 'Admin', 'claude-permission-mode.json');
  const cacheFile =
    explicitCacheFile || path.join(homeDir, '.claude', '.theo-claude-permission-mode.json');
  const claudeSettingsFile = path.join(homeDir, '.claude', 'settings.json');
  let vscodeSettingsFile = String(opts.vscodeSettingsPath || '').trim();
  if (!vscodeSettingsFile && homeDir) {
    if (process.platform === 'darwin') {
      vscodeSettingsFile = path.join(
        homeDir,
        'Library',
        'Application Support',
        'Code',
        'User',
        'settings.json'
      );
    } else if (process.platform === 'linux') {
      vscodeSettingsFile = path.join(homeDir, '.config', 'Code', 'User', 'settings.json');
    } else {
      const appDataBase = hasCustomHome
        ? path.join(homeDir, 'AppData', 'Roaming')
        : process.env.APPDATA || path.join(homeDir, 'AppData', 'Roaming');
      vscodeSettingsFile = path.join(appDataBase, 'Code', 'User', 'settings.json');
    }
  }
  return {
    homeDir,
    memoryRoot,
    explicitModeFile,
    explicitCacheFile,
    sharedFile,
    cacheFile,
    claudeSettingsFile,
    vscodeSettingsFile
  };
}

function readLocalClaudePermissionCache(options = {}) {
  const { cacheFile } = resolveClaudePermissionModePaths(options);
  if (!cacheFile || !fs.existsSync(cacheFile)) {
    return null;
  }
  try {
    const raw = fs.readFileSync(cacheFile, 'utf8').replace(/^\uFEFF/, '');
    const parsed = JSON.parse(raw);
    const mode = parsed && typeof parsed === 'object' ? normalizeExplicitClaudeMode(parsed.defaultMode) : '';
    if (!mode || !VALID_CLAUDE_PERMISSION_MODES.has(mode)) {
      return null;
    }
    return {
      defaultMode: mode,
      rev: Math.max(0, Math.floor(Number(parsed.rev || 0) || 0)),
      updatedAt: Number(parsed.updatedAt || 0) || 0,
      updatedBy: String(parsed.updatedBy || ''),
      source: String(parsed.source || 'cache'),
      dirtyToStore: Boolean(parsed.dirtyToStore),
      lastSyncedDiskMode: normalizeExplicitClaudeMode(parsed.lastSyncedDiskMode || ''),
      lastSyncedDiskMtimeMs: Number(parsed.lastSyncedDiskMtimeMs || 0) || 0,
      lastSyncedDiskRev: Math.max(0, Math.floor(Number(parsed.lastSyncedDiskRev || 0) || 0)),
      cacheFile
    };
  } catch {
    return null;
  }
}

function readDiskSharedClaudePermissionFile(sharedFile) {
  if (!sharedFile || !fs.existsSync(sharedFile)) {
    return {
      exists: false,
      valid: false,
      mode: '',
      rev: 0,
      updatedAt: 0,
      mtimeMs: 0,
      description: '',
      hasLegacyMeta: false
    };
  }
  let mtimeMs = 0;
  try {
    mtimeMs = Number(fs.statSync(sharedFile).mtimeMs || 0);
  } catch {}
  try {
    const raw = fs.readFileSync(sharedFile, 'utf8').replace(/^\uFEFF/, '');
    const parsed = JSON.parse(raw);
    const rawMode = parsed && typeof parsed === 'object' ? parsed.defaultMode : null;
    const valid = typeof rawMode === 'string' && VALID_CLAUDE_PERMISSION_MODES.has(rawMode);
    const hasLegacyMeta = Boolean(
      parsed &&
        typeof parsed === 'object' &&
        (Object.prototype.hasOwnProperty.call(parsed, 'rev') ||
          Object.prototype.hasOwnProperty.call(parsed, 'updatedAt'))
    );
    return {
      exists: true,
      valid,
      mode: valid ? rawMode : '',
      rev: valid ? Math.max(0, Math.floor(Number(parsed.rev || 0) || 0)) : 0,
      updatedAt: valid ? Math.max(0, Math.floor(Number(parsed.updatedAt || 0) || 0)) : 0,
      mtimeMs,
      description:
        parsed && typeof parsed.description === 'string' ? parsed.description : '',
      hasLegacyMeta
    };
  } catch {
    return {
      exists: true,
      valid: false,
      mode: '',
      rev: 0,
      updatedAt: 0,
      mtimeMs,
      description: '',
      hasLegacyMeta: false
    };
  }
}

function resolveSharedClaudePermissionModeInfo(options = {}) {
  const paths = resolveClaudePermissionModePaths(options);
  const { homeDir, explicitModeFile, explicitCacheFile, sharedFile, claudeSettingsFile } = paths;

  // Preserve strict single-file semantics when a caller/test passes an explicit modeFilePath without localCachePath.
  if (explicitModeFile && !explicitCacheFile) {
    const disk = readDiskSharedClaudePermissionFile(sharedFile);
    if (disk.exists) {
      return {
        defaultMode: disk.valid ? disk.mode : 'auto',
        rev: disk.rev || 0,
        updatedAt: disk.updatedAt || disk.mtimeMs || 0,
        updatedBy: '',
        source: disk.valid ? 'shared_file' : 'corrupt_fallback'
      };
    }
  } else {
    const cache = readLocalClaudePermissionCache(options);
    const disk = readDiskSharedClaudePermissionFile(sharedFile);
    if (disk.exists && disk.valid) {
      if (cache) {
        const hasSyncedBaseline =
          cache.rev === 0 ||
          (Number(cache.lastSyncedDiskMtimeMs || 0) > 0 && Boolean(cache.lastSyncedDiskMode));
        const isStaleSyncedDisk =
          !hasSyncedBaseline ||
          (disk.rev > 0 && disk.rev < cache.rev) ||
          (Number(cache.lastSyncedDiskRev || 0) > 0 &&
            disk.rev > 0 &&
            disk.rev < Number(cache.lastSyncedDiskRev));
        const minUpdatedMs =
          cache.rev > 0 ? Number(cache.updatedAt || 0) + 500 : Number(cache.updatedAt || 0) - 2000;
        const diskEditedAfterSync =
          !isStaleSyncedDisk &&
          disk.mode !== cache.lastSyncedDiskMode &&
          disk.mtimeMs > Number(cache.lastSyncedDiskMtimeMs || 0) + 50 &&
          disk.mtimeMs > minUpdatedMs;
        if (!diskEditedAfterSync) {
          return {
            defaultMode: cache.defaultMode,
            rev: cache.rev,
            updatedAt: cache.updatedAt,
            updatedBy: cache.updatedBy,
            source: cache.source || 'cloud_cache'
          };
        }
      }
      return {
        defaultMode: disk.mode,
        rev: disk.rev || (cache ? cache.rev : 0),
        updatedAt: Math.max(disk.updatedAt || 0, disk.mtimeMs || 0, cache?.updatedAt || 0),
        updatedBy: '',
        source: 'shared_file'
      };
    }
    if (cache) {
      return {
        defaultMode: cache.defaultMode,
        rev: cache.rev,
        updatedAt: cache.updatedAt,
        updatedBy: cache.updatedBy,
        source: cache.source || 'cloud_cache'
      };
    }
    if (disk.exists && !disk.valid) {
      // Fail safe if the shared mode file exists on disk, no valid local cloud cache exists, and the file is corrupt.
      return {
        defaultMode: 'auto',
        rev: 0,
        updatedAt: disk.mtimeMs || 0,
        updatedBy: '',
        source: 'corrupt_fallback'
      };
    }
  }

  if (homeDir && fs.existsSync(claudeSettingsFile)) {
    try {
      const raw = fs.readFileSync(claudeSettingsFile, 'utf8').replace(/^\uFEFF/, '');
      const parsed = JSON.parse(raw);
      const mode = parsed?.permissions?.defaultMode;
      if (typeof mode === 'string' && VALID_CLAUDE_PERMISSION_MODES.has(mode)) {
        return {
          defaultMode: mode,
          rev: 0,
          updatedAt: 0,
          updatedBy: '',
          source: 'claude_settings'
        };
      }
    } catch {}
  }
  return {
    defaultMode: 'auto',
    rev: 0,
    updatedAt: 0,
    updatedBy: '',
    source: 'default'
  };
}

function resolveSharedClaudePermissionMode(options = {}) {
  return resolveSharedClaudePermissionModeInfo(options).defaultMode;
}

function skipJsoncWsAndComments(s, startIdx) {
  let i = startIdx;
  const len = s.length;
  while (i < len) {
    const ch = s[i];
    if (ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n') {
      i += 1;
      continue;
    }
    if (ch === '/' && s[i + 1] === '/') {
      i += 2;
      while (i < len && s[i] !== '\n') i += 1;
      continue;
    }
    if (ch === '/' && s[i + 1] === '*') {
      const end = s.indexOf('*/', i + 2);
      if (end === -1) return -1;
      i = end + 2;
      continue;
    }
    break;
  }
  return i;
}

function skipJsoncString(s, startIdx) {
  if (s[startIdx] !== '"') return -1;
  let i = startIdx + 1;
  const len = s.length;
  while (i < len) {
    const ch = s[i];
    if (ch === '\\') {
      i += 2;
      continue;
    }
    if (ch === '"') {
      return i + 1;
    }
    if (ch === '\r' || ch === '\n') {
      return -1;
    }
    i += 1;
  }
  return -1;
}

function skipJsoncValue(s, startIdx) {
  const ch = s[startIdx];
  if (ch === '"') return skipJsoncString(s, startIdx);
  if (ch === '{' || ch === '[') {
    const stack = [ch === '{' ? '}' : ']'];
    let i = startIdx + 1;
    const len = s.length;
    while (i < len && stack.length > 0) {
      const next = skipJsoncWsAndComments(s, i);
      if (next < 0 || next >= len) return -1;
      i = next;
      const c = s[i];
      if (c === '"') {
        const endStr = skipJsoncString(s, i);
        if (endStr < 0) return -1;
        i = endStr;
        continue;
      }
      if (c === '{' || c === '[') {
        stack.push(c === '{' ? '}' : ']');
        i += 1;
        continue;
      }
      if (c === '}' || c === ']') {
        if (c !== stack[stack.length - 1]) return -1;
        stack.pop();
        i += 1;
        continue;
      }
      i += 1;
    }
    return stack.length === 0 ? i : -1;
  }
  let i = startIdx;
  const len = s.length;
  while (i < len) {
    const c = s[i];
    if (
      c === ' ' ||
      c === '\t' ||
      c === '\r' ||
      c === '\n' ||
      c === ',' ||
      c === '}' ||
      c === ']' ||
      c === '/'
    ) {
      break;
    }
    i += 1;
  }
  if (i === startIdx) return -1;
  const rawToken = s.slice(startIdx, i);
  try {
    JSON.parse(rawToken);
    return i;
  } catch {
    return -1;
  }
}

function parseJsoncRootEntries(text) {
  const openBrace = skipJsoncWsAndComments(text, 0);
  if (openBrace < 0 || text[openBrace] !== '{') return null;
  const entries = [];
  let cursor = openBrace + 1;
  let closeBrace = -1;
  while (cursor < text.length) {
    const tok = skipJsoncWsAndComments(text, cursor);
    if (tok < 0 || tok >= text.length) return null;
    if (text[tok] === '}') {
      closeBrace = tok;
      const afterClose = skipJsoncWsAndComments(text, closeBrace + 1);
      if (afterClose !== text.length) return null;
      break;
    }
    if (text[tok] !== '"') return null;
    const keyEnd = skipJsoncString(text, tok);
    if (keyEnd < 0) return null;
    let keyName;
    try {
      keyName = JSON.parse(text.slice(tok, keyEnd));
    } catch {
      return null;
    }
    const colon = skipJsoncWsAndComments(text, keyEnd);
    if (colon < 0 || text[colon] !== ':') return null;
    const valStart = skipJsoncWsAndComments(text, colon + 1);
    if (valStart < 0 || valStart >= text.length) return null;
    const valEnd = skipJsoncValue(text, valStart);
    if (valEnd < 0) return null;
    let hasParsedScalar = false;
    let parsedScalar = undefined;
    try {
      parsedScalar = JSON.parse(text.slice(valStart, valEnd));
      hasParsedScalar = true;
    } catch {}
    const afterVal = skipJsoncWsAndComments(text, valEnd);
    if (afterVal < 0 || afterVal >= text.length) return null;
    let commaIdx = -1;
    if (text[afterVal] === ',') {
      commaIdx = afterVal;
      cursor = commaIdx + 1;
    } else if (text[afterVal] === '}') {
      cursor = afterVal;
    } else {
      return null;
    }
    entries.push({
      keyName,
      keyStart: tok,
      valStart,
      valEnd,
      commaIdx,
      hasParsedScalar,
      parsedScalar
    });
  }
  if (closeBrace < 0) return null;
  return { openBrace, closeBrace, entries };
}

function mutateJsoncTopLevelKeys(rawInput, updates = {}) {
  const eol = String(rawInput || '').includes('\r\n') ? '\r\n' : '\n';
  let text = String(rawInput || '').replace(/^\uFEFF/, '');
  if (!text.trim()) {
    const freshObj = {};
    for (const [k, v] of Object.entries(updates)) {
      if (v !== undefined) freshObj[k] = v;
    }
    const serialized = JSON.stringify(freshObj, null, 2).replace(/\n/g, eol) + eol;
    return { ok: true, text: serialized, changed: serialized !== rawInput };
  }

  let root = parseJsoncRootEntries(text);
  if (!root) return { ok: false, text: rawInput, changed: false };

  // Pass 1: Update existing keys in place from right to left (preserving duplicate cleanup if any).
  const seenExisting = new Set();
  const duplicateIndicesToRemove = [];
  for (let idx = root.entries.length - 1; idx >= 0; idx -= 1) {
    const e = root.entries[idx];
    if (!Object.prototype.hasOwnProperty.call(updates, e.keyName)) continue;
    const nextVal = updates[e.keyName];
    if (nextVal === undefined) continue;
    if (seenExisting.has(e.keyName)) {
      duplicateIndicesToRemove.push(idx);
      continue;
    }
    seenExisting.add(e.keyName);
    const nextJson = JSON.stringify(nextVal);
    if (e.hasParsedScalar && JSON.stringify(e.parsedScalar) === nextJson) {
      continue;
    }
    text = text.slice(0, e.valStart) + nextJson + text.slice(e.valEnd);
  }

  // Pass 2: Delete keys set to `undefined` (and any duplicate earlier occurrences of updated keys), one at a time.
  const shouldDeleteEntry = (entries, idx) => {
    const e = entries[idx];
    if (Object.prototype.hasOwnProperty.call(updates, e.keyName) && updates[e.keyName] === undefined) {
      return true;
    }
    if (Object.prototype.hasOwnProperty.call(updates, e.keyName) && updates[e.keyName] !== undefined) {
      for (let later = idx + 1; later < entries.length; later += 1) {
        if (entries[later].keyName === e.keyName) return true;
      }
    }
    return false;
  };

  for (let guard = 0; guard < 64; guard += 1) {
    root = parseJsoncRootEntries(text);
    if (!root) return { ok: false, text: rawInput, changed: false };
    const delIdx = root.entries.findIndex((_, idx) => shouldDeleteEntry(root.entries, idx));
    if (delIdx === -1) break;
    const e = root.entries[delIdx];
    let lineIndentStart = e.keyStart;
    while (lineIndentStart > 0 && (text[lineIndentStart - 1] === ' ' || text[lineIndentStart - 1] === '\t')) {
      lineIndentStart -= 1;
    }
    const precededByNewline = lineIndentStart > 0 && text[lineIndentStart - 1] === '\n';
    const prevNewlineStart = precededByNewline
      ? lineIndentStart >= 2 && text[lineIndentStart - 2] === '\r'
        ? lineIndentStart - 2
        : lineIndentStart - 1
      : -1;

    if (e.commaIdx !== -1) {
      const noCommentBeforeComma =
        !/\/[/*]/.test(text.slice(e.valEnd, e.commaIdx)) &&
        !text.slice(e.valEnd, e.commaIdx).includes('\n');
      let afterCommaWs = e.commaIdx + 1;
      while (afterCommaWs < text.length && (text[afterCommaWs] === ' ' || text[afterCommaWs] === '\t')) {
        afterCommaWs += 1;
      }
      const followedByNewline =
        text[afterCommaWs] === '\n' ||
        (text[afterCommaWs] === '\r' && text[afterCommaWs + 1] === '\n');
      if (precededByNewline && noCommentBeforeComma && followedByNewline) {
        const nextLineStart =
          text[afterCommaWs] === '\r' ? afterCommaWs + 2 : afterCommaWs + 1;
        text = text.slice(0, lineIndentStart) + text.slice(nextLineStart);
      } else {
        text = text.slice(0, e.keyStart) + text.slice(afterCommaWs);
      }
    } else {
      const prevEntry = delIdx > 0 ? root.entries[delIdx - 1] : null;
      let afterValWs = e.valEnd;
      while (afterValWs < text.length && (text[afterValWs] === ' ' || text[afterValWs] === '\t')) {
        afterValWs += 1;
      }
      const cleanLineTail =
        text[afterValWs] === '\n' ||
        (text[afterValWs] === '\r' && text[afterValWs + 1] === '\n');
      if (prevNewlineStart >= 0 && cleanLineTail && (!prevEntry || prevEntry.commaIdx < prevNewlineStart)) {
        text = text.slice(0, prevNewlineStart) + text.slice(afterValWs);
        if (prevEntry && prevEntry.commaIdx !== -1) {
          text = text.slice(0, prevEntry.commaIdx) + text.slice(prevEntry.commaIdx + 1);
        }
      } else if (prevEntry && prevEntry.commaIdx !== -1 && !/\/[/*]/.test(text.slice(prevEntry.commaIdx + 1, e.keyStart))) {
        text = text.slice(0, prevEntry.commaIdx) + text.slice(e.valEnd);
      } else {
        text = text.slice(0, e.keyStart) + text.slice(e.valEnd);
        if (prevEntry && prevEntry.commaIdx !== -1) {
          text = text.slice(0, prevEntry.commaIdx) + text.slice(prevEntry.commaIdx + 1);
        }
      }
    }
  }

  // Pass 3: Append any missing keys whose desired value is not undefined.
  root = parseJsoncRootEntries(text);
  if (!root) return { ok: false, text: rawInput, changed: false };
  const presentKeys = new Set(root.entries.map((e) => e.keyName));
  const missingPairs = Object.entries(updates).filter(
    ([k, v]) => v !== undefined && !presentKeys.has(k)
  );

  if (missingPairs.length > 0) {
    let propIndent = '  ';
    if (root.entries.length > 0) {
      let s = root.entries[0].keyStart;
      while (s > 0 && (text[s - 1] === ' ' || text[s - 1] === '\t')) s -= 1;
      if (s > 0 && text[s - 1] === '\n') {
        propIndent = text.slice(s, root.entries[0].keyStart) || '  ';
      }
    }
    let closeIndentStart = root.closeBrace;
    while (
      closeIndentStart > 0 &&
      (text[closeIndentStart - 1] === ' ' || text[closeIndentStart - 1] === '\t')
    ) {
      closeIndentStart -= 1;
    }
    const closeOnOwnLine = closeIndentStart > 0 && text[closeIndentStart - 1] === '\n';
    const closeIndent = closeOnOwnLine ? text.slice(closeIndentStart, root.closeBrace) : '';
    const formattedLines = missingPairs
      .map(([k, v], i) => {
        const comma = i < missingPairs.length - 1 ? ',' : '';
        return `${propIndent}${JSON.stringify(k)}: ${JSON.stringify(v)}${comma}`;
      })
      .join(eol);

    if (root.entries.length === 0) {
      if (closeOnOwnLine) {
        text =
          text.slice(0, closeIndentStart) +
          formattedLines +
          eol +
          text.slice(closeIndentStart);
      } else {
        text =
          text.slice(0, root.closeBrace) +
          eol +
          formattedLines +
          eol +
          closeIndent +
          text.slice(root.closeBrace);
      }
    } else {
      const last = root.entries[root.entries.length - 1];
      if (closeOnOwnLine) {
        let out =
          text.slice(0, closeIndentStart) +
          formattedLines +
          eol +
          text.slice(closeIndentStart);
        if (last.commaIdx === -1) {
          out = out.slice(0, last.valEnd) + ',' + out.slice(last.valEnd);
        }
        text = out;
      } else {
        let out =
          text.slice(0, root.closeBrace) +
          ' ' +
          missingPairs.map(([k, v]) => `${JSON.stringify(k)}: ${JSON.stringify(v)}`).join(', ') +
          ' ' +
          text.slice(root.closeBrace);
        if (last.commaIdx === -1) {
          out = out.slice(0, last.valEnd) + ',' + out.slice(last.valEnd);
        }
        text = out;
      }
    }
  }

  return { ok: true, text, changed: text !== rawInput };
}

function writeFileAtomicSync(filePath, content) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const tmpPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.writeFileSync(tmpPath, content, 'utf8');
    fs.renameSync(tmpPath, filePath);
  } catch {
    try {
      if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
    } catch {}
    fs.writeFileSync(filePath, content, 'utf8');
  }
}

function writeSharedClaudePermissionMode(rawMode, meta = {}, options = {}) {
  const mode = normalizeExplicitClaudeMode(rawMode);
  if (!mode || !VALID_CLAUDE_PERMISSION_MODES.has(mode)) {
    return { ok: false, error: `Invalid Claude permission mode: ${String(rawMode || '')}` };
  }
  const effOpts = {
    ...(meta && typeof meta === 'object' ? meta : {}),
    ...(options && typeof options === 'object' ? options : {})
  };
  const paths = resolveClaudePermissionModePaths(effOpts);
  const {
    homeDir,
    explicitModeFile,
    sharedFile,
    cacheFile,
    claudeSettingsFile,
    vscodeSettingsFile
  } = paths;
  const prevCache = readLocalClaudePermissionCache(effOpts);
  const updatedFiles = [];
  const nowMs = Date.now();
  const nextRev =
    meta && Number.isFinite(Number(meta.rev)) && Number(meta.rev) > 0
      ? Math.floor(Number(meta.rev))
      : Number(prevCache?.rev || 0);
  const nextUpdatedAt =
    meta && Number.isFinite(Number(meta.updatedAt)) && Number(meta.updatedAt) > 0
      ? Number(meta.updatedAt)
      : nowMs;

  // 1. Update Admin\claude-permission-mode.json when the Admin directory (or explicit override) is present.
  // Keep git-tracked Admin\claude-permission-mode.json pure `{ description, defaultMode }` (volatile rev/updatedAt live only in `~/.claude/.theo-claude-permission-mode.json`)
  // and record any pre-existing valid disk file baseline even when `skipSharedFile` is set or OneDrive stub write fails.
  const observedDisk = sharedFile
    ? readDiskSharedClaudePermissionFile(sharedFile)
    : { exists: false, valid: false, mode: '', mtimeMs: 0, description: '', hasLegacyMeta: false };
  let syncedDiskMtimeMs = observedDisk.valid ? observedDisk.mtimeMs : 0;
  let syncedDiskMode = observedDisk.valid ? observedDisk.mode : '';
  let syncedDiskRev = Number(prevCache?.lastSyncedDiskRev || 0) || 0;
  const sharedDir = sharedFile ? path.dirname(sharedFile) : '';
  if (
    !effOpts.skipSharedFile &&
    sharedFile &&
    (explicitModeFile || (sharedDir && fs.existsSync(sharedDir)))
  ) {
    try {
      const description = observedDisk.description || SHARED_CLAUDE_MODE_DEFAULT_DESCRIPTION;
      const sharedObj = {
        description,
        defaultMode: mode
      };
      const nextSharedJson = JSON.stringify(sharedObj, null, 2) + '\n';
      if (
        !observedDisk.exists ||
        !observedDisk.valid ||
        observedDisk.mode !== mode ||
        observedDisk.hasLegacyMeta
      ) {
        const curRaw = observedDisk.exists ? fs.readFileSync(sharedFile, 'utf8') : '';
        if (curRaw !== nextSharedJson) {
          writeFileAtomicSync(sharedFile, nextSharedJson);
          updatedFiles.push(sharedFile);
        }
      }
      syncedDiskMtimeMs = Number(fs.statSync(sharedFile).mtimeMs || Date.now());
      syncedDiskMode = mode;
      syncedDiskRev = nextRev;
    } catch {}
  }

  // 2. Update ~/.claude/settings.json (`permissions.defaultMode`).
  if (homeDir && claudeSettingsFile) {
    try {
      let settingsObj = {};
      let canWriteSettings = true;
      if (fs.existsSync(claudeSettingsFile)) {
        const rawSettings = fs.readFileSync(claudeSettingsFile, 'utf8').replace(/^\uFEFF/, '');
        if (rawSettings.trim()) {
          try {
            const parsed = JSON.parse(rawSettings);
            if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
              settingsObj = parsed;
            } else {
              canWriteSettings = false;
            }
          } catch {
            canWriteSettings = false;
          }
        }
      }
      if (canWriteSettings) {
        const curPerms =
          settingsObj.permissions &&
          typeof settingsObj.permissions === 'object' &&
          !Array.isArray(settingsObj.permissions)
            ? settingsObj.permissions
            : {};
        if (curPerms.defaultMode !== mode) {
          settingsObj.permissions = { ...curPerms, defaultMode: mode };
          writeFileAtomicSync(claudeSettingsFile, JSON.stringify(settingsObj, null, 2) + '\n');
          updatedFiles.push(claudeSettingsFile);
        }
      }
    } catch {}
  }

  // 3. Update VS Code User/settings.json (JSONC-safe, preserving all // and /* */ comments and CRLF).
  if (vscodeSettingsFile && fs.existsSync(path.dirname(vscodeSettingsFile))) {
    try {
      const existsVs = fs.existsSync(vscodeSettingsFile);
      const rawVs = existsVs ? fs.readFileSync(vscodeSettingsFile, 'utf8') : '';
      let existingSkip = false;
      if (rawVs.trim()) {
        const parsedRoot = parseJsoncRootEntries(rawVs.replace(/^\uFEFF/, ''));
        if (parsedRoot) {
          for (const e of parsedRoot.entries) {
            if (e.keyName === 'claudeCode.allowDangerouslySkipPermissions' && e.hasParsedScalar) {
              existingSkip = Boolean(e.parsedScalar);
            }
          }
        }
      }
      const vsUpdates =
        mode === 'bypassPermissions'
          ? {
              'claudeCode.allowDangerouslySkipPermissions': true,
              'claudeCode.initialPermissionMode': 'bypassPermissions'
            }
          : {
              'claudeCode.initialPermissionMode': undefined,
              ...(existingSkip ? { 'claudeCode.allowDangerouslySkipPermissions': false } : {})
            };
      if (existsVs || mode === 'bypassPermissions') {
        const mutated = mutateJsoncTopLevelKeys(rawVs, vsUpdates);
        if (mutated.ok && mutated.changed) {
          writeFileAtomicSync(vscodeSettingsFile, mutated.text);
          updatedFiles.push(vscodeSettingsFile);
        }
      }
    } catch {}
  }

  // 4. Persist local fleet state cache (`~/.claude/.theo-claude-permission-mode.json`) so paused-OneDrive hosts stay synced.
  const nextDirtyToStore =
    meta && typeof meta.dirtyToStore === 'boolean' ? meta.dirtyToStore : false;
  const cacheRecord = {
    defaultMode: mode,
    rev: nextRev,
    updatedAt: nextUpdatedAt,
    updatedBy: String(meta?.updatedBy || prevCache?.updatedBy || '').trim().slice(0, 80),
    source: String(meta?.source || 'local').trim().slice(0, 40),
    dirtyToStore: nextDirtyToStore,
    lastSyncedDiskMode: syncedDiskMode || prevCache?.lastSyncedDiskMode || '',
    lastSyncedDiskMtimeMs: syncedDiskMtimeMs || Number(prevCache?.lastSyncedDiskMtimeMs || 0) || 0,
    lastSyncedDiskRev: syncedDiskRev
  };
  if (cacheFile) {
    try {
      writeFileAtomicSync(cacheFile, JSON.stringify(cacheRecord, null, 2) + '\n');
      updatedFiles.push(cacheFile);
    } catch {}
  }

  const summaryDoc = {
    defaultMode: cacheRecord.defaultMode,
    rev: cacheRecord.rev,
    updatedAt: cacheRecord.updatedAt,
    updatedBy: cacheRecord.updatedBy,
    source: cacheRecord.source,
    dirtyToStore: cacheRecord.dirtyToStore
  };

  return {
    ok: true,
    defaultMode: mode,
    claudePermissionMode: summaryDoc,
    cache: summaryDoc,
    updatedFiles
  };
}

function resolveEffectiveClaudeCliPermission(explicitMode = '', options = {}) {
  const explicit = normalizeExplicitClaudeMode(explicitMode);
  const mode = explicit || resolveSharedClaudePermissionMode(options);
  return {
    mode,
    allowDangerouslySkipPermissions: mode === 'bypassPermissions',
    source: explicit ? 'explicit' : 'shared'
  };
}

function copyDirRecursiveSync(srcDir, dstDir) {
  if (!fs.existsSync(srcDir)) return;
  fs.mkdirSync(dstDir, { recursive: true });
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, entry.name);
    const d = path.join(dstDir, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursiveSync(s, d);
    } else if (entry.isFile()) {
      fs.copyFileSync(s, d);
    }
  }
}

function getCliTranscriptSidecarPath(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId || !/^[0-9a-fA-F-]{8,}$/.test(cleanId)) return '';
  return path.join(os.homedir(), '.gemini', 'antigravity-cli', 'theo-transcripts', `${cleanId}.jsonl`);
}

function appendCliTranscriptSidecarStep(conversationId, stepObj) {
  const filePath = getCliTranscriptSidecarPath(conversationId);
  if (!filePath || !stepObj) return;
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.appendFileSync(filePath, `${JSON.stringify(stepObj)}\n`, 'utf8');
  } catch {}
}

function hasIdeConversationOnDisk(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId) return false;
  const geminiRoot = path.join(os.homedir(), '.gemini');
  for (const donorName of ['antigravity', 'antigravity-ide']) {
    const donorConv = path.join(geminiRoot, donorName, 'conversations');
    if (
      fs.existsSync(path.join(donorConv, `${cleanId}.db`)) ||
      fs.existsSync(path.join(donorConv, `${cleanId}.pb`))
    ) {
      return true;
    }
  }
  return false;
}

function ensureCliConversationMirrored(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId) return;
  const geminiRoot = path.join(os.homedir(), '.gemini');
  const cliConvDir = path.join(geminiRoot, 'antigravity-cli', 'conversations');

  for (const donorName of ['antigravity', 'antigravity-ide']) {
    const donorRoot = path.join(geminiRoot, donorName);
    let foundInDonor = false;
    for (const ext of ['.db', '.pb']) {
      const donorFile = path.join(donorRoot, 'conversations', `${cleanId}${ext}`);
      if (!fs.existsSync(donorFile)) continue;
      foundInDonor = true;
      const cliFile = path.join(cliConvDir, `${cleanId}${ext}`);
      try {
        const donorMtime = fs.statSync(donorFile).mtimeMs;
        const cliMtime = fs.existsSync(cliFile) ? fs.statSync(cliFile).mtimeMs : 0;
        const donorWal = `${donorFile}-wal`;
        const walActive = fs.existsSync(donorWal) && fs.statSync(donorWal).size > 0;
        if (cliMtime === 0 || (donorMtime > cliMtime + 500 && !walActive)) {
          fs.mkdirSync(cliConvDir, { recursive: true });
          fs.copyFileSync(donorFile, cliFile);
        }
      } catch {}
    }
    if (foundInDonor) {
      try {
        const donorBrain = path.join(donorRoot, 'brain', cleanId);
        const cliBrain = path.join(geminiRoot, 'antigravity-cli', 'brain', cleanId);
        if (fs.existsSync(donorBrain) && !fs.existsSync(cliBrain)) {
          copyDirRecursiveSync(donorBrain, cliBrain);
        }
      } catch {}
      return;
    }
  }
}

function mirrorCliConversationToIde(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId) return false;
  const geminiRoot = path.join(os.homedir(), '.gemini');
  const cliConvDir = path.join(geminiRoot, 'antigravity-cli', 'conversations');
  const ideConvDir = path.join(geminiRoot, 'antigravity', 'conversations');
  let mirroredAny = false;
  for (const ext of ['.db', '.pb']) {
    const cliFile = path.join(cliConvDir, `${cleanId}${ext}`);
    if (!fs.existsSync(cliFile)) continue;
    const ideFile = path.join(ideConvDir, `${cleanId}${ext}`);
    try {
      const ideWal = `${ideFile}-wal`;
      if (fs.existsSync(ideWal) && fs.statSync(ideWal).size > 0) {
        return false; // Active IDE WAL lock — never overwrite live IDE database
      }
      const cliMtime = fs.statSync(cliFile).mtimeMs;
      const ideMtime = fs.existsSync(ideFile) ? fs.statSync(ideFile).mtimeMs : 0;
      if (ideMtime === 0 || cliMtime > ideMtime + 500) {
        fs.mkdirSync(ideConvDir, { recursive: true });
        fs.copyFileSync(cliFile, ideFile);
        mirroredAny = true;
      }
    } catch {}
  }
  return mirroredAny;
}

function remapCrossHostPath(rawPath) {
  const clean = String(rawPath || '').trim();
  if (!clean) return '';
  if (fs.existsSync(clean)) return clean;
  const home = os.homedir();
  const mBhfirms = clean.match(/^[A-Za-z]:[\\/]Users[\\/][^\\/]+[\\/]bhfirms(?:[\\/](.*))?$/i);
  if (mBhfirms) {
    const sub = mBhfirms[1] ? mBhfirms[1].replace(/[\\/]+/g, path.sep) : '';
    const candidate = sub ? path.join(home, 'bhfirms', sub) : path.join(home, 'bhfirms');
    if (fs.existsSync(candidate)) return candidate;
  }
  return '';
}

function resolveDefaultCwd(requestedCwd = '', requestedWorkspace = '') {
  const home = os.homedir();
  const bhfirmsRoot = path.join(home, 'bhfirms');
  if (requestedCwd) {
    const mapped = remapCrossHostPath(requestedCwd);
    if (mapped) return mapped;
  }
  if (requestedWorkspace) {
    const slug = String(requestedWorkspace)
      .replace(/^Scope:\s*/i, '')
      .trim();
    if (slug) {
      const mapped = remapCrossHostPath(slug);
      if (mapped) return mapped;
      const candidate = path.isAbsolute(slug) ? slug : path.join(bhfirmsRoot, slug);
      if (fs.existsSync(candidate)) {
        return candidate;
      }
    }
  }
  if (fs.existsSync(bhfirmsRoot)) {
    const preferred = ['theo', 'isabi-app', 'isabi', 'theo-hub'];
    for (const p of preferred) {
      const candidate = path.join(bhfirmsRoot, p);
      if (fs.existsSync(candidate)) return candidate;
    }
    return bhfirmsRoot;
  }
  return home;
}

function prepareSafePromptArg(rawPrompt, cwd = '') {
  const text = String(rawPrompt || '').trim();
  if (text.length <= 14000) {
    return { argText: text, tempFile: '' };
  }
  // Spill large prompts inside workspace .theo-uploads (when possible) so CLI sandboxes can read it
  const baseDir =
    cwd && fs.existsSync(cwd)
      ? path.join(cwd, '.theo-uploads')
      : path.join(os.homedir(), '.claude', 'theo-uploads');
  fs.mkdirSync(baseDir, { recursive: true });
  const promptFile = path.join(
    baseDir,
    `prompt-${Date.now()}-${crypto.randomBytes(3).toString('hex')}.md`
  );
  fs.writeFileSync(promptFile, text, 'utf8');
  const head = text.slice(0, 1200);
  return {
    argText: `${head}\n\n[Full prompt (${text.length} chars) saved at \`${promptFile}\` — read that file in full first before executing.]`,
    tempFile: promptFile
  };
}

class TheoDirectRunner {
  constructor(options = {}) {
    this.onStreamEvent = typeof options.onStreamEvent === 'function' ? options.onStreamEvent : null;
    this.onRunFinished = typeof options.onRunFinished === 'function' ? options.onRunFinished : null;
    this._spawnImpl = typeof options.spawnImpl === 'function' ? options.spawnImpl : null;
    this._resolveClaudeBin =
      typeof options.resolveClaudeBin === 'function' ? options.resolveClaudeBin : null;
    this.permissionOptions =
      options.permissionOptions && typeof options.permissionOptions === 'object'
        ? options.permissionOptions
        : {};
    this.activeRuns = new Map(); // runKey -> runState
    this.recentRuns = new Map(); // threadId -> finished runState
    this.seqCounter = 0;
  }

  rebindCallbacks(options = {}) {
    if (typeof options.onStreamEvent === 'function') {
      this.onStreamEvent = options.onStreamEvent;
    }
    if (typeof options.onRunFinished === 'function') {
      this.onRunFinished = options.onRunFinished;
    }
  }

  getDevice() {
    return getDeviceIdentity();
  }

  hasActiveRun(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return false;
    for (const run of this.activeRuns.values()) {
      if (run.threadId === clean || run.draftId === clean) return true;
    }
    return false;
  }

  getActiveRuns() {
    return Array.from(this.activeRuns.values()).map((r) => this._serializeRunSummary(r));
  }

  getLiveThreadOverlay(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return null;
    for (const run of this.activeRuns.values()) {
      if (run.threadId === clean || run.draftId === clean) {
        return this._serializeRunDetail(run);
      }
    }
    const recent = this.recentRuns.get(clean);
    if (recent && Date.now() - recent.finishedAt < 300000) {
      return this._serializeRunDetail(recent);
    }
    return null;
  }

  _serializeRunSummary(run) {
    const dev = this.getDevice();
    return {
      runKey: run.runKey,
      id: run.threadId || run.draftId,
      threadId: run.threadId || '',
      draftId: run.draftId || '',
      provider: run.provider,
      deviceId: dev.id,
      deviceName: dev.name,
      cwd: run.cwd,
      folder: path.basename(run.cwd || '') || 'Workspace',
      title: run.title,
      model: run.model || (run.provider === 'claude' ? 'Fable 5.1' : 'Gemini 4 Argon (High)'),
      status: run.status,
      startedAt: run.startedAt,
      updatedAt: run.updatedAt,
      fullText: run.fullText,
      fullThinking: run.fullThinking,
      activeTool: run.activeTool,
      usage: run.usage,
      error: run.error || ''
    };
  }

  _serializeRunDetail(run) {
    return {
      ...this._serializeRunSummary(run),
      prompt: run.prompt,
      toolSteps: run.toolSteps.slice(-16),
      error: run.error || ''
    };
  }

  stopRun(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return { ok: false, stopped: 0 };
    let stopped = 0;
    for (const [key, run] of Array.from(this.activeRuns.entries())) {
      if (run.threadId === clean || run.draftId === clean || key === clean) {
        run.cancelled = true;
        run.status = 'cancelled';
        run.updatedAt = Date.now();
        if (run.watchdogTimer) {
          clearTimeout(run.watchdogTimer);
          run.watchdogTimer = null;
        }
        this._killProcessTree(run.child);
        this._flushDelta(run, true);
        this.activeRuns.delete(key);
        if (run.threadId) {
          run.finishedAt = Date.now();
          this.recentRuns.set(run.threadId, run);
          this._persistRunSidecar(run);
        }
        stopped += 1;
      }
    }
    return { ok: stopped > 0, stopped, id: clean };
  }

  _killProcessTree(child) {
    if (!child || !child.pid) return;
    const pid = child.pid;
    if (process.platform === 'win32') {
      execFile('taskkill.exe', ['/PID', String(pid), '/T', '/F'], { windowsHide: true }, () => {});
    } else {
      try {
        process.kill(-pid, 'SIGTERM');
      } catch {
        try {
          child.kill('SIGTERM');
        } catch {}
      }
    }
  }

  _persistUserSidecarIfNeeded(run) {
    if (run.provider !== 'antigravity' || !run.threadId || run.userSidecarWritten) return;
    run.userSidecarWritten = true;
    appendCliTranscriptSidecarStep(run.threadId, {
      step_index: Date.now() * 2,
      source: 'USER_EXPLICIT',
      type: 'USER_INPUT',
      status: 'DONE',
      created_at: new Date(run.startedAt || Date.now()).toISOString(),
      cwd: run.cwd || '',
      title: run.title || '',
      content: run.prompt || ''
    });
  }

  _persistRunSidecar(run) {
    if (run.provider !== 'antigravity' || !run.threadId || run.assistantSidecarWritten) return;
    this._persistUserSidecarIfNeeded(run);
    if (!run.fullText && !run.fullThinking && !run.toolSteps.length && !run.error) return;
    run.assistantSidecarWritten = true;
    appendCliTranscriptSidecarStep(run.threadId, {
      step_index: Date.now() * 2 + 1,
      source: 'MODEL',
      type: 'PLANNER_RESPONSE',
      status: run.status === 'failed' ? 'ERROR' : run.status === 'cancelled' ? 'CANCELED' : 'DONE',
      created_at: new Date(run.updatedAt || Date.now()).toISOString(),
      content:
        run.fullText ||
        (run.error ? `⚠️ ${run.error}` : run.status === 'cancelled' ? '_[Stopped by user]_' : ''),
      thinking: run.fullThinking || '',
      input_tokens: Number(run.usage?.input_tokens || run.usage?.inputTokens || 0),
      cache_read_tokens: Number(run.usage?.cache_read_tokens || run.usage?.cacheReadTokens || 0),
      output_tokens: Number(run.usage?.output_tokens || run.usage?.outputTokens || 0),
      tool_calls: (run.toolSteps || []).map((ts) => ({
        name: ts.name || 'tool',
        args: { toolSummary: ts.name || 'Tool step' }
      }))
    });
  }

  _queueDelta(run, extra = {}) {
    if (extra.textDelta) {
      run.pendingTextDelta += extra.textDelta;
    }
    if (extra.thinkingDelta) {
      run.pendingThinkingDelta += extra.thinkingDelta;
    }
    if (extra.forceImmediate) {
      this._flushDelta(run, true);
      return;
    }
    if (run.flushTimer) return;
    run.flushTimer = setTimeout(() => {
      run.flushTimer = null;
      this._flushDelta(run, false);
    }, 35);
    if (typeof run.flushTimer.unref === 'function') {
      run.flushTimer.unref();
    }
  }

  _flushDelta(run, force = false) {
    if (run.flushTimer) {
      clearTimeout(run.flushTimer);
      run.flushTimer = null;
    }
    if (!force && !run.pendingTextDelta && !run.pendingThinkingDelta) {
      return;
    }
    const dev = this.getDevice();
    this.seqCounter += 1;
    const payload = {
      type: 'stream_delta',
      seq: this.seqCounter,
      deviceId: dev.id,
      deviceName: dev.name,
      runKey: run.runKey,
      threadId: run.threadId || run.draftId,
      realThreadId: run.threadId || '',
      draftId: run.draftId || '',
      provider: run.provider,
      cwd: run.cwd,
      folder: path.basename(run.cwd || '') || 'Workspace',
      title: run.title,
      status: run.status,
      textDelta: run.pendingTextDelta,
      thinkingDelta: run.pendingThinkingDelta,
      fullText: run.fullText,
      fullThinking: run.fullThinking,
      activeTool: run.activeTool || '',
      toolSteps: run.toolSteps.slice(-12),
      usage: run.usage || null,
      error: run.error || '',
      updatedAt: Date.now()
    };
    run.pendingTextDelta = '';
    run.pendingThinkingDelta = '';
    if (this.onStreamEvent) {
      try {
        this.onStreamEvent(payload);
      } catch {}
    }
  }

  _armWatchdog(run, runKey) {
    if (run.watchdogTimer) clearTimeout(run.watchdogTimer);
    run.watchdogTimer = setTimeout(() => {
      if (this.activeRuns.get(runKey) !== run || run.status !== 'working') return;
      run.status = 'failed';
      run.error = 'CLI process timed out after 15m of inactivity (possible interactive prompt block).';
      this._killProcessTree(run.child);
      this._finishRun(runKey, run);
    }, INACTIVITY_TIMEOUT_MS);
    if (typeof run.watchdogTimer.unref === 'function') {
      run.watchdogTimer.unref();
    }
  }

  async startPromptRun(params = {}) {
    const provider = params.provider === 'claude' ? 'claude' : 'antigravity';
    const rawPrompt = String(params.prompt || params.text || '').trim();
    if (!rawPrompt) {
      return { ok: false, error: 'Prompt is empty' };
    }

    const newSession = Boolean(params.newSession || !params.id);
    const requestedId = newSession ? '' : String(params.id || params.threadId || '').trim();
    const draftId = String(params.draftId || `draft-direct-${Date.now()}`).trim();
    const cwd = resolveDefaultCwd(params.cwd, params.workspace || params.repoPrefix);
    const effort = String(params.effort || 'high').trim();
    const model = String(params.model || '').trim();
    const rawMode = String(params.mode || '').trim();
    const mode = rawMode || 'auto';
    const { argText: safePrompt, tempFile: tempPromptFile } = prepareSafePromptArg(rawPrompt, cwd);

    let binPath = '';
    let args = [];
    let preAssignedId = requestedId;

    if (provider === 'claude') {
      binPath = (this._resolveClaudeBin || resolveClaudeBinaryPath)();
      if (!binPath) {
        return { ok: false, error: 'Claude CLI binary not found on this device' };
      }
      if (!preAssignedId) {
        preAssignedId = crypto.randomUUID();
      }
      const perm = resolveEffectiveClaudeCliPermission(rawMode, this.permissionOptions || {});
      const claudePermMode = perm.mode;
      args = [
        '-p',
        '--verbose',
        '--output-format=stream-json',
        '--include-partial-messages',
        `--permission-mode=${claudePermMode}`,
        ...(perm.allowDangerouslySkipPermissions ? ['--allow-dangerously-skip-permissions'] : []),
        '--forward-subagent-text'
      ];
      if (effort) args.push('--effort', effort);
      if (model) args.push('--model', model);
      if (requestedId) {
        args.push('--resume', requestedId);
      } else {
        args.push('--session-id', preAssignedId);
      }
      // '--' prevents prompts starting with '-' from being parsed as CLI flags
      args.push('--', safePrompt);
    } else {
      binPath = resolveAgyBinaryPath();
      if (!binPath) {
        return { ok: false, error: 'Antigravity CLI (agy) binary not found on this device' };
      }
      const agyMode =
        mode === 'plan' ? 'plan' : mode === 'accept-edits' ? 'accept-edits' : 'auto';
      args = [
        '--output-format=stream-json',
        `--mode=${agyMode}`,
        `--effort=${effort || 'high'}`
      ];
      if (model) args.push(`--model=${model}`);
      if (requestedId) {
        ensureCliConversationMirrored(requestedId);
        args.push(`--conversation=${requestedId}`);
      }
      args.push(`-p=${safePrompt}`);
    }

    const runKey = preAssignedId || draftId || `run-${Date.now()}`;
    // Prevent concurrent stream collision on the same session ID
    if (requestedId && this.hasActiveRun(requestedId)) {
      this.stopRun(requestedId);
    } else if (this.activeRuns.has(runKey)) {
      this.stopRun(runKey);
    }

    const titleSnippet = rawPrompt.replace(/\s+/g, ' ').slice(0, 72);
    const run = {
      runKey,
      threadId: preAssignedId || '',
      draftId,
      provider,
      cwd,
      title: params.title || titleSnippet || 'New Session',
      model,
      prompt: rawPrompt,
      tempPromptFile,
      userSidecarWritten: false,
      assistantSidecarWritten: false,
      status: 'working',
      startedAt: Date.now(),
      updatedAt: Date.now(),
      fullText: '',
      fullThinking: '',
      pendingTextDelta: '',
      pendingThinkingDelta: '',
      activeTool: '',
      toolSteps: [],
      usage: null,
      error: '',
      cancelled: false,
      flushTimer: null,
      watchdogTimer: null,
      child: null
    };

    const spawnSpec = resolveSpawnableCli(binPath, args);
    const childEnv = {
      ...process.env,
      AGY_CLI_DISABLE_AUTO_UPDATE: '1',
      NO_COLOR: '1',
      ...(spawnSpec.envPatch || {})
    };
    if (!spawnSpec.envPatch?.ELECTRON_RUN_AS_NODE) {
      delete childEnv.ELECTRON_RUN_AS_NODE;
    }

    let child;
    try {
      const spawnFn = this._spawnImpl || spawn;
      child = spawnFn(spawnSpec.command, spawnSpec.args, {
        cwd,
        env: childEnv,
        windowsHide: true,
        windowsVerbatimArguments: Boolean(spawnSpec.windowsVerbatimArguments),
        stdio: ['ignore', 'pipe', 'pipe']
      });
    } catch (spawnErr) {
      if (tempPromptFile) {
        try {
          fs.unlinkSync(tempPromptFile);
        } catch {}
      }
      return {
        ok: false,
        error: `Failed to spawn ${provider} CLI: ${String(spawnErr?.message || spawnErr)}`
      };
    }

    run.child = child;
    this.activeRuns.set(runKey, run);
    this._armWatchdog(run, runKey);
    if (run.threadId) {
      this._persistUserSidecarIfNeeded(run);
    }
    this._queueDelta(run, { forceImmediate: true });

    let resolveInitId;
    const initIdPromise = new Promise((resolve) => {
      resolveInitId = resolve;
      const t = setTimeout(() => resolve(run.threadId || ''), 1800);
      if (typeof t.unref === 'function') t.unref();
    });

    const outDecoder = new StringDecoder('utf8');
    const errDecoder = new StringDecoder('utf8');
    let stdoutRemainder = '';
    child.stdout.on('data', (chunk) => {
      this._armWatchdog(run, runKey);
      stdoutRemainder += outDecoder.write(chunk);
      let nlIdx;
      while ((nlIdx = stdoutRemainder.indexOf('\n')) !== -1) {
        const rawLine = stdoutRemainder.slice(0, nlIdx).trim();
        stdoutRemainder = stdoutRemainder.slice(nlIdx + 1);
        if (!rawLine || rawLine[0] !== '{') continue;
        try {
          const evt = JSON.parse(rawLine);
          this._ingestStreamFrame(run, evt, resolveInitId);
        } catch {}
      }
    });

    let stderrBuf = '';
    child.stderr.on('data', (chunk) => {
      this._armWatchdog(run, runKey);
      stderrBuf = (stderrBuf + errDecoder.write(chunk)).slice(-4000);
    });

    child.on('error', (err) => {
      run.status = 'failed';
      run.error = String(err?.message || err);
      run.updatedAt = Date.now();
      resolveInitId(run.threadId || '');
      this._finishRun(runKey, run);
    });

    child.on('close', (code) => {
      stdoutRemainder += outDecoder.end();
      stderrBuf = (stderrBuf + errDecoder.end()).slice(-4000);
      if (stdoutRemainder.trim().startsWith('{')) {
        try {
          this._ingestStreamFrame(run, JSON.parse(stdoutRemainder.trim()), resolveInitId);
        } catch {}
      }
      if (!run.cancelled) {
        if (code !== 0 && !run.fullText && !run.error) {
          run.status = 'failed';
          run.error = stderrBuf.trim().slice(0, 400) || `Process exited with code ${code}`;
        } else if (run.status === 'working') {
          run.status = 'completed';
        }
      }
      run.activeTool = '';
      run.updatedAt = Date.now();
      resolveInitId(run.threadId || '');
      this._finishRun(runKey, run);
    });

    const resolvedId = (await initIdPromise) || run.threadId || preAssignedId || draftId;
    return {
      ok: true,
      mode: 'direct_stream',
      provider,
      id: resolvedId,
      threadId: resolvedId,
      draftId,
      cwd,
      deviceId: this.getDevice().id,
      deviceName: this.getDevice().name
    };
  }

  _finishRun(runKey, run) {
    if (run.watchdogTimer) {
      clearTimeout(run.watchdogTimer);
      run.watchdogTimer = null;
    }
    if (run.tempPromptFile) {
      try {
        fs.unlinkSync(run.tempPromptFile);
      } catch {}
      run.tempPromptFile = '';
    }
    this._persistRunSidecar(run);
    this._flushDelta(run, true);
    if (this.activeRuns.get(runKey) === run) {
      this.activeRuns.delete(runKey);
    }
    run.finishedAt = Date.now();
    if (run.threadId) {
      this.recentRuns.set(run.threadId, run);
      if (this.recentRuns.size > 40) {
        const oldestKey = this.recentRuns.keys().next().value;
        if (oldestKey) this.recentRuns.delete(oldestKey);
      }
    }
    if (this.onRunFinished) {
      try {
        this.onRunFinished(this._serializeRunDetail(run));
      } catch {}
    }
  }

  _ingestStreamFrame(run, evt, resolveInitId) {
    run.updatedAt = Date.now();

    if (run.provider === 'antigravity') {
      const cid = evt.conversation_id || evt.step_update?.conversation_id || evt.result?.conversation_id;
      if (cid && !run.threadId) {
        run.threadId = String(cid).trim();
        this._persistUserSidecarIfNeeded(run);
        resolveInitId(run.threadId);
        this._queueDelta(run, { forceImmediate: true });
      }

      if (evt.event === 'step_update' && evt.step_update) {
        const su = evt.step_update;
        let tDelta = '';
        let thDelta = '';
        if (typeof su.text_delta === 'string' && su.text_delta) {
          tDelta = su.text_delta;
          run.fullText += tDelta;
        }
        const rawThought = su.thinking_delta ?? su.thought_delta ?? su.reasoning_delta ?? '';
        if (typeof rawThought === 'string' && rawThought) {
          thDelta = rawThought;
          run.fullThinking += thDelta;
        }
        const stepType = String(su.step_type || '').toLowerCase();
        if (stepType && stepType !== 'agent_response' && stepType !== 'user_input') {
          const toolLabel = su.tool_name || su.name || stepType.replace(/_/g, ' ');
          if (su.state === 'ACTIVE' || su.state === 'RUNNING') {
            run.activeTool = toolLabel;
            if (!run.toolSteps.some((s) => s.stepIndex === su.step_index)) {
              run.toolSteps.push({
                stepIndex: su.step_index,
                name: toolLabel,
                state: 'running',
                at: Date.now()
              });
            }
          } else if (su.state === 'DONE') {
            if (run.activeTool === toolLabel) run.activeTool = '';
            const match = run.toolSteps.find((s) => s.stepIndex === su.step_index);
            if (match) match.state = 'done';
          }
          this._queueDelta(run, { textDelta: tDelta, thinkingDelta: thDelta, forceImmediate: true });
          return;
        }
        if (su.usage) {
          run.usage = su.usage;
        }
        if (tDelta || thDelta) {
          this._queueDelta(run, { textDelta: tDelta, thinkingDelta: thDelta });
        }
        return;
      }

      if (evt.event === 'result' && evt.result) {
        const res = evt.result;
        if (!run.fullText && typeof res.response === 'string') {
          run.fullText = res.response;
        }
        if (res.usage) run.usage = res.usage;
        if (res.status === 'ERROR' || res.error) {
          run.status = 'failed';
          run.error = String(res.error || 'Execution error');
        } else {
          run.status = 'completed';
        }
        run.activeTool = '';
        this._queueDelta(run, { forceImmediate: true });
      }
      return;
    }

    // Claude Code stream-json frames
    if (evt.session_id && !run.threadId) {
      run.threadId = String(evt.session_id).trim();
      resolveInitId(run.threadId);
    }
    if (evt.type === 'system' && evt.subtype === 'init') {
      if (evt.model) run.model = evt.model;
      this._queueDelta(run, { forceImmediate: true });
      return;
    }
    if (evt.type === 'stream_event' && evt.event) {
      const inner = evt.event;
      if (inner.type === 'content_block_start' && inner.content_block) {
        const cb = inner.content_block;
        if (cb.type === 'tool_use' && cb.name) {
          run.activeTool = cb.name;
          run.toolSteps.push({
            stepIndex: run.toolSteps.length + 1,
            name: cb.name,
            state: 'running',
            at: Date.now()
          });
          this._queueDelta(run, { forceImmediate: true });
        }
        return;
      }
      if (inner.type === 'content_block_delta' && inner.delta) {
        const d = inner.delta;
        if (d.type === 'text_delta' && typeof d.text === 'string') {
          run.fullText += d.text;
          this._queueDelta(run, { textDelta: d.text });
        } else if (d.type === 'thinking_delta' && typeof d.thinking === 'string') {
          run.fullThinking += d.thinking;
          this._queueDelta(run, { thinkingDelta: d.thinking });
        }
        return;
      }
      if (inner.type === 'content_block_stop') {
        if (run.activeTool) {
          run.activeTool = '';
          const lastTool = run.toolSteps[run.toolSteps.length - 1];
          if (lastTool) lastTool.state = 'done';
          this._queueDelta(run, { forceImmediate: true });
        }
        return;
      }
    }
    if (evt.type === 'assistant' && evt.message?.content) {
      const blocks = Array.isArray(evt.message.content) ? evt.message.content : [];
      for (const b of blocks) {
        if (b && b.type === 'text' && typeof b.text === 'string' && !run.fullText) {
          run.fullText = b.text;
        }
      }
    }
    if (evt.type === 'result') {
      if (evt.is_error) {
        run.status = 'failed';
        run.error = String(evt.result || 'Claude execution error');
      } else {
        run.status = 'completed';
        if (!run.fullText && typeof evt.result === 'string') {
          run.fullText = evt.result;
        }
      }
      if (evt.usage) run.usage = evt.usage;
      run.activeTool = '';
      this._queueDelta(run, { forceImmediate: true });
    }
  }
}

module.exports = {
  TheoDirectRunner,
  VALID_CLAUDE_PERMISSION_MODES,
  ensureCliConversationMirrored,
  mirrorCliConversationToIde,
  hasIdeConversationOnDisk,
  getCliTranscriptSidecarPath,
  resolveDefaultCwd,
  remapCrossHostPath,
  normalizeExplicitClaudeMode,
  resolveClaudePermissionModePaths,
  readLocalClaudePermissionCache,
  readDiskSharedClaudePermissionFile,
  resolveSharedClaudePermissionModeInfo,
  resolveSharedClaudePermissionMode,
  resolveEffectiveClaudeCliPermission,
  mutateJsoncTopLevelKeys,
  writeSharedClaudePermissionMode
};
