'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const { StringDecoder } = require('string_decoder');
const {
  resolveAgyBinaryPath,
  resolveClaudeBinaryPath,
  resolveSpawnableCli,
  getDeviceIdentity
} = require('./device-identity');

const INACTIVITY_TIMEOUT_MS = 15 * 60 * 1000; // 15 min silence watchdog for hung interactive prompts
const VALID_CLAUDE_PERMISSION_MODES = new Set([
  'acceptEdits',
  'auto',
  'bypassPermissions',
  'default',
  'plan'
]);

function normalizeExplicitClaudeMode(rawMode) {
  const clean = String(rawMode || '').trim();
  if (!clean) return '';
  if (clean === 'plan') return 'plan';
  if (clean === 'accept-edits' || clean === 'acceptEdits') return 'acceptEdits';
  if (
    clean === 'bypassPermissions' ||
    clean === 'bypass' ||
    clean === 'bypass-permissions'
  ) {
    return 'bypassPermissions';
  }
  if (clean === 'default' || clean === 'manual') return 'default';
  if (clean === 'auto') return 'auto';
  return '';
}

function resolveSharedClaudePermissionMode(options = {}) {
  const opts = options && typeof options === 'object' ? options : {};
  const homeDir = String(opts.homeDir || process.env.THEO_GUARD_HOME || os.homedir()).trim();
  const explicitModeFile = String(
    opts.modeFilePath || process.env.THEO_CLAUDE_PERMISSION_MODE_PATH || ''
  ).trim();
  const memoryRoot = String(
    opts.memoryRoot ||
      process.env.THEO_MEMORY_ROOT ||
      path.join(homeDir, 'OneDrive - BHFIRMS', 'System', 'System', 'THEO')
  ).trim();
  const sharedFile = explicitModeFile || path.join(memoryRoot, 'Admin', 'claude-permission-mode.json');

  if (sharedFile && fs.existsSync(sharedFile)) {
    try {
      const raw = fs.readFileSync(sharedFile, 'utf8').replace(/^\uFEFF/, '');
      const parsed = JSON.parse(raw);
      const mode = parsed && typeof parsed === 'object' ? parsed.defaultMode : null;
      if (typeof mode === 'string' && VALID_CLAUDE_PERMISSION_MODES.has(mode)) {
        return mode;
      }
    } catch {}
    // Fail safe if the shared mode file exists on disk but is corrupt or names an unknown mode.
    return 'auto';
  }

  if (homeDir) {
    const claudeSettings = path.join(homeDir, '.claude', 'settings.json');
    if (fs.existsSync(claudeSettings)) {
      try {
        const raw = fs.readFileSync(claudeSettings, 'utf8').replace(/^\uFEFF/, '');
        const parsed = JSON.parse(raw);
        const mode = parsed?.permissions?.defaultMode;
        if (typeof mode === 'string' && VALID_CLAUDE_PERMISSION_MODES.has(mode)) {
          return mode;
        }
      } catch {}
    }
  }
  return 'auto';
}

function resolveEffectiveClaudeCliPermission(explicitMode = '', options = {}) {
  const explicit = normalizeExplicitClaudeMode(explicitMode);
  const mode = explicit || resolveSharedClaudePermissionMode(options);
  return {
    mode,
    allowDangerouslySkipPermissions: mode === 'bypassPermissions',
    source: explicit ? 'explicit' : 'shared'
  };
}

function copyDirRecursiveSync(srcDir, dstDir) {
  if (!fs.existsSync(srcDir)) return;
  fs.mkdirSync(dstDir, { recursive: true });
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, entry.name);
    const d = path.join(dstDir, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursiveSync(s, d);
    } else if (entry.isFile()) {
      fs.copyFileSync(s, d);
    }
  }
}

function getCliTranscriptSidecarPath(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId || !/^[0-9a-fA-F-]{8,}$/.test(cleanId)) return '';
  return path.join(os.homedir(), '.gemini', 'antigravity-cli', 'theo-transcripts', `${cleanId}.jsonl`);
}

function appendCliTranscriptSidecarStep(conversationId, stepObj) {
  const filePath = getCliTranscriptSidecarPath(conversationId);
  if (!filePath || !stepObj) return;
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.appendFileSync(filePath, `${JSON.stringify(stepObj)}\n`, 'utf8');
  } catch {}
}

function hasIdeConversationOnDisk(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId) return false;
  const geminiRoot = path.join(os.homedir(), '.gemini');
  for (const donorName of ['antigravity', 'antigravity-ide']) {
    const donorConv = path.join(geminiRoot, donorName, 'conversations');
    if (
      fs.existsSync(path.join(donorConv, `${cleanId}.db`)) ||
      fs.existsSync(path.join(donorConv, `${cleanId}.pb`))
    ) {
      return true;
    }
  }
  return false;
}

function ensureCliConversationMirrored(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId) return;
  const geminiRoot = path.join(os.homedir(), '.gemini');
  const cliConvDir = path.join(geminiRoot, 'antigravity-cli', 'conversations');

  for (const donorName of ['antigravity', 'antigravity-ide']) {
    const donorRoot = path.join(geminiRoot, donorName);
    let foundInDonor = false;
    for (const ext of ['.db', '.pb']) {
      const donorFile = path.join(donorRoot, 'conversations', `${cleanId}${ext}`);
      if (!fs.existsSync(donorFile)) continue;
      foundInDonor = true;
      const cliFile = path.join(cliConvDir, `${cleanId}${ext}`);
      try {
        const donorMtime = fs.statSync(donorFile).mtimeMs;
        const cliMtime = fs.existsSync(cliFile) ? fs.statSync(cliFile).mtimeMs : 0;
        const donorWal = `${donorFile}-wal`;
        const walActive = fs.existsSync(donorWal) && fs.statSync(donorWal).size > 0;
        if (cliMtime === 0 || (donorMtime > cliMtime + 500 && !walActive)) {
          fs.mkdirSync(cliConvDir, { recursive: true });
          fs.copyFileSync(donorFile, cliFile);
        }
      } catch {}
    }
    if (foundInDonor) {
      try {
        const donorBrain = path.join(donorRoot, 'brain', cleanId);
        const cliBrain = path.join(geminiRoot, 'antigravity-cli', 'brain', cleanId);
        if (fs.existsSync(donorBrain) && !fs.existsSync(cliBrain)) {
          copyDirRecursiveSync(donorBrain, cliBrain);
        }
      } catch {}
      return;
    }
  }
}

function mirrorCliConversationToIde(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId) return false;
  const geminiRoot = path.join(os.homedir(), '.gemini');
  const cliConvDir = path.join(geminiRoot, 'antigravity-cli', 'conversations');
  const ideConvDir = path.join(geminiRoot, 'antigravity', 'conversations');
  let mirroredAny = false;
  for (const ext of ['.db', '.pb']) {
    const cliFile = path.join(cliConvDir, `${cleanId}${ext}`);
    if (!fs.existsSync(cliFile)) continue;
    const ideFile = path.join(ideConvDir, `${cleanId}${ext}`);
    try {
      const ideWal = `${ideFile}-wal`;
      if (fs.existsSync(ideWal) && fs.statSync(ideWal).size > 0) {
        return false; // Active IDE WAL lock — never overwrite live IDE database
      }
      const cliMtime = fs.statSync(cliFile).mtimeMs;
      const ideMtime = fs.existsSync(ideFile) ? fs.statSync(ideFile).mtimeMs : 0;
      if (ideMtime === 0 || cliMtime > ideMtime + 500) {
        fs.mkdirSync(ideConvDir, { recursive: true });
        fs.copyFileSync(cliFile, ideFile);
        mirroredAny = true;
      }
    } catch {}
  }
  return mirroredAny;
}

function remapCrossHostPath(rawPath) {
  const clean = String(rawPath || '').trim();
  if (!clean) return '';
  if (fs.existsSync(clean)) return clean;
  const home = os.homedir();
  const mBhfirms = clean.match(/^[A-Za-z]:[\\/]Users[\\/][^\\/]+[\\/]bhfirms(?:[\\/](.*))?$/i);
  if (mBhfirms) {
    const sub = mBhfirms[1] ? mBhfirms[1].replace(/[\\/]+/g, path.sep) : '';
    const candidate = sub ? path.join(home, 'bhfirms', sub) : path.join(home, 'bhfirms');
    if (fs.existsSync(candidate)) return candidate;
  }
  return '';
}

function resolveDefaultCwd(requestedCwd = '', requestedWorkspace = '') {
  const home = os.homedir();
  const bhfirmsRoot = path.join(home, 'bhfirms');
  if (requestedCwd) {
    const mapped = remapCrossHostPath(requestedCwd);
    if (mapped) return mapped;
  }
  if (requestedWorkspace) {
    const slug = String(requestedWorkspace)
      .replace(/^Scope:\s*/i, '')
      .trim();
    if (slug) {
      const mapped = remapCrossHostPath(slug);
      if (mapped) return mapped;
      const candidate = path.isAbsolute(slug) ? slug : path.join(bhfirmsRoot, slug);
      if (fs.existsSync(candidate)) {
        return candidate;
      }
    }
  }
  if (fs.existsSync(bhfirmsRoot)) {
    const preferred = ['theo', 'isabi-app', 'isabi', 'theo-hub'];
    for (const p of preferred) {
      const candidate = path.join(bhfirmsRoot, p);
      if (fs.existsSync(candidate)) return candidate;
    }
    return bhfirmsRoot;
  }
  return home;
}

function prepareSafePromptArg(rawPrompt, cwd = '') {
  const text = String(rawPrompt || '').trim();
  if (text.length <= 14000) {
    return { argText: text, tempFile: '' };
  }
  // Spill large prompts inside workspace .theo-uploads (when possible) so CLI sandboxes can read it
  const baseDir =
    cwd && fs.existsSync(cwd)
      ? path.join(cwd, '.theo-uploads')
      : path.join(os.homedir(), '.claude', 'theo-uploads');
  fs.mkdirSync(baseDir, { recursive: true });
  const promptFile = path.join(
    baseDir,
    `prompt-${Date.now()}-${crypto.randomBytes(3).toString('hex')}.md`
  );
  fs.writeFileSync(promptFile, text, 'utf8');
  const head = text.slice(0, 1200);
  return {
    argText: `${head}\n\n[Full prompt (${text.length} chars) saved at \`${promptFile}\` — read that file in full first before executing.]`,
    tempFile: promptFile
  };
}

class TheoDirectRunner {
  constructor(options = {}) {
    this.onStreamEvent = typeof options.onStreamEvent === 'function' ? options.onStreamEvent : null;
    this.onRunFinished = typeof options.onRunFinished === 'function' ? options.onRunFinished : null;
    this._spawnImpl = typeof options.spawnImpl === 'function' ? options.spawnImpl : null;
    this._resolveClaudeBin =
      typeof options.resolveClaudeBin === 'function' ? options.resolveClaudeBin : null;
    this.permissionOptions =
      options.permissionOptions && typeof options.permissionOptions === 'object'
        ? options.permissionOptions
        : {};
    this.activeRuns = new Map(); // runKey -> runState
    this.recentRuns = new Map(); // threadId -> finished runState
    this.seqCounter = 0;
  }

  rebindCallbacks(options = {}) {
    if (typeof options.onStreamEvent === 'function') {
      this.onStreamEvent = options.onStreamEvent;
    }
    if (typeof options.onRunFinished === 'function') {
      this.onRunFinished = options.onRunFinished;
    }
  }

  getDevice() {
    return getDeviceIdentity();
  }

  hasActiveRun(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return false;
    for (const run of this.activeRuns.values()) {
      if (run.threadId === clean || run.draftId === clean) return true;
    }
    return false;
  }

  getActiveRuns() {
    return Array.from(this.activeRuns.values()).map((r) => this._serializeRunSummary(r));
  }

  getLiveThreadOverlay(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return null;
    for (const run of this.activeRuns.values()) {
      if (run.threadId === clean || run.draftId === clean) {
        return this._serializeRunDetail(run);
      }
    }
    const recent = this.recentRuns.get(clean);
    if (recent && Date.now() - recent.finishedAt < 300000) {
      return this._serializeRunDetail(recent);
    }
    return null;
  }

  _serializeRunSummary(run) {
    const dev = this.getDevice();
    return {
      runKey: run.runKey,
      id: run.threadId || run.draftId,
      threadId: run.threadId || '',
      draftId: run.draftId || '',
      provider: run.provider,
      deviceId: dev.id,
      deviceName: dev.name,
      cwd: run.cwd,
      folder: path.basename(run.cwd || '') || 'Workspace',
      title: run.title,
      model: run.model || (run.provider === 'claude' ? 'Fable 5.1' : 'Gemini 4 Argon (High)'),
      status: run.status,
      startedAt: run.startedAt,
      updatedAt: run.updatedAt,
      fullText: run.fullText,
      fullThinking: run.fullThinking,
      activeTool: run.activeTool,
      usage: run.usage,
      error: run.error || ''
    };
  }

  _serializeRunDetail(run) {
    return {
      ...this._serializeRunSummary(run),
      prompt: run.prompt,
      toolSteps: run.toolSteps.slice(-16),
      error: run.error || ''
    };
  }

  stopRun(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return { ok: false, stopped: 0 };
    let stopped = 0;
    for (const [key, run] of Array.from(this.activeRuns.entries())) {
      if (run.threadId === clean || run.draftId === clean || key === clean) {
        run.cancelled = true;
        run.status = 'cancelled';
        run.updatedAt = Date.now();
        if (run.watchdogTimer) {
          clearTimeout(run.watchdogTimer);
          run.watchdogTimer = null;
        }
        this._killProcessTree(run.child);
        this._flushDelta(run, true);
        this.activeRuns.delete(key);
        if (run.threadId) {
          run.finishedAt = Date.now();
          this.recentRuns.set(run.threadId, run);
          this._persistRunSidecar(run);
        }
        stopped += 1;
      }
    }
    return { ok: stopped > 0, stopped, id: clean };
  }

  _killProcessTree(child) {
    if (!child || !child.pid) return;
    const pid = child.pid;
    if (process.platform === 'win32') {
      execFile('taskkill.exe', ['/PID', String(pid), '/T', '/F'], { windowsHide: true }, () => {});
    } else {
      try {
        process.kill(-pid, 'SIGTERM');
      } catch {
        try {
          child.kill('SIGTERM');
        } catch {}
      }
    }
  }

  _persistUserSidecarIfNeeded(run) {
    if (run.provider !== 'antigravity' || !run.threadId || run.userSidecarWritten) return;
    run.userSidecarWritten = true;
    appendCliTranscriptSidecarStep(run.threadId, {
      step_index: Date.now() * 2,
      source: 'USER_EXPLICIT',
      type: 'USER_INPUT',
      status: 'DONE',
      created_at: new Date(run.startedAt || Date.now()).toISOString(),
      cwd: run.cwd || '',
      title: run.title || '',
      content: run.prompt || ''
    });
  }

  _persistRunSidecar(run) {
    if (run.provider !== 'antigravity' || !run.threadId || run.assistantSidecarWritten) return;
    this._persistUserSidecarIfNeeded(run);
    if (!run.fullText && !run.fullThinking && !run.toolSteps.length && !run.error) return;
    run.assistantSidecarWritten = true;
    appendCliTranscriptSidecarStep(run.threadId, {
      step_index: Date.now() * 2 + 1,
      source: 'MODEL',
      type: 'PLANNER_RESPONSE',
      status: run.status === 'failed' ? 'ERROR' : run.status === 'cancelled' ? 'CANCELED' : 'DONE',
      created_at: new Date(run.updatedAt || Date.now()).toISOString(),
      content:
        run.fullText ||
        (run.error ? `⚠️ ${run.error}` : run.status === 'cancelled' ? '_[Stopped by user]_' : ''),
      thinking: run.fullThinking || '',
      input_tokens: Number(run.usage?.input_tokens || run.usage?.inputTokens || 0),
      cache_read_tokens: Number(run.usage?.cache_read_tokens || run.usage?.cacheReadTokens || 0),
      output_tokens: Number(run.usage?.output_tokens || run.usage?.outputTokens || 0),
      tool_calls: (run.toolSteps || []).map((ts) => ({
        name: ts.name || 'tool',
        args: { toolSummary: ts.name || 'Tool step' }
      }))
    });
  }

  _queueDelta(run, extra = {}) {
    if (extra.textDelta) {
      run.pendingTextDelta += extra.textDelta;
    }
    if (extra.thinkingDelta) {
      run.pendingThinkingDelta += extra.thinkingDelta;
    }
    if (extra.forceImmediate) {
      this._flushDelta(run, true);
      return;
    }
    if (run.flushTimer) return;
    run.flushTimer = setTimeout(() => {
      run.flushTimer = null;
      this._flushDelta(run, false);
    }, 35);
    if (typeof run.flushTimer.unref === 'function') {
      run.flushTimer.unref();
    }
  }

  _flushDelta(run, force = false) {
    if (run.flushTimer) {
      clearTimeout(run.flushTimer);
      run.flushTimer = null;
    }
    if (!force && !run.pendingTextDelta && !run.pendingThinkingDelta) {
      return;
    }
    const dev = this.getDevice();
    this.seqCounter += 1;
    const payload = {
      type: 'stream_delta',
      seq: this.seqCounter,
      deviceId: dev.id,
      deviceName: dev.name,
      runKey: run.runKey,
      threadId: run.threadId || run.draftId,
      realThreadId: run.threadId || '',
      draftId: run.draftId || '',
      provider: run.provider,
      cwd: run.cwd,
      folder: path.basename(run.cwd || '') || 'Workspace',
      title: run.title,
      status: run.status,
      textDelta: run.pendingTextDelta,
      thinkingDelta: run.pendingThinkingDelta,
      fullText: run.fullText,
      fullThinking: run.fullThinking,
      activeTool: run.activeTool || '',
      toolSteps: run.toolSteps.slice(-12),
      usage: run.usage || null,
      error: run.error || '',
      updatedAt: Date.now()
    };
    run.pendingTextDelta = '';
    run.pendingThinkingDelta = '';
    if (this.onStreamEvent) {
      try {
        this.onStreamEvent(payload);
      } catch {}
    }
  }

  _armWatchdog(run, runKey) {
    if (run.watchdogTimer) clearTimeout(run.watchdogTimer);
    run.watchdogTimer = setTimeout(() => {
      if (this.activeRuns.get(runKey) !== run || run.status !== 'working') return;
      run.status = 'failed';
      run.error = 'CLI process timed out after 15m of inactivity (possible interactive prompt block).';
      this._killProcessTree(run.child);
      this._finishRun(runKey, run);
    }, INACTIVITY_TIMEOUT_MS);
    if (typeof run.watchdogTimer.unref === 'function') {
      run.watchdogTimer.unref();
    }
  }

  async startPromptRun(params = {}) {
    const provider = params.provider === 'claude' ? 'claude' : 'antigravity';
    const rawPrompt = String(params.prompt || params.text || '').trim();
    if (!rawPrompt) {
      return { ok: false, error: 'Prompt is empty' };
    }

    const newSession = Boolean(params.newSession || !params.id);
    const requestedId = newSession ? '' : String(params.id || params.threadId || '').trim();
    const draftId = String(params.draftId || `draft-direct-${Date.now()}`).trim();
    const cwd = resolveDefaultCwd(params.cwd, params.workspace || params.repoPrefix);
    const effort = String(params.effort || 'high').trim();
    const model = String(params.model || '').trim();
    const rawMode = String(params.mode || '').trim();
    const mode = rawMode || 'auto';
    const { argText: safePrompt, tempFile: tempPromptFile } = prepareSafePromptArg(rawPrompt, cwd);

    let binPath = '';
    let args = [];
    let preAssignedId = requestedId;

    if (provider === 'claude') {
      binPath = (this._resolveClaudeBin || resolveClaudeBinaryPath)();
      if (!binPath) {
        return { ok: false, error: 'Claude CLI binary not found on this device' };
      }
      if (!preAssignedId) {
        preAssignedId = crypto.randomUUID();
      }
      const perm = resolveEffectiveClaudeCliPermission(rawMode, this.permissionOptions || {});
      const claudePermMode = perm.mode;
      args = [
        '-p',
        '--verbose',
        '--output-format=stream-json',
        '--include-partial-messages',
        `--permission-mode=${claudePermMode}`,
        ...(perm.allowDangerouslySkipPermissions ? ['--allow-dangerously-skip-permissions'] : []),
        '--forward-subagent-text'
      ];
      if (effort) args.push('--effort', effort);
      if (model) args.push('--model', model);
      if (requestedId) {
        args.push('--resume', requestedId);
      } else {
        args.push('--session-id', preAssignedId);
      }
      // '--' prevents prompts starting with '-' from being parsed as CLI flags
      args.push('--', safePrompt);
    } else {
      binPath = resolveAgyBinaryPath();
      if (!binPath) {
        return { ok: false, error: 'Antigravity CLI (agy) binary not found on this device' };
      }
      const agyMode =
        mode === 'plan' ? 'plan' : mode === 'accept-edits' ? 'accept-edits' : 'auto';
      args = [
        '--output-format=stream-json',
        `--mode=${agyMode}`,
        `--effort=${effort || 'high'}`
      ];
      if (model) args.push(`--model=${model}`);
      if (requestedId) {
        ensureCliConversationMirrored(requestedId);
        args.push(`--conversation=${requestedId}`);
      }
      args.push(`-p=${safePrompt}`);
    }

    const runKey = preAssignedId || draftId || `run-${Date.now()}`;
    // Prevent concurrent stream collision on the same session ID
    if (requestedId && this.hasActiveRun(requestedId)) {
      this.stopRun(requestedId);
    } else if (this.activeRuns.has(runKey)) {
      this.stopRun(runKey);
    }

    const titleSnippet = rawPrompt.replace(/\s+/g, ' ').slice(0, 72);
    const run = {
      runKey,
      threadId: preAssignedId || '',
      draftId,
      provider,
      cwd,
      title: params.title || titleSnippet || 'New Session',
      model,
      prompt: rawPrompt,
      tempPromptFile,
      userSidecarWritten: false,
      assistantSidecarWritten: false,
      status: 'working',
      startedAt: Date.now(),
      updatedAt: Date.now(),
      fullText: '',
      fullThinking: '',
      pendingTextDelta: '',
      pendingThinkingDelta: '',
      activeTool: '',
      toolSteps: [],
      usage: null,
      error: '',
      cancelled: false,
      flushTimer: null,
      watchdogTimer: null,
      child: null
    };

    const spawnSpec = resolveSpawnableCli(binPath, args);
    const childEnv = {
      ...process.env,
      AGY_CLI_DISABLE_AUTO_UPDATE: '1',
      NO_COLOR: '1',
      ...(spawnSpec.envPatch || {})
    };
    if (!spawnSpec.envPatch?.ELECTRON_RUN_AS_NODE) {
      delete childEnv.ELECTRON_RUN_AS_NODE;
    }

    let child;
    try {
      const spawnFn = this._spawnImpl || spawn;
      child = spawnFn(spawnSpec.command, spawnSpec.args, {
        cwd,
        env: childEnv,
        windowsHide: true,
        windowsVerbatimArguments: Boolean(spawnSpec.windowsVerbatimArguments),
        stdio: ['ignore', 'pipe', 'pipe']
      });
    } catch (spawnErr) {
      if (tempPromptFile) {
        try {
          fs.unlinkSync(tempPromptFile);
        } catch {}
      }
      return {
        ok: false,
        error: `Failed to spawn ${provider} CLI: ${String(spawnErr?.message || spawnErr)}`
      };
    }

    run.child = child;
    this.activeRuns.set(runKey, run);
    this._armWatchdog(run, runKey);
    if (run.threadId) {
      this._persistUserSidecarIfNeeded(run);
    }
    this._queueDelta(run, { forceImmediate: true });

    let resolveInitId;
    const initIdPromise = new Promise((resolve) => {
      resolveInitId = resolve;
      const t = setTimeout(() => resolve(run.threadId || ''), 1800);
      if (typeof t.unref === 'function') t.unref();
    });

    const outDecoder = new StringDecoder('utf8');
    const errDecoder = new StringDecoder('utf8');
    let stdoutRemainder = '';
    child.stdout.on('data', (chunk) => {
      this._armWatchdog(run, runKey);
      stdoutRemainder += outDecoder.write(chunk);
      let nlIdx;
      while ((nlIdx = stdoutRemainder.indexOf('\n')) !== -1) {
        const rawLine = stdoutRemainder.slice(0, nlIdx).trim();
        stdoutRemainder = stdoutRemainder.slice(nlIdx + 1);
        if (!rawLine || rawLine[0] !== '{') continue;
        try {
          const evt = JSON.parse(rawLine);
          this._ingestStreamFrame(run, evt, resolveInitId);
        } catch {}
      }
    });

    let stderrBuf = '';
    child.stderr.on('data', (chunk) => {
      this._armWatchdog(run, runKey);
      stderrBuf = (stderrBuf + errDecoder.write(chunk)).slice(-4000);
    });

    child.on('error', (err) => {
      run.status = 'failed';
      run.error = String(err?.message || err);
      run.updatedAt = Date.now();
      resolveInitId(run.threadId || '');
      this._finishRun(runKey, run);
    });

    child.on('close', (code) => {
      stdoutRemainder += outDecoder.end();
      stderrBuf = (stderrBuf + errDecoder.end()).slice(-4000);
      if (stdoutRemainder.trim().startsWith('{')) {
        try {
          this._ingestStreamFrame(run, JSON.parse(stdoutRemainder.trim()), resolveInitId);
        } catch {}
      }
      if (!run.cancelled) {
        if (code !== 0 && !run.fullText && !run.error) {
          run.status = 'failed';
          run.error = stderrBuf.trim().slice(0, 400) || `Process exited with code ${code}`;
        } else if (run.status === 'working') {
          run.status = 'completed';
        }
      }
      run.activeTool = '';
      run.updatedAt = Date.now();
      resolveInitId(run.threadId || '');
      this._finishRun(runKey, run);
    });

    const resolvedId = (await initIdPromise) || run.threadId || preAssignedId || draftId;
    return {
      ok: true,
      mode: 'direct_stream',
      provider,
      id: resolvedId,
      threadId: resolvedId,
      draftId,
      cwd,
      deviceId: this.getDevice().id,
      deviceName: this.getDevice().name
    };
  }

  _finishRun(runKey, run) {
    if (run.watchdogTimer) {
      clearTimeout(run.watchdogTimer);
      run.watchdogTimer = null;
    }
    if (run.tempPromptFile) {
      try {
        fs.unlinkSync(run.tempPromptFile);
      } catch {}
      run.tempPromptFile = '';
    }
    this._persistRunSidecar(run);
    this._flushDelta(run, true);
    if (this.activeRuns.get(runKey) === run) {
      this.activeRuns.delete(runKey);
    }
    run.finishedAt = Date.now();
    if (run.threadId) {
      this.recentRuns.set(run.threadId, run);
      if (this.recentRuns.size > 40) {
        const oldestKey = this.recentRuns.keys().next().value;
        if (oldestKey) this.recentRuns.delete(oldestKey);
      }
    }
    if (this.onRunFinished) {
      try {
        this.onRunFinished(this._serializeRunDetail(run));
      } catch {}
    }
  }

  _ingestStreamFrame(run, evt, resolveInitId) {
    run.updatedAt = Date.now();

    if (run.provider === 'antigravity') {
      const cid = evt.conversation_id || evt.step_update?.conversation_id || evt.result?.conversation_id;
      if (cid && !run.threadId) {
        run.threadId = String(cid).trim();
        this._persistUserSidecarIfNeeded(run);
        resolveInitId(run.threadId);
        this._queueDelta(run, { forceImmediate: true });
      }

      if (evt.event === 'step_update' && evt.step_update) {
        const su = evt.step_update;
        let tDelta = '';
        let thDelta = '';
        if (typeof su.text_delta === 'string' && su.text_delta) {
          tDelta = su.text_delta;
          run.fullText += tDelta;
        }
        const rawThought = su.thinking_delta ?? su.thought_delta ?? su.reasoning_delta ?? '';
        if (typeof rawThought === 'string' && rawThought) {
          thDelta = rawThought;
          run.fullThinking += thDelta;
        }
        const stepType = String(su.step_type || '').toLowerCase();
        if (stepType && stepType !== 'agent_response' && stepType !== 'user_input') {
          const toolLabel = su.tool_name || su.name || stepType.replace(/_/g, ' ');
          if (su.state === 'ACTIVE' || su.state === 'RUNNING') {
            run.activeTool = toolLabel;
            if (!run.toolSteps.some((s) => s.stepIndex === su.step_index)) {
              run.toolSteps.push({
                stepIndex: su.step_index,
                name: toolLabel,
                state: 'running',
                at: Date.now()
              });
            }
          } else if (su.state === 'DONE') {
            if (run.activeTool === toolLabel) run.activeTool = '';
            const match = run.toolSteps.find((s) => s.stepIndex === su.step_index);
            if (match) match.state = 'done';
          }
          this._queueDelta(run, { textDelta: tDelta, thinkingDelta: thDelta, forceImmediate: true });
          return;
        }
        if (su.usage) {
          run.usage = su.usage;
        }
        if (tDelta || thDelta) {
          this._queueDelta(run, { textDelta: tDelta, thinkingDelta: thDelta });
        }
        return;
      }

      if (evt.event === 'result' && evt.result) {
        const res = evt.result;
        if (!run.fullText && typeof res.response === 'string') {
          run.fullText = res.response;
        }
        if (res.usage) run.usage = res.usage;
        if (res.status === 'ERROR' || res.error) {
          run.status = 'failed';
          run.error = String(res.error || 'Execution error');
        } else {
          run.status = 'completed';
        }
        run.activeTool = '';
        this._queueDelta(run, { forceImmediate: true });
      }
      return;
    }

    // Claude Code stream-json frames
    if (evt.session_id && !run.threadId) {
      run.threadId = String(evt.session_id).trim();
      resolveInitId(run.threadId);
    }
    if (evt.type === 'system' && evt.subtype === 'init') {
      if (evt.model) run.model = evt.model;
      this._queueDelta(run, { forceImmediate: true });
      return;
    }
    if (evt.type === 'stream_event' && evt.event) {
      const inner = evt.event;
      if (inner.type === 'content_block_start' && inner.content_block) {
        const cb = inner.content_block;
        if (cb.type === 'tool_use' && cb.name) {
          run.activeTool = cb.name;
          run.toolSteps.push({
            stepIndex: run.toolSteps.length + 1,
            name: cb.name,
            state: 'running',
            at: Date.now()
          });
          this._queueDelta(run, { forceImmediate: true });
        }
        return;
      }
      if (inner.type === 'content_block_delta' && inner.delta) {
        const d = inner.delta;
        if (d.type === 'text_delta' && typeof d.text === 'string') {
          run.fullText += d.text;
          this._queueDelta(run, { textDelta: d.text });
        } else if (d.type === 'thinking_delta' && typeof d.thinking === 'string') {
          run.fullThinking += d.thinking;
          this._queueDelta(run, { thinkingDelta: d.thinking });
        }
        return;
      }
      if (inner.type === 'content_block_stop') {
        if (run.activeTool) {
          run.activeTool = '';
          const lastTool = run.toolSteps[run.toolSteps.length - 1];
          if (lastTool) lastTool.state = 'done';
          this._queueDelta(run, { forceImmediate: true });
        }
        return;
      }
    }
    if (evt.type === 'assistant' && evt.message?.content) {
      const blocks = Array.isArray(evt.message.content) ? evt.message.content : [];
      for (const b of blocks) {
        if (b && b.type === 'text' && typeof b.text === 'string' && !run.fullText) {
          run.fullText = b.text;
        }
      }
    }
    if (evt.type === 'result') {
      if (evt.is_error) {
        run.status = 'failed';
        run.error = String(evt.result || 'Claude execution error');
      } else {
        run.status = 'completed';
        if (!run.fullText && typeof evt.result === 'string') {
          run.fullText = evt.result;
        }
      }
      if (evt.usage) run.usage = evt.usage;
      run.activeTool = '';
      this._queueDelta(run, { forceImmediate: true });
    }
  }
}

module.exports = {
  TheoDirectRunner,
  ensureCliConversationMirrored,
  mirrorCliConversationToIde,
  hasIdeConversationOnDisk,
  getCliTranscriptSidecarPath,
  resolveDefaultCwd,
  remapCrossHostPath,
  normalizeExplicitClaudeMode,
  resolveSharedClaudePermissionMode,
  resolveEffectiveClaudeCliPermission
};
