'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn, execFile } = require('child_process');
const {
  resolveAgyBinaryPath,
  resolveClaudeBinaryPath,
  getDeviceIdentity
} = require('./device-identity');

function copyDirRecursiveSync(srcDir, dstDir) {
  if (!fs.existsSync(srcDir)) return;
  fs.mkdirSync(dstDir, { recursive: true });
  for (const entry of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, entry.name);
    const d = path.join(dstDir, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursiveSync(s, d);
    } else if (entry.isFile()) {
      fs.copyFileSync(s, d);
    }
  }
}

function ensureCliConversationMirrored(conversationId) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId) return;
  const geminiRoot = path.join(os.homedir(), '.gemini');
  const cliRoot = path.join(geminiRoot, 'antigravity-cli');
  const cliPb = path.join(cliRoot, 'conversations', `${cleanId}.pb`);
  if (fs.existsSync(cliPb)) return;

  for (const donorName of ['antigravity', 'antigravity-ide']) {
    const donorRoot = path.join(geminiRoot, donorName);
    const donorPb = path.join(donorRoot, 'conversations', `${cleanId}.pb`);
    if (fs.existsSync(donorPb)) {
      try {
        fs.mkdirSync(path.join(cliRoot, 'conversations'), { recursive: true });
        fs.copyFileSync(donorPb, cliPb);
        const donorBrain = path.join(donorRoot, 'brain', cleanId);
        const cliBrain = path.join(cliRoot, 'brain', cleanId);
        if (fs.existsSync(donorBrain) && !fs.existsSync(cliBrain)) {
          copyDirRecursiveSync(donorBrain, cliBrain);
        }
        return;
      } catch {}
    }
  }
}

function resolveDefaultCwd(requestedCwd = '', requestedWorkspace = '') {
  const home = os.homedir();
  const bhfirmsRoot = path.join(home, 'bhfirms');
  if (requestedCwd) {
    const clean = String(requestedCwd).trim();
    if (clean && fs.existsSync(clean)) {
      return clean;
    }
  }
  if (requestedWorkspace) {
    const slug = String(requestedWorkspace)
      .replace(/^Scope:\s*/i, '')
      .trim();
    if (slug) {
      const candidate = path.isAbsolute(slug) ? slug : path.join(bhfirmsRoot, slug);
      if (fs.existsSync(candidate)) {
        return candidate;
      }
    }
  }
  if (fs.existsSync(bhfirmsRoot)) {
    const preferred = ['theo', 'isabi-app', 'isabi', 'theo-hub'];
    for (const p of preferred) {
      const candidate = path.join(bhfirmsRoot, p);
      if (fs.existsSync(candidate)) return candidate;
    }
    return bhfirmsRoot;
  }
  return home;
}

function prepareSafePromptArg(rawPrompt) {
  const text = String(rawPrompt || '').trim();
  if (text.length <= 14000) {
    return text;
  }
  // Windows CreateProcess limit is 32,767 chars; spill large prompts into ~/.claude/theo-uploads
  const uploadDir = path.join(os.homedir(), '.claude', 'theo-uploads');
  fs.mkdirSync(uploadDir, { recursive: true });
  const promptFile = path.join(uploadDir, `prompt-${Date.now()}-${Math.random().toString(16).slice(2, 6)}.md`);
  fs.writeFileSync(promptFile, text, 'utf8');
  const head = text.slice(0, 1200);
  return `${head}\n\n[Full prompt (${text.length} chars) saved at \`${promptFile}\` — read that file in full first before executing.]`;
}

class TheoDirectRunner {
  constructor(options = {}) {
    this.onStreamEvent = typeof options.onStreamEvent === 'function' ? options.onStreamEvent : null;
    this.onRunFinished = typeof options.onRunFinished === 'function' ? options.onRunFinished : null;
    this.activeRuns = new Map(); // runKey -> runState
    this.recentRuns = new Map(); // threadId -> finished runState (kept 90s for immediate UI hydration)
    this.seqCounter = 0;
  }

  getDevice() {
    return getDeviceIdentity();
  }

  hasActiveRun(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return false;
    for (const run of this.activeRuns.values()) {
      if (run.threadId === clean || run.draftId === clean) return true;
    }
    return false;
  }

  getActiveRuns() {
    return Array.from(this.activeRuns.values()).map((r) => this._serializeRunSummary(r));
  }

  getLiveThreadOverlay(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return null;
    for (const run of this.activeRuns.values()) {
      if (run.threadId === clean || run.draftId === clean) {
        return this._serializeRunDetail(run);
      }
    }
    const recent = this.recentRuns.get(clean);
    if (recent && Date.now() - recent.finishedAt < 90000) {
      return this._serializeRunDetail(recent);
    }
    return null;
  }

  _serializeRunSummary(run) {
    const dev = this.getDevice();
    return {
      runKey: run.runKey,
      id: run.threadId || run.draftId,
      threadId: run.threadId || '',
      draftId: run.draftId || '',
      provider: run.provider,
      deviceId: dev.id,
      deviceName: dev.name,
      cwd: run.cwd,
      folder: path.basename(run.cwd || '') || 'Workspace',
      title: run.title,
      model: run.model || (run.provider === 'claude' ? 'Fable 5.1' : 'Gemini 4 Argon (High)'),
      status: run.status,
      startedAt: run.startedAt,
      updatedAt: run.updatedAt,
      fullText: run.fullText,
      fullThinking: run.fullThinking,
      activeTool: run.activeTool,
      usage: run.usage
    };
  }

  _serializeRunDetail(run) {
    return {
      ...this._serializeRunSummary(run),
      prompt: run.prompt,
      toolSteps: run.toolSteps.slice(-16),
      error: run.error || ''
    };
  }

  stopRun(threadId) {
    const clean = String(threadId || '').trim();
    if (!clean) return { ok: false, stopped: 0 };
    let stopped = 0;
    for (const [key, run] of this.activeRuns.entries()) {
      if (run.threadId === clean || run.draftId === clean || key === clean) {
        run.cancelled = true;
        run.status = 'cancelled';
        run.updatedAt = Date.now();
        this._killProcessTree(run.child);
        this._flushDelta(run, true);
        this.activeRuns.delete(key);
        if (run.threadId) {
          run.finishedAt = Date.now();
          this.recentRuns.set(run.threadId, run);
        }
        stopped += 1;
      }
    }
    return { ok: stopped > 0, stopped, id: clean };
  }

  _killProcessTree(child) {
    if (!child || !child.pid) return;
    const pid = child.pid;
    if (process.platform === 'win32') {
      execFile('taskkill.exe', ['/PID', String(pid), '/T', '/F'], { windowsHide: true }, () => {});
    } else {
      try {
        process.kill(-pid, 'SIGTERM');
      } catch {
        try {
          child.kill('SIGTERM');
        } catch {}
      }
    }
  }

  _queueDelta(run, extra = {}) {
    if (extra.textDelta) {
      run.pendingTextDelta += extra.textDelta;
    }
    if (extra.thinkingDelta) {
      run.pendingThinkingDelta += extra.thinkingDelta;
    }
    if (extra.forceImmediate) {
      this._flushDelta(run, true);
      return;
    }
    if (run.flushTimer) return;
    run.flushTimer = setTimeout(() => {
      run.flushTimer = null;
      this._flushDelta(run, false);
    }, 35);
    if (typeof run.flushTimer.unref === 'function') {
      run.flushTimer.unref();
    }
  }

  _flushDelta(run, force = false) {
    if (run.flushTimer) {
      clearTimeout(run.flushTimer);
      run.flushTimer = null;
    }
    if (!force && !run.pendingTextDelta && !run.pendingThinkingDelta) {
      return;
    }
    const dev = this.getDevice();
    this.seqCounter += 1;
    const payload = {
      type: 'stream_delta',
      seq: this.seqCounter,
      deviceId: dev.id,
      deviceName: dev.name,
      runKey: run.runKey,
      threadId: run.threadId || run.draftId,
      realThreadId: run.threadId || '',
      draftId: run.draftId || '',
      provider: run.provider,
      cwd: run.cwd,
      folder: path.basename(run.cwd || '') || 'Workspace',
      title: run.title,
      status: run.status,
      textDelta: run.pendingTextDelta,
      thinkingDelta: run.pendingThinkingDelta,
      fullText: run.fullText,
      fullThinking: run.fullThinking,
      activeTool: run.activeTool || '',
      toolSteps: run.toolSteps.slice(-12),
      usage: run.usage || null,
      error: run.error || '',
      updatedAt: Date.now()
    };
    run.pendingTextDelta = '';
    run.pendingThinkingDelta = '';
    if (this.onStreamEvent) {
      try {
        this.onStreamEvent(payload);
      } catch {}
    }
  }

  async startPromptRun(params = {}) {
    const provider = params.provider === 'claude' ? 'claude' : 'antigravity';
    const rawPrompt = String(params.prompt || params.text || '').trim();
    if (!rawPrompt) {
      return { ok: false, error: 'Prompt is empty' };
    }

    const newSession = Boolean(params.newSession || !params.id);
    const requestedId = newSession ? '' : String(params.id || params.threadId || '').trim();
    const draftId = String(params.draftId || `draft-direct-${Date.now()}`).trim();
    const cwd = resolveDefaultCwd(params.cwd, params.workspace || params.repoPrefix);
    const effort = String(params.effort || 'high').trim();
    const model = String(params.model || '').trim();
    const mode = String(params.mode || 'auto').trim();
    const safePrompt = prepareSafePromptArg(rawPrompt);

    let binPath = '';
    let args = [];
    let preAssignedId = requestedId;

    if (provider === 'claude') {
      binPath = resolveClaudeBinaryPath();
      if (!binPath) {
        return { ok: false, error: 'Claude CLI binary not found on this device' };
      }
      if (!preAssignedId) {
        preAssignedId = crypto.randomUUID();
      }
      const claudePermMode =
        mode === 'plan' ? 'plan' : mode === 'accept-edits' ? 'acceptEdits' : 'auto';
      args = [
        '-p',
        '--verbose',
        '--output-format=stream-json',
        '--include-partial-messages',
        `--permission-mode=${claudePermMode}`,
        '--forward-subagent-text'
      ];
      if (effort) args.push('--effort', effort);
      if (model) args.push('--model', model);
      if (requestedId) {
        args.push('--resume', requestedId);
      } else {
        args.push('--session-id', preAssignedId);
      }
      args.push(safePrompt);
    } else {
      binPath = resolveAgyBinaryPath();
      if (!binPath) {
        return { ok: false, error: 'Antigravity CLI (agy) binary not found on this device' };
      }
      const agyMode =
        mode === 'plan' ? 'plan' : mode === 'accept-edits' ? 'accept-edits' : 'auto';
      args = [
        '--output-format=stream-json',
        `--mode=${agyMode}`,
        `--effort=${effort || 'high'}`
      ];
      if (model) args.push(`--model=${model}`);
      if (requestedId) {
        ensureCliConversationMirrored(requestedId);
        args.push(`--conversation=${requestedId}`);
      }
      args.push(`-p=${safePrompt}`);
    }

    const runKey = preAssignedId || draftId || `run-${Date.now()}`;
    const titleSnippet = rawPrompt.replace(/\s+/g, ' ').slice(0, 72);
    const run = {
      runKey,
      threadId: preAssignedId || '',
      draftId,
      provider,
      cwd,
      title: params.title || titleSnippet || 'New Session',
      model,
      prompt: rawPrompt,
      status: 'working',
      startedAt: Date.now(),
      updatedAt: Date.now(),
      fullText: '',
      fullThinking: '',
      pendingTextDelta: '',
      pendingThinkingDelta: '',
      activeTool: '',
      toolSteps: [],
      usage: null,
      error: '',
      cancelled: false,
      flushTimer: null,
      child: null
    };

    this.activeRuns.set(runKey, run);

    // Wait briefly (up to 1.8s) for `init` event so Antigravity new-session calls immediately return the real conversation_id!
    let resolveInitId;
    const initIdPromise = new Promise((resolve) => {
      resolveInitId = resolve;
      const t = setTimeout(() => resolve(run.threadId || ''), 1800);
      if (typeof t.unref === 'function') t.unref();
    });

    const childEnv = {
      ...process.env,
      AGY_CLI_DISABLE_AUTO_UPDATE: '1',
      NO_COLOR: '1'
    };
    delete childEnv.ELECTRON_RUN_AS_NODE;

    const child = spawn(binPath, args, {
      cwd,
      env: childEnv,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    run.child = child;
    this._queueDelta(run, { forceImmediate: true });

    let stdoutRemainder = '';
    child.stdout.on('data', (chunk) => {
      stdoutRemainder += chunk.toString('utf8');
      let nlIdx;
      while ((nlIdx = stdoutRemainder.indexOf('\n')) !== -1) {
        const rawLine = stdoutRemainder.slice(0, nlIdx).trim();
        stdoutRemainder = stdoutRemainder.slice(nlIdx + 1);
        if (!rawLine || rawLine[0] !== '{') continue;
        try {
          const evt = JSON.parse(rawLine);
          this._ingestStreamFrame(run, evt, resolveInitId);
        } catch {}
      }
    });

    let stderrBuf = '';
    child.stderr.on('data', (chunk) => {
      stderrBuf = (stderrBuf + chunk.toString('utf8')).slice(-4000);
    });

    child.on('error', (err) => {
      run.status = 'failed';
      run.error = String(err?.message || err);
      run.updatedAt = Date.now();
      resolveInitId(run.threadId || '');
      this._finishRun(runKey, run);
    });

    child.on('close', (code) => {
      if (stdoutRemainder.trim().startsWith('{')) {
        try {
          this._ingestStreamFrame(run, JSON.parse(stdoutRemainder.trim()), resolveInitId);
        } catch {}
      }
      if (!run.cancelled) {
        if (code !== 0 && !run.fullText && !run.error) {
          run.status = 'failed';
          run.error = stderrBuf.trim().slice(0, 400) || `Process exited with code ${code}`;
        } else if (run.status === 'working') {
          run.status = 'completed';
        }
      }
      run.activeTool = '';
      run.updatedAt = Date.now();
      resolveInitId(run.threadId || '');
      this._finishRun(runKey, run);
    });

    const resolvedId = (await initIdPromise) || run.threadId || preAssignedId || draftId;
    return {
      ok: true,
      mode: 'direct_stream',
      provider,
      id: resolvedId,
      threadId: resolvedId,
      draftId,
      cwd,
      deviceId: this.getDevice().id,
      deviceName: this.getDevice().name
    };
  }

  _finishRun(runKey, run) {
    this._flushDelta(run, true);
    this.activeRuns.delete(runKey);
    run.finishedAt = Date.now();
    if (run.threadId) {
      this.recentRuns.set(run.threadId, run);
    }
    if (this.onRunFinished) {
      try {
        this.onRunFinished(this._serializeRunDetail(run));
      } catch {}
    }
  }

  _ingestStreamFrame(run, evt, resolveInitId) {
    run.updatedAt = Date.now();

    if (run.provider === 'antigravity') {
      const cid = evt.conversation_id || evt.step_update?.conversation_id || evt.result?.conversation_id;
      if (cid && !run.threadId) {
        run.threadId = String(cid).trim();
        resolveInitId(run.threadId);
        this._queueDelta(run, { forceImmediate: true });
      }

      if (evt.event === 'step_update' && evt.step_update) {
        const su = evt.step_update;
        let tDelta = '';
        let thDelta = '';
        if (typeof su.text_delta === 'string' && su.text_delta) {
          tDelta = su.text_delta;
          run.fullText += tDelta;
        }
        const rawThought = su.thinking_delta ?? su.thought_delta ?? su.reasoning_delta ?? '';
        if (typeof rawThought === 'string' && rawThought) {
          thDelta = rawThought;
          run.fullThinking += thDelta;
        }
        const stepType = String(su.step_type || '').toLowerCase();
        if (stepType && stepType !== 'agent_response' && stepType !== 'user_input') {
          const toolLabel = su.tool_name || su.name || stepType.replace(/_/g, ' ');
          if (su.state === 'ACTIVE' || su.state === 'RUNNING') {
            run.activeTool = toolLabel;
            if (!run.toolSteps.some((s) => s.stepIndex === su.step_index)) {
              run.toolSteps.push({
                stepIndex: su.step_index,
                name: toolLabel,
                state: 'running',
                at: Date.now()
              });
            }
          } else if (su.state === 'DONE') {
            if (run.activeTool === toolLabel) run.activeTool = '';
            const match = run.toolSteps.find((s) => s.stepIndex === su.step_index);
            if (match) match.state = 'done';
          }
          this._queueDelta(run, { textDelta: tDelta, thinkingDelta: thDelta, forceImmediate: true });
          return;
        }
        if (su.usage) {
          run.usage = su.usage;
        }
        if (tDelta || thDelta) {
          this._queueDelta(run, { textDelta: tDelta, thinkingDelta: thDelta });
        }
        return;
      }

      if (evt.event === 'result' && evt.result) {
        const res = evt.result;
        if (!run.fullText && typeof res.response === 'string') {
          run.fullText = res.response;
        }
        if (res.usage) run.usage = res.usage;
        if (res.status === 'ERROR' || res.error) {
          run.status = 'failed';
          run.error = String(res.error || 'Execution error');
        } else {
          run.status = 'completed';
        }
        run.activeTool = '';
        this._queueDelta(run, { forceImmediate: true });
      }
      return;
    }

    // Claude Code stream-json frames
    if (evt.session_id && !run.threadId) {
      run.threadId = String(evt.session_id).trim();
      resolveInitId(run.threadId);
    }
    if (evt.type === 'system' && evt.subtype === 'init') {
      if (evt.model) run.model = evt.model;
      this._queueDelta(run, { forceImmediate: true });
      return;
    }
    if (evt.type === 'stream_event' && evt.event) {
      const inner = evt.event;
      if (inner.type === 'content_block_start' && inner.content_block) {
        const cb = inner.content_block;
        if (cb.type === 'tool_use' && cb.name) {
          run.activeTool = cb.name;
          run.toolSteps.push({
            stepIndex: run.toolSteps.length + 1,
            name: cb.name,
            state: 'running',
            at: Date.now()
          });
          this._queueDelta(run, { forceImmediate: true });
        }
        return;
      }
      if (inner.type === 'content_block_delta' && inner.delta) {
        const d = inner.delta;
        if (d.type === 'text_delta' && typeof d.text === 'string') {
          run.fullText += d.text;
          this._queueDelta(run, { textDelta: d.text });
        } else if (d.type === 'thinking_delta' && typeof d.thinking === 'string') {
          run.fullThinking += d.thinking;
          this._queueDelta(run, { thinkingDelta: d.thinking });
        }
        return;
      }
      if (inner.type === 'content_block_stop') {
        if (run.activeTool) {
          run.activeTool = '';
          const lastTool = run.toolSteps[run.toolSteps.length - 1];
          if (lastTool) lastTool.state = 'done';
          this._queueDelta(run, { forceImmediate: true });
        }
        return;
      }
    }
    if (evt.type === 'assistant' && evt.message?.content) {
      const blocks = Array.isArray(evt.message.content) ? evt.message.content : [];
      for (const b of blocks) {
        if (b && b.type === 'text' && typeof b.text === 'string' && !run.fullText) {
          run.fullText = b.text;
        }
      }
    }
    if (evt.type === 'result') {
      if (evt.is_error) {
        run.status = 'failed';
        run.error = String(evt.result || 'Claude execution error');
      } else {
        run.status = 'completed';
        if (!run.fullText && typeof evt.result === 'string') {
          run.fullText = evt.result;
        }
      }
      if (evt.usage) run.usage = evt.usage;
      run.activeTool = '';
      this._queueDelta(run, { forceImmediate: true });
    }
  }
}

module.exports = {
  TheoDirectRunner,
  ensureCliConversationMirrored,
  resolveDefaultCwd
};
