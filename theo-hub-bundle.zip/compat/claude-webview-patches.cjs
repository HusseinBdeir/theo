const vm = require('vm');

const CLAUDE_BRIDGE_MARKER = 'claude-hub-bridge-v1';
const CLAUDE_PIN_MARKER = '/*bhf-pin*/';
const CLAUDE_NOWARN_MARKER = '/*bhf-nowarn*/';
const CLAUDE_NOBROWSER_MARKER = '/*bhf-nobrowserbanner*/';
const CLAUDE_CTX_MARKER = '/*bhf-context-window*/';
const CLAUDE_USAGE_RESET_MARKER = '/*bhf-usage-reset*/';
const CLAUDE_RELOAD_MARKER = '/*bhf-reload-resume*/';

const CLAUDE_CTX_UI_RUNTIME_JS = `
/*bhf-context-window-start*/
;(function(){
  if (typeof window === 'undefined' || window.__bhfClaudeContextWindowInstalled) return;
  window.__bhfClaudeContextWindowInstalled = true;

  const STYLE_ID = 'bhf-context-window-styles';
  const POPOVER_ID = 'bhf-context-window-popover';
  const WRAPPER_ATTR = 'data-bhf-context-wrapper';
  const BTN_TESTID = 'bhf-context-window-trigger';

  let activeSession = null;
  let activeOnCompact = null;
  let lastHookUsedTokens = 0;
  let lastHookContextWindow = 0;
  let rpcCacheBySession = new WeakMap();
  let isFetchingRpc = false;
  let popoverOpen = false;
  let activeTriggerEl = null;

  const CATEGORY_COLORS = {
    'System prompt': '#6366f1',
    'Memory files': '#8b5cf6',
    'System tools': '#06b6d4',
    'MCP tools': '#0ea5e9',
    'Custom agents': '#ec4899',
    'Skills': '#14b8a6',
    'Messages': '#10b981',
    'Autocompact buffer': '#64748b'
  };
  const FALLBACK_PALETTE = ['#6366f1', '#06b6d4', '#10b981', '#f59e0b', '#3b82f6', '#8b5cf6', '#ec4899'];

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = \`
      [\${WRAPPER_ATTR}="true"] {
        display: inline-flex;
        align-items: center;
        flex-shrink: 0;
      }
      .bhf-ctx-btn {
        appearance: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        min-height: var(--app-pill-min-height, 20px);
        height: 20px;
        padding: 0 8px;
        margin-left: 5px;
        border-radius: 9999px;
        font-family: inherit;
        font-size: 0.85em;
        line-height: 1;
        font-weight: 500;
        color: var(--app-pill-foreground, var(--vscode-foreground, rgba(220, 220, 225, 0.9)));
        background: var(--app-pill-background, rgba(128, 128, 135, 0.12));
        border: 1px solid rgba(128, 128, 135, 0.24);
        cursor: pointer;
        user-select: none;
        outline: none;
        white-space: nowrap;
        flex-shrink: 0;
        box-sizing: border-box;
        transition: background-color 0.15s ease, border-color 0.15s ease, color 0.15s ease;
      }
      .bhf-ctx-btn:hover, .bhf-ctx-btn[data-open="true"] {
        background: var(--app-pill-hover-background, rgba(128, 128, 135, 0.22));
        border-color: rgba(128, 128, 135, 0.42);
      }
      .bhf-ctx-pct {
        opacity: 0.72;
        font-variant-numeric: tabular-nums;
      }
      .bhf-ctx-popover {
        position: fixed;
        z-index: 99999;
        width: 352px;
        max-width: calc(100vw - 24px);
        border-radius: 12px;
        background: var(--vscode-editorWidget-background, var(--app-secondary-background, #1e1f22));
        color: var(--vscode-editorWidget-foreground, var(--app-primary-foreground, #e5e7eb));
        border: 1px solid var(--vscode-editorWidget-border, var(--app-input-border, rgba(128, 128, 135, 0.28)));
        box-shadow: 0 14px 36px rgba(0, 0, 0, 0.45), 0 2px 8px rgba(0, 0, 0, 0.25);
        padding: 12px 14px;
        font-family: inherit;
        font-size: 12px;
        line-height: 1.4;
        user-select: none;
        box-sizing: border-box;
      }
      .bhf-ctx-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 8px;
      }
      .bhf-ctx-title {
        font-weight: 600;
        font-size: 12.5px;
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
      }
      .bhf-ctx-sub {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        margin-bottom: 6px;
        font-variant-numeric: tabular-nums;
      }
      .bhf-ctx-bar-track {
        display: flex;
        width: 100%;
        height: 8px;
        border-radius: 9999px;
        overflow: hidden;
        background: rgba(128, 128, 135, 0.2);
        margin-bottom: 10px;
      }
      .bhf-ctx-bar-seg {
        height: 100%;
        transition: width 0.25s ease;
      }
      .bhf-ctx-rows {
        display: flex;
        flex-direction: column;
        gap: 5px;
        padding: 8px 0;
        border-top: 1px solid rgba(128, 128, 135, 0.18);
        border-bottom: 1px solid rgba(128, 128, 135, 0.18);
      }
      .bhf-ctx-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        font-size: 11.5px;
        font-variant-numeric: tabular-nums;
      }
      .bhf-ctx-row-left {
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
      }
      .bhf-ctx-dot {
        width: 8px;
        height: 8px;
        border-radius: 2px;
        flex-shrink: 0;
      }
      .bhf-ctx-meta-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 6px;
        margin-top: 8px;
      }
      .bhf-ctx-meta-box {
        padding: 5px 7px;
        border-radius: 6px;
        background: rgba(128, 128, 135, 0.1);
        display: flex;
        flex-direction: column;
        gap: 1px;
      }
      .bhf-ctx-meta-label {
        font-size: 10px;
        opacity: 0.65;
      }
      .bhf-ctx-meta-val {
        font-size: 11.5px;
        font-weight: 600;
        font-variant-numeric: tabular-nums;
      }
      .bhf-ctx-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        margin-top: 10px;
      }
      .bhf-ctx-action-btn {
        flex: 1;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        height: 27px;
        padding: 0 8px;
        border-radius: 6px;
        font-family: inherit;
        font-size: 11.5px;
        font-weight: 500;
        background: rgba(99, 102, 241, 0.16);
        color: #818cf8;
        border: 1px solid rgba(99, 102, 241, 0.3);
        cursor: pointer;
        transition: background 0.15s ease, opacity 0.15s ease;
        white-space: nowrap;
      }
      .bhf-ctx-action-btn:hover:not(:disabled) {
        background: rgba(99, 102, 241, 0.26);
      }
      .bhf-ctx-action-btn:disabled {
        opacity: 0.45;
        cursor: default;
      }
      .bhf-ctx-action-btn.bhf-ctx-compact-btn {
        flex: 0 0 auto;
        background: rgba(245, 158, 11, 0.14);
        color: #fbbf24;
        border-color: rgba(245, 158, 11, 0.3);
      }
      .bhf-ctx-action-btn.bhf-ctx-compact-btn:hover:not(:disabled) {
        background: rgba(245, 158, 11, 0.24);
      }
      .bhf-ctx-icon-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 22px;
        height: 22px;
        border-radius: 5px;
        background: transparent;
        color: inherit;
        opacity: 0.65;
        border: none;
        cursor: pointer;
        padding: 0;
      }
      .bhf-ctx-icon-btn:hover {
        opacity: 1;
        background: rgba(128, 128, 135, 0.18);
      }
    \`;
    document.head.appendChild(style);
  }

  function formatCompactTokens(num) {
    const n = Number(num || 0);
    if (!Number.isFinite(n) || n <= 0) return '0';
    if (n >= 1000000) {
      const m = n / 1000000;
      return (m >= 10 ? Math.round(m) : Number(m.toFixed(1))) + 'M';
    }
    if (n >= 1000) {
      const k = n / 1000;
      return (k >= 100 ? Math.round(k) : Number(k.toFixed(1))) + 'k';
    }
    return String(Math.round(n));
  }

  function formatExactTokens(num) {
    return Math.round(Number(num || 0)).toLocaleString('en-US');
  }

  function getStatusColor(pct) {
    if (pct >= 85) return '#f43f5e';
    if (pct >= 65) return '#f59e0b';
    return '#10b981';
  }

  function buildRingSvg(pct, color) {
    const r = 5.2;
    const c = 2 * Math.PI * r;
    const clamped = Math.max(0, Math.min(100, pct));
    const offset = c - (clamped / 100) * c;
    return \`<svg width="13" height="13" viewBox="0 0 14 14" style="flex-shrink:0;transform:rotate(-90deg);display:block">
      <circle cx="7" cy="7" r="\${r}" fill="none" stroke="currentColor" stroke-opacity="0.22" stroke-width="2"></circle>
      <circle cx="7" cy="7" r="\${r}" fill="none" stroke="\${color}" stroke-width="2" stroke-dasharray="\${c.toFixed(2)}" stroke-dashoffset="\${offset.toFixed(2)}" stroke-linecap="round"></circle>
    </svg>\`;
  }

  function getModelPillButton() {
    return document.querySelector('button[role="combobox"][class*="modelPill"]');
  }

  function getSelectedModelLabel() {
    const btn = getModelPillButton();
    if (btn) {
      const txt = (btn.textContent || '').replace(/\\s+/g, ' ').trim();
      if (txt) return txt;
    }
    const s = activeSession;
    if (s) {
      const m = s.lastServedModel?.value || s.modelSelection?.value || s.config?.value?.modelSetting;
      if (m) return String(m);
    }
    return 'Claude';
  }

  function inferMaxTokensFromModel(s) {
    const candidates = [];
    if (s) {
      if (s.lastServedModel?.value) candidates.push(String(s.lastServedModel.value));
      if (s.modelSelection?.value) candidates.push(String(s.modelSelection.value));
      if (s.config?.value?.modelSetting) candidates.push(String(s.config.value.modelSetting));
    }
    const pill = getModelPillButton();
    if (pill) {
      candidates.push(pill.textContent || '');
      candidates.push(pill.getAttribute('title') || '');
    }
    const combined = candidates.join(' ').toLowerCase();
    if (!combined.trim()) return 1000000;
    if (
      combined.includes('[1m]') ||
      combined.includes('1m context') ||
      combined.includes('fable') ||
      combined.includes('mythos') ||
      combined.includes('opus-4-7') ||
      combined.includes('opus 4.7') ||
      combined.includes('opus-4-8') ||
      combined.includes('opus 4.8') ||
      combined.includes('sonnet-5') ||
      combined.includes('sonnet 5') ||
      combined.includes('opus-5') ||
      combined.includes('opus 5') ||
      /\\b5\\.[0-9]/.test(combined)
    ) {
      return 1000000;
    }
    if (
      combined.includes('haiku') ||
      combined.includes('4-5') ||
      combined.includes('4.5') ||
      combined.includes('4-6') ||
      combined.includes('4.6') ||
      combined.includes('sonnet-4') ||
      combined.includes('opus-4')
    ) {
      return 200000;
    }
    return 1000000;
  }

  function getCachedRpcUsage(s) {
    if (!s) return null;
    return rpcCacheBySession.get(s)?.usage || null;
  }

  function getEffectiveMetrics() {
    const s = activeSession;
    const rpc = getCachedRpcUsage(s);
    const uData = s?.usageData?.value;

    let usedTokens = 0;
    if (uData && Number(uData.totalTokens) > 0) {
      usedTokens = Number(uData.totalTokens);
    } else if (rpc && Number(rpc.totalTokens) > 0) {
      usedTokens = Number(rpc.totalTokens);
    } else if (lastHookUsedTokens > 0) {
      usedTokens = Number(lastHookUsedTokens);
    }

    let maxTokens = 0;
    if (rpc && Number(rpc.rawMaxTokens) > 0) {
      maxTokens = Number(rpc.rawMaxTokens);
    } else if (uData && Number(uData.contextWindow) > 0) {
      maxTokens = Number(uData.contextWindow);
    } else if (rpc && Number(rpc.maxTokens) > 0) {
      maxTokens = Number(rpc.maxTokens);
    } else if (lastHookContextWindow > 0) {
      maxTokens = Number(lastHookContextWindow);
    } else {
      maxTokens = inferMaxTokensFromModel(s);
    }

    const pct = maxTokens > 0 ? Math.min(100, (usedTokens / maxTokens) * 100) : 0;
    return { usedTokens, maxTokens, pct, rpc, apiUsage: s?.__bhfLastApiUsage || rpc?.apiUsage || null };
  }

  async function refreshRpcContextUsage(force = false, allowOpenChannel = false) {
    const s = activeSession;
    if (!s) return;
    const channelId = s.claudeChannelId || s.claudeChannelIdSignal?.value;
    const conn = s.connection?.value;
    if (!channelId && !allowOpenChannel) return;

    const uData = s.usageData?.value;
    const curTokens = Number(uData?.totalTokens || 0);
    const curModel = String(s.lastServedModel?.value || s.modelSelection?.value || '');
    const cached = rpcCacheBySession.get(s);
    const now = Date.now();

    if (
      !force &&
      cached &&
      cached.tokens === curTokens &&
      cached.model === curModel &&
      now - cached.fetchedAt < 10000
    ) {
      return;
    }
    if (isFetchingRpc) return;
    isFetchingRpc = true;
    try {
      let res = null;
      if (channelId && conn && typeof conn.getContextUsage === 'function') {
        res = await conn.getContextUsage(channelId);
      } else if (allowOpenChannel && typeof s.getContextUsage === 'function') {
        res = await s.getContextUsage();
      }
      if (res && res.usage) {
        rpcCacheBySession.set(s, {
          usage: res.usage,
          tokens: Number(s.usageData?.value?.totalTokens || res.usage.totalTokens || 0),
          model: curModel,
          fetchedAt: Date.now()
        });
        updateAllButtons();
      }
    } catch {} finally {
      isFetchingRpc = false;
    }
  }

  function updateAllButtons() {
    const { usedTokens, maxTokens, pct } = getEffectiveMetrics();
    const color = getStatusColor(pct);
    const usedText = formatCompactTokens(usedTokens);
    const maxText = formatCompactTokens(maxTokens);
    const pctRound = Math.round(pct);
    const tooltip = \`Context Window: \${formatExactTokens(usedTokens)} / \${formatExactTokens(maxTokens)} tokens (\${pct.toFixed(1)}%) — Click for breakdown\`;

    const buttons = document.querySelectorAll(\`[data-testid="\${BTN_TESTID}"]\`);
    buttons.forEach((btn) => {
      if (btn.title !== tooltip) btn.title = tooltip;
      if (btn.getAttribute('aria-label') !== tooltip) btn.setAttribute('aria-label', tooltip);
      const openAttr = popoverOpen ? 'true' : 'false';
      if (btn.getAttribute('data-open') !== openAttr) btn.setAttribute('data-open', openAttr);
      const html = \`\${buildRingSvg(pct, color)}<span>\${usedText} / \${maxText}</span><span class="bhf-ctx-pct">\${pctRound}%</span>\`;
      if (btn.__lastHtml !== html) {
        btn.innerHTML = html;
        btn.__lastHtml = html;
      }
    });

    if (popoverOpen) {
      renderPopoverContent();
    }
  }

  function closePopover() {
    popoverOpen = false;
    const existing = document.getElementById(POPOVER_ID);
    if (existing) existing.remove();
    updateAllButtons();
  }

  function openNativeContextDialog() {
    closePopover();
    try {
      if (typeof window.__bhfOpenContextDialog === 'function') {
        window.__bhfOpenContextDialog();
      }
    } catch {}
  }

  function triggerCompactNow() {
    closePopover();
    try {
      if (typeof activeOnCompact === 'function') {
        activeOnCompact();
      }
    } catch {}
  }

  function positionPopover(popoverEl, anchorEl) {
    if (!popoverEl || !anchorEl) return;
    const rect = anchorEl.getBoundingClientRect();
    const popRect = popoverEl.getBoundingClientRect();
    const margin = 8;

    let left = rect.left;
    if (left + popRect.width > window.innerWidth - 12) {
      left = Math.max(12, window.innerWidth - popRect.width - 12);
    }
    if (left < 12) left = 12;

    let top = rect.top - popRect.height - margin;
    if (top < 12) {
      top = Math.min(window.innerHeight - popRect.height - 12, rect.bottom + margin);
    }

    popoverEl.style.left = \`\${Math.round(left)}px\`;
    popoverEl.style.top = \`\${Math.round(top)}px\`;
  }

  function buildCategoriesList(usedTokens, maxTokens, rpc, apiUsage) {
    const categories = [];
    if (rpc && Array.isArray(rpc.categories)) {
      const activeCats = rpc.categories.filter(
        (c) => c && c.tokens > 0 && !c.isDeferred && c.name !== 'Free space' && c.name !== 'Autocompact buffer'
      );
      activeCats.forEach((c, idx) => {
        categories.push({
          label: c.name,
          tokens: Number(c.tokens || 0),
          color: CATEGORY_COLORS[c.name] || FALLBACK_PALETTE[idx % FALLBACK_PALETTE.length]
        });
      });
    } else if (apiUsage && usedTokens > 0) {
      const cached = Number(apiUsage.cache_read_input_tokens || 0) + Number(apiUsage.cache_creation_input_tokens || 0);
      const freshIn = Number(apiUsage.input_tokens || 0);
      const out = Number(apiUsage.output_tokens || 0);
      if (cached > 0) categories.push({ label: 'Cached Context (Prompt & History)', tokens: cached, color: '#6366f1' });
      if (freshIn > 0) categories.push({ label: 'New Turn Input', tokens: freshIn, color: '#06b6d4' });
      if (out > 0) categories.push({ label: 'Last Assistant Output', tokens: out, color: '#10b981' });
    }

    if (categories.length === 0 && usedTokens > 0) {
      categories.push({
        label: 'Active Conversation Context',
        tokens: usedTokens,
        color: '#10b981'
      });
    }
    return categories;
  }

  function renderPopoverContent() {
    let pop = document.getElementById(POPOVER_ID);
    if (!pop) {
      pop = document.createElement('div');
      pop.id = POPOVER_ID;
      pop.className = 'bhf-ctx-popover';
      document.body.appendChild(pop);
    }

    const { usedTokens, maxTokens, pct, rpc, apiUsage } = getEffectiveMetrics();
    const remainingTokens = Math.max(0, maxTokens - usedTokens);
    const categories = buildCategoriesList(usedTokens, maxTokens, rpc, apiUsage);
    const modelLabel = getSelectedModelLabel() || rpc?.model || 'Current Model';

    const segsHtml = categories
      .filter((c) => c.tokens > 0 && maxTokens > 0)
      .map((c) => {
        const w = Math.max(0.8, Math.min(100, (c.tokens / maxTokens) * 100));
        return \`<div class="bhf-ctx-bar-seg" style="width:\${w.toFixed(2)}%;background:\${c.color}" title="\${c.label}: \${formatExactTokens(c.tokens)} tokens"></div>\`;
      })
      .join('');

    const rowsHtml = categories
      .map((c) => {
        const cPct = maxTokens > 0 ? ((c.tokens / maxTokens) * 100).toFixed(1) : '0.0';
        return \`<div class="bhf-ctx-row">
          <div class="bhf-ctx-row-left">
            <span class="bhf-ctx-dot" style="background:\${c.color}"></span>
            <span>\${c.label}</span>
          </div>
          <span>\${formatExactTokens(c.tokens)} <span style="opacity:0.6">(\${cPct}%)</span></span>
        </div>\`;
      })
      .join('');

    const remPct = maxTokens > 0 ? ((remainingTokens / maxTokens) * 100).toFixed(1) : '100.0';
    const cachedTokens = Number(apiUsage?.cache_read_input_tokens || 0) + Number(apiUsage?.cache_creation_input_tokens || 0);
    const inputTokens = Number(apiUsage?.input_tokens || 0);
    const outputTokens = Number(apiUsage?.output_tokens || 0);
    const canCompact = typeof activeOnCompact === 'function' && usedTokens > 0 && !activeSession?.busy?.value;

    pop.innerHTML = \`
      <div class="bhf-ctx-header">
        <div class="bhf-ctx-title">
          <span>Context Window</span>
          <span style="font-size:10.5px;font-weight:500;opacity:0.65;max-width:175px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${modelLabel}</span>
        </div>
        <div style="display:flex;align-items:center;gap:2px">
          <button type="button" class="bhf-ctx-icon-btn" data-bhf-action="refresh" title="Refresh token breakdown">↻</button>
          <button type="button" class="bhf-ctx-icon-btn" data-bhf-action="close" title="Close">✕</button>
        </div>
      </div>
      <div class="bhf-ctx-sub">
        <span style="font-weight:600;font-size:13px">\${formatExactTokens(usedTokens)} <span style="opacity:0.65;font-weight:400">/ \${formatExactTokens(maxTokens)} tokens</span></span>
        <span style="font-weight:600;color:\${getStatusColor(pct)}">\${pct.toFixed(1)}% used</span>
      </div>
      <div class="bhf-ctx-bar-track">\${segsHtml}</div>
      <div class="bhf-ctx-rows">
        \${rowsHtml}
        <div class="bhf-ctx-row" style="padding-top:2px;opacity:0.8">
          <div class="bhf-ctx-row-left">
            <span class="bhf-ctx-dot" style="background:rgba(128,128,135,0.35)"></span>
            <span>Available Capacity</span>
          </div>
          <span>\${formatExactTokens(remainingTokens)} <span style="opacity:0.6">(\${remPct}%)</span></span>
        </div>
      </div>
      <div class="bhf-ctx-meta-grid">
        <div class="bhf-ctx-meta-box">
          <span class="bhf-ctx-meta-label">Cached Input</span>
          <span class="bhf-ctx-meta-val">\${formatCompactTokens(cachedTokens)}</span>
        </div>
        <div class="bhf-ctx-meta-box">
          <span class="bhf-ctx-meta-label">New Input</span>
          <span class="bhf-ctx-meta-val">\${formatCompactTokens(inputTokens)}</span>
        </div>
        <div class="bhf-ctx-meta-box">
          <span class="bhf-ctx-meta-label">Last Output</span>
          <span class="bhf-ctx-meta-val">\${formatCompactTokens(outputTokens)}</span>
        </div>
      </div>
      <div class="bhf-ctx-footer">
        <button type="button" class="bhf-ctx-action-btn" data-bhf-action="inspector" title="Open Claude Code's detailed context modal (/context)">
          <span>Open Full Context Details</span>
        </button>
        <button type="button" class="bhf-ctx-action-btn bhf-ctx-compact-btn" data-bhf-action="compact" \${canCompact ? '' : 'disabled'} title="Compact conversation context (/compact)">
          <span>Compact Now</span>
        </button>
      </div>
    \`;

    pop.querySelector('[data-bhf-action="close"]')?.addEventListener('click', (e) => {
      e.stopPropagation();
      closePopover();
    });
    pop.querySelector('[data-bhf-action="refresh"]')?.addEventListener('click', (e) => {
      e.stopPropagation();
      refreshRpcContextUsage(true, true);
    });
    pop.querySelector('[data-bhf-action="inspector"]')?.addEventListener('click', (e) => {
      e.stopPropagation();
      openNativeContextDialog();
    });
    pop.querySelector('[data-bhf-action="compact"]')?.addEventListener('click', (e) => {
      e.stopPropagation();
      triggerCompactNow();
    });

    if (activeTriggerEl) {
      positionPopover(pop, activeTriggerEl);
    }
  }

  function togglePopover(triggerEl) {
    if (popoverOpen && activeTriggerEl === triggerEl) {
      closePopover();
      return;
    }
    activeTriggerEl = triggerEl;
    popoverOpen = true;
    renderPopoverContent();
    updateAllButtons();
    refreshRpcContextUsage(true, false);
  }

  function injectContextButtons() {
    ensureStyles();
    // Clean up any orphaned wrappers whose preceding sibling is no longer the modelPill button
    document.querySelectorAll(\`[\${WRAPPER_ATTR}="true"]\`).forEach((w) => {
      const prev = w.previousElementSibling;
      if (!prev || prev.getAttribute('role') !== 'combobox') {
        w.remove();
      }
    });

    const modelPills = document.querySelectorAll('button[role="combobox"][class*="modelPill"]');
    modelPills.forEach((pill) => {
      const next = pill.nextElementSibling;
      if (next && next.getAttribute(WRAPPER_ATTR) === 'true') return;

      const wrapper = document.createElement('div');
      wrapper.setAttribute(WRAPPER_ATTR, 'true');
      wrapper.setAttribute('data-footer-overlay', '');

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('data-testid', BTN_TESTID);
      btn.setAttribute('data-footer-overlay', '');
      btn.className = 'bhf-ctx-btn';
      btn.addEventListener('mousedown', (e) => {
        e.preventDefault();
      });
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.altKey || e.shiftKey) {
          openNativeContextDialog();
          return;
        }
        togglePopover(btn);
      });

      wrapper.appendChild(btn);
      pill.insertAdjacentElement('afterend', wrapper);
      updateAllButtons();
    });
  }

  const VALID_IDLE_PERM_MODES = {
    acceptEdits: 1,
    auto: 1,
    bypassPermissions: 1,
    default: 1,
    plan: 1
  };
  let lastSharedPermMode = '';

  function resolveConfigPermMode(s) {
    const cfg = s?.connection?.value?.config?.value;
    const cfgInit =
      typeof cfg?.initialPermissionMode === 'string' && VALID_IDLE_PERM_MODES[cfg.initialPermissionMode]
        ? cfg.initialPermissionMode
        : '';
    const cfgSettingsMode =
      typeof cfg?.claudeSettings?.effective?.permissions?.defaultMode === 'string' &&
      VALID_IDLE_PERM_MODES[cfg.claudeSettings.effective.permissions.defaultMode]
        ? cfg.claudeSettings.effective.permissions.defaultMode
        : '';
    return cfgInit || cfgSettingsMode;
  }

  function ensureSessionPermHook(s) {
    if (!s || s.__bhfWrappedSetPerm || typeof s.setPermissionMode !== 'function') return;
    s.__bhfWrappedSetPerm = true;
    const orig = s.setPermissionMode.bind(s);
    s.setPermissionMode = function(mode, pushToCli, userInitiated, opts) {
      if (userInitiated !== false) {
        s.__bhfUserPickedModeUnder = lastSharedPermMode || resolveConfigPermMode(s) || '__manual__';
        s.__bhfSyncedIntoPlan = false;
      }
      return orig(mode, pushToCli, userInitiated, opts);
    };
  }

  function syncIdleSessionPermMode(explicitMode, fromHostPush, resetSessionOverrides) {
    const s = activeSession;
    if (!s || typeof s.setPermissionMode !== 'function') return;
    ensureSessionPermHook(s);
    const cfg = s.connection?.value?.config?.value;
    const rawTarget = explicitMode || lastSharedPermMode || resolveConfigPermMode(s);
    const target = VALID_IDLE_PERM_MODES[rawTarget] ? rawTarget : '';
    if (!target) return;
    if (target === 'bypassPermissions' && cfg && cfg.allowDangerouslySkipPermissions !== true) {
      return;
    }
    if (s.claudeChannelId) return;
    const cur = s.permissionMode?.value;
    if (!cur) return;
    if (cur === target) {
      if (target === 'plan' && !s.__bhfUserPickedModeUnder) {
        s.__bhfSyncedIntoPlan = true;
      }
      return;
    }
    if (!resetSessionOverrides && cur === 'plan' && target !== 'plan' && !s.__bhfSyncedIntoPlan) {
      return;
    }
    if (!fromHostPush && !resetSessionOverrides && s.__bhfUserPickedModeUnder === target) return;
    if (!fromHostPush && !resetSessionOverrides && s.__bhfIdlePermSyncedFor === target) return;
    s.__bhfIdlePermSyncedFor = target;
    try {
      s.setPermissionMode(target, false, false);
      s.__bhfSyncedIntoPlan = target === 'plan';
    } catch {}
  }

  window.addEventListener('message', (ev) => {
    const d = ev && ev.data;
    if (d && d.type === 'bhf_shared_permission_mode' && typeof d.mode === 'string' && d.mode) {
      const modeChanged = lastSharedPermMode !== d.mode;
      const resetOverrides = Boolean(d.resetSessionOverrides);
      lastSharedPermMode = d.mode;
      if ((modeChanged || resetOverrides) && activeSession) {
        activeSession.__bhfUserPickedModeUnder = '';
        activeSession.__bhfIdlePermSyncedFor = '';
      }
      syncIdleSessionPermMode(d.mode, modeChanged || resetOverrides, resetOverrides);
    }
  });

  window.__bhfTrackClaudeSession = function(session, onCompact, usedTokens, contextWindow) {
    const changed = activeSession !== session;
    if (session) activeSession = session;
    if (typeof onCompact === 'function') activeOnCompact = onCompact;
    if (typeof usedTokens === 'number') lastHookUsedTokens = usedTokens;
    if (typeof contextWindow === 'number') lastHookContextWindow = contextWindow;
    queueMicrotask(() => {
      syncIdleSessionPermMode('', false);
      injectContextButtons();
      updateAllButtons();
      if (changed || usedTokens > 0) {
        refreshRpcContextUsage(false, false);
      }
    });
  };

  window.__bhfNotifySessionUsage = function(session) {
    if (session && (!activeSession || activeSession === session)) {
      activeSession = session;
      queueMicrotask(() => {
        updateAllButtons();
        refreshRpcContextUsage(false, false);
      });
    }
  };

  document.addEventListener('mousedown', (e) => {
    if (!popoverOpen) return;
    const pop = document.getElementById(POPOVER_ID);
    const target = e.target;
    if (pop && target instanceof Node && (pop.contains(target) || (activeTriggerEl && activeTriggerEl.contains(target)))) {
      return;
    }
    closePopover();
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && popoverOpen) {
      closePopover();
    }
  });

  window.addEventListener('resize', () => {
    if (popoverOpen && activeTriggerEl) {
      const pop = document.getElementById(POPOVER_ID);
      if (pop) positionPopover(pop, activeTriggerEl);
    }
  });

  const observer = new MutationObserver(() => {
    injectContextButtons();
  });

  function start() {
    injectContextButtons();
    updateAllButtons();
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    }
    setInterval(() => {
      syncIdleSessionPermMode('', false);
      injectContextButtons();
      updateAllButtons();
      refreshRpcContextUsage(false, false);
    }, 2500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
/*bhf-context-window-end*/
`.trim();

function patchClaudeExtensionSource(sourceText, options = {}) {
  if (typeof sourceText !== 'string' || !sourceText) {
    throw new Error('Empty Claude Code extension bundle.');
  }
  const col = options.column === 'Active' ? 'Active' : 'One';
  let src = sourceText;

  // 1. Pin new Claude Code editor tabs to ViewColumn.One (/*bhf-pin*/)
  const pinPatchedRe = /([\w$]+)=([\w$]+)\.ViewColumn\.(One|Active);\/\*bhf-pin\*\//;
  const stockOldRe =
    /([\w$]+)=([\w$]+)\.ViewColumn\.Beside;let ([\w$]+)=([\w$]+)\([^;]*\);if\(\3(?:!==void 0)?\)\1=\3(?:\.viewColumn)?;else \1=this\.findUnusedColumn\(\),([\w$]+)=(?:!0|\1!==\2\.ViewColumn\.Beside)/;
  const stock283Re =
    /if\(([\w$]+)!==void 0\)([\w$]+)=\1;else\{let ([\w$]+)=([\w$]+)\.window\.tabGroups\.all\.map\(/;

  if (pinPatchedRe.test(src)) {
    src = src.replace(pinPatchedRe, (_, g1, g2) => `${g1}=${g2}.ViewColumn.${col};/*bhf-pin*/`);
  } else if (stockOldRe.test(src)) {
    src = src.replace(stockOldRe, (_, g1, g2) => `${g1}=${g2}.ViewColumn.${col};/*bhf-pin*/`);
  } else if (stock283Re.test(src)) {
    src = src.replace(
      stock283Re,
      (_, g1, g2, g3, g4) =>
        `if(${g1}!==void 0)${g2}=${g1};else if(!0)${g2}=${g4}.ViewColumn.${col};/*bhf-pin*/else{let ${g3}=${g4}.window.tabGroups.all.map(`
    );
  }

  // 2. Attach compat/claude-hub-bridge.cjs (/*claude-hub-bridge-v1*/)
  if (!src.includes(`/*${CLAUDE_BRIDGE_MARKER}*/`)) {
    const attachRe =
      /(([\w$]+)\.subscriptions\.push\(([\w$]+)\.window\.registerWebviewViewProvider\("claudeVSCodeSessionsList",\{resolveWebviewView\(([\w$]+),([\w$]+),([\w$]+)\)\{([\w$]+)\.resolveSessionListView\(\4,\5,\6\)\}\})/;
    const match = src.match(attachRe);
    if (!match) {
      throw new Error(
        'Could not find claudeVSCodeSessionsList registration anchor in Claude Code extension.js.'
      );
    }
    const [fullMatch, , ctxVar, vscodeVar, , , , controllerVar] = match;
    const injection =
      `(()=>{/*${CLAUDE_BRIDGE_MARKER}*/try{require("./claude-hub-bridge.cjs").attach({vscode:${vscodeVar},context:${ctxVar},controller:${controllerVar}})}catch(_bhfErr){console.error("[claude-hub-bridge]",_bhfErr)}})(),` +
      fullMatch;
    src = src.replace(fullMatch, () => injection);
  }

  // 3. Ensure Developer: Reload Window seamlessly resumes interrupted turns (/*bhf-reload-resume*/)
  if (!src.includes(CLAUDE_RELOAD_MARKER)) {
    // 3a. Raise continueAfterReload.reruns limit from 2 to 99 so multiple window reloads never pause a session
    const rerunLimitRe = /([\w$]+=3600000,[\w$]+=)2(;function [\w$]+\([\w$]+\)\{return`continueAfterReload\.reruns:)/;
    if (rerunLimitRe.test(src)) {
      src = src.replace(
        rerunLimitRe,
        (_, prefix, suffix) => `${prefix}99${CLAUDE_RELOAD_MARKER}${suffix}`
      );
    }
    // 3b. Raise lock release wait timeout from 2000ms to 10000ms so pre-reload claude.exe shutdown never triggers false 'held elsewhere'
    const releaseWaitRe = /var ([\w$]+)=2000;(function [\w$]+\([\w$]+,[\w$]+,[\w$]+\)\{if\([\w$]+===void 0\)return Promise\.resolve\(!0\))/;
    if (releaseWaitRe.test(src)) {
      src = src.replace(
        releaseWaitRe,
        (_, varName, suffix) => `var ${varName}=10000;${CLAUDE_RELOAD_MARKER}${suffix}`
      );
    }
    // 3c. Pass reopenedAfterRestart = true (6th arg) in deserializeWebviewPanel's setupPanel call
    const deserRe =
      /(async deserializeWebviewPanel\(([\w$]+),([\w$]+)\)\{[\s\S]{0,260}?([\w$]+)\.setupPanel\(\2,([\w$]+),void 0,([\w$]+))\)/;
    if (deserRe.test(src)) {
      src = src.replace(deserRe, (_, prefix) => `${prefix},!1,!0${CLAUDE_RELOAD_MARKER})`);
    }
  }

  if (options.validateSyntax !== false) {
    new vm.Script(src, { filename: 'claude-extension.js' });
  }
  return src;
}

function patchClaudeWebviewSource(sourceText, options = {}) {
  if (typeof sourceText !== 'string' || !sourceText) {
    throw new Error('Empty Claude Code webview bundle.');
  }
  let src = sourceText;

  // 1. Suppress yellow usage warning banner (/*bhf-nowarn*/)
  if (!src.includes(CLAUDE_NOWARN_MARKER)) {
    const usageBannerRe =
      /\}if\(([\w$]+)\.utilization!==void 0&&\1\.utilization<([\w$]+)\)return null;let ([\w$]+)=\1\.rateLimitType/;
    if (usageBannerRe.test(src)) {
      src = src.replace(
        usageBannerRe,
        (_, g1, _g2, g3) => `}if(!0)return null;${CLAUDE_NOWARN_MARKER}let ${g3}=${g1}.rateLimitType`
      );
    }
  }

  // 2. Suppress "Connecting to browser…" / "Browser connected" banner (/*bhf-nobrowserbanner*/)
  if (!src.includes(CLAUDE_NOBROWSER_MARKER)) {
    const browserBannerRe =
      /function ([\w$]+)\(\{state:([\w$]+),onClose:([\w$]+),otherPopupsVisible:([\w$]+)\}\)\{if\(\4\)return null;(?=[^\n]{0,400}"Connecting to browser…"[^\n]{0,200}"Browser connected")/;
    if (browserBannerRe.test(src)) {
      src = src.replace(
        browserBannerRe,
        (_, fnName, stateVar, onCloseVar, otherVar) =>
          `function ${fnName}({state:${stateVar},onClose:${onCloseVar},otherPopupsVisible:${otherVar}}){if(${otherVar}||${stateVar}.status!=="error")return null;${CLAUDE_NOBROWSER_MARKER}`
      );
    }
  }

  // 3. Zero expired rate_limits windows in native /usage modal (/*bhf-usage-reset*/)
  if (!src.includes(CLAUDE_USAGE_RESET_MARKER)) {
    const usageResetRe =
      /\.flatMap\(\(\{label:([\w$]+),window:([\w$]+)\}\)=>\{if\(!\2\|\|\2\.utilization===null\)return\[\];return\[\{label:\1,utilization:\2\.utilization,resetsAt:\2\.resets_at\?\?void 0((?:,[^}]*)?)\}\]\}\)/;
    if (usageResetRe.test(src)) {
      src = src.replace(
        usageResetRe,
        (_, labelVar, winVar, extraProps = '') =>
          `.flatMap(({label:${labelVar},window:${winVar}})=>{if(!${winVar}||${winVar}.utilization===null)return[];${CLAUDE_USAGE_RESET_MARKER}let _bhfExp=${winVar}.resets_at?Date.parse(${winVar}.resets_at)<=Date.now():!1;return[{label:${labelVar},utilization:_bhfExp?0:${winVar}.utilization,resetsAt:_bhfExp?void 0:${winVar}.resets_at??void 0${extraProps}}]})`
      );
    }
  }

  // 4. Inject live Context Window pill + breakdown popover (/*bhf-context-window*/)
  if (!src.includes(CLAUDE_CTX_MARKER)) {
    const rUpdate = /updateUsage\(([\w$]+)\)\{let ([\w$]+)=\1\.input_tokens\+/;
    const rComp =
      /function ([\w$]+)\(\{usedTokens:([\w$]+),contextWindow:([\w$]+),onCompact:([\w$]+),buttonClassName:([\w$]+)\}\)\{/;
    const rCall =
      /(usedTokens:([\w$]+)\.usageData\.value\.totalTokens,contextWindow:[\w$]+\(\2\.usageData\.value\.contextWindow,\2\.usageData\.value\.maxOutputTokens\),onCompact:[\w$]+,buttonClassName:[\w$]+\.usageButtonV2)/;
    const rDialog = /openContextDialog:\(\)=>([\w$]+)\(!0\)/;

    if (rUpdate.test(src) && rComp.test(src) && rCall.test(src) && rDialog.test(src)) {
      src = src.replace(
        rUpdate,
        (_, uVar, sumVar) =>
          `updateUsage(${uVar}){this.__bhfLastApiUsage=${uVar};window.__bhfNotifySessionUsage?.(this);let ${sumVar}=${uVar}.input_tokens+`
      );
      src = src.replace(
        rComp,
        (_, fnName, usedVar, cwVar, compactVar, clsVar) =>
          `function ${fnName}({usedTokens:${usedVar},contextWindow:${cwVar},onCompact:${compactVar},buttonClassName:${clsVar},session:__bhfS}){try{window.__bhfTrackClaudeSession?.(__bhfS,${compactVar},${usedVar},${cwVar})}catch{}return null;${CLAUDE_CTX_MARKER}`
      );
      src = src.replace(rCall, (_, full, sessVar) => `${full},session:${sessVar}`);
      src = src.replace(
        rDialog,
        (_, fnVar) => `openContextDialog:(window.__bhfOpenContextDialog=()=>(${fnVar}(!0)))`
      );
      src = `${src}\n${CLAUDE_CTX_UI_RUNTIME_JS}\n`;
    }
  } else if (/\/\*bhf-context-window-start\*\/[\s\S]*?\/\*bhf-context-window-end\*\//.test(src)) {
    src = src.replace(
      /\/\*bhf-context-window-start\*\/[\s\S]*?\/\*bhf-context-window-end\*\//,
      () => CLAUDE_CTX_UI_RUNTIME_JS
    );
  }

  // 5. Ensure interrupted turns auto-resume when sessions load after reload (/*bhf-reload-resume*/)
  if (!src.includes(CLAUDE_RELOAD_MARKER)) {
    // 5a. In open_session startup handler, always enable resumeInterruptedTurnOnLoad when no new prompt is being submitted
    const openSessRe =
      /let ([\w$]+)=([\w$]+)\.afterExtensionRestart\?\(([\w$]+)\)=>\{\3\.resumeInterruptedTurnOnLoad="extensionRestart"\}:void 0;/;
    if (openSessRe.test(src)) {
      src = src.replace(
        openSessRe,
        (_, cbVar, mVar, eVar) =>
          `let ${cbVar}=(${eVar})=>{${eVar}.resumeInterruptedTurnOnLoad=${mVar}.afterExtensionRestart?"extensionRestart":"reload"};${CLAUDE_RELOAD_MARKER}`
      );
    }
    // 5b. In loadFromServer, default Z to 'reload' on initial channel load and do not let historical background subagents (!Jm1) block auto-resume
    const loadZRe =
      /let ([\w$]+)=!1,([\w$]+)=this\.resumeInterruptedTurnOnLoad;if\(this\.resumeInterruptedTurnOnLoad=void 0,/;
    if (loadZRe.test(src)) {
      src = src.replace(
        loadZRe,
        (_, jVar, zVar) =>
          `let ${jVar}=!1,${zVar}=this.resumeInterruptedTurnOnLoad||(this.claudeChannelId===void 0?"reload":void 0);${CLAUDE_RELOAD_MARKER}if(this.resumeInterruptedTurnOnLoad=void 0,`
      );
    }
    const loadARe =
      /(let [\w$]+=[\w$]+!==void 0&&[\w$]+\([\w$]+\.messages\.at\(-1\)\)===void 0&&[\w$]+\(([\w$]+)\)&&[\w$]+\(\2\)===void 0)&&!([\w$]+)\(\2\)/;
    if (loadARe.test(src)) {
      src = src.replace(
        loadARe,
        (_, prefix, dVar, jmVar) => `${prefix}&&(!0||!${jmVar}(${dVar}))${CLAUDE_RELOAD_MARKER}`
      );
    }
  }

  if (options.validateSyntax !== false) {
    new vm.Script(src, { filename: 'claude-webview-index.js' });
  }
  return src;
}

module.exports = {
  CLAUDE_BRIDGE_MARKER,
  CLAUDE_PIN_MARKER,
  CLAUDE_NOWARN_MARKER,
  CLAUDE_NOBROWSER_MARKER,
  CLAUDE_CTX_MARKER,
  CLAUDE_USAGE_RESET_MARKER,
  CLAUDE_RELOAD_MARKER,
  CLAUDE_CTX_UI_RUNTIME_JS,
  patchClaudeExtensionSource,
  patchClaudeWebviewSource
};
