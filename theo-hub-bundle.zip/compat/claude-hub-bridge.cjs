const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
let excelPreview = null;
try {
  excelPreview = require('./excel-preview.cjs');
} catch {}

const BRIDGE_VERSION = '0.1.0';
const STATE_SYMBOL = Symbol.for('bhfirms.antigravityHub.claudeBridgeState');
const CLAUDE_DRAFT_SCHEME = 'claude-session';

const TAB_ICON_FILES = {
  plain: 'claude-logo.svg',
  done: 'claude-logo-done.svg',
  pending: 'claude-logo-pending.svg'
};

function makeDraftId() {
  if (typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
}

function getBridgeState() {
  if (!globalThis[STATE_SYMBOL]) {
    globalThis[STATE_SYMBOL] = {
      attached: false,
      version: BRIDGE_VERSION,
      vscode: null,
      context: null,
      controller: null,
      sidebarView: null,
      sidebarDelegate: null,
      sidebarFallbackTimer: null,
      origResolveSessionListView: null,
      badgeById: new Map(),
      lastRateLimitWindows: null,
      lastFullRateLimits: null,
      lastFullRateLimitsAt: 0,
      lastProcessUsagePollAt: 0,
      activityTimer: null,
      commandsRegistered: false,
      hookedPanels: new WeakSet(),
      hookedComms: new WeakSet(),
      pendingPermissions: new Map()
    };
  }
  return globalThis[STATE_SYMBOL];
}

function getHideDuplicateSetting(vscode) {
  try {
    return Boolean(
      vscode?.workspace
        ?.getConfiguration('antigravityHub')
        ?.get('hideDuplicateActivityBarIcon', true)
    );
  } catch {
    return true;
  }
}

function applyActivityBarVisibility(state) {
  const { vscode } = state;
  if (!vscode?.commands) {
    return;
  }
  const hideDuplicate = getHideDuplicateSetting(vscode);
  vscode.commands
    .executeCommand('setContext', 'claude-vscode.sessionsListEnabled', !hideDuplicate)
    .then(
      () => {},
      () => {}
    );
}

function notifyActivityChanged(payload = {}) {
  const state = getBridgeState();
  const { vscode } = state;
  if (!vscode?.commands) {
    return;
  }
  if (state.activityTimer) {
    clearTimeout(state.activityTimer);
  }
  state.activityTimer = setTimeout(() => {
    state.activityTimer = null;
    vscode.commands
      .executeCommand('antigravityHub.activityChanged', {
        provider: 'claude',
        ...payload
      })
      .then(
        () => {},
        () => {}
      );
  }, 60);
}

function notifyThreadSeen(threadId) {
  const cleanId = String(threadId || '').trim();
  if (!cleanId) {
    return;
  }
  const state = getBridgeState();
  if (state.badgeById.get(cleanId) === 'done') {
    state.badgeById.set(cleanId, 'plain');
  }
  try {
    state.controller?.setSessionUnread?.(cleanId, false);
  } catch {}
  if (state.vscode?.commands) {
    state.vscode.commands
      .executeCommand('antigravityHub.markThreadSeen', {
        id: cleanId,
        provider: 'claude',
        seenAt: Math.floor(Date.now() / 1000)
      })
      .then(
        () => {},
        () => {}
      );
  }
}

function getTabIconPath(state, badgeState = 'plain') {
  const { vscode, context } = state;
  if (!vscode?.Uri || !context?.extensionPath) {
    return null;
  }
  const fileName = TAB_ICON_FILES[badgeState] || TAB_ICON_FILES.plain;
  const iconUri = vscode.Uri.file(path.join(context.extensionPath, 'resources', fileName));
  return { light: iconUri, dark: iconUri };
}

function doesIconMatchFileName(iconPath, fileName) {
  if (!iconPath || !fileName) {
    return false;
  }
  const target = iconPath.dark || iconPath.light || iconPath;
  const raw = String(target?.fsPath || target?.path || target || '');
  if (!raw) {
    return false;
  }
  const lower = raw.toLowerCase();
  const suffix = String(fileName).toLowerCase();
  return lower.endsWith(`/${suffix}`) || lower.endsWith(`\\${suffix}`) || lower === suffix;
}

function applyPanelTabIcon(state, panel, badgeState = 'plain') {
  if (!panel) {
    return false;
  }
  const normalized = TAB_ICON_FILES[badgeState] ? badgeState : 'plain';
  const expectedFile = TAB_ICON_FILES[normalized];
  if (
    panel.__bhfBadgeState === normalized &&
    doesIconMatchFileName(panel.iconPath, expectedFile)
  ) {
    return false;
  }
  const iconPath = getTabIconPath(state, normalized);
  if (!iconPath) {
    return false;
  }
  try {
    panel.iconPath = iconPath;
    panel.__bhfBadgeState = normalized;
    return true;
  } catch {
    return false;
  }
}

function findSessionIdForPanel(controller, targetPanel) {
  if (!controller?.sessionPanels || !targetPanel) {
    return '';
  }
  for (const [sessionId, panel] of controller.sessionPanels.entries()) {
    if (panel === targetPanel) {
      return String(sessionId || '');
    }
  }
  return '';
}

function findPanelForComms(controller, targetComms) {
  if (!targetComms) {
    return null;
  }
  if (targetComms.__bhfPanel) {
    return targetComms.__bhfPanel;
  }
  if (controller?.panelComms instanceof Map) {
    for (const [panel, c] of controller.panelComms.entries()) {
      if (c === targetComms) {
        targetComms.__bhfPanel = panel;
        return panel;
      }
    }
  }
  return null;
}

function resolveSessionIdForComms(controller, comms, channelId = '', panel = null) {
  if (comms) {
    if (channelId && comms.channels instanceof Map) {
      const ch = comms.channels.get(channelId);
      if (ch?.sessionId) {
        return String(ch.sessionId);
      }
    }
    if (channelId && comms.pendingChannels instanceof Map) {
      const pch = comms.pendingChannels.get(channelId);
      if (pch?.sessionId) {
        return String(pch.sessionId);
      }
    }
    if (comms.channels instanceof Map) {
      for (const ch of comms.channels.values()) {
        if (ch?.sessionId) {
          return String(ch.sessionId);
        }
      }
    }
    if (comms.pendingChannels instanceof Map) {
      for (const pch of comms.pendingChannels.values()) {
        if (pch?.sessionId) {
          return String(pch.sessionId);
        }
      }
    }
  }
  const resolvedPanel = panel || findPanelForComms(controller, comms);
  return findSessionIdForPanel(controller, resolvedPanel);
}

function hasRemainingPendingPermissionsForSession(state, sessionId, comms = null) {
  if (!(state?.pendingPermissions instanceof Map) || state.pendingPermissions.size === 0) {
    return false;
  }
  for (const entry of state.pendingPermissions.values()) {
    if (!entry) continue;
    if (comms && entry.comms === comms) {
      return true;
    }
    if (sessionId) {
      const entrySid =
        entry.sessionId ||
        resolveSessionIdForComms(state.controller, entry.comms, entry.channelId, entry.panel);
      if (entrySid === sessionId) {
        return true;
      }
    }
  }
  return false;
}

function clearPendingBadgeIfIdle(state, sessionId, comms = null, panel = null) {
  if (hasRemainingPendingPermissionsForSession(state, sessionId, comms)) {
    return false;
  }
  if (comms?.lastRenameTabFlags && typeof comms.lastRenameTabFlags === 'object') {
    comms.lastRenameTabFlags.hasPendingPermissions = false;
  }
  if (sessionId && state.badgeById.get(sessionId) === 'pending') {
    state.badgeById.set(sessionId, 'plain');
  }
  const targetPanel =
    panel ||
    (sessionId ? state.controller?.sessionPanels?.get?.(sessionId) : null) ||
    comms?.__bhfPanel ||
    findPanelForComms(state.controller, comms);
  if (targetPanel) {
    const nextBadge =
      sessionId && state.badgeById.get(sessionId) === 'done' && !targetPanel.active
        ? 'done'
        : 'plain';
    return applyPanelTabIcon(state, targetPanel, nextBadge);
  }
  return false;
}

function hookCommsObject(state, comms, panel = null) {
  if (!comms) {
    return;
  }
  if (panel) {
    comms.__bhfPanel = panel;
  }
  state.hookedComms.add(comms);
  if (!comms.__bhfHookedApplyTabIcon && typeof comms.applyTabIcon === 'function') {
    comms.__bhfHookedApplyTabIcon = true;
    const origApplyTabIcon = comms.applyTabIcon.bind(comms);
    comms.applyTabIcon = function (...args) {
      const res = origApplyTabIcon(...args);
      const pTab = this.panelTab || comms.__bhfPanel || panel;
      if (pTab) {
        pTab.__bhfBadgeState = null;
      }
      if (this.lastRenameTabFlags?.hasPendingPermissions === false) {
        const sid = resolveSessionIdForComms(state.controller, this, '', pTab);
        clearPendingBadgeIfIdle(state, sid, this, pTab);
      }
      return res;
    };
  }
  if (!comms.__bhfHookedRelayUsage && typeof comms.relayUsageWindows === 'function') {
    comms.__bhfHookedRelayUsage = true;
    const origRelayUsageWindows = comms.relayUsageWindows.bind(comms);
    comms.relayUsageWindows = function (usagePayload, ...rest) {
      if (usagePayload?.rate_limits && typeof usagePayload.rate_limits === 'object') {
        state.lastFullRateLimits = usagePayload.rate_limits;
        state.lastFullRateLimitsAt = Date.now();
        notifyActivityChanged({ type: 'claude-usage' });
      }
      return origRelayUsageWindows(usagePayload, ...rest);
    };
  }
  if (!comms.__bhfHookedSendRequest && typeof comms.sendRequest === 'function') {
    comms.__bhfHookedSendRequest = true;
    const origSendRequest = comms.sendRequest.bind(comms);
    comms.sendRequest = async function (channelId, request, signal) {
      const reqType = String(request?.type || '');
      if (
        request &&
        (reqType === 'tool_permission_request' ||
          reqType === 'user_dialog_request' ||
          reqType === 'engine_prompt_ask')
      ) {
        const permId = makeDraftId();
        const resolvedPanel =
          comms.__bhfPanel || findPanelForComms(state.controller, comms) || panel;
        const sessionId =
          resolveSessionIdForComms(state.controller, comms, channelId, resolvedPanel) ||
          String(request.sessionId || '');
        const beforeReqIds = new Set(
          comms.outstandingRequests instanceof Map ? comms.outstandingRequests.keys() : []
        );
        const reqPromise = origSendRequest(channelId, request, signal);
        let requestId = '';
        if (comms.outstandingRequests instanceof Map) {
          for (const k of comms.outstandingRequests.keys()) {
            if (!beforeReqIds.has(k)) {
              requestId = String(k);
              break;
            }
          }
        }
        const entry = {
          id: permId,
          requestId,
          requestType: reqType,
          provider: 'claude',
          sessionId,
          channelId: String(channelId || ''),
          toolName: String(request.toolName || request.dialogKind || 'Tool'),
          toolUseId: String(request.toolUseID || request.toolUseId || ''),
          inputs: request.inputs || request.payload || {},
          suggestions: Array.isArray(request.suggestions) ? request.suggestions : [],
          title: resolvedPanel?.title || 'Claude Code',
          createdAt: Date.now(),
          panel: resolvedPanel,
          comms
        };
        state.pendingPermissions.set(permId, entry);
        if (sessionId) {
          state.badgeById.set(sessionId, 'pending');
        }
        if (resolvedPanel) {
          applyPanelTabIcon(state, resolvedPanel, 'pending');
        }
        notifyActivityChanged({
          type: 'claude-permission',
          threadId: sessionId,
          permissionId: permId
        });
        try {
          return await reqPromise;
        } finally {
          state.pendingPermissions.delete(permId);
          const resolvedSid =
            sessionId ||
            resolveSessionIdForComms(state.controller, comms, channelId, resolvedPanel);
          clearPendingBadgeIfIdle(state, resolvedSid, comms, resolvedPanel);
          notifyActivityChanged({
            type: 'claude-permission-cleared',
            threadId: resolvedSid,
            permissionId: permId
          });
        }
      }
      return origSendRequest(channelId, request, signal);
    };
  }
}

function ensureCommsHooked(state, panel) {
  const { controller } = state;
  if (controller?.allComms instanceof Set) {
    for (const c of controller.allComms) {
      hookCommsObject(state, c, null);
    }
  }
  if (!controller?.panelComms || !panel) {
    return;
  }
  const comms = controller.panelComms.get(panel);
  if (comms) {
    hookCommsObject(state, comms, panel);
  }
}

function setOpeningClaudeTarget(state, { threadId = '', uriKey = '', durationMs = 1600 } = {}) {
  if (!state) {
    return;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = String(uriKey || '').trim();
  if (!cleanId && !cleanUri) {
    state.__bhfOpeningTarget = null;
    return;
  }
  const now = Date.now();
  const prev =
    state.__bhfOpeningTarget && now < Number(state.__bhfOpeningTarget.until || 0)
      ? state.__bhfOpeningTarget
      : null;
  let outgoingThreadId = '';
  let outgoingUriKey = '';
  if (state.controller?.panelComms instanceof Map) {
    for (const panel of state.controller.panelComms.keys()) {
      if (panel?.active) {
        const sid = findSessionIdForPanel(state.controller, panel);
        const pUri = String(panel.__bhfDraftUri || '').trim();
        if ((cleanId && sid && sid !== cleanId) || (cleanUri && pUri && pUri !== cleanUri)) {
          outgoingThreadId = sid;
          outgoingUriKey = pUri;
          break;
        }
      }
    }
  }
  if (
    !outgoingThreadId &&
    !outgoingUriKey &&
    prev &&
    ((cleanId && prev.threadId === cleanId) || (cleanUri && prev.uriKey === cleanUri))
  ) {
    outgoingThreadId = prev.outgoingThreadId || '';
    outgoingUriKey = prev.outgoingUriKey || '';
  }
  state.__bhfOpeningTarget = {
    threadId: cleanId,
    uriKey: cleanUri,
    outgoingThreadId,
    outgoingUriKey,
    setAt: now,
    until: now + Math.max(120, Number(durationMs) || 1600)
  };
}

function isOpeningOtherClaudeTarget(state, { threadId = '', uriKey = '' } = {}) {
  const cur = state?.__bhfOpeningTarget;
  if (!cur) {
    return false;
  }
  if (Date.now() >= Number(cur.until || 0)) {
    state.__bhfOpeningTarget = null;
    return false;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = String(uriKey || '').trim();
  if ((cleanId && cur.threadId === cleanId) || (cleanUri && cur.uriKey === cleanUri)) {
    return false;
  }
  if (cur.outgoingThreadId || cur.outgoingUriKey) {
    return Boolean(
      (cur.outgoingThreadId && cleanId === cur.outgoingThreadId) ||
        (cur.outgoingUriKey && cleanUri === cur.outgoingUriKey)
    );
  }
  return false;
}

function clearOpeningClaudeTargetIfMatched(state, { threadId = '', uriKey = '' } = {}) {
  const cur = state?.__bhfOpeningTarget;
  if (!cur) {
    return;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = String(uriKey || '').trim();
  if ((cleanId && cur.threadId === cleanId) || (cleanUri && cur.uriKey === cleanUri)) {
    state.__bhfOpeningTarget = null;
  }
}

function ensurePanelHooked(state, panel) {
  if (!panel) {
    return;
  }
  ensureCommsHooked(state, panel);
  if (state.hookedPanels.has(panel)) {
    return;
  }
  state.hookedPanels.add(panel);
  if (!panel.__bhfDraftUri) {
    panel.__bhfDraftUri = `${CLAUDE_DRAFT_SCHEME}://draft/${makeDraftId()}`;
  }
  try {
    if (typeof panel.onDidChangeViewState === 'function') {
      panel.onDidChangeViewState(() => {
        ensureCommsHooked(state, panel);
        const sessionId = findSessionIdForPanel(state.controller, panel);
        const pUri = panel.__bhfDraftUri || '';
        if (panel.active) {
          if (isOpeningOtherClaudeTarget(state, { threadId: sessionId, uriKey: pUri })) {
            return;
          }
          clearOpeningClaudeTargetIfMatched(state, { threadId: sessionId, uriKey: pUri });
          if (sessionId) {
            applyPanelTabIcon(state, panel, 'plain');
            notifyThreadSeen(sessionId);
          }
        }
        notifyActivityChanged({
          type: 'tab-state',
          threadId: sessionId,
          uri: pUri,
          active: Boolean(panel.active)
        });
      });
    }
  } catch {}
  try {
    if (typeof panel.onDidDispose === 'function') {
      panel.onDidDispose(() => {
        const sessionId = findSessionIdForPanel(state.controller, panel);
        for (const [permId, perm] of state.pendingPermissions.entries()) {
          if (perm.panel === panel) {
            state.pendingPermissions.delete(permId);
          }
        }
        notifyActivityChanged({
          type: 'tab-closed',
          threadId: sessionId,
          uri: panel.__bhfDraftUri || ''
        });
      });
    }
  } catch {}
}

function getClaudeActiveGroupInfoByColumn(vscode) {
  const byColumn = new Map();
  const groups = vscode?.window?.tabGroups?.all || [];
  for (const group of groups) {
    const tabs = Array.isArray(group?.tabs) ? group.tabs : [];
    const activeTab = tabs.find((t) => Boolean(t?.isActive)) || group?.activeTab || null;
    if (!activeTab) {
      continue;
    }
    const col = group.viewColumn || 1;
    const viewType = String(activeTab?.input?.viewType || '');
    const isClaudePanel = viewType.includes('claudeVSCodePanel');
    byColumn.set(col, {
      groupActive: Boolean(group.isActive),
      hasNonClaudeActiveTab: !isClaudePanel
    });
  }
  return byColumn;
}

function getOpenClaudeTabsSnapshot() {
  const state = getBridgeState();
  const { controller, vscode } = state;
  const result = [];
  const seenPanels = new Set();
  const seenSessionIds = new Set();
  const activeGroupByColumn = getClaudeActiveGroupInfoByColumn(vscode);

  if (controller?.sessionPanels instanceof Map) {
    for (const [sessionId, panel] of controller.sessionPanels.entries()) {
      if (!panel) {
        continue;
      }
      ensurePanelHooked(state, panel);
      seenPanels.add(panel);
      const cleanId = String(sessionId || '').trim();
      if (cleanId) {
        seenSessionIds.add(cleanId);
      }
      const viewColumn = panel.viewColumn || 1;
      let isActive = Boolean(panel.active);
      const colInfo = activeGroupByColumn.get(viewColumn);
      if (isActive && colInfo && (!colInfo.groupActive || colInfo.hasNonClaudeActiveTab)) {
        isActive = false;
      }
      result.push({
        uri: panel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${cleanId}`,
        id: cleanId,
        provider: 'claude',
        title: panel.title || 'Claude Code',
        active: isActive,
        visible: Boolean(panel.visible),
        viewColumn
      });
    }
  }

  if (controller?.panelComms instanceof Map) {
    for (const panel of controller.panelComms.keys()) {
      if (!panel || seenPanels.has(panel)) {
        continue;
      }
      ensurePanelHooked(state, panel);
      seenPanels.add(panel);
      const viewColumn = panel.viewColumn || 1;
      let isActive = Boolean(panel.active);
      const colInfo = activeGroupByColumn.get(viewColumn);
      if (isActive && colInfo && (!colInfo.groupActive || colInfo.hasNonClaudeActiveTab)) {
        isActive = false;
      }
      result.push({
        uri: panel.__bhfDraftUri,
        id: '',
        provider: 'claude',
        title: panel.title || 'New Claude session',
        active: isActive,
        visible: Boolean(panel.visible),
        viewColumn
      });
    }
  }

  // Also include un-revived remembered tabs from VS Code restart
  const remembered = Array.isArray(controller?.rememberedTabSessions)
    ? controller.rememberedTabSessions
    : [];
  if (remembered.length > 0) {
    const groups = vscode?.window?.tabGroups?.all || [];
    const activeTabLabels = new Set();
    for (const group of groups) {
      for (const tab of group.tabs || []) {
        const viewType = String(tab?.input?.viewType || '');
        if (viewType.includes('claudeVSCodePanel') && tab.isActive && group.isActive) {
          activeTabLabels.add(tab.label || '');
        }
      }
    }
    for (const rem of remembered) {
      const cleanId = String(rem?.sessionId || '').trim();
      if (!cleanId || seenSessionIds.has(cleanId)) {
        continue;
      }
      seenSessionIds.add(cleanId);
      result.push({
        uri: `${CLAUDE_DRAFT_SCHEME}://remembered/${cleanId}`,
        id: cleanId,
        provider: 'claude',
        title: rem.title || 'Claude Code',
        active: Boolean(rem.title && activeTabLabels.has(rem.title)),
        visible: Boolean(rem.title && activeTabLabels.has(rem.title)),
        viewColumn: 1
      });
    }
  }

  return result;
}

function getPendingPermissionsSnapshot() {
  const state = getBridgeState();
  const out = [];
  for (const [id, entry] of state.pendingPermissions.entries()) {
    const resolvedPanel = entry.panel || findPanelForComms(state.controller, entry.comms);
    const resolvedSessionId =
      entry.sessionId ||
      resolveSessionIdForComms(state.controller, entry.comms, entry.channelId, resolvedPanel) ||
      '';
    out.push({
      id,
      requestId: entry.requestId || '',
      requestType: entry.requestType || 'tool_permission_request',
      provider: 'claude',
      sessionId: resolvedSessionId,
      channelId: entry.channelId || '',
      toolName: entry.toolName || 'Tool',
      toolUseId: entry.toolUseId || '',
      inputs: entry.inputs || {},
      suggestions: Array.isArray(entry.suggestions) ? entry.suggestions : [],
      title: resolvedPanel?.title || entry.title || 'Claude Code',
      createdAt: entry.createdAt
    });
  }
  return out;
}

function getLiveSnapshot() {
  const state = getBridgeState();
  const { controller } = state;
  const sessionStates = [];
  const seenStateIds = new Set();

  const outstandingSessionIds = new Set();
  const allCommsList = [];
  if (controller?.allComms instanceof Set) {
    for (const c of controller.allComms) {
      if (c && !allCommsList.includes(c)) allCommsList.push(c);
    }
  }
  if (controller?.panelComms instanceof Map) {
    for (const [panel, c] of controller.panelComms.entries()) {
      if (c) {
        c.__bhfPanel = panel;
        if (!allCommsList.includes(c)) allCommsList.push(c);
      }
    }
  }
  for (const c of allCommsList) {
    hookCommsObject(state, c, c.__bhfPanel || null);
  }
  if (state.pendingPermissions instanceof Map) {
    for (const entry of state.pendingPermissions.values()) {
      if (!entry) continue;
      const sid =
        entry.sessionId ||
        resolveSessionIdForComms(controller, entry.comms, entry.channelId, entry.panel);
      if (sid) {
        outstandingSessionIds.add(sid);
      }
    }
  }

  if (controller?.sessionStates instanceof Map) {
    for (const [id, entry] of controller.sessionStates.entries()) {
      const info = entry?.info || entry || {};
      const cleanSid = String(info.sessionId || id || '');
      const hasOutstanding = Boolean(cleanSid && outstandingSessionIds.has(cleanSid));
      if (cleanSid) seenStateIds.add(cleanSid);
      sessionStates.push({
        sessionId: cleanSid,
        state: hasOutstanding ? 'waiting_input' : String(info.state || 'idle'),
        hasOutstandingRequest: hasOutstanding,
        title: String(info.title || '')
      });
    }
  }
  for (const sid of outstandingSessionIds) {
    if (!seenStateIds.has(sid)) {
      const panel = controller?.sessionPanels?.get?.(sid);
      sessionStates.push({
        sessionId: sid,
        state: 'waiting_input',
        hasOutstandingRequest: true,
        title: String(panel?.title || '')
      });
    }
  }

  const liveElsewhere = Array.isArray(controller?.liveElsewhereSessions)
    ? controller.liveElsewhereSessions.map((item) => ({
        sessionId: String(item?.sessionId || ''),
        pid: item?.pid || 0,
        cwd: item?.cwd || ''
      }))
    : [];

  try {
    controller?.refreshUnreadFromStore?.();
  } catch {}
  const unreadIds =
    controller?.unreadSessionKeys instanceof Set
      ? Array.from(controller.unreadSessionKeys)
      : [];

  let activeSessionId = '';
  try {
    activeSessionId =
      controller?.activePanelSessionId?.() || controller?.activeSessionId || '';
  } catch {}

  if (controller?.allComms instanceof Set) {
    for (const c of controller.allComms) {
      hookCommsObject(state, c, null);
    }
  }

  const rawRateLimitWindows =
    controller?.panelUsageRelay?.merged || state.lastRateLimitWindows || null;
  let rateLimitWindows = rawRateLimitWindows;
  const nowSec = Math.floor(Date.now() / 1000);
  let hasExpiredRelayWindow = false;
  if (rawRateLimitWindows && typeof rawRateLimitWindows === 'object') {
    rateLimitWindows = { ...rawRateLimitWindows };
    for (const [k, v] of Object.entries(rateLimitWindows)) {
      if (v && typeof v === 'object') {
        const rSec = Number(v.resetsAt || 0);
        if (rSec > 0 && rSec <= nowSec) {
          hasExpiredRelayWindow = true;
          rateLimitWindows[k] = { ...v, utilization: 0, resetsAt: undefined };
        }
      }
    }
  }

  if (hasExpiredRelayWindow && Date.now() - (state.lastProcessUsagePollAt || 0) > 180000) {
    state.lastProcessUsagePollAt = Date.now();
    try {
      const commsList =
        controller?.allComms instanceof Set
          ? Array.from(controller.allComms)
          : controller?.panelComms instanceof Map
            ? Array.from(controller.panelComms.values())
            : [];
      for (const c of commsList) {
        const ch = findActiveChannelEntry(c);
        if (ch?.entry?.query && typeof c.relayUsageWindowsFromProcess === 'function') {
          Promise.resolve(c.relayUsageWindowsFromProcess(ch.entry.query)).catch(() => {});
          break;
        }
      }
    } catch {}
  }

  let archivedIds = [];
  try {
    const rawArchived =
      controller?.settings?.getArchivedSessionIds?.() ??
      state.context?.globalState?.get?.('hiddenSessionIds');
    if (Array.isArray(rawArchived)) {
      archivedIds = rawArchived.filter(Boolean);
    }
  } catch {}

  let unarchivedAt = {};
  try {
    const rawUnarchived =
      controller?.settings?.getSessionUnarchiveTimes?.() ??
      state.context?.globalState?.get?.('sessionUnarchivedAt');
    if (rawUnarchived && typeof rawUnarchived === 'object') {
      unarchivedAt = { ...rawUnarchived };
    }
  } catch {}

  let autoArchiveDays = 14;
  try {
    if (typeof controller?.settings?.getAutoArchiveInactiveDays === 'function') {
      const days = controller.settings.getAutoArchiveInactiveDays();
      if (typeof days === 'number' && Number.isFinite(days)) {
        autoArchiveDays = days;
      }
    }
  } catch {}

  let sessionGroups = [];
  try {
    const rawGroups = controller?.settings?.getSessionGroups?.();
    if (Array.isArray(rawGroups)) {
      sessionGroups = rawGroups;
    }
  } catch {}

  return {
    active: true,
    openTabs: getOpenClaudeTabsSnapshot(),
    sessionStates,
    liveElsewhere,
    unreadIds,
    archivedIds,
    unarchivedAt,
    autoArchiveDays,
    sessionGroups,
    activeSessionId,
    rateLimitWindows,
    fullRateLimits: state.lastFullRateLimits || null,
    fullRateLimitsAt: state.lastFullRateLimitsAt || 0,
    pendingPermissions: getPendingPermissionsSnapshot()
  };
}

function resolveTargetColumn(vscode, options = {}) {
  if (typeof options.viewColumn === 'number') {
    return options.viewColumn;
  }
  if (options.beside) {
    return vscode.ViewColumn.Beside;
  }
  return vscode.ViewColumn.One;
}

async function openClaudeTab(options = {}) {
  const state = getBridgeState();
  const { vscode, controller } = state;
  if (!vscode || !controller) {
    return null;
  }

  const viewColumn = resolveTargetColumn(vscode, options);
  const preserveFocus = Boolean(options.preserveFocus);

  // 1. Focus an open draft Claude tab by its draft URI
  const draftUri = String(options.draftUri || options.key || '').trim();
  if (draftUri && draftUri.startsWith(`${CLAUDE_DRAFT_SCHEME}://draft/`)) {
    if (controller.panelComms instanceof Map) {
      for (const panel of controller.panelComms.keys()) {
        if (panel && panel.__bhfDraftUri === draftUri) {
          if (!preserveFocus) {
            setOpeningClaudeTarget(state, { uriKey: draftUri });
          }
          panel.reveal(
            options.beside ? vscode.ViewColumn.Beside : panel.viewColumn || viewColumn,
            preserveFocus
          );
          notifyActivityChanged({ type: 'reveal-draft', uri: draftUri });
          return { uri: draftUri, id: '', provider: 'claude', revealed: true };
        }
      }
    }
  }

  // 2. Open a new blank Claude session tab
  const sessionId = String(options.id || options.threadId || '').trim();
  if (options.newSession || !sessionId) {
    const pendingDraftUri = `${CLAUDE_DRAFT_SCHEME}://draft/${makeDraftId()}`;
    if (!preserveFocus) {
      setOpeningClaudeTarget(state, { uriKey: pendingDraftUri });
    }
    const res = await controller.createPanel(
      undefined,
      options.initialPrompt,
      viewColumn,
      undefined,
      true,
      !preserveFocus,
      preserveFocus,
      false
    );
    const panel = res?.createdPanel;
    if (panel) {
      if (!panel.__bhfDraftUri) {
        panel.__bhfDraftUri = pendingDraftUri;
      }
      ensurePanelHooked(state, panel);
    }
    const uri = panel?.__bhfDraftUri || pendingDraftUri;
    notifyActivityChanged({ type: 'open-new', uri });
    return { uri, id: '', provider: 'claude', draft: true, panel };
  }

  if (!preserveFocus) {
    setOpeningClaudeTarget(state, { threadId: sessionId });
  }

  // 3. Reveal or open an existing Claude session tab
  const existingPanel = controller.sessionPanels?.get?.(sessionId);
  if (existingPanel) {
    existingPanel.reveal(
      options.beside ? vscode.ViewColumn.Beside : existingPanel.viewColumn || viewColumn,
      preserveFocus
    );
    ensurePanelHooked(state, existingPanel);
    if (options.title && options.title !== 'Claude Code') {
      existingPanel.title = options.title;
    }
    if (!preserveFocus) {
      if (
        state.badgeById.get(sessionId) === 'done' ||
        existingPanel.__bhfBadgeState === 'done'
      ) {
        applyPanelTabIcon(state, existingPanel, 'plain');
      }
      notifyThreadSeen(sessionId);
    }
    notifyActivityChanged({ type: 'reveal', threadId: sessionId });
    return {
      uri: existingPanel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
      id: sessionId,
      provider: 'claude',
      revealed: true
    };
  }

  if (!preserveFocus) {
    notifyThreadSeen(sessionId);
  }
  if (
    !options.initialPrompt &&
    !options.beside &&
    typeof controller.revealRememberedTab === 'function' &&
    Array.isArray(controller.rememberedTabSessions)
  ) {
    const matchedRemembered = controller.rememberedTabSessions.find(
      (rem) => String(rem?.sessionId || '').trim() === sessionId
    );
    if (matchedRemembered) {
      try {
        await controller.revealRememberedTab(matchedRemembered);
        const revivedPanel = controller.sessionPanels?.get?.(sessionId);
        if (revivedPanel) {
          ensurePanelHooked(state, revivedPanel);
          if (options.title && options.title !== 'Claude Code') {
            revivedPanel.title = options.title;
          }
          notifyActivityChanged({ type: 'reveal', threadId: sessionId });
          return {
            uri: revivedPanel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
            id: sessionId,
            provider: 'claude',
            revealed: true
          };
        }
      } catch {}
    }
  }
  const res = await controller.createPanel(
    sessionId,
    options.initialPrompt,
    viewColumn,
    undefined,
    true,
    !preserveFocus,
    preserveFocus,
    !options.initialPrompt
  );
  const createdPanel = res?.createdPanel || controller.sessionPanels?.get?.(sessionId);
  if (createdPanel) {
    ensurePanelHooked(state, createdPanel);
    if (options.title && options.title !== 'Claude Code') {
      createdPanel.title = options.title;
    }
  }
  notifyActivityChanged({ type: 'open-thread', threadId: sessionId });
  return {
    uri: createdPanel?.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
    id: sessionId,
    provider: 'claude',
    revealed: false
  };
}

async function closeClaudeTab(options = {}) {
  const state = getBridgeState();
  const { controller } = state;
  if (!controller) {
    return false;
  }
  const sessionId = String(options.id || options.threadId || '').trim();
  const draftUri = String(options.uri || options.key || '').trim();
  let closed = false;

  if (sessionId && controller.sessionPanels instanceof Map) {
    const panel = controller.sessionPanels.get(sessionId);
    if (panel) {
      try {
        panel.dispose();
        closed = true;
      } catch {}
    }
  }

  if (!closed && draftUri && controller.panelComms instanceof Map) {
    for (const panel of Array.from(controller.panelComms.keys())) {
      if (panel && panel.__bhfDraftUri === draftUri) {
        try {
          panel.dispose();
          closed = true;
        } catch {}
      }
    }
  }

  return closed;
}

function syncClaudeTabBadges(badgesById = {}) {
  const state = getBridgeState();
  const { controller } = state;
  if (!controller?.sessionPanels || !badgesById || typeof badgesById !== 'object') {
    return false;
  }
  let changed = false;
  for (const [id, badge] of Object.entries(badgesById)) {
    if (id && TAB_ICON_FILES[badge]) {
      state.badgeById.set(id, badge);
    }
  }
  for (const [sessionId, panel] of controller.sessionPanels.entries()) {
    if (!panel) {
      continue;
    }
    let targetBadge =
      badgesById[sessionId] || state.badgeById.get(sessionId) || 'plain';
    if (targetBadge === 'done' && panel.active) {
      targetBadge = 'plain';
      state.badgeById.set(sessionId, 'plain');
    }
    if (applyPanelTabIcon(state, panel, targetBadge)) {
      changed = true;
    }
  }
  return changed;
}

async function reviveRememberedClaudeTabs(state) {
  const { controller, vscode } = state || getBridgeState();
  if (!controller || !vscode || state.revivingRememberedTabs) {
    return 0;
  }
  const remembered = Array.isArray(controller.rememberedTabSessions)
    ? [...controller.rememberedTabSessions]
    : [];
  const toRevive = remembered.filter((rem) => {
    const sid = String(rem?.sessionId || '').trim();
    return (
      sid &&
      !controller.sessionPanels?.has?.(sid) &&
      !controller.tabRevivesInFlight?.has?.(sid) &&
      !state.revivedRememberedIds?.has?.(sid)
    );
  });
  if (toRevive.length === 0) {
    return 0;
  }

  if (!state.revivedRememberedIds) {
    state.revivedRememberedIds = new Set();
  }
  state.revivingRememberedTabs = true;
  let revivedCount = 0;
  try {
    const activeGroup = vscode.window?.tabGroups?.activeTabGroup;
    const origActiveTab = activeGroup?.activeTab || null;
    const origGroupColumn = activeGroup?.viewColumn || 1;

    for (const rem of toRevive.slice(0, 2)) {
      const sid = String(rem?.sessionId || '').trim();
      if (!sid || controller.sessionPanels?.has?.(sid)) {
        continue;
      }
      state.revivedRememberedIds.add(sid);
      try {
        if (typeof controller.revealRememberedTab === 'function') {
          await controller.revealRememberedTab(rem);
          revivedCount += 1;
        } else {
          await openClaudeTab({
            id: sid,
            title: String(rem?.title || '').trim(),
            preserveFocus: true
          });
          revivedCount += 1;
        }
      } catch {}
    }

    // Restore focus to whichever tab the user originally had active before revival
    if (origActiveTab) {
      try {
        const currentGroup =
          (vscode.window?.tabGroups?.all || []).find((g) => g.viewColumn === origGroupColumn) ||
          vscode.window?.tabGroups?.activeTabGroup;
        if (currentGroup && Array.isArray(currentGroup.tabs)) {
          const idx = currentGroup.tabs.indexOf(origActiveTab);
          if (idx >= 0 && !origActiveTab.isActive) {
            await vscode.commands.executeCommand('workbench.action.openEditorAtIndex', idx);
          }
        }
      } catch {}
    }
    notifyActivityChanged({ type: 'claude-revived-remembered-tabs' });
    return revivedCount;
  } finally {
    state.revivingRememberedTabs = false;
  }
}

function scheduleRememberedTabsRevival(state, delayMs = 1800) {
  if (state.reviveRememberedTimer) {
    clearTimeout(state.reviveRememberedTimer);
  }
  state.reviveRememberedTimer = setTimeout(() => {
    state.reviveRememberedTimer = null;
    reviveRememberedClaudeTabs(state).catch(() => {});
  }, delayMs);
}

function installControllerHooks(state) {
  const { controller, vscode } = state;
  if (!controller || controller.__bhfClaudeBridgePatched) {
    return;
  }
  controller.__bhfClaudeBridgePatched = true;

  // Ensure live process registry runs even when claudeVSCodeSessionsList is delegated or hidden
  try {
    const roots = vscode?.workspace?.workspaceFolders?.map((f) => f.uri.fsPath) || [];
    if (roots.length > 0 && typeof controller.startLiveRegistry === 'function') {
      controller.startLiveRegistry(roots[0]);
    } else {
      controller.liveRegistry?.start?.();
    }
  } catch {}

  // 1. Sidebar delegation for claudeVSCodeSessionsList
  if (typeof controller.resolveSessionListView === 'function') {
    state.origResolveSessionListView = controller.resolveSessionListView.bind(controller);
    controller.resolveSessionListView = async function (webviewView, resolveContext, token) {
      this.sessionListView = webviewView;
      state.sidebarView = webviewView;

      if (state.sidebarDelegate && typeof state.sidebarDelegate.resolveWebviewView === 'function') {
        return state.sidebarDelegate.resolveWebviewView(webviewView, resolveContext, token);
      }

      return new Promise((resolve) => {
        if (state.sidebarFallbackTimer) {
          clearTimeout(state.sidebarFallbackTimer);
        }
        state.sidebarFallbackTimer = setTimeout(async () => {
          state.sidebarFallbackTimer = null;
          if (
            state.sidebarDelegate &&
            typeof state.sidebarDelegate.resolveWebviewView === 'function'
          ) {
            resolve(
              await state.sidebarDelegate.resolveWebviewView(webviewView, resolveContext, token)
            );
          } else {
            resolve(await state.origResolveSessionListView(webviewView, resolveContext, token));
          }
        }, 4000);
      });
    };
  }

  // 2. Hook setupPanel to track open & draft panels and ensure reopenedAfterRestart is true when loading an existing session
  if (typeof controller.setupPanel === 'function') {
    const origSetupPanel = controller.setupPanel.bind(controller);
    controller.setupPanel = function (
      panel,
      sessionId,
      initialPrompt,
      fullEditor,
      focusInput,
      reopenedAfterRestart,
      ...rest
    ) {
      ensurePanelHooked(state, panel);
      const effectiveReopened =
        reopenedAfterRestart !== undefined
          ? reopenedAfterRestart
          : Boolean(sessionId && !initialPrompt);
      const res = origSetupPanel(
        panel,
        sessionId,
        initialPrompt,
        fullEditor,
        focusInput,
        effectiveReopened,
        ...rest
      );
      ensurePanelHooked(state, panel);
      notifyActivityChanged({
        type: 'claude-setup-panel',
        threadId: String(sessionId || ''),
        uri: panel?.__bhfDraftUri || ''
      });
      return res;
    };
  }

  // 3. Hook registerPanelSession so draft tabs smoothly bind to their Claude sessionId
  if (typeof controller.registerPanelSession === 'function') {
    const origRegisterPanelSession = controller.registerPanelSession.bind(controller);
    controller.registerPanelSession = function (sessionId, panel, ...rest) {
      ensurePanelHooked(state, panel);
      const res = origRegisterPanelSession(sessionId, panel, ...rest);
      notifyActivityChanged({
        type: 'claude-register-session',
        threadId: String(sessionId || ''),
        uri: panel?.__bhfDraftUri || ''
      });
      return res;
    };
  }

  // 4. Hook createPanel so default viewColumn is ViewColumn.One (middle editor)
  if (typeof controller.createPanel === 'function') {
    const origCreatePanel = controller.createPanel.bind(controller);
    controller.createPanel = async function (
      sessionId,
      initialPrompt,
      viewColumn,
      groupId,
      fullEditor,
      focusInput,
      preserveFocus,
      reopenedAfterRestart
    ) {
      const targetColumn =
        viewColumn !== undefined ? viewColumn : vscode?.ViewColumn?.One || 1;
      const effectiveReopened =
        reopenedAfterRestart !== undefined
          ? reopenedAfterRestart
          : Boolean(sessionId && !initialPrompt);
      const res = await origCreatePanel(
        sessionId,
        initialPrompt,
        targetColumn,
        groupId,
        fullEditor,
        focusInput,
        preserveFocus,
        effectiveReopened
      );
      if (res?.createdPanel) {
        ensurePanelHooked(state, res.createdPanel);
      }
      notifyActivityChanged({
        type: 'claude-create-panel',
        threadId: String(sessionId || ''),
        uri: res?.createdPanel?.__bhfDraftUri || ''
      });
      return res;
    };
  }

  // 5. Hook broadcastSessionStates
  if (typeof controller.broadcastSessionStates === 'function') {
    const origBroadcastStates = controller.broadcastSessionStates.bind(controller);
    controller.broadcastSessionStates = function (...args) {
      const res = origBroadcastStates(...args);
      notifyActivityChanged({ type: 'claude-states' });
      return res;
    };
  }

  // 6. Hook broadcastPanelUsage
  if (typeof controller.broadcastPanelUsage === 'function') {
    const origBroadcastUsage = controller.broadcastPanelUsage.bind(controller);
    controller.broadcastPanelUsage = function (windows, ...rest) {
      if (windows) {
        state.lastRateLimitWindows = windows;
      }
      const res = origBroadcastUsage(windows, ...rest);
      notifyActivityChanged({ type: 'claude-usage' });
      return res;
    };
  }

  // 7. Hook handleSessionRenamed
  if (typeof controller.handleSessionRenamed === 'function') {
    const origHandleRenamed = controller.handleSessionRenamed.bind(controller);
    controller.handleSessionRenamed = function (sessionId, title, sourceComms, skipCli) {
      const res = origHandleRenamed(sessionId, title, sourceComms, skipCli);
      const panel = this.sessionPanels?.get?.(sessionId);
      if (panel && title && panel.title !== title) {
        panel.title = title;
      }
      notifyActivityChanged({
        type: 'claude-renamed',
        threadId: String(sessionId || ''),
        title: String(title || '')
      });
      return res;
    };
  }

  // 8. Hook setSessionUnread
  if (typeof controller.setSessionUnread === 'function') {
    const origSetUnread = controller.setSessionUnread.bind(controller);
    controller.setSessionUnread = function (sessionId, unread) {
      const res = origSetUnread(sessionId, unread);
      notifyActivityChanged({
        type: 'claude-unread',
        threadId: String(sessionId || ''),
        unread: Boolean(unread)
      });
      return res;
    };
  }

  // 9. Hook broadcastSessionArchiveChanged
  if (typeof controller.broadcastSessionArchiveChanged === 'function') {
    const origBroadcastArchive = controller.broadcastSessionArchiveChanged.bind(controller);
    controller.broadcastSessionArchiveChanged = function (sourceComms, sessionIdOrIds, archived) {
      const res = origBroadcastArchive(sourceComms, sessionIdOrIds, archived);
      notifyActivityChanged({
        type: 'claude-archive',
        archived: Boolean(archived)
      });
      return res;
    };
  }

  // 10. Hook noteListedSessions so inferred background tabs after Reload Window are automatically revived
  if (typeof controller.noteListedSessions === 'function') {
    const origNoteListed = controller.noteListedSessions.bind(controller);
    controller.noteListedSessions = function (sessions, ...rest) {
      const res = origNoteListed(sessions, ...rest);
      scheduleRememberedTabsRevival(state, 1800);
      return res;
    };
  }

  // Hook any already-open panels
  if (controller.sessionPanels instanceof Map) {
    for (const panel of controller.sessionPanels.values()) {
      ensurePanelHooked(state, panel);
    }
  }
  if (controller.panelComms instanceof Map) {
    for (const panel of controller.panelComms.keys()) {
      ensurePanelHooked(state, panel);
    }
  }

  scheduleRememberedTabsRevival(state, 2200);
}

function findActiveChannelEntry(comms) {
  if (!comms) {
    return null;
  }
  if (comms.channels instanceof Map) {
    for (const [channelId, entry] of comms.channels.entries()) {
      return { channelId, entry };
    }
  }
  if (comms.pendingChannels instanceof Map) {
    for (const [channelId, entry] of comms.pendingChannels.entries()) {
      return { channelId, entry };
    }
  }
  return null;
}

async function sendPromptToClaude(options = {}) {
  const state = getBridgeState();
  const { controller } = state;
  const promptText = String(options.prompt || options.text || '').trim();
  if (!promptText || !controller) {
    return { sent: false, error: 'Missing prompt or Claude controller' };
  }
  const sessionId = String(options.id || options.threadId || '').trim();

  // Case 1: New session with initialPrompt
  if (options.newSession || !sessionId) {
    const opened = await openClaudeTab({
      newSession: true,
      initialPrompt: promptText,
      preserveFocus: Boolean(options.preserveFocus)
    });
    let resolvedId = '';
    if (opened?.panel) {
      const deadline = Date.now() + 2200;
      while (Date.now() < deadline && !resolvedId) {
        resolvedId = findSessionIdForPanel(controller, opened.panel);
        if (!resolvedId) {
          await new Promise((r) => setTimeout(r, 100));
        }
      }
    }
    return {
      sent: Boolean(opened),
      method: 'createPanel-new',
      id: resolvedId,
      sessionId: resolvedId,
      opened: opened
        ? {
            uri: opened.uri,
            id: resolvedId,
            provider: 'claude',
            draft: true
          }
        : null
    };
  }

  // Case 2: Existing session panel already open with active channel
  let panel = controller.sessionPanels?.get?.(sessionId);
  if (panel && controller.panelComms instanceof Map) {
    const comms = controller.panelComms.get(panel);
    const ch = findActiveChannelEntry(comms);
    if (comms && ch && typeof comms.transportMessage === 'function') {
      ensureCommsHooked(state, panel);
      await comms.transportMessage(
        ch.channelId,
        {
          type: 'user',
          uuid: makeDraftId(),
          session_id: sessionId,
          parent_tool_use_id: null,
          message: {
            role: 'user',
            content: [{ type: 'text', text: promptText }]
          }
        },
        false,
        true
      );
      notifyActivityChanged({ type: 'claude-remote-send', threadId: sessionId });
      return { sent: true, method: 'transportMessage', sessionId, channelId: ch.channelId };
    }
  }

  // Case 3: Open panel with initialPrompt (Claude Code automatically submits initialPrompt on launch)
  const opened = await openClaudeTab({
    id: sessionId,
    initialPrompt: promptText,
    preserveFocus: Boolean(options.preserveFocus)
  });
  return { sent: Boolean(opened), method: 'createPanel-resume', sessionId, opened };
}

const CLAUDE_REJECT_DEFAULT_MSG =
  "The user doesn't want to proceed with this tool use. The tool use was rejected (eg. if it was a file edit, the new_string was NOT written to the file). STOP what you are doing and wait for the user to tell you how to proceed.";
const CLAUDE_REJECT_WITH_REASON_PREFIX =
  "The user doesn't want to proceed with this tool use. The tool use was rejected (eg. if it was a file edit, the new_string was NOT written to the file). The user provided the following reason for the rejection: ";

function findCommsForSession(controller, sessionId) {
  if (!controller) return null;
  if (sessionId && controller.sessionPanels instanceof Map && controller.panelComms instanceof Map) {
    const panel = controller.sessionPanels.get(sessionId);
    const comms = panel && controller.panelComms.get(panel);
    if (comms) return comms;
  }
  const candidates = [];
  if (controller.allComms instanceof Set) {
    for (const c of controller.allComms) {
      if (c && !candidates.includes(c)) candidates.push(c);
    }
  }
  if (controller.panelComms instanceof Map) {
    for (const c of controller.panelComms.values()) {
      if (c && !candidates.includes(c)) candidates.push(c);
    }
  }
  if (sessionId) {
    for (const c of candidates) {
      const sid = resolveSessionIdForComms(controller, c, '', c.__bhfPanel || null);
      if (sid === sessionId) return c;
    }
  }
  for (const c of candidates) {
    if (c.outstandingRequests instanceof Map && c.outstandingRequests.size > 0) {
      return c;
    }
  }
  return candidates[0] || null;
}

async function respondClaudePermission(options = {}) {
  const state = getBridgeState();
  const permId = String(options.id || options.permissionId || '').trim();
  const sessionId = String(options.sessionId || options.threadId || '').trim();
  const approved = options.approved !== false;
  const allowAlways = Boolean(options.allowAlways || options.decision === 'allow_always');
  const customReason = String(options.customReason || options.writeInResponse || '').trim();

  let target = permId ? state.pendingPermissions.get(permId) : null;
  if (!target && sessionId) {
    for (const entry of state.pendingPermissions.values()) {
      const entrySid =
        entry.sessionId ||
        resolveSessionIdForComms(state.controller, entry.comms, entry.channelId, entry.panel);
      if (entrySid === sessionId) {
        target = entry;
        break;
      }
    }
  }
  if (!target && state.pendingPermissions.size > 0) {
    target = state.pendingPermissions.values().next().value;
  }

  const comms = target?.comms || findCommsForSession(state.controller, sessionId);
  if (!comms) {
    return { resolved: false, error: 'No matching pending permission or Claude channel found' };
  }

  let resolvedCount = 0;
  const mergedUpdatedInput = {
    ...(target?.inputs || {}),
    ...(options.updatedInput && typeof options.updatedInput === 'object'
      ? options.updatedInput
      : {}),
    ...(options.answers && typeof options.answers === 'object'
      ? { answers: options.answers }
      : {})
  };

  let updatedPermissions;
  if (approved && allowAlways && Array.isArray(target?.suggestions) && target.suggestions.length > 0) {
    const dest = String(options.destination || 'userSettings');
    updatedPermissions = target.suggestions.map((s) => ({
      ...s,
      destination: s.type === 'setMode' ? s.destination : dest
    }));
  }

  const resultPayload = approved
    ? {
        behavior: 'allow',
        updatedInput: mergedUpdatedInput,
        ...(updatedPermissions ? { updatedPermissions } : {})
      }
    : {
        behavior: 'deny',
        message: customReason
          ? `${CLAUDE_REJECT_WITH_REASON_PREFIX}${customReason}`
          : String(options.reason || CLAUDE_REJECT_DEFAULT_MSG),
        interrupt: !customReason
      };

  const responseEnvelope = {
    type: 'tool_permission_response',
    result: resultPayload
  };

  if (comms.outstandingRequests instanceof Map) {
    const entries = Array.from(comms.outstandingRequests.entries());
    const targetReqId = target?.requestId || '';
    const filteredEntries =
      targetReqId && comms.outstandingRequests.has(targetReqId)
        ? [[targetReqId, comms.outstandingRequests.get(targetReqId)]]
        : entries;

    for (const [reqId, resolver] of filteredEntries) {
      let invoked = false;
      if (typeof resolver === 'function') {
        resolver(responseEnvelope);
        invoked = true;
      } else if (resolver && typeof resolver.resolve === 'function') {
        resolver.resolve(responseEnvelope);
        invoked = true;
      }
      if (invoked) {
        comms.outstandingRequests.delete(reqId);
        if (typeof comms.send === 'function') {
          try {
            comms.send({ type: 'cancel_request', targetRequestId: reqId });
          } catch {}
        }
        resolvedCount += 1;
      }
    }
  }
  if (target?.id) {
    state.pendingPermissions.delete(target.id);
  }
  const effectiveSid =
    target?.sessionId ||
    sessionId ||
    resolveSessionIdForComms(state.controller, comms, '', comms.__bhfPanel || null);
  clearPendingBadgeIfIdle(state, effectiveSid, comms, target?.panel || comms?.__bhfPanel || null);
  notifyActivityChanged({
    type: 'claude-permission-responded',
    threadId: effectiveSid,
    approved
  });
  return {
    resolved: resolvedCount > 0,
    resolvedCount,
    id: target?.id || permId || effectiveSid,
    sessionId: effectiveSid,
    approved,
    allowAlways
  };
}

async function interruptClaudeSession(options = {}) {
  const state = getBridgeState();
  const { controller } = state;
  const sessionId = String(options.id || options.threadId || '').trim();
  let interrupted = false;
  let matchedChannelId = '';

  if (sessionId && state.pendingPermissions instanceof Map) {
    for (const [reqId, p] of Array.from(state.pendingPermissions.entries())) {
      const pSid =
        p?.sessionId || resolveSessionIdForComms(controller, p?.comms, p?.channelId, p?.panel);
      if (p && pSid === sessionId) {
        try {
          await respondClaudePermission({
            id: reqId,
            sessionId,
            approved: false,
            reason: 'Stopped by user'
          });
        } catch {}
        state.pendingPermissions.delete(reqId);
        interrupted = true;
      }
    }
  }

  if (controller) {
    const candidateComms = [];
    const panel = sessionId
      ? controller.sessionPanels?.get?.(sessionId)
      : controller.sessionPanels?.get?.(controller.activePanelSessionId?.());
    if (panel && controller.panelComms instanceof Map) {
      const pc = controller.panelComms.get(panel);
      if (pc) candidateComms.push(pc);
    }
    if (controller.panelComms instanceof Map) {
      for (const pc of controller.panelComms.values()) {
        if (pc && !candidateComms.includes(pc)) candidateComms.push(pc);
      }
    }
    if (controller.allComms instanceof Set) {
      for (const ac of controller.allComms.values()) {
        if (ac && !candidateComms.includes(ac)) candidateComms.push(ac);
      }
    }

    for (const comms of candidateComms) {
      if (!comms || typeof comms.interruptClaude !== 'function') continue;
      if (sessionId && comms.channels instanceof Map) {
        for (const [channelId, entry] of comms.channels.entries()) {
          if (entry && entry.sessionId === sessionId) {
            try {
              await comms.interruptClaude(channelId);
              interrupted = true;
              matchedChannelId = channelId;
            } catch {}
          }
        }
      }
      if (!interrupted && ( comms === candidateComms[0] || !sessionId )) {
        const ch = findActiveChannelEntry(comms);
        if (ch && (!sessionId || !ch.entry?.sessionId || ch.entry.sessionId === sessionId)) {
          try {
            await comms.interruptClaude(ch.channelId);
            interrupted = true;
            matchedChannelId = ch.channelId;
          } catch {}
        }
      }
    }
  }

  if (sessionId && state.liveSessionStates instanceof Map) {
    const prev = state.liveSessionStates.get(sessionId) || {};
    state.liveSessionStates.set(sessionId, {
      ...prev,
      sessionId,
      state: 'idle',
      updatedAt: Date.now()
    });
  }
  notifyActivityChanged({
    type: 'claude-interrupted',
    threadId: sessionId
  });
  return { interrupted, sessionId, channelId: matchedChannelId };
}

function registerBridgeCommands(state) {
  state.__cmdHandlers = {
    getOpenClaudeTabsSnapshot,
    getLiveSnapshot,
    openClaudeTab,
    closeClaudeTab,
    sendPromptToClaude,
    respondClaudePermission,
    interruptClaudeSession,
    syncClaudeTabBadges
  };
  const { vscode, context } = state;
  if (!vscode || !context || state.commandsRegistered) {
    return;
  }
  state.commandsRegistered = true;

  context.subscriptions.push(
    vscode.commands.registerCommand('antigravityHub.claudeBridgeStatus', () => ({
      active: true,
      version: BRIDGE_VERSION,
      openTabs: (state.__cmdHandlers?.getOpenClaudeTabsSnapshot || getOpenClaudeTabsSnapshot)(),
      hasSidebarView: Boolean(state.sidebarView),
      hasSidebarDelegate: Boolean(state.sidebarDelegate),
      hideDuplicateIcon: getHideDuplicateSetting(vscode)
    })),
    vscode.commands.registerCommand('antigravityHub.claudeAttachSidebar', async (delegate) => {
      state.sidebarDelegate = delegate || null;
      if (state.sidebarFallbackTimer) {
        clearTimeout(state.sidebarFallbackTimer);
        state.sidebarFallbackTimer = null;
      }
      if (state.sidebarView && delegate && typeof delegate.resolveWebviewView === 'function') {
        await delegate.resolveWebviewView(state.sidebarView);
      }
      applyActivityBarVisibility(state);
      return { attached: Boolean(delegate), hadSidebarView: Boolean(state.sidebarView) };
    }),
    vscode.commands.registerCommand('antigravityHub.claudeGetSnapshot', () =>
      (state.__cmdHandlers?.getLiveSnapshot || getLiveSnapshot)()
    ),
    vscode.commands.registerCommand('antigravityHub.claudeOpenTab', async (options = {}) =>
      (state.__cmdHandlers?.openClaudeTab || openClaudeTab)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeCloseTab', async (options = {}) =>
      (state.__cmdHandlers?.closeClaudeTab || closeClaudeTab)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeSendPrompt', async (options = {}) =>
      (state.__cmdHandlers?.sendPromptToClaude || sendPromptToClaude)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeRespondPermission', async (options = {}) =>
      (state.__cmdHandlers?.respondClaudePermission || respondClaudePermission)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeInterrupt', async (options = {}) =>
      (state.__cmdHandlers?.interruptClaudeSession || interruptClaudeSession)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeRenameSession', async (options = {}) => {
      const id = String(options.id || options.threadId || '').trim();
      const title = String(options.title || '').trim();
      if (!id || !title || !state.controller) {
        return false;
      }
      try {
        state.controller.handleSessionRenamed?.(id, title, undefined, Boolean(options.skipCli));
        const panel = state.controller.sessionPanels?.get?.(id);
        if (panel) {
          panel.title = title;
        }
        return true;
      } catch {
        return false;
      }
    }),
    vscode.commands.registerCommand('antigravityHub.claudeSetUnread', async (options = {}) => {
      const id = String(options.id || options.threadId || '').trim();
      if (!id || !state.controller) {
        return false;
      }
      try {
        return Boolean(state.controller.setSessionUnread?.(id, Boolean(options.unread)));
      } catch {
        return false;
      }
    }),
    vscode.commands.registerCommand('antigravityHub.claudeDeleteGroup', async (options = {}) => {
      const gId = String(options.id || options.group || '').trim();
      const nameKey = String(options.name || '').trim().toLowerCase();
      if (!gId && !nameKey) {
        return false;
      }
      let touched = 0;
      try {
        if (typeof state.controller?.settings?.deleteSessionGroup === 'function') {
          await state.controller.settings.deleteSessionGroup(gId);
          touched += 1;
        }
      } catch {}
      try {
        const gs = state.context?.globalState;
        const keys = typeof gs?.keys === 'function' ? gs.keys() : [];
        for (const k of keys) {
          if (!String(k).startsWith('sessionGroups:')) {
            continue;
          }
          const cur = gs.get(k);
          if (!Array.isArray(cur)) {
            continue;
          }
          const next = cur.filter(
            (g) =>
              !g ||
              !(
                (gId && g.id === gId) ||
                (nameKey && String(g.name || '').trim().toLowerCase() === nameKey)
              )
          );
          if (next.length !== cur.length) {
            await gs.update(k, next);
            touched += 1;
          }
        }
      } catch {}
      return touched > 0;
    }),
    vscode.commands.registerCommand('antigravityHub.claudeRemoveFromGroup', async (options = {}) =>
      removeSessionsFromClaudeGroups(state, options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeSetArchived', async (options = {}) => {
      const rawIds = Array.isArray(options.ids)
        ? options.ids
        : options.id
          ? [options.id]
          : [];
      const ids = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
      if (ids.length === 0) {
        return false;
      }
      const archived = Boolean(options.archived);
      try {
        if (archived) {
          await removeSessionsFromClaudeGroups(state, { ids });
          if (typeof state.controller?.settings?.archiveSessions === 'function') {
            await state.controller.settings.archiveSessions(ids);
          } else if (state.context?.globalState) {
            const cur = state.context.globalState.get('hiddenSessionIds') || [];
            await state.context.globalState.update('hiddenSessionIds', [
              ...new Set([...cur, ...ids])
            ]);
          }
        } else {
          if (typeof state.controller?.settings?.unarchiveSessions === 'function') {
            await state.controller.settings.unarchiveSessions(ids);
          } else if (state.context?.globalState) {
            const cur = state.context.globalState.get('hiddenSessionIds') || [];
            const removeSet = new Set(ids);
            await state.context.globalState.update(
              'hiddenSessionIds',
              cur.filter((item) => !removeSet.has(item))
            );
          }
        }
        try {
          state.controller?.broadcastSessionArchiveChanged?.(undefined, ids[0], archived);
        } catch {}
        return true;
      } catch {
        return false;
      }
    }),
    vscode.commands.registerCommand('antigravityHub.claudeSyncTabBadges', (badgesById = {}) =>
      (state.__cmdHandlers?.syncClaudeTabBadges || syncClaudeTabBadges)(badgesById)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeResetCachedUsage', () => {
      state.lastRateLimitWindows = null;
      state.lastFullRateLimits = null;
      state.lastFullRateLimitsAt = 0;
      state.lastProcessUsagePollAt = 0;
      try {
        if (state.controller?.panelUsageRelay) {
          state.controller.panelUsageRelay.merged = null;
        }
      } catch {}
      return { ok: true };
    }),
    vscode.commands.registerCommand('antigravityHub.claudeSetActivityBarVisible', async (visible) => {
      const hideDuplicate = !visible;
      try {
        await vscode.workspace
          .getConfiguration('antigravityHub')
          .update('hideDuplicateActivityBarIcon', hideDuplicate, vscode.ConfigurationTarget.Global);
      } catch {}
      applyActivityBarVisibility(state);
      return { hideDuplicateIcon: hideDuplicate };
    })
  );

  if (typeof vscode.workspace?.onDidChangeConfiguration === 'function') {
    context.subscriptions.push(
      vscode.workspace.onDidChangeConfiguration((e) => {
        if (e.affectsConfiguration?.('antigravityHub.hideDuplicateActivityBarIcon')) {
          applyActivityBarVisibility(state);
        }
      })
    );
  }
}

function resolveVscodeApi(candidate) {
  if (
    candidate &&
    typeof candidate === 'object' &&
    candidate.workspace &&
    candidate.window &&
    candidate.commands
  ) {
    return candidate;
  }
  try {
    const realVscode = require('vscode');
    if (realVscode && realVscode.workspace && realVscode.window && realVscode.commands) {
      return realVscode;
    }
  } catch {}
  return null;
}

function attach({ vscode, context, controller }) {
  const state = getBridgeState();
  state.vscode = resolveVscodeApi(vscode) || resolveVscodeApi(state.vscode);
  state.context = context || state.context;
  state.controller = controller || state.controller;
  state.attached = true;

  installControllerHooks(state);
  installClaudeOpenFileSupport(state);
  registerBridgeCommands(state);
  applyActivityBarVisibility(state);
  setTimeout(() => applyActivityBarVisibility(state), 50);

  return state;
}

function installClaudeOpenFileSupport(state) {
  const { controller } = state || {};
  const vscode = resolveVscodeApi(state?.vscode);
  if (vscode && excelPreview?.ensureExcelPreviewRegistered) {
    excelPreview.ensureExcelPreviewRegistered(vscode, state?.context);
  }
  if (!controller || typeof controller.openFile !== 'function' || !excelPreview?.openFileUriSmart) {
    return;
  }
  if (!controller.__bhfOrigOpenFile) {
    controller.__bhfOrigOpenFile = controller.openFile.bind(controller);
  }
  state.__bhfClaudeOpenFileImpl = async function (filePath, location, opts) {
    const activeVscode = resolveVscodeApi(state?.vscode) || vscode;
    if (!filePath || !activeVscode) {
      return controller.__bhfOrigOpenFile(filePath, location, opts);
    }
    let resolved = String(filePath);
    if (!path.isAbsolute(resolved) && controller.cwd) {
      const candidate = path.join(controller.cwd, resolved);
      try {
        if (fs.existsSync(candidate)) resolved = candidate;
      } catch {}
    }
    const outcome = await excelPreview.openFileUriSmart(activeVscode, resolved, () =>
      controller.__bhfOrigOpenFile(filePath, location, opts)
    );
    return outcome && outcome.mode === 'orig' ? outcome.result : undefined;
  };
  if (!controller.__bhfOpenFileWrapped) {
    controller.__bhfOpenFileWrapped = true;
    controller.openFile = function (filePath, location, opts) {
      const impl = state.__bhfClaudeOpenFileImpl;
      return typeof impl === 'function'
        ? impl(filePath, location, opts)
        : controller.__bhfOrigOpenFile(filePath, location, opts);
    };
  }
}

async function removeSessionsFromClaudeGroups(stateOrOptions = {}, maybeOptions = {}) {
  const isStateObj =
    stateOrOptions &&
    typeof stateOrOptions === 'object' &&
    ('controller' in stateOrOptions || 'context' in stateOrOptions || 'attached' in stateOrOptions);
  const state = isStateObj ? stateOrOptions : getBridgeState();
  const options = isStateObj ? maybeOptions || {} : stateOrOptions || {};
  const rawIds = Array.isArray(options.ids)
    ? options.ids
    : options.id
      ? [options.id]
      : [];
  const removeSet = new Set(rawIds.map((x) => String(x || '').trim()).filter(Boolean));
  if (removeSet.size === 0) {
    return false;
  }
  const targetGroupId = String(options.group || options.groupId || '').trim();
  let touched = 0;

  try {
    const settings = state?.controller?.settings;
    if (typeof settings?.getSessionGroups === 'function') {
      const liveGroups = settings.getSessionGroups();
      if (Array.isArray(liveGroups)) {
        for (const g of liveGroups) {
          if (!g || !Array.isArray(g.sessionIds)) continue;
          if (targetGroupId && g.id !== targetGroupId) continue;
          const nextSids = g.sessionIds.filter((sid) => !removeSet.has(String(sid || '').trim()));
          if (nextSids.length !== g.sessionIds.length) {
            g.sessionIds = nextSids;
            touched += 1;
            if (typeof settings.removeSessionsFromGroup === 'function') {
              await settings.removeSessionsFromGroup(g.id, Array.from(removeSet));
            } else if (typeof settings.updateSessionGroup === 'function') {
              await settings.updateSessionGroup(g.id, { sessionIds: nextSids });
            }
          }
        }
      }
    }
  } catch {}

  try {
    const gs = state?.context?.globalState;
    const keys = typeof gs?.keys === 'function' ? gs.keys() : [];
    for (const k of keys) {
      if (!String(k).startsWith('sessionGroups:')) {
        continue;
      }
      const cur = gs.get(k);
      if (!Array.isArray(cur)) {
        continue;
      }
      let keyMutated = false;
      const next = cur.map((g) => {
        if (!g || !Array.isArray(g.sessionIds)) {
          return g;
        }
        if (targetGroupId && g.id !== targetGroupId) {
          return g;
        }
        const filtered = g.sessionIds.filter((sid) => !removeSet.has(String(sid || '').trim()));
        if (filtered.length !== g.sessionIds.length) {
          keyMutated = true;
          return { ...g, sessionIds: filtered };
        }
        return g;
      });
      if (keyMutated) {
        await gs.update(k, next);
        touched += 1;
      }
    }
  } catch {}

  return touched > 0;
}

function hotUpgradeLiveState() {
  const state = getBridgeState();
  registerBridgeCommands(state);
  installClaudeOpenFileSupport(state);
  const { controller } = state;
  if (!state.removeFromGroupCommandRegistered && state.vscode?.commands && state.context) {
    state.removeFromGroupCommandRegistered = true;
    try {
      state.context.subscriptions.push(
        state.vscode.commands.registerCommand(
          'antigravityHub.claudeRemoveFromGroup',
          async (options = {}) => removeSessionsFromClaudeGroups(state, options)
        )
      );
    } catch {}
  }
  if (!controller) return false;
  if (controller.sessionPanels instanceof Map) {
    for (const panel of controller.sessionPanels.values()) {
      ensurePanelHooked(state, panel);
    }
  }
  if (controller.panelComms instanceof Map) {
    for (const [panel, c] of controller.panelComms.entries()) {
      if (c && panel) c.__bhfPanel = panel;
      ensurePanelHooked(state, panel);
      hookCommsObject(state, c, panel);
    }
  }
  if (controller.allComms instanceof Set) {
    for (const c of controller.allComms) {
      hookCommsObject(state, c, c?.__bhfPanel || null);
    }
  }
  return true;
}

module.exports = {
  BRIDGE_VERSION,
  CLAUDE_DRAFT_SCHEME,
  attach,
  getBridgeState,
  hotUpgradeLiveState,
  getLiveSnapshot,
  getOpenClaudeTabsSnapshot,
  getPendingPermissionsSnapshot,
  openClaudeTab,
  closeClaudeTab,
  syncClaudeTabBadges,
  applyPanelTabIcon,
  respondClaudePermission,
  sendPromptToClaude,
  interruptClaudeSession,
  reviveRememberedClaudeTabs,
  removeSessionsFromClaudeGroups
};

