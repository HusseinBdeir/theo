const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
let excelPreview = null;
try {
  excelPreview = require('./excel-preview.cjs');
} catch {}
let normalizeUriKey = (u) => String(u || '').trim();
try {
  ({ normalizeUriKey } = require('./antigravity-tab-state.cjs'));
} catch {}

const BRIDGE_VERSION = '0.1.0';
const STATE_SYMBOL = Symbol.for('bhfirms.antigravityHub.claudeBridgeState');
const PREWARM_GUARD_SYMBOL = Symbol.for('bhfirms.theoHub.prewarmGuard');
const CLAUDE_DRAFT_SCHEME = 'claude-session';
const CLAUDE_PREWARM_IDS_STATE_KEY = 'antigravity-hub.claude-prewarmed-ids.v1';

function readPersistedPrewarmClaudeIds(workspaceState) {
  try {
    const raw = workspaceState?.get?.(CLAUDE_PREWARM_IDS_STATE_KEY, []);
    if (!Array.isArray(raw)) return [];
    const out = [];
    const seen = new Set();
    for (const id of raw) {
      const clean = String(id || '').trim();
      if (clean && !seen.has(clean)) {
        seen.add(clean);
        out.push(clean);
      }
    }
    return out;
  } catch {
    return [];
  }
}

const claudePrewarmIdWriteChains = new WeakMap();

function queuePersistedPrewarmClaudeWrite(workspaceState, task) {
  if (!workspaceState || typeof workspaceState.update !== 'function') {
    return Promise.resolve();
  }
  const prev = claudePrewarmIdWriteChains.get(workspaceState) || Promise.resolve();
  const next = prev.catch(() => {}).then(() => task(workspaceState));
  claudePrewarmIdWriteChains.set(workspaceState, next.catch(() => {}));
  return next;
}

async function recordPersistedPrewarmClaudeId(workspaceState, sessionId) {
  const clean = String(sessionId || '').trim();
  if (!clean) return;
  await queuePersistedPrewarmClaudeWrite(workspaceState, async (ws) => {
    const cur = readPersistedPrewarmClaudeIds(ws);
    if (cur.includes(clean)) return;
    await ws.update(CLAUDE_PREWARM_IDS_STATE_KEY, [...cur.slice(-7), clean]);
  });
}

async function removePersistedPrewarmClaudeId(workspaceState, sessionId) {
  const clean = String(sessionId || '').trim();
  if (!clean) return;
  await queuePersistedPrewarmClaudeWrite(workspaceState, async (ws) => {
    const cur = readPersistedPrewarmClaudeIds(ws);
    if (!cur.includes(clean)) return;
    await ws.update(
      CLAUDE_PREWARM_IDS_STATE_KEY,
      cur.filter((id) => id !== clean)
    );
  });
}

function isPrewarmGuardActive() {
  return Number(globalThis[PREWARM_GUARD_SYMBOL]?.depth || 0) > 0;
}

async function withPrewarmGuard(fn) {
  const box = (globalThis[PREWARM_GUARD_SYMBOL] ||= { depth: 0 });
  box.depth += 1;
  try {
    return await fn();
  } finally {
    box.depth = Math.max(0, box.depth - 1);
  }
}

function captureActiveTabInColumn(vscode, viewColumn) {
  const groups = Array.isArray(vscode?.window?.tabGroups?.all) ? vscode.window.tabGroups.all : [];
  const hasExplicitCol = typeof viewColumn === 'number' && Number.isFinite(viewColumn);
  const activeGroup =
    vscode?.window?.tabGroups?.activeTabGroup ||
    groups.find((g) => Boolean(g?.isActive)) ||
    null;
  const group = hasExplicitCol
    ? groups.find((g) => Number(g?.viewColumn || 1) === Number(viewColumn)) || null
    : activeGroup || groups[0] || null;
  if (!group) {
    return null;
  }
  const tabs = Array.isArray(group.tabs) ? group.tabs : [];
  const activeTab = group.activeTab || tabs.find((t) => Boolean(t?.isActive)) || null;
  const idx = activeTab ? tabs.indexOf(activeTab) : -1;
  if (idx < 0) {
    return null;
  }
  return {
    viewColumn: group.viewColumn || (hasExplicitCol ? viewColumn : 1),
    index: idx,
    tab: activeTab,
    inputUri: activeTab?.input?.uri || activeTab?.input?.original || null,
    viewType: String(activeTab?.input?.viewType || ''),
    uriStr: activeTab?.input?.uri ? String(activeTab.input.uri) : '',
    label: String(activeTab?.label || '')
  };
}

async function restoreActiveTabInColumn(stateOrVscode, saved) {
  const vscode = stateOrVscode?.window ? stateOrVscode : stateOrVscode?.vscode;
  const state = stateOrVscode?.controller ? stateOrVscode : getBridgeState();
  if (!vscode || !saved || typeof saved.index !== 'number' || saved.index < 0) {
    return;
  }
  const targetCol = Number(saved.viewColumn || 1);
  let targetTab = saved.tab || null;
  let targetUri = saved.inputUri || null;
  let targetUriStr = saved.uriStr || '';
  let targetUriKey = targetUriStr ? normalizeUriKey(targetUriStr) : '';
  let targetViewType = saved.viewType || '';
  let targetLabel = saved.label || '';
  try {
    const groups = Array.isArray(vscode?.window?.tabGroups?.all) ? vscode.window.tabGroups.all : [];
    const grp = groups.find((g) => Number(g?.viewColumn || 1) === targetCol) || null;
    const tabs = Array.isArray(grp?.tabs) ? grp.tabs : [];
    const matched = tabs.find(
      (t) =>
        t === saved.tab ||
        (targetUriKey && t?.input?.uri && normalizeUriKey(t.input.uri) === targetUriKey) ||
        (saved.viewType &&
          String(t?.input?.viewType || '') === saved.viewType &&
          String(t?.label || '') === saved.label)
    );
    if (matched) {
      targetTab = matched;
      targetUri = matched?.input?.uri || matched?.input?.original || targetUri;
      targetUriStr = matched?.input?.uri ? String(matched.input.uri) : targetUriStr;
      targetUriKey = targetUriStr ? normalizeUriKey(targetUriStr) : targetUriKey;
      targetViewType = String(matched?.input?.viewType || targetViewType || '');
      targetLabel = String(matched?.label || targetLabel || '');
    }
  } catch {}
  try {
    const ctrl = state?.controller;
    const isClaudeRestoreTarget = /claude/i.test(targetViewType) && !targetUriKey;
    if (ctrl && isClaudeRestoreTarget) {
      const panels = [];
      if (ctrl.sessionPanels instanceof Map) {
        for (const p of ctrl.sessionPanels.values()) panels.push(p);
      }
      if (ctrl.panelComms instanceof Map) {
        for (const p of ctrl.panelComms.keys()) panels.push(p);
      }
      const isEligibleClaudePanel = (p) =>
        p &&
        !p.__bhfDisposed &&
        !p.__bhfPrewarmed &&
        !p.__bhfEvictingPrewarm &&
        Number(p.viewColumn || 1) === targetCol &&
        (!targetLabel || String(p.title || '') === targetLabel);
      const matchedPanel =
        panels.find((p) => isEligibleClaudePanel(p) && p.active) ||
        panels.find(isEligibleClaudePanel) ||
        null;
      if (matchedPanel?.reveal) {
        matchedPanel.reveal(targetCol, true);
        return;
      }
    }
    const agyState = globalThis[Symbol.for('bhfirms.antigravityHub.bridgeState')];
    if (targetUriKey && agyState?.entriesByUriKey instanceof Map) {
      for (const entry of agyState.entriesByUriKey.values()) {
        const eUri = normalizeUriKey(entry?.uriKey || entry?.uri || '');
        if (
          entry?.panel?.reveal &&
          !entry.__bhfPrewarmed &&
          !entry.__bhfEvictingPrewarm &&
          eUri &&
          eUri === targetUriKey
        ) {
          entry.panel.reveal(targetCol, true);
          return;
        }
      }
    }
    const openUri = targetUri || (targetUriStr && vscode.Uri?.parse ? vscode.Uri.parse(targetUriStr) : null);
    if (openUri && vscode.commands?.executeCommand) {
      if (targetViewType && targetViewType !== 'default') {
        await vscode.commands.executeCommand('vscode.openWith', openUri, targetViewType, {
          viewColumn: targetCol,
          preserveFocus: true,
          preview: false
        });
      } else {
        await vscode.commands.executeCommand('vscode.open', openUri, {
          viewColumn: targetCol,
          preserveFocus: true,
          preview: false
        });
      }
    }
  } catch {}
}

function isPendingClaudePrewarm(state, sessionId, panel = null) {
  if (panel?.__bhfPrewarmed) return true;
  const cleanId = String(sessionId || panel?.__bhfSessionId || '').trim();
  return Boolean(cleanId && state?.__bhfPendingPrewarmSessionIds?.has?.(cleanId));
}

function markPanelAsPrewarmedIfPending(state, sessionId, panel) {
  if (!panel) return false;
  const cleanId = String(sessionId || panel.__bhfSessionId || '').trim();
  if (cleanId && state?.__bhfPendingPrewarmSessionIds?.has?.(cleanId)) {
    panel.__bhfSessionId = cleanId;
    panel.__bhfPrewarmed = true;
    panel.__bhfPrewarmedAt = panel.__bhfPrewarmedAt || Date.now();
    panel.__bhfEvictingPrewarm = false;
    return true;
  }
  return Boolean(panel.__bhfPrewarmed);
}

function stripSessionFromRememberedTabs(controller, sessionId) {
  const cleanId = String(sessionId || '').trim();
  if (!cleanId || !Array.isArray(controller?.rememberedTabSessions)) return;
  const filtered = controller.rememberedTabSessions.filter(
    (rem) => String(rem?.sessionId || '').trim() !== cleanId
  );
  if (filtered.length !== controller.rememberedTabSessions.length) {
    controller.rememberedTabSessions.splice(0, controller.rememberedTabSessions.length, ...filtered);
  }
}

function getAllClaudeLivePanels(state) {
  const out = [];
  const seen = new Set();
  const ctrl = state?.controller;
  if (ctrl?.sessionPanels instanceof Map) {
    for (const [sid, panel] of ctrl.sessionPanels.entries()) {
      if (!panel || seen.has(panel)) continue;
      seen.add(panel);
      out.push({ sid: String(sid || ''), panel });
    }
  }
  if (ctrl?.panelComms instanceof Map) {
    for (const panel of ctrl.panelComms.keys()) {
      if (!panel || seen.has(panel)) continue;
      seen.add(panel);
      out.push({ sid: String(panel.__bhfSessionId || ''), panel });
    }
  }
  return out;
}

function isAgySessionTabPrewarmed(inputUri) {
  try {
    const agyState = globalThis[Symbol.for('bhfirms.antigravityHub.bridgeState')];
    if (!agyState || !inputUri) return false;
    const targetKey = normalizeUriKey(inputUri);
    if (!targetKey) return false;
    if (agyState.__bhfPendingPrewarmByUri?.has?.(targetKey)) {
      return true;
    }
    for (const entry of agyState.entriesByUriKey?.values?.() || []) {
      if (normalizeUriKey(entry?.uriKey || entry?.uri || '') === targetKey) {
        return Boolean(entry.__bhfPrewarmed || entry.__bhfEvictingPrewarm);
      }
    }
    const persisted = agyState.context?.workspaceState?.get?.('antigravity-hub.prewarmed-uris.v1', []);
    if (Array.isArray(persisted)) {
      for (const u of persisted) {
        if (normalizeUriKey(u) === targetKey) return true;
      }
    }
    return false;
  } catch {
    return false;
  }
}

function hasNonPrewarmedTabInClaudeColumn(
  state,
  viewColumn,
  { excludePanel = null, excludeSessionId = '' } = {}
) {
  const col = Number(viewColumn || 1);
  const cleanExclSid = String(excludeSessionId || '').trim();
  const vscode = state?.vscode;
  const groups = Array.isArray(vscode?.window?.tabGroups?.all) ? vscode.window.tabGroups.all : [];
  const colGroup = groups.find((g) => Number(g?.viewColumn || 1) === col) || null;
  if (colGroup && Array.isArray(colGroup.tabs)) {
    const skipClaudeLabelBudget = new Map();
    let skipUnlabeledBudget = 0;
    for (const { sid, panel } of getAllClaudeLivePanels(state)) {
      if (!panel || panel.__bhfDisposed) continue;
      if (Number(panel.viewColumn || 1) !== col) continue;
      const isExcluded = panel === excludePanel || Boolean(cleanExclSid && sid === cleanExclSid);
      const isPw = Boolean(panel.__bhfPrewarmed || panel.__bhfEvictingPrewarm);
      if (!isExcluded && !isPw) continue;
      const lbl = String(panel.title || '').trim();
      if (lbl) {
        skipClaudeLabelBudget.set(lbl, (skipClaudeLabelBudget.get(lbl) || 0) + 1);
      } else {
        skipUnlabeledBudget += 1;
      }
    }
    for (const tab of colGroup.tabs) {
      if (!tab) continue;
      const vt = String(tab?.input?.viewType || '');
      const lbl = String(tab?.label || '').trim();
      if (/claude/i.test(vt)) {
        const rem = lbl ? skipClaudeLabelBudget.get(lbl) || 0 : 0;
        if (rem > 0) {
          skipClaudeLabelBudget.set(lbl, rem - 1);
          continue;
        }
        if (!lbl && skipUnlabeledBudget > 0) {
          skipUnlabeledBudget -= 1;
          continue;
        }
        return true;
      }
      if (tab?.input?.uri?.scheme === 'antigravity-session' && isAgySessionTabPrewarmed(tab.input.uri)) {
        continue;
      }
      return true;
    }
    return false;
  }
  for (const { sid, panel } of getAllClaudeLivePanels(state)) {
    if (!panel || panel.__bhfDisposed || panel === excludePanel) continue;
    if (cleanExclSid && sid === cleanExclSid) continue;
    if (panel.__bhfPrewarmed || panel.__bhfEvictingPrewarm) continue;
    if (Number(panel.viewColumn || 1) === col) {
      return true;
    }
  }
  return false;
}

const PREWARM_TELEMETRY_SYM = Symbol.for('bhfirms.theoHub.prewarmTelemetry');

function ensurePrewarmTelemetryStore() {
  let st = globalThis[PREWARM_TELEMETRY_SYM];
  if (!st || typeof st !== 'object' || st.version !== 1) {
    st = {
      version: 1,
      resetGen: 1,
      startedAt: Date.now(),
      tier1Passes: 0,
      prewarmedOpens: 0,
      hits: 0,
      coldOpens: 0,
      evictions: 0,
      totalWarmHitAgeMs: 0,
      lastHitAt: 0,
      byProvider: {
        antigravity: { prewarmedOpens: 0, hits: 0, coldOpens: 0, evictions: 0 },
        claude: { prewarmedOpens: 0, hits: 0, coldOpens: 0, evictions: 0 }
      }
    };
    globalThis[PREWARM_TELEMETRY_SYM] = st;
  } else if (!Number.isFinite(st.resetGen) || st.resetGen < 1) {
    st.resetGen = 1;
  }
  return st;
}

function recordPrewarmTelemetryWarmed(panel) {
  const st = ensurePrewarmTelemetryStore();
  const gen = Number(st.resetGen || 1);
  if (!panel || (panel.__bhfTelemetryWarmed && Number(panel.__bhfTelemetryGen || 0) === gen)) {
    return false;
  }
  panel.__bhfTelemetryWarmed = true;
  panel.__bhfTelemetryGen = gen;
  st.prewarmedOpens += 1;
  st.byProvider.claude.prewarmedOpens += 1;
  return true;
}

function recordPrewarmTelemetryHit(panel) {
  if (!panel || panel.__bhfTelemetryPromoted) return false;
  const st = ensurePrewarmTelemetryStore();
  const gen = Number(st.resetGen || 1);
  if (panel.__bhfTelemetryWarmed && Number(panel.__bhfTelemetryGen || 0) !== gen) {
    panel.__bhfTelemetryPromoted = true;
    return false;
  }
  if (!panel.__bhfTelemetryWarmed && !panel.__bhfTelemetryColdCounted) {
    recordPrewarmTelemetryWarmed(panel);
  }
  panel.__bhfTelemetryPromoted = true;
  const warmAgeMs = panel.__bhfPrewarmedAt
    ? Math.max(0, Date.now() - Number(panel.__bhfPrewarmedAt))
    : 0;
  st.hits += 1;
  st.totalWarmHitAgeMs += warmAgeMs;
  st.lastHitAt = Date.now();
  st.byProvider.claude.hits += 1;
  return true;
}

function recordPrewarmTelemetryEvicted(panel) {
  if (!panel || !panel.__bhfTelemetryWarmed || panel.__bhfTelemetryPromoted || panel.__bhfTelemetryEvicted) {
    return false;
  }
  const st = ensurePrewarmTelemetryStore();
  const gen = Number(st.resetGen || 1);
  if (Number(panel.__bhfTelemetryGen || 0) !== gen) {
    panel.__bhfTelemetryEvicted = true;
    return false;
  }
  panel.__bhfTelemetryEvicted = true;
  st.evictions += 1;
  st.byProvider.claude.evictions += 1;
  return true;
}

function recordPrewarmTelemetryColdOpen(panel) {
  if (panel && (panel.__bhfTelemetryPromoted || panel.__bhfTelemetryWarmed || panel.__bhfTelemetryColdCounted)) {
    return false;
  }
  if (panel) panel.__bhfTelemetryColdCounted = true;
  const st = ensurePrewarmTelemetryStore();
  st.coldOpens += 1;
  st.byProvider.claude.coldOpens += 1;
  return true;
}

function evictPrewarmedClaudePanel(state, panel) {
  if (!panel || !panel.__bhfPrewarmed) return false;
  recordPrewarmTelemetryEvicted(panel);
  panel.__bhfEvictingPrewarm = true;
  panel.__bhfPrewarmed = false;
  panel.__bhfPrewarmedAt = 0;
  const sid = findSessionIdForPanel(state?.controller, panel) || panel.__bhfSessionId || '';
  if (sid) {
    removePersistedPrewarmClaudeId(state?.context?.workspaceState, sid).catch?.(() => {});
    stripSessionFromRememberedTabs(state?.controller, sid);
  }
  try {
    panel.dispose?.();
  } catch {}
  return true;
}

function evictPrewarmedClaudeTabsInColumnIfOrphaned(state, viewColumn, excludeOpts = {}) {
  if (!state || hasNonPrewarmedTabInClaudeColumn(state, viewColumn, excludeOpts)) {
    return 0;
  }
  const col = Number(viewColumn || 1);
  let count = 0;
  for (const { panel } of getAllClaudeLivePanels(state)) {
    if (!panel || panel.__bhfDisposed || !panel.__bhfPrewarmed) continue;
    if (Number(panel.viewColumn || 1) === col) {
      if (evictPrewarmedClaudePanel(state, panel)) count += 1;
    }
  }
  return count;
}

async function sweepPersistedPrewarmClaudeIds(state) {
  const workspaceState = state?.context?.workspaceState;
  const ctrl = state?.controller;
  if (!workspaceState) return 0;
  const persisted = readPersistedPrewarmClaudeIds(workspaceState);
  if (persisted.length === 0) return 0;
  if (!(state.__bhfEvictedStartupPrewarmClaudeIds instanceof Set)) {
    state.__bhfEvictedStartupPrewarmClaudeIds = new Set();
  }
  let swept = 0;
  for (const sid of persisted) {
    if (state.__bhfPendingPrewarmSessionIds?.has?.(sid)) continue;
    const livePanel = ctrl?.sessionPanels?.get?.(sid);
    if (livePanel && !livePanel.__bhfPrewarmed && !livePanel.__bhfDisposed) {
      await removePersistedPrewarmClaudeId(workspaceState, sid).catch(() => {});
      continue;
    }
    state.__bhfEvictedStartupPrewarmClaudeIds.add(sid);
    stripSessionFromRememberedTabs(ctrl, sid);
    if (livePanel && !livePanel.__bhfDisposed) {
      livePanel.__bhfEvictingPrewarm = true;
      livePanel.__bhfPrewarmed = false;
      try {
        livePanel.dispose();
        swept += 1;
      } catch {}
    }
    await removePersistedPrewarmClaudeId(workspaceState, sid).catch(() => {});
  }
  return swept;
}

function promotePrewarmedClaudePanel(state, panel, { notify = true } = {}) {
  if (!panel || !panel.__bhfPrewarmed) {
    return false;
  }
  recordPrewarmTelemetryHit(panel);
  panel.__bhfPrewarmed = false;
  panel.__bhfPrewarmedAt = 0;
  const sid = findSessionIdForPanel(state?.controller, panel) || panel.__bhfSessionId || '';
  if (sid) {
    removePersistedPrewarmClaudeId(state?.context?.workspaceState, sid).catch?.(() => {});
  }
  try {
    state?.sidebarDelegate?.notePrewarmPromoted?.(sid || '');
  } catch {}
  if (notify) {
    notifyActivityChanged({
      type: 'tab-state',
      threadId: sid || '',
      uri: panel.__bhfDraftUri || '',
      active: Boolean(panel.active)
    });
  }
  return true;
}

const TAB_ICON_FILES = {
  plain: 'claude-logo.svg',
  done: 'claude-logo-done.svg',
  pending: 'claude-logo-pending.svg'
};

function makeDraftId() {
  if (typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
}

function getBridgeState() {
  if (!globalThis[STATE_SYMBOL]) {
    globalThis[STATE_SYMBOL] = {
      attached: false,
      version: BRIDGE_VERSION,
      vscode: null,
      context: null,
      controller: null,
      sidebarView: null,
      sidebarDelegate: null,
      sidebarFallbackTimer: null,
      origResolveSessionListView: null,
      badgeById: new Map(),
      lastRateLimitWindows: null,
      lastFullRateLimits: null,
      lastFullRateLimitsAt: 0,
      lastProcessUsagePollAt: 0,
      activityTimer: null,
      commandsRegistered: false,
      hookedPanels: new WeakSet(),
      hookedComms: new WeakSet(),
      pendingPermissions: new Map(),
      __bhfPermSyncTimer: null,
      __bhfPermSyncInFlight: null,
      __bhfSharedPermCache: null,
      __bhfAppliedSharedPermMode: '',
      __bhfConfigSyncedMode: '',
      __bhfSharedPlanSessionIds: new Set()
    };
  }
  return globalThis[STATE_SYMBOL];
}

const _scratchSessionCache = new Map();

function isClaudeDesktopScratchSessionSync(sessionId, vscodeApi = null, stateObj = null) {
  const cleanId = String(sessionId || '').trim();
  if (!cleanId || cleanId.includes('/') || cleanId.includes('\\') || cleanId.includes('..')) {
    return false;
  }
  try {
    const cfgDir = String(
      vscodeApi?.workspace?.getConfiguration?.('antigravityHub')?.get?.('claudeDataDir', '') || ''
    ).trim();
    const claudeHome = cfgDir || path.join(os.homedir(), '.claude');
    const cache =
      stateObj && typeof stateObj === 'object'
        ? stateObj.__bhfScratchSessionCache || (stateObj.__bhfScratchSessionCache = new Map())
        : _scratchSessionCache;
    const cacheKey = `${claudeHome}\n${cleanId}`;
    const now = Date.now();
    const hit = cache.get(cacheKey);
    if (hit && (hit.expiresAt === 0 || now < hit.expiresAt)) {
      return hit.value;
    }
    const setCache = (value, foundFile) => {
      if (cache.size >= 1000 && !cache.has(cacheKey)) {
        const oldestKey = cache.keys().next().value;
        if (oldestKey !== undefined) cache.delete(oldestKey);
      }
      cache.set(cacheKey, {
        value: Boolean(value),
        expiresAt: foundFile ? 0 : now + 30000
      });
      return Boolean(value);
    };

    const projectsDir = path.join(claudeHome, 'projects');
    if (!fs.existsSync(projectsDir)) return setCache(false, false);
    for (const entry of fs.readdirSync(projectsDir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const candidate = path.join(projectsDir, entry.name, `${cleanId}.jsonl`);
      if (!fs.existsSync(candidate)) continue;
      if (/(?:-|_)scratch-workspaces(?:-|$)|(?:-|_)appdata[-_]+local[-_]+claude-data(?:-|$)/i.test(entry.name)) {
        return setCache(true, true);
      }
      const fd = fs.openSync(candidate, 'r');
      try {
        const buf = Buffer.alloc(65536);
        const bytesRead = fs.readSync(fd, buf, 0, buf.length, 0);
        const head = buf
          .toString('utf8', 0, bytesRead)
          .replace(/\\\\/g, '/')
          .replace(/\\\//g, '/')
          .replace(/\\/g, '/')
          .toLowerCase();
        const isScratch =
          head.includes('/scratch-workspaces/') ||
          head.includes('/scratch-workspaces"') ||
          head.includes('/appdata/local/claude-data/') ||
          head.endsWith('/scratch-workspaces');
        return setCache(isScratch, true);
      } finally {
        fs.closeSync(fd);
      }
    }
    return setCache(false, false);
  } catch {}
  return false;
}

function getHideDuplicateSetting(vscode) {
  try {
    return Boolean(
      vscode?.workspace
        ?.getConfiguration('antigravityHub')
        ?.get('hideDuplicateActivityBarIcon', true)
    );
  } catch {
    return true;
  }
}

function applyActivityBarVisibility(state) {
  const { vscode } = state;
  if (!vscode?.commands) {
    return;
  }
  const hideDuplicate = getHideDuplicateSetting(vscode);
  vscode.commands
    .executeCommand('setContext', 'claude-vscode.sessionsListEnabled', !hideDuplicate)
    .then(
      () => {},
      () => {}
    );
}

function notifyActivityChanged(payload = {}) {
  const state = getBridgeState();
  const cleanTid = String(payload?.threadId || '').trim();
  const livePanel = cleanTid ? state.controller?.sessionPanels?.get?.(cleanTid) : null;
  if (
    payload?.type !== 'tab-closed' &&
    (isPrewarmGuardActive() || isPendingClaudePrewarm(state, cleanTid, livePanel))
  ) {
    return;
  }
  if (payload?.type === 'tab-closed') {
    try {
      state.sidebarDelegate?.handleTabClosedFast?.({
        id: payload.threadId || '',
        key: payload.uri || ''
      });
    } catch {}
  }
  const { vscode } = state;
  if (!vscode?.commands) {
    return;
  }
  const prev = state.pendingActivityPayload;
  if (!prev || payload?.type === 'tab-closed' || prev?.type !== 'tab-closed') {
    state.pendingActivityPayload = { ...payload };
  }
  if (state.activityTimer) {
    clearTimeout(state.activityTimer);
  }
  const delayMs =
    payload?.type === 'tab-closed' || state.pendingActivityPayload?.type === 'tab-closed' ? 5 : 60;
  state.activityTimer = setTimeout(() => {
    state.activityTimer = null;
    const merged = state.pendingActivityPayload || payload;
    state.pendingActivityPayload = null;
    const mergedTid = String(merged?.threadId || '').trim();
    const mergedPanel = mergedTid ? state.controller?.sessionPanels?.get?.(mergedTid) : null;
    if (
      merged?.type !== 'tab-closed' &&
      (isPrewarmGuardActive() || isPendingClaudePrewarm(state, mergedTid, mergedPanel))
    ) {
      return;
    }
    vscode.commands
      .executeCommand('antigravityHub.activityChanged', {
        provider: 'claude',
        ...merged
      })
      .then(
        () => {},
        () => {}
      );
  }, delayMs);
}

function notifyThreadSeen(threadId) {
  const cleanId = String(threadId || '').trim();
  if (!cleanId) {
    return;
  }
  const state = getBridgeState();
  if (state.badgeById.get(cleanId) === 'done') {
    state.badgeById.set(cleanId, 'plain');
  }
  try {
    state.controller?.setSessionUnread?.(cleanId, false);
  } catch {}
  if (state.vscode?.commands) {
    state.vscode.commands
      .executeCommand('antigravityHub.markThreadSeen', {
        id: cleanId,
        provider: 'claude',
        seenAt: Math.floor(Date.now() / 1000)
      })
      .then(
        () => {},
        () => {}
      );
  }
}

function getTabIconPath(state, badgeState = 'plain') {
  const { vscode, context } = state;
  if (!vscode?.Uri || !context?.extensionPath) {
    return null;
  }
  const fileName = TAB_ICON_FILES[badgeState] || TAB_ICON_FILES.plain;
  const iconUri = vscode.Uri.file(path.join(context.extensionPath, 'resources', fileName));
  return { light: iconUri, dark: iconUri };
}

function doesIconMatchFileName(iconPath, fileName) {
  if (!iconPath || !fileName) {
    return false;
  }
  const target = iconPath.dark || iconPath.light || iconPath;
  const raw = String(target?.fsPath || target?.path || target || '');
  if (!raw) {
    return false;
  }
  const lower = raw.toLowerCase();
  const suffix = String(fileName).toLowerCase();
  return lower.endsWith(`/${suffix}`) || lower.endsWith(`\\${suffix}`) || lower === suffix;
}

function applyPanelTabIcon(state, panel, badgeState = 'plain') {
  if (!panel) {
    return false;
  }
  const normalized = TAB_ICON_FILES[badgeState] ? badgeState : 'plain';
  const expectedFile = TAB_ICON_FILES[normalized];
  if (
    panel.__bhfBadgeState === normalized &&
    doesIconMatchFileName(panel.iconPath, expectedFile)
  ) {
    return false;
  }
  const iconPath = getTabIconPath(state, normalized);
  if (!iconPath) {
    return false;
  }
  try {
    panel.iconPath = iconPath;
    panel.__bhfBadgeState = normalized;
    return true;
  } catch {
    return false;
  }
}

function findSessionIdForPanel(controller, targetPanel) {
  if (!controller?.sessionPanels || !targetPanel) {
    return '';
  }
  for (const [sessionId, panel] of controller.sessionPanels.entries()) {
    if (panel === targetPanel) {
      return String(sessionId || '');
    }
  }
  return '';
}

function findPanelForComms(controller, targetComms) {
  if (!targetComms) {
    return null;
  }
  if (targetComms.__bhfPanel) {
    return targetComms.__bhfPanel;
  }
  if (controller?.panelComms instanceof Map) {
    for (const [panel, c] of controller.panelComms.entries()) {
      if (c === targetComms) {
        targetComms.__bhfPanel = panel;
        return panel;
      }
    }
  }
  return null;
}

function resolveSessionIdForComms(controller, comms, channelId = '', panel = null) {
  if (comms) {
    if (channelId && comms.channels instanceof Map) {
      const ch = comms.channels.get(channelId);
      if (ch?.sessionId) {
        return String(ch.sessionId);
      }
    }
    if (channelId && comms.pendingChannels instanceof Map) {
      const pch = comms.pendingChannels.get(channelId);
      if (pch?.sessionId) {
        return String(pch.sessionId);
      }
    }
    if (comms.channels instanceof Map) {
      for (const ch of comms.channels.values()) {
        if (ch?.sessionId) {
          return String(ch.sessionId);
        }
      }
    }
    if (comms.pendingChannels instanceof Map) {
      for (const pch of comms.pendingChannels.values()) {
        if (pch?.sessionId) {
          return String(pch.sessionId);
        }
      }
    }
  }
  const resolvedPanel = panel || findPanelForComms(controller, comms);
  return findSessionIdForPanel(controller, resolvedPanel);
}

function hasRemainingPendingPermissionsForSession(state, sessionId, comms = null) {
  if (!(state?.pendingPermissions instanceof Map) || state.pendingPermissions.size === 0) {
    return false;
  }
  for (const entry of state.pendingPermissions.values()) {
    if (!entry) continue;
    if (comms && entry.comms === comms) {
      return true;
    }
    if (sessionId) {
      const entrySid =
        entry.sessionId ||
        resolveSessionIdForComms(state.controller, entry.comms, entry.channelId, entry.panel);
      if (entrySid === sessionId) {
        return true;
      }
    }
  }
  return false;
}

function clearPendingBadgeIfIdle(state, sessionId, comms = null, panel = null) {
  if (hasRemainingPendingPermissionsForSession(state, sessionId, comms)) {
    return false;
  }
  if (comms?.lastRenameTabFlags && typeof comms.lastRenameTabFlags === 'object') {
    comms.lastRenameTabFlags.hasPendingPermissions = false;
  }
  if (sessionId && state.badgeById.get(sessionId) === 'pending') {
    state.badgeById.set(sessionId, 'plain');
  }
  const targetPanel =
    panel ||
    (sessionId ? state.controller?.sessionPanels?.get?.(sessionId) : null) ||
    comms?.__bhfPanel ||
    findPanelForComms(state.controller, comms);
  if (targetPanel) {
    const nextBadge =
      sessionId && state.badgeById.get(sessionId) === 'done' && !targetPanel.active
        ? 'done'
        : 'plain';
    return applyPanelTabIcon(state, targetPanel, nextBadge);
  }
  return false;
}

function hookCommsObject(state, comms, panel = null) {
  if (!comms) {
    return;
  }
  if (panel) {
    comms.__bhfPanel = panel;
  }
  state.hookedComms.add(comms);
  if (!(comms.__bhfChannelModes instanceof Map)) {
    comms.__bhfChannelModes = new Map();
  }
  if (!(comms.__bhfUserChosenChannelModes instanceof Map)) {
    comms.__bhfUserChosenChannelModes = new Map();
  }
  if (!(comms.__bhfAppliedSharedModeByChannel instanceof Map)) {
    comms.__bhfAppliedSharedModeByChannel = new Map();
  }
  if (!(comms.__bhfSharedPlanChannels instanceof Set)) {
    comms.__bhfSharedPlanChannels = new Set();
  }
  if (!comms.__bhfHookedSendPermTrack && typeof comms.send === 'function') {
    comms.__bhfHookedSendPermTrack = true;
    comms.__bhfOrigSend = comms.send.bind(comms);
    comms.send = function (payload, ...rest) {
      try {
        if (typeof state.__bhfOnCommsSend === 'function') {
          state.__bhfOnCommsSend(state, comms, payload);
        }
      } catch {}
      return comms.__bhfOrigSend(payload, ...rest);
    };
  }
  // Unsent-text reports from the chat box (claude-webview-patches.cjs /*bhf-draft-report*/) are THEO's own
  // messages: record them on the comms object and never pass them to Claude Code, which would log each one as
  // "Unknown message". Read by getClaudeDraftSnapshot for the hands-free reload (auto-reload.js).
  if (!comms.__bhfHookedFromClient && typeof comms.fromClient === 'function') {
    comms.__bhfHookedFromClient = true;
    const origFromClient = comms.fromClient.bind(comms);
    comms.fromClient = function (msg, ...rest) {
      if (msg && typeof msg === 'object' && msg.type === 'bhf_draft_state') {
        comms.__bhfDraftReport = { has: msg.has === true, at: Date.now() };
        return undefined;
      }
      return origFromClient(msg, ...rest);
    };
  }
  if (!comms.__bhfHookedSetPermissionMode && typeof comms.setPermissionMode === 'function') {
    comms.__bhfHookedSetPermissionMode = true;
    comms.__bhfOrigSetPermissionMode = comms.setPermissionMode.bind(comms);
    comms.setPermissionMode = function (channelId, mode, userInitiated, ...rest) {
      if (typeof state.__bhfOnCommsSetPermissionMode === 'function') {
        return state.__bhfOnCommsSetPermissionMode(
          state,
          comms,
          channelId,
          mode,
          userInitiated,
          ...rest
        );
      }
      return comms.__bhfOrigSetPermissionMode(channelId, mode, userInitiated, ...rest);
    };
  }
  if (!comms.__bhfHookedLaunchClaude && typeof comms.launchClaude === 'function') {
    comms.__bhfHookedLaunchClaude = true;
    comms.__bhfOrigLaunchClaude = comms.launchClaude.bind(comms);
    comms.launchClaude = function (channelId, sessionId, cwdOrOpts, permissionMode, ...rest) {
      if (typeof state.__bhfOnCommsLaunchClaude === 'function') {
        return state.__bhfOnCommsLaunchClaude(
          state,
          comms,
          channelId,
          sessionId,
          cwdOrOpts,
          permissionMode,
          ...rest
        );
      }
      return comms.__bhfOrigLaunchClaude(
        channelId,
        sessionId,
        cwdOrOpts,
        permissionMode,
        ...rest
      );
    };
  }
  if (!comms.__bhfHookedApplyTabIcon && typeof comms.applyTabIcon === 'function') {
    comms.__bhfHookedApplyTabIcon = true;
    const origApplyTabIcon = comms.applyTabIcon.bind(comms);
    comms.applyTabIcon = function (...args) {
      const res = origApplyTabIcon(...args);
      const pTab = this.panelTab || comms.__bhfPanel || panel;
      if (pTab) {
        pTab.__bhfBadgeState = null;
      }
      if (this.lastRenameTabFlags?.hasPendingPermissions === false) {
        const sid = resolveSessionIdForComms(state.controller, this, '', pTab);
        clearPendingBadgeIfIdle(state, sid, this, pTab);
      }
      return res;
    };
  }
  if (!comms.__bhfHookedRelayUsage && typeof comms.relayUsageWindows === 'function') {
    comms.__bhfHookedRelayUsage = true;
    const origRelayUsageWindows = comms.relayUsageWindows.bind(comms);
    comms.relayUsageWindows = function (usagePayload, ...rest) {
      if (usagePayload?.rate_limits && typeof usagePayload.rate_limits === 'object') {
        state.lastFullRateLimits = usagePayload.rate_limits;
        state.lastFullRateLimitsAt = Date.now();
        notifyActivityChanged({ type: 'claude-usage' });
      }
      return origRelayUsageWindows(usagePayload, ...rest);
    };
  }
  if (!comms.__bhfHookedSendRequest && typeof comms.sendRequest === 'function') {
    comms.__bhfHookedSendRequest = true;
    const origSendRequest = comms.sendRequest.bind(comms);
    comms.sendRequest = async function (channelId, request, signal) {
      const reqType = String(request?.type || '');
      if (
        request &&
        (reqType === 'tool_permission_request' ||
          reqType === 'user_dialog_request' ||
          reqType === 'engine_prompt_ask')
      ) {
        const permId = makeDraftId();
        const resolvedPanel =
          comms.__bhfPanel || findPanelForComms(state.controller, comms) || panel;
        const sessionId =
          resolveSessionIdForComms(state.controller, comms, channelId, resolvedPanel) ||
          String(request.sessionId || '');
        const beforeReqIds = new Set(
          comms.outstandingRequests instanceof Map ? comms.outstandingRequests.keys() : []
        );
        const reqPromise = origSendRequest(channelId, request, signal);
        let requestId = '';
        if (comms.outstandingRequests instanceof Map) {
          for (const k of comms.outstandingRequests.keys()) {
            if (!beforeReqIds.has(k)) {
              requestId = String(k);
              break;
            }
          }
        }
        const entry = {
          id: permId,
          requestId,
          requestType: reqType,
          provider: 'claude',
          sessionId,
          channelId: String(channelId || ''),
          toolName: String(request.toolName || request.dialogKind || 'Tool'),
          toolUseId: String(request.toolUseID || request.toolUseId || ''),
          inputs: request.inputs || request.payload || {},
          suggestions: Array.isArray(request.suggestions) ? request.suggestions : [],
          title: resolvedPanel?.title || 'Claude Code',
          createdAt: Date.now(),
          panel: resolvedPanel,
          comms
        };
        state.pendingPermissions.set(permId, entry);
        if (sessionId) {
          state.badgeById.set(sessionId, 'pending');
        }
        if (resolvedPanel) {
          applyPanelTabIcon(state, resolvedPanel, 'pending');
        }
        notifyActivityChanged({
          type: 'claude-permission',
          threadId: sessionId,
          permissionId: permId
        });
        try {
          return await reqPromise;
        } finally {
          state.pendingPermissions.delete(permId);
          const resolvedSid =
            sessionId ||
            resolveSessionIdForComms(state.controller, comms, channelId, resolvedPanel);
          clearPendingBadgeIfIdle(state, resolvedSid, comms, resolvedPanel);
          notifyActivityChanged({
            type: 'claude-permission-cleared',
            threadId: resolvedSid,
            permissionId: permId
          });
        }
      }
      return origSendRequest(channelId, request, signal);
    };
  }
}

function ensureCommsHooked(state, panel) {
  const { controller } = state;
  if (controller?.allComms instanceof Set) {
    for (const c of controller.allComms) {
      hookCommsObject(state, c, null);
    }
  }
  if (!controller?.panelComms || !panel) {
    return;
  }
  const comms = controller.panelComms.get(panel);
  if (comms) {
    hookCommsObject(state, comms, panel);
  }
}

function setOpeningClaudeTarget(state, { threadId = '', uriKey = '', durationMs = 1600 } = {}) {
  if (!state) {
    return 0;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = String(uriKey || '').trim();
  if (!cleanId && !cleanUri) {
    state.__bhfOpeningTarget = null;
    return Number(state.__bhfOpenSeq || 0);
  }
  const nextSeq = Number(state.__bhfOpenSeq || 0) + 1;
  state.__bhfOpenSeq = nextSeq;
  const now = Date.now();
  const prev =
    state.__bhfOpeningTarget && now < Number(state.__bhfOpeningTarget.until || 0)
      ? state.__bhfOpeningTarget
      : null;
  const outgoingThreadIds = new Set(prev?.outgoingThreadIds instanceof Set ? prev.outgoingThreadIds : []);
  const outgoingUriKeys = new Set(prev?.outgoingUriKeys instanceof Set ? prev.outgoingUriKeys : []);
  if (prev?.outgoingThreadId) outgoingThreadIds.add(prev.outgoingThreadId);
  if (prev?.outgoingUriKey) outgoingUriKeys.add(prev.outgoingUriKey);
  if (prev) {
    const sameAsPrev =
      (cleanId && prev.threadId === cleanId) || (cleanUri && prev.uriKey === cleanUri);
    if (!sameAsPrev) {
      if (prev.threadId) outgoingThreadIds.add(prev.threadId);
      if (prev.uriKey) outgoingUriKeys.add(prev.uriKey);
    }
  }
  let outgoingThreadId = '';
  let outgoingUriKey = '';
  if (state.controller?.panelComms instanceof Map) {
    for (const panel of state.controller.panelComms.keys()) {
      if (panel?.active) {
        const sid = findSessionIdForPanel(state.controller, panel);
        const pUri = String(panel.__bhfDraftUri || '').trim();
        if ((cleanId && sid && sid !== cleanId) || (cleanUri && pUri && pUri !== cleanUri)) {
          outgoingThreadId = sid;
          outgoingUriKey = pUri;
          if (sid) outgoingThreadIds.add(sid);
          if (pUri) outgoingUriKeys.add(pUri);
          break;
        }
      }
    }
  }
  if (cleanId) outgoingThreadIds.delete(cleanId);
  if (cleanUri) outgoingUriKeys.delete(cleanUri);
  state.__bhfOpeningTarget = {
    seq: nextSeq,
    threadId: cleanId,
    uriKey: cleanUri,
    outgoingThreadId,
    outgoingUriKey,
    outgoingThreadIds,
    outgoingUriKeys,
    setAt: now,
    until: now + Math.max(120, Number(durationMs) || 1600)
  };
  return nextSeq;
}

function isOpeningOtherClaudeTarget(state, { threadId = '', uriKey = '' } = {}) {
  const cur = state?.__bhfOpeningTarget;
  if (!cur) {
    return false;
  }
  if (Date.now() >= Number(cur.until || 0)) {
    state.__bhfOpeningTarget = null;
    return false;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = String(uriKey || '').trim();
  if ((cleanId && cur.threadId === cleanId) || (cleanUri && cur.uriKey === cleanUri)) {
    return false;
  }
  if (cleanId && cur.outgoingThreadIds instanceof Set && cur.outgoingThreadIds.has(cleanId)) {
    return true;
  }
  if (cleanUri && cur.outgoingUriKeys instanceof Set && cur.outgoingUriKeys.has(cleanUri)) {
    return true;
  }
  if (cur.outgoingThreadId || cur.outgoingUriKey) {
    return Boolean(
      (cur.outgoingThreadId && cleanId === cur.outgoingThreadId) ||
        (cur.outgoingUriKey && cleanUri === cur.outgoingUriKey)
    );
  }
  return false;
}

function clearOpeningClaudeTargetIfMatched(state, { threadId = '', uriKey = '' } = {}) {
  const cur = state?.__bhfOpeningTarget;
  if (!cur) {
    return;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = String(uriKey || '').trim();
  if ((cleanId && cur.threadId === cleanId) || (cleanUri && cur.uriKey === cleanUri)) {
    state.__bhfOpeningTarget = null;
  }
}

// A disposed WebviewPanel throws "Webview is disposed" from its viewColumn getter, and onDidDispose
// listeners run after disposal, so the close handler would throw before the sidebar heard of the
// close. Reads go through this helper: it remembers the last column seen and falls back to it.
function readPanelViewColumnSafe(panel, holder) {
  try {
    const col = panel?.viewColumn;
    if (col) {
      if (holder) holder.__bhfLastViewColumn = col;
      return col;
    }
  } catch {}
  return Number(holder?.__bhfLastViewColumn) || 1;
}

function attachClaudeFastCloseListener(state, panel) {
  if (!state || !panel || panel.__bhfFastCloseHooked) {
    return;
  }
  if (typeof panel.onDidDispose !== 'function') {
    return;
  }
  panel.__bhfFastCloseHooked = true;
  readPanelViewColumnSafe(panel, panel);
  try {
    panel.onDidChangeViewState?.(() => {
      readPanelViewColumnSafe(panel, panel);
    });
  } catch {}
  try {
    panel.onDidDispose(() => {
      const wasPrewarmed = Boolean(panel.__bhfPrewarmed);
      const wasEvictingPrewarm = Boolean(panel.__bhfEvictingPrewarm);
      panel.__bhfDisposed = true;
      const disposedViewCol = readPanelViewColumnSafe(panel, panel);
      const sessionId = findSessionIdForPanel(state.controller, panel) || panel.__bhfSessionId || '';
      if (sessionId) {
        removePersistedPrewarmClaudeId(state?.context?.workspaceState, sessionId).catch?.(() => {});
      }
      clearOpeningClaudeTargetIfMatched(state, {
        threadId: sessionId,
        uriKey: panel.__bhfDraftUri || ''
      });
      if (wasEvictingPrewarm) {
        recordPrewarmTelemetryEvicted(panel);
        return;
      }
      if (wasPrewarmed) {
        recordPrewarmTelemetryEvicted(panel);
        try {
          state.sidebarDelegate?.notePrewarmDismissed?.(sessionId || '');
        } catch {}
        return;
      }
      evictPrewarmedClaudeTabsInColumnIfOrphaned(state, disposedViewCol, {
        excludePanel: panel,
        excludeSessionId: sessionId
      });
      try {
        state.sidebarDelegate?.handleTabClosedFast?.({
          id: sessionId,
          key: panel.__bhfDraftUri || ''
        });
      } catch {}
    });
  } catch {}
}

function ensurePanelHooked(state, panel) {
  if (!panel) {
    return;
  }
  ensureCommsHooked(state, panel);
  attachClaudeFastCloseListener(state, panel);
  if (state.hookedPanels.has(panel)) {
    return;
  }
  state.hookedPanels.add(panel);
  if (!panel.__bhfDraftUri) {
    panel.__bhfDraftUri = `${CLAUDE_DRAFT_SCHEME}://draft/${makeDraftId()}`;
  }
  if (!panel.__bhfCreatedAt) {
    panel.__bhfCreatedAt = Date.now();
  }
  try {
    if (typeof panel.onDidChangeViewState === 'function') {
      panel.onDidChangeViewState(() => {
        if (isPrewarmGuardActive() && panel.__bhfPrewarmed) {
          return;
        }
        ensureCommsHooked(state, panel);
        const sessionId = findSessionIdForPanel(state.controller, panel);
        const pUri = panel.__bhfDraftUri || '';
        if (panel.active) {
          if (isOpeningOtherClaudeTarget(state, { threadId: sessionId, uriKey: pUri })) {
            return;
          }
          clearOpeningClaudeTargetIfMatched(state, { threadId: sessionId, uriKey: pUri });
          if (panel.__bhfPrewarmed) {
            const panelCol = panel.viewColumn || 1;
            if (
              state.vscode?.window?.state?.focused === false ||
              !hasNonPrewarmedTabInClaudeColumn(state, panelCol, {
                excludePanel: panel,
                excludeSessionId: sessionId || panel.__bhfSessionId || ''
              })
            ) {
              evictPrewarmedClaudePanel(state, panel);
              return;
            }
            promotePrewarmedClaudePanel(state, panel, { notify: false });
          }
          if (sessionId && !panel.__bhfPrewarmed) {
            applyPanelTabIcon(state, panel, 'plain');
            notifyThreadSeen(sessionId);
          }
        }
        if (panel.__bhfPrewarmed) {
          return;
        }
        notifyActivityChanged({
          type: 'tab-state',
          threadId: sessionId,
          uri: pUri,
          active: Boolean(panel.active)
        });
      });
    }
  } catch {}
  try {
    if (typeof panel.onDidDispose === 'function') {
      panel.onDidDispose(() => {
        const sessionId = findSessionIdForPanel(state.controller, panel);
        for (const [permId, perm] of state.pendingPermissions.entries()) {
          if (perm.panel === panel) {
            state.pendingPermissions.delete(permId);
          }
        }
        if (panel.__bhfPrewarmed || panel.__bhfEvictingPrewarm) {
          return;
        }
        notifyActivityChanged({
          type: 'tab-closed',
          threadId: sessionId,
          uri: panel.__bhfDraftUri || ''
        });
      });
    }
  } catch {}
}

function getClaudeActiveGroupInfoByColumn(vscode) {
  const byColumn = new Map();
  const groups = Array.isArray(vscode?.window?.tabGroups?.all) ? vscode.window.tabGroups.all : [];
  const activeGroup =
    vscode?.window?.tabGroups?.activeTabGroup ||
    groups.find((g) => Boolean(g?.isActive)) ||
    (groups.length === 1 ? groups[0] : null);
  for (const group of groups) {
    const tabs = Array.isArray(group?.tabs) ? group.tabs : [];
    const activeTab = group?.activeTab || tabs.find((t) => Boolean(t?.isActive)) || null;
    if (!activeTab) {
      continue;
    }
    const col = group.viewColumn || 1;
    const viewType = String(activeTab?.input?.viewType || '');
    const isClaudePanel = viewType.includes('claudeVSCodePanel');
    const groupActive = Boolean(activeGroup ? group === activeGroup : group?.isActive);
    byColumn.set(col, {
      groupActive,
      hasNonClaudeActiveTab: !isClaudePanel,
      activeTabLabel: isClaudePanel ? String(activeTab.label || '') : ''
    });
  }
  return byColumn;
}

function getOpenClaudeTabsSnapshot() {
  const state = getBridgeState();
  const { controller, vscode } = state;
  const result = [];
  const seenPanels = new Set();
  const seenSessionIds = new Set();
  const groups = Array.isArray(vscode?.window?.tabGroups?.all) ? vscode.window.tabGroups.all : [];
  const hasTabGroups = groups.length > 0;
  const claudeTabCountByCol = new Map();
  if (hasTabGroups) {
    for (const group of groups) {
      const col = group.viewColumn || 1;
      let count = claudeTabCountByCol.get(col) || 0;
      for (const tab of group?.tabs || []) {
        if (String(tab?.input?.viewType || '').includes('claudeVSCodePanel')) {
          count += 1;
        }
      }
      claudeTabCountByCol.set(col, count);
    }
  }
  const nowMs = Date.now();
  const isPanelClosedInTabGroups = (panel, col) => {
    if (panel.__bhfDisposed) return true;
    const colCount = claudeTabCountByCol.get(col) || 0;
    if (colCount > 0) {
      panel.__bhfSeenInTabGroups = true;
      return false;
    }
    if (!hasTabGroups) return false;
    if (!(panel.__bhfSeenInTabGroups || Boolean(vscode?.version))) return false;
    return nowMs - Number(panel.__bhfCreatedAt || 0) >= 450;
  };
  const activeGroupByColumn = getClaudeActiveGroupInfoByColumn(vscode);
  let activeClaudeCol = null;
  let activeClaudeLabel = '';
  for (const [col, info] of activeGroupByColumn.entries()) {
    if (info.groupActive && !info.hasNonClaudeActiveTab) {
      activeClaudeCol = col;
      activeClaudeLabel = info.activeTabLabel || '';
      break;
    }
  }

  if (controller?.sessionPanels instanceof Map) {
    for (const [sessionId, panel] of controller.sessionPanels.entries()) {
      if (!panel) {
        continue;
      }
      ensurePanelHooked(state, panel);
      const viewColumn = panel.viewColumn || 1;
      if (isPanelClosedInTabGroups(panel, viewColumn)) {
        continue;
      }
      seenPanels.add(panel);
      const cleanId = String(sessionId || '').trim();
      if (isPrewarmGuardActive() && cleanId && state.__bhfPendingPrewarmSessionIds?.has(cleanId)) {
        seenPanels.add(panel);
        continue;
      }
      let isActive = Boolean(panel.active);
      if (hasTabGroups) {
        const colInfo = activeGroupByColumn.get(viewColumn);
        if (!colInfo || !colInfo.groupActive || colInfo.hasNonClaudeActiveTab) {
          isActive = false;
        }
      }
      if (panel.__bhfPrewarmed) {
        if (!isPrewarmGuardActive() && isActive) {
          if (
            vscode?.window?.state?.focused === false ||
            !hasNonPrewarmedTabInClaudeColumn(state, viewColumn, {
              excludePanel: panel,
              excludeSessionId: cleanId
            })
          ) {
            evictPrewarmedClaudePanel(state, panel);
            continue;
          }
          promotePrewarmedClaudePanel(state, panel, { notify: true });
        } else {
          continue;
        }
      }
      if (cleanId) {
        seenSessionIds.add(cleanId);
      }
      result.push({
        uri: panel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${cleanId}`,
        id: cleanId,
        provider: 'claude',
        title: panel.title || 'Claude Code',
        active: isActive,
        visible: Boolean(panel.visible),
        viewColumn,
        hydrated: true
      });
    }
  }

  if (controller?.panelComms instanceof Map) {
    for (const panel of controller.panelComms.keys()) {
      if (!panel || seenPanels.has(panel)) {
        continue;
      }
      ensurePanelHooked(state, panel);
      const viewColumn = panel.viewColumn || 1;
      if (isPanelClosedInTabGroups(panel, viewColumn)) {
        continue;
      }
      seenPanels.add(panel);
      if (panel.__bhfPrewarmed) {
        continue;
      }
      let isActive = Boolean(panel.active);
      if (hasTabGroups) {
        const colInfo = activeGroupByColumn.get(viewColumn);
        if (!colInfo || !colInfo.groupActive || colInfo.hasNonClaudeActiveTab) {
          isActive = false;
        }
      }
      result.push({
        uri: panel.__bhfDraftUri,
        id: '',
        provider: 'claude',
        title: panel.title || 'New Claude session',
        active: isActive,
        visible: Boolean(panel.visible),
        viewColumn,
        createdAt: Number(panel.__bhfCreatedAt || 0)
      });
    }
  }

  // Promote active Claude panel when workbench focus is in THEO Sidebar / Terminal
  if (activeClaudeCol !== null && !result.some((r) => r.active)) {
    const visibleInCol = result.filter((r) => r.visible && r.viewColumn === activeClaudeCol);
    const labelMatched = activeClaudeLabel
      ? visibleInCol.find((r) => r.title === activeClaudeLabel) ||
        result.find((r) => r.viewColumn === activeClaudeCol && r.title === activeClaudeLabel)
      : null;
    let ctrlActiveSid = '';
    try {
      ctrlActiveSid = String(
        controller?.activePanelSessionId?.() || controller?.activeSessionId || ''
      ).trim();
    } catch {}
    const sidMatched = ctrlActiveSid
      ? visibleInCol.find((r) => r.id === ctrlActiveSid) ||
        result.find((r) => r.viewColumn === activeClaudeCol && r.id === ctrlActiveSid)
      : null;
    const promoted =
      labelMatched || sidMatched || (visibleInCol.length === 1 ? visibleInCol[0] : null);
    if (promoted) {
      promoted.active = true;
      promoted.visible = true;
    }
  }

  // Also include un-revived remembered tabs from VS Code restart
  const persistedPrewarmIds = new Set(readPersistedPrewarmClaudeIds(state?.context?.workspaceState));
  const remembered = Array.isArray(controller?.rememberedTabSessions)
    ? controller.rememberedTabSessions
    : [];
  if (remembered.length > 0) {
    const activeTabLabels = new Set();
    if (activeClaudeCol !== null && activeClaudeLabel && !result.some((r) => r.active)) {
      activeTabLabels.add(activeClaudeLabel);
    }
    for (const rem of remembered) {
      const cleanId = String(rem?.sessionId || '').trim();
      if (
        !cleanId ||
        seenSessionIds.has(cleanId) ||
        persistedPrewarmIds.has(cleanId) ||
        state.__bhfPendingPrewarmSessionIds?.has?.(cleanId) ||
        state.__bhfEvictedStartupPrewarmClaudeIds?.has?.(cleanId) ||
        controller?.sessionPanels?.get?.(cleanId)?.__bhfPrewarmed
      ) {
        continue;
      }
      seenSessionIds.add(cleanId);
      const isRemActive = Boolean(rem.title && activeTabLabels.has(rem.title));
      result.push({
        uri: `${CLAUDE_DRAFT_SCHEME}://remembered/${cleanId}`,
        id: cleanId,
        provider: 'claude',
        title: rem.title || 'Claude Code',
        active: isRemActive,
        visible: isRemActive,
        viewColumn: activeClaudeCol || 1,
        hydrated: false
      });
    }
  }

  return result;
}

function getPendingPermissionsSnapshot() {
  const state = getBridgeState();
  const out = [];
  for (const [id, entry] of state.pendingPermissions.entries()) {
    const resolvedPanel = entry.panel || findPanelForComms(state.controller, entry.comms);
    const resolvedSessionId =
      entry.sessionId ||
      resolveSessionIdForComms(state.controller, entry.comms, entry.channelId, resolvedPanel) ||
      '';
    out.push({
      id,
      requestId: entry.requestId || '',
      requestType: entry.requestType || 'tool_permission_request',
      provider: 'claude',
      sessionId: resolvedSessionId,
      channelId: entry.channelId || '',
      toolName: entry.toolName || 'Tool',
      toolUseId: entry.toolUseId || '',
      inputs: entry.inputs || {},
      suggestions: Array.isArray(entry.suggestions) ? entry.suggestions : [],
      title: resolvedPanel?.title || entry.title || 'Claude Code',
      createdAt: entry.createdAt
    });
  }
  return out;
}

function getLiveSnapshot() {
  const state = getBridgeState();
  const { controller } = state;
  const sessionStates = [];
  const seenStateIds = new Set();

  const outstandingSessionIds = new Set();
  const allCommsList = [];
  if (controller?.allComms instanceof Set) {
    for (const c of controller.allComms) {
      if (c && !allCommsList.includes(c)) allCommsList.push(c);
    }
  }
  if (controller?.panelComms instanceof Map) {
    for (const [panel, c] of controller.panelComms.entries()) {
      if (c) {
        c.__bhfPanel = panel;
        if (!allCommsList.includes(c)) allCommsList.push(c);
      }
    }
  }
  for (const c of allCommsList) {
    hookCommsObject(state, c, c.__bhfPanel || null);
  }
  if (state.pendingPermissions instanceof Map) {
    for (const entry of state.pendingPermissions.values()) {
      if (!entry) continue;
      const sid =
        entry.sessionId ||
        resolveSessionIdForComms(controller, entry.comms, entry.channelId, entry.panel);
      if (sid) {
        outstandingSessionIds.add(sid);
      }
    }
  }

  if (controller?.sessionStates instanceof Map) {
    for (const [id, entry] of controller.sessionStates.entries()) {
      const info = entry?.info || entry || {};
      const cleanSid = String(info.sessionId || id || '');
      const hasOutstanding = Boolean(cleanSid && outstandingSessionIds.has(cleanSid));
      if (cleanSid) seenStateIds.add(cleanSid);
      sessionStates.push({
        sessionId: cleanSid,
        state: hasOutstanding ? 'waiting_input' : String(info.state || 'idle'),
        hasOutstandingRequest: hasOutstanding,
        title: String(info.title || '')
      });
    }
  }
  for (const sid of outstandingSessionIds) {
    if (!seenStateIds.has(sid)) {
      const panel = controller?.sessionPanels?.get?.(sid);
      sessionStates.push({
        sessionId: sid,
        state: 'waiting_input',
        hasOutstandingRequest: true,
        title: String(panel?.title || '')
      });
    }
  }

  const liveElsewhere = Array.isArray(controller?.liveElsewhereSessions)
    ? controller.liveElsewhereSessions.map((item) => ({
        sessionId: String(item?.sessionId || ''),
        pid: item?.pid || 0,
        cwd: item?.cwd || ''
      }))
    : [];

  try {
    controller?.refreshUnreadFromStore?.();
  } catch {}
  const unreadIds =
    controller?.unreadSessionKeys instanceof Set
      ? Array.from(controller.unreadSessionKeys)
      : [];

  let activeSessionId = '';
  try {
    activeSessionId =
      controller?.activePanelSessionId?.() || controller?.activeSessionId || '';
  } catch {}

  if (controller?.allComms instanceof Set) {
    for (const c of controller.allComms) {
      hookCommsObject(state, c, null);
    }
  }

  const rawRateLimitWindows =
    controller?.panelUsageRelay?.merged || state.lastRateLimitWindows || null;
  let rateLimitWindows = rawRateLimitWindows;
  const nowSec = Math.floor(Date.now() / 1000);
  let hasExpiredRelayWindow = false;
  if (rawRateLimitWindows && typeof rawRateLimitWindows === 'object') {
    rateLimitWindows = { ...rawRateLimitWindows };
    for (const [k, v] of Object.entries(rateLimitWindows)) {
      if (v && typeof v === 'object') {
        const rSec = Number(v.resetsAt || 0);
        if (rSec > 0 && rSec <= nowSec) {
          hasExpiredRelayWindow = true;
          rateLimitWindows[k] = { ...v, utilization: 0, resetsAt: undefined };
        }
      }
    }
  }

  if (hasExpiredRelayWindow && Date.now() - (state.lastProcessUsagePollAt || 0) > 180000) {
    state.lastProcessUsagePollAt = Date.now();
    try {
      const commsList =
        controller?.allComms instanceof Set
          ? Array.from(controller.allComms)
          : controller?.panelComms instanceof Map
            ? Array.from(controller.panelComms.values())
            : [];
      for (const c of commsList) {
        const ch = findActiveChannelEntry(c);
        if (ch?.entry?.query && typeof c.relayUsageWindowsFromProcess === 'function') {
          Promise.resolve(c.relayUsageWindowsFromProcess(ch.entry.query)).catch(() => {});
          break;
        }
      }
    } catch {}
  }

  let archivedIds = [];
  try {
    const rawArchived =
      controller?.settings?.getArchivedSessionIds?.() ??
      state.context?.globalState?.get?.('hiddenSessionIds');
    if (Array.isArray(rawArchived)) {
      archivedIds = rawArchived.filter(Boolean);
    }
  } catch {}

  let unarchivedAt = {};
  try {
    const rawUnarchived =
      controller?.settings?.getSessionUnarchiveTimes?.() ??
      state.context?.globalState?.get?.('sessionUnarchivedAt');
    if (rawUnarchived && typeof rawUnarchived === 'object') {
      unarchivedAt = { ...rawUnarchived };
    }
  } catch {}

  let autoArchiveDays = 14;
  try {
    if (typeof controller?.settings?.getAutoArchiveInactiveDays === 'function') {
      const days = controller.settings.getAutoArchiveInactiveDays();
      if (typeof days === 'number' && Number.isFinite(days)) {
        autoArchiveDays = days;
      }
    }
  } catch {}

  let sessionGroups = [];
  try {
    const rawGroups = controller?.settings?.getSessionGroups?.();
    if (Array.isArray(rawGroups)) {
      sessionGroups = rawGroups;
    }
  } catch {}

  return {
    active: true,
    openTabs: getOpenClaudeTabsSnapshot(),
    sessionStates,
    liveElsewhere,
    unreadIds,
    archivedIds,
    unarchivedAt,
    autoArchiveDays,
    sessionGroups,
    activeSessionId,
    rateLimitWindows,
    fullRateLimits: state.lastFullRateLimits || null,
    fullRateLimitsAt: state.lastFullRateLimitsAt || 0,
    pendingPermissions: getPendingPermissionsSnapshot()
  };
}

function resolveTargetColumn(vscode, options = {}) {
  if (typeof options.viewColumn === 'number') {
    return options.viewColumn;
  }
  if (options.beside) {
    return vscode.ViewColumn.Beside;
  }
  if (options.prewarm) {
    const activeCol = vscode?.window?.tabGroups?.activeTabGroup?.viewColumn;
    if (typeof activeCol === 'number') {
      return activeCol;
    }
  }
  return vscode.ViewColumn.One;
}

async function openClaudeTab(options = {}) {
  const state = options.state || getBridgeState();
  const { vscode, controller } = state;
  if (!vscode || !controller) {
    return null;
  }

  const isPrewarm = Boolean(options.prewarm);
  const viewColumn = resolveTargetColumn(vscode, options);
  const preserveFocus = isPrewarm ? true : Boolean(options.preserveFocus);
  const beside = Boolean(options.beside);
  const wantForeground = !preserveFocus && !beside;

  // 1. Focus an open draft Claude tab by its draft URI
  const draftUri = String(options.draftUri || options.key || '').trim();
  if (draftUri && draftUri.startsWith(`${CLAUDE_DRAFT_SCHEME}://draft/`)) {
    if (isPrewarm) {
      return null;
    }
    if (controller.panelComms instanceof Map) {
      for (const panel of controller.panelComms.keys()) {
        if (panel && panel.__bhfDraftUri === draftUri) {
          if (wantForeground) {
            setOpeningClaudeTarget(state, { uriKey: draftUri });
          }
          panel.reveal(
            beside ? vscode.ViewColumn.Beside : panel.viewColumn || viewColumn,
            preserveFocus
          );
          notifyActivityChanged({
            type: wantForeground ? 'reveal-draft' : 'reveal-draft-bg',
            uri: draftUri,
            preserveFocus,
            beside
          });
          return { uri: draftUri, id: '', provider: 'claude', revealed: true };
        }
      }
    }
  }
  let uriSessionId = '';
  if (draftUri) {
    const mUri = draftUri.match(
      /^(?:claude-session|claude-draft|claude):\/\/(?:session|remembered)\/([^/?#]+)/i
    );
    if (mUri && mUri[1]) {
      try {
        uriSessionId = decodeURIComponent(mUri[1]).trim();
      } catch {
        uriSessionId = mUri[1].trim();
      }
    }
  }

  // 2. Open a new blank Claude session tab
  const sessionId = String(options.id || options.threadId || uriSessionId || '').trim();
  if (options.newSession || !sessionId) {
    if (isPrewarm) {
      return null;
    }
    const pendingDraftUri = `${CLAUDE_DRAFT_SCHEME}://draft/${makeDraftId()}`;
    const openSeq = wantForeground ? setOpeningClaudeTarget(state, { uriKey: pendingDraftUri }) : 0;
    const res = await controller.createPanel(
      undefined,
      options.initialPrompt,
      viewColumn,
      undefined,
      true,
      !preserveFocus,
      preserveFocus,
      false
    );
    const panel = res?.createdPanel;
    if (panel) {
      if (!panel.__bhfDraftUri) {
        panel.__bhfDraftUri = pendingDraftUri;
      }
      ensurePanelHooked(state, panel);
    }
    const uri = panel?.__bhfDraftUri || pendingDraftUri;
    const isSuperseded = Boolean(openSeq && state.__bhfOpenSeq !== openSeq);
    notifyActivityChanged({
      type: !wantForeground || isSuperseded ? 'open-new-bg' : 'open-new',
      uri,
      preserveFocus: Boolean(preserveFocus || isSuperseded),
      beside
    });
    return { uri, id: '', provider: 'claude', draft: true, panel };
  }

  if (
    options.claudeDesktopScratch ||
    isClaudeDesktopScratchSessionSync(sessionId, state.vscode, state)
  ) {
    return null;
  }

  if (isPrewarm && (beside || options.initialPrompt)) {
    return null;
  }

  const openSeq = wantForeground ? setOpeningClaudeTarget(state, { threadId: sessionId }) : 0;

  // 3. Reveal or open an existing Claude session tab
  const existingPanel = controller.sessionPanels?.get?.(sessionId);
  if (existingPanel) {
    if (isPrewarm) {
      return {
        uri: existingPanel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
        id: sessionId,
        provider: 'claude',
        alreadyOpen: true,
        prewarmed: Boolean(existingPanel.__bhfPrewarmed),
        panel: existingPanel
      };
    }
    promotePrewarmedClaudePanel(state, existingPanel, { notify: false });
    existingPanel.reveal(
      beside ? vscode.ViewColumn.Beside : existingPanel.viewColumn || viewColumn,
      preserveFocus
    );
    ensurePanelHooked(state, existingPanel);
    if (options.title && options.title !== 'Claude Code') {
      existingPanel.title = options.title;
    }
    if (wantForeground) {
      if (
        state.badgeById.get(sessionId) === 'done' ||
        existingPanel.__bhfBadgeState === 'done'
      ) {
        applyPanelTabIcon(state, existingPanel, 'plain');
      }
      notifyThreadSeen(sessionId);
    }
    const isSuperseded = Boolean(openSeq && state.__bhfOpenSeq !== openSeq);
    notifyActivityChanged({
      type: !wantForeground || isSuperseded ? 'reveal-bg' : 'reveal',
      threadId: sessionId,
      preserveFocus: Boolean(preserveFocus || isSuperseded),
      beside
    });
    return {
      uri: existingPanel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
      id: sessionId,
      provider: 'claude',
      revealed: true,
      panel: existingPanel
    };
  }

  if (isPrewarm) {
    if (state.__bhfPendingPrewarmSessionIds?.has?.(sessionId)) {
      return {
        uri: `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
        id: sessionId,
        provider: 'claude',
        alreadyOpen: true,
        prewarmed: true
      };
    }
    if (
      Array.isArray(controller.rememberedTabSessions) &&
      controller.rememberedTabSessions.some((rem) => String(rem?.sessionId || '').trim() === sessionId)
    ) {
      return null;
    }
    const activeTabSnap = captureActiveTabInColumn(vscode, viewColumn);
    if (!activeTabSnap) {
      return null;
    }
    if (!(state.__bhfPendingPrewarmSessionIds instanceof Set)) {
      state.__bhfPendingPrewarmSessionIds = new Set();
    }
    state.__bhfPendingPrewarmSessionIds.add(sessionId);
    let createdPanel = null;
    await withPrewarmGuard(async () => {
      try {
        const res = await controller.createPanel(
          sessionId,
          undefined,
          viewColumn,
          undefined,
          true,
          false,
          true,
          false
        );
        createdPanel = res?.createdPanel || controller.sessionPanels?.get?.(sessionId) || null;
        if (createdPanel) {
          createdPanel.__bhfSessionId = sessionId;
          createdPanel.__bhfPrewarmed = true;
          createdPanel.__bhfPrewarmedAt = Date.now();
          createdPanel.__bhfEvictingPrewarm = false;
          recordPrewarmTelemetryWarmed(createdPanel);
          ensurePanelHooked(state, createdPanel);
          if (options.title && options.title !== 'Claude Code') {
            createdPanel.title = options.title;
          }
        }
      } finally {
        state.__bhfPendingPrewarmSessionIds?.delete?.(sessionId);
        await restoreActiveTabInColumn(state, activeTabSnap);
      }
    });
    if (createdPanel) {
      await recordPersistedPrewarmClaudeId(state.context?.workspaceState, sessionId).catch(() => {});
    }
    return createdPanel
      ? {
          uri: createdPanel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
          id: sessionId,
          provider: 'claude',
          prewarmed: true,
          panel: createdPanel
        }
      : null;
  }

  if (sessionId) {
    state.__bhfPendingPrewarmSessionIds?.delete?.(sessionId);
    state.__bhfEvictedStartupPrewarmClaudeIds?.delete?.(sessionId);
    await removePersistedPrewarmClaudeId(state.context?.workspaceState, sessionId).catch?.(() => {});
  }

  if (wantForeground) {
    notifyThreadSeen(sessionId);
  }
  if (
    !options.initialPrompt &&
    !beside &&
    typeof controller.revealRememberedTab === 'function' &&
    Array.isArray(controller.rememberedTabSessions)
  ) {
    const matchedRemembered = controller.rememberedTabSessions.find(
      (rem) => String(rem?.sessionId || '').trim() === sessionId
    );
    if (matchedRemembered) {
      try {
        await controller.revealRememberedTab(matchedRemembered);
        const revivedPanel = controller.sessionPanels?.get?.(sessionId);
        if (revivedPanel) {
          if (!revivedPanel.__bhfPrewarmed) {
            recordPrewarmTelemetryColdOpen(revivedPanel);
          } else {
            promotePrewarmedClaudePanel(state, revivedPanel, { notify: false });
          }
          ensurePanelHooked(state, revivedPanel);
          if (options.title && options.title !== 'Claude Code') {
            revivedPanel.title = options.title;
          }
          const isSuperseded = Boolean(openSeq && state.__bhfOpenSeq !== openSeq);
          notifyActivityChanged({
            type: !wantForeground || isSuperseded ? 'reveal-bg' : 'reveal',
            threadId: sessionId,
            preserveFocus: Boolean(preserveFocus || isSuperseded),
            beside
          });
          return {
            uri: revivedPanel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
            id: sessionId,
            provider: 'claude',
            revealed: true,
            panel: revivedPanel
          };
        }
      } catch {}
    }
  }
  const res = await controller.createPanel(
    sessionId,
    options.initialPrompt,
    viewColumn,
    undefined,
    true,
    !preserveFocus,
    preserveFocus,
    !options.initialPrompt
  );
  const createdPanel = res?.createdPanel || controller.sessionPanels?.get?.(sessionId);
  if (createdPanel) {
    if (!createdPanel.__bhfPrewarmed) {
      recordPrewarmTelemetryColdOpen(createdPanel);
    }
    promotePrewarmedClaudePanel(state, createdPanel, { notify: false });
    ensurePanelHooked(state, createdPanel);
    if (options.title && options.title !== 'Claude Code') {
      createdPanel.title = options.title;
    }
  }
  const isSuperseded = Boolean(openSeq && state.__bhfOpenSeq !== openSeq);
  notifyActivityChanged({
    type: !wantForeground || isSuperseded ? 'open-thread-bg' : 'open-thread',
    threadId: sessionId,
    preserveFocus: Boolean(preserveFocus || isSuperseded),
    beside
  });
  return {
    uri: createdPanel?.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${sessionId}`,
    id: sessionId,
    provider: 'claude',
    revealed: false,
    panel: createdPanel || null
  };
}

function getPrewarmedClaudeTabsSnapshot() {
  const state = getBridgeState();
  const { controller } = state;
  const out = [];
  if (controller?.sessionPanels instanceof Map) {
    for (const [sessionId, panel] of controller.sessionPanels.entries()) {
      if (!panel || panel.__bhfDisposed || !panel.__bhfPrewarmed) {
        continue;
      }
      const cleanId = String(sessionId || '').trim();
      out.push({
        uri: panel.__bhfDraftUri || `${CLAUDE_DRAFT_SCHEME}://session/${cleanId}`,
        id: cleanId,
        provider: 'claude',
        title: panel.title || 'Claude Code',
        createdAt: Number(panel.__bhfPrewarmedAt || panel.__bhfCreatedAt || 0)
      });
    }
  }
  return out;
}

async function closeClaudeTab(options = {}) {
  const state = getBridgeState();
  const { controller } = state;
  if (!controller) {
    return false;
  }
  const sessionId = String(options.id || options.threadId || '').trim();
  const draftUri = String(options.uri || options.key || '').trim();
  const onlyPrewarmed = Boolean(options.onlyPrewarmed);
  let closed = false;

  if (sessionId && controller.sessionPanels instanceof Map) {
    const panel = controller.sessionPanels.get(sessionId);
    if (panel && (!onlyPrewarmed || panel.__bhfPrewarmed)) {
      if (panel.__bhfPrewarmed) {
        recordPrewarmTelemetryEvicted(panel);
        panel.__bhfEvictingPrewarm = true;
        removePersistedPrewarmClaudeId(state.context?.workspaceState, sessionId).catch?.(() => {});
        stripSessionFromRememberedTabs(controller, sessionId);
      }
      try {
        panel.dispose();
        closed = true;
      } catch {}
    }
  }

  if (!closed && draftUri && controller.panelComms instanceof Map) {
    for (const panel of Array.from(controller.panelComms.keys())) {
      if (panel && panel.__bhfDraftUri === draftUri && (!onlyPrewarmed || panel.__bhfPrewarmed)) {
        if (panel.__bhfPrewarmed) {
          recordPrewarmTelemetryEvicted(panel);
          panel.__bhfEvictingPrewarm = true;
          const sid = findSessionIdForPanel(controller, panel) || panel.__bhfSessionId || sessionId;
          if (sid) {
            removePersistedPrewarmClaudeId(state.context?.workspaceState, sid).catch?.(() => {});
            stripSessionFromRememberedTabs(controller, sid);
          }
        }
        try {
          panel.dispose();
          closed = true;
        } catch {}
      }
    }
  }

  let matchedRem = null;
  if (!onlyPrewarmed && sessionId && Array.isArray(controller.rememberedTabSessions)) {
    matchedRem =
      controller.rememberedTabSessions.find(
        (rem) => String(rem?.sessionId || '').trim() === sessionId
      ) || null;
  }
  if (!onlyPrewarmed && sessionId) {
    const beforeRemLen = Array.isArray(controller.rememberedTabSessions)
      ? controller.rememberedTabSessions.length
      : 0;
    stripSessionFromRememberedTabs(controller, sessionId);
    const afterRemLen = Array.isArray(controller.rememberedTabSessions)
      ? controller.rememberedTabSessions.length
      : 0;
    if (afterRemLen < beforeRemLen) {
      closed = true;
    }
  }
  if (!onlyPrewarmed && matchedRem && state.vscode?.window?.tabGroups?.close) {
    const remTitle = String(matchedRem.title || options.title || '').trim();
    const groups = Array.isArray(state.vscode.window.tabGroups.all)
      ? state.vscode.window.tabGroups.all
      : [];
    const livePanels = getAllClaudeLivePanels(state);
    const liveTitleCounts = new Map();
    for (const item of livePanels) {
      const t = String(item?.panel?.title || '').trim();
      if (t) liveTitleCounts.set(t, (liveTitleCounts.get(t) || 0) + 1);
    }
    if (remTitle) {
      for (const group of groups) {
        if (matchedRem.viewColumn != null && (group?.viewColumn || 1) !== matchedRem.viewColumn) {
          continue;
        }
        for (const tab of group?.tabs || []) {
          const viewType = String(tab?.input?.viewType || '');
          if (!viewType.includes('claudeVSCodePanel')) continue;
          if (String(tab?.label || '').trim() !== remTitle) continue;
          const liveCount = liveTitleCounts.get(remTitle) || 0;
          if (liveCount > 0) {
            liveTitleCounts.set(remTitle, liveCount - 1);
            continue;
          }
          try {
            await state.vscode.window.tabGroups.close(tab);
            closed = true;
          } catch {}
          return closed;
        }
      }
    }
  }

  return closed;
}

function syncClaudeTabBadges(badgesById = {}) {
  const state = getBridgeState();
  const { controller } = state;
  if (!controller?.sessionPanels || !badgesById || typeof badgesById !== 'object') {
    return false;
  }
  let changed = false;
  for (const [id, badge] of Object.entries(badgesById)) {
    if (id && TAB_ICON_FILES[badge]) {
      state.badgeById.set(id, badge);
    }
  }
  for (const [sessionId, panel] of controller.sessionPanels.entries()) {
    if (!panel) {
      continue;
    }
    let targetBadge =
      badgesById[sessionId] || state.badgeById.get(sessionId) || 'plain';
    if (targetBadge === 'done' && panel.active) {
      targetBadge = 'plain';
      state.badgeById.set(sessionId, 'plain');
    }
    if (applyPanelTabIcon(state, panel, targetBadge)) {
      changed = true;
    }
  }
  return changed;
}

async function reviveRememberedClaudeTabs(state) {
  const { controller, vscode } = state || getBridgeState();
  if (!controller || !vscode || state.revivingRememberedTabs) {
    return 0;
  }
  const persistedPrewarmIds = new Set(readPersistedPrewarmClaudeIds(state?.context?.workspaceState));
  const remembered = Array.isArray(controller.rememberedTabSessions)
    ? [...controller.rememberedTabSessions]
    : [];
  const toRevive = remembered.filter((rem) => {
    const sid = String(rem?.sessionId || '').trim();
    return (
      sid &&
      !rem?.claudeDesktopScratch &&
      !isClaudeDesktopScratchSessionSync(sid, vscode) &&
      !persistedPrewarmIds.has(sid) &&
      !state.pendingPrewarmSessionIds?.has?.(sid) &&
      !state.__bhfPendingPrewarmSessionIds?.has?.(sid) &&
      !state.__bhfEvictedStartupPrewarmClaudeIds?.has?.(sid) &&
      !controller.sessionPanels?.has?.(sid) &&
      !controller.tabRevivesInFlight?.has?.(sid) &&
      !state.revivedRememberedIds?.has?.(sid)
    );
  });
  if (toRevive.length === 0) {
    return 0;
  }

  if (!state.revivedRememberedIds) {
    state.revivedRememberedIds = new Set();
  }
  state.revivingRememberedTabs = true;
  let revivedCount = 0;
  try {
    const activeGroup = vscode.window?.tabGroups?.activeTabGroup;
    const origActiveTab = activeGroup?.activeTab || null;
    const origGroupColumn = activeGroup?.viewColumn || 1;

    for (const rem of toRevive.slice(0, 2)) {
      const sid = String(rem?.sessionId || '').trim();
      if (
        !sid ||
        rem?.claudeDesktopScratch ||
        isClaudeDesktopScratchSessionSync(sid, vscode) ||
        controller.sessionPanels?.has?.(sid)
      ) {
        continue;
      }
      state.revivedRememberedIds.add(sid);
      try {
        if (typeof controller.revealRememberedTab === 'function') {
          await controller.revealRememberedTab(rem);
          revivedCount += 1;
        } else {
          await openClaudeTab({
            id: sid,
            title: String(rem?.title || '').trim(),
            preserveFocus: true
          });
          revivedCount += 1;
        }
      } catch {}
    }

    // Restore focus to whichever tab the user originally had active before revival
    if (origActiveTab) {
      try {
        const currentGroup =
          (vscode.window?.tabGroups?.all || []).find((g) => g.viewColumn === origGroupColumn) ||
          vscode.window?.tabGroups?.activeTabGroup;
        if (currentGroup && Array.isArray(currentGroup.tabs)) {
          const idx = currentGroup.tabs.indexOf(origActiveTab);
          if (idx >= 0 && !origActiveTab.isActive) {
            await vscode.commands.executeCommand('workbench.action.openEditorAtIndex', idx);
          }
        }
      } catch {}
    }
    notifyActivityChanged({ type: 'claude-revived-remembered-tabs' });
    return revivedCount;
  } finally {
    state.revivingRememberedTabs = false;
  }
}

function scheduleRememberedTabsRevival(state, delayMs = 1800) {
  if (state.reviveRememberedTimer) {
    clearTimeout(state.reviveRememberedTimer);
  }
  state.reviveRememberedTimer = setTimeout(() => {
    state.reviveRememberedTimer = null;
    reviveRememberedClaudeTabs(state).catch(() => {});
  }, delayMs);
}

function installControllerHooks(state) {
  const { controller, vscode } = state;
  if (!controller || controller.__bhfClaudeBridgePatched) {
    return;
  }
  controller.__bhfClaudeBridgePatched = true;

  // Ensure live process registry runs even when claudeVSCodeSessionsList is delegated or hidden
  try {
    const roots = vscode?.workspace?.workspaceFolders?.map((f) => f.uri.fsPath) || [];
    if (roots.length > 0 && typeof controller.startLiveRegistry === 'function') {
      controller.startLiveRegistry(roots[0]);
    } else {
      controller.liveRegistry?.start?.();
    }
  } catch {}

  // 1. Sidebar delegation for claudeVSCodeSessionsList
  if (typeof controller.resolveSessionListView === 'function') {
    state.origResolveSessionListView = controller.resolveSessionListView.bind(controller);
    controller.resolveSessionListView = async function (webviewView, resolveContext, token) {
      this.sessionListView = webviewView;
      state.sidebarView = webviewView;

      if (state.sidebarDelegate && typeof state.sidebarDelegate.resolveWebviewView === 'function') {
        return state.sidebarDelegate.resolveWebviewView(webviewView, resolveContext, token);
      }

      return new Promise((resolve) => {
        if (state.sidebarFallbackTimer) {
          clearTimeout(state.sidebarFallbackTimer);
        }
        state.sidebarFallbackTimer = setTimeout(async () => {
          state.sidebarFallbackTimer = null;
          if (
            state.sidebarDelegate &&
            typeof state.sidebarDelegate.resolveWebviewView === 'function'
          ) {
            resolve(
              await state.sidebarDelegate.resolveWebviewView(webviewView, resolveContext, token)
            );
          } else {
            resolve(await state.origResolveSessionListView(webviewView, resolveContext, token));
          }
        }, 4000);
      });
    };
  }

  // 2. Hook setupPanel to track open & draft panels and ensure reopenedAfterRestart is true when loading an existing session
  if (typeof controller.setupPanel === 'function') {
    const origSetupPanel = controller.setupPanel.bind(controller);
    controller.setupPanel = function (
      panel,
      sessionId,
      initialPrompt,
      fullEditor,
      focusInput,
      reopenedAfterRestart,
      ...rest
    ) {
      const prewarmTagged = markPanelAsPrewarmedIfPending(state, sessionId, panel);
      ensurePanelHooked(state, panel);
      const effectiveReopened =
        reopenedAfterRestart !== undefined
          ? reopenedAfterRestart
          : Boolean(sessionId && !initialPrompt);
      const res = origSetupPanel(
        panel,
        sessionId,
        initialPrompt,
        fullEditor,
        focusInput,
        effectiveReopened,
        ...rest
      );
      markPanelAsPrewarmedIfPending(state, sessionId, panel);
      ensurePanelHooked(state, panel);
      setTimeout(() => {
        syncSharedClaudePermissionMode(state).catch(() => {});
      }, 200);
      if (!prewarmTagged && !isPendingClaudePrewarm(state, sessionId, panel)) {
        notifyActivityChanged({
          type: 'claude-setup-panel',
          threadId: String(sessionId || ''),
          uri: panel?.__bhfDraftUri || ''
        });
      }
      return res;
    };
  }

  // 3. Hook registerPanelSession so draft tabs smoothly bind to their Claude sessionId
  if (typeof controller.registerPanelSession === 'function') {
    const origRegisterPanelSession = controller.registerPanelSession.bind(controller);
    controller.registerPanelSession = function (sessionId, panel, ...rest) {
      const prewarmTagged = markPanelAsPrewarmedIfPending(state, sessionId, panel);
      ensurePanelHooked(state, panel);
      const res = origRegisterPanelSession(sessionId, panel, ...rest);
      if (!prewarmTagged && !isPendingClaudePrewarm(state, sessionId, panel)) {
        notifyActivityChanged({
          type: 'claude-register-session',
          threadId: String(sessionId || ''),
          uri: panel?.__bhfDraftUri || ''
        });
      }
      return res;
    };
  }

  // 4. Hook createPanel so default viewColumn is ViewColumn.One (middle editor)
  if (typeof controller.createPanel === 'function') {
    const origCreatePanel = controller.createPanel.bind(controller);
    controller.createPanel = async function (
      sessionId,
      initialPrompt,
      viewColumn,
      groupId,
      fullEditor,
      focusInput,
      preserveFocus,
      reopenedAfterRestart
    ) {
      const targetColumn =
        viewColumn !== undefined ? viewColumn : vscode?.ViewColumn?.One || 1;
      const effectiveReopened =
        reopenedAfterRestart !== undefined
          ? reopenedAfterRestart
          : Boolean(sessionId && !initialPrompt);
      const res = await origCreatePanel(
        sessionId,
        initialPrompt,
        targetColumn,
        groupId,
        fullEditor,
        focusInput,
        preserveFocus,
        effectiveReopened
      );
      let prewarmTagged = false;
      if (res?.createdPanel) {
        prewarmTagged = markPanelAsPrewarmedIfPending(state, sessionId, res.createdPanel);
        ensurePanelHooked(state, res.createdPanel);
      }
      if (!prewarmTagged && !isPendingClaudePrewarm(state, sessionId, res?.createdPanel)) {
        notifyActivityChanged({
          type: 'claude-create-panel',
          threadId: String(sessionId || ''),
          uri: res?.createdPanel?.__bhfDraftUri || ''
        });
      }
      return res;
    };
  }

  // 5. Hook broadcastSessionStates
  if (typeof controller.broadcastSessionStates === 'function') {
    const origBroadcastStates = controller.broadcastSessionStates.bind(controller);
    controller.broadcastSessionStates = function (...args) {
      const res = origBroadcastStates(...args);
      notifyActivityChanged({ type: 'claude-states' });
      return res;
    };
  }

  // 6. Hook broadcastPanelUsage
  if (typeof controller.broadcastPanelUsage === 'function') {
    const origBroadcastUsage = controller.broadcastPanelUsage.bind(controller);
    controller.broadcastPanelUsage = function (windows, ...rest) {
      if (windows) {
        state.lastRateLimitWindows = windows;
      }
      const res = origBroadcastUsage(windows, ...rest);
      notifyActivityChanged({ type: 'claude-usage' });
      return res;
    };
  }

  // 7. Hook handleSessionRenamed
  if (typeof controller.handleSessionRenamed === 'function') {
    const origHandleRenamed = controller.handleSessionRenamed.bind(controller);
    controller.handleSessionRenamed = function (sessionId, title, sourceComms, skipCli) {
      const res = origHandleRenamed(sessionId, title, sourceComms, skipCli);
      const panel = this.sessionPanels?.get?.(sessionId);
      if (panel && title && panel.title !== title) {
        panel.title = title;
      }
      notifyActivityChanged({
        type: 'claude-renamed',
        threadId: String(sessionId || ''),
        title: String(title || '')
      });
      return res;
    };
  }

  // 8. Hook setSessionUnread
  if (typeof controller.setSessionUnread === 'function') {
    const origSetUnread = controller.setSessionUnread.bind(controller);
    controller.setSessionUnread = function (sessionId, unread) {
      const res = origSetUnread(sessionId, unread);
      notifyActivityChanged({
        type: 'claude-unread',
        threadId: String(sessionId || ''),
        unread: Boolean(unread)
      });
      return res;
    };
  }

  // 9. Hook broadcastSessionArchiveChanged
  if (typeof controller.broadcastSessionArchiveChanged === 'function') {
    const origBroadcastArchive = controller.broadcastSessionArchiveChanged.bind(controller);
    controller.broadcastSessionArchiveChanged = function (sourceComms, sessionIdOrIds, archived) {
      const res = origBroadcastArchive(sourceComms, sessionIdOrIds, archived);
      notifyActivityChanged({
        type: 'claude-archive',
        archived: Boolean(archived)
      });
      return res;
    };
  }

  // 10. Hook noteListedSessions so inferred background tabs after Reload Window are automatically revived
  if (typeof controller.noteListedSessions === 'function') {
    const origNoteListed = controller.noteListedSessions.bind(controller);
    controller.noteListedSessions = function (sessions, ...rest) {
      const res = origNoteListed(sessions, ...rest);
      scheduleRememberedTabsRevival(state, 1800);
      return res;
    };
  }

  // Hook any already-open panels
  if (controller.sessionPanels instanceof Map) {
    for (const panel of controller.sessionPanels.values()) {
      ensurePanelHooked(state, panel);
    }
  }
  if (controller.panelComms instanceof Map) {
    for (const panel of controller.panelComms.keys()) {
      ensurePanelHooked(state, panel);
    }
  }

  scheduleRememberedTabsRevival(state, 2200);
}

function findActiveChannelEntry(comms) {
  if (!comms) {
    return null;
  }
  if (comms.channels instanceof Map) {
    for (const [channelId, entry] of comms.channels.entries()) {
      return { channelId, entry };
    }
  }
  if (comms.pendingChannels instanceof Map) {
    for (const [channelId, entry] of comms.pendingChannels.entries()) {
      return { channelId, entry };
    }
  }
  return null;
}

function normalizeClaudePermissionModeInput(rawMode) {
  const clean = String(rawMode || '').trim();
  if (!clean) return '';
  if (clean === 'plan') return 'plan';
  if (clean === 'accept-edits' || clean === 'acceptEdits') return 'acceptEdits';
  if (
    clean === 'bypassPermissions' ||
    clean === 'bypass' ||
    clean === 'bypass-permissions'
  ) {
    return 'bypassPermissions';
  }
  if (clean === 'default' || clean === 'manual') return 'default';
  if (clean === 'auto') return 'auto';
  return '';
}

async function sendPromptToClaude(options = {}) {
  const state = options.state || getBridgeState();
  const { controller } = state;
  const promptText = String(options.prompt || options.text || '').trim();
  if (!promptText || !controller) {
    return { sent: false, error: 'Missing prompt or Claude controller' };
  }
  try {
    await syncSharedClaudePermissionMode(state);
  } catch {}
  const explicitMode = normalizeClaudePermissionModeInput(options.mode);
  const sharedMode = readSharedClaudePermissionMode(state.__bhfPermSyncOptions)?.mode || '';
  const desiredMode = explicitMode || sharedMode;
  const sessionId = String(options.id || options.threadId || '').trim();

  // Case 1: New session with initialPrompt
  if (options.newSession || !sessionId) {
    const pendingToken = desiredMode
      ? {
          mode: desiredMode,
          explicit: Boolean(explicitMode),
          until: Date.now() + 8000
        }
      : null;
    if (pendingToken) {
      state.__bhfPendingIdeLaunchMode = pendingToken;
    }
    let opened = null;
    try {
      opened = await openClaudeTab({
        state,
        newSession: true,
        initialPrompt: promptText,
        preserveFocus: Boolean(options.preserveFocus)
      });
    } finally {
      if (state.__bhfPendingIdeLaunchMode === pendingToken && (!opened || opened.panel || opened.revealed)) {
        state.__bhfPendingIdeLaunchMode = null;
      }
    }
    if (opened?.panel && desiredMode) {
      opened.panel.__bhfLaunchModeOverride = {
        mode: desiredMode,
        explicit: Boolean(explicitMode)
      };
      const pComms = controller.panelComms?.get?.(opened.panel);
      const activeCh = pComms ? findActiveChannelEntry(pComms) : null;
      if (pComms && activeCh?.channelId) {
        hookCommsObject(state, pComms, opened.panel);
        if (pComms.__bhfChannelModes.get(activeCh.channelId) !== desiredMode) {
          try {
            const setFn =
              pComms.__bhfOrigSetPermissionMode || pComms.setPermissionMode?.bind(pComms);
            const r = setFn ? await setFn(activeCh.channelId, desiredMode, false) : null;
            if (r && r.success !== false) {
              pComms.__bhfChannelModes.set(activeCh.channelId, desiredMode);
              if (explicitMode) {
                pComms.__bhfUserChosenChannelModes.set(activeCh.channelId, {
                  mode: desiredMode,
                  underSharedMode: sharedMode || desiredMode
                });
              }
              (pComms.__bhfOrigSend || pComms.send?.bind(pComms))?.({
                type: 'io_message',
                channelId: activeCh.channelId,
                message: { type: 'system', subtype: 'status', permissionMode: desiredMode },
                done: false
              });
            }
          } catch {}
        }
      }
    }
    let resolvedId = '';
    if (opened?.panel) {
      const deadline = Date.now() + 2200;
      while (Date.now() < deadline && !resolvedId) {
        resolvedId = findSessionIdForPanel(controller, opened.panel);
        if (!resolvedId) {
          await new Promise((r) => setTimeout(r, 100));
        }
      }
    }
    return {
      sent: Boolean(opened),
      method: 'createPanel-new',
      id: resolvedId,
      sessionId: resolvedId,
      opened: opened
        ? {
            uri: opened.uri,
            id: resolvedId,
            provider: 'claude',
            draft: true
          }
        : null
    };
  }

  // Case 2: Existing session panel already open with active channel
  if (options.claudeDesktopScratch || isClaudeDesktopScratchSessionSync(sessionId, state.vscode)) {
    return {
      sent: false,
      blocked: 'claude-desktop-scratch',
      error: 'Open this chat in Claude Desktop to reply (scratch session has no workspace folder).',
      sessionId
    };
  }
  let panel = controller.sessionPanels?.get?.(sessionId);
  if (panel && controller.panelComms instanceof Map) {
    const comms = controller.panelComms.get(panel);
    const ch = findActiveChannelEntry(comms);
    if (comms && ch && typeof comms.transportMessage === 'function') {
      ensureCommsHooked(state, panel);
      if (explicitMode && comms.__bhfChannelModes?.get(ch.channelId) !== explicitMode) {
        try {
          const setFn = comms.__bhfOrigSetPermissionMode || comms.setPermissionMode?.bind(comms);
          const r = setFn ? await setFn(ch.channelId, explicitMode, false) : null;
          if (r && r.success !== false) {
            comms.__bhfChannelModes.set(ch.channelId, explicitMode);
            comms.__bhfUserChosenChannelModes.set(ch.channelId, {
              mode: explicitMode,
              underSharedMode: sharedMode || explicitMode
            });
            (comms.__bhfOrigSend || comms.send?.bind(comms))?.({
              type: 'io_message',
              channelId: ch.channelId,
              message: { type: 'system', subtype: 'status', permissionMode: explicitMode },
              done: false
            });
          }
        } catch {}
      }
      await comms.transportMessage(
        ch.channelId,
        {
          type: 'user',
          uuid: makeDraftId(),
          session_id: sessionId,
          parent_tool_use_id: null,
          message: {
            role: 'user',
            content: [{ type: 'text', text: promptText }]
          }
        },
        false,
        true
      );
      notifyActivityChanged({ type: 'claude-remote-send', threadId: sessionId });
      return { sent: true, method: 'transportMessage', sessionId, channelId: ch.channelId };
    }
  }

  // Case 3: Open panel with initialPrompt (Claude Code automatically submits initialPrompt on launch)
  const storedMode = getStoredSessionMode(controller, sessionId);
  const applyResumeOverride = Boolean(
    desiredMode &&
      (explicitMode ||
        storedMode !== 'plan' ||
        state.__bhfSharedPlanSessionIds?.has?.(sessionId))
  );
  const resumeToken = applyResumeOverride
    ? {
        mode: desiredMode,
        explicit: Boolean(explicitMode),
        until: Date.now() + 8000
      }
    : null;
  if (resumeToken) {
    state.__bhfPendingIdeLaunchMode = resumeToken;
  }
  let opened = null;
  try {
    opened = await openClaudeTab({
      state,
      id: sessionId,
      initialPrompt: promptText,
      preserveFocus: Boolean(options.preserveFocus)
    });
  } finally {
    if (state.__bhfPendingIdeLaunchMode === resumeToken && (!opened || opened.panel || opened.revealed)) {
      state.__bhfPendingIdeLaunchMode = null;
    }
  }
  if (applyResumeOverride && opened?.panel) {
    opened.panel.__bhfLaunchModeOverride = {
      mode: desiredMode,
      explicit: Boolean(explicitMode)
    };
  }
  return { sent: Boolean(opened), method: 'createPanel-resume', sessionId, opened };
}

const CLAUDE_REJECT_DEFAULT_MSG =
  "The user doesn't want to proceed with this tool use. The tool use was rejected (eg. if it was a file edit, the new_string was NOT written to the file). STOP what you are doing and wait for the user to tell you how to proceed.";
const CLAUDE_REJECT_WITH_REASON_PREFIX =
  "The user doesn't want to proceed with this tool use. The tool use was rejected (eg. if it was a file edit, the new_string was NOT written to the file). The user provided the following reason for the rejection: ";

function findCommsForSession(controller, sessionId) {
  if (!controller) return null;
  if (sessionId && controller.sessionPanels instanceof Map && controller.panelComms instanceof Map) {
    const panel = controller.sessionPanels.get(sessionId);
    const comms = panel && controller.panelComms.get(panel);
    if (comms) return comms;
  }
  const candidates = [];
  if (controller.allComms instanceof Set) {
    for (const c of controller.allComms) {
      if (c && !candidates.includes(c)) candidates.push(c);
    }
  }
  if (controller.panelComms instanceof Map) {
    for (const c of controller.panelComms.values()) {
      if (c && !candidates.includes(c)) candidates.push(c);
    }
  }
  if (sessionId) {
    for (const c of candidates) {
      const sid = resolveSessionIdForComms(controller, c, '', c.__bhfPanel || null);
      if (sid === sessionId) return c;
    }
  }
  for (const c of candidates) {
    if (c.outstandingRequests instanceof Map && c.outstandingRequests.size > 0) {
      return c;
    }
  }
  return candidates[0] || null;
}

async function respondClaudePermission(options = {}) {
  const state = options.state || getBridgeState();
  const permId = String(options.id || options.permissionId || '').trim();
  const sessionId = String(options.sessionId || options.threadId || '').trim();

  let target = permId ? state.pendingPermissions.get(permId) : null;
  if (!target && !permId && sessionId) {
    for (const entry of state.pendingPermissions.values()) {
      const entrySid =
        entry.sessionId ||
        resolveSessionIdForComms(state.controller, entry.comms, entry.channelId, entry.panel);
      if (entrySid === sessionId) {
        target = entry;
        break;
      }
    }
  }
  if (!target && !permId && !sessionId && state.pendingPermissions.size > 0) {
    target = state.pendingPermissions.values().next().value;
  }

  const resolvedTargetSid = String(
    target?.sessionId ||
      sessionId ||
      (target
        ? resolveSessionIdForComms(state.controller, target.comms, target.channelId, target.panel)
        : '') ||
      ''
  ).trim();
  if (
    options.claudeDesktopScratch ||
    (resolvedTargetSid && isClaudeDesktopScratchSessionSync(resolvedTargetSid, state.vscode)) ||
    (sessionId && isClaudeDesktopScratchSessionSync(sessionId, state.vscode))
  ) {
    return {
      resolved: false,
      blocked: 'claude-desktop-scratch',
      error: 'Open this chat in Claude Desktop to answer this question.'
    };
  }

  const approved = options.approved !== false;
  const allowAlways = Boolean(options.allowAlways || options.decision === 'allow_always');
  const customReason = String(options.customReason || options.writeInResponse || '').trim();

  const comms = target?.comms || (!permId && sessionId ? findCommsForSession(state.controller, sessionId) : null);
  if (!comms) {
    return { resolved: false, error: 'No matching pending permission or Claude channel found' };
  }
  const commsSid = String(
    resolveSessionIdForComms(
      state.controller,
      comms,
      target?.channelId || '',
      target?.panel || comms.__bhfPanel || null
    ) || ''
  ).trim();
  if (commsSid && isClaudeDesktopScratchSessionSync(commsSid, state.vscode)) {
    return {
      resolved: false,
      blocked: 'claude-desktop-scratch',
      error: 'Open this chat in Claude Desktop to answer this question.'
    };
  }

  let resolvedCount = 0;
  const mergedUpdatedInput = {
    ...(target?.inputs || {}),
    ...(options.updatedInput && typeof options.updatedInput === 'object'
      ? options.updatedInput
      : {}),
    ...(options.answers && typeof options.answers === 'object'
      ? { answers: options.answers }
      : {})
  };

  let updatedPermissions;
  if (approved && allowAlways && Array.isArray(target?.suggestions) && target.suggestions.length > 0) {
    const dest = String(options.destination || 'userSettings');
    updatedPermissions = target.suggestions.map((s) => ({
      ...s,
      destination: s.type === 'setMode' ? s.destination : dest
    }));
  }

  const resultPayload = approved
    ? {
        behavior: 'allow',
        updatedInput: mergedUpdatedInput,
        ...(updatedPermissions ? { updatedPermissions } : {})
      }
    : {
        behavior: 'deny',
        message: customReason
          ? `${CLAUDE_REJECT_WITH_REASON_PREFIX}${customReason}`
          : String(options.reason || CLAUDE_REJECT_DEFAULT_MSG),
        interrupt: !customReason
      };

  const responseEnvelope = {
    type: 'tool_permission_response',
    result: resultPayload
  };

  if (comms.outstandingRequests instanceof Map) {
    const entries = Array.from(comms.outstandingRequests.entries());
    const targetReqId = target?.requestId || '';
    const filteredEntries =
      targetReqId && comms.outstandingRequests.has(targetReqId)
        ? [[targetReqId, comms.outstandingRequests.get(targetReqId)]]
        : entries;

    for (const [reqId, resolver] of filteredEntries) {
      let invoked = false;
      if (typeof resolver === 'function') {
        resolver(responseEnvelope);
        invoked = true;
      } else if (resolver && typeof resolver.resolve === 'function') {
        resolver.resolve(responseEnvelope);
        invoked = true;
      }
      if (invoked) {
        comms.outstandingRequests.delete(reqId);
        if (typeof comms.send === 'function') {
          try {
            comms.send({ type: 'cancel_request', targetRequestId: reqId });
          } catch {}
        }
        resolvedCount += 1;
      }
    }
  }
  if (target?.id) {
    state.pendingPermissions.delete(target.id);
  }
  const effectiveSid =
    target?.sessionId ||
    sessionId ||
    resolveSessionIdForComms(state.controller, comms, '', comms.__bhfPanel || null);
  clearPendingBadgeIfIdle(state, effectiveSid, comms, target?.panel || comms?.__bhfPanel || null);
  notifyActivityChanged({
    type: 'claude-permission-responded',
    threadId: effectiveSid,
    approved
  });
  return {
    resolved: resolvedCount > 0,
    resolvedCount,
    id: target?.id || permId || effectiveSid,
    sessionId: effectiveSid,
    approved,
    allowAlways
  };
}

async function interruptClaudeSession(options = {}) {
  const state = getBridgeState();
  const { controller } = state;
  const sessionId = String(options.id || options.threadId || '').trim();
  let interrupted = false;
  let matchedChannelId = '';

  if (sessionId && state.pendingPermissions instanceof Map) {
    for (const [reqId, p] of Array.from(state.pendingPermissions.entries())) {
      const pSid =
        p?.sessionId || resolveSessionIdForComms(controller, p?.comms, p?.channelId, p?.panel);
      if (p && pSid === sessionId) {
        try {
          await respondClaudePermission({
            id: reqId,
            sessionId,
            approved: false,
            reason: 'Stopped by user'
          });
        } catch {}
        state.pendingPermissions.delete(reqId);
        interrupted = true;
      }
    }
  }

  if (controller) {
    const candidateComms = [];
    const panel = sessionId
      ? controller.sessionPanels?.get?.(sessionId)
      : controller.sessionPanels?.get?.(controller.activePanelSessionId?.());
    if (panel && controller.panelComms instanceof Map) {
      const pc = controller.panelComms.get(panel);
      if (pc) candidateComms.push(pc);
    }
    if (controller.panelComms instanceof Map) {
      for (const pc of controller.panelComms.values()) {
        if (pc && !candidateComms.includes(pc)) candidateComms.push(pc);
      }
    }
    if (controller.allComms instanceof Set) {
      for (const ac of controller.allComms.values()) {
        if (ac && !candidateComms.includes(ac)) candidateComms.push(ac);
      }
    }

    for (const comms of candidateComms) {
      if (!comms || typeof comms.interruptClaude !== 'function') continue;
      if (sessionId && comms.channels instanceof Map) {
        for (const [channelId, entry] of comms.channels.entries()) {
          if (entry && entry.sessionId === sessionId) {
            try {
              await comms.interruptClaude(channelId);
              interrupted = true;
              matchedChannelId = channelId;
            } catch {}
          }
        }
      }
      if (!interrupted && ( comms === candidateComms[0] || !sessionId )) {
        const ch = findActiveChannelEntry(comms);
        if (ch && (!sessionId || !ch.entry?.sessionId || ch.entry.sessionId === sessionId)) {
          try {
            await comms.interruptClaude(ch.channelId);
            interrupted = true;
            matchedChannelId = ch.channelId;
          } catch {}
        }
      }
    }
  }

  if (sessionId && state.liveSessionStates instanceof Map) {
    const prev = state.liveSessionStates.get(sessionId) || {};
    state.liveSessionStates.set(sessionId, {
      ...prev,
      sessionId,
      state: 'idle',
      updatedAt: Date.now()
    });
  }
  notifyActivityChanged({
    type: 'claude-interrupted',
    threadId: sessionId
  });
  return { interrupted, sessionId, channelId: matchedChannelId };
}

function registerBridgeCommands(state) {
  state.__cmdHandlers = {
    getOpenClaudeTabsSnapshot,
    getPrewarmedClaudeTabsSnapshot,
    getLiveSnapshot,
    openClaudeTab,
    closeClaudeTab,
    sendPromptToClaude,
    respondClaudePermission,
    interruptClaudeSession,
    syncClaudeTabBadges,
    syncSharedClaudePermissionMode
  };
  const { vscode, context } = state;
  if (context?.workspaceState && !state.__bhfStartupPrewarmClaudeSwept) {
    state.__bhfStartupPrewarmClaudeSwept = true;
    sweepPersistedPrewarmClaudeIds(state).catch(() => {});
  }
  if (vscode?.commands && context && !state.prewarmCommandsRegistered) {
    state.prewarmCommandsRegistered = true;
    try {
      context.subscriptions.push(
        vscode.commands.registerCommand('antigravityHub.claudeGetPrewarmedTabs', () =>
          (state.__cmdHandlers?.getPrewarmedClaudeTabsSnapshot || getPrewarmedClaudeTabsSnapshot)()
        )
      );
    } catch {}
  }
  if (!vscode || !context || state.commandsRegistered) {
    return;
  }
  state.commandsRegistered = true;
  state.syncPermModeCommandRegistered = true;

  context.subscriptions.push(
    vscode.commands.registerCommand('antigravityHub.claudeBridgeStatus', () => ({
      active: true,
      version: BRIDGE_VERSION,
      openTabs: (state.__cmdHandlers?.getOpenClaudeTabsSnapshot || getOpenClaudeTabsSnapshot)(),
      hasSidebarView: Boolean(state.sidebarView),
      hasSidebarDelegate: Boolean(state.sidebarDelegate),
      hideDuplicateIcon: getHideDuplicateSetting(vscode)
    })),
    vscode.commands.registerCommand('antigravityHub.claudeAttachSidebar', async (delegate) => {
      state.sidebarDelegate = delegate || null;
      if (state.sidebarFallbackTimer) {
        clearTimeout(state.sidebarFallbackTimer);
        state.sidebarFallbackTimer = null;
      }
      if (state.sidebarView && delegate && typeof delegate.resolveWebviewView === 'function') {
        await delegate.resolveWebviewView(state.sidebarView);
      }
      applyActivityBarVisibility(state);
      return { attached: Boolean(delegate), hadSidebarView: Boolean(state.sidebarView) };
    }),
    vscode.commands.registerCommand('antigravityHub.claudeGetSnapshot', () =>
      (state.__cmdHandlers?.getLiveSnapshot || getLiveSnapshot)()
    ),
    vscode.commands.registerCommand('antigravityHub.claudeOpenTab', async (options = {}) =>
      (state.__cmdHandlers?.openClaudeTab || openClaudeTab)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeCloseTab', async (options = {}) =>
      (state.__cmdHandlers?.closeClaudeTab || closeClaudeTab)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeSendPrompt', async (options = {}) =>
      (state.__cmdHandlers?.sendPromptToClaude || sendPromptToClaude)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeRespondPermission', async (options = {}) =>
      (state.__cmdHandlers?.respondClaudePermission || respondClaudePermission)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeInterrupt', async (options = {}) =>
      (state.__cmdHandlers?.interruptClaudeSession || interruptClaudeSession)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeRenameSession', async (options = {}) => {
      const id = String(options.id || options.threadId || '').trim();
      const title = String(options.title || '').trim();
      if (!id || !title || !state.controller) {
        return false;
      }
      try {
        state.controller.handleSessionRenamed?.(id, title, undefined, Boolean(options.skipCli));
        const panel = state.controller.sessionPanels?.get?.(id);
        if (panel) {
          panel.title = title;
        }
        return true;
      } catch {
        return false;
      }
    }),
    vscode.commands.registerCommand('antigravityHub.claudeSetUnread', async (options = {}) => {
      const id = String(options.id || options.threadId || '').trim();
      if (!id || !state.controller) {
        return false;
      }
      try {
        return Boolean(state.controller.setSessionUnread?.(id, Boolean(options.unread)));
      } catch {
        return false;
      }
    }),
    vscode.commands.registerCommand('antigravityHub.claudeDeleteGroup', async (options = {}) => {
      const gId = String(options.id || options.group || '').trim();
      const nameKey = String(options.name || '').trim().toLowerCase();
      if (!gId && !nameKey) {
        return false;
      }
      let touched = 0;
      try {
        if (typeof state.controller?.settings?.deleteSessionGroup === 'function') {
          await state.controller.settings.deleteSessionGroup(gId);
          touched += 1;
        }
      } catch {}
      try {
        const gs = state.context?.globalState;
        const keys = typeof gs?.keys === 'function' ? gs.keys() : [];
        for (const k of keys) {
          if (!String(k).startsWith('sessionGroups:')) {
            continue;
          }
          const cur = gs.get(k);
          if (!Array.isArray(cur)) {
            continue;
          }
          const next = cur.filter(
            (g) =>
              !g ||
              !(
                (gId && g.id === gId) ||
                (nameKey && String(g.name || '').trim().toLowerCase() === nameKey)
              )
          );
          if (next.length !== cur.length) {
            await gs.update(k, next);
            touched += 1;
          }
        }
      } catch {}
      return touched > 0;
    }),
    vscode.commands.registerCommand('antigravityHub.claudeRemoveFromGroup', async (options = {}) =>
      removeSessionsFromClaudeGroups(state, options)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeSetArchived', async (options = {}) => {
      const rawIds = Array.isArray(options.ids)
        ? options.ids
        : options.id
          ? [options.id]
          : [];
      const ids = rawIds.map((x) => String(x || '').trim()).filter(Boolean);
      if (ids.length === 0) {
        return false;
      }
      const archived = Boolean(options.archived);
      try {
        if (archived) {
          await removeSessionsFromClaudeGroups(state, { ids });
          if (typeof state.controller?.settings?.archiveSessions === 'function') {
            await state.controller.settings.archiveSessions(ids);
          } else if (state.context?.globalState) {
            const cur = state.context.globalState.get('hiddenSessionIds') || [];
            await state.context.globalState.update('hiddenSessionIds', [
              ...new Set([...cur, ...ids])
            ]);
          }
        } else {
          if (typeof state.controller?.settings?.unarchiveSessions === 'function') {
            await state.controller.settings.unarchiveSessions(ids);
          } else if (state.context?.globalState) {
            const cur = state.context.globalState.get('hiddenSessionIds') || [];
            const removeSet = new Set(ids);
            await state.context.globalState.update(
              'hiddenSessionIds',
              cur.filter((item) => !removeSet.has(item))
            );
          }
        }
        try {
          state.controller?.broadcastSessionArchiveChanged?.(undefined, ids[0], archived);
        } catch {}
        return true;
      } catch {
        return false;
      }
    }),
    vscode.commands.registerCommand('antigravityHub.claudeSyncTabBadges', (badgesById = {}) =>
      (state.__cmdHandlers?.syncClaudeTabBadges || syncClaudeTabBadges)(badgesById)
    ),
    vscode.commands.registerCommand('antigravityHub.claudeResetCachedUsage', () => {
      state.lastRateLimitWindows = null;
      state.lastFullRateLimits = null;
      state.lastFullRateLimitsAt = 0;
      state.lastProcessUsagePollAt = 0;
      try {
        if (state.controller?.panelUsageRelay) {
          state.controller.panelUsageRelay.merged = null;
        }
      } catch {}
      return { ok: true };
    }),
    vscode.commands.registerCommand('antigravityHub.claudeSetActivityBarVisible', async (visible) => {
      const hideDuplicate = !visible;
      try {
        await vscode.workspace
          .getConfiguration('antigravityHub')
          .update('hideDuplicateActivityBarIcon', hideDuplicate, vscode.ConfigurationTarget.Global);
      } catch {}
      applyActivityBarVisibility(state);
      return { hideDuplicateIcon: hideDuplicate };
    }),
    vscode.commands.registerCommand(
      'antigravityHub.claudeSyncPermissionMode',
      async (options = {}) =>
        (state.__cmdHandlers?.syncSharedClaudePermissionMode || syncSharedClaudePermissionMode)(
          state,
          options
        )
    )
  );

  if (typeof vscode.workspace?.onDidChangeConfiguration === 'function') {
    context.subscriptions.push(
      vscode.workspace.onDidChangeConfiguration((e) => {
        if (e.affectsConfiguration?.('antigravityHub.hideDuplicateActivityBarIcon')) {
          applyActivityBarVisibility(state);
        }
        if (
          e.affectsConfiguration?.('claudeCode.initialPermissionMode') ||
          e.affectsConfiguration?.('claudeCode.allowDangerouslySkipPermissions')
        ) {
          syncSharedClaudePermissionMode(state).catch(() => {});
        }
      })
    );
  }
}

function resolveVscodeApi(candidate) {
  if (
    candidate &&
    typeof candidate === 'object' &&
    candidate.workspace &&
    candidate.window &&
    candidate.commands
  ) {
    return candidate;
  }
  try {
    const realVscode = require('vscode');
    if (realVscode && realVscode.workspace && realVscode.window && realVscode.commands) {
      return realVscode;
    }
  } catch {}
  return null;
}

function attach({ vscode, context, controller }) {
  const state = getBridgeState();
  state.vscode = resolveVscodeApi(vscode) || resolveVscodeApi(state.vscode);
  state.context = context || state.context;
  state.controller = controller || state.controller;
  state.attached = true;

  installControllerHooks(state);
  installClaudeOpenFileSupport(state);
  registerBridgeCommands(state);
  ensurePermissionSyncSupport(state);
  applyActivityBarVisibility(state);
  setTimeout(() => applyActivityBarVisibility(state), 50);
  if (state.context?.workspaceState) {
    state.__bhfStartupPrewarmClaudeSwept = true;
    sweepPersistedPrewarmClaudeIds(state).catch(() => {});
  }

  return state;
}

function installClaudeOpenFileSupport(state) {
  const { controller } = state || {};
  const vscode = resolveVscodeApi(state?.vscode);
  if (vscode && excelPreview?.ensureExcelPreviewRegistered) {
    excelPreview.ensureExcelPreviewRegistered(vscode, state?.context);
  }
  if (!controller || typeof controller.openFile !== 'function' || !excelPreview?.openFileUriSmart) {
    return;
  }
  if (!controller.__bhfOrigOpenFile) {
    controller.__bhfOrigOpenFile = controller.openFile.bind(controller);
  }
  state.__bhfClaudeOpenFileImpl = async function (filePath, location, opts) {
    const activeVscode = resolveVscodeApi(state?.vscode) || vscode;
    if (!filePath || !activeVscode) {
      return controller.__bhfOrigOpenFile(filePath, location, opts);
    }
    let resolved = String(filePath);
    if (!path.isAbsolute(resolved) && controller.cwd) {
      const candidate = path.join(controller.cwd, resolved);
      try {
        if (fs.existsSync(candidate)) resolved = candidate;
      } catch {}
    }
    const outcome = await excelPreview.openFileUriSmart(activeVscode, resolved, () =>
      controller.__bhfOrigOpenFile(filePath, location, opts)
    );
    return outcome && outcome.mode === 'orig' ? outcome.result : undefined;
  };
  if (!controller.__bhfOpenFileWrapped) {
    controller.__bhfOpenFileWrapped = true;
    controller.openFile = function (filePath, location, opts) {
      const impl = state.__bhfClaudeOpenFileImpl;
      return typeof impl === 'function'
        ? impl(filePath, location, opts)
        : controller.__bhfOrigOpenFile(filePath, location, opts);
    };
  }
}

async function removeSessionsFromClaudeGroups(stateOrOptions = {}, maybeOptions = {}) {
  const isStateObj =
    stateOrOptions &&
    typeof stateOrOptions === 'object' &&
    ('controller' in stateOrOptions || 'context' in stateOrOptions || 'attached' in stateOrOptions);
  const state = isStateObj ? stateOrOptions : getBridgeState();
  const options = isStateObj ? maybeOptions || {} : stateOrOptions || {};
  const rawIds = Array.isArray(options.ids)
    ? options.ids
    : options.id
      ? [options.id]
      : [];
  const removeSet = new Set(rawIds.map((x) => String(x || '').trim()).filter(Boolean));
  if (removeSet.size === 0) {
    return false;
  }
  const targetGroupId = String(options.group || options.groupId || '').trim();
  let touched = 0;

  try {
    const settings = state?.controller?.settings;
    if (typeof settings?.getSessionGroups === 'function') {
      const liveGroups = settings.getSessionGroups();
      if (Array.isArray(liveGroups)) {
        for (const g of liveGroups) {
          if (!g || !Array.isArray(g.sessionIds)) continue;
          if (targetGroupId && g.id !== targetGroupId) continue;
          const nextSids = g.sessionIds.filter((sid) => !removeSet.has(String(sid || '').trim()));
          if (nextSids.length !== g.sessionIds.length) {
            g.sessionIds = nextSids;
            touched += 1;
            if (typeof settings.removeSessionsFromGroup === 'function') {
              await settings.removeSessionsFromGroup(g.id, Array.from(removeSet));
            } else if (typeof settings.updateSessionGroup === 'function') {
              await settings.updateSessionGroup(g.id, { sessionIds: nextSids });
            }
          }
        }
      }
    }
  } catch {}

  try {
    const gs = state?.context?.globalState;
    const keys = typeof gs?.keys === 'function' ? gs.keys() : [];
    for (const k of keys) {
      if (!String(k).startsWith('sessionGroups:')) {
        continue;
      }
      const cur = gs.get(k);
      if (!Array.isArray(cur)) {
        continue;
      }
      let keyMutated = false;
      const next = cur.map((g) => {
        if (!g || !Array.isArray(g.sessionIds)) {
          return g;
        }
        if (targetGroupId && g.id !== targetGroupId) {
          return g;
        }
        const filtered = g.sessionIds.filter((sid) => !removeSet.has(String(sid || '').trim()));
        if (filtered.length !== g.sessionIds.length) {
          keyMutated = true;
          return { ...g, sessionIds: filtered };
        }
        return g;
      });
      if (keyMutated) {
        await gs.update(k, next);
        touched += 1;
      }
    }
  } catch {}

  return touched > 0;
}

const VALID_SHARED_CLAUDE_MODES = new Set([
  'acceptEdits',
  'auto',
  'bypassPermissions',
  'default',
  'plan'
]);

function readSharedClaudePermissionMode(options = {}) {
  const opts = options && typeof options === 'object' ? options : {};
  const useCache =
    !opts.modeFilePath &&
    !opts.localCachePath &&
    !opts.memoryRoot &&
    !opts.homeDir &&
    !process.env.THEO_CLAUDE_PERMISSION_MODE_PATH &&
    !process.env.THEO_CLAUDE_PERMISSION_CACHE_PATH &&
    !process.env.THEO_MEMORY_ROOT &&
    !process.env.THEO_GUARD_HOME;
  const homeDir = String(opts.homeDir || process.env.THEO_GUARD_HOME || os.homedir()).trim();
  const explicitFile = String(
    opts.modeFilePath || process.env.THEO_CLAUDE_PERMISSION_MODE_PATH || ''
  ).trim();
  const explicitCacheFile = String(
    opts.localCachePath || process.env.THEO_CLAUDE_PERMISSION_CACHE_PATH || ''
  ).trim();
  // THEO memory lives only at ~/bhfirms/memory (moved off OneDrive 2026-11-11).
  const defaultMemoryRoot = path.join(homeDir, 'bhfirms', 'memory');
  const memoryRoot = String(
    opts.memoryRoot || process.env.THEO_MEMORY_ROOT || defaultMemoryRoot
  ).trim();
  const sharedFile = explicitFile || path.join(memoryRoot, 'Admin', 'claude-permission-mode.json');
  const cacheFile =
    explicitCacheFile ||
    (explicitFile
      ? ''
      : homeDir
        ? path.join(homeDir, '.claude', '.theo-claude-permission-mode.json')
        : '');

  let sharedMtimeMs = 0;
  let sharedSize = -1;
  if (sharedFile && fs.existsSync(sharedFile)) {
    try {
      const st = fs.statSync(sharedFile);
      sharedMtimeMs = st.mtimeMs;
      sharedSize = st.size;
    } catch {}
  }
  let cacheMtimeMs = 0;
  let cacheSize = -1;
  if (cacheFile && fs.existsSync(cacheFile)) {
    try {
      const st = fs.statSync(cacheFile);
      cacheMtimeMs = st.mtimeMs;
      cacheSize = st.size;
    } catch {}
  }
  if (sharedSize < 0 && cacheSize < 0) {
    return null;
  }

  const bridgeState = useCache ? getBridgeState() : null;
  const cached = bridgeState?.__bhfSharedPermCache;
  if (
    cached &&
    cached.file === sharedFile &&
    cached.cacheFile === cacheFile &&
    cached.mtimeMs === sharedMtimeMs &&
    cached.size === sharedSize &&
    cached.cacheMtimeMs === cacheMtimeMs &&
    cached.cacheSize === cacheSize
  ) {
      return cached.mode
        ? {
            mode: cached.mode,
            file: cached.resolvedFrom || sharedFile,
            mtimeMs: cached.effectiveMtimeMs,
            cacheRev: cached.cacheRev || 0,
            cacheUpdatedAt: cached.cacheUpdatedAt || 0
          }
        : null;
    }

  let cacheObj = null;
  if (cacheSize >= 0 && cacheFile) {
    try {
      const rawCache = fs.readFileSync(cacheFile, 'utf8').replace(/^\uFEFF/, '');
      const parsedCache = JSON.parse(rawCache);
      const cm = parsedCache && typeof parsedCache === 'object' ? parsedCache.defaultMode : null;
      if (typeof cm === 'string' && VALID_SHARED_CLAUDE_MODES.has(cm)) {
        cacheObj = {
          mode: cm,
          rev: Math.max(0, Math.floor(Number(parsedCache.rev || 0) || 0)),
          updatedAt: Number(parsedCache.updatedAt || 0) || 0,
          lastSyncedDiskMode:
            typeof parsedCache.lastSyncedDiskMode === 'string' ? parsedCache.lastSyncedDiskMode : '',
          lastSyncedDiskMtimeMs: Number(parsedCache.lastSyncedDiskMtimeMs || 0) || 0,
          lastSyncedDiskRev: Math.max(0, Math.floor(Number(parsedCache.lastSyncedDiskRev || 0) || 0))
        };
      }
    } catch {}
  }

  let diskMode = '';
  let diskRev = 0;
  if (sharedSize >= 0 && sharedFile) {
    try {
      const raw = fs.readFileSync(sharedFile, 'utf8').replace(/^\uFEFF/, '');
      const parsed = JSON.parse(raw);
      const mode = parsed && typeof parsed === 'object' ? parsed.defaultMode : null;
      if (typeof mode === 'string' && VALID_SHARED_CLAUDE_MODES.has(mode)) {
        diskMode = mode;
        diskRev = Math.max(0, Math.floor(Number(parsed.rev || 0) || 0));
      }
    } catch {}
  }

  let validMode = '';
  let resolvedFrom = sharedFile;
  let effectiveMtimeMs = sharedMtimeMs;
  const cacheRev = cacheObj ? cacheObj.rev : 0;
  const cacheUpdatedAt = cacheObj ? cacheObj.updatedAt : 0;
  if (diskMode && cacheObj) {
    const hasSyncedBaseline =
      cacheObj.rev === 0 ||
      (cacheObj.lastSyncedDiskMtimeMs > 0 && Boolean(cacheObj.lastSyncedDiskMode));
    const isStaleSyncedDisk =
      !hasSyncedBaseline ||
      (diskRev > 0 && diskRev < cacheObj.rev) ||
      (cacheObj.lastSyncedDiskRev > 0 && diskRev > 0 && diskRev < cacheObj.lastSyncedDiskRev);
    const minUpdatedMs =
      cacheObj.rev > 0 ? cacheObj.updatedAt + 500 : cacheObj.updatedAt - 2000;
    const diskEditedAfterSync =
      !isStaleSyncedDisk &&
      diskMode !== cacheObj.lastSyncedDiskMode &&
      sharedMtimeMs > cacheObj.lastSyncedDiskMtimeMs + 50 &&
      sharedMtimeMs > minUpdatedMs;
    if (diskEditedAfterSync) {
      validMode = diskMode;
      resolvedFrom = sharedFile;
      effectiveMtimeMs = sharedMtimeMs;
    } else {
      validMode = cacheObj.mode;
      resolvedFrom = cacheFile;
      effectiveMtimeMs = cacheMtimeMs || sharedMtimeMs;
    }
  } else if (diskMode) {
    validMode = diskMode;
    resolvedFrom = sharedFile;
    effectiveMtimeMs = sharedMtimeMs;
  } else if (cacheObj) {
    validMode = cacheObj.mode;
    resolvedFrom = cacheFile;
    effectiveMtimeMs = cacheMtimeMs;
  }

  if (bridgeState) {
    bridgeState.__bhfSharedPermCache = {
      file: sharedFile,
      cacheFile,
      mtimeMs: sharedMtimeMs,
      size: sharedSize,
      cacheMtimeMs,
      cacheSize,
      cacheRev,
      cacheUpdatedAt,
      mode: validMode,
      resolvedFrom,
      effectiveMtimeMs
    };
  }
  return validMode
    ? { mode: validMode, file: resolvedFrom, mtimeMs: effectiveMtimeMs, cacheRev, cacheUpdatedAt }
    : null;
}

function hasPendingPermissionForChannel(state, channelId, sessionId = '') {
  if (!(state?.pendingPermissions instanceof Map) || state.pendingPermissions.size === 0) {
    return false;
  }
  for (const entry of state.pendingPermissions.values()) {
    if (!entry) continue;
    if (channelId && entry.channelId && String(entry.channelId) === String(channelId)) {
      return true;
    }
    if (sessionId) {
      const entrySid =
        entry.sessionId ||
        resolveSessionIdForComms(state.controller, entry.comms, entry.channelId, entry.panel);
      if (entrySid === sessionId) {
        return true;
      }
    }
  }
  return false;
}

function getStoredSessionMode(controller, sessionId) {
  if (!controller || !sessionId) return '';
  try {
    const entry = controller.settings?.sessionModeStore?.get?.(sessionId);
    const mode = typeof entry === 'string' ? entry : entry?.mode;
    return typeof mode === 'string' ? mode : '';
  } catch {
    return '';
  }
}

function collectLiveCommsAndPanels(controller) {
  const commsList = [];
  const panels = [];
  const webviews = [];
  const addWebview = (wv) => {
    if (wv && typeof wv === 'object' && !webviews.includes(wv)) {
      webviews.push(wv);
    }
  };
  if (!controller) return { commsList, panels, webviews };
  if (controller.panelComms instanceof Map) {
    for (const [panel, c] of controller.panelComms.entries()) {
      if (panel && !panels.includes(panel)) panels.push(panel);
      addWebview(panel?.webview);
      if (c && !commsList.includes(c)) {
        if (panel && !c.__bhfPanel) c.__bhfPanel = panel;
        commsList.push(c);
      }
      addWebview(c?.webview);
    }
  }
  if (controller.sessionPanels instanceof Map) {
    for (const panel of controller.sessionPanels.values()) {
      if (panel && !panels.includes(panel)) panels.push(panel);
      addWebview(panel?.webview);
    }
  }
  if (controller.allComms instanceof Set) {
    for (const c of controller.allComms) {
      if (c && !commsList.includes(c)) commsList.push(c);
      addWebview(c?.__bhfPanel?.webview);
      addWebview(c?.webview);
    }
  }
  return { commsList, panels, webviews };
}

async function refreshCommsConfigState(commsList) {
  for (const c of commsList) {
    try {
      if (typeof c.loadConfig === 'function') {
        await c.loadConfig();
      }
      if (typeof c.pushStateUpdate === 'function') {
        await c.pushStateUpdate();
      }
    } catch {}
  }
}

async function runSinglePermissionSyncPass(state, effectiveOpts = {}) {
  const shared = readSharedClaudePermissionMode(effectiveOpts);
  const targetMode = shared?.mode || '';
  if (!targetMode) {
    return { ok: false, skipped: 'no-shared-mode' };
  }

  const seenRev = Number(shared?.cacheRev || 0);
  const seenCacheUpdatedAt = Number(shared?.cacheUpdatedAt || 0);
  let cacheAdvancedSinceBoot = false;
  if (state.__bhfHasObservedInitialPermState !== true) {
    state.__bhfHasObservedInitialPermState = true;
    state.__bhfLastSeenCacheRev = seenRev;
    state.__bhfLastSeenCacheUpdatedAt = seenCacheUpdatedAt;
  } else {
    if (
      (seenRev > 0 && seenRev > Number(state.__bhfLastSeenCacheRev || 0)) ||
      (seenCacheUpdatedAt > 0 &&
        seenCacheUpdatedAt > Number(state.__bhfLastSeenCacheUpdatedAt || 0))
    ) {
      cacheAdvancedSinceBoot = true;
    }
    if (seenRev > Number(state.__bhfLastSeenCacheRev || 0)) {
      state.__bhfLastSeenCacheRev = seenRev;
    }
    if (seenCacheUpdatedAt > Number(state.__bhfLastSeenCacheUpdatedAt || 0)) {
      state.__bhfLastSeenCacheUpdatedAt = seenCacheUpdatedAt;
    }
  }

  const resetOverrides = Boolean(
    effectiveOpts.resetSessionOverrides ||
      state.__bhfDeferredResetOverrides ||
      cacheAdvancedSinceBoot
  );
  const { controller } = state;
  const { commsList, webviews } = collectLiveCommsAndPanels(controller);
  for (const c of commsList) {
    hookCommsObject(state, c, c.__bhfPanel || null);
    if (resetOverrides && c.__bhfUserChosenChannelModes instanceof Map) {
      c.__bhfUserChosenChannelModes.clear();
    }
  }

  const sharedModeChanged =
    state.__bhfAppliedSharedPermMode !== targetMode ||
    Boolean(effectiveOpts.force) ||
    resetOverrides;
  let hasUnhandledChannels = false;
  for (const c of commsList) {
    if (c.channels instanceof Map) {
      for (const chId of c.channels.keys()) {
        if (c.__bhfAppliedSharedModeByChannel?.get(String(chId)) !== targetMode) {
          hasUnhandledChannels = true;
          break;
        }
      }
    }
    if (hasUnhandledChannels) break;
  }
  const hasUnhandledWebviews = webviews.some(
    (wv) => wv.__bhfAppliedSharedPermMode !== targetMode
  );

  if (!sharedModeChanged && !hasUnhandledChannels && !hasUnhandledWebviews) {
    return { ok: true, mode: targetMode, switched: 0, noop: true };
  }

  // 1. Sync VS Code global claudeCode configuration when shared mode changes.
  let vscodeConfigUpdated = false;
  const vscode = resolveVscodeApi(state.vscode);
  if ((sharedModeChanged || state.__bhfConfigSyncedMode !== targetMode) && vscode?.workspace) {
    try {
      const cfg = vscode.workspace.getConfiguration('claudeCode');
      const globalTarget = vscode.ConfigurationTarget?.Global ?? true;
      if (targetMode === 'bypassPermissions') {
        if (cfg?.inspect?.('allowDangerouslySkipPermissions')?.globalValue !== true) {
          await cfg.update('allowDangerouslySkipPermissions', true, globalTarget);
          vscodeConfigUpdated = true;
        }
        if (cfg?.inspect?.('initialPermissionMode')?.globalValue !== 'bypassPermissions') {
          await cfg.update('initialPermissionMode', 'bypassPermissions', globalTarget);
          vscodeConfigUpdated = true;
        }
      } else {
        if (cfg?.inspect?.('initialPermissionMode')?.globalValue !== undefined) {
          await cfg.update('initialPermissionMode', undefined, globalTarget);
          vscodeConfigUpdated = true;
        }
        if (Boolean(cfg?.inspect?.('allowDangerouslySkipPermissions')?.globalValue)) {
          await cfg.update('allowDangerouslySkipPermissions', false, globalTarget);
          vscodeConfigUpdated = true;
        }
        if (typeof controller?.settings?.setPermissionMode === 'function') {
          if (
            targetMode === 'default' ||
            targetMode === 'auto' ||
            targetMode === 'acceptEdits'
          ) {
            if (controller.settings.getInitialPermissionMode?.() !== targetMode) {
              await controller.settings.setPermissionMode(targetMode);
              vscodeConfigUpdated = true;
            }
          } else if (targetMode === 'plan') {
            const curInit = controller.settings.getInitialPermissionMode?.();
            if (curInit !== undefined && curInit !== 'plan') {
              await controller.settings.setPermissionMode(undefined);
              vscodeConfigUpdated = true;
            }
          }
        }
      }
      state.__bhfConfigSyncedMode = targetMode;
    } catch {}
  }

  if (!(state.__bhfSharedPlanSessionIds instanceof Set)) {
    state.__bhfSharedPlanSessionIds = new Set();
  }

  // 2. Clear stale non-'plan' stored session modes (and shared-synced or explicitly-reset 'plan' entries when leaving 'plan').
  if ((sharedModeChanged || resetOverrides) && controller?.settings?.sessionModeStore) {
    try {
      const store = controller.settings.sessionModeStore;
      const ids = typeof store.ids === 'function' ? store.ids() : [];
      for (const sid of ids) {
        const entry = store.get?.(sid);
        const storedMode = typeof entry === 'string' ? entry : entry?.mode;
        const isOrganicPlan =
          !resetOverrides &&
          storedMode === 'plan' &&
          !state.__bhfSharedPlanSessionIds.has(sid);
        if (storedMode && !isOrganicPlan && storedMode !== targetMode) {
          if (typeof controller.settings.clearSessionPermissionMode === 'function') {
            await controller.settings.clearSessionPermissionMode(sid);
          } else if (typeof store.update === 'function') {
            await store.update(sid, undefined);
          }
          state.__bhfSharedPlanSessionIds.delete(sid);
        }
      }
    } catch {}
  }

  // When entering bypassPermissions, push refreshed config to comms/webviews BEFORE switching live channels
  // so getAllowDangerouslySkipPermissions() and webview bypassConfigVerdict() are open first.
  if (
    targetMode === 'bypassPermissions' &&
    (vscodeConfigUpdated ||
      sharedModeChanged ||
      commsList.some((c) => c.settings?.getAllowDangerouslySkipPermissions?.() === false))
  ) {
    await refreshCommsConfigState(commsList);
  }

  // 3. Switch already-open live CLI channels + update open webviews' mode picker pill.
  const switchedChannels = [];
  let deferredPending = false;
  for (const c of commsList) {
    if (!(c.channels instanceof Map)) continue;
    for (const [rawChId, chObj] of c.channels.entries()) {
      const channelId = String(rawChId || '');
      if (!channelId) continue;
      if (!effectiveOpts.force && c.__bhfAppliedSharedModeByChannel.get(channelId) === targetMode) {
        continue;
      }
      const userChoice = c.__bhfUserChosenChannelModes.get(channelId);
      if (userChoice && userChoice.underSharedMode === targetMode) {
        c.__bhfAppliedSharedModeByChannel.set(channelId, targetMode);
        continue;
      }
      const sid = resolveSessionIdForComms(controller, c, channelId, c.__bhfPanel || null);
      const currentMode =
        c.__bhfChannelModes.get(channelId) ||
        String(chObj?.query?.transport?.options?.permissionMode || '') ||
        getStoredSessionMode(controller, sid);
      const wasSyncedIntoPlan =
        c.__bhfSharedPlanChannels?.has?.(channelId) ||
        Boolean(sid && state.__bhfSharedPlanSessionIds.has(sid));
      if (!resetOverrides && currentMode === 'plan' && !wasSyncedIntoPlan) {
        c.__bhfAppliedSharedModeByChannel.set(channelId, targetMode);
        continue;
      }
      if (hasPendingPermissionForChannel(state, channelId, sid)) {
        deferredPending = true;
        continue;
      }
      if (currentMode === targetMode && !sharedModeChanged && !effectiveOpts.force) {
        c.__bhfAppliedSharedModeByChannel.set(channelId, targetMode);
        continue;
      }
      const setFn =
        typeof c.__bhfOrigSetPermissionMode === 'function'
          ? c.__bhfOrigSetPermissionMode
          : typeof c.setPermissionMode === 'function'
            ? c.setPermissionMode.bind(c)
            : null;
      if (!setFn) continue;
      try {
        const res = await setFn(channelId, targetMode, false);
        if (res && res.success !== false) {
          c.__bhfChannelModes.set(channelId, targetMode);
          c.__bhfAppliedSharedModeByChannel.set(channelId, targetMode);
          if (targetMode === 'plan') {
            c.__bhfSharedPlanChannels.add(channelId);
            if (sid) state.__bhfSharedPlanSessionIds.add(sid);
          } else {
            c.__bhfSharedPlanChannels.delete(channelId);
            if (sid) state.__bhfSharedPlanSessionIds.delete(sid);
          }
          const sendFn =
            typeof c.__bhfOrigSend === 'function'
              ? c.__bhfOrigSend
              : typeof c.send === 'function'
                ? c.send.bind(c)
                : null;
          if (sendFn) {
            sendFn({
              type: 'io_message',
              channelId,
              message: {
                type: 'system',
                subtype: 'status',
                permissionMode: targetMode
              },
              done: false
            });
          }
          switchedChannels.push(channelId);
        }
      } catch {}
    }
  }

  if (targetMode !== 'bypassPermissions' && (vscodeConfigUpdated || sharedModeChanged)) {
    await refreshCommsConfigState(commsList);
  }

  // 4. Push shared mode to every open editor & sidebar webview (including idle/restored tabs opened after attach).
  let notifiedWebviews = 0;
  for (const wv of webviews) {
    if (sharedModeChanged || resetOverrides || wv.__bhfAppliedSharedPermMode !== targetMode) {
      try {
        if (typeof wv.postMessage === 'function') {
          wv.postMessage({
            type: 'bhf_shared_permission_mode',
            mode: targetMode,
            resetSessionOverrides: resetOverrides
          });
          wv.__bhfAppliedSharedPermMode = targetMode;
          notifiedWebviews += 1;
        }
      } catch {}
    }
  }

  if (deferredPending) {
    if (resetOverrides) {
      state.__bhfDeferredResetOverrides = true;
    }
  } else {
    state.__bhfDeferredResetOverrides = false;
    state.__bhfAppliedSharedPermMode = targetMode;
    if (resetOverrides && targetMode !== 'plan') {
      state.__bhfSharedPlanSessionIds.clear();
    }
  }

  return {
    ok: true,
    mode: targetMode,
    switched: switchedChannels.length,
    switchedChannels,
    notifiedWebviews,
    deferredPending
  };
}

async function syncSharedClaudePermissionMode(stateOrOptions = {}, maybeOptions = {}) {
  const isStateObj =
    stateOrOptions &&
    typeof stateOrOptions === 'object' &&
    ('controller' in stateOrOptions || 'context' in stateOrOptions || 'attached' in stateOrOptions);
  const state = isStateObj ? stateOrOptions : getBridgeState();
  const options = isStateObj ? maybeOptions || {} : stateOrOptions || {};
  if (!state) return { ok: false, skipped: 'no-state' };
  if (options.homeDir || options.memoryRoot || options.modeFilePath || options.localCachePath) {
    state.__bhfPermSyncOptions = {
      homeDir: options.homeDir,
      memoryRoot: options.memoryRoot,
      modeFilePath: options.modeFilePath,
      localCachePath: options.localCachePath
    };
  }
  const effectiveOpts = state.__bhfPermSyncOptions
    ? { ...state.__bhfPermSyncOptions, ...options }
    : options;

  if (state.__bhfPermSyncInFlight) {
    state.__bhfPermSyncQueued = {
      ...state.__bhfPermSyncQueued,
      ...effectiveOpts,
      force: Boolean(state.__bhfPermSyncQueued?.force || effectiveOpts.force),
      resetSessionOverrides: Boolean(
        state.__bhfPermSyncQueued?.resetSessionOverrides || effectiveOpts.resetSessionOverrides
      )
    };
    return state.__bhfPermSyncInFlight;
  }

  const drain = (async () => {
    let nextOpts = effectiveOpts;
    let lastResult = { ok: false, skipped: 'no-state' };
    while (nextOpts) {
      lastResult = await runSinglePermissionSyncPass(state, nextOpts);
      nextOpts = state.__bhfPermSyncQueued || null;
      state.__bhfPermSyncQueued = null;
    }
    return lastResult;
  })().finally(() => {
    if (state.__bhfPermSyncInFlight === drain) {
      state.__bhfPermSyncInFlight = null;
    }
  });
  state.__bhfPermSyncInFlight = drain;
  return drain;
}

function ensurePermissionSyncSupport(state) {
  if (!state) return;
  state.__bhfOnCommsSend = function (st, comms, payload) {
    if (
      payload &&
      payload.type === 'io_message' &&
      payload.channelId &&
      typeof payload.message?.permissionMode === 'string'
    ) {
      const chKey = String(payload.channelId);
      const pm = payload.message.permissionMode;
      comms.__bhfChannelModes.set(chKey, pm);
      if (pm !== 'plan') {
        comms.__bhfSharedPlanChannels?.delete?.(chKey);
        const sid = resolveSessionIdForComms(st.controller, comms, chKey, comms.__bhfPanel || null);
        if (sid) st.__bhfSharedPlanSessionIds?.delete?.(sid);
      }
    }
    if (payload?.request?.type === 'update_state') {
      const targetMode =
        st.__bhfAppliedSharedPermMode ||
        readSharedClaudePermissionMode(st.__bhfPermSyncOptions)?.mode ||
        '';
      const wv = comms?.__bhfPanel?.webview || comms?.webview;
      if (targetMode && wv && typeof wv.postMessage === 'function') {
        try {
          wv.postMessage({ type: 'bhf_shared_permission_mode', mode: targetMode });
          wv.__bhfAppliedSharedPermMode = targetMode;
        } catch {}
      }
    }
  };
  state.__bhfOnCommsSetPermissionMode = async function (
    st,
    comms,
    channelId,
    mode,
    userInitiated,
    ...rest
  ) {
    const res = await comms.__bhfOrigSetPermissionMode(channelId, mode, userInitiated, ...rest);
    if (res && res.success !== false && channelId && typeof mode === 'string') {
      const chKey = String(channelId);
      comms.__bhfChannelModes.set(chKey, mode);
      if (userInitiated) {
        comms.__bhfSharedPlanChannels?.delete?.(chKey);
        const sid = resolveSessionIdForComms(st.controller, comms, chKey, comms.__bhfPanel || null);
        if (sid) st.__bhfSharedPlanSessionIds?.delete?.(sid);
        comms.__bhfUserChosenChannelModes.set(chKey, {
          mode,
          underSharedMode:
            st.__bhfAppliedSharedPermMode ||
            readSharedClaudePermissionMode(st.__bhfPermSyncOptions)?.mode ||
            ''
        });
      }
    }
    return res;
  };
  state.__bhfOnCommsLaunchClaude = async function (
    st,
    comms,
    channelId,
    sessionId,
    cwdOrOpts,
    permissionMode,
    ...rest
  ) {
    if (!(st.__bhfSharedPlanSessionIds instanceof Set)) {
      st.__bhfSharedPlanSessionIds = new Set();
    }
    const chKey = String(channelId || '');
    const shared = readSharedClaudePermissionMode(st.__bhfPermSyncOptions);
    const targetMode = shared?.mode || '';
    let effectiveMode = permissionMode;

    const panelOverride = comms?.__bhfPanel?.__bhfLaunchModeOverride || null;
    const stateOverride =
      st.__bhfPendingIdeLaunchMode && Date.now() < Number(st.__bhfPendingIdeLaunchMode.until || 0)
        ? st.__bhfPendingIdeLaunchMode
        : null;
    const launchOverride = panelOverride || stateOverride;
    if (panelOverride && comms?.__bhfPanel) {
      comms.__bhfPanel.__bhfLaunchModeOverride = null;
    }
    if (stateOverride) {
      st.__bhfPendingIdeLaunchMode = null;
    }

    if (
      launchOverride?.mode &&
      (launchOverride.mode !== 'bypassPermissions' ||
        comms.settings?.getAllowDangerouslySkipPermissions?.() !== false)
    ) {
      effectiveMode = launchOverride.mode;
      if (chKey) {
        if (launchOverride.explicit) {
          comms.__bhfSharedPlanChannels.delete(chKey);
          if (sessionId) st.__bhfSharedPlanSessionIds.delete(String(sessionId));
          comms.__bhfUserChosenChannelModes.set(chKey, {
            mode: effectiveMode,
            underSharedMode: targetMode || effectiveMode
          });
        } else if (effectiveMode === 'plan' && targetMode === 'plan') {
          comms.__bhfSharedPlanChannels.add(chKey);
          if (sessionId) st.__bhfSharedPlanSessionIds.add(String(sessionId));
        }
        if (targetMode && effectiveMode === targetMode) {
          comms.__bhfAppliedSharedModeByChannel.set(chKey, targetMode);
        }
      }
    } else if (!sessionId && targetMode) {
      const hostInitMode = String(st.controller?.settings?.getInitialPermissionMode?.() || '');
      const wv = comms?.__bhfPanel?.webview || comms?.webview || null;
      const draftWasSeededWithTarget =
        (st.__bhfConfigSyncedMode === targetMode && hostInitMode === targetMode) ||
        wv?.__bhfAppliedSharedPermMode === targetMode;
      if (
        draftWasSeededWithTarget &&
        typeof permissionMode === 'string' &&
        permissionMode &&
        permissionMode !== targetMode
      ) {
        // Host or webview already seeded this draft tab with targetMode, so permissionMode !== targetMode is a genuine user choice.
        comms.__bhfSharedPlanChannels.delete(chKey);
        comms.__bhfUserChosenChannelModes.set(chKey, {
          mode: permissionMode,
          underSharedMode: targetMode
        });
      } else if (permissionMode === targetMode && chKey) {
        comms.__bhfAppliedSharedModeByChannel.set(chKey, targetMode);
        if (targetMode === 'plan') {
          comms.__bhfSharedPlanChannels.add(chKey);
        } else {
          comms.__bhfSharedPlanChannels.delete(chKey);
        }
      } else if (
        permissionMode !== targetMode &&
        (targetMode !== 'bypassPermissions' ||
          comms.settings?.getAllowDangerouslySkipPermissions?.() !== false)
      ) {
        effectiveMode = targetMode;
        if (chKey) {
          comms.__bhfAppliedSharedModeByChannel.set(chKey, targetMode);
          if (targetMode === 'plan') {
            comms.__bhfSharedPlanChannels.add(chKey);
          } else {
            comms.__bhfSharedPlanChannels.delete(chKey);
          }
        }
      }
    } else if (
      sessionId &&
      targetMode &&
      (permissionMode !== 'plan' || st.__bhfSharedPlanSessionIds.has(String(sessionId))) &&
      permissionMode !== targetMode &&
      comms.__bhfUserChosenChannelModes.get(chKey)?.underSharedMode !== targetMode &&
      (targetMode !== 'bypassPermissions' ||
        comms.settings?.getAllowDangerouslySkipPermissions?.() !== false)
    ) {
      effectiveMode = targetMode;
      if (chKey) {
        comms.__bhfAppliedSharedModeByChannel.set(chKey, targetMode);
        if (targetMode === 'plan') {
          comms.__bhfSharedPlanChannels.add(chKey);
          st.__bhfSharedPlanSessionIds.add(String(sessionId));
        } else {
          comms.__bhfSharedPlanChannels.delete(chKey);
          st.__bhfSharedPlanSessionIds.delete(String(sessionId));
        }
      }
    }

    if (chKey && typeof effectiveMode === 'string' && effectiveMode) {
      comms.__bhfChannelModes.set(chKey, effectiveMode);
    }

    const res = await comms.__bhfOrigLaunchClaude(
      channelId,
      sessionId,
      cwdOrOpts,
      effectiveMode,
      ...rest
    );
    if (effectiveMode && effectiveMode !== permissionMode && chKey) {
      try {
        const sendFn =
          typeof comms.__bhfOrigSend === 'function'
            ? comms.__bhfOrigSend
            : typeof comms.send === 'function'
              ? comms.send.bind(comms)
              : null;
        if (sendFn) {
          sendFn({
            type: 'io_message',
            channelId: chKey,
            message: {
              type: 'system',
              subtype: 'status',
              permissionMode: effectiveMode
            },
            done: false
          });
        }
      } catch {}
    }
    return res;
  };

  if (state.__bhfPermSyncTimer) {
    clearInterval(state.__bhfPermSyncTimer);
    state.__bhfPermSyncTimer = null;
  }
  if (state.__bhfPermCacheWatcher) {
    try {
      state.__bhfPermCacheWatcher.close();
    } catch {}
    state.__bhfPermCacheWatcher = null;
  }
  if (process.env.THEO_SMOKE_TEST !== '1') {
    const t = setInterval(() => {
      syncSharedClaudePermissionMode(state).catch(() => {});
    }, 8000);
    if (typeof t?.unref === 'function') {
      t.unref();
    }
    state.__bhfPermSyncTimer = t;
    try {
      const homeDir = String(process.env.THEO_GUARD_HOME || os.homedir() || '').trim();
      const claudeDir = homeDir ? path.join(homeDir, '.claude') : '';
      if (claudeDir && fs.existsSync(claudeDir)) {
        let debounce = null;
        const watcher = fs.watch(claudeDir, (_evt, fname) => {
          if (fname && String(fname) !== '.theo-claude-permission-mode.json') return;
          if (debounce) clearTimeout(debounce);
          debounce = setTimeout(() => {
            debounce = null;
            syncSharedClaudePermissionMode(state).catch(() => {});
          }, 35);
          if (typeof debounce?.unref === 'function') debounce.unref();
        });
        watcher.on('error', () => {});
        if (typeof watcher.unref === 'function') watcher.unref();
        state.__bhfPermCacheWatcher = watcher;
      }
    } catch {}
    syncSharedClaudePermissionMode(state).catch(() => {});
  }
}

// Unsent text in this window's Claude Code chat boxes, for the hands-free reload (auto-reload.js).
// Every chat tab's webview reports on change and at least every 90 s. A chat tab that has not reported within
// ttlMs (an old webview loaded before the patch, or one whose report channel broke) makes the answer unknown
// (`ok: false`), so the reload waits. The sidebar chat counts only once it has reported at all.
// Returns { ok, drafts, reporting, silent }.
function getClaudeDraftSnapshot(options = {}) {
  const ttlMs = Number(options.ttlMs) > 0 ? Number(options.ttlMs) : 5 * 60 * 1000;
  const now = Number(options.now || Date.now());
  const details = Boolean(options.details);
  const state = options.state || getBridgeState();
  const controller = state?.controller;
  // Not attached: no chat tab is visible to the bridge. The caller decides (auto-reload.js readClaudeDrafts).
  if (!controller) {
    return details
      ? {
          ok: true,
          drafts: 0,
          reporting: 0,
          silent: 0,
          attached: false,
          draftSessionIds: [],
          silentSessionIds: [],
          reportingSessionIds: [],
          hasAnonymousSilentOrDraft: false
        }
      : { ok: true, drafts: 0, reporting: 0, silent: 0, attached: false };
  }
  const required = new Set();
  const panelMetaByComms = new Map();
  try {
    if (controller.panelComms instanceof Map) {
      for (const [panel, c] of controller.panelComms.entries()) {
        if (!c) continue;
        if (!c.__bhfHookedFromClient) hookCommsObject(state, c, panel || null);
        required.add(c);
        if (details) {
          const sid =
            resolveSessionIdForComms(controller, c, '', panel || null) ||
            String(panel?.__bhfSessionId || '').trim();
          panelMetaByComms.set(c, { isPanel: true, sid });
        }
      }
    }
    // The sidebar chat must report too: someone who works only there would otherwise lose a draft.
    if (controller.sidebarComms) {
      const c = controller.sidebarComms;
      if (!c.__bhfHookedFromClient) hookCommsObject(state, c, null);
      required.add(c);
      if (details && !panelMetaByComms.has(c)) {
        panelMetaByComms.set(c, { isPanel: false, sid: '' });
      }
    }
  } catch {
    return details
      ? {
          ok: false,
          drafts: 0,
          reporting: 0,
          silent: 0,
          attached: true,
          draftSessionIds: [],
          silentSessionIds: [],
          reportingSessionIds: [],
          hasAnonymousSilentOrDraft: true
        }
      : { ok: false, drafts: 0, reporting: 0, silent: 0, attached: true };
  }
  let drafts = 0;
  let reporting = 0;
  let silent = 0;
  const draftSessionSet = new Set();
  const silentSessionSet = new Set();
  const reportingSessionSet = new Set();
  let hasAnonymousSilentOrDraft = false;
  for (const c of required) {
    const rep = c && c.__bhfDraftReport;
    const meta = details ? panelMetaByComms.get(c) : null;
    if (rep && now - Number(rep.at || 0) <= ttlMs) {
      reporting += 1;
      if (meta?.isPanel && meta.sid) {
        reportingSessionSet.add(meta.sid);
      }
      if (rep.has) {
        drafts += 1;
        if (meta?.isPanel) {
          if (meta.sid) draftSessionSet.add(meta.sid);
          else hasAnonymousSilentOrDraft = true;
        }
      }
    } else {
      silent += 1;
      if (meta?.isPanel) {
        if (meta.sid) silentSessionSet.add(meta.sid);
        else hasAnonymousSilentOrDraft = true;
      }
    }
  }
  if (!details) {
    return { ok: silent === 0, drafts, reporting, silent, attached: true };
  }
  return {
    ok: silent === 0,
    drafts,
    reporting,
    silent,
    attached: true,
    draftSessionIds: Array.from(draftSessionSet),
    silentSessionIds: Array.from(silentSessionSet),
    reportingSessionIds: Array.from(reportingSessionSet),
    hasAnonymousSilentOrDraft
  };
}

function hotUpgradeLiveState() {
  const state = getBridgeState();
  registerBridgeCommands(state);
  installClaudeOpenFileSupport(state);
  const { controller } = state;
  if (!state.removeFromGroupCommandRegistered && state.vscode?.commands && state.context) {
    state.removeFromGroupCommandRegistered = true;
    try {
      state.context.subscriptions.push(
        state.vscode.commands.registerCommand(
          'antigravityHub.claudeRemoveFromGroup',
          async (options = {}) => removeSessionsFromClaudeGroups(state, options)
        )
      );
    } catch {}
  }
  if (!state.syncPermModeCommandRegistered && state.vscode?.commands && state.context) {
    state.syncPermModeCommandRegistered = true;
    try {
      state.context.subscriptions.push(
        state.vscode.commands.registerCommand(
          'antigravityHub.claudeSyncPermissionMode',
          async (options = {}) =>
            (state.__cmdHandlers?.syncSharedClaudePermissionMode || syncSharedClaudePermissionMode)(
              state,
              options
            )
        )
      );
    } catch {}
  }
  if (!controller) return false;
  if (controller.sessionPanels instanceof Map) {
    for (const panel of controller.sessionPanels.values()) {
      ensurePanelHooked(state, panel);
    }
  }
  if (controller.panelComms instanceof Map) {
    for (const [panel, c] of controller.panelComms.entries()) {
      if (c && panel) c.__bhfPanel = panel;
      ensurePanelHooked(state, panel);
      hookCommsObject(state, c, panel);
    }
  }
  if (controller.allComms instanceof Set) {
    for (const c of controller.allComms) {
      hookCommsObject(state, c, c?.__bhfPanel || null);
    }
  }
  ensurePermissionSyncSupport(state);
  return true;
}

module.exports = {
  BRIDGE_VERSION,
  CLAUDE_DRAFT_SCHEME,
  attach,
  getBridgeState,
  getClaudeDraftSnapshot,
  hookCommsObject,
  readPanelViewColumnSafe,
  attachClaudeFastCloseListener,
  hotUpgradeLiveState,
  getLiveSnapshot,
  getOpenClaudeTabsSnapshot,
  getPrewarmedClaudeTabsSnapshot,
  getPendingPermissionsSnapshot,
  openClaudeTab,
  closeClaudeTab,
  syncClaudeTabBadges,
  applyPanelTabIcon,
  respondClaudePermission,
  sendPromptToClaude,
  interruptClaudeSession,
  reviveRememberedClaudeTabs,
  removeSessionsFromClaudeGroups,
  readSharedClaudePermissionMode,
  syncSharedClaudePermissionMode,
  ensurePermissionSyncSupport,
  isClaudeDesktopScratchSessionSync,
  recordPrewarmTelemetryWarmed,
  recordPrewarmTelemetryHit,
  recordPrewarmTelemetryEvicted,
  recordPrewarmTelemetryColdOpen,
  promotePrewarmedClaudePanel,
  evictPrewarmedClaudePanel
};

