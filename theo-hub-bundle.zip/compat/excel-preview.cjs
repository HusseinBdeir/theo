'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { execFile } = require('child_process');

const EXCEL_PREVIEW_VIEW_TYPE = 'theoHub.excelPreview';
const EXCEL_HTML_RENDER_VERSION = 2;
const EXCEL_PANEL_CACHE_SYMBOL = Symbol.for('bhfirms.theoHub.excelPanelsByPath');
const EXCEL_PROVIDER_STATE_SYMBOL = Symbol.for('bhfirms.theoHub.excelProviderState');

const DELIVERABLE_PREVIEW_VIEW_TYPE = 'theoHub.deliverablePreview';
const DELIVERABLE_HTML_RENDER_VERSION = 1;
const DELIVERABLE_PANEL_CACHE_SYMBOL = Symbol.for('bhfirms.theoHub.deliverablePanelsByPath');
const DELIVERABLE_PROVIDER_STATE_SYMBOL = Symbol.for('bhfirms.theoHub.deliverableProviderState');
const DELIVERABLE_INFLIGHT_SYMBOL = Symbol.for('bhfirms.theoHub.deliverableInFlight');

const SPREADSHEET_EXT_RE = /\.(xlsx|xlsm|xls|xlsb|ods)$/i;
const HTML_DELIVERABLE_EXT_RE = /\.(html?|xhtml)$/i;
const PDF_DELIVERABLE_EXT_RE = /\.pdf$/i;
const PPTX_DELIVERABLE_EXT_RE = /\.(pptx|ppsx|pptm)$/i;
const DELIVERABLE_EXT_RE = /\.(html?|xhtml|pdf|pptx|ppsx|pptm)$/i;
const VSCODE_OPEN_BINARY_EXT_RE = /\.(png|jpe?g|gif|webp|bmp|ico|cur|avif|mp4|webm|mov|mp3|wav|ogg|flac|woff2?|ttf|otf)$/i;
const DIRECT_EXTERNAL_OFFICE_EXT_RE = /\.(docx?|vsdx?|msg)$/i;
const EXTERNAL_OFFICE_EXT_RE = /\.(docx?|pptx?|vsdx?|msg)$/i;

function getOpenPanelsMap() {
  if (!globalThis[EXCEL_PANEL_CACHE_SYMBOL]) {
    globalThis[EXCEL_PANEL_CACHE_SYMBOL] = new Map();
  }
  return globalThis[EXCEL_PANEL_CACHE_SYMBOL];
}

function getProviderState() {
  if (!globalThis[EXCEL_PROVIDER_STATE_SYMBOL]) {
    globalThis[EXCEL_PROVIDER_STATE_SYMBOL] = {
      customEditorRegistered: false,
      commandRegistered: false,
      renderImpl: null
    };
  }
  return globalThis[EXCEL_PROVIDER_STATE_SYMBOL];
}

function normalizeFilePathFromUri(vscode, rawUriOrPath) {
  if (!rawUriOrPath) return '';
  if (typeof rawUriOrPath === 'object' && typeof rawUriOrPath.fsPath === 'string') {
    return rawUriOrPath.fsPath;
  }
  const str = String(rawUriOrPath || '').trim();
  if (!str) return '';

  if (/^file:\/\//i.test(str)) {
    try {
      if (vscode?.Uri?.parse) {
        const parsed = vscode.Uri.parse(str);
        if (parsed?.fsPath) {
          let p = parsed.fsPath;
          if (/%[0-9A-Fa-f]{2}/.test(p) && !fs.existsSync(p)) {
            try {
              const decoded = decodeURIComponent(p);
              if (fs.existsSync(decoded)) p = decoded;
            } catch {}
          }
          return p;
        }
      }
    } catch {}
    try {
      const u = new URL(str);
      let p = decodeURIComponent(u.pathname || '');
      if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
      return p.replace(/\//g, path.sep);
    } catch {}
  }

  return str;
}

// ---------------------------------------------------------------------------
// Minimal Zero-Dependency ZIP Central-Directory Reader + OOXML (.xlsx/.xlsm) Parser
// ---------------------------------------------------------------------------

function readZipEntries(buf) {
  const entries = new Map();
  if (!Buffer.isBuffer(buf) || buf.length < 22) {
    return entries;
  }
  if (buf.readUInt32LE(0) !== 0x04034b50) {
    return entries;
  }

  // Locate End of Central Directory (0x06054b50)
  const minPos = Math.max(0, buf.length - 65558);
  let eocd = -1;
  for (let i = buf.length - 22; i >= minPos; i -= 1) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) {
    return entries;
  }

  const totalEntries = buf.readUInt16LE(eocd + 10);
  const cdOffset = buf.readUInt32LE(eocd + 16);
  let ptr = cdOffset;

  for (let idx = 0; idx < totalEntries && ptr + 46 <= buf.length; idx += 1) {
    if (buf.readUInt32LE(ptr) !== 0x02014b50) break;
    const compMethod = buf.readUInt16LE(ptr + 10);
    const compSize = buf.readUInt32LE(ptr + 20);
    const uncompSize = buf.readUInt32LE(ptr + 24);
    const nameLen = buf.readUInt16LE(ptr + 28);
    const extraLen = buf.readUInt16LE(ptr + 30);
    const commentLen = buf.readUInt16LE(ptr + 32);
    const localOffset = buf.readUInt32LE(ptr + 42);
    const rawName = buf.toString('utf8', ptr + 46, ptr + 46 + nameLen);
    const normName = rawName.replace(/^\/+/, '').replace(/\\/g, '/');
    ptr += 46 + nameLen + extraLen + commentLen;

    if (localOffset + 30 > buf.length) continue;
    if (buf.readUInt32LE(localOffset) !== 0x04034b50) continue;
    const localNameLen = buf.readUInt16LE(localOffset + 26);
    const localExtraLen = buf.readUInt16LE(localOffset + 28);
    const dataStart = localOffset + 30 + localNameLen + localExtraLen;

    entries.set(normName, () => {
      if (compMethod === 0) {
        return buf.subarray(dataStart, dataStart + uncompSize);
      }
      if (compMethod === 8) {
        return zlib.inflateRawSync(buf.subarray(dataStart, dataStart + compSize));
      }
      throw new Error(`Unsupported ZIP compression method ${compMethod}`);
    });
  }
  return entries;
}

function readZipText(entries, entryPath) {
  const clean = String(entryPath || '').replace(/^\/+/, '').replace(/\\/g, '/');
  let getter = entries.get(clean);
  if (!getter) {
    const lower = clean.toLowerCase();
    for (const [k, v] of entries.entries()) {
      if (k.toLowerCase() === lower) {
        getter = v;
        break;
      }
    }
  }
  if (!getter) return '';
  return getter().toString('utf8');
}

function decodeXmlText(raw) {
  if (!raw) return '';
  return String(raw)
    .replace(/_x([0-9A-Fa-f]{4})_/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/&#x([0-9A-Fa-f]+);/g, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, dec) => String.fromCodePoint(parseInt(dec, 10)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

function parseXmlAttrs(attrStr) {
  const attrs = {};
  if (!attrStr) return attrs;
  const re = /([A-Za-z0-9_:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
  let m;
  while ((m = re.exec(attrStr)) !== null) {
    attrs[m[1]] = decodeXmlText(m[2] !== undefined ? m[2] : m[3]);
  }
  return attrs;
}

function colLettersToIndex(letters) {
  let n = 0;
  for (let i = 0; i < letters.length; i += 1) {
    n = n * 26 + (letters.charCodeAt(i) - 64);
  }
  return n - 1; // 0-based
}

function indexToColLetters(idx) {
  let n = idx + 1;
  let out = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    out = String.fromCharCode(65 + rem) + out;
    n = Math.floor((n - 1) / 26);
  }
  return out;
}

function parseCellRef(ref) {
  const m = /^([A-Za-z]+)(\d+)$/.exec(String(ref || '').trim());
  if (!m) return null;
  return {
    col: colLettersToIndex(m[1].toUpperCase()),
    row: parseInt(m[2], 10) - 1
  };
}

function parseRangeRef(ref) {
  const parts = String(ref || '').split(':');
  const start = parseCellRef(parts[0]);
  const end = parts[1] ? parseCellRef(parts[1]) : start;
  if (!start || !end) return null;
  return {
    r1: Math.min(start.row, end.row),
    c1: Math.min(start.col, end.col),
    r2: Math.max(start.row, end.row),
    c2: Math.max(start.col, end.col)
  };
}

function parseSharedStrings(xml) {
  if (!xml) return [];
  const out = [];
  const siRe = /<si\b[^>]*>([\s\S]*?)<\/si>/g;
  let m;
  while ((m = siRe.exec(xml)) !== null) {
    // Strip phonetic <rPh>...</rPh> blocks
    const body = m[1].replace(/<rPh\b[^>]*>[\s\S]*?<\/rPh>/g, '');
    const tRe = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g;
    let tm;
    let combined = '';
    while ((tm = tRe.exec(body)) !== null) {
      combined += decodeXmlText(tm[1]);
    }
    out.push(combined);
  }
  return out;
}

const BUILTIN_NUM_FMTS = {
  0: 'General',
  1: '0',
  2: '0.00',
  3: '#,##0',
  4: '#,##0.00',
  9: '0%',
  10: '0.00%',
  11: '0.00E+00',
  14: 'dd-mm-yy',
  15: 'd-mmm-yy',
  16: 'd-mmm',
  17: 'mmm-yy',
  18: 'h:mm AM/PM',
  19: 'h:mm:ss AM/PM',
  20: 'h:mm',
  21: 'h:mm:ss',
  22: 'dd-mm-yy h:mm',
  37: '#,##0 ;(#,##0)',
  38: '#,##0 ;[Red](#,##0)',
  39: '#,##0.00;(#,##0.00)',
  40: '#,##0.00;[Red](#,##0.00)',
  44: '$#,##0.00',
  45: 'mm:ss',
  46: '[h]:mm:ss',
  47: 'mmss.0',
  49: '@'
};

function classifyNumFmt(numFmtId, rawCode) {
  const code = String(rawCode || BUILTIN_NUM_FMTS[numFmtId] || 'General');
  if (
    (numFmtId >= 14 && numFmtId <= 22) ||
    (numFmtId >= 27 && numFmtId <= 36) ||
    (numFmtId >= 45 && numFmtId <= 47)
  ) {
    return { code, kind: 'date' };
  }
  if (numFmtId === 9 || numFmtId === 10) {
    return { code, kind: 'percent' };
  }
  const firstSection = code.split(';')[0] || '';
  const stripped = firstSection
    .replace(/"[^"]*"/g, '')
    .replace(/\\./g, '')
    .replace(/\[[^\]]*\]/g, '');
  if (stripped.includes('%')) {
    return { code, kind: 'percent' };
  }
  if (/[dmyhs]/i.test(stripped) && !/[#0]/.test(stripped)) {
    return { code, kind: 'date' };
  }
  const hasDollar = /\$/.test(firstSection);
  const hasComma = stripped.includes(',');
  const decMatch = /\.(0+)/.exec(stripped);
  const decimals = decMatch ? decMatch[1].length : null;
  return {
    code,
    kind: hasDollar ? 'currency' : hasComma || decimals !== null ? 'number' : 'general',
    decimals,
    hasComma
  };
}

function parseStyles(xml) {
  const customFmts = new Map();
  const fontsBold = [];
  const cellXfs = [];

  if (!xml) return { cellXfs };

  const nfRe = /<numFmt\b([^>]*)\/?>/g;
  let m;
  while ((m = nfRe.exec(xml)) !== null) {
    const a = parseXmlAttrs(m[1]);
    if (a.numFmtId !== undefined && a.formatCode !== undefined) {
      customFmts.set(Number(a.numFmtId), a.formatCode);
    }
  }

  const fontsBlock = /<fonts\b[^>]*>([\s\S]*?)<\/fonts>/.exec(xml);
  if (fontsBlock) {
    const fRe = /<font\b[^>]*>([\s\S]*?)<\/font>/g;
    let fm;
    while ((fm = fRe.exec(fontsBlock[1])) !== null) {
      const isBold = /<b(?:\s+val="(?:1|true)")?\s*\/?>/i.test(fm[1]) && !/<b\s+val="(?:0|false)"/i.test(fm[1]);
      fontsBold.push(isBold);
    }
  }

  const xfsBlock = /<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/.exec(xml);
  if (xfsBlock) {
    const xfRe = /<xf\b([^>/]*)(?:\/>|>[\s\S]*?<\/xf>)/g;
    let xm;
    while ((xm = xfRe.exec(xfsBlock[1])) !== null) {
      const a = parseXmlAttrs(xm[1]);
      const numFmtId = Number(a.numFmtId || 0);
      const fontId = Number(a.fontId || 0);
      const fmtCode = customFmts.get(numFmtId) || BUILTIN_NUM_FMTS[numFmtId] || 'General';
      cellXfs.push({
        numFmtId,
        bold: Boolean(fontsBold[fontId]),
        ...classifyNumFmt(numFmtId, fmtCode)
      });
    }
  }

  return { cellXfs };
}

const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatExcelDate(serial, code, is1904) {
  const num = Number(serial);
  if (!Number.isFinite(num)) return String(serial);
  const baseDays = is1904 ? num + 1462 : num < 60 ? num + 1 : num;
  const utcMs = Date.UTC(1899, 11, 30) + Math.round(baseDays * 86400000);
  const dt = new Date(utcMs);
  if (Number.isNaN(dt.getTime())) return String(serial);

  const yyyy = dt.getUTCFullYear();
  const yy = String(yyyy).slice(-2);
  const m = dt.getUTCMonth() + 1;
  const mm = String(m).padStart(2, '0');
  const mmm = MONTH_SHORT[m - 1];
  const d = dt.getUTCDate();
  const dd = String(d).padStart(2, '0');
  const lc = String(code || '').toLowerCase();

  if (lc.includes('mmm') && lc.includes('yyyy')) {
    return `${dd}-${mmm}-${yyyy}`;
  }
  if (lc.includes('mmm')) {
    return `${dd}-${mmm}-${yy}`;
  }
  if (lc.includes('yyyy-mm-dd') || lc.includes('yyyy/mm/dd')) {
    return `${yyyy}-${mm}-${dd}`;
  }
  if (lc.includes('h:mm')) {
    const hh = String(dt.getUTCHours()).padStart(2, '0');
    const mi = String(dt.getUTCMinutes()).padStart(2, '0');
    if (num < 1) return `${hh}:${mi}`;
    return `${dd}-${mm}-${yy} ${hh}:${mi}`;
  }
  return `${dd}-${mm}-${yy}`;
}

function formatExcelNumber(num, xf) {
  if (!Number.isFinite(num)) return String(num);
  // Clean IEEE-754 representation dust (e.g. 4406.5999999999985 -> 4406.6)
  const cleaned = Math.abs(num) < 1e12 ? Number(num.toPrecision(12)) : num;

  if (!xf || xf.kind === 'general') {
    if (Number.isInteger(cleaned)) {
      return String(cleaned);
    }
    return String(Number(cleaned.toFixed(6)));
  }
  if (xf.kind === 'percent') {
    const dec = xf.decimals !== null ? xf.decimals : 1;
    return `${(cleaned * 100).toFixed(dec).replace(/\.0+$/, '')}%`;
  }
  if (xf.kind === 'currency') {
    const dec = xf.decimals !== null ? xf.decimals : Number.isInteger(cleaned) ? 0 : 2;
    const absStr = Math.abs(cleaned).toLocaleString('en-US', {
      minimumFractionDigits: dec,
      maximumFractionDigits: dec
    });
    return cleaned < 0 ? `($${absStr})` : `$${absStr}`;
  }
  if (xf.kind === 'number') {
    const dec = xf.decimals !== null ? xf.decimals : Number.isInteger(cleaned) ? 0 : 2;
    return cleaned.toLocaleString('en-US', {
      useGrouping: Boolean(xf.hasComma),
      minimumFractionDigits: dec,
      maximumFractionDigits: dec
    });
  }
  return String(cleaned);
}

function resolveRelTarget(baseDir, target) {
  if (!target) return '';
  const clean = String(target).replace(/\\/g, '/');
  if (clean.startsWith('/')) return clean.slice(1);
  return path.posix.normalize(path.posix.join(baseDir, clean));
}

function parseRelsMap(xml, baseDir) {
  const map = new Map();
  if (!xml) return map;
  const relRe = /<Relationship\b([^>]*)\/?>/g;
  let m;
  while ((m = relRe.exec(xml)) !== null) {
    const a = parseXmlAttrs(m[1]);
    if (a.Id && a.Target) {
      map.set(a.Id, resolveRelTarget(baseDir, a.Target));
    }
  }
  return map;
}

function parseWorksheet(sheetXml, sheetRelsXml, entries, sharedStrings, styles, is1904) {
  const colWidths = {};
  const colBlock = /<cols\b[^>]*>([\s\S]*?)<\/cols>/.exec(sheetXml);
  if (colBlock) {
    const cRe = /<col\b([^>]*)\/?>/g;
    let cm;
    while ((cm = cRe.exec(colBlock[1])) !== null) {
      const a = parseXmlAttrs(cm[1]);
      const minC = Math.max(1, Number(a.min || 1));
      const maxC = Math.min(256, Number(a.max || minC));
      const w = Number(a.width || 0);
      if (w > 0) {
        for (let c = minC; c <= maxC; c += 1) {
          colWidths[c - 1] = w;
        }
      }
    }
  }

  // Detect Excel Tables on this sheet
  const tables = [];
  if (sheetRelsXml) {
    const sRels = parseRelsMap(sheetRelsXml, 'xl/worksheets');
    const tpRe = /<tablePart\b([^>]*)\/?>/g;
    let tm;
    while ((tm = tpRe.exec(sheetXml)) !== null) {
      const a = parseXmlAttrs(tm[1]);
      const rid = a['r:id'] || a.id;
      const tblPath = rid ? sRels.get(rid) : '';
      if (tblPath) {
        const tblXml = readZipText(entries, tblPath);
        const tblTag = /<table\b([^>]*)>/.exec(tblXml);
        const styleTag = /<tableStyleInfo\b([^>]*)\/?>/.exec(tblXml);
        if (tblTag) {
          const ta = parseXmlAttrs(tblTag[1]);
          const sa = styleTag ? parseXmlAttrs(styleTag[1]) : {};
          const rng = parseRangeRef(ta.ref);
          if (rng) {
            tables.push({
              name: ta.displayName || ta.name || 'Table',
              ref: ta.ref,
              styleName: sa.name || 'TableStyleMedium2',
              rowStripes: sa.showRowStripes !== '0',
              ...rng
            });
          }
        }
      }
    }
  }

  // Detect merged cells
  const merges = [];
  const mergeBlock = /<mergeCells\b[^>]*>([\s\S]*?)<\/mergeCells>/.exec(sheetXml);
  if (mergeBlock) {
    const mRe = /<mergeCell\b([^>]*)\/?>/g;
    let mm;
    while ((mm = mRe.exec(mergeBlock[1])) !== null) {
      const a = parseXmlAttrs(mm[1]);
      const rng = parseRangeRef(a.ref);
      if (rng) merges.push(rng);
    }
  }

  const rowMap = new Map();
  let maxRow = -1;
  let maxCol = -1;

  const rowRe = /<row\b([^>/]*)(?:\/>|>([\s\S]*?)<\/row>)/g;
  let rm;
  let nextFallbackRow = 0;
  while ((rm = rowRe.exec(sheetXml)) !== null) {
    const ra = parseXmlAttrs(rm[1]);
    const rIdx = ra.r ? parseInt(ra.r, 10) - 1 : nextFallbackRow;
    nextFallbackRow = rIdx + 1;
    if (!rm[2]) continue;

    const cellRe = /<c\b([^>/]*)(?:\/>|>([\s\S]*?)<\/c>)/g;
    let cm;
    let nextFallbackCol = 0;
    const cells = new Map();

    while ((cm = cellRe.exec(rm[2])) !== null) {
      const ca = parseXmlAttrs(cm[1]);
      const inner = cm[2] || '';
      const pos = ca.r ? parseCellRef(ca.r) : null;
      const cIdx = pos ? pos.col : nextFallbackCol;
      nextFallbackCol = cIdx + 1;

      const cType = ca.t || '';
      const sIdx = ca.s !== undefined ? Number(ca.s) : -1;
      const xf = sIdx >= 0 ? styles.cellXfs[sIdx] : null;

      const fMatch = /<f(?:\s[^>]*)?>([\s\S]*?)<\/f>/.exec(inner);
      const formula = fMatch ? decodeXmlText(fMatch[1]) : '';
      const vMatch = /<v(?:\s[^>]*)?>([\s\S]*?)<\/v>/.exec(inner);
      const rawV = vMatch ? vMatch[1] : null;

      let text = '';
      let numVal = null;
      let align = 'left';

      if (cType === 's') {
        const sId = rawV !== null ? parseInt(rawV, 10) : -1;
        text = sId >= 0 && sId < sharedStrings.length ? sharedStrings[sId] : '';
      } else if (cType === 'inlineStr') {
        const tRe = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g;
        let tm2;
        while ((tm2 = tRe.exec(inner)) !== null) {
          text += decodeXmlText(tm2[1]);
        }
      } else if (cType === 'str' || cType === 'e') {
        text = rawV !== null ? decodeXmlText(rawV) : '';
      } else if (cType === 'b') {
        text = rawV === '1' || rawV === 'true' ? 'TRUE' : 'FALSE';
        align = 'center';
      } else if (rawV !== null && rawV !== '') {
        const parsedNum = Number(rawV);
        if (Number.isFinite(parsedNum)) {
          if (xf && xf.kind === 'date') {
            text = formatExcelDate(parsedNum, xf.code, is1904);
          } else {
            numVal = Math.abs(parsedNum) < 1e12 ? Number(parsedNum.toPrecision(12)) : parsedNum;
            text = formatExcelNumber(parsedNum, xf);
            align = 'right';
          }
        } else {
          text = decodeXmlText(rawV);
        }
      }

      if (text !== '' || formula !== '' || (xf && xf.bold)) {
        cells.set(cIdx, {
          t: text,
          n: numVal,
          f: formula ? (formula.startsWith('=') ? formula : `=${formula}`) : '',
          b: Boolean(xf?.bold),
          a: align
        });
        if (rIdx > maxRow) maxRow = rIdx;
        if (cIdx > maxCol) maxCol = cIdx;
      }
    }

    if (cells.size > 0) {
      rowMap.set(rIdx, cells);
    }
  }

  for (const tbl of tables) {
    if (tbl.r2 > maxRow) maxRow = tbl.r2;
    if (tbl.c2 > maxCol) maxCol = tbl.c2;
  }

  const rowCount = Math.min(Math.max(maxRow + 1, 0), 5000);
  const colCount = Math.min(Math.max(maxCol + 1, 0), 120);
  const grid = [];
  for (let r = 0; r < rowCount; r += 1) {
    const rCells = rowMap.get(r);
    const rowArr = new Array(colCount);
    for (let c = 0; c < colCount; c += 1) {
      rowArr[c] = rCells?.get(c) || null;
    }
    grid.push(rowArr);
  }

  return {
    rowCount,
    colCount,
    totalRowsInSheet: maxRow + 1,
    truncated: maxRow + 1 > rowCount,
    colWidths,
    tables,
    merges,
    grid
  };
}

function parseCsvText(rawText, delimiter = ',') {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  for (let i = 0; i < rawText.length; i += 1) {
    const ch = rawText[i];
    if (inQuotes) {
      if (ch === '"') {
        if (rawText[i + 1] === '"') {
          field += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === delimiter) {
      row.push(field);
      field = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && rawText[i + 1] === '\n') i += 1;
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else {
      field += ch;
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  const colCount = rows.reduce((m, r) => Math.max(m, r.length), 0);
  const cappedRows = rows.slice(0, 5000);
  const grid = cappedRows.map((r, rIdx) => {
    const arr = new Array(colCount);
    for (let c = 0; c < colCount; c += 1) {
      const v = r[c] !== undefined ? r[c] : '';
      const trimmed = v.trim();
      const num = trimmed !== '' && /^-?\d+(\.\d+)?$/.test(trimmed) ? Number(trimmed) : null;
      arr[c] = v === '' ? null : { t: v, n: num, f: '', b: rIdx === 0, a: num !== null ? 'right' : 'left' };
    }
    return arr;
  });
  return {
    name: 'Sheet1',
    rowCount: grid.length,
    colCount,
    totalRowsInSheet: rows.length,
    truncated: rows.length > grid.length,
    colWidths: {},
    tables: grid.length > 1 ? [{ name: 'CSV', r1: 0, c1: 0, r2: grid.length - 1, c2: colCount - 1, rowStripes: true }] : [],
    merges: [],
    grid
  };
}

function readWorkbookBufferSafe(filePath) {
  try {
    return fs.readFileSync(filePath);
  } catch (err) {
    if (process.platform === 'win32' && err && (err.code === 'EBUSY' || err.code === 'EPERM' || err.code === 'EACCES')) {
      const os = require('os');
      const cp = require('child_process');
      const tmpCopy = path.join(os.tmpdir(), `theo-wb-${ process.pid }-${ Date.now() }${ path.extname(filePath) }`);
      try {
        cp.execFileSync('cmd.exe', ['/d', '/s', '/c', 'copy', '/y', '/b', filePath, tmpCopy], {
          windowsHide: true,
          stdio: 'ignore',
          timeout: 5000
        });
        return fs.readFileSync(tmpCopy);
      } finally {
        try {
          fs.unlinkSync(tmpCopy);
        } catch {}
      }
    }
    throw err;
  }
}

function parseSpreadsheetFile(filePath) {
  const stat = fs.statSync(filePath);
  const ext = path.extname(filePath).toLowerCase();

  if (ext === '.csv' || ext === '.tsv') {
    const raw = readWorkbookBufferSafe(filePath).toString('utf8');
    const sheet = parseCsvText(raw, ext === '.tsv' ? '\t' : ',');
    return {
      fileName: path.basename(filePath),
      filePath,
      fileSize: stat.size,
      mtimeMs: stat.mtimeMs,
      sheets: [sheet]
    };
  }

  const buf = readWorkbookBufferSafe(filePath);
  const entries = readZipEntries(buf);
  if (entries.size === 0) {
    return {
      fileName: path.basename(filePath),
      filePath,
      fileSize: stat.size,
      mtimeMs: stat.mtimeMs,
      unsupportedBinary: true,
      sheets: []
    };
  }

  const wbXml = readZipText(entries, 'xl/workbook.xml');
  const wbRelsXml = readZipText(entries, 'xl/_rels/workbook.xml.rels');
  const sharedStrings = parseSharedStrings(readZipText(entries, 'xl/sharedStrings.xml'));
  const styles = parseStyles(readZipText(entries, 'xl/styles.xml'));
  const is1904 = /<workbookPr\b[^>]*\bdate1904="(?:1|true)"/i.test(wbXml);
  const wbRels = parseRelsMap(wbRelsXml, 'xl');

  const sheetDefs = [];
  const shRe = /<sheet\b([^>]*)\/?>/g;
  let sm;
  while ((sm = shRe.exec(wbXml)) !== null) {
    const a = parseXmlAttrs(sm[1]);
    if (a.state === 'veryHidden') continue;
    const rid = a['r:id'] || a.id;
    const target = rid ? wbRels.get(rid) : '';
    if (target) {
      sheetDefs.push({
        name: a.name || `Sheet${sheetDefs.length + 1}`,
        target
      });
    }
  }

  const sheets = sheetDefs.map((sd) => {
    const sXml = readZipText(entries, sd.target);
    const relsPath = path.posix.join(
      path.posix.dirname(sd.target),
      '_rels',
      `${path.posix.basename(sd.target)}.rels`
    );
    const sRelsXml = readZipText(entries, relsPath);
    const parsed = parseWorksheet(sXml, sRelsXml, entries, sharedStrings, styles, is1904);
    return {
      name: sd.name,
      ...parsed
    };
  });

  return {
    fileName: path.basename(filePath),
    filePath,
    fileSize: stat.size,
    mtimeMs: stat.mtimeMs,
    sheets
  };
}

// ---------------------------------------------------------------------------
// Interactive VS Code Spreadsheet Webview HTML Builder
// ---------------------------------------------------------------------------

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderInitialSheetMarkup(workbookData, activeIdx = 0) {
  const sheets = Array.isArray(workbookData?.sheets) ? workbookData.sheets : [];
  const tabsHtml = sheets
    .map(
      (s, idx) =>
        `<div class="tab${idx === activeIdx ? ' active' : ''}" data-idx="${idx}">${escapeHtml(s.name)}</div>`
    )
    .join('');

  if (workbookData?.unsupportedBinary) {
    return {
      dimsText: 'Legacy binary format',
      fxText: '',
      tabsHtml,
      gridHtml:
        '<div class="empty-state"><p>Legacy binary spreadsheet format. Click <strong>Open in Excel</strong> above to view.</p></div>'
    };
  }

  const sh = sheets[activeIdx];
  if (!sh || sh.rowCount === 0 || sh.colCount === 0) {
    return {
      dimsText: 'Empty sheet',
      fxText: '',
      tabsHtml,
      gridHtml: '<div class="empty-state">This worksheet is empty.</div>'
    };
  }

  const dimsText = `${sh.rowCount} rows × ${sh.colCount} cols${sh.truncated ? ' (preview)' : ''}`;
  const anchorCell = sh.grid?.[0]?.[0] || null;
  const fxText = anchorCell
    ? anchorCell.f
      ? `${anchorCell.f}   [${anchorCell.t}]`
      : String(anchorCell.t || '')
    : '';

  const primaryTbl = sh.tables && sh.tables[0] ? sh.tables[0] : null;
  const mergeSpan = new Map();
  const mergeSkip = new Set();
  for (const m of sh.merges || []) {
    const rs = m.r2 - m.r1 + 1;
    const cs = m.c2 - m.c1 + 1;
    if (rs > 1 || cs > 1) {
      mergeSpan.set(`${m.r1}:${m.c1}`, { rs, cs });
      for (let rr = m.r1; rr <= m.r2; rr += 1) {
        for (let cc = m.c1; cc <= m.c2; cc += 1) {
          if (rr !== m.r1 || cc !== m.c1) mergeSkip.add(`${rr}:${cc}`);
        }
      }
    }
  }

  let gridHtml = '<table class="sheet"><colgroup><col style="width:42px">';
  for (let c = 0; c < sh.colCount; c += 1) {
    const excelW = sh.colWidths && sh.colWidths[c] ? sh.colWidths[c] : 12;
    const px = Math.max(58, Math.min(340, Math.round(excelW * 8.2 + 12)));
    gridHtml += `<col style="width:${px}px">`;
  }
  gridHtml += '</colgroup><thead><tr><th class="corner"></th>';
  for (let c = 0; c < sh.colCount; c += 1) {
    gridHtml += `<th class="col-hdr">${indexToColLetters(c)}</th>`;
  }
  gridHtml += '</tr></thead><tbody>';

  for (let r = 0; r < sh.rowCount; r += 1) {
    const rowArr = sh.grid[r] || [];
    const firstCellText = rowArr[0] && rowArr[0].t ? String(rowArr[0].t).trim().toUpperCase() : '';
    let trCls = '';
    if (primaryTbl && r === primaryTbl.r1) {
      trCls = 'tbl-header';
    } else if (firstCellText === 'TOTAL' || firstCellText === 'GRAND TOTAL') {
      trCls = 'tbl-total';
    } else if (
      primaryTbl &&
      primaryTbl.rowStripes &&
      r > primaryTbl.r1 &&
      r <= primaryTbl.r2 &&
      (r - primaryTbl.r1) % 2 === 0
    ) {
      trCls = 'tbl-stripe';
    }

    gridHtml += `<tr data-r="${r}"${trCls ? ` class="${trCls}"` : ''}><th class="row-hdr">${r + 1}</th>`;
    for (let c = 0; c < sh.colCount; c += 1) {
      const key = `${r}:${c}`;
      if (mergeSkip.has(key)) continue;
      const span = mergeSpan.get(key);
      const cell = rowArr[c];
      const cls = [];
      if (cell) {
        if (cell.a === 'right' && trCls !== 'tbl-header') cls.push('align-right');
        else if (cell.a === 'center') cls.push('align-center');
        if (cell.b) cls.push('is-bold');
      }
      if (r === 0 && c === 0) {
        cls.push('sel', 'sel-anchor');
      }
      let attrs = ` data-r="${r}" data-c="${c}"`;
      if (span) {
        if (span.rs > 1) attrs += ` rowspan="${span.rs}"`;
        if (span.cs > 1) attrs += ` colspan="${span.cs}"`;
      }
      if (cls.length) attrs += ` class="${cls.join(' ')}"`;
      const txt = cell ? escapeHtml(cell.t) : '';
      if (txt.length > 18) attrs += ` title="${txt}"`;
      gridHtml += `<td${attrs}>${txt}</td>`;
    }
    gridHtml += '</tr>';
  }
  gridHtml += '</tbody></table>';

  return { dimsText, fxText, tabsHtml, gridHtml };
}

function buildSpreadsheetWebviewHtml(workbookData) {
  const safeJson = JSON.stringify(workbookData)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
  const title = escapeHtml(workbookData.fileName || 'Workbook');
  const initial = renderInitialSheetMarkup(workbookData, 0);

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${title}</title>
<style>
  :root {
    --bg: var(--vscode-editor-background, #18181b);
    --fg: var(--vscode-editor-foreground, #e4e4e7);
    --muted: var(--vscode-descriptionForeground, #a1a1aa);
    --border: var(--vscode-panel-border, rgba(255,255,255,0.10));
    --bar-bg: var(--vscode-editorWidget-background, #202024);
    --hdr-bg: var(--vscode-editorGroupHeader-tabsBackground, #232329);
    --accent: #2563eb;
    --accent-soft: rgba(37, 99, 235, 0.18);
    --tbl-hdr-bg: #2f5597;
    --tbl-hdr-fg: #ffffff;
    --tbl-stripe: rgba(59, 130, 246, 0.08);
    --tbl-total-bg: rgba(59, 130, 246, 0.16);
  }
  * { box-sizing: border-box; }
  html, body {
    margin: 0; padding: 0; width: 100%; height: 100%;
    overflow: hidden;
    background: var(--bg);
    color: var(--fg);
    font-family: var(--vscode-font-family, "Segoe UI", system-ui, sans-serif);
    font-size: 12.5px;
    user-select: none;
  }
  .app {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
  }
  .toolbar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px;
    background: var(--bar-bg);
    border-bottom: 1px solid var(--border);
    flex-shrink: 0;
  }
  .file-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-weight: 600;
    font-size: 12.5px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 340px;
  }
  .excel-dot {
    width: 8px; height: 8px; border-radius: 2px;
    background: #107c41;
    flex-shrink: 0;
  }
  .meta-pill {
    font-size: 11px;
    color: var(--muted);
    padding: 2px 7px;
    border-radius: 4px;
    background: rgba(128,128,128,0.12);
    white-space: nowrap;
  }
  .spacer { flex: 1; }
  .search-box {
    background: var(--vscode-input-background, rgba(0,0,0,0.22));
    color: var(--vscode-input-foreground, var(--fg));
    border: 1px solid var(--vscode-input-border, var(--border));
    border-radius: 4px;
    padding: 3px 8px;
    font-size: 12px;
    width: 180px;
    outline: none;
  }
  .search-box:focus { border-color: var(--accent); }
  .btn {
    background: rgba(128,128,128,0.14);
    color: var(--fg);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 3px 9px;
    font-size: 11.5px;
    cursor: pointer;
    white-space: nowrap;
  }
  .btn:hover { background: rgba(128,128,128,0.24); }
  .btn.primary {
    background: #107c41;
    border-color: #15803d;
    color: #fff;
    font-weight: 500;
  }
  .btn.primary:hover { background: #15803d; }

  .formula-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 4px 12px;
    background: var(--hdr-bg);
    border-bottom: 1px solid var(--border);
    flex-shrink: 0;
    font-family: var(--vscode-editor-font-family, Consolas, monospace);
    font-size: 12px;
  }
  .cell-addr {
    min-width: 54px;
    text-align: center;
    padding: 2px 6px;
    border-radius: 3px;
    background: rgba(128,128,128,0.15);
    font-weight: 600;
    color: var(--fg);
  }
  .fx-glyph {
    color: var(--muted);
    font-style: italic;
    font-weight: 600;
    padding: 0 2px;
  }
  .fx-val {
    flex: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    user-select: text;
    color: var(--fg);
  }

  .grid-wrap {
    flex: 1;
    overflow: auto;
    position: relative;
  }
  table.sheet {
    border-collapse: separate;
    border-spacing: 0;
    table-layout: fixed;
    width: max-content;
  }
  table.sheet th, table.sheet td {
    border-right: 1px solid var(--border);
    border-bottom: 1px solid var(--border);
    padding: 4px 8px;
    height: 24px;
    line-height: 1.25;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-variant-numeric: tabular-nums;
  }
  table.sheet thead th.corner,
  table.sheet thead th.col-hdr {
    position: sticky;
    top: 0;
    z-index: 4;
    background: var(--hdr-bg);
    color: var(--muted);
    font-weight: 600;
    font-size: 11px;
    text-align: center;
    padding: 3px 4px;
    height: 22px;
  }
  table.sheet thead th.corner {
    left: 0;
    z-index: 6;
    width: 42px;
    min-width: 42px;
  }
  table.sheet tbody th.row-hdr {
    position: sticky;
    left: 0;
    z-index: 3;
    background: var(--hdr-bg);
    color: var(--muted);
    font-weight: 500;
    font-size: 11px;
    text-align: center;
    width: 42px;
    min-width: 42px;
    padding: 3px 4px;
  }
  /* Sticky Excel Table Header Row when table starts on row 1 */
  table.sheet tr.tbl-header th.row-hdr {
    position: sticky;
    top: 22px;
    left: 0;
    z-index: 5;
  }
  table.sheet tr.tbl-header td {
    position: sticky;
    top: 22px;
    z-index: 2;
    background: var(--tbl-hdr-bg);
    color: var(--tbl-hdr-fg);
    font-weight: 600;
    white-space: pre-line;
    height: auto;
    vertical-align: bottom;
    padding: 6px 8px;
  }
  table.sheet tr.tbl-stripe td {
    background: var(--tbl-stripe);
  }
  table.sheet tr.tbl-total td {
    background: var(--tbl-total-bg);
    font-weight: 700;
    border-top: 2px solid rgba(59, 130, 246, 0.45);
  }
  td.align-right { text-align: right; }
  td.align-center { text-align: center; }
  td.is-bold { font-weight: 700; }
  td.sel {
    background: var(--accent-soft) !important;
  }
  td.sel-anchor {
    outline: 2px solid var(--accent);
    outline-offset: -2px;
  }
  tr.filtered-out { display: none; }

  .footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 0 12px;
    height: 30px;
    background: var(--bar-bg);
    border-top: 1px solid var(--border);
    flex-shrink: 0;
  }
  .tabs {
    display: flex;
    align-items: stretch;
    gap: 2px;
    height: 100%;
    overflow-x: auto;
  }
  .tab {
    display: inline-flex;
    align-items: center;
    padding: 0 14px;
    font-size: 12px;
    color: var(--muted);
    cursor: pointer;
    border-bottom: 2px solid transparent;
    white-space: nowrap;
  }
  .tab:hover { color: var(--fg); background: rgba(128,128,128,0.08); }
  .tab.active {
    color: var(--fg);
    font-weight: 600;
    border-bottom-color: #107c41;
    background: var(--bg);
  }
  .stats {
    display: flex;
    align-items: center;
    gap: 14px;
    font-size: 11.5px;
    color: var(--muted);
    font-variant-numeric: tabular-nums;
    white-space: nowrap;
  }
  .stats strong { color: var(--fg); font-weight: 600; }
  .empty-state {
    padding: 40px;
    text-align: center;
    color: var(--muted);
  }
</style>
</head>
<body>
<div class="app">
  <div class="toolbar">
    <div class="file-badge" title="${escapeHtml(workbookData.filePath || '')}">
      <span class="excel-dot"></span>
      <span id="wb-name">${title}</span>
    </div>
    <span class="meta-pill" id="sheet-dims">${escapeHtml(initial.dimsText)}</span>
    <div class="spacer"></div>
    <input type="text" class="search-box" id="filter-input" placeholder="Filter rows…" />
    <button class="btn" id="btn-copy" title="Copy visible sheet as TSV">Copy Sheet</button>
    <button class="btn" id="btn-reload" title="Reload from disk">↻ Reload</button>
    <button class="btn" id="btn-reveal" title="Reveal in Windows Explorer">Explorer</button>
    <button class="btn primary" id="btn-excel" title="Open in desktop Microsoft Excel">Open in Excel</button>
  </div>
  <div class="formula-bar">
    <span class="cell-addr" id="cell-addr">A1</span>
    <span class="fx-glyph">fx</span>
    <span class="fx-val" id="fx-val">${escapeHtml(initial.fxText)}</span>
  </div>
  <div class="grid-wrap" id="grid-wrap">${initial.gridHtml}</div>
  <div class="footer">
    <div class="tabs" id="sheet-tabs">${initial.tabsHtml}</div>
    <div class="stats" id="sel-stats"></div>
  </div>
</div>

<script id="wb-json" type="application/json">${safeJson}</script>
<script>
(function() {
  const vscode = typeof acquireVsCodeApi === 'function' ? acquireVsCodeApi() : { postMessage: function() {} };
  const CR = String.fromCharCode(13);
  const LF = String.fromCharCode(10);
  const TAB = String.fromCharCode(9);

  let wb = JSON.parse(document.getElementById('wb-json').textContent || '{}');
  let activeSheetIdx = 0;
  let selStart = { r: 0, c: 0 };
  let selEnd = { r: 0, c: 0 };
  let isDragging = false;

  const gridWrap = document.getElementById('grid-wrap');
  const tabsEl = document.getElementById('sheet-tabs');
  const dimsEl = document.getElementById('sheet-dims');
  const addrEl = document.getElementById('cell-addr');
  const fxEl = document.getElementById('fx-val');
  const statsEl = document.getElementById('sel-stats');
  const filterInput = document.getElementById('filter-input');

  function cleanTsvCell(cell) {
    if (!cell || cell.t === undefined || cell.t === null) return '';
    return String(cell.t).split(CR).join('').split(LF).join(' ');
  }

  function colLetters(idx) {
    let n = idx + 1, s = '';
    while (n > 0) {
      const rem = (n - 1) % 26;
      s = String.fromCharCode(65 + rem) + s;
      n = Math.floor((n - 1) / 26);
    }
    return s;
  }

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function renderTabs() {
    if (!wb.sheets || wb.sheets.length === 0) {
      tabsEl.innerHTML = '';
      return;
    }
    tabsEl.innerHTML = wb.sheets.map((s, idx) =>
      '<div class="tab' + (idx === activeSheetIdx ? ' active' : '') + '" data-idx="' + idx + '">' + esc(s.name) + '</div>'
    ).join('');
  }

  function renderSheet() {
    if (wb.unsupportedBinary) {
      dimsEl.textContent = 'Legacy binary format';
      gridWrap.innerHTML = '<div class="empty-state"><p>Legacy binary spreadsheet format. Click <strong>Open in Excel</strong> above to view.</p></div>';
      return;
    }
    const sh = wb.sheets[activeSheetIdx];
    if (!sh || sh.rowCount === 0 || sh.colCount === 0) {
      dimsEl.textContent = 'Empty sheet';
      gridWrap.innerHTML = '<div class="empty-state">This worksheet is empty.</div>';
      return;
    }

    dimsEl.textContent = sh.rowCount + ' rows × ' + sh.colCount + ' cols' + (sh.truncated ? ' (preview)' : '');
    const primaryTbl = sh.tables && sh.tables[0] ? sh.tables[0] : null;

    const mergeSpan = new Map();
    const mergeSkip = new Set();
    for (const m of (sh.merges || [])) {
      const rs = m.r2 - m.r1 + 1;
      const cs = m.c2 - m.c1 + 1;
      if (rs > 1 || cs > 1) {
        mergeSpan.set(m.r1 + ':' + m.c1, { rs, cs });
        for (let rr = m.r1; rr <= m.r2; rr++) {
          for (let cc = m.c1; cc <= m.c2; cc++) {
            if (rr !== m.r1 || cc !== m.c1) mergeSkip.add(rr + ':' + cc);
          }
        }
      }
    }

    let html = '<table class="sheet"><colgroup><col style="width:42px">';
    for (let c = 0; c < sh.colCount; c++) {
      const excelW = sh.colWidths && sh.colWidths[c] ? sh.colWidths[c] : 12;
      const px = Math.max(58, Math.min(340, Math.round(excelW * 8.2 + 12)));
      html += '<col style="width:' + px + 'px">';
    }
    html += '</colgroup><thead><tr><th class="corner"></th>';
    for (let c = 0; c < sh.colCount; c++) {
      html += '<th class="col-hdr">' + colLetters(c) + '</th>';
    }
    html += '</tr></thead><tbody>';

    for (let r = 0; r < sh.rowCount; r++) {
      const rowArr = sh.grid[r] || [];
      const firstCellText = rowArr[0] && rowArr[0].t ? String(rowArr[0].t).trim().toUpperCase() : '';
      let trCls = '';
      if (primaryTbl && r === primaryTbl.r1) {
        trCls = 'tbl-header';
      } else if (firstCellText === 'TOTAL' || firstCellText === 'GRAND TOTAL') {
        trCls = 'tbl-total';
      } else if (primaryTbl && primaryTbl.rowStripes && r > primaryTbl.r1 && r <= primaryTbl.r2 && ((r - primaryTbl.r1) % 2 === 0)) {
        trCls = 'tbl-stripe';
      }

      html += '<tr data-r="' + r + '"' + (trCls ? ' class="' + trCls + '"' : '') + '>';
      html += '<th class="row-hdr">' + (r + 1) + '</th>';
      for (let c = 0; c < sh.colCount; c++) {
        const key = r + ':' + c;
        if (mergeSkip.has(key)) continue;
        const span = mergeSpan.get(key);
        const cell = rowArr[c];
        const cls = [];
        if (cell) {
          if (cell.a === 'right' && trCls !== 'tbl-header') cls.push('align-right');
          else if (cell.a === 'center') cls.push('align-center');
          if (cell.b) cls.push('is-bold');
        }
        let attrs = ' data-r="' + r + '" data-c="' + c + '"';
        if (span) {
          if (span.rs > 1) attrs += ' rowspan="' + span.rs + '"';
          if (span.cs > 1) attrs += ' colspan="' + span.cs + '"';
        }
        if (cls.length) attrs += ' class="' + cls.join(' ') + '"';
        const txt = cell ? esc(cell.t) : '';
        if (txt.length > 18) attrs += ' title="' + txt + '"';
        html += '<td' + attrs + '>' + txt + '</td>';
      }
      html += '</tr>';
    }
    html += '</tbody></table>';
    gridWrap.innerHTML = html;
    applyFilter();
    updateSelectionUI();
  }

  function updateSelectionUI() {
    const sh = wb.sheets[activeSheetIdx];
    if (!sh) return;
    const r1 = Math.min(selStart.r, selEnd.r);
    const r2 = Math.max(selStart.r, selEnd.r);
    const c1 = Math.min(selStart.c, selEnd.c);
    const c2 = Math.max(selStart.c, selEnd.c);

    const prev = gridWrap.querySelectorAll('td.sel, td.sel-anchor');
    prev.forEach((el) => el.classList.remove('sel', 'sel-anchor'));

    let count = 0, numCount = 0, sum = 0;
    for (let r = r1; r <= r2; r++) {
      const rowEl = gridWrap.querySelector('tr[data-r="' + r + '"]');
      if (rowEl && rowEl.classList.contains('filtered-out')) continue;
      for (let c = c1; c <= c2; c++) {
        const td = rowEl ? rowEl.querySelector('td[data-c="' + c + '"]') : null;
        if (td) {
          td.classList.add('sel');
          if (r === selStart.r && c === selStart.c) td.classList.add('sel-anchor');
        }
        const cell = sh.grid[r] && sh.grid[r][c];
        if (cell && cell.t !== '') {
          count += 1;
          if (typeof cell.n === 'number' && Number.isFinite(cell.n)) {
            numCount += 1;
            sum += cell.n;
          }
        }
      }
    }

    const anchorRef = colLetters(selStart.c) + (selStart.r + 1);
    const rangeRef = (r1 === r2 && c1 === c2) ? anchorRef : (colLetters(c1) + (r1 + 1) + ':' + colLetters(c2) + (r2 + 1));
    addrEl.textContent = rangeRef;

    const anchorCell = sh.grid[selStart.r] && sh.grid[selStart.r][selStart.c];
    if (anchorCell) {
      fxEl.textContent = anchorCell.f ? (anchorCell.f + '   [' + anchorCell.t + ']') : anchorCell.t;
    } else {
      fxEl.textContent = '';
    }

    if (numCount > 1) {
      const avg = sum / numCount;
      const fmt = (n) => Number(n.toFixed(2)).toLocaleString('en-US', { maximumFractionDigits: 2 });
      statsEl.innerHTML = '<span>Count: <strong>' + count + '</strong></span><span>Avg: <strong>' + fmt(avg) + '</strong></span><span>Sum: <strong>' + fmt(sum) + '</strong></span>';
    } else if (count > 1) {
      statsEl.innerHTML = '<span>Count: <strong>' + count + '</strong></span>';
    } else {
      statsEl.innerHTML = '';
    }
  }

  function applyFilter() {
    const q = (filterInput.value || '').trim().toLowerCase();
    const sh = wb.sheets[activeSheetIdx];
    if (!sh) return;
    const primaryTbl = sh.tables && sh.tables[0] ? sh.tables[0] : null;
    const trs = gridWrap.querySelectorAll('tbody tr');
    trs.forEach((tr) => {
      const r = Number(tr.getAttribute('data-r'));
      if (!q || (primaryTbl && r === primaryTbl.r1)) {
        tr.classList.remove('filtered-out');
        return;
      }
      const rowArr = sh.grid[r] || [];
      const match = rowArr.some((cell) => cell && String(cell.t).toLowerCase().includes(q));
      tr.classList.toggle('filtered-out', !match);
    });
  }

  gridWrap.addEventListener('mousedown', (e) => {
    const td = e.target.closest('td[data-r]');
    if (!td) return;
    const r = Number(td.getAttribute('data-r'));
    const c = Number(td.getAttribute('data-c'));
    if (e.shiftKey) {
      selEnd = { r, c };
    } else {
      selStart = { r, c };
      selEnd = { r, c };
    }
    isDragging = true;
    updateSelectionUI();
  });

  gridWrap.addEventListener('mouseover', (e) => {
    if (!isDragging) return;
    const td = e.target.closest('td[data-r]');
    if (!td) return;
    selEnd = { r: Number(td.getAttribute('data-r')), c: Number(td.getAttribute('data-c')) };
    updateSelectionUI();
  });

  window.addEventListener('mouseup', () => { isDragging = false; });

  // Column header click selects entire column (excluding header row)
  gridWrap.addEventListener('click', (e) => {
    const colHdr = e.target.closest('th.col-hdr');
    if (colHdr) {
      const sh = wb.sheets[activeSheetIdx];
      if (!sh) return;
      const idx = Array.from(colHdr.parentElement.children).indexOf(colHdr) - 1;
      if (idx >= 0) {
        const startRow = sh.tables && sh.tables[0] ? sh.tables[0].r1 + 1 : 0;
        let endRow = sh.rowCount - 1;
        const lastFirst = sh.grid[endRow] && sh.grid[endRow][0] ? String(sh.grid[endRow][0].t).trim().toUpperCase() : '';
        if (lastFirst === 'TOTAL' && endRow > startRow) endRow -= 1;
        selStart = { r: startRow, c: idx };
        selEnd = { r: endRow, c: idx };
        updateSelectionUI();
      }
    }
  });

  window.addEventListener('keydown', (e) => {
    if (document.activeElement === filterInput) return;
    const sh = wb.sheets[activeSheetIdx];
    if (!sh) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') {
      const r1 = Math.min(selStart.r, selEnd.r), r2 = Math.max(selStart.r, selEnd.r);
      const c1 = Math.min(selStart.c, selEnd.c), c2 = Math.max(selStart.c, selEnd.c);
      const lines = [];
      for (let r = r1; r <= r2; r++) {
        const vals = [];
        for (let c = c1; c <= c2; c++) {
          const cell = sh.grid[r] && sh.grid[r][c];
          vals.push(cleanTsvCell(cell));
        }
        lines.push(vals.join(TAB));
      }
      navigator.clipboard.writeText(lines.join(LF)).catch(() => {});
      return;
    }
    const moves = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] };
    if (moves[e.key]) {
      e.preventDefault();
      const [dr, dc] = moves[e.key];
      const nr = Math.max(0, Math.min(sh.rowCount - 1, selStart.r + dr));
      const nc = Math.max(0, Math.min(sh.colCount - 1, selStart.c + dc));
      selStart = { r: nr, c: nc };
      if (!e.shiftKey) selEnd = { r: nr, c: nc };
      updateSelectionUI();
    }
  });

  tabsEl.addEventListener('click', (e) => {
    const tab = e.target.closest('.tab[data-idx]');
    if (!tab) return;
    activeSheetIdx = Number(tab.getAttribute('data-idx'));
    selStart = { r: 0, c: 0 };
    selEnd = { r: 0, c: 0 };
    renderTabs();
    renderSheet();
  });

  filterInput.addEventListener('input', applyFilter);

  document.getElementById('btn-copy').addEventListener('click', () => {
    const sh = wb.sheets[activeSheetIdx];
    if (!sh) return;
    const lines = sh.grid.map((row) => row.map((c) => cleanTsvCell(c)).join(TAB));
    navigator.clipboard.writeText(lines.join(LF)).catch(() => {});
  });
  document.getElementById('btn-reload').addEventListener('click', () => vscode.postMessage({ type: 'reload' }));
  document.getElementById('btn-reveal').addEventListener('click', () => vscode.postMessage({ type: 'reveal' }));
  document.getElementById('btn-excel').addEventListener('click', () => vscode.postMessage({ type: 'openExternal' }));

  window.addEventListener('message', (e) => {
    const msg = e.data;
    if (msg && msg.type === 'workbookUpdated' && msg.workbook) {
      wb = msg.workbook;
      if (activeSheetIdx >= wb.sheets.length) activeSheetIdx = 0;
      renderTabs();
      renderSheet();
    }
  });

  renderTabs();
  renderSheet();
})();
</script>
</body>
</html>`;
}

// ---------------------------------------------------------------------------
// VS Code Panel & CustomReadonlyEditorProvider Management
// ---------------------------------------------------------------------------

function attachPanelLifecycle(vscode, panel, fsPath) {
  const normKey = path.resolve(fsPath).toLowerCase();
  const openMap = getOpenPanelsMap();
  panel.__bhfFsPath = fsPath;
  openMap.set(normKey, panel);

  const renderFromDisk = (isUpdate = false) => {
    try {
      const data = parseSpreadsheetFile(fsPath);
      if (isUpdate && panel.__bhfHtmlRenderVersion === EXCEL_HTML_RENDER_VERSION) {
        panel.webview.postMessage({ type: 'workbookUpdated', workbook: data }).then(() => {}, () => {});
      } else {
        panel.webview.html = buildSpreadsheetWebviewHtml(data);
        panel.__bhfHtmlRenderVersion = EXCEL_HTML_RENDER_VERSION;
      }
    } catch (err) {
      panel.webview.html = `<!DOCTYPE html><html><body style="font-family:sans-serif;padding:24px;color:#e4e4e7;background:#18181b"><h3>Unable to read workbook</h3><p>${escapeHtml(err.message || String(err))}</p></body></html>`;
    }
  };

  renderFromDisk(false);

  const msgSub = panel.webview.onDidReceiveMessage((msg) => {
    if (!msg || typeof msg !== 'object') return;
    const fileUri = vscode.Uri.file(fsPath);
    if (msg.type === 'reload') {
      renderFromDisk(true);
    } else if (msg.type === 'reveal') {
      vscode.commands.executeCommand('revealFileInOS', fileUri).then(() => {}, () => {});
    } else if (msg.type === 'openExternal') {
      vscode.env.openExternal(fileUri).then(() => {}, () => {});
    }
  });

  let lastMtime = 0;
  try {
    lastMtime = fs.statSync(fsPath).mtimeMs;
  } catch {}
  const watcher = (curr) => {
    if (curr && curr.mtimeMs > 0 && curr.mtimeMs !== lastMtime) {
      lastMtime = curr.mtimeMs;
      renderFromDisk(true);
    }
  };
  try {
    fs.watchFile(fsPath, { persistent: false, interval: 2000 }, watcher);
  } catch {}

  panel.onDidDispose(() => {
    if (openMap.get(normKey) === panel) {
      openMap.delete(normKey);
    }
    try {
      msgSub.dispose();
    } catch {}
    try {
      fs.unwatchFile(fsPath, watcher);
    } catch {}
  });
}

function getDeliverableOpenPanelsMap() {
  if (!globalThis[DELIVERABLE_PANEL_CACHE_SYMBOL]) {
    globalThis[DELIVERABLE_PANEL_CACHE_SYMBOL] = new Map();
  }
  return globalThis[DELIVERABLE_PANEL_CACHE_SYMBOL];
}

function getDeliverableProviderState() {
  if (!globalThis[DELIVERABLE_PROVIDER_STATE_SYMBOL]) {
    globalThis[DELIVERABLE_PROVIDER_STATE_SYMBOL] = {
      customEditorRegistered: false,
      commandRegistered: false,
      renderImpl: null
    };
  }
  return globalThis[DELIVERABLE_PROVIDER_STATE_SYMBOL];
}

function getDeliverableInFlightMap() {
  if (!globalThis[DELIVERABLE_INFLIGHT_SYMBOL]) {
    globalThis[DELIVERABLE_INFLIGHT_SYMBOL] = new Map();
  }
  return globalThis[DELIVERABLE_INFLIGHT_SYMBOL];
}

function hasExplicitLineTarget(rawUriOrPath) {
  let s = String(rawUriOrPath || '').trim();
  if (!s) return false;
  if (/^file:\/\//i.test(s)) {
    s = s.replace(/^file:\/\/\/?/i, '');
    try {
      s = decodeURIComponent(s);
    } catch {}
  }
  if (/#L?\d+(?:\s*-\s*L?\d+)?$/i.test(s)) return true;
  const colMatch = s.match(/:(\d+)(?:-(\d+))?$/);
  if (colMatch) {
    const prefix = s.slice(0, colMatch.index + 1);
    if (!/^[A-Za-z]:$/.test(prefix)) return true;
  }
  return false;
}

function classifyDeliverableKind(fsPath) {
  const s = String(fsPath || '').trim();
  if (!s) return '';
  if (SPREADSHEET_EXT_RE.test(s) || /\.(csv|tsv)$/i.test(s)) return 'spreadsheet';
  if (HTML_DELIVERABLE_EXT_RE.test(s)) return 'html';
  if (PDF_DELIVERABLE_EXT_RE.test(s)) return 'pdf';
  if (PPTX_DELIVERABLE_EXT_RE.test(s)) return 'pptx';
  return '';
}

function getDocPreviewCacheRoot() {
  return (
    process.env.THEO_DOC_PREVIEW_CACHE_DIR ||
    path.join(os.homedir(), '.theo', 'doc-preview-cache')
  );
}

function buildOpaqueStorageShimScript() {
  return (
    '(function(){' +
    'function mk(){var d=Object.create(null);return{' +
    'get length(){return Object.keys(d).length;},' +
    'clear:function(){d=Object.create(null);},' +
    'getItem:function(k){k=String(k);return Object.prototype.hasOwnProperty.call(d,k)?d[k]:null;},' +
    'key:function(i){var ks=Object.keys(d);return i>=0&&i<ks.length?ks[i]:null;},' +
    'removeItem:function(k){delete d[String(k)];},' +
    'setItem:function(k,v){d[String(k)]=String(v);}' +
    '};}' +
    '["localStorage","sessionStorage"].forEach(function(p){' +
    'try{var s=window[p];s.setItem("__t","1");s.removeItem("__t");}catch(_e){' +
    'try{Object.defineProperty(window,p,{value:mk(),configurable:true});}catch(_e2){}' +
    '}' +
    '});' +
    '})();'
  );
}

function injectOpaqueStorageShim(rawHtml) {
  const html = String(rawHtml || '');
  const tag = '<script data-theo-storage-shim="1">' + buildOpaqueStorageShimScript() + '</script>';
  if (/<head(?:\s[^>]*)?>/i.test(html)) {
    return html.replace(/<head(?:\s[^>]*)?>/i, (m) => m + tag);
  }
  if (/<!doctype[^>]*>/i.test(html)) {
    return html.replace(/<!doctype[^>]*>/i, (m) => m + tag);
  }
  if (/<html(?:\s[^>]*)?>/i.test(html)) {
    return html.replace(/<html(?:\s[^>]*)?>/i, (m) => m + tag);
  }
  return tag + html;
}

function isRealPathWithinDir(targetPath, rootDir) {
  try {
    const realRoot = fs.realpathSync(rootDir);
    const realTarget = fs.realpathSync(targetPath);
    const nr = process.platform === 'win32' ? realRoot.toLowerCase() : realRoot;
    const nt = process.platform === 'win32' ? realTarget.toLowerCase() : realTarget;
    return nt === nr || nt.startsWith(nr + path.sep);
  } catch {
    return false;
  }
}

const INLINE_SENSITIVE_SEG_RE =
  /^(\.theo|\.claude|\.ssh|\.aws|\.git|\.gitdirs|\.gnupg|\.kube|\.azure|\.system_generated)$/i;
const INLINE_SENSITIVE_FILE_RE =
  /^(\.env(\..+)?|\.dev\.vars(\..+)?|\.npmrc|\.pypirc|\.netrc|.*bank-kyc-ali-bdeir.*|.*user-passports-antigua-lebanon.*|.*\.tfstate(\.backup)?|.*credentials.*|.*secret.*|.*private[_-]?key.*|id_(rsa|dsa|ecdsa|ed25519)(\.pub)?|.*\.(pem|key|pfx|p12|kdbx|jks|keystore)|.*\.(sqlite|sqlite3|db)(-wal|-shm)?)$/i;

function isSafeInlineAssetRef(refStr, resolvedPath = '', allowedRootDir = '') {
  const raw = String(refStr || '').trim();
  if (!raw || raw.startsWith('#')) return false;
  if (/^(?:[a-zA-Z][a-zA-Z0-9+.-]*:|\/\/)/i.test(raw)) return false;
  if (raw.includes('\0')) return false;
  const clean = raw.split(/[?#]/)[0].trim();
  if (!clean) return false;
  const segs = clean.split(/[\\/]+/).filter(Boolean);
  for (const seg of segs) {
    if (seg === '.') continue;
    if (seg === '..' || seg.startsWith('.')) return false;
    if (INLINE_SENSITIVE_SEG_RE.test(seg) || INLINE_SENSITIVE_FILE_RE.test(seg)) return false;
    if (seg.toLowerCase() === 'private') return false;
  }
  const base = segs[segs.length - 1] || '';
  if (!base || base === '.' || INLINE_SENSITIVE_FILE_RE.test(base)) return false;
  if (resolvedPath) {
    try {
      const realPath = fs.realpathSync(resolvedPath);
      const realSegs = realPath.split(/[\\/]+/).filter(Boolean);
      for (const rs of realSegs) {
        if (INLINE_SENSITIVE_SEG_RE.test(rs)) return false;
      }
      if (INLINE_SENSITIVE_FILE_RE.test(path.basename(realPath))) return false;
      if (allowedRootDir) {
        const rel = path.relative(fs.realpathSync(allowedRootDir), realPath).replace(/\\/g, '/').toLowerCase();
        if (!rel || rel.startsWith('..') || rel === 'private' || rel.startsWith('private/')) return false;
      }
    } catch {
      return false;
    }
  }
  return true;
}

function inlineSafeLocalHtmlAssets(html, baseDir, allowedRootDir) {
  let out = String(html || '');
  let totalBudget = 2.5 * 1024 * 1024;
  const maxSingle = 512 * 1024;
  const root = allowedRootDir || baseDir;

  out = out.replace(/<link\b([^>]*\brel\s*=\s*["']stylesheet["'][^>]*)>/gi, (full, attrs) => {
    const hrefMatch = /\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(attrs);
    const href = hrefMatch ? (hrefMatch[1] ?? hrefMatch[2] ?? '') : '';
    if (!isSafeInlineAssetRef(href)) return full;
    const cleanRel = href.split(/[?#]/)[0].trim();
    const resolved = path.resolve(baseDir, cleanRel);
    if (!isRealPathWithinDir(resolved, root)) return full;
    if (!isSafeInlineAssetRef(href, resolved, root)) return full;
    try {
      const st = fs.statSync(resolved);
      if (!st.isFile() || st.size > maxSingle || st.size > totalBudget) return full;
      totalBudget -= st.size;
      const cssTxt = fs.readFileSync(resolved, 'utf8').replace(/<\/style/gi, '<\\/style');
      return `<style data-inlined-href="${escapeHtml(cleanRel)}">${cssTxt}</style>`;
    } catch {
      return full;
    }
  });

  const mimeByExt = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
  };
  out = out.replace(/(<img\b[^>]*\bsrc\s*=\s*)(?:"([^"]*)"|'([^']*)')([^>]*>)/gi, (full, pre, q1, q2, post) => {
    const src = q1 ?? q2 ?? '';
    if (!isSafeInlineAssetRef(src)) return full;
    const cleanRel = src.split(/[?#]/)[0].trim();
    const ext = path.extname(cleanRel).toLowerCase();
    const mime = mimeByExt[ext];
    if (!mime) return full;
    const resolved = path.resolve(baseDir, cleanRel);
    if (!isRealPathWithinDir(resolved, root)) return full;
    if (!isSafeInlineAssetRef(src, resolved, root)) return full;
    try {
      const st = fs.statSync(resolved);
      if (!st.isFile() || st.size > maxSingle || st.size > totalBudget) return full;
      totalBudget -= st.size;
      const b64 = fs.readFileSync(resolved).toString('base64');
      return `${pre}"data:${mime};base64,${b64}"${post}`;
    } catch {
      return full;
    }
  });

  return out;
}

function prepareHtmlPreviewPayload(fsPath, opts = {}) {
  const stat = fs.statSync(fsPath);
  const maxBytes = Math.min(Number(opts.maxBytes || 8 * 1024 * 1024), 8 * 1024 * 1024);
  const fullBuf = readWorkbookBufferSafe(fsPath);
  const truncated = fullBuf.length > maxBytes;
  const sliceBuf = truncated ? fullBuf.subarray(0, maxBytes) : fullBuf;
  const sourceHtml = sliceBuf.toString('utf8');
  const baseDir = path.dirname(fsPath);
  const allowedRoot = opts.allowedRootDir || baseDir;
  const withAssets =
    opts.inlineLocalAssets === false
      ? sourceHtml
      : inlineSafeLocalHtmlAssets(sourceHtml, baseDir, allowedRoot);
  const sandboxedHtml = injectOpaqueStorageShim(withAssets);
  return {
    ok: true,
    kind: 'html',
    file: path.basename(fsPath),
    fullPath: fsPath,
    size: stat.size,
    mtime: stat.mtimeMs,
    truncated,
    sourceHtml,
    sandboxedHtml
  };
}

function hasPdfMagicHeader(filePath) {
  let fd = null;
  try {
    const st = fs.statSync(filePath);
    if (!st.isFile() || st.size < 8) return false;
    const len = Math.min(1024, st.size);
    const buf = Buffer.alloc(len);
    fd = fs.openSync(filePath, 'r');
    fs.readSync(fd, buf, 0, len, 0);
    return buf.includes(Buffer.from('%PDF-'));
  } catch {
    return false;
  } finally {
    if (fd !== null) {
      try { fs.closeSync(fd); } catch {}
    }
  }
}

const DELIVERABLE_SEM = { active: 0, waiters: [] };
async function withDeliverableSemaphore(fn) {
  if (DELIVERABLE_SEM.active >= 2) {
    await new Promise((resolve) => DELIVERABLE_SEM.waiters.push(resolve));
  }
  DELIVERABLE_SEM.active += 1;
  try {
    return await fn();
  } finally {
    DELIVERABLE_SEM.active = Math.max(0, DELIVERABLE_SEM.active - 1);
    const next = DELIVERABLE_SEM.waiters.shift();
    if (next) next();
  }
}

function runExecFileAsync(cmd, args, opts = {}) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { windowsHide: true, maxBuffer: 4 * 1024 * 1024, ...opts }, (err, stdout, stderr) => {
      if (err) {
        err.stdout = stdout;
        err.stderr = stderr;
        reject(err);
      } else {
        resolve({ stdout: String(stdout || ''), stderr: String(stderr || '') });
      }
    });
  });
}

function computeDeliverableCacheDir(fsPath, stat, siblingStat = null) {
  const sibSig = siblingStat ? `|sib:${siblingStat.size}:${Math.floor(siblingStat.mtimeMs)}` : '';
  const key = crypto
    .createHash('sha256')
    .update('v1|' + path.resolve(fsPath).toLowerCase() + '|' + stat.size + '|' + Math.floor(stat.mtimeMs) + sibSig)
    .digest('hex')
    .slice(0, 24);
  const root = getDocPreviewCacheRoot();
  const dir = path.join(root, key);
  const isNew = !fs.existsSync(dir);
  fs.mkdirSync(dir, { recursive: true });
  if (isNew) {
    setImmediate(() => {
      try {
        const entries = fs.readdirSync(root, { withFileTypes: true }).filter((d) => d.isDirectory());
        if (entries.length > 40) {
          const sorted = entries
            .map((d) => {
              const p = path.join(root, d.name);
              try { return { p, mtime: fs.statSync(p).mtimeMs }; } catch { return { p, mtime: 0 }; }
            })
            .sort((a, b) => a.mtime - b.mtime);
          for (const item of sorted.slice(0, sorted.length - 40)) {
            if (path.resolve(item.p) !== path.resolve(dir)) {
              fs.rmSync(item.p, { recursive: true, force: true });
            }
          }
        }
      } catch {}
    });
  }
  return dir;
}

function findPythonExeForPdf() {
  if (process.env.THEO_PYTHON_EXE && fs.existsSync(process.env.THEO_PYTHON_EXE)) {
    return process.env.THEO_PYTHON_EXE;
  }
  const portable = path.join(os.homedir(), '.local', 'python312', process.platform === 'win32' ? 'python.exe' : 'bin/python3');
  if (fs.existsSync(portable)) return portable;
  return process.platform === 'win32' ? 'python.exe' : 'python3';
}

async function exportPptxToPdfViaPowerPointAsync(fsPath, cacheDir) {
  if (process.platform !== 'win32' || process.env.THEO_DISABLE_PPT_COM === '1') {
    return '';
  }
  const finalPdf = path.join(cacheDir, 'deck.pdf');
  if (hasPdfMagicHeader(finalPdf)) return finalPdf;
  const tmpPdf = path.join(cacheDir, `deck.${process.pid}.${Date.now()}.tmp.pdf`);
  const psScript = [
    '$ErrorActionPreference = "Stop"',
    '$hadPpt = ($null -ne (Get-Process POWERPNT -ErrorAction SilentlyContinue))',
    '$app = $null; $pres = $null',
    'try {',
    '  $app = New-Object -ComObject PowerPoint.Application',
    '  $pres = $app.Presentations.Open($env:THEO_PPTX_IN, -1, 0, 0)',
    '  $pres.SaveAs($env:THEO_PDF_TMP, 32)',
    '} finally {',
    '  if ($pres -ne $null) { try { $pres.Close() } catch {} }',
    '  if (-not $hadPpt -and $app -ne $null) { try { if ($app.Presentations.Count -eq 0) { $app.Quit() } } catch {} }',
    '}'
  ].join('\n');
  try {
    await withDeliverableSemaphore(() =>
      runExecFileAsync(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psScript],
        {
          timeout: 25000,
          env: { ...process.env, THEO_PPTX_IN: fsPath, THEO_PDF_TMP: tmpPdf }
        }
      )
    );
    if (hasPdfMagicHeader(tmpPdf)) {
      fs.renameSync(tmpPdf, finalPdf);
      return finalPdf;
    }
  } catch {}
  try { if (fs.existsSync(tmpPdf)) fs.unlinkSync(tmpPdf); } catch {}
  return '';
}

function extractPptxSlidesFallback(fsPath) {
  const buf = readWorkbookBufferSafe(fsPath);
  const entries = readZipEntries(buf);
  if (entries.size === 0) return [];

  const presXml = readZipText(entries, 'ppt/presentation.xml');
  const presRelsXml = readZipText(entries, 'ppt/_rels/presentation.xml.rels');
  const presRels = parseRelsMap(presRelsXml, 'ppt');
  const orderedSlidePaths = [];

  if (presXml && presRels.size > 0) {
    const sldRe = /<p:sldId\b([^>]*)\/?>/g;
    let m;
    while ((m = sldRe.exec(presXml)) !== null) {
      const a = parseXmlAttrs(m[1]);
      const rid = a['r:id'] || a.id;
      const target = rid ? presRels.get(rid) : '';
      if (target) orderedSlidePaths.push(target);
    }
  }
  if (orderedSlidePaths.length === 0) {
    for (const k of entries.keys()) {
      if (/^ppt\/slides\/slide\d+\.xml$/i.test(k)) orderedSlidePaths.push(k);
    }
    orderedSlidePaths.sort((a, b) => {
      const na = parseInt((a.match(/slide(\d+)\.xml/i) || [])[1] || '0', 10);
      const nb = parseInt((b.match(/slide(\d+)\.xml/i) || [])[1] || '0', 10);
      return na - nb;
    });
  }

  const mimeMap = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml'
  };

  return orderedSlidePaths.map((sPath, idx) => {
    const xml = readZipText(entries, sPath);
    const paras = [];
    const pRe = /<a:p\b[^>]*>([\s\S]*?)<\/a:p>/g;
    let pm;
    while ((pm = pRe.exec(xml)) !== null) {
      const tRe = /<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>/g;
      let tm;
      let line = '';
      while ((tm = tRe.exec(pm[1])) !== null) {
        line += decodeXmlText(tm[1]);
      }
      const clean = line.replace(/\s+/g, ' ').trim();
      if (clean && (paras.length === 0 || paras[paras.length - 1] !== clean)) {
        paras.push(clean);
      }
    }
    let imageDataUri = '';
    const relsPath = path.posix.join(
      path.posix.dirname(sPath),
      '_rels',
      `${path.posix.basename(sPath)}.rels`
    );
    const relsXml = readZipText(entries, relsPath);
    if (relsXml) {
      const rMap = parseRelsMap(relsXml, path.posix.dirname(sPath));
      for (const target of rMap.values()) {
        const ext = path.posix.extname(target).toLowerCase();
        const mime = mimeMap[ext];
        if (!mime || !/^ppt\/media\//i.test(target)) continue;
        const getter = entries.get(target);
        if (!getter) continue;
        try {
          const imgBuf = getter();
          if (imgBuf.length <= 400 * 1024) {
            imageDataUri = `data:${mime};base64,${imgBuf.toString('base64')}`;
            break;
          }
        } catch {}
      }
    }
    const title = paras[0] || `Slide ${idx + 1}`;
    const bullets = paras.slice(1, 14);
    return {
      page: idx + 1,
      title,
      bullets,
      imageDataUri
    };
  });
}

async function resolvePptxBackingPdfAsync(fsPath, stat, cacheDir) {
  const dir = path.dirname(fsPath);
  const stem = path.basename(fsPath, path.extname(fsPath));
  const siblingPdf = path.join(dir, `${stem}.pdf`);
  if (fs.existsSync(siblingPdf) && isRealPathWithinDir(siblingPdf, dir) && hasPdfMagicHeader(siblingPdf)) {
    try {
      const pdfStat = fs.statSync(siblingPdf);
      if (pdfStat.mtimeMs >= stat.mtimeMs - 120000) {
        return { pdfPath: siblingPdf, sourceKind: 'sibling-pdf' };
      }
    } catch {}
  }

  const cachedPdf = path.join(cacheDir, 'deck.pdf');
  if (hasPdfMagicHeader(cachedPdf)) {
    return { pdfPath: cachedPdf, sourceKind: 'cached-pdf' };
  }

  const exportedPdf = await exportPptxToPdfViaPowerPointAsync(fsPath, cacheDir);
  if (exportedPdf) {
    return { pdfPath: exportedPdf, sourceKind: 'ppt-com' };
  }

  const slides = extractPptxSlidesFallback(fsPath);
  return { pdfPath: '', sourceKind: 'ooxml-slides', slides };
}

async function renderPdfPageViaPythonAsync(pdfPath, pageNum, cacheDir) {
  if (process.env.THEO_FORCE_WINRT_PDF === '1') {
    throw new Error('WinRT forced');
  }
  const pyExe = findPythonExeForPdf();
  const pyScript = [
    'import json, os, pathlib, pymupdf',
    'doc = pymupdf.open(os.environ["THEO_PDF_IN"])',
    'n = len(doc)',
    'if n < 1: raise RuntimeError("Empty PDF")',
    'req = int(os.environ.get("THEO_PAGE_NUM", "1") or "1")',
    'p = max(1, min(n, req))',
    'page = doc[p - 1]',
    'r = page.rect',
    'scale = min(2.5, max(1.0, 1920.0 / max(r.width, r.height, 1.0)))',
    'pix = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False)',
    'out_dir = pathlib.Path(os.environ["THEO_OUT_DIR"])',
    'png = pix.tobytes("png")',
    'if len(png) <= 580 * 1024:',
    '  fname = f"page-{p:04d}.png"; mime = "image/png"; data = png',
    'else:',
    '  fname = f"page-{p:04d}.jpg"; mime = "image/jpeg"; data = pix.tobytes("jpg", jpg_quality=86)',
    'tmp = out_dir / (fname + f".{os.getpid()}.tmp")',
    'tmp.write_bytes(data)',
    'tmp.replace(out_dir / fname)',
    'print(json.dumps({"ok": True, "pageCount": n, "page": p, "width": pix.width, "height": pix.height, "mime": mime, "file": fname}))'
  ].join('\n');

  const { stdout } = await withDeliverableSemaphore(() =>
    runExecFileAsync(pyExe, ['-c', pyScript], {
      timeout: 20000,
      env: {
        ...process.env,
        THEO_PDF_IN: pdfPath,
        THEO_OUT_DIR: cacheDir,
        THEO_PAGE_NUM: String(pageNum || 1)
      }
    })
  );
  const parsed = JSON.parse(stdout.trim().split(/\r?\n/).pop() || '{}');
  if (!parsed || !parsed.ok || !parsed.file) {
    throw new Error('Invalid Python PDF output');
  }
  return parsed;
}

async function renderPdfPageViaWinRtAsync(pdfPath, pageNum, cacheDir) {
  if (process.platform !== 'win32') {
    throw new Error('WinRT PDF unavailable outside Windows');
  }
  const psScript = [
    '$ErrorActionPreference = "Stop"',
    'Add-Type -AssemblyName System.Runtime.WindowsRuntime',
    '$null = [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]',
    '$null = [Windows.Data.Pdf.PdfDocument,Windows.Data.Pdf,ContentType=WindowsRuntime]',
    '$null = [Windows.Data.Pdf.PdfPageRenderOptions,Windows.Data.Pdf,ContentType=WindowsRuntime]',
    '$null = [Windows.Storage.Streams.InMemoryRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]',
    '$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq "AsTask" -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 })[0]',
    'function Await($op, $t) { $m = $asTask.MakeGenericMethod($t); $task = $m.Invoke($null, @($op)); $task.Wait() | Out-Null; return $task.Result }',
    '$asActionTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq "AsTask" -and -not $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 })[0]',
    'function AwaitAct($op) { $task = $asActionTask.Invoke($null, @($op)); $task.Wait() | Out-Null }',
    '$sf = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($env:THEO_PDF_IN)) ([Windows.Storage.StorageFile])',
    '$doc = Await ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($sf)) ([Windows.Data.Pdf.PdfDocument])',
    '$n = [int]$doc.PageCount',
    'if ($n -lt 1) { throw "Empty PDF" }',
    '$req = [int]$env:THEO_PAGE_NUM; if ($req -lt 1) { $req = 1 }; if ($req -gt $n) { $req = $n }',
    '$pg = $doc.GetPage([uint32]($req - 1))',
    '$sz = $pg.Size',
    '$maxDim = [Math]::Max($sz.Width, $sz.Height); if ($maxDim -lt 1) { $maxDim = 1000 }',
    '$w = [uint32][Math]::Round(1920 * ($sz.Width / $maxDim))',
    '$h = [uint32][Math]::Round(1920 * ($sz.Height / $maxDim))',
    'if ($w -lt 1) { $w = 1920 }; if ($h -lt 1) { $h = 1080 }',
    '$opts = New-Object Windows.Data.Pdf.PdfPageRenderOptions',
    '$opts.DestinationWidth = $w; $opts.DestinationHeight = $h',
    '$stream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream',
    'AwaitAct ($pg.RenderToStreamAsync($stream, $opts))',
    '$stream.Seek(0)',
    '$netStream = [System.IO.WindowsRuntimeStreamExtensions]::AsStream($stream)',
    '$fname = ("page-{0:D4}.png" -f $req)',
    '$outPath = Join-Path $env:THEO_OUT_DIR $fname',
    '$mime = "image/png"',
    '$fs = [System.IO.File]::Open($outPath, [System.IO.FileMode]::Create)',
    '$netStream.CopyTo($fs); $fs.Close(); $stream.Dispose(); $pg.Dispose()',
    'if ((Get-Item $outPath).Length -gt 593920) {',
    '  try {',
    '    Add-Type -AssemblyName System.Drawing',
    '    $jpgName = ("page-{0:D4}.jpg" -f $req)',
    '    $jpgPath = Join-Path $env:THEO_OUT_DIR $jpgName',
    '    $bmp = [System.Drawing.Bitmap]::FromFile($outPath)',
    '    $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq "image/jpeg" } | Select-Object -First 1',
    '    $ep = New-Object System.Drawing.Imaging.EncoderParameters(1)',
    '    $ep.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter([System.Drawing.Imaging.Encoder]::Quality, [long]85)',
    '    $bmp.Save($jpgPath, $codec, $ep)',
    '    $bmp.Dispose()',
    '    if ((Get-Item $jpgPath).Length -lt (Get-Item $outPath).Length) {',
    '      Remove-Item $outPath -Force -ErrorAction SilentlyContinue',
    '      $fname = $jpgName; $mime = "image/jpeg"',
    '    } else { Remove-Item $jpgPath -Force -ErrorAction SilentlyContinue }',
    '  } catch {}',
    '}',
    '@{ ok=$true; pageCount=$n; page=$req; width=[int]$w; height=[int]$h; mime=$mime; file=$fname } | ConvertTo-Json -Compress'
  ].join('\n');

  const { stdout } = await withDeliverableSemaphore(() =>
    runExecFileAsync(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psScript],
      {
        timeout: 25000,
        env: {
          ...process.env,
          THEO_PDF_IN: pdfPath,
          THEO_OUT_DIR: cacheDir,
          THEO_PAGE_NUM: String(pageNum || 1)
        }
      }
    )
  );
  const parsed = JSON.parse(stdout.trim().split(/\r?\n/).pop() || '{}');
  if (!parsed || !parsed.ok || !parsed.file) {
    throw new Error('Invalid WinRT PDF output');
  }
  return parsed;
}

const DELIVERABLE_META_LOCK_SYMBOL = Symbol.for('bhfirms.theoHub.deliverableMetaLocks');
function getDeliverableMetaLockMap() {
  if (!globalThis[DELIVERABLE_META_LOCK_SYMBOL]) {
    globalThis[DELIVERABLE_META_LOCK_SYMBOL] = new Map();
  }
  return globalThis[DELIVERABLE_META_LOCK_SYMBOL];
}

async function withDirMetaLock(cacheDir, fn) {
  const locks = getDeliverableMetaLockMap();
  const prev = locks.get(cacheDir) || Promise.resolve();
  let release;
  const mine = new Promise((resolve) => { release = resolve; });
  const tail = prev.then(() => mine, () => mine);
  locks.set(cacheDir, tail);
  await prev;
  try {
    return await fn();
  } finally {
    release();
    if (locks.get(cacheDir) === tail) locks.delete(cacheDir);
  }
}

async function renderPdfPageAsync(pdfPath, pageNumber, cacheDir) {
  if (!hasPdfMagicHeader(pdfPath)) {
    return { ok: false, error: 'Invalid PDF header' };
  }
  const reqPage = Math.max(1, parseInt(pageNumber, 10) || 1);
  const metaPath = path.join(cacheDir, 'meta.json');
  let meta = null;
  try {
    if (fs.existsSync(metaPath)) {
      meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
    }
  } catch {
    meta = null;
  }

  const clampedFromMeta = meta?.pageCount ? Math.max(1, Math.min(Number(meta.pageCount), reqPage)) : reqPage;
  const cachedPageInfo = meta?.pages?.[String(clampedFromMeta)];
  if (cachedPageInfo && cachedPageInfo.file) {
    const cachedFile = path.join(cacheDir, cachedPageInfo.file);
    if (fs.existsSync(cachedFile)) {
      return {
        ok: true,
        pageCount: Number(meta.pageCount),
        page: clampedFromMeta,
        width: Number(cachedPageInfo.width || 0),
        height: Number(cachedPageInfo.height || 0),
        pageMime: cachedPageInfo.mime || 'image/png',
        pageImageBase64: fs.readFileSync(cachedFile).toString('base64')
      };
    }
  }

  let info = null;
  try {
    info = await renderPdfPageViaPythonAsync(pdfPath, reqPage, cacheDir);
  } catch {
    info = await renderPdfPageViaWinRtAsync(pdfPath, reqPage, cacheDir);
  }

  const outFile = path.join(cacheDir, info.file);
  const imgBuf = fs.readFileSync(outFile);
  await withDirMetaLock(cacheDir, async () => {
    let latestMeta = null;
    try {
      if (fs.existsSync(metaPath)) {
        latestMeta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
      }
    } catch {
      latestMeta = null;
    }
    const nextMeta = latestMeta && typeof latestMeta === 'object' ? latestMeta : { pageCount: info.pageCount, pages: {} };
    nextMeta.pageCount = Number(info.pageCount);
    nextMeta.pages = nextMeta.pages && typeof nextMeta.pages === 'object' ? nextMeta.pages : {};
    nextMeta.pages[String(info.page)] = {
      width: Number(info.width || 0),
      height: Number(info.height || 0),
      mime: info.mime || 'image/png',
      file: info.file
    };
    const tmpMeta = path.join(cacheDir, `meta.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`);
    try {
      fs.writeFileSync(tmpMeta, JSON.stringify(nextMeta), 'utf8');
      fs.renameSync(tmpMeta, metaPath);
    } catch {
      try { if (fs.existsSync(tmpMeta)) fs.unlinkSync(tmpMeta); } catch {}
    }
  });

  return {
    ok: true,
    pageCount: Number(info.pageCount),
    page: Number(info.page),
    width: Number(info.width || 0),
    height: Number(info.height || 0),
    pageMime: info.mime || 'image/png',
    pageImageBase64: imgBuf.toString('base64')
  };
}

async function renderDeliverablePageAsync(fsPath, pageNumber = 1, opts = {}) {
  const kind = classifyDeliverableKind(fsPath);
  if (kind !== 'pdf' && kind !== 'pptx') {
    return { ok: false, error: `Page rendering unsupported for ${kind || 'unknown'} deliverable` };
  }
  const stat = fs.statSync(fsPath);
  let siblingStat = null;
  if (kind === 'pptx') {
    const dir = path.dirname(fsPath);
    const stem = path.basename(fsPath, path.extname(fsPath));
    const sibPath = path.join(dir, `${stem}.pdf`);
    try {
      if (fs.existsSync(sibPath) && isRealPathWithinDir(sibPath, dir) && hasPdfMagicHeader(sibPath)) {
        siblingStat = fs.statSync(sibPath);
      }
    } catch {}
  }
  const cacheDir = computeDeliverableCacheDir(fsPath, stat, siblingStat);
  const inflight = getDeliverableInFlightMap();
  const lockKey = `${cacheDir}::p${Math.max(1, parseInt(pageNumber, 10) || 1)}`;
  if (inflight.has(lockKey)) {
    return inflight.get(lockKey);
  }
  const prom = (async () => {
    let pdfPath = fsPath;
    let sourceKind = 'pdf';
    if (kind === 'pptx') {
      const resolved = await resolvePptxBackingPdfAsync(fsPath, stat, cacheDir);
      sourceKind = resolved.sourceKind;
      if (!resolved.pdfPath) {
        const slides = Array.isArray(resolved.slides) ? resolved.slides : [];
        if (slides.length === 0) {
          return {
            ok: true,
            kind: 'pptx',
            sourceKind,
            file: path.basename(fsPath),
            fullPath: fsPath,
            size: stat.size,
            mtime: stat.mtimeMs,
            pageCount: 0,
            page: 0,
            slides: [],
            pageImageBase64: '',
            pageMime: ''
          };
        }
        const p = Math.max(1, Math.min(slides.length, parseInt(pageNumber, 10) || 1));
        return {
          ok: true,
          kind: 'pptx',
          sourceKind,
          file: path.basename(fsPath),
          fullPath: fsPath,
          size: stat.size,
          mtime: stat.mtimeMs,
          pageCount: slides.length,
          page: p,
          slides,
          pageImageBase64: '',
          pageMime: ''
        };
      }
      pdfPath = resolved.pdfPath;
    }

    const rendered = await renderPdfPageAsync(pdfPath, pageNumber, cacheDir);
    if (!rendered.ok) return rendered;
    return {
      ...rendered,
      kind,
      sourceKind,
      file: path.basename(fsPath),
      fullPath: fsPath,
      size: stat.size,
      mtime: stat.mtimeMs
    };
  })();

  inflight.set(lockKey, prom);
  try {
    return await prom;
  } finally {
    if (inflight.get(lockKey) === prom) {
      inflight.delete(lockKey);
    }
  }
}

async function inspectDeliverableAsync(fsPath, opts = {}) {
  const kind = classifyDeliverableKind(fsPath);
  if (!kind) {
    return { ok: false, error: 'Unsupported deliverable type' };
  }
  const stat = fs.statSync(fsPath);
  if (kind === 'html') {
    return prepareHtmlPreviewPayload(fsPath, opts);
  }
  if (kind === 'spreadsheet') {
    const wb = parseSpreadsheetFile(fsPath);
    return {
      ok: true,
      kind: 'spreadsheet',
      file: wb.fileName,
      fullPath: fsPath,
      size: wb.fileSize,
      mtime: wb.mtimeMs,
      unsupportedBinary: Boolean(wb.unsupportedBinary),
      sheets: wb.sheets
    };
  }
  return renderDeliverablePageAsync(fsPath, Number(opts.page || 1), opts);
}

function buildDeliverableWebviewHtml(initialData) {
  const payload = initialData && typeof initialData === 'object' ? initialData : { ok: false, error: 'Empty deliverable' };
  const safeJson = JSON.stringify(payload)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
  const titleText = escapeHtml(payload.file || 'Deliverable Preview');
  const kind = String(payload.kind || '').toLowerCase();
  const isHtml = kind === 'html';
  const isPptx = kind === 'pptx';

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${titleText}</title>
<style>
  :root {
    --bg: var(--vscode-editor-background, #141417);
    --fg: var(--vscode-editor-foreground, #e5e7eb);
    --bar: var(--vscode-editorGroupHeader-tabsBackground, #1b1c22);
    --border: var(--vscode-panel-border, rgba(148,163,184,0.22));
    --btn: var(--vscode-button-secondaryBackground, #272932);
    --btn-fg: var(--vscode-button-secondaryForeground, #f3f4f6);
    --accent: #c8a24d;
    --muted: var(--vscode-descriptionForeground, #9ca3af);
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; height: 100%; width: 100%; background: var(--bg); color: var(--fg); font-family: var(--vscode-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif); overflow: hidden; display: flex; flex-direction: column; }
  [hidden] { display: none !important; }
  .toolbar { flex: 0 0 auto; display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 6px 12px; background: var(--bar); border-bottom: 1px solid var(--border); flex-wrap: wrap; min-height: 40px; }
  .tb-left, .tb-center, .tb-right { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
  .tb-title { font-weight: 600; font-size: 12.5px; max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .tb-meta { font-size: 11px; color: var(--muted); }
  .btn { appearance: none; border: 1px solid var(--border); background: var(--btn); color: var(--btn-fg); border-radius: 5px; padding: 4px 9px; font-size: 11.5px; font-weight: 500; cursor: pointer; line-height: 1.3; }
  .btn:hover:not(:disabled) { border-color: var(--accent); }
  .btn.active { border-color: var(--accent); color: var(--accent); }
  .btn:disabled { opacity: 0.45; cursor: default; }
  .stage-wrap { flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column; overflow: hidden; position: relative; }
  .html-frame { width: 100%; height: 100%; border: 0; background: #ffffff; flex: 1 1 auto; }
  .source-pre { flex: 1 1 auto; margin: 0; padding: 14px 16px; overflow: auto; font-family: var(--vscode-editor-font-family, ui-monospace, monospace); font-size: 12px; line-height: 1.5; white-space: pre; tab-size: 2; }
  .deck-main { flex: 1 1 auto; min-height: 0; overflow: auto; display: flex; flex-direction: column; align-items: center; gap: 16px; padding: 18px; }
  .page-card { background: #1e2028; border: 1px solid var(--border); border-radius: 8px; box-shadow: 0 12px 34px rgba(0,0,0,0.42); overflow: hidden; max-width: 100%; display: flex; flex-direction: column; align-items: center; }
  .page-card img { display: block; max-width: 100%; height: auto; background: #ffffff; }
  .page-cap { font-size: 11px; color: var(--muted); padding: 6px 10px; width: 100%; text-align: center; border-top: 1px solid var(--border); }
  .ooxml-card { width: min(920px, 100%); aspect-ratio: 16 / 9; background: linear-gradient(155deg, #1b2232 0%, #121722 100%); border: 1px solid var(--border); border-radius: 10px; padding: 28px 34px; display: flex; flex-direction: column; gap: 14px; overflow: auto; box-shadow: 0 12px 34px rgba(0,0,0,0.4); }
  .ooxml-title { font-size: 22px; font-weight: 700; color: #f8fafc; border-bottom: 2px solid var(--accent); padding-bottom: 8px; }
  .ooxml-bullets { margin: 0; padding-left: 20px; display: flex; flex-direction: column; gap: 8px; font-size: 14px; line-height: 1.5; color: #cbd5e1; }
  .thumb-strip { flex: 0 0 auto; display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-top: 1px solid var(--border); background: var(--bar); overflow-x: auto; }
  .thumb-btn { flex: 0 0 auto; min-width: 44px; padding: 4px 9px; border-radius: 5px; border: 1px solid var(--border); background: var(--btn); color: var(--btn-fg); font-size: 11px; cursor: pointer; }
  .thumb-btn.active { border-color: var(--accent); color: var(--accent); font-weight: 700; }
  .status-msg { padding: 28px; text-align: center; color: var(--muted); font-size: 13px; }
</style>
</head>
<body>
<div class="toolbar">
  <div class="tb-left">
    <span class="tb-title" id="tb-title">${titleText}</span>
    <span class="tb-meta" id="tb-meta"></span>
  </div>
  <div class="tb-center" id="tb-nav" ${isHtml ? 'hidden' : ''}>
    <button type="button" class="btn" id="btn-prev">Prev</button>
    <span class="tb-meta" id="page-indicator">1 / 1</span>
    <button type="button" class="btn" id="btn-next">Next</button>
    <button type="button" class="btn active" id="btn-mode-single">Single</button>
    <button type="button" class="btn" id="btn-mode-all">All Pages</button>
    <button type="button" class="btn" id="btn-zoom-out">-</button>
    <button type="button" class="btn active" id="btn-zoom-fit">Fit</button>
    <button type="button" class="btn" id="btn-zoom-in">+</button>
  </div>
  <div class="tb-center" id="tb-html-nav" ${isHtml ? '' : 'hidden'}>
    <button type="button" class="btn active" id="btn-html-preview">Preview</button>
    <button type="button" class="btn" id="btn-html-source">Source</button>
  </div>
  <div class="tb-right">
    <button type="button" class="btn" id="btn-open-ext">${isPptx ? 'Open in PowerPoint' : isHtml ? 'Open in Browser' : 'Open External'}</button>
    <button type="button" class="btn" id="btn-open-text" ${isHtml ? '' : 'hidden'}>Open Text Editor</button>
    <button type="button" class="btn" id="btn-reveal">Reveal</button>
    <button type="button" class="btn" id="btn-reload">Reload</button>
  </div>
</div>
<div class="stage-wrap">
  <iframe id="dlv-frame" class="html-frame" sandbox="allow-scripts allow-forms allow-modals" ${isHtml ? '' : 'hidden'}></iframe>
  <pre id="dlv-source" class="source-pre" hidden></pre>
  <div id="dlv-deck" class="deck-main" ${isHtml ? 'hidden' : ''}></div>
  <div id="dlv-thumbs" class="thumb-strip" ${isHtml ? 'hidden' : ''}></div>
</div>
<script id="dlv-json" type="application/json">${safeJson}</script>
<script>
(function(){
  var vscode = typeof acquireVsCodeApi === 'function' ? acquireVsCodeApi() : { postMessage: function(){} };
  var data = {};
  try { data = JSON.parse(document.getElementById('dlv-json').textContent || '{}'); } catch (e) { data = { ok: false, error: String(e) }; }
  var pageCache = {};
  var inFlightPages = {};
  var curPage = Number(data.page || 1);
  var pageCount = Number(data.pageCount !== undefined ? data.pageCount : (Array.isArray(data.slides) ? data.slides.length : 1));
  var viewMode = 'single';
  var htmlMode = 'preview';
  var zoomPct = 0;

  var metaEl = document.getElementById('tb-meta');
  var frameEl = document.getElementById('dlv-frame');
  var srcEl = document.getElementById('dlv-source');
  var deckEl = document.getElementById('dlv-deck');
  var thumbsEl = document.getElementById('dlv-thumbs');
  var pageIndEl = document.getElementById('page-indicator');

  function fmtBytes(n) {
    n = Number(n || 0);
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(2) + ' MB';
  }

  function storePage(p) {
    if (p && p.page && (p.pageImageBase64 || p.slides)) {
      pageCache[Number(p.page)] = p;
    }
  }
  storePage(data);

  function renderHtml() {
    metaEl.textContent = fmtBytes(data.size) + (data.truncated ? ' (truncated)' : '');
    if (htmlMode === 'preview') {
      frameEl.hidden = false;
      srcEl.hidden = true;
      frameEl.srcdoc = String(data.sandboxedHtml || data.sourceHtml || '');
    } else {
      frameEl.hidden = true;
      srcEl.hidden = false;
      srcEl.textContent = String(data.sourceHtml || '');
    }
    document.getElementById('btn-html-preview').classList.toggle('active', htmlMode === 'preview');
    document.getElementById('btn-html-source').classList.toggle('active', htmlMode === 'source');
  }

  function createOoxmlCard(slide) {
    var card = document.createElement('div');
    card.className = 'ooxml-card';
    var h = document.createElement('div');
    h.className = 'ooxml-title';
    h.textContent = String(slide.title || ('Slide ' + slide.page));
    card.appendChild(h);
    if (Array.isArray(slide.bullets) && slide.bullets.length) {
      var ul = document.createElement('ul');
      ul.className = 'ooxml-bullets';
      for (var i = 0; i < slide.bullets.length; i++) {
        var li = document.createElement('li');
        li.textContent = String(slide.bullets[i] || '');
        ul.appendChild(li);
      }
      card.appendChild(ul);
    }
    if (slide.imageDataUri) {
      var im = document.createElement('img');
      im.src = slide.imageDataUri;
      im.style.maxWidth = '100%';
      im.style.borderRadius = '6px';
      card.appendChild(im);
    }
    return card;
  }

  function renderPageSlot(pNum) {
    var cached = pageCache[pNum];
    if (Array.isArray(data.slides) && data.slides.length === 0) {
      var emptyMsg = document.createElement('div');
      emptyMsg.className = 'status-msg';
      emptyMsg.textContent = 'No slides found in this presentation.';
      return emptyMsg;
    }
    if (!cached && Array.isArray(data.slides) && data.slides[pNum - 1]) {
      return createOoxmlCard(data.slides[pNum - 1]);
    }
    if (!cached) {
      var loading = document.createElement('div');
      loading.className = 'status-msg';
      loading.textContent = 'Rendering ' + (data.kind === 'pptx' ? 'Slide ' : 'Page ') + pNum + '...';
      if (!inFlightPages[pNum]) {
        inFlightPages[pNum] = true;
        vscode.postMessage({ type: 'requestPage', page: pNum });
      }
      return loading;
    }
    if (Array.isArray(cached.slides) && !cached.pageImageBase64) {
      if (cached.slides[pNum - 1]) {
        return createOoxmlCard(cached.slides[pNum - 1]);
      }
      var emptySl = document.createElement('div');
      emptySl.className = 'status-msg';
      emptySl.textContent = 'No slides found in this presentation.';
      return emptySl;
    }
    var card = document.createElement('div');
    card.className = 'page-card';
    if (zoomPct > 0) {
      card.style.width = zoomPct + '%';
    }
    var img = document.createElement('img');
    img.src = 'data:' + (cached.pageMime || 'image/png') + ';base64,' + cached.pageImageBase64;
    img.alt = (data.kind === 'pptx' ? 'Slide ' : 'Page ') + pNum;
    if (zoomPct > 0) {
      img.style.width = '100%';
    } else {
      img.style.maxHeight = viewMode === 'single' ? 'calc(100vh - 140px)' : 'none';
    }
    card.appendChild(img);
    var cap = document.createElement('div');
    cap.className = 'page-cap';
    cap.textContent = (data.kind === 'pptx' ? 'Slide ' : 'Page ') + pNum + ' of ' + pageCount;
    card.appendChild(cap);
    return card;
  }

  function renderDeck() {
    if (!data.ok) {
      deckEl.innerHTML = '';
      var errDiv = document.createElement('div');
      errDiv.className = 'status-msg';
      errDiv.textContent = data.error || 'Unable to preview deliverable.';
      deckEl.appendChild(errDiv);
      return;
    }
    var unitLabel = data.kind === 'pptx' ? 'Slide' : 'Page';
    metaEl.textContent = fmtBytes(data.size) + (data.sourceKind ? ' | ' + data.sourceKind : '');
    pageIndEl.textContent = unitLabel + ' ' + curPage + ' / ' + pageCount;
    document.getElementById('btn-prev').disabled = curPage <= 1;
    document.getElementById('btn-next').disabled = curPage >= pageCount;
    document.getElementById('btn-mode-single').classList.toggle('active', viewMode === 'single');
    document.getElementById('btn-mode-all').classList.toggle('active', viewMode === 'all');
    document.getElementById('btn-zoom-fit').classList.toggle('active', zoomPct === 0);
    document.getElementById('btn-zoom-fit').textContent = zoomPct === 0 ? 'Fit' : zoomPct + '%';

    deckEl.innerHTML = '';
    if (viewMode === 'single') {
      deckEl.appendChild(renderPageSlot(curPage));
    } else {
      var capPages = Math.min(pageCount, 40);
      for (var i = 1; i <= capPages; i++) {
        deckEl.appendChild(renderPageSlot(i));
      }
    }

    thumbsEl.innerHTML = '';
    if (pageCount > 1) {
      thumbsEl.hidden = false;
      for (var t = 1; t <= pageCount; t++) {
        (function(pNum){
          var b = document.createElement('button');
          b.type = 'button';
          b.className = 'thumb-btn' + (pNum === curPage ? ' active' : '');
          b.textContent = String(pNum);
          b.addEventListener('click', function(){ curPage = pNum; viewMode = 'single'; renderDeck(); });
          thumbsEl.appendChild(b);
        })(t);
      }
    } else {
      thumbsEl.hidden = true;
    }
  }

  function render() {
    if (data.kind === 'html') renderHtml();
    else renderDeck();
  }

  document.getElementById('btn-html-preview').addEventListener('click', function(){ htmlMode = 'preview'; renderHtml(); });
  document.getElementById('btn-html-source').addEventListener('click', function(){ htmlMode = 'source'; renderHtml(); });
  document.getElementById('btn-prev').addEventListener('click', function(){ if (curPage > 1) { curPage -= 1; renderDeck(); } });
  document.getElementById('btn-next').addEventListener('click', function(){ if (curPage < pageCount) { curPage += 1; renderDeck(); } });
  document.getElementById('btn-mode-single').addEventListener('click', function(){ viewMode = 'single'; renderDeck(); });
  document.getElementById('btn-mode-all').addEventListener('click', function(){ viewMode = 'all'; renderDeck(); });
  document.getElementById('btn-zoom-fit').addEventListener('click', function(){ zoomPct = 0; renderDeck(); });
  document.getElementById('btn-zoom-in').addEventListener('click', function(){ zoomPct = zoomPct === 0 ? 115 : Math.min(200, zoomPct + 20); renderDeck(); });
  document.getElementById('btn-zoom-out').addEventListener('click', function(){ zoomPct = zoomPct === 0 ? 80 : Math.max(40, zoomPct - 20); renderDeck(); });
  document.getElementById('btn-open-ext').addEventListener('click', function(){ vscode.postMessage({ type: 'openExternal' }); });
  document.getElementById('btn-open-text').addEventListener('click', function(){ vscode.postMessage({ type: 'openTextEditor' }); });
  document.getElementById('btn-reveal').addEventListener('click', function(){ vscode.postMessage({ type: 'reveal' }); });
  document.getElementById('btn-reload').addEventListener('click', function(){ pageCache = {}; vscode.postMessage({ type: 'reload' }); });

  window.addEventListener('keydown', function(e){
    if (data.kind === 'html') return;
    if (e.key === 'ArrowLeft' && curPage > 1) { e.preventDefault(); curPage -= 1; renderDeck(); }
    if (e.key === 'ArrowRight' && curPage < pageCount) { e.preventDefault(); curPage += 1; renderDeck(); }
  });

  window.addEventListener('message', function(e){
    var msg = e.data;
    if (!msg || typeof msg !== 'object') return;
    if (msg.type === 'deliverableUpdated' && msg.data) {
      data = msg.data;
      pageCache = {};
      inFlightPages = {};
      storePage(data);
      pageCount = Number(data.pageCount !== undefined ? data.pageCount : (Array.isArray(data.slides) ? data.slides.length : 1));
      curPage = pageCount > 0 ? Math.max(1, Math.min(pageCount, curPage)) : 0;
      render();
    } else if (msg.type === 'pageData' && msg.data) {
      delete inFlightPages[Number(msg.data.page)];
      storePage(msg.data);
      if (Number(msg.data.pageCount || 0) > 0) pageCount = Number(msg.data.pageCount);
      renderDeck();
    }
  });

  render();
})();
</script>
</body>
</html>`;
}

function attachDeliverablePanelLifecycle(vscode, panel, fsPath) {
  const normKey = path.resolve(fsPath).toLowerCase();
  const openMap = getDeliverableOpenPanelsMap();
  panel.__bhfFsPath = fsPath;
  openMap.set(normKey, panel);

  const renderFromDisk = async (isUpdate = false) => {
    try {
      const data = await inspectDeliverableAsync(fsPath, { page: 1 });
      if (isUpdate && panel.__bhfDeliverableRenderVersion === DELIVERABLE_HTML_RENDER_VERSION) {
        panel.webview.postMessage({ type: 'deliverableUpdated', data }).then(() => {}, () => {});
      } else {
        panel.webview.html = buildDeliverableWebviewHtml(data);
        panel.__bhfDeliverableRenderVersion = DELIVERABLE_HTML_RENDER_VERSION;
      }
    } catch (err) {
      panel.webview.html = buildDeliverableWebviewHtml({
        ok: false,
        kind: classifyDeliverableKind(fsPath) || 'pdf',
        file: path.basename(fsPath),
        error: err?.message || String(err)
      });
    }
  };

  renderFromDisk(false).catch(() => {});

  const msgSub = panel.webview.onDidReceiveMessage(async (msg) => {
    if (!msg || typeof msg !== 'object') return;
    const fileUri = vscode.Uri.file(fsPath);
    if (msg.type === 'reload') {
      renderFromDisk(true).catch(() => {});
    } else if (msg.type === 'requestPage') {
      try {
        const pageData = await renderDeliverablePageAsync(fsPath, Number(msg.page || 1));
        panel.webview.postMessage({ type: 'pageData', data: pageData }).then(() => {}, () => {});
      } catch {}
    } else if (msg.type === 'reveal') {
      vscode.commands.executeCommand('revealFileInOS', fileUri).then(() => {}, () => {});
    } else if (msg.type === 'openExternal') {
      vscode.env.openExternal(fileUri).then(() => {}, () => {});
    } else if (msg.type === 'openTextEditor') {
      vscode.commands.executeCommand('vscode.openWith', fileUri, 'default').then(
        () => {},
        () => vscode.commands.executeCommand('vscode.open', fileUri, { preview: false }).then(() => {}, () => {})
      );
    }
  });

  let lastMtime = 0;
  try { lastMtime = fs.statSync(fsPath).mtimeMs; } catch {}
  const watcher = (curr) => {
    if (curr && curr.mtimeMs > 0 && curr.mtimeMs !== lastMtime) {
      lastMtime = curr.mtimeMs;
      renderFromDisk(true).catch(() => {});
    }
  };
  try {
    fs.watchFile(fsPath, { persistent: false, interval: 2500 }, watcher);
  } catch {}

  panel.onDidDispose(() => {
    if (openMap.get(normKey) === panel) {
      openMap.delete(normKey);
    }
    try { msgSub.dispose(); } catch {}
    try { fs.unwatchFile(fsPath, watcher); } catch {}
  });
}

async function openDeliverablePreviewTab(vscode, rawUriOrPath, options = {}) {
  const fsPath = normalizeFilePathFromUri(vscode, rawUriOrPath);
  if (!fsPath || !fs.existsSync(fsPath)) {
    throw new Error(`Deliverable not found: ${fsPath || rawUriOrPath}`);
  }
  const normKey = path.resolve(fsPath).toLowerCase();
  const openMap = getDeliverableOpenPanelsMap();
  const existing = openMap.get(normKey);
  if (existing) {
    try {
      existing.reveal(options.viewColumn || existing.viewColumn || vscode.ViewColumn.Active, false);
      const data = await inspectDeliverableAsync(fsPath, { page: 1 });
      if (existing.__bhfDeliverableRenderVersion !== DELIVERABLE_HTML_RENDER_VERSION) {
        existing.webview.html = buildDeliverableWebviewHtml(data);
        existing.__bhfFsPath = fsPath;
        existing.__bhfDeliverableRenderVersion = DELIVERABLE_HTML_RENDER_VERSION;
      } else {
        existing.webview.postMessage({ type: 'deliverableUpdated', data }).then(() => {}, () => {});
      }
      return existing;
    } catch {
      openMap.delete(normKey);
    }
  }

  const targetCol = options.viewColumn || vscode.ViewColumn.One;
  const panel = vscode.window.createWebviewPanel(
    'theoHub.deliverableViewerTab',
    path.basename(fsPath),
    { viewColumn: targetCol, preserveFocus: false },
    {
      enableScripts: true,
      retainContextWhenHidden: true,
      localResourceRoots: [vscode.Uri.file(path.dirname(fsPath))]
    }
  );
  attachDeliverablePanelLifecycle(vscode, panel, fsPath);
  return panel;
}

function upgradeOpenExcelPanels() {
  const openMap = getOpenPanelsMap();
  let upgraded = 0;
  for (const [normKey, panel] of openMap.entries()) {
    if (!panel || !panel.webview) {
      openMap.delete(normKey);
      continue;
    }
    if (panel.__bhfHtmlRenderVersion === EXCEL_HTML_RENDER_VERSION) {
      continue;
    }
    let targetPath = panel.__bhfFsPath || '';
    if (!targetPath && normKey && fs.existsSync(normKey)) {
      try {
        targetPath = fs.realpathSync?.native ? fs.realpathSync.native(normKey) : normKey;
      } catch {
        targetPath = normKey;
      }
    }
    if (targetPath && fs.existsSync(targetPath)) {
      try {
        const data = parseSpreadsheetFile(targetPath);
        panel.webview.html = buildSpreadsheetWebviewHtml(data);
        panel.__bhfFsPath = targetPath;
        panel.__bhfHtmlRenderVersion = EXCEL_HTML_RENDER_VERSION;
        upgraded += 1;
      } catch {}
    }
  }
  const delivMap = getDeliverableOpenPanelsMap();
  for (const [normKey, panel] of delivMap.entries()) {
    if (!panel || !panel.webview) {
      delivMap.delete(normKey);
      continue;
    }
    if (panel.__bhfDeliverableRenderVersion === DELIVERABLE_HTML_RENDER_VERSION) {
      continue;
    }
    const targetPath = panel.__bhfFsPath || normKey;
    if (targetPath && fs.existsSync(targetPath)) {
      inspectDeliverableAsync(targetPath, { page: 1 })
        .then((data) => {
          panel.webview.html = buildDeliverableWebviewHtml(data);
          panel.__bhfFsPath = targetPath;
          panel.__bhfDeliverableRenderVersion = DELIVERABLE_HTML_RENDER_VERSION;
        })
        .catch(() => {});
      upgraded += 1;
    }
  }
  return upgraded;
}

async function openExcelPreviewTab(vscode, rawUriOrPath, options = {}) {
  const fsPath = normalizeFilePathFromUri(vscode, rawUriOrPath);
  if (!fsPath || !fs.existsSync(fsPath)) {
    throw new Error(`Workbook not found: ${fsPath || rawUriOrPath}`);
  }
  const normKey = path.resolve(fsPath).toLowerCase();
  const openMap = getOpenPanelsMap();
  const existing = openMap.get(normKey);
  if (existing) {
    try {
      existing.reveal(options.viewColumn || existing.viewColumn || vscode.ViewColumn.Active, false);
      const data = parseSpreadsheetFile(fsPath);
      if (existing.__bhfHtmlRenderVersion !== EXCEL_HTML_RENDER_VERSION) {
        existing.webview.html = buildSpreadsheetWebviewHtml(data);
        existing.__bhfFsPath = fsPath;
        existing.__bhfHtmlRenderVersion = EXCEL_HTML_RENDER_VERSION;
      } else {
        existing.webview.postMessage({ type: 'workbookUpdated', workbook: data }).then(() => {}, () => {});
      }
      return existing;
    } catch {
      openMap.delete(normKey);
    }
  }

  const targetCol = options.viewColumn || vscode.ViewColumn.One;
  const panel = vscode.window.createWebviewPanel(
    'theoHub.excelViewerTab',
    path.basename(fsPath),
    { viewColumn: targetCol, preserveFocus: false },
    {
      enableScripts: true,
      retainContextWhenHidden: true,
      localResourceRoots: [vscode.Uri.file(path.dirname(fsPath))]
    }
  );
  attachPanelLifecycle(vscode, panel, fsPath);
  return panel;
}

function ensureExcelPreviewRegistered(vscode, context) {
  upgradeOpenExcelPanels();
  if (!vscode?.window) return;
  const st = getProviderState();
  st.renderImpl = (panel, fsPath) => attachPanelLifecycle(vscode, panel, fsPath);

  if (!st.customEditorRegistered && typeof vscode.window.registerCustomEditorProvider === 'function') {
    try {
      const provider = {
        async openCustomDocument(uri) {
          return { uri, dispose() {} };
        },
        async resolveCustomEditor(document, webviewPanel) {
          webviewPanel.webview.options = {
            enableScripts: true,
            localResourceRoots: [vscode.Uri.file(path.dirname(document.uri.fsPath))]
          };
          const impl = getProviderState().renderImpl;
          if (impl) impl(webviewPanel, document.uri.fsPath);
        }
      };
      const disp = vscode.window.registerCustomEditorProvider(EXCEL_PREVIEW_VIEW_TYPE, provider, {
        webviewOptions: { retainContextWhenHidden: true },
        supportsMultipleEditorsPerDocument: false
      });
      st.customEditorRegistered = true;
      context?.subscriptions?.push?.(disp);
    } catch {}
  }

  if (!st.commandRegistered && vscode.commands) {
    try {
      const cmdDisp = vscode.commands.registerCommand('theoHub.openExcelPreview', async (uriOrPath) => {
        const target =
          uriOrPath ||
          vscode.window.activeTextEditor?.document?.uri ||
          null;
        if (target) {
          await openExcelPreviewTab(vscode, target);
        }
      });
      st.commandRegistered = true;
      context?.subscriptions?.push?.(cmdDisp);
    } catch {}
  }

  const dst = getDeliverableProviderState();
  dst.renderImpl = (panel, fsPath) => attachDeliverablePanelLifecycle(vscode, panel, fsPath);

  if (!dst.customEditorRegistered && typeof vscode.window.registerCustomEditorProvider === 'function') {
    try {
      const delivProvider = {
        async openCustomDocument(uri) {
          return { uri, dispose() {} };
        },
        async resolveCustomEditor(document, webviewPanel) {
          webviewPanel.webview.options = {
            enableScripts: true,
            localResourceRoots: [vscode.Uri.file(path.dirname(document.uri.fsPath))]
          };
          const impl = getDeliverableProviderState().renderImpl;
          if (impl) impl(webviewPanel, document.uri.fsPath);
        }
      };
      const disp2 = vscode.window.registerCustomEditorProvider(DELIVERABLE_PREVIEW_VIEW_TYPE, delivProvider, {
        webviewOptions: { retainContextWhenHidden: true },
        supportsMultipleEditorsPerDocument: false
      });
      dst.customEditorRegistered = true;
      context?.subscriptions?.push?.(disp2);
    } catch {}
  }

  if (!dst.commandRegistered && vscode.commands) {
    try {
      const cmdDisp2 = vscode.commands.registerCommand('theoHub.openDeliverablePreview', async (uriOrPath) => {
        const target =
          uriOrPath ||
          vscode.window.activeTextEditor?.document?.uri ||
          null;
        if (target) {
          await openDeliverablePreviewTab(vscode, target);
        }
      });
      dst.commandRegistered = true;
      context?.subscriptions?.push?.(cmdDisp2);
    } catch {}
  }
}

async function openFileUriSmart(vscode, rawUriOrPath, fallbackOrigFn = null) {
  const fsPath = normalizeFilePathFromUri(vscode, rawUriOrPath);
  if (fsPath && SPREADSHEET_EXT_RE.test(fsPath) && fs.existsSync(fsPath)) {
    await openExcelPreviewTab(vscode, fsPath);
    return { handled: true, mode: 'excelPreview' };
  }

  if (fsPath && HTML_DELIVERABLE_EXT_RE.test(fsPath) && fs.existsSync(fsPath)) {
    if (hasExplicitLineTarget(rawUriOrPath)) {
      if (typeof fallbackOrigFn === 'function') {
        const res = await fallbackOrigFn();
        return { handled: true, mode: 'orig', result: res };
      }
      await vscode.commands.executeCommand('vscode.open', vscode.Uri.file(fsPath), { preview: true });
      return { handled: true, mode: 'vscodeOpen' };
    }
    await openDeliverablePreviewTab(vscode, fsPath);
    return { handled: true, mode: 'htmlPreview' };
  }

  if (fsPath && (PDF_DELIVERABLE_EXT_RE.test(fsPath) || PPTX_DELIVERABLE_EXT_RE.test(fsPath)) && fs.existsSync(fsPath)) {
    await openDeliverablePreviewTab(vscode, fsPath);
    return { handled: true, mode: 'deliverablePreview' };
  }

  if (fsPath && DIRECT_EXTERNAL_OFFICE_EXT_RE.test(fsPath) && fs.existsSync(fsPath)) {
    await vscode.env.openExternal(vscode.Uri.file(fsPath));
    return { handled: true, mode: 'officeExternal' };
  }

  if (fsPath && VSCODE_OPEN_BINARY_EXT_RE.test(fsPath) && fs.existsSync(fsPath)) {
    const fileUri = vscode.Uri.file(fsPath);
    await vscode.commands.executeCommand('vscode.open', fileUri, { preview: true });
    return { handled: true, mode: 'vscodeOpen' };
  }

  if (typeof fallbackOrigFn === 'function') {
    try {
      const res = await fallbackOrigFn();
      return { handled: true, mode: 'orig', result: res };
    } catch (err) {
      // Binary file fallback when openTextDocument rejects
      if (fsPath && fs.existsSync(fsPath)) {
        const fileUri = vscode.Uri.file(fsPath);
        try {
          await vscode.commands.executeCommand('vscode.open', fileUri, { preview: true });
          return { handled: true, mode: 'vscodeOpenFallback' };
        } catch {
          await vscode.env.openExternal(fileUri);
          return { handled: true, mode: 'externalFallback' };
        }
      }
      throw err;
    }
  }

  if (fsPath && fs.existsSync(fsPath)) {
    await vscode.commands.executeCommand('vscode.open', vscode.Uri.file(fsPath), { preview: true });
    return { handled: true, mode: 'vscodeOpenDirect' };
  }
  return { handled: false };
}

module.exports = {
  EXCEL_PREVIEW_VIEW_TYPE,
  EXCEL_HTML_RENDER_VERSION,
  DELIVERABLE_PREVIEW_VIEW_TYPE,
  DELIVERABLE_HTML_RENDER_VERSION,
  SPREADSHEET_EXT_RE,
  HTML_DELIVERABLE_EXT_RE,
  PDF_DELIVERABLE_EXT_RE,
  PPTX_DELIVERABLE_EXT_RE,
  DELIVERABLE_EXT_RE,
  hasExplicitLineTarget,
  classifyDeliverableKind,
  getDocPreviewCacheRoot,
  injectOpaqueStorageShim,
  prepareHtmlPreviewPayload,
  extractPptxSlidesFallback,
  inspectDeliverableAsync,
  renderDeliverablePageAsync,
  renderPdfPageAsync,
  computeDeliverableCacheDir,
  buildDeliverableWebviewHtml,
  openDeliverablePreviewTab,
  normalizeFilePathFromUri,
  parseSpreadsheetFile,
  buildSpreadsheetWebviewHtml,
  openExcelPreviewTab,
  upgradeOpenExcelPanels,
  ensureExcelPreviewRegistered,
  openFileUriSmart
};
