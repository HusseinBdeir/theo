'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const EXCEL_PREVIEW_VIEW_TYPE = 'theoHub.excelPreview';
const EXCEL_HTML_RENDER_VERSION = 2;
const EXCEL_PANEL_CACHE_SYMBOL = Symbol.for('bhfirms.theoHub.excelPanelsByPath');
const EXCEL_PROVIDER_STATE_SYMBOL = Symbol.for('bhfirms.theoHub.excelProviderState');

const SPREADSHEET_EXT_RE = /\.(xlsx|xlsm|xls|xlsb|ods)$/i;
const VSCODE_OPEN_BINARY_EXT_RE = /\.(pdf|png|jpe?g|gif|webp|bmp|ico|cur|avif|mp4|webm|mov|mp3|wav|ogg|flac|woff2?|ttf|otf)$/i;
const EXTERNAL_OFFICE_EXT_RE = /\.(docx?|pptx?|vsdx?|msg)$/i;

function getOpenPanelsMap() {
  if (!globalThis[EXCEL_PANEL_CACHE_SYMBOL]) {
    globalThis[EXCEL_PANEL_CACHE_SYMBOL] = new Map();
  }
  return globalThis[EXCEL_PANEL_CACHE_SYMBOL];
}

function getProviderState() {
  if (!globalThis[EXCEL_PROVIDER_STATE_SYMBOL]) {
    globalThis[EXCEL_PROVIDER_STATE_SYMBOL] = {
      customEditorRegistered: false,
      commandRegistered: false,
      renderImpl: null
    };
  }
  return globalThis[EXCEL_PROVIDER_STATE_SYMBOL];
}

function normalizeFilePathFromUri(vscode, rawUriOrPath) {
  if (!rawUriOrPath) return '';
  if (typeof rawUriOrPath === 'object' && typeof rawUriOrPath.fsPath === 'string') {
    return rawUriOrPath.fsPath;
  }
  const str = String(rawUriOrPath || '').trim();
  if (!str) return '';

  if (/^file:\/\//i.test(str)) {
    try {
      if (vscode?.Uri?.parse) {
        const parsed = vscode.Uri.parse(str);
        if (parsed?.fsPath) {
          let p = parsed.fsPath;
          if (/%[0-9A-Fa-f]{2}/.test(p) && !fs.existsSync(p)) {
            try {
              const decoded = decodeURIComponent(p);
              if (fs.existsSync(decoded)) p = decoded;
            } catch {}
          }
          return p;
        }
      }
    } catch {}
    try {
      const u = new URL(str);
      let p = decodeURIComponent(u.pathname || '');
      if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
      return p.replace(/\//g, path.sep);
    } catch {}
  }

  return str;
}

// ---------------------------------------------------------------------------
// Minimal Zero-Dependency ZIP Central-Directory Reader + OOXML (.xlsx/.xlsm) Parser
// ---------------------------------------------------------------------------

function readZipEntries(buf) {
  const entries = new Map();
  if (!Buffer.isBuffer(buf) || buf.length < 22) {
    return entries;
  }
  if (buf.readUInt32LE(0) !== 0x04034b50) {
    return entries;
  }

  // Locate End of Central Directory (0x06054b50)
  const minPos = Math.max(0, buf.length - 65558);
  let eocd = -1;
  for (let i = buf.length - 22; i >= minPos; i -= 1) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) {
    return entries;
  }

  const totalEntries = buf.readUInt16LE(eocd + 10);
  const cdOffset = buf.readUInt32LE(eocd + 16);
  let ptr = cdOffset;

  for (let idx = 0; idx < totalEntries && ptr + 46 <= buf.length; idx += 1) {
    if (buf.readUInt32LE(ptr) !== 0x02014b50) break;
    const compMethod = buf.readUInt16LE(ptr + 10);
    const compSize = buf.readUInt32LE(ptr + 20);
    const uncompSize = buf.readUInt32LE(ptr + 24);
    const nameLen = buf.readUInt16LE(ptr + 28);
    const extraLen = buf.readUInt16LE(ptr + 30);
    const commentLen = buf.readUInt16LE(ptr + 32);
    const localOffset = buf.readUInt32LE(ptr + 42);
    const rawName = buf.toString('utf8', ptr + 46, ptr + 46 + nameLen);
    const normName = rawName.replace(/^\/+/, '').replace(/\\/g, '/');
    ptr += 46 + nameLen + extraLen + commentLen;

    if (localOffset + 30 > buf.length) continue;
    if (buf.readUInt32LE(localOffset) !== 0x04034b50) continue;
    const localNameLen = buf.readUInt16LE(localOffset + 26);
    const localExtraLen = buf.readUInt16LE(localOffset + 28);
    const dataStart = localOffset + 30 + localNameLen + localExtraLen;

    entries.set(normName, () => {
      if (compMethod === 0) {
        return buf.subarray(dataStart, dataStart + uncompSize);
      }
      if (compMethod === 8) {
        return zlib.inflateRawSync(buf.subarray(dataStart, dataStart + compSize));
      }
      throw new Error(`Unsupported ZIP compression method ${compMethod}`);
    });
  }
  return entries;
}

function readZipText(entries, entryPath) {
  const clean = String(entryPath || '').replace(/^\/+/, '').replace(/\\/g, '/');
  let getter = entries.get(clean);
  if (!getter) {
    const lower = clean.toLowerCase();
    for (const [k, v] of entries.entries()) {
      if (k.toLowerCase() === lower) {
        getter = v;
        break;
      }
    }
  }
  if (!getter) return '';
  return getter().toString('utf8');
}

function decodeXmlText(raw) {
  if (!raw) return '';
  return String(raw)
    .replace(/_x([0-9A-Fa-f]{4})_/g, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
    .replace(/&#x([0-9A-Fa-f]+);/g, (_, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, dec) => String.fromCodePoint(parseInt(dec, 10)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

function parseXmlAttrs(attrStr) {
  const attrs = {};
  if (!attrStr) return attrs;
  const re = /([A-Za-z0-9_:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
  let m;
  while ((m = re.exec(attrStr)) !== null) {
    attrs[m[1]] = decodeXmlText(m[2] !== undefined ? m[2] : m[3]);
  }
  return attrs;
}

function colLettersToIndex(letters) {
  let n = 0;
  for (let i = 0; i < letters.length; i += 1) {
    n = n * 26 + (letters.charCodeAt(i) - 64);
  }
  return n - 1; // 0-based
}

function indexToColLetters(idx) {
  let n = idx + 1;
  let out = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    out = String.fromCharCode(65 + rem) + out;
    n = Math.floor((n - 1) / 26);
  }
  return out;
}

function parseCellRef(ref) {
  const m = /^([A-Za-z]+)(\d+)$/.exec(String(ref || '').trim());
  if (!m) return null;
  return {
    col: colLettersToIndex(m[1].toUpperCase()),
    row: parseInt(m[2], 10) - 1
  };
}

function parseRangeRef(ref) {
  const parts = String(ref || '').split(':');
  const start = parseCellRef(parts[0]);
  const end = parts[1] ? parseCellRef(parts[1]) : start;
  if (!start || !end) return null;
  return {
    r1: Math.min(start.row, end.row),
    c1: Math.min(start.col, end.col),
    r2: Math.max(start.row, end.row),
    c2: Math.max(start.col, end.col)
  };
}

function parseSharedStrings(xml) {
  if (!xml) return [];
  const out = [];
  const siRe = /<si\b[^>]*>([\s\S]*?)<\/si>/g;
  let m;
  while ((m = siRe.exec(xml)) !== null) {
    // Strip phonetic <rPh>...</rPh> blocks
    const body = m[1].replace(/<rPh\b[^>]*>[\s\S]*?<\/rPh>/g, '');
    const tRe = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g;
    let tm;
    let combined = '';
    while ((tm = tRe.exec(body)) !== null) {
      combined += decodeXmlText(tm[1]);
    }
    out.push(combined);
  }
  return out;
}

const BUILTIN_NUM_FMTS = {
  0: 'General',
  1: '0',
  2: '0.00',
  3: '#,##0',
  4: '#,##0.00',
  9: '0%',
  10: '0.00%',
  11: '0.00E+00',
  14: 'dd-mm-yy',
  15: 'd-mmm-yy',
  16: 'd-mmm',
  17: 'mmm-yy',
  18: 'h:mm AM/PM',
  19: 'h:mm:ss AM/PM',
  20: 'h:mm',
  21: 'h:mm:ss',
  22: 'dd-mm-yy h:mm',
  37: '#,##0 ;(#,##0)',
  38: '#,##0 ;[Red](#,##0)',
  39: '#,##0.00;(#,##0.00)',
  40: '#,##0.00;[Red](#,##0.00)',
  44: '$#,##0.00',
  45: 'mm:ss',
  46: '[h]:mm:ss',
  47: 'mmss.0',
  49: '@'
};

function classifyNumFmt(numFmtId, rawCode) {
  const code = String(rawCode || BUILTIN_NUM_FMTS[numFmtId] || 'General');
  if (
    (numFmtId >= 14 && numFmtId <= 22) ||
    (numFmtId >= 27 && numFmtId <= 36) ||
    (numFmtId >= 45 && numFmtId <= 47)
  ) {
    return { code, kind: 'date' };
  }
  if (numFmtId === 9 || numFmtId === 10) {
    return { code, kind: 'percent' };
  }
  const firstSection = code.split(';')[0] || '';
  const stripped = firstSection
    .replace(/"[^"]*"/g, '')
    .replace(/\\./g, '')
    .replace(/\[[^\]]*\]/g, '');
  if (stripped.includes('%')) {
    return { code, kind: 'percent' };
  }
  if (/[dmyhs]/i.test(stripped) && !/[#0]/.test(stripped)) {
    return { code, kind: 'date' };
  }
  const hasDollar = /\$/.test(firstSection);
  const hasComma = stripped.includes(',');
  const decMatch = /\.(0+)/.exec(stripped);
  const decimals = decMatch ? decMatch[1].length : null;
  return {
    code,
    kind: hasDollar ? 'currency' : hasComma || decimals !== null ? 'number' : 'general',
    decimals,
    hasComma
  };
}

function parseStyles(xml) {
  const customFmts = new Map();
  const fontsBold = [];
  const cellXfs = [];

  if (!xml) return { cellXfs };

  const nfRe = /<numFmt\b([^>]*)\/?>/g;
  let m;
  while ((m = nfRe.exec(xml)) !== null) {
    const a = parseXmlAttrs(m[1]);
    if (a.numFmtId !== undefined && a.formatCode !== undefined) {
      customFmts.set(Number(a.numFmtId), a.formatCode);
    }
  }

  const fontsBlock = /<fonts\b[^>]*>([\s\S]*?)<\/fonts>/.exec(xml);
  if (fontsBlock) {
    const fRe = /<font\b[^>]*>([\s\S]*?)<\/font>/g;
    let fm;
    while ((fm = fRe.exec(fontsBlock[1])) !== null) {
      const isBold = /<b(?:\s+val="(?:1|true)")?\s*\/?>/i.test(fm[1]) && !/<b\s+val="(?:0|false)"/i.test(fm[1]);
      fontsBold.push(isBold);
    }
  }

  const xfsBlock = /<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/.exec(xml);
  if (xfsBlock) {
    const xfRe = /<xf\b([^>/]*)(?:\/>|>[\s\S]*?<\/xf>)/g;
    let xm;
    while ((xm = xfRe.exec(xfsBlock[1])) !== null) {
      const a = parseXmlAttrs(xm[1]);
      const numFmtId = Number(a.numFmtId || 0);
      const fontId = Number(a.fontId || 0);
      const fmtCode = customFmts.get(numFmtId) || BUILTIN_NUM_FMTS[numFmtId] || 'General';
      cellXfs.push({
        numFmtId,
        bold: Boolean(fontsBold[fontId]),
        ...classifyNumFmt(numFmtId, fmtCode)
      });
    }
  }

  return { cellXfs };
}

const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatExcelDate(serial, code, is1904) {
  const num = Number(serial);
  if (!Number.isFinite(num)) return String(serial);
  const baseDays = is1904 ? num + 1462 : num < 60 ? num + 1 : num;
  const utcMs = Date.UTC(1899, 11, 30) + Math.round(baseDays * 86400000);
  const dt = new Date(utcMs);
  if (Number.isNaN(dt.getTime())) return String(serial);

  const yyyy = dt.getUTCFullYear();
  const yy = String(yyyy).slice(-2);
  const m = dt.getUTCMonth() + 1;
  const mm = String(m).padStart(2, '0');
  const mmm = MONTH_SHORT[m - 1];
  const d = dt.getUTCDate();
  const dd = String(d).padStart(2, '0');
  const lc = String(code || '').toLowerCase();

  if (lc.includes('mmm') && lc.includes('yyyy')) {
    return `${dd}-${mmm}-${yyyy}`;
  }
  if (lc.includes('mmm')) {
    return `${dd}-${mmm}-${yy}`;
  }
  if (lc.includes('yyyy-mm-dd') || lc.includes('yyyy/mm/dd')) {
    return `${yyyy}-${mm}-${dd}`;
  }
  if (lc.includes('h:mm')) {
    const hh = String(dt.getUTCHours()).padStart(2, '0');
    const mi = String(dt.getUTCMinutes()).padStart(2, '0');
    if (num < 1) return `${hh}:${mi}`;
    return `${dd}-${mm}-${yy} ${hh}:${mi}`;
  }
  return `${dd}-${mm}-${yy}`;
}

function formatExcelNumber(num, xf) {
  if (!Number.isFinite(num)) return String(num);
  // Clean IEEE-754 representation dust (e.g. 4406.5999999999985 -> 4406.6)
  const cleaned = Math.abs(num) < 1e12 ? Number(num.toPrecision(12)) : num;

  if (!xf || xf.kind === 'general') {
    if (Number.isInteger(cleaned)) {
      return String(cleaned);
    }
    return String(Number(cleaned.toFixed(6)));
  }
  if (xf.kind === 'percent') {
    const dec = xf.decimals !== null ? xf.decimals : 1;
    return `${(cleaned * 100).toFixed(dec).replace(/\.0+$/, '')}%`;
  }
  if (xf.kind === 'currency') {
    const dec = xf.decimals !== null ? xf.decimals : Number.isInteger(cleaned) ? 0 : 2;
    const absStr = Math.abs(cleaned).toLocaleString('en-US', {
      minimumFractionDigits: dec,
      maximumFractionDigits: dec
    });
    return cleaned < 0 ? `($${absStr})` : `$${absStr}`;
  }
  if (xf.kind === 'number') {
    const dec = xf.decimals !== null ? xf.decimals : Number.isInteger(cleaned) ? 0 : 2;
    return cleaned.toLocaleString('en-US', {
      useGrouping: Boolean(xf.hasComma),
      minimumFractionDigits: dec,
      maximumFractionDigits: dec
    });
  }
  return String(cleaned);
}

function resolveRelTarget(baseDir, target) {
  if (!target) return '';
  const clean = String(target).replace(/\\/g, '/');
  if (clean.startsWith('/')) return clean.slice(1);
  return path.posix.normalize(path.posix.join(baseDir, clean));
}

function parseRelsMap(xml, baseDir) {
  const map = new Map();
  if (!xml) return map;
  const relRe = /<Relationship\b([^>]*)\/?>/g;
  let m;
  while ((m = relRe.exec(xml)) !== null) {
    const a = parseXmlAttrs(m[1]);
    if (a.Id && a.Target) {
      map.set(a.Id, resolveRelTarget(baseDir, a.Target));
    }
  }
  return map;
}

function parseWorksheet(sheetXml, sheetRelsXml, entries, sharedStrings, styles, is1904) {
  const colWidths = {};
  const colBlock = /<cols\b[^>]*>([\s\S]*?)<\/cols>/.exec(sheetXml);
  if (colBlock) {
    const cRe = /<col\b([^>]*)\/?>/g;
    let cm;
    while ((cm = cRe.exec(colBlock[1])) !== null) {
      const a = parseXmlAttrs(cm[1]);
      const minC = Math.max(1, Number(a.min || 1));
      const maxC = Math.min(256, Number(a.max || minC));
      const w = Number(a.width || 0);
      if (w > 0) {
        for (let c = minC; c <= maxC; c += 1) {
          colWidths[c - 1] = w;
        }
      }
    }
  }

  // Detect Excel Tables on this sheet
  const tables = [];
  if (sheetRelsXml) {
    const sRels = parseRelsMap(sheetRelsXml, 'xl/worksheets');
    const tpRe = /<tablePart\b([^>]*)\/?>/g;
    let tm;
    while ((tm = tpRe.exec(sheetXml)) !== null) {
      const a = parseXmlAttrs(tm[1]);
      const rid = a['r:id'] || a.id;
      const tblPath = rid ? sRels.get(rid) : '';
      if (tblPath) {
        const tblXml = readZipText(entries, tblPath);
        const tblTag = /<table\b([^>]*)>/.exec(tblXml);
        const styleTag = /<tableStyleInfo\b([^>]*)\/?>/.exec(tblXml);
        if (tblTag) {
          const ta = parseXmlAttrs(tblTag[1]);
          const sa = styleTag ? parseXmlAttrs(styleTag[1]) : {};
          const rng = parseRangeRef(ta.ref);
          if (rng) {
            tables.push({
              name: ta.displayName || ta.name || 'Table',
              ref: ta.ref,
              styleName: sa.name || 'TableStyleMedium2',
              rowStripes: sa.showRowStripes !== '0',
              ...rng
            });
          }
        }
      }
    }
  }

  // Detect merged cells
  const merges = [];
  const mergeBlock = /<mergeCells\b[^>]*>([\s\S]*?)<\/mergeCells>/.exec(sheetXml);
  if (mergeBlock) {
    const mRe = /<mergeCell\b([^>]*)\/?>/g;
    let mm;
    while ((mm = mRe.exec(mergeBlock[1])) !== null) {
      const a = parseXmlAttrs(mm[1]);
      const rng = parseRangeRef(a.ref);
      if (rng) merges.push(rng);
    }
  }

  const rowMap = new Map();
  let maxRow = -1;
  let maxCol = -1;

  const rowRe = /<row\b([^>/]*)(?:\/>|>([\s\S]*?)<\/row>)/g;
  let rm;
  let nextFallbackRow = 0;
  while ((rm = rowRe.exec(sheetXml)) !== null) {
    const ra = parseXmlAttrs(rm[1]);
    const rIdx = ra.r ? parseInt(ra.r, 10) - 1 : nextFallbackRow;
    nextFallbackRow = rIdx + 1;
    if (!rm[2]) continue;

    const cellRe = /<c\b([^>/]*)(?:\/>|>([\s\S]*?)<\/c>)/g;
    let cm;
    let nextFallbackCol = 0;
    const cells = new Map();

    while ((cm = cellRe.exec(rm[2])) !== null) {
      const ca = parseXmlAttrs(cm[1]);
      const inner = cm[2] || '';
      const pos = ca.r ? parseCellRef(ca.r) : null;
      const cIdx = pos ? pos.col : nextFallbackCol;
      nextFallbackCol = cIdx + 1;

      const cType = ca.t || '';
      const sIdx = ca.s !== undefined ? Number(ca.s) : -1;
      const xf = sIdx >= 0 ? styles.cellXfs[sIdx] : null;

      const fMatch = /<f(?:\s[^>]*)?>([\s\S]*?)<\/f>/.exec(inner);
      const formula = fMatch ? decodeXmlText(fMatch[1]) : '';
      const vMatch = /<v(?:\s[^>]*)?>([\s\S]*?)<\/v>/.exec(inner);
      const rawV = vMatch ? vMatch[1] : null;

      let text = '';
      let numVal = null;
      let align = 'left';

      if (cType === 's') {
        const sId = rawV !== null ? parseInt(rawV, 10) : -1;
        text = sId >= 0 && sId < sharedStrings.length ? sharedStrings[sId] : '';
      } else if (cType === 'inlineStr') {
        const tRe = /<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g;
        let tm2;
        while ((tm2 = tRe.exec(inner)) !== null) {
          text += decodeXmlText(tm2[1]);
        }
      } else if (cType === 'str' || cType === 'e') {
        text = rawV !== null ? decodeXmlText(rawV) : '';
      } else if (cType === 'b') {
        text = rawV === '1' || rawV === 'true' ? 'TRUE' : 'FALSE';
        align = 'center';
      } else if (rawV !== null && rawV !== '') {
        const parsedNum = Number(rawV);
        if (Number.isFinite(parsedNum)) {
          if (xf && xf.kind === 'date') {
            text = formatExcelDate(parsedNum, xf.code, is1904);
          } else {
            numVal = Math.abs(parsedNum) < 1e12 ? Number(parsedNum.toPrecision(12)) : parsedNum;
            text = formatExcelNumber(parsedNum, xf);
            align = 'right';
          }
        } else {
          text = decodeXmlText(rawV);
        }
      }

      if (text !== '' || formula !== '' || (xf && xf.bold)) {
        cells.set(cIdx, {
          t: text,
          n: numVal,
          f: formula ? (formula.startsWith('=') ? formula : `=${formula}`) : '',
          b: Boolean(xf?.bold),
          a: align
        });
        if (rIdx > maxRow) maxRow = rIdx;
        if (cIdx > maxCol) maxCol = cIdx;
      }
    }

    if (cells.size > 0) {
      rowMap.set(rIdx, cells);
    }
  }

  for (const tbl of tables) {
    if (tbl.r2 > maxRow) maxRow = tbl.r2;
    if (tbl.c2 > maxCol) maxCol = tbl.c2;
  }

  const rowCount = Math.min(Math.max(maxRow + 1, 0), 5000);
  const colCount = Math.min(Math.max(maxCol + 1, 0), 120);
  const grid = [];
  for (let r = 0; r < rowCount; r += 1) {
    const rCells = rowMap.get(r);
    const rowArr = new Array(colCount);
    for (let c = 0; c < colCount; c += 1) {
      rowArr[c] = rCells?.get(c) || null;
    }
    grid.push(rowArr);
  }

  return {
    rowCount,
    colCount,
    totalRowsInSheet: maxRow + 1,
    truncated: maxRow + 1 > rowCount,
    colWidths,
    tables,
    merges,
    grid
  };
}

function parseCsvText(rawText, delimiter = ',') {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  for (let i = 0; i < rawText.length; i += 1) {
    const ch = rawText[i];
    if (inQuotes) {
      if (ch === '"') {
        if (rawText[i + 1] === '"') {
          field += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        field += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === delimiter) {
      row.push(field);
      field = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && rawText[i + 1] === '\n') i += 1;
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else {
      field += ch;
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  const colCount = rows.reduce((m, r) => Math.max(m, r.length), 0);
  const cappedRows = rows.slice(0, 5000);
  const grid = cappedRows.map((r, rIdx) => {
    const arr = new Array(colCount);
    for (let c = 0; c < colCount; c += 1) {
      const v = r[c] !== undefined ? r[c] : '';
      const trimmed = v.trim();
      const num = trimmed !== '' && /^-?\d+(\.\d+)?$/.test(trimmed) ? Number(trimmed) : null;
      arr[c] = v === '' ? null : { t: v, n: num, f: '', b: rIdx === 0, a: num !== null ? 'right' : 'left' };
    }
    return arr;
  });
  return {
    name: 'Sheet1',
    rowCount: grid.length,
    colCount,
    totalRowsInSheet: rows.length,
    truncated: rows.length > grid.length,
    colWidths: {},
    tables: grid.length > 1 ? [{ name: 'CSV', r1: 0, c1: 0, r2: grid.length - 1, c2: colCount - 1, rowStripes: true }] : [],
    merges: [],
    grid
  };
}

function readWorkbookBufferSafe(filePath) {
  try {
    return fs.readFileSync(filePath);
  } catch (err) {
    if (process.platform === 'win32' && err && (err.code === 'EBUSY' || err.code === 'EPERM' || err.code === 'EACCES')) {
      const os = require('os');
      const cp = require('child_process');
      const tmpCopy = path.join(os.tmpdir(), `theo-wb-${ process.pid }-${ Date.now() }${ path.extname(filePath) }`);
      try {
        cp.execFileSync('cmd.exe', ['/d', '/s', '/c', 'copy', '/y', '/b', filePath, tmpCopy], {
          windowsHide: true,
          stdio: 'ignore',
          timeout: 5000
        });
        return fs.readFileSync(tmpCopy);
      } finally {
        try {
          fs.unlinkSync(tmpCopy);
        } catch {}
      }
    }
    throw err;
  }
}

function parseSpreadsheetFile(filePath) {
  const stat = fs.statSync(filePath);
  const ext = path.extname(filePath).toLowerCase();

  if (ext === '.csv' || ext === '.tsv') {
    const raw = readWorkbookBufferSafe(filePath).toString('utf8');
    const sheet = parseCsvText(raw, ext === '.tsv' ? '\t' : ',');
    return {
      fileName: path.basename(filePath),
      filePath,
      fileSize: stat.size,
      mtimeMs: stat.mtimeMs,
      sheets: [sheet]
    };
  }

  const buf = readWorkbookBufferSafe(filePath);
  const entries = readZipEntries(buf);
  if (entries.size === 0) {
    return {
      fileName: path.basename(filePath),
      filePath,
      fileSize: stat.size,
      mtimeMs: stat.mtimeMs,
      unsupportedBinary: true,
      sheets: []
    };
  }

  const wbXml = readZipText(entries, 'xl/workbook.xml');
  const wbRelsXml = readZipText(entries, 'xl/_rels/workbook.xml.rels');
  const sharedStrings = parseSharedStrings(readZipText(entries, 'xl/sharedStrings.xml'));
  const styles = parseStyles(readZipText(entries, 'xl/styles.xml'));
  const is1904 = /<workbookPr\b[^>]*\bdate1904="(?:1|true)"/i.test(wbXml);
  const wbRels = parseRelsMap(wbRelsXml, 'xl');

  const sheetDefs = [];
  const shRe = /<sheet\b([^>]*)\/?>/g;
  let sm;
  while ((sm = shRe.exec(wbXml)) !== null) {
    const a = parseXmlAttrs(sm[1]);
    if (a.state === 'veryHidden') continue;
    const rid = a['r:id'] || a.id;
    const target = rid ? wbRels.get(rid) : '';
    if (target) {
      sheetDefs.push({
        name: a.name || `Sheet${sheetDefs.length + 1}`,
        target
      });
    }
  }

  const sheets = sheetDefs.map((sd) => {
    const sXml = readZipText(entries, sd.target);
    const relsPath = path.posix.join(
      path.posix.dirname(sd.target),
      '_rels',
      `${path.posix.basename(sd.target)}.rels`
    );
    const sRelsXml = readZipText(entries, relsPath);
    const parsed = parseWorksheet(sXml, sRelsXml, entries, sharedStrings, styles, is1904);
    return {
      name: sd.name,
      ...parsed
    };
  });

  return {
    fileName: path.basename(filePath),
    filePath,
    fileSize: stat.size,
    mtimeMs: stat.mtimeMs,
    sheets
  };
}

// ---------------------------------------------------------------------------
// Interactive VS Code Spreadsheet Webview HTML Builder
// ---------------------------------------------------------------------------

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderInitialSheetMarkup(workbookData, activeIdx = 0) {
  const sheets = Array.isArray(workbookData?.sheets) ? workbookData.sheets : [];
  const tabsHtml = sheets
    .map(
      (s, idx) =>
        `<div class="tab${idx === activeIdx ? ' active' : ''}" data-idx="${idx}">${escapeHtml(s.name)}</div>`
    )
    .join('');

  if (workbookData?.unsupportedBinary) {
    return {
      dimsText: 'Legacy binary format',
      fxText: '',
      tabsHtml,
      gridHtml:
        '<div class="empty-state"><p>Legacy binary spreadsheet format. Click <strong>Open in Excel</strong> above to view.</p></div>'
    };
  }

  const sh = sheets[activeIdx];
  if (!sh || sh.rowCount === 0 || sh.colCount === 0) {
    return {
      dimsText: 'Empty sheet',
      fxText: '',
      tabsHtml,
      gridHtml: '<div class="empty-state">This worksheet is empty.</div>'
    };
  }

  const dimsText = `${sh.rowCount} rows × ${sh.colCount} cols${sh.truncated ? ' (preview)' : ''}`;
  const anchorCell = sh.grid?.[0]?.[0] || null;
  const fxText = anchorCell
    ? anchorCell.f
      ? `${anchorCell.f}   [${anchorCell.t}]`
      : String(anchorCell.t || '')
    : '';

  const primaryTbl = sh.tables && sh.tables[0] ? sh.tables[0] : null;
  const mergeSpan = new Map();
  const mergeSkip = new Set();
  for (const m of sh.merges || []) {
    const rs = m.r2 - m.r1 + 1;
    const cs = m.c2 - m.c1 + 1;
    if (rs > 1 || cs > 1) {
      mergeSpan.set(`${m.r1}:${m.c1}`, { rs, cs });
      for (let rr = m.r1; rr <= m.r2; rr += 1) {
        for (let cc = m.c1; cc <= m.c2; cc += 1) {
          if (rr !== m.r1 || cc !== m.c1) mergeSkip.add(`${rr}:${cc}`);
        }
      }
    }
  }

  let gridHtml = '<table class="sheet"><colgroup><col style="width:42px">';
  for (let c = 0; c < sh.colCount; c += 1) {
    const excelW = sh.colWidths && sh.colWidths[c] ? sh.colWidths[c] : 12;
    const px = Math.max(58, Math.min(340, Math.round(excelW * 8.2 + 12)));
    gridHtml += `<col style="width:${px}px">`;
  }
  gridHtml += '</colgroup><thead><tr><th class="corner"></th>';
  for (let c = 0; c < sh.colCount; c += 1) {
    gridHtml += `<th class="col-hdr">${indexToColLetters(c)}</th>`;
  }
  gridHtml += '</tr></thead><tbody>';

  for (let r = 0; r < sh.rowCount; r += 1) {
    const rowArr = sh.grid[r] || [];
    const firstCellText = rowArr[0] && rowArr[0].t ? String(rowArr[0].t).trim().toUpperCase() : '';
    let trCls = '';
    if (primaryTbl && r === primaryTbl.r1) {
      trCls = 'tbl-header';
    } else if (firstCellText === 'TOTAL' || firstCellText === 'GRAND TOTAL') {
      trCls = 'tbl-total';
    } else if (
      primaryTbl &&
      primaryTbl.rowStripes &&
      r > primaryTbl.r1 &&
      r <= primaryTbl.r2 &&
      (r - primaryTbl.r1) % 2 === 0
    ) {
      trCls = 'tbl-stripe';
    }

    gridHtml += `<tr data-r="${r}"${trCls ? ` class="${trCls}"` : ''}><th class="row-hdr">${r + 1}</th>`;
    for (let c = 0; c < sh.colCount; c += 1) {
      const key = `${r}:${c}`;
      if (mergeSkip.has(key)) continue;
      const span = mergeSpan.get(key);
      const cell = rowArr[c];
      const cls = [];
      if (cell) {
        if (cell.a === 'right' && trCls !== 'tbl-header') cls.push('align-right');
        else if (cell.a === 'center') cls.push('align-center');
        if (cell.b) cls.push('is-bold');
      }
      if (r === 0 && c === 0) {
        cls.push('sel', 'sel-anchor');
      }
      let attrs = ` data-r="${r}" data-c="${c}"`;
      if (span) {
        if (span.rs > 1) attrs += ` rowspan="${span.rs}"`;
        if (span.cs > 1) attrs += ` colspan="${span.cs}"`;
      }
      if (cls.length) attrs += ` class="${cls.join(' ')}"`;
      const txt = cell ? escapeHtml(cell.t) : '';
      if (txt.length > 18) attrs += ` title="${txt}"`;
      gridHtml += `<td${attrs}>${txt}</td>`;
    }
    gridHtml += '</tr>';
  }
  gridHtml += '</tbody></table>';

  return { dimsText, fxText, tabsHtml, gridHtml };
}

function buildSpreadsheetWebviewHtml(workbookData) {
  const safeJson = JSON.stringify(workbookData)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
  const title = escapeHtml(workbookData.fileName || 'Workbook');
  const initial = renderInitialSheetMarkup(workbookData, 0);

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${title}</title>
<style>
  :root {
    --bg: var(--vscode-editor-background, #18181b);
    --fg: var(--vscode-editor-foreground, #e4e4e7);
    --muted: var(--vscode-descriptionForeground, #a1a1aa);
    --border: var(--vscode-panel-border, rgba(255,255,255,0.10));
    --bar-bg: var(--vscode-editorWidget-background, #202024);
    --hdr-bg: var(--vscode-editorGroupHeader-tabsBackground, #232329);
    --accent: #2563eb;
    --accent-soft: rgba(37, 99, 235, 0.18);
    --tbl-hdr-bg: #2f5597;
    --tbl-hdr-fg: #ffffff;
    --tbl-stripe: rgba(59, 130, 246, 0.08);
    --tbl-total-bg: rgba(59, 130, 246, 0.16);
  }
  * { box-sizing: border-box; }
  html, body {
    margin: 0; padding: 0; width: 100%; height: 100%;
    overflow: hidden;
    background: var(--bg);
    color: var(--fg);
    font-family: var(--vscode-font-family, "Segoe UI", system-ui, sans-serif);
    font-size: 12.5px;
    user-select: none;
  }
  .app {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
  }
  .toolbar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px;
    background: var(--bar-bg);
    border-bottom: 1px solid var(--border);
    flex-shrink: 0;
  }
  .file-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-weight: 600;
    font-size: 12.5px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 340px;
  }
  .excel-dot {
    width: 8px; height: 8px; border-radius: 2px;
    background: #107c41;
    flex-shrink: 0;
  }
  .meta-pill {
    font-size: 11px;
    color: var(--muted);
    padding: 2px 7px;
    border-radius: 4px;
    background: rgba(128,128,128,0.12);
    white-space: nowrap;
  }
  .spacer { flex: 1; }
  .search-box {
    background: var(--vscode-input-background, rgba(0,0,0,0.22));
    color: var(--vscode-input-foreground, var(--fg));
    border: 1px solid var(--vscode-input-border, var(--border));
    border-radius: 4px;
    padding: 3px 8px;
    font-size: 12px;
    width: 180px;
    outline: none;
  }
  .search-box:focus { border-color: var(--accent); }
  .btn {
    background: rgba(128,128,128,0.14);
    color: var(--fg);
    border: 1px solid var(--border);
    border-radius: 4px;
    padding: 3px 9px;
    font-size: 11.5px;
    cursor: pointer;
    white-space: nowrap;
  }
  .btn:hover { background: rgba(128,128,128,0.24); }
  .btn.primary {
    background: #107c41;
    border-color: #15803d;
    color: #fff;
    font-weight: 500;
  }
  .btn.primary:hover { background: #15803d; }

  .formula-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 4px 12px;
    background: var(--hdr-bg);
    border-bottom: 1px solid var(--border);
    flex-shrink: 0;
    font-family: var(--vscode-editor-font-family, Consolas, monospace);
    font-size: 12px;
  }
  .cell-addr {
    min-width: 54px;
    text-align: center;
    padding: 2px 6px;
    border-radius: 3px;
    background: rgba(128,128,128,0.15);
    font-weight: 600;
    color: var(--fg);
  }
  .fx-glyph {
    color: var(--muted);
    font-style: italic;
    font-weight: 600;
    padding: 0 2px;
  }
  .fx-val {
    flex: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    user-select: text;
    color: var(--fg);
  }

  .grid-wrap {
    flex: 1;
    overflow: auto;
    position: relative;
  }
  table.sheet {
    border-collapse: separate;
    border-spacing: 0;
    table-layout: fixed;
    width: max-content;
  }
  table.sheet th, table.sheet td {
    border-right: 1px solid var(--border);
    border-bottom: 1px solid var(--border);
    padding: 4px 8px;
    height: 24px;
    line-height: 1.25;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-variant-numeric: tabular-nums;
  }
  table.sheet thead th.corner,
  table.sheet thead th.col-hdr {
    position: sticky;
    top: 0;
    z-index: 4;
    background: var(--hdr-bg);
    color: var(--muted);
    font-weight: 600;
    font-size: 11px;
    text-align: center;
    padding: 3px 4px;
    height: 22px;
  }
  table.sheet thead th.corner {
    left: 0;
    z-index: 6;
    width: 42px;
    min-width: 42px;
  }
  table.sheet tbody th.row-hdr {
    position: sticky;
    left: 0;
    z-index: 3;
    background: var(--hdr-bg);
    color: var(--muted);
    font-weight: 500;
    font-size: 11px;
    text-align: center;
    width: 42px;
    min-width: 42px;
    padding: 3px 4px;
  }
  /* Sticky Excel Table Header Row when table starts on row 1 */
  table.sheet tr.tbl-header th.row-hdr {
    position: sticky;
    top: 22px;
    left: 0;
    z-index: 5;
  }
  table.sheet tr.tbl-header td {
    position: sticky;
    top: 22px;
    z-index: 2;
    background: var(--tbl-hdr-bg);
    color: var(--tbl-hdr-fg);
    font-weight: 600;
    white-space: pre-line;
    height: auto;
    vertical-align: bottom;
    padding: 6px 8px;
  }
  table.sheet tr.tbl-stripe td {
    background: var(--tbl-stripe);
  }
  table.sheet tr.tbl-total td {
    background: var(--tbl-total-bg);
    font-weight: 700;
    border-top: 2px solid rgba(59, 130, 246, 0.45);
  }
  td.align-right { text-align: right; }
  td.align-center { text-align: center; }
  td.is-bold { font-weight: 700; }
  td.sel {
    background: var(--accent-soft) !important;
  }
  td.sel-anchor {
    outline: 2px solid var(--accent);
    outline-offset: -2px;
  }
  tr.filtered-out { display: none; }

  .footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 0 12px;
    height: 30px;
    background: var(--bar-bg);
    border-top: 1px solid var(--border);
    flex-shrink: 0;
  }
  .tabs {
    display: flex;
    align-items: stretch;
    gap: 2px;
    height: 100%;
    overflow-x: auto;
  }
  .tab {
    display: inline-flex;
    align-items: center;
    padding: 0 14px;
    font-size: 12px;
    color: var(--muted);
    cursor: pointer;
    border-bottom: 2px solid transparent;
    white-space: nowrap;
  }
  .tab:hover { color: var(--fg); background: rgba(128,128,128,0.08); }
  .tab.active {
    color: var(--fg);
    font-weight: 600;
    border-bottom-color: #107c41;
    background: var(--bg);
  }
  .stats {
    display: flex;
    align-items: center;
    gap: 14px;
    font-size: 11.5px;
    color: var(--muted);
    font-variant-numeric: tabular-nums;
    white-space: nowrap;
  }
  .stats strong { color: var(--fg); font-weight: 600; }
  .empty-state {
    padding: 40px;
    text-align: center;
    color: var(--muted);
  }
</style>
</head>
<body>
<div class="app">
  <div class="toolbar">
    <div class="file-badge" title="${escapeHtml(workbookData.filePath || '')}">
      <span class="excel-dot"></span>
      <span id="wb-name">${title}</span>
    </div>
    <span class="meta-pill" id="sheet-dims">${escapeHtml(initial.dimsText)}</span>
    <div class="spacer"></div>
    <input type="text" class="search-box" id="filter-input" placeholder="Filter rows…" />
    <button class="btn" id="btn-copy" title="Copy visible sheet as TSV">Copy Sheet</button>
    <button class="btn" id="btn-reload" title="Reload from disk">↻ Reload</button>
    <button class="btn" id="btn-reveal" title="Reveal in Windows Explorer">Explorer</button>
    <button class="btn primary" id="btn-excel" title="Open in desktop Microsoft Excel">Open in Excel</button>
  </div>
  <div class="formula-bar">
    <span class="cell-addr" id="cell-addr">A1</span>
    <span class="fx-glyph">fx</span>
    <span class="fx-val" id="fx-val">${escapeHtml(initial.fxText)}</span>
  </div>
  <div class="grid-wrap" id="grid-wrap">${initial.gridHtml}</div>
  <div class="footer">
    <div class="tabs" id="sheet-tabs">${initial.tabsHtml}</div>
    <div class="stats" id="sel-stats"></div>
  </div>
</div>

<script id="wb-json" type="application/json">${safeJson}</script>
<script>
(function() {
  const vscode = typeof acquireVsCodeApi === 'function' ? acquireVsCodeApi() : { postMessage: function() {} };
  const CR = String.fromCharCode(13);
  const LF = String.fromCharCode(10);
  const TAB = String.fromCharCode(9);

  let wb = JSON.parse(document.getElementById('wb-json').textContent || '{}');
  let activeSheetIdx = 0;
  let selStart = { r: 0, c: 0 };
  let selEnd = { r: 0, c: 0 };
  let isDragging = false;

  const gridWrap = document.getElementById('grid-wrap');
  const tabsEl = document.getElementById('sheet-tabs');
  const dimsEl = document.getElementById('sheet-dims');
  const addrEl = document.getElementById('cell-addr');
  const fxEl = document.getElementById('fx-val');
  const statsEl = document.getElementById('sel-stats');
  const filterInput = document.getElementById('filter-input');

  function cleanTsvCell(cell) {
    if (!cell || cell.t === undefined || cell.t === null) return '';
    return String(cell.t).split(CR).join('').split(LF).join(' ');
  }

  function colLetters(idx) {
    let n = idx + 1, s = '';
    while (n > 0) {
      const rem = (n - 1) % 26;
      s = String.fromCharCode(65 + rem) + s;
      n = Math.floor((n - 1) / 26);
    }
    return s;
  }

  function esc(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function renderTabs() {
    if (!wb.sheets || wb.sheets.length === 0) {
      tabsEl.innerHTML = '';
      return;
    }
    tabsEl.innerHTML = wb.sheets.map((s, idx) =>
      '<div class="tab' + (idx === activeSheetIdx ? ' active' : '') + '" data-idx="' + idx + '">' + esc(s.name) + '</div>'
    ).join('');
  }

  function renderSheet() {
    if (wb.unsupportedBinary) {
      dimsEl.textContent = 'Legacy binary format';
      gridWrap.innerHTML = '<div class="empty-state"><p>Legacy binary spreadsheet format. Click <strong>Open in Excel</strong> above to view.</p></div>';
      return;
    }
    const sh = wb.sheets[activeSheetIdx];
    if (!sh || sh.rowCount === 0 || sh.colCount === 0) {
      dimsEl.textContent = 'Empty sheet';
      gridWrap.innerHTML = '<div class="empty-state">This worksheet is empty.</div>';
      return;
    }

    dimsEl.textContent = sh.rowCount + ' rows × ' + sh.colCount + ' cols' + (sh.truncated ? ' (preview)' : '');
    const primaryTbl = sh.tables && sh.tables[0] ? sh.tables[0] : null;

    const mergeSpan = new Map();
    const mergeSkip = new Set();
    for (const m of (sh.merges || [])) {
      const rs = m.r2 - m.r1 + 1;
      const cs = m.c2 - m.c1 + 1;
      if (rs > 1 || cs > 1) {
        mergeSpan.set(m.r1 + ':' + m.c1, { rs, cs });
        for (let rr = m.r1; rr <= m.r2; rr++) {
          for (let cc = m.c1; cc <= m.c2; cc++) {
            if (rr !== m.r1 || cc !== m.c1) mergeSkip.add(rr + ':' + cc);
          }
        }
      }
    }

    let html = '<table class="sheet"><colgroup><col style="width:42px">';
    for (let c = 0; c < sh.colCount; c++) {
      const excelW = sh.colWidths && sh.colWidths[c] ? sh.colWidths[c] : 12;
      const px = Math.max(58, Math.min(340, Math.round(excelW * 8.2 + 12)));
      html += '<col style="width:' + px + 'px">';
    }
    html += '</colgroup><thead><tr><th class="corner"></th>';
    for (let c = 0; c < sh.colCount; c++) {
      html += '<th class="col-hdr">' + colLetters(c) + '</th>';
    }
    html += '</tr></thead><tbody>';

    for (let r = 0; r < sh.rowCount; r++) {
      const rowArr = sh.grid[r] || [];
      const firstCellText = rowArr[0] && rowArr[0].t ? String(rowArr[0].t).trim().toUpperCase() : '';
      let trCls = '';
      if (primaryTbl && r === primaryTbl.r1) {
        trCls = 'tbl-header';
      } else if (firstCellText === 'TOTAL' || firstCellText === 'GRAND TOTAL') {
        trCls = 'tbl-total';
      } else if (primaryTbl && primaryTbl.rowStripes && r > primaryTbl.r1 && r <= primaryTbl.r2 && ((r - primaryTbl.r1) % 2 === 0)) {
        trCls = 'tbl-stripe';
      }

      html += '<tr data-r="' + r + '"' + (trCls ? ' class="' + trCls + '"' : '') + '>';
      html += '<th class="row-hdr">' + (r + 1) + '</th>';
      for (let c = 0; c < sh.colCount; c++) {
        const key = r + ':' + c;
        if (mergeSkip.has(key)) continue;
        const span = mergeSpan.get(key);
        const cell = rowArr[c];
        const cls = [];
        if (cell) {
          if (cell.a === 'right' && trCls !== 'tbl-header') cls.push('align-right');
          else if (cell.a === 'center') cls.push('align-center');
          if (cell.b) cls.push('is-bold');
        }
        let attrs = ' data-r="' + r + '" data-c="' + c + '"';
        if (span) {
          if (span.rs > 1) attrs += ' rowspan="' + span.rs + '"';
          if (span.cs > 1) attrs += ' colspan="' + span.cs + '"';
        }
        if (cls.length) attrs += ' class="' + cls.join(' ') + '"';
        const txt = cell ? esc(cell.t) : '';
        if (txt.length > 18) attrs += ' title="' + txt + '"';
        html += '<td' + attrs + '>' + txt + '</td>';
      }
      html += '</tr>';
    }
    html += '</tbody></table>';
    gridWrap.innerHTML = html;
    applyFilter();
    updateSelectionUI();
  }

  function updateSelectionUI() {
    const sh = wb.sheets[activeSheetIdx];
    if (!sh) return;
    const r1 = Math.min(selStart.r, selEnd.r);
    const r2 = Math.max(selStart.r, selEnd.r);
    const c1 = Math.min(selStart.c, selEnd.c);
    const c2 = Math.max(selStart.c, selEnd.c);

    const prev = gridWrap.querySelectorAll('td.sel, td.sel-anchor');
    prev.forEach((el) => el.classList.remove('sel', 'sel-anchor'));

    let count = 0, numCount = 0, sum = 0;
    for (let r = r1; r <= r2; r++) {
      const rowEl = gridWrap.querySelector('tr[data-r="' + r + '"]');
      if (rowEl && rowEl.classList.contains('filtered-out')) continue;
      for (let c = c1; c <= c2; c++) {
        const td = rowEl ? rowEl.querySelector('td[data-c="' + c + '"]') : null;
        if (td) {
          td.classList.add('sel');
          if (r === selStart.r && c === selStart.c) td.classList.add('sel-anchor');
        }
        const cell = sh.grid[r] && sh.grid[r][c];
        if (cell && cell.t !== '') {
          count += 1;
          if (typeof cell.n === 'number' && Number.isFinite(cell.n)) {
            numCount += 1;
            sum += cell.n;
          }
        }
      }
    }

    const anchorRef = colLetters(selStart.c) + (selStart.r + 1);
    const rangeRef = (r1 === r2 && c1 === c2) ? anchorRef : (colLetters(c1) + (r1 + 1) + ':' + colLetters(c2) + (r2 + 1));
    addrEl.textContent = rangeRef;

    const anchorCell = sh.grid[selStart.r] && sh.grid[selStart.r][selStart.c];
    if (anchorCell) {
      fxEl.textContent = anchorCell.f ? (anchorCell.f + '   [' + anchorCell.t + ']') : anchorCell.t;
    } else {
      fxEl.textContent = '';
    }

    if (numCount > 1) {
      const avg = sum / numCount;
      const fmt = (n) => Number(n.toFixed(2)).toLocaleString('en-US', { maximumFractionDigits: 2 });
      statsEl.innerHTML = '<span>Count: <strong>' + count + '</strong></span><span>Avg: <strong>' + fmt(avg) + '</strong></span><span>Sum: <strong>' + fmt(sum) + '</strong></span>';
    } else if (count > 1) {
      statsEl.innerHTML = '<span>Count: <strong>' + count + '</strong></span>';
    } else {
      statsEl.innerHTML = '';
    }
  }

  function applyFilter() {
    const q = (filterInput.value || '').trim().toLowerCase();
    const sh = wb.sheets[activeSheetIdx];
    if (!sh) return;
    const primaryTbl = sh.tables && sh.tables[0] ? sh.tables[0] : null;
    const trs = gridWrap.querySelectorAll('tbody tr');
    trs.forEach((tr) => {
      const r = Number(tr.getAttribute('data-r'));
      if (!q || (primaryTbl && r === primaryTbl.r1)) {
        tr.classList.remove('filtered-out');
        return;
      }
      const rowArr = sh.grid[r] || [];
      const match = rowArr.some((cell) => cell && String(cell.t).toLowerCase().includes(q));
      tr.classList.toggle('filtered-out', !match);
    });
  }

  gridWrap.addEventListener('mousedown', (e) => {
    const td = e.target.closest('td[data-r]');
    if (!td) return;
    const r = Number(td.getAttribute('data-r'));
    const c = Number(td.getAttribute('data-c'));
    if (e.shiftKey) {
      selEnd = { r, c };
    } else {
      selStart = { r, c };
      selEnd = { r, c };
    }
    isDragging = true;
    updateSelectionUI();
  });

  gridWrap.addEventListener('mouseover', (e) => {
    if (!isDragging) return;
    const td = e.target.closest('td[data-r]');
    if (!td) return;
    selEnd = { r: Number(td.getAttribute('data-r')), c: Number(td.getAttribute('data-c')) };
    updateSelectionUI();
  });

  window.addEventListener('mouseup', () => { isDragging = false; });

  // Column header click selects entire column (excluding header row)
  gridWrap.addEventListener('click', (e) => {
    const colHdr = e.target.closest('th.col-hdr');
    if (colHdr) {
      const sh = wb.sheets[activeSheetIdx];
      if (!sh) return;
      const idx = Array.from(colHdr.parentElement.children).indexOf(colHdr) - 1;
      if (idx >= 0) {
        const startRow = sh.tables && sh.tables[0] ? sh.tables[0].r1 + 1 : 0;
        let endRow = sh.rowCount - 1;
        const lastFirst = sh.grid[endRow] && sh.grid[endRow][0] ? String(sh.grid[endRow][0].t).trim().toUpperCase() : '';
        if (lastFirst === 'TOTAL' && endRow > startRow) endRow -= 1;
        selStart = { r: startRow, c: idx };
        selEnd = { r: endRow, c: idx };
        updateSelectionUI();
      }
    }
  });

  window.addEventListener('keydown', (e) => {
    if (document.activeElement === filterInput) return;
    const sh = wb.sheets[activeSheetIdx];
    if (!sh) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') {
      const r1 = Math.min(selStart.r, selEnd.r), r2 = Math.max(selStart.r, selEnd.r);
      const c1 = Math.min(selStart.c, selEnd.c), c2 = Math.max(selStart.c, selEnd.c);
      const lines = [];
      for (let r = r1; r <= r2; r++) {
        const vals = [];
        for (let c = c1; c <= c2; c++) {
          const cell = sh.grid[r] && sh.grid[r][c];
          vals.push(cleanTsvCell(cell));
        }
        lines.push(vals.join(TAB));
      }
      navigator.clipboard.writeText(lines.join(LF)).catch(() => {});
      return;
    }
    const moves = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] };
    if (moves[e.key]) {
      e.preventDefault();
      const [dr, dc] = moves[e.key];
      const nr = Math.max(0, Math.min(sh.rowCount - 1, selStart.r + dr));
      const nc = Math.max(0, Math.min(sh.colCount - 1, selStart.c + dc));
      selStart = { r: nr, c: nc };
      if (!e.shiftKey) selEnd = { r: nr, c: nc };
      updateSelectionUI();
    }
  });

  tabsEl.addEventListener('click', (e) => {
    const tab = e.target.closest('.tab[data-idx]');
    if (!tab) return;
    activeSheetIdx = Number(tab.getAttribute('data-idx'));
    selStart = { r: 0, c: 0 };
    selEnd = { r: 0, c: 0 };
    renderTabs();
    renderSheet();
  });

  filterInput.addEventListener('input', applyFilter);

  document.getElementById('btn-copy').addEventListener('click', () => {
    const sh = wb.sheets[activeSheetIdx];
    if (!sh) return;
    const lines = sh.grid.map((row) => row.map((c) => cleanTsvCell(c)).join(TAB));
    navigator.clipboard.writeText(lines.join(LF)).catch(() => {});
  });
  document.getElementById('btn-reload').addEventListener('click', () => vscode.postMessage({ type: 'reload' }));
  document.getElementById('btn-reveal').addEventListener('click', () => vscode.postMessage({ type: 'reveal' }));
  document.getElementById('btn-excel').addEventListener('click', () => vscode.postMessage({ type: 'openExternal' }));

  window.addEventListener('message', (e) => {
    const msg = e.data;
    if (msg && msg.type === 'workbookUpdated' && msg.workbook) {
      wb = msg.workbook;
      if (activeSheetIdx >= wb.sheets.length) activeSheetIdx = 0;
      renderTabs();
      renderSheet();
    }
  });

  renderTabs();
  renderSheet();
})();
</script>
</body>
</html>`;
}

// ---------------------------------------------------------------------------
// VS Code Panel & CustomReadonlyEditorProvider Management
// ---------------------------------------------------------------------------

function attachPanelLifecycle(vscode, panel, fsPath) {
  const normKey = path.resolve(fsPath).toLowerCase();
  const openMap = getOpenPanelsMap();
  panel.__bhfFsPath = fsPath;
  openMap.set(normKey, panel);

  const renderFromDisk = (isUpdate = false) => {
    try {
      const data = parseSpreadsheetFile(fsPath);
      if (isUpdate && panel.__bhfHtmlRenderVersion === EXCEL_HTML_RENDER_VERSION) {
        panel.webview.postMessage({ type: 'workbookUpdated', workbook: data }).then(() => {}, () => {});
      } else {
        panel.webview.html = buildSpreadsheetWebviewHtml(data);
        panel.__bhfHtmlRenderVersion = EXCEL_HTML_RENDER_VERSION;
      }
    } catch (err) {
      panel.webview.html = `<!DOCTYPE html><html><body style="font-family:sans-serif;padding:24px;color:#e4e4e7;background:#18181b"><h3>Unable to read workbook</h3><p>${escapeHtml(err.message || String(err))}</p></body></html>`;
    }
  };

  renderFromDisk(false);

  const msgSub = panel.webview.onDidReceiveMessage((msg) => {
    if (!msg || typeof msg !== 'object') return;
    const fileUri = vscode.Uri.file(fsPath);
    if (msg.type === 'reload') {
      renderFromDisk(true);
    } else if (msg.type === 'reveal') {
      vscode.commands.executeCommand('revealFileInOS', fileUri).then(() => {}, () => {});
    } else if (msg.type === 'openExternal') {
      vscode.env.openExternal(fileUri).then(() => {}, () => {});
    }
  });

  let lastMtime = 0;
  try {
    lastMtime = fs.statSync(fsPath).mtimeMs;
  } catch {}
  const watcher = (curr) => {
    if (curr && curr.mtimeMs > 0 && curr.mtimeMs !== lastMtime) {
      lastMtime = curr.mtimeMs;
      renderFromDisk(true);
    }
  };
  try {
    fs.watchFile(fsPath, { persistent: false, interval: 2000 }, watcher);
  } catch {}

  panel.onDidDispose(() => {
    if (openMap.get(normKey) === panel) {
      openMap.delete(normKey);
    }
    try {
      msgSub.dispose();
    } catch {}
    try {
      fs.unwatchFile(fsPath, watcher);
    } catch {}
  });
}

function upgradeOpenExcelPanels() {
  const openMap = getOpenPanelsMap();
  let upgraded = 0;
  for (const [normKey, panel] of openMap.entries()) {
    if (!panel || !panel.webview) {
      openMap.delete(normKey);
      continue;
    }
    if (panel.__bhfHtmlRenderVersion === EXCEL_HTML_RENDER_VERSION) {
      continue;
    }
    let targetPath = panel.__bhfFsPath || '';
    if (!targetPath && normKey && fs.existsSync(normKey)) {
      try {
        targetPath = fs.realpathSync?.native ? fs.realpathSync.native(normKey) : normKey;
      } catch {
        targetPath = normKey;
      }
    }
    if (targetPath && fs.existsSync(targetPath)) {
      try {
        const data = parseSpreadsheetFile(targetPath);
        panel.webview.html = buildSpreadsheetWebviewHtml(data);
        panel.__bhfFsPath = targetPath;
        panel.__bhfHtmlRenderVersion = EXCEL_HTML_RENDER_VERSION;
        upgraded += 1;
      } catch {}
    }
  }
  return upgraded;
}

async function openExcelPreviewTab(vscode, rawUriOrPath, options = {}) {
  const fsPath = normalizeFilePathFromUri(vscode, rawUriOrPath);
  if (!fsPath || !fs.existsSync(fsPath)) {
    throw new Error(`Workbook not found: ${fsPath || rawUriOrPath}`);
  }
  const normKey = path.resolve(fsPath).toLowerCase();
  const openMap = getOpenPanelsMap();
  const existing = openMap.get(normKey);
  if (existing) {
    try {
      existing.reveal(options.viewColumn || existing.viewColumn || vscode.ViewColumn.Active, false);
      const data = parseSpreadsheetFile(fsPath);
      if (existing.__bhfHtmlRenderVersion !== EXCEL_HTML_RENDER_VERSION) {
        existing.webview.html = buildSpreadsheetWebviewHtml(data);
        existing.__bhfFsPath = fsPath;
        existing.__bhfHtmlRenderVersion = EXCEL_HTML_RENDER_VERSION;
      } else {
        existing.webview.postMessage({ type: 'workbookUpdated', workbook: data }).then(() => {}, () => {});
      }
      return existing;
    } catch {
      openMap.delete(normKey);
    }
  }

  const targetCol = options.viewColumn || vscode.ViewColumn.One;
  const panel = vscode.window.createWebviewPanel(
    'theoHub.excelViewerTab',
    path.basename(fsPath),
    { viewColumn: targetCol, preserveFocus: false },
    {
      enableScripts: true,
      retainContextWhenHidden: true,
      localResourceRoots: [vscode.Uri.file(path.dirname(fsPath))]
    }
  );
  attachPanelLifecycle(vscode, panel, fsPath);
  return panel;
}

function ensureExcelPreviewRegistered(vscode, context) {
  upgradeOpenExcelPanels();
  if (!vscode?.window) return;
  const st = getProviderState();
  st.renderImpl = (panel, fsPath) => attachPanelLifecycle(vscode, panel, fsPath);

  if (!st.customEditorRegistered && typeof vscode.window.registerCustomEditorProvider === 'function') {
    try {
      const provider = {
        async openCustomDocument(uri) {
          return { uri, dispose() {} };
        },
        async resolveCustomEditor(document, webviewPanel) {
          webviewPanel.webview.options = {
            enableScripts: true,
            localResourceRoots: [vscode.Uri.file(path.dirname(document.uri.fsPath))]
          };
          const impl = getProviderState().renderImpl;
          if (impl) impl(webviewPanel, document.uri.fsPath);
        }
      };
      const disp = vscode.window.registerCustomEditorProvider(EXCEL_PREVIEW_VIEW_TYPE, provider, {
        webviewOptions: { retainContextWhenHidden: true },
        supportsMultipleEditorsPerDocument: false
      });
      st.customEditorRegistered = true;
      context?.subscriptions?.push?.(disp);
    } catch {}
  }

  if (!st.commandRegistered && vscode.commands) {
    try {
      const cmdDisp = vscode.commands.registerCommand('theoHub.openExcelPreview', async (uriOrPath) => {
        const target =
          uriOrPath ||
          vscode.window.activeTextEditor?.document?.uri ||
          null;
        if (target) {
          await openExcelPreviewTab(vscode, target);
        }
      });
      st.commandRegistered = true;
      context?.subscriptions?.push?.(cmdDisp);
    } catch {}
  }
}

async function openFileUriSmart(vscode, rawUriOrPath, fallbackOrigFn = null) {
  const fsPath = normalizeFilePathFromUri(vscode, rawUriOrPath);
  if (fsPath && SPREADSHEET_EXT_RE.test(fsPath) && fs.existsSync(fsPath)) {
    await openExcelPreviewTab(vscode, fsPath);
    return { handled: true, mode: 'excelPreview' };
  }

  if (fsPath && VSCODE_OPEN_BINARY_EXT_RE.test(fsPath) && fs.existsSync(fsPath)) {
    const fileUri = vscode.Uri.file(fsPath);
    await vscode.commands.executeCommand('vscode.open', fileUri, { preview: true });
    return { handled: true, mode: 'vscodeOpen' };
  }

  if (fsPath && EXTERNAL_OFFICE_EXT_RE.test(fsPath) && fs.existsSync(fsPath)) {
    const fileUri = vscode.Uri.file(fsPath);
    try {
      await vscode.commands.executeCommand('vscode.open', fileUri, { preview: true });
    } catch {
      await vscode.env.openExternal(fileUri);
    }
    return { handled: true, mode: 'officeExternal' };
  }

  if (typeof fallbackOrigFn === 'function') {
    try {
      const res = await fallbackOrigFn();
      return { handled: true, mode: 'orig', result: res };
    } catch (err) {
      // Binary file fallback when openTextDocument rejects
      if (fsPath && fs.existsSync(fsPath)) {
        const fileUri = vscode.Uri.file(fsPath);
        try {
          await vscode.commands.executeCommand('vscode.open', fileUri, { preview: true });
          return { handled: true, mode: 'vscodeOpenFallback' };
        } catch {
          await vscode.env.openExternal(fileUri);
          return { handled: true, mode: 'externalFallback' };
        }
      }
      throw err;
    }
  }

  if (fsPath && fs.existsSync(fsPath)) {
    await vscode.commands.executeCommand('vscode.open', vscode.Uri.file(fsPath), { preview: true });
    return { handled: true, mode: 'vscodeOpenDirect' };
  }
  return { handled: false };
}

module.exports = {
  EXCEL_PREVIEW_VIEW_TYPE,
  EXCEL_HTML_RENDER_VERSION,
  SPREADSHEET_EXT_RE,
  normalizeFilePathFromUri,
  parseSpreadsheetFile,
  buildSpreadsheetWebviewHtml,
  openExcelPreviewTab,
  upgradeOpenExcelPanels,
  ensureExcelPreviewRegistered,
  openFileUriSmart
};
