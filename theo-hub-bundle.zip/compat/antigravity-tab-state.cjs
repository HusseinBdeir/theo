const SESSION_TAB_SCHEME = 'antigravity-session';
const SESSION_TAB_AUTHORITY = 'route';
const SESSION_TAB_VIEW_TYPE = 'antigravity.conversationEditor';
const TAB_STATE_KEY = 'antigravity-hub.tab-state.v1';

function normalizeTabText(value, maxLength = 220) {
  const clean = String(value || '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!clean) {
    return '';
  }
  return clean.length > maxLength ? `${clean.slice(0, maxLength - 1)}…` : clean;
}

function normalizeUriKey(uriOrString) {
  if (!uriOrString) {
    return '';
  }
  let raw = '';
  if (typeof uriOrString === 'string') {
    raw = uriOrString.trim();
  } else if (typeof uriOrString.toString === 'function') {
    try {
      raw = uriOrString.toString(true);
    } catch {
      raw = uriOrString.toString();
    }
    raw = String(raw || '').trim();
  }
  if (!raw) {
    return '';
  }
  if (raw.includes('%3D') || raw.includes('%3d') || raw.includes('%26')) {
    const qIdx = raw.indexOf('?');
    if (qIdx !== -1) {
      const base = raw.slice(0, qIdx);
      const query = raw
        .slice(qIdx + 1)
        .replace(/%3D/gi, '=')
        .replace(/%26/gi, '&');
      return `${base}?${query}`;
    }
  }
  return raw;
}

function buildNewSessionUriString(draftId) {
  const cleanDraftId = encodeURIComponent(String(draftId || `${Date.now()}`));
  return `${SESSION_TAB_SCHEME}://${SESSION_TAB_AUTHORITY}/new?draft=${cleanDraftId}`;
}

function buildThreadUriString(threadId) {
  const cleanThreadId = encodeURIComponent(String(threadId || '').trim());
  return `${SESSION_TAB_SCHEME}://${SESSION_TAB_AUTHORITY}/local/${cleanThreadId}`;
}

function parseSessionUri(uriOrString) {
  const key = normalizeUriKey(uriOrString);
  if (!key) {
    return { kind: 'invalid', uriKey: '' };
  }

  let parsed;
  try {
    parsed = new URL(key);
  } catch {
    return { kind: 'invalid', uriKey: key };
  }

  const scheme = parsed.protocol.replace(/:$/, '');
  if (scheme !== SESSION_TAB_SCHEME) {
    return { kind: 'invalid', uriKey: key };
  }

  const pathname = parsed.pathname || '';
  if (pathname === '/new') {
    return {
      kind: 'new',
      uriKey: key,
      draftId: parsed.searchParams.get('draft') || ''
    };
  }

  const match = pathname.match(/^\/local\/([^/]+)$/);
  if (match) {
    let threadId = match[1];
    try {
      threadId = decodeURIComponent(match[1]);
    } catch {
      threadId = match[1];
    }
    return {
      kind: 'thread',
      uriKey: key,
      threadId
    };
  }

  return { kind: 'unknown', uriKey: key };
}

function readTabStateMap(memento) {
  const raw = memento?.get ? memento.get(TAB_STATE_KEY, {}) : {};
  return raw && typeof raw === 'object' ? { ...raw } : {};
}

async function writeTabStateMap(memento, nextMap) {
  if (!memento?.update) {
    return;
  }
  await memento.update(TAB_STATE_KEY, nextMap || {});
}

function readTabState(memento, uriOrString) {
  const key = normalizeUriKey(uriOrString);
  if (!key) {
    return null;
  }
  const map = readTabStateMap(memento);
  let entry = map[key];
  if (!entry) {
    for (const [k, v] of Object.entries(map)) {
      if (normalizeUriKey(k) === key && v && typeof v === 'object') {
        entry = v;
        break;
      }
    }
  }
  return entry && typeof entry === 'object' ? { ...entry } : null;
}

async function writeTabState(memento, uriOrString, patch = {}) {
  const key = normalizeUriKey(uriOrString);
  if (!key || !memento?.update) {
    return null;
  }

  const map = readTabStateMap(memento);
  let current = map[key] && typeof map[key] === 'object' ? map[key] : null;
  for (const [k, v] of Object.entries(map)) {
    if (k !== key && normalizeUriKey(k) === key) {
      if (!current && v && typeof v === 'object') {
        current = v;
      }
      delete map[k];
    }
  }
  const next = {
    ...(current || {}),
    ...patch,
    updatedAt: Number.isFinite(patch.updatedAt) ? patch.updatedAt : Date.now()
  };

  if ('title' in patch) {
    next.title = normalizeTabText(patch.title, 96);
  }
  if ('id' in patch) {
    next.id = normalizeTabText(patch.id, 140);
  }

  map[key] = next;
  await writeTabStateMap(memento, map);
  return next;
}

async function deleteTabState(memento, uriOrString) {
  const key = normalizeUriKey(uriOrString);
  if (!key || !memento?.update) {
    return;
  }
  const map = readTabStateMap(memento);
  let changed = false;
  for (const k of Object.keys(map)) {
    if (k === key || normalizeUriKey(k) === key) {
      delete map[k];
      changed = true;
    }
  }
  if (!changed) {
    return;
  }
  await writeTabStateMap(memento, map);
}

function findDraftTabEntryForThread(memento, threadId) {
  const cleanThreadId = normalizeTabText(threadId, 140);
  if (!cleanThreadId) {
    return null;
  }
  const map = readTabStateMap(memento);
  for (const [uriKey, value] of Object.entries(map)) {
    if (value && typeof value === 'object' && value.id === cleanThreadId) {
      return { uriKey: normalizeUriKey(uriKey), state: { ...value } };
    }
  }
  return null;
}

module.exports = {
  SESSION_TAB_SCHEME,
  SESSION_TAB_AUTHORITY,
  SESSION_TAB_VIEW_TYPE,
  TAB_STATE_KEY,
  normalizeTabText,
  normalizeUriKey,
  buildNewSessionUriString,
  buildThreadUriString,
  parseSessionUri,
  readTabStateMap,
  writeTabStateMap,
  readTabState,
  writeTabState,
  deleteTabState,
  findDraftTabEntryForThread
};

