const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const net = require('net');
const os = require('os');
const path = require('path');
const { URL } = require('url');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');

const PROXY_STATE_SYMBOL = Symbol.for('bhfirms.antigravityHub.contextWindowProxyState');
const PROXY_WORKER_VERSION = 7;

function toAntigravityFolderUri(folderPath) {
  const posix = path.resolve(folderPath).replace(/\\/g, '/');
  if (/^[A-Za-z]:\//.test(posix)) {
    const drive = posix[0].toLowerCase();
    const rest = posix.slice(2).split('/').map(encodeURIComponent).join('/');
    return `file:///${drive}%3A${rest}`;
  }
  return `file://${posix.split('/').map(encodeURIComponent).join('/')}`;
}

function getDefaultTheoWorkspaceUri() {
  try {
    const homeDir = os.homedir();
    const bhfMem = path.join(homeDir, 'bhfirms', 'memory');
    if (fs.existsSync(path.join(bhfMem, 'THEO.md'))) {
      return toAntigravityFolderUri(bhfMem);
    }
  } catch {}
  return '';
}
const PROXY_WORKER_CODE_SIG = (() => {
  try {
    const raw = fs.readFileSync(__filename);
    return `${PROXY_WORKER_VERSION}:${crypto.createHash('md5').update(raw).digest('hex').slice(0, 12)}`;
  } catch {
    return `${PROXY_WORKER_VERSION}:0`;
  }
})();

const UPSTREAM_HTTP_AGENT = new http.Agent({
  keepAlive: true,
  maxSockets: 64,
  maxFreeSockets: 16,
  keepAliveMsecs: 30000
});
UPSTREAM_HTTP_AGENT.on('free', (sock) => {
  try {
    sock.unref?.();
  } catch {}
});

function shouldDisableProxyWorker() {
  return process.env.THEO_DISABLE_PROXY_WORKER === '1' || !isMainThread;
}

function scheduleWorkerConfigSync(st, clearMainJsCache = false) {
  if (!st || !isMainThread || st._suppressWorkerSync) {
    return;
  }
  if (clearMainJsCache) {
    st._pendingClearMainJs = true;
  }
  if (st._workerSyncScheduled) {
    return;
  }
  st._workerSyncScheduled = true;
  queueMicrotask(() => {
    st._workerSyncScheduled = false;
    const clearCache = Boolean(st._pendingClearMainJs);
    st._pendingClearMainJs = false;
    if (!st.worker) {
      return;
    }
    try {
      st.worker.postMessage({
        type: 'syncConfig',
        upstreamHost: st._upstreamHost || '127.0.0.1',
        upstreamPort: Number(st._upstreamPort || 0),
        upstreamOrigin: st._upstreamOrigin || '',
        csrfToken: st._csrfToken || '',
        retiringHubs: Array.isArray(st._retiringHubs) ? st._retiringHubs : [],
        clearMainJsCache: clearCache
      });
    } catch {}
  });
}

function ensureReactiveProxyState(st) {
  if (!st || st.__bhfReactiveInstalled) {
    return st;
  }
  const initHost = st.upstreamHost || '127.0.0.1';
  const initPort = Number(st.upstreamPort || 0);
  const initOrigin = st.upstreamOrigin || '';
  const initCsrf = st.csrfToken || '';
  const initRetiringHubs = Array.isArray(st.retiringHubs) ? st.retiringHubs : [];
  const initMainJsCache = st.mainJsCache || null;

  Object.defineProperties(st, {
    __bhfReactiveInstalled: { value: true, enumerable: false, configurable: true },
    _upstreamHost: { value: initHost, writable: true, enumerable: false, configurable: true },
    _upstreamPort: { value: initPort, writable: true, enumerable: false, configurable: true },
    _upstreamOrigin: { value: initOrigin, writable: true, enumerable: false, configurable: true },
    _csrfToken: { value: initCsrf, writable: true, enumerable: false, configurable: true },
    _retiringHubs: { value: initRetiringHubs, writable: true, enumerable: false, configurable: true },
    _mainJsCache: { value: initMainJsCache, writable: true, enumerable: false, configurable: true },
    _workerSyncScheduled: { value: false, writable: true, enumerable: false, configurable: true },
    _pendingClearMainJs: { value: false, writable: true, enumerable: false, configurable: true },
    _suppressWorkerSync: { value: false, writable: true, enumerable: false, configurable: true },
    upstreamHost: {
      enumerable: true,
      configurable: true,
      get() {
        return st._upstreamHost;
      },
      set(v) {
        const next = String(v || '127.0.0.1');
        if (st._upstreamHost !== next) {
          st._upstreamHost = next;
          scheduleWorkerConfigSync(st, false);
        }
      }
    },
    upstreamPort: {
      enumerable: true,
      configurable: true,
      get() {
        return st._upstreamPort;
      },
      set(v) {
        const next = Number(v || 0);
        if (st._upstreamPort !== next) {
          st._upstreamPort = next;
          scheduleWorkerConfigSync(st, false);
        }
      }
    },
    upstreamOrigin: {
      enumerable: true,
      configurable: true,
      get() {
        return st._upstreamOrigin;
      },
      set(v) {
        const next = String(v || '');
        if (st._upstreamOrigin !== next) {
          const hadPrev = Boolean(st._upstreamOrigin);
          st._upstreamOrigin = next;
          scheduleWorkerConfigSync(st, hadPrev);
        }
      }
    },
    csrfToken: {
      enumerable: true,
      configurable: true,
      get() {
        return st._csrfToken;
      },
      set(v) {
        const next = String(v || '');
        if (st._csrfToken !== next) {
          st._csrfToken = next;
          scheduleWorkerConfigSync(st, false);
        }
      }
    },
    retiringHubs: {
      enumerable: true,
      configurable: true,
      get() {
        return st._retiringHubs;
      },
      set(v) {
        const next = Array.isArray(v) ? v : [];
        st._retiringHubs = next;
        scheduleWorkerConfigSync(st, false);
      }
    },
    mainJsCache: {
      enumerable: true,
      configurable: true,
      get() {
        return st._mainJsCache;
      },
      set(v) {
        st._mainJsCache = v;
        if (v === null) {
          scheduleWorkerConfigSync(st, true);
        }
      }
    }
  });
  return st;
}

function getProxyState() {
  if (!globalThis[PROXY_STATE_SYMBOL]) {
    globalThis[PROXY_STATE_SYMBOL] = {
      server: null,
      worker: null,
      workerCodeSig: '',
      migrationPromise: null,
      listenPromise: null,
      proxyPort: 0,
      upstreamHost: '127.0.0.1',
      upstreamPort: 0,
      upstreamOrigin: '',
      csrfToken: '',
      retiringHubs: [],
      cacheById: new Map(),
      mainJsCache: null,
      mainJsInFlight: null,
      remoteActionQueue: [],
      broadcastDeliveredById: new Map(),
      lastValidAuthResultByPort: new Map(),
      pendingApprovalsById: new Map(),
      activeUpgradeSockets: new Set(),
      cascadeByTabId: new Map()
    };
  }
  const st = globalThis[PROXY_STATE_SYMBOL];
  if (!Array.isArray(st.retiringHubs)) {
    st.retiringHubs = [];
  }
  if (!Array.isArray(st.remoteActionQueue)) {
    st.remoteActionQueue = [];
  }
  if (!(st.broadcastDeliveredById instanceof Map)) {
    st.broadcastDeliveredById = new Map();
  }
  if (!(st.lastValidAuthResultByPort instanceof Map)) {
    st.lastValidAuthResultByPort = new Map();
  }
  if (!(st.pendingApprovalsById instanceof Map)) {
    st.pendingApprovalsById = new Map();
  }
  if (!(st.activeUpgradeSockets instanceof Set)) {
    st.activeUpgradeSockets = new Set();
  }
  if (!(st.cascadeByTabId instanceof Map)) {
    st.cascadeByTabId = new Map();
  }
  return isMainThread ? ensureReactiveProxyState(st) : st;
}

function isValidCascadeIdToken(val) {
  const s = String(val || '').trim();
  return Boolean(s && /^[A-Za-z0-9_-]{6,80}$/.test(s) && s !== 'undefined' && s !== 'null');
}

function extractCascadeIdFromPathOrReferer(rawPathOrUrl) {
  if (!rawPathOrUrl || typeof rawPathOrUrl !== 'string') {
    return '';
  }
  const m = rawPathOrUrl.match(/\/c\/([A-Za-z0-9_-]{6,80})(?:[/?#]|$)/i);
  return m && isValidCascadeIdToken(m[1]) ? m[1].trim() : '';
}

function bindTabCascade(proxyState, tabId, cascadeId) {
  if (!proxyState) return;
  const cleanTabId = String(tabId || '').trim();
  const cleanCid = isValidCascadeIdToken(cascadeId) ? String(cascadeId).trim() : '';
  if (!cleanTabId || !cleanCid) {
    return;
  }
  if (!(proxyState.cascadeByTabId instanceof Map)) {
    proxyState.cascadeByTabId = new Map();
  }
  proxyState.cascadeByTabId.set(cleanTabId, {
    cascadeId: cleanCid,
    updatedAt: Date.now()
  });
  if (proxyState.cascadeByTabId.size > 512) {
    const firstKey = proxyState.cascadeByTabId.keys().next().value;
    if (firstKey) proxyState.cascadeByTabId.delete(firstKey);
  }
  if (isMainThread && proxyState.worker) {
    try {
      proxyState.worker.postMessage({
        type: 'bindTabCascade',
        tabId: cleanTabId,
        cascadeId: cleanCid
      });
    } catch {}
  }
  if (proxyState.activeUpgradeSockets instanceof Set) {
    for (const entry of Array.from(proxyState.activeUpgradeSockets)) {
      if (!entry || entry.tabId !== cleanTabId) continue;
      entry.cascadeId = cleanCid;
      const desired = resolveUpstreamForCascade(proxyState, cleanCid);
      const desiredPort = Number(desired?.port || 0);
      const curPort = Number(entry.targetPort || 0);
      if (desiredPort > 0 && curPort > 0 && desiredPort !== curPort) {
        proxyState.activeUpgradeSockets.delete(entry);
        try {
          entry.upSocket?.destroy?.();
        } catch {}
        try {
          entry.clientSocket?.destroy?.();
        } catch {}
      }
    }
  }
}

function resolveUpstreamForCascade(proxyState, cascadeId = '') {
  const cleanCid = String(cascadeId || '').trim();
  if (cleanCid && Array.isArray(proxyState?.retiringHubs)) {
    for (const hub of proxyState.retiringHubs) {
      const port = Number(hub?.port || 0);
      if (
        port > 0 &&
        Array.isArray(hub.cascadeIds) &&
        hub.cascadeIds.includes(cleanCid)
      ) {
        return {
          host: proxyState.upstreamHost || '127.0.0.1',
          port,
          csrfToken: String(hub.csrfToken || proxyState.csrfToken || ''),
          isRetiring: true
        };
      }
    }
  }
  return {
    host: proxyState?.upstreamHost || '127.0.0.1',
    port: Number(proxyState?.upstreamPort || 0),
    csrfToken: String(proxyState?.csrfToken || ''),
    isRetiring: false
  };
}

function extractCascadeIdFromWsChunk(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 6) {
    return '';
  }
  try {
    const opcode = buf[0] & 0x0f;
    const isMasked = (buf[1] & 0x80) !== 0;
    let payloadLen = buf[1] & 0x7f;
    let offset = 2;
    if (payloadLen === 126) {
      if (buf.length < 8) return '';
      payloadLen = buf.readUInt16BE(2);
      offset = 4;
    } else if (payloadLen === 127) {
      if (buf.length < 14) return '';
      payloadLen = Number(buf.readBigUInt64BE(2));
      offset = 10;
    }
    if (opcode === 1 || opcode === 2 || opcode === 0) {
      let text = '';
      if (isMasked) {
        if (buf.length < offset + 4) return '';
        const mask = buf.subarray(offset, offset + 4);
        offset += 4;
        const avail = Math.min(payloadLen, buf.length - offset, 2048);
        if (avail <= 0) return '';
        const out = Buffer.allocUnsafe(avail);
        for (let i = 0; i < avail; i += 1) {
          out[i] = buf[offset + i] ^ mask[i & 3];
        }
        text = out.toString('utf8');
      } else {
        const avail = Math.min(payloadLen, buf.length - offset, 2048);
        if (avail > 0) {
          text = buf.toString('utf8', offset, offset + avail);
        }
      }
      if (text) {
        const m = text.match(/\\?"(?:cascadeId|conversationId|cascade_id)\\?"\s*:\s*\\?"([A-Za-z0-9_-]{6,80})\\?"/);
        if (m && isValidCascadeIdToken(m[1])) {
          return m[1].trim();
        }
        const protoLen36 = text.match(/(?:[\n\x12]\$)([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
        if (protoLen36 && protoLen36[1]) {
          return protoLen36[1].trim();
        }
        if (/Cascade|Trajectory|Conversation/i.test(text)) {
          const u = text.match(/\b([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\b/i);
          if (u && u[1]) {
            return u[1].trim();
          }
        }
      }
    }
  } catch {}
  return '';
}

function enqueueRemoteWebviewAction(actionObj = {}) {
  const st = getProxyState();
  const kind = String(actionObj.kind || 'approve').trim();
  const rawPayload =
    actionObj.payload && typeof actionObj.payload === 'object' ? actionObj.payload : undefined;
  const normalizedPayload =
    kind === 'refresh_auth' && rawPayload
      ? buildSignInPayloadFromAuthResult(rawPayload)
      : rawPayload;
  if (kind === 'refresh_auth') {
    st._localAuthProbeCache = null;
    st._localAuthProbeInFlight = null;
    st._authStatusRefreshThrottle?.clear?.();
  }
  const entry = {
    actionId: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    id: String(actionObj.id || actionObj.threadId || '').trim(),
    kind,
    text: String(actionObj.text || '').trim(),
    targetLabel: String(actionObj.targetLabel || '').trim(),
    selectedOptionIds: Array.isArray(actionObj.selectedOptionIds)
      ? actionObj.selectedOptionIds
      : undefined,
    selectedTexts: Array.isArray(actionObj.selectedTexts) ? actionObj.selectedTexts : undefined,
    writeInResponse:
      typeof actionObj.writeInResponse === 'string' ? actionObj.writeInResponse : undefined,
    skipped: actionObj.skipped !== undefined ? Boolean(actionObj.skipped) : undefined,
    payload: normalizedPayload,
    broadcastTtlMs:
      Number(actionObj.broadcastTtlMs || 0) > 0 ? Number(actionObj.broadcastTtlMs) : undefined,
    createdAt: Date.now()
  };
  st.remoteActionQueue.push(entry);
  if (st.remoteActionQueue.length > 50) {
    st.remoteActionQueue.splice(0, st.remoteActionQueue.length - 50);
  }
  if (isMainThread && st.worker) {
    try {
      st.worker.postMessage({ type: 'enqueueAction', entry });
    } catch {}
  }
  return entry;
}

function getPendingApprovals() {
  const st = getProxyState();
  const out = [];
  const now = Date.now();
  for (const [id, info] of st.pendingApprovalsById.entries()) {
    if (info && Array.isArray(info.buttons) && info.buttons.length > 0 && now - (info.updatedAt || 0) < 30000) {
      out.push({
        id,
        provider: 'antigravity',
        buttons: info.buttons,
        summary: info.summary || 'Awaiting confirmation in Antigravity',
        updatedAt: info.updatedAt
      });
    }
  }
  return out;
}

function updateUpstreamTarget(proxyState, serverUrl) {
  try {
    const parsed = new URL(serverUrl);
    const nextOrigin = parsed.origin;
    if (proxyState.upstreamOrigin && proxyState.upstreamOrigin !== nextOrigin) {
      proxyState.mainJsCache = null;
      proxyState.mainJsInFlight = null;
    }
    proxyState.upstreamHost = parsed.hostname || '127.0.0.1';
    proxyState.upstreamPort = Number(parsed.port || (parsed.protocol === 'https:' ? 443 : 80));
    proxyState.upstreamOrigin = nextOrigin;
  } catch {}
}

function closeUpstreamSocketsForPortLocal(proxyState, portToClose = 0, options = null) {
  if (!proxyState || !(proxyState.activeUpgradeSockets instanceof Set)) {
    return 0;
  }
  const cleanPort = Number(portToClose || 0);
  const excludeSet =
    options && Array.isArray(options.excludeCascadeIds) && options.excludeCascadeIds.length > 0
      ? new Set(options.excludeCascadeIds.map((id) => String(id || '').trim()).filter(Boolean))
      : null;
  const onlySet =
    options && Array.isArray(options.onlyCascadeIds) && options.onlyCascadeIds.length > 0
      ? new Set(options.onlyCascadeIds.map((id) => String(id || '').trim()).filter(Boolean))
      : null;
  const keepOnlySet =
    options && Array.isArray(options.keepOnlyCascadeIds)
      ? new Set(options.keepOnlyCascadeIds.map((id) => String(id || '').trim()).filter(Boolean))
      : null;
  const preserveUntagged = Boolean(options?.preserveUntagged);
  let closed = 0;
  for (const entry of Array.from(proxyState.activeUpgradeSockets)) {
    if (!entry) {
      proxyState.activeUpgradeSockets.delete(entry);
      continue;
    }
    if (cleanPort && Number(entry.targetPort || 0) !== cleanPort) {
      continue;
    }
    const mappedCid =
      entry.tabId && proxyState.cascadeByTabId instanceof Map
        ? proxyState.cascadeByTabId.get(entry.tabId)?.cascadeId || ''
        : '';
    const entryCid = String(entry.cascadeId || mappedCid || '').trim();
    if (keepOnlySet) {
      if (entryCid && keepOnlySet.has(entryCid)) {
        continue;
      }
    }
    if (onlySet) {
      if (!entryCid || !onlySet.has(entryCid)) {
        continue;
      }
    }
    if (excludeSet) {
      if (entryCid && excludeSet.has(entryCid)) {
        continue;
      }
      if (!entryCid && preserveUntagged) {
        continue;
      }
    }
    proxyState.activeUpgradeSockets.delete(entry);
    closed += 1;
    try {
      entry.upSocket?.destroy?.();
    } catch {}
    try {
      entry.clientSocket?.destroy?.();
    } catch {}
  }
  return closed;
}

function closeUpstreamSocketsForPort(proxyState = getProxyState(), portToClose = 0, options = null) {
  const closed = closeUpstreamSocketsForPortLocal(proxyState, portToClose, options);
  if (isMainThread && proxyState?.worker) {
    try {
      proxyState.worker.postMessage({
        type: 'closeSockets',
        portToClose: Number(portToClose || 0),
        options: options
          ? {
              excludeCascadeIds: Array.isArray(options.excludeCascadeIds)
                ? options.excludeCascadeIds.slice()
                : undefined,
              onlyCascadeIds: Array.isArray(options.onlyCascadeIds)
                ? options.onlyCascadeIds.slice()
                : undefined,
              keepOnlyCascadeIds: Array.isArray(options.keepOnlyCascadeIds)
                ? options.keepOnlyCascadeIds.slice()
                : undefined,
              preserveUntagged: Boolean(options.preserveUntagged)
            }
          : null
      });
    } catch {}
  }
  return closed;
}

function callUpstreamRpc(proxyState, method, bodyObj, timeoutMs = 4500) {
  return new Promise((resolve, reject) => {
    const target = resolveUpstreamForCascade(proxyState, bodyObj?.cascadeId);
    if (!target.port || !target.csrfToken) {
      reject(new Error('Upstream port or CSRF token not ready'));
      return;
    }
    const payload = JSON.stringify(bodyObj || {});
    const req = http.request(
      {
        agent: UPSTREAM_HTTP_AGENT,
        hostname: target.host,
        port: target.port,
        path: `/exa.language_server_pb.LanguageServerService/${method}`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': target.csrfToken,
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
            try {
              resolve(text ? JSON.parse(text) : {});
            } catch (err) {
              reject(err);
            }
          } else {
            reject(new Error(`RPC ${method} HTTP ${res.statusCode}`));
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error(`RPC ${method} timeout`)));
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

function callUpstreamTargetRpc(target, method, bodyObj = {}, timeoutMs = 1200) {
  return new Promise((resolve, reject) => {
    const cleanPort = Number(target?.port || 0);
    const cleanHost = String(target?.host || '127.0.0.1').trim() || '127.0.0.1';
    const cleanToken = String(target?.csrfToken || '').trim();
    if (!cleanPort || !cleanToken) {
      reject(new Error('Upstream port or CSRF token not ready'));
      return;
    }
    const payload = JSON.stringify(bodyObj || {});
    const req = http.request(
      {
        agent: UPSTREAM_HTTP_AGENT,
        hostname: cleanHost,
        port: cleanPort,
        path: `/exa.language_server_pb.LanguageServerService/${method}`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': cleanToken,
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
            try {
              resolve(text ? JSON.parse(text) : {});
            } catch (err) {
              reject(err);
            }
          } else {
            reject(new Error(`RPC ${method} HTTP ${res.statusCode}`));
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error(`RPC ${method} timeout`)));
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

function sanitizeAuthResultForClient(rawAuth = {}) {
  const out = {
    hasValidAuth: Boolean(rawAuth?.hasValidAuth),
    isGcpTos: Boolean(rawAuth?.isGcpTos),
    projectId: String(rawAuth?.projectId ?? rawAuth?.project ?? ''),
    location: String(rawAuth?.location ?? ''),
    grantedScopes: Array.isArray(rawAuth?.grantedScopes)
      ? rawAuth.grantedScopes.map(String)
      : ['email', 'profile', 'openid']
  };
  if (rawAuth?.wifProvider !== undefined) {
    out.wifProvider = String(rawAuth.wifProvider || '');
  }
  if (rawAuth?.authMode !== undefined) {
    out.authMode = rawAuth.authMode;
  }
  return out;
}

function buildSignInPayloadFromAuthResult(authResult = {}) {
  const payload = {
    isGcpTos: Boolean(authResult?.isGcpTos),
    project: String(authResult?.projectId ?? authResult?.project ?? ''),
    location: String(authResult?.location ?? ''),
    grantedScopes: Array.isArray(authResult?.grantedScopes)
      ? authResult.grantedScopes.map(String)
      : []
  };
  if (authResult?.wifProvider !== undefined) {
    payload.wifProvider = authResult.wifProvider;
  }
  if (authResult?.authMode !== undefined) {
    payload.authMode = authResult.authMode;
  }
  return payload;
}

function maybeRefreshCachedAuthResult(proxyState, target, liveEmail) {
  if (!proxyState || !target?.port || !target?.csrfToken || !liveEmail) {
    return;
  }
  if (!(proxyState.lastValidAuthResultByPort instanceof Map)) {
    proxyState.lastValidAuthResultByPort = new Map();
  }
  if (!(proxyState._authStatusRefreshThrottle instanceof Map)) {
    proxyState._authStatusRefreshThrottle = new Map();
  }
  const now = Date.now();
  const throttleKey = `${target.host || '127.0.0.1'}:${target.port}:${liveEmail}`;
  const lastAttempt = Number(proxyState._authStatusRefreshThrottle.get(throttleKey) || 0);
  if (now - lastAttempt < 30000) {
    return;
  }
  proxyState._authStatusRefreshThrottle.set(throttleKey, now);
  callUpstreamTargetRpc(target, 'GetAuthStatus', {}, 900)
    .then((resp) => {
      if (resp?.authResult?.hasValidAuth === true) {
        const cacheKey = `${target.port}:${liveEmail}`;
        proxyState.lastValidAuthResultByPort.set(cacheKey, {
          authResult: sanitizeAuthResultForClient(resp.authResult),
          updatedAt: Date.now()
        });
        if (proxyState.lastValidAuthResultByPort.size > 32) {
          const oldestKey = proxyState.lastValidAuthResultByPort.keys().next().value;
          if (oldestKey) proxyState.lastValidAuthResultByPort.delete(oldestKey);
        }
      }
    })
    .catch(() => {});
}

async function probeUpstreamLocalSignedIn(proxyState, targetOverride = null, timeoutMs = 1200) {
  const target = targetOverride || resolveUpstreamForCascade(proxyState, '');
  const cleanPort = Number(target?.port || 0);
  const cleanToken = String(target?.csrfToken || '').trim();
  const cleanHost = String(target?.host || '127.0.0.1').trim() || '127.0.0.1';
  if (!cleanPort || !cleanToken) {
    return { signedIn: false, reason: 'missing_upstream' };
  }

  const dedupKey = `${cleanHost}:${cleanPort}:${cleanToken}`;
  const now = Date.now();
  if (
    proxyState?._localAuthProbeCache &&
    proxyState._localAuthProbeCache.key === dedupKey &&
    now - proxyState._localAuthProbeCache.at < 1500
  ) {
    return proxyState._localAuthProbeCache.result;
  }
  if (proxyState?._localAuthProbeInFlight && proxyState._localAuthProbeInFlight.key === dedupKey) {
    return proxyState._localAuthProbeInFlight.promise;
  }

  const runProbe = (async () => {
    const [hasTokSettled, userStSettled] = await Promise.allSettled([
      callUpstreamTargetRpc(
        { host: cleanHost, port: cleanPort, csrfToken: cleanToken },
        'HasAuthToken',
        {},
        timeoutMs
      ),
      callUpstreamTargetRpc(
        { host: cleanHost, port: cleanPort, csrfToken: cleanToken },
        'GetUserStatus',
        {},
        timeoutMs
      )
    ]);

    const hasToken =
      hasTokSettled.status === 'fulfilled' && hasTokSettled.value?.hasToken === true;
    const userStatus =
      userStSettled.status === 'fulfilled' ? userStSettled.value?.userStatus : null;
    const liveEmail = String(userStatus?.email || '')
      .trim()
      .toLowerCase();
    const hasValidEmail = Boolean(liveEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(liveEmail));

    if (!hasToken || !hasValidEmail) {
      if (proxyState?.lastValidAuthResultByPort instanceof Map) {
        for (const k of Array.from(proxyState.lastValidAuthResultByPort.keys())) {
          if (k.startsWith(`${cleanPort}:`)) {
            proxyState.lastValidAuthResultByPort.delete(k);
          }
        }
      }
      const neg = { signedIn: false };
      if (proxyState) {
        proxyState._localAuthProbeCache = { key: dedupKey, at: Date.now(), result: neg };
      }
      return neg;
    }

    const cacheKey = `${cleanPort}:${liveEmail}`;
    const cached =
      proxyState?.lastValidAuthResultByPort instanceof Map
        ? proxyState.lastValidAuthResultByPort.get(cacheKey)
        : null;
    if (!cached || Date.now() - Number(cached.updatedAt || 0) > 300000) {
      maybeRefreshCachedAuthResult(
        proxyState,
        { host: cleanHost, port: cleanPort, csrfToken: cleanToken },
        liveEmail
      );
    }

    const authResult = cached?.authResult
      ? sanitizeAuthResultForClient({ ...cached.authResult, hasValidAuth: true })
      : sanitizeAuthResultForClient({
          hasValidAuth: true,
          isGcpTos: Boolean(userStatus?.isGcpTos),
          projectId: String(userStatus?.projectId || userStatus?.project || ''),
          location: String(userStatus?.location || ''),
          grantedScopes: Array.isArray(userStatus?.grantedScopes)
            ? userStatus.grantedScopes.map(String)
            : ['email', 'profile', 'openid']
        });
    const signInPayload = buildSignInPayloadFromAuthResult(authResult);
    const pos = { signedIn: true, authResult, signInPayload };
    if (proxyState) {
      proxyState._localAuthProbeCache = { key: dedupKey, at: Date.now(), result: pos };
    }
    return pos;
  })().finally(() => {
    if (proxyState?._localAuthProbeInFlight?.promise === runProbe) {
      proxyState._localAuthProbeInFlight = null;
    }
  });

  if (proxyState) {
    proxyState._localAuthProbeInFlight = { key: dedupKey, promise: runProbe };
  }
  return runProbe;
}

function isAllowedLoopbackOrigin(req, proxyPort = 0) {
  const secFetchSite = String(req?.headers?.['sec-fetch-site'] || '')
    .trim()
    .toLowerCase();
  if (secFetchSite === 'cross-site') {
    return false;
  }
  const cleanProxyPort = Number(proxyPort || 0);
  const rawHost = String(req?.headers?.host || '').trim();
  if (!rawHost) {
    return false;
  }
  try {
    const parsedHost = new URL(`http://${rawHost}`);
    if (parsedHost.hostname !== '127.0.0.1' && parsedHost.hostname !== 'localhost') {
      return false;
    }
    if (cleanProxyPort > 0 && Number(parsedHost.port || 80) !== cleanProxyPort) {
      return false;
    }
  } catch {
    return false;
  }
  const rawOrigin = String(req?.headers?.origin || '').trim();
  if (!rawOrigin) {
    return true;
  }
  if (/^vscode-webview:\/\//i.test(rawOrigin)) {
    return true;
  }
  try {
    const parsed = new URL(rawOrigin);
    if (parsed.protocol !== 'http:') {
      return false;
    }
    if (parsed.hostname !== '127.0.0.1' && parsed.hostname !== 'localhost') {
      return false;
    }
    if (cleanProxyPort > 0 && Number(parsed.port || 80) !== cleanProxyPort) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

function scheduleInitialProxyAuthBroadcast(proxyState) {
  const timer = setTimeout(async () => {
    try {
      if (!proxyState?.upstreamPort || proxyState.upstreamPort <= 0) {
        await recoverUpstreamIfDead(proxyState, 0);
      }
      const check = await probeUpstreamLocalSignedIn(proxyState, null, 1500);
      if (check?.signedIn && Array.isArray(proxyState?.remoteActionQueue)) {
        proxyState.remoteActionQueue.push({
          actionId: `bhf-boot-auth-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`,
          id: '*',
          kind: 'refresh_auth',
          payload: check.signInPayload,
          broadcastTtlMs: 15000,
          createdAt: Date.now()
        });
        if (proxyState.remoteActionQueue.length > 50) {
          proxyState.remoteActionQueue.splice(0, proxyState.remoteActionQueue.length - 50);
        }
      }
    } catch {}
  }, 250);
  timer.unref?.();
}

function extractLatestUsage(chatModel) {
  if (!chatModel || typeof chatModel !== 'object') {
    return null;
  }
  const retryInfos = Array.isArray(chatModel.retryInfos) ? chatModel.retryInfos : [];
  for (let i = retryInfos.length - 1; i >= 0; i -= 1) {
    if (retryInfos[i] && retryInfos[i].usage) {
      return retryInfos[i].usage;
    }
  }
  return chatModel.usage || null;
}

function extractBaseOverheadFromGm(gmEntry) {
  const groups = Array.isArray(gmEntry?.chatModel?.chatStartMetadata?.contextWindowMetadata?.tokenBreakdown?.groups)
    ? gmEntry.chatModel.chatStartMetadata.contextWindowMetadata.tokenBreakdown.groups
    : [];
  let systemPromptTokens = 0;
  let toolsTokens = 0;
  const topSystemSections = [];
  for (const grp of groups) {
    const gType = String(grp?.type || '');
    const gName = String(grp?.name || '');
    const gTokens = Number(grp?.numTokens || 0);
    const children = Array.isArray(grp?.children) ? grp.children : [];
    if (gType.includes('SYSTEM_PROMPT') || gName === 'System Prompt') {
      systemPromptTokens += gTokens;
      for (const ch of children) {
        const chTokens = Number(ch?.numTokens || 0);
        if (chTokens > 0) {
          topSystemSections.push({
            name: String(ch?.name || 'section'),
            tokens: chTokens
          });
        }
      }
    } else if (gType.includes('TOOLS') || gName === 'Tools' || gName === 'MCP Tools') {
      toolsTokens += gTokens;
    }
  }
  if (systemPromptTokens <= 0 && toolsTokens <= 0) {
    return null;
  }
  topSystemSections.sort((a, b) => b.tokens - a.tokens);
  return {
    systemPromptTokens,
    toolsTokens,
    topSystemSections: topSystemSections.slice(0, 5)
  };
}

function getLastStepIndexOfGm(gmEntry) {
  const indices = Array.isArray(gmEntry?.stepIndices) ? gmEntry.stepIndices : [];
  let maxIdx = -1;
  for (const idx of indices) {
    const n = Number(idx);
    if (Number.isFinite(n) && n > maxIdx) {
      maxIdx = n;
    }
  }
  if (maxIdx < 0) {
    const fallback = Number(gmEntry?.chatModel?.customMetadata?.last_step_index);
    if (Number.isFinite(fallback) && fallback >= 0) {
      maxIdx = fallback;
    }
  }
  return maxIdx;
}

function extractCheckpointSummaryTokens(cpStep) {
  const retryInfos = Array.isArray(cpStep?.metadata?.retryInfos) ? cpStep.metadata.retryInfos : [];
  for (let i = retryInfos.length - 1; i >= 0; i -= 1) {
    const u = retryInfos[i]?.usage;
    const respOut = Number(u?.responseOutputTokens || u?.outputTokens || 0);
    if (respOut > 0) {
      return respOut;
    }
  }
  const mu = cpStep?.metadata?.modelUsage;
  const muOut = Number(mu?.responseOutputTokens || mu?.outputTokens || 0);
  if (muOut > 0) {
    return muOut;
  }
  const summaryText = String(cpStep?.checkpoint?.sessionSummary || '');
  if (summaryText.length > 0) {
    return Math.ceil(summaryText.length / 3.5);
  }
  return 2500;
}

function summarizePostCheckpointContext(cascadeId, latestChatGm, cpStep, stepsAfterCp, baseOverhead, totalTurns) {
  const chatModel = latestChatGm?.chatModel || {};
  const plannerConfig = latestChatGm?.plannerConfig || {};
  const usage = extractLatestUsage(chatModel) || {};
  const cwm = chatModel?.chatStartMetadata?.contextWindowMetadata || {};
  const maxContextTokens = Number(cwm.maxContextTokens || 256000);

  const systemPromptTokens = Number(baseOverhead?.systemPromptTokens || 12200);
  const toolsTokens = Number(baseOverhead?.toolsTokens || 5400);
  const topSystemSections = Array.isArray(baseOverhead?.topSystemSections)
    ? baseOverhead.topSystemSections
    : [];

  const summaryOutTokens = extractCheckpointSummaryTokens(cpStep);
  const checkpointTokens = summaryOutTokens + 850;

  let userTokens = 0;
  let assistantTokens = 0;
  let toolResultsTokens = 0;
  const trailing = Array.isArray(stepsAfterCp) ? stepsAfterCp : [];
  for (const st of trailing) {
    const sType = String(st?.type || '');
    if (sType === 'CORTEX_STEP_TYPE_USER_INPUT') {
      const txt = String(st?.userInput?.userResponse || '');
      if (txt) {
        userTokens += Math.max(20, Math.ceil(txt.length / 3.8));
      }
      const items = Array.isArray(st?.userInput?.items) ? st.userInput.items : [];
      for (const it of items) {
        if (it?.media || it?.item?.media) {
          userTokens += 1100;
        }
      }
    } else if (sType === 'CORTEX_STEP_TYPE_PLANNER_RESPONSE') {
      const th =
        String(st?.plannerResponse?.thinking || '') +
        String(st?.plannerResponse?.response || '');
      if (th) {
        assistantTokens += Math.ceil(th.length / 3.8);
      }
    } else if (sType && sType !== 'CORTEX_STEP_TYPE_CHECKPOINT') {
      const raw = JSON.stringify(st?.viewFile || st?.runCommand || st?.grepSearch || '');
      if (raw && raw.length > 2) {
        toolResultsTokens += Math.min(12000, Math.ceil(raw.length / 4.2));
      }
    }
  }

  const usedTokens =
    systemPromptTokens +
    toolsTokens +
    checkpointTokens +
    userTokens +
    assistantTokens +
    toolResultsTokens;

  return {
    ok: true,
    empty: false,
    compacted: true,
    checkpointIndex: Number(cpStep?.checkpoint?.checkpointIndex || 1),
    cascadeId,
    turnCount: totalTurns,
    stepCount: 1 + trailing.length,
    usedTokens,
    estimatedTokensUsed: usedTokens,
    maxContextTokens,
    inputTokens: userTokens,
    cacheReadTokens: 0,
    outputTokens: summaryOutTokens,
    thinkingOutputTokens: 0,
    responseOutputTokens: summaryOutTokens,
    modelName: String(plannerConfig.modelName || chatModel.modelDisplayName || usage.model || ''),
    breakdown: {
      systemPromptTokens,
      toolsTokens,
      userTokens,
      assistantTokens,
      toolResultsTokens,
      checkpointTokens,
      topSystemSections
    },
    updatedAt: Date.now()
  };
}

function summarizeGeneratorMetadata(cascadeId, gmEntry, totalTurns, baseOverhead = null) {
  const chatModel = gmEntry?.chatModel || {};
  const plannerConfig = gmEntry?.plannerConfig || {};
  const usage = extractLatestUsage(chatModel) || {};

  const inputTokens = Number(usage.inputTokens || 0);
  const cacheReadTokens = Number(usage.cacheReadTokens || 0);
  const outputTokens = Number(usage.outputTokens || 0);
  const thinkingOutputTokens = Number(usage.thinkingOutputTokens || 0);
  const responseOutputTokens = Number(usage.responseOutputTokens || 0);

  const cwm = chatModel?.chatStartMetadata?.contextWindowMetadata || {};
  const estimatedTokensUsed = Number(cwm.estimatedTokensUsed || 0);
  const maxContextTokens = Number(cwm.maxContextTokens || 0);

  const promptPlusCache = inputTokens + cacheReadTokens;
  const usedTokens =
    estimatedTokensUsed > 0 ? estimatedTokensUsed : promptPlusCache + outputTokens;

  const groups = Array.isArray(cwm?.tokenBreakdown?.groups) ? cwm.tokenBreakdown.groups : [];
  let systemPromptTokens = 0;
  let toolsTokens = 0;
  let userTokens = 0;
  let assistantTokens = 0;
  let toolResultsTokens = 0;
  let checkpointTokens = 0;
  let stepCount = 0;
  let systemPromptSections = [];

  for (const grp of groups) {
    const gType = String(grp?.type || '');
    const gName = String(grp?.name || '');
    const gTokens = Number(grp?.numTokens || 0);
    const children = Array.isArray(grp?.children) ? grp.children : [];

    if (gType.includes('SYSTEM_PROMPT') || gName === 'System Prompt') {
      systemPromptTokens += gTokens;
      for (const ch of children) {
        const chTokens = Number(ch?.numTokens || 0);
        if (chTokens > 0) {
          systemPromptSections.push({
            name: String(ch?.name || 'section'),
            tokens: chTokens
          });
        }
      }
    } else if (gType.includes('TOOLS') || gName === 'Tools' || gName === 'MCP Tools') {
      toolsTokens += gTokens;
    } else if (gType.includes('CHAT_MESSAGES') || gName === 'Chat Messages') {
      stepCount = children.length;
      for (const ch of children) {
        const chTokens = Number(ch?.numTokens || 0);
        const rawName = String(ch?.name || '');
        const kind = rawName.includes(': ') ? rawName.split(': ').slice(1).join(': ') : rawName;
        if (kind === 'USER_INPUT') {
          userTokens += chTokens;
        } else if (kind === 'PLANNER_RESPONSE') {
          assistantTokens += chTokens;
        } else if (kind === 'CHECKPOINT') {
          checkpointTokens += chTokens;
        } else {
          toolResultsTokens += chTokens;
        }
      }
    }
  }

  systemPromptSections.sort((a, b) => b.tokens - a.tokens);

  if (groups.length === 0 && baseOverhead && usedTokens > 0) {
    const baseSys = Number(baseOverhead.systemPromptTokens || 0);
    const baseTools = Number(baseOverhead.toolsTokens || 0);
    if (baseSys + baseTools > 0 && baseSys + baseTools < usedTokens) {
      systemPromptTokens = baseSys;
      toolsTokens = baseTools;
      toolResultsTokens = Math.max(0, usedTokens - baseSys - baseTools);
      if (Array.isArray(baseOverhead.topSystemSections)) {
        systemPromptSections = baseOverhead.topSystemSections.slice(0, 5);
      }
    }
  }

  return {
    ok: true,
    empty: false,
    cascadeId,
    turnCount: totalTurns,
    stepCount,
    usedTokens,
    estimatedTokensUsed,
    maxContextTokens,
    inputTokens,
    cacheReadTokens,
    outputTokens,
    thinkingOutputTokens,
    responseOutputTokens,
    modelName: String(plannerConfig.modelName || chatModel.modelDisplayName || usage.model || ''),
    breakdown: {
      systemPromptTokens,
      toolsTokens,
      userTokens,
      assistantTokens,
      toolResultsTokens,
      checkpointTokens,
      topSystemSections: systemPromptSections.slice(0, 5)
    },
    updatedAt: Date.now()
  };
}

async function fetchContextWindowStatus(proxyState, cascadeId, force = false) {
  const cleanId = String(cascadeId || '').trim();
  if (!cleanId || !/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(cleanId)) {
    return {
      ok: true,
      empty: true,
      cascadeId: '',
      usedTokens: 0,
      maxContextTokens: 0
    };
  }

  let cacheEntry = proxyState.cacheById.get(cleanId);
  const now = Date.now();
  if (!force && cacheEntry?.lastSummary && now - cacheEntry.fetchedAt < 1200) {
    return cacheEntry.lastSummary;
  }

  if (!cacheEntry) {
    cacheEntry = {
      offset: 0,
      lastGm: null,
      lastBaseOverhead: null,
      lastSummary: null,
      fetchedAt: 0
    };
    proxyState.cacheById.set(cleanId, cacheEntry);
  }

  try {
    let offset = Math.max(0, cacheEntry.offset > 0 ? cacheEntry.offset - 1 : 0);
    let latestChatGm = cacheEntry.lastGm;
    let latestBaseOverhead = cacheEntry.lastBaseOverhead || null;
    let totalCount = offset;

    for (let pageIdx = 0; pageIdx < 20; pageIdx += 1) {
      const resp = await callUpstreamRpc(
        proxyState,
        'GetCascadeTrajectoryGeneratorMetadata',
        {
          cascadeId: cleanId,
          generatorMetadataOffset: offset
        },
        4000
      );
      const list = Array.isArray(resp?.generatorMetadata) ? resp.generatorMetadata : [];
      if (list.length === 0) {
        if (offset > 0 && pageIdx === 0) {
          // Conversation may have been reverted to an earlier step; retry from 0
          offset = 0;
          latestChatGm = null;
          totalCount = 0;
          continue;
        }
        break;
      }
      for (let i = 0; i < list.length; i += 1) {
        const overhead = extractBaseOverheadFromGm(list[i]);
        if (overhead) {
          latestBaseOverhead = overhead;
        }
      }
      for (let i = list.length - 1; i >= 0; i -= 1) {
        if (list[i]?.chatModel) {
          latestChatGm = list[i];
          break;
        }
      }
      offset += list.length;
      totalCount = offset;
      if (list.length < 100) {
        break;
      }
    }

    cacheEntry.offset = totalCount;
    cacheEntry.lastGm = latestChatGm;
    cacheEntry.lastBaseOverhead = latestBaseOverhead;
    cacheEntry.fetchedAt = Date.now();

    if (!latestChatGm) {
      const emptySummary = {
        ok: true,
        empty: true,
        cascadeId: cleanId,
        turnCount: 0,
        usedTokens: 0,
        maxContextTokens: 0,
        updatedAt: Date.now()
      };
      cacheEntry.lastSummary = emptySummary;
      return emptySummary;
    }

    // Check if a /compact (or auto-compaction) CHECKPOINT step completed AFTER latestChatGm.
    // Antigravity only appends a new chatModel entry to generatorMetadata after the *next*
    // user message's model call finishes, so without checking trailing steps the badge would
    // appear stuck at the pre-compaction token count right after /compact completes.
    const lastGmStepIdx = getLastStepIndexOfGm(latestChatGm);
    if (lastGmStepIdx >= 0) {
      try {
        const stepsResp = await callUpstreamRpc(
          proxyState,
          'GetCascadeTrajectorySteps',
          {
            cascadeId: cleanId,
            stepOffset: lastGmStepIdx + 1
          },
          1800
        );
        const trailingSteps = Array.isArray(stepsResp?.steps) ? stepsResp.steps : [];
        let lastCpPos = -1;
        for (let i = trailingSteps.length - 1; i >= 0; i -= 1) {
          const st = trailingSteps[i];
          if (
            st?.type === 'CORTEX_STEP_TYPE_CHECKPOINT' &&
            (!st?.status || st.status === 'CORTEX_STEP_STATUS_DONE')
          ) {
            lastCpPos = i;
            break;
          }
        }
        if (lastCpPos >= 0) {
          const cpSummary = summarizePostCheckpointContext(
            cleanId,
            latestChatGm,
            trailingSteps[lastCpPos],
            trailingSteps.slice(lastCpPos + 1),
            latestBaseOverhead,
            totalCount
          );
          cacheEntry.lastSummary = cpSummary;
          return cpSummary;
        }
      } catch {}
    }

    const summary = summarizeGeneratorMetadata(
      cleanId,
      latestChatGm,
      totalCount,
      latestBaseOverhead
    );
    cacheEntry.lastSummary = summary;
    return summary;
  } catch (err) {
    if (cacheEntry?.lastSummary) {
      return cacheEntry.lastSummary;
    }
    return {
      ok: false,
      empty: true,
      cascadeId: cleanId,
      error: err?.message || String(err),
      usedTokens: 0,
      maxContextTokens: 0
    };
  }
}

function buildClientWsBootScript() {
  const defaultWsUri = getDefaultTheoWorkspaceUri();
  return `(function() {
  if (typeof window === 'undefined' || window.__bhfWsBootInstalled) return;
  window.__bhfWsBootInstalled = true;
  if (!window.__bhfDefaultWorkspaceUri) {
    window.__bhfDefaultWorkspaceUri = ${JSON.stringify(defaultWsUri)};
  }

  function makeTabId() {
    try {
      if (window.crypto && typeof window.crypto.randomUUID === 'function') {
        return window.crypto.randomUUID();
      }
    } catch {}
    return 'tab-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  if (!window.__bhfTabId) {
    window.__bhfTabId = makeTabId();
  }
  if (!(window.__bhfActiveWsSet instanceof Set)) {
    window.__bhfActiveWsSet = new Set();
  }

  const CID_PATH_RE = /\\/c\\/([A-Za-z0-9_-]{6,80})(?:[/?#]|$)/;

  function detectCascadeId() {
    try {
      const loc = window.__bhfRouter?.state?.location;
      const search = loc?.search;
      if (search && typeof search === 'object') {
        if (typeof search.focused === 'string' && search.focused) return search.focused;
        if (typeof search.cascadeId === 'string' && search.cascadeId) return search.cascadeId;
      }
      const rPath = String(loc?.pathname || '');
      const rm = rPath.match(CID_PATH_RE);
      if (rm && rm[1] && rm[1].toLowerCase() !== 'new') return rm[1];
      const wPath = String(window.location?.pathname || '');
      const wm = wPath.match(CID_PATH_RE);
      if (wm && wm[1] && wm[1].toLowerCase() !== 'new') return wm[1];
      if (typeof window.__bhfLastCascadeId === 'string' && window.__bhfLastCascadeId) {
        return window.__bhfLastCascadeId;
      }
    } catch {}
    return '';
  }

  window.__bhfGetCascadeId = detectCascadeId;

  window.__bhfCloseAllActiveWs = function(reason) {
    const closeReason = String(reason || 'bhf_hub_switch').slice(0, 120);
    let closedCount = 0;
    try {
      const list = window.__bhfActiveWsSet instanceof Set ? Array.from(window.__bhfActiveWsSet) : [];
      if (window.__bhfActiveWs && !list.includes(window.__bhfActiveWs)) {
        list.push(window.__bhfActiveWs);
      }
      for (const ws of list) {
        try {
          if (ws && (ws.readyState === 0 || ws.readyState === 1)) {
            ws.close(1001, closeReason);
            closedCount += 1;
          }
        } catch {}
      }
    } catch {}
    return closedCount;
  };

  let lastBoundCid = '';
  const NativeFetch = typeof window.fetch === 'function' ? window.fetch.bind(window) : null;

  function notifyTabBind(cid) {
    const clean = String(cid || '').trim();
    if (!clean || clean === lastBoundCid || clean.toLowerCase() === 'new') return;
    lastBoundCid = clean;
    window.__bhfLastCascadeId = clean;
    if (!NativeFetch) return;
    try {
      const q =
        '/__bhf_tab_bind?tabId=' +
        encodeURIComponent(window.__bhfTabId) +
        '&id=' +
        encodeURIComponent(clean);
      NativeFetch(q, { cache: 'no-store' }).catch(function() {});
    } catch {}
  }

  window.__bhfNotifyTabBind = notifyTabBind;

  window.__bhfFastGetAuthStatus = function(_clientOwner, invokeOrig) {
    let origPromise;
    try {
      origPromise = Promise.resolve().then(invokeOrig);
    } catch (err) {
      return Promise.reject(err);
    }
    origPromise.catch(function() {});
    if (!NativeFetch) return origPromise;
    return new Promise(function(resolve, reject) {
      let settled = false;
      let timer = null;
      const finishResolve = function(val) {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        resolve(val);
      };
      const finishReject = function(err) {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        reject(err);
      };
      const tryFastCheck = function() {
        const cid = detectCascadeId();
        const url = '/__bhf_auth_fastcheck' + (cid ? '?id=' + encodeURIComponent(cid) : '');
        return NativeFetch(url, { cache: 'no-store' })
          .then(function(r) {
            return r && r.ok ? r.json() : null;
          })
          .then(function(data) {
            if (
              data &&
              data.signedIn === true &&
              data.authResult &&
              data.authResult.hasValidAuth === true
            ) {
              return { authResult: data.authResult };
            }
            return null;
          })
          .catch(function() {
            return null;
          });
      };
      origPromise.then(finishResolve, function(err) {
        const msg = String((err && err.message) || err || '');
        if (/deadline|timed?\s*out|aborted|canceled|network/i.test(msg)) {
          tryFastCheck().then(function(fb) {
            if (fb) finishResolve(fb);
            else finishReject(err);
          });
          return;
        }
        finishReject(err);
      });
      timer = setTimeout(function() {
        if (settled) return;
        tryFastCheck().then(function(fb) {
          if (fb) finishResolve(fb);
        });
      }, 1800);
    });
  };

  try {
    const NativeWS = window.WebSocket;
    if (typeof NativeWS === 'function' && !NativeWS.__bhfPatched) {
      const PatchedWS = function(url, protocols) {
        let finalUrl = url;
        let isConnectWs = false;
        try {
          const u = new URL(String(url), window.location.origin);
          if (u.pathname === '/connect-websocket') {
            isConnectWs = true;
            if (window.__bhfTabId && !u.searchParams.has('bhfTabId')) {
              u.searchParams.set('bhfTabId', window.__bhfTabId);
            }
            const cid = detectCascadeId();
            if (cid && !u.searchParams.has('bhfCid')) {
              u.searchParams.set('bhfCid', cid);
            }
            finalUrl = u.toString();
          }
        } catch {}
        const ws = protocols !== undefined ? new NativeWS(finalUrl, protocols) : new NativeWS(finalUrl);
        if (isConnectWs || String(finalUrl).includes('/connect-websocket')) {
          try {
            window.__bhfActiveWs = ws;
            window.__bhfActiveWsSet.add(ws);
            const drop = function() {
              try {
                window.__bhfActiveWsSet.delete(ws);
              } catch {}
            };
            ws.addEventListener('close', drop);
            ws.addEventListener('error', drop);
          } catch {}
        }
        return ws;
      };
      PatchedWS.prototype = NativeWS.prototype;
      Object.setPrototypeOf(PatchedWS, NativeWS);
      PatchedWS.CONNECTING = NativeWS.CONNECTING;
      PatchedWS.OPEN = NativeWS.OPEN;
      PatchedWS.CLOSING = NativeWS.CLOSING;
      PatchedWS.CLOSED = NativeWS.CLOSED;
      PatchedWS.__bhfPatched = true;
      window.WebSocket = PatchedWS;
    }
  } catch {}

  try {
    if (NativeFetch && !window.fetch.__bhfFetchPatched) {
      const patchedFetch = function(input, init) {
        try {
          const rawUrl =
            typeof input === 'string'
              ? input
              : input && typeof input.url === 'string'
                ? input.url
                : String(input || '');
          const u = new URL(rawUrl, window.location.origin);
          if (
            u.origin === window.location.origin &&
            (u.pathname.includes('/exa.language_server_pb.') || u.pathname.startsWith('/__bhf_'))
          ) {
            const cid = detectCascadeId();
            if (cid) {
              window.__bhfLastCascadeId = cid;
            }
            const baseHeaders =
              (init && init.headers) ||
              (input && typeof input === 'object' && input.headers ? input.headers : undefined);
            const nextHeaders = new Headers(baseHeaders || undefined);
            if (window.__bhfTabId && !nextHeaders.has('x-bhf-tab-id')) {
              nextHeaders.set('x-bhf-tab-id', window.__bhfTabId);
            }
            if (cid && !nextHeaders.has('x-bhf-cascade-id')) {
              nextHeaders.set('x-bhf-cascade-id', cid);
            }
            const nextInit = Object.assign({}, init || {}, { headers: nextHeaders });
            return NativeFetch(input, nextInit);
          }
        } catch {}
        return NativeFetch(input, init);
      };
      patchedFetch.__bhfFetchPatched = true;
      window.fetch = patchedFetch;
    }
  } catch {}

  try {
    const ensureUrlWorkspaceParam = function(rawUrl) {
      try {
        const wsUri = (function() {
          try {
            const cur = new URLSearchParams(window.location.search);
            return cur.get('workspaceUri') || cur.get('ws') || window.__bhfDefaultWorkspaceUri || '';
          } catch {
            return window.__bhfDefaultWorkspaceUri || '';
          }
        })();
        if (!wsUri) return rawUrl;
        const u = new URL(String(rawUrl || window.location.href), window.location.origin);
        if (u.origin !== window.location.origin) return rawUrl;
        if (!u.searchParams.has('workspaceUri') && !u.searchParams.has('ws')) {
          u.searchParams.set('workspaceUri', wsUri);
          return u.pathname + u.search + u.hash;
        }
      } catch {}
      return rawUrl;
    };
    const syncRouteCid = function() {
      const cid = detectCascadeId();
      if (cid) notifyTabBind(cid);
    };
    const origPush = window.history && window.history.pushState;
    const origReplace = window.history && window.history.replaceState;
    if (typeof origReplace === 'function' && window.__bhfDefaultWorkspaceUri) {
      try {
        const curSearch = new URLSearchParams(window.location.search);
        if (!curSearch.get('workspaceUri') && !curSearch.get('ws')) {
          origReplace.call(
            window.history,
            window.history.state,
            '',
            ensureUrlWorkspaceParam(window.location.href)
          );
        }
      } catch {}
    }
    if (typeof origPush === 'function' && !origPush.__bhfPatched) {
      const wrappedPush = function() {
        const args = Array.prototype.slice.call(arguments);
        if (args.length >= 3 && args[2] != null) {
          args[2] = ensureUrlWorkspaceParam(args[2]);
        }
        const res = origPush.apply(this, args);
        syncRouteCid();
        return res;
      };
      wrappedPush.__bhfPatched = true;
      window.history.pushState = wrappedPush;
    }
    if (typeof origReplace === 'function' && !origReplace.__bhfPatched) {
      const wrappedReplace = function() {
        const args = Array.prototype.slice.call(arguments);
        if (args.length >= 3 && args[2] != null) {
          args[2] = ensureUrlWorkspaceParam(args[2]);
        }
        const res = origReplace.apply(this, args);
        syncRouteCid();
        return res;
      };
      wrappedReplace.__bhfPatched = true;
      window.history.replaceState = wrappedReplace;
    }
    window.addEventListener('popstate', syncRouteCid);
    setTimeout(syncRouteCid, 0);
  } catch {}
})();`;
}

function buildClientContextUiScript() {
  return `${buildClientWsBootScript()}
(function() {
  if (window.__bhfContextUiInstalled) return;
  window.__bhfContextUiInstalled = true;

  const STYLE_ID = 'bhf-context-window-styles';
  const POPOVER_ID = 'bhf-context-window-popover';
  const WRAPPER_ATTR = 'data-bhf-context-wrapper';
  const BTN_TESTID = 'bhf-context-window-trigger';

  let activeCascadeId = '';
  let latestStatus = null;
  let isFetching = false;
  let lastFetchAt = 0;
  let popoverOpen = false;
  let activeTriggerEl = null;
  let lastKnownHubPort = 0;

  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = \`
      .bhf-ctx-btn {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        height: 28px;
        padding: 0 8px;
        border-radius: 9999px;
        font-size: 11.5px;
        line-height: 1;
        font-weight: 500;
        color: var(--secondary-foreground, rgba(220, 220, 225, 0.85));
        background: transparent;
        border: 1px solid rgba(128, 128, 135, 0.22);
        cursor: pointer;
        user-select: none;
        outline: none;
        white-space: nowrap;
        transition: background-color 0.15s ease, border-color 0.15s ease, color 0.15s ease;
      }
      .bhf-ctx-btn:hover, .bhf-ctx-btn[data-open="true"] {
        background-color: var(--secondary, rgba(128, 128, 135, 0.16));
        border-color: rgba(128, 128, 135, 0.38);
      }
      .bhf-ctx-pct {
        opacity: 0.72;
        font-variant-numeric: tabular-nums;
      }
      .bhf-ctx-popover {
        position: fixed;
        z-index: 99999;
        width: 348px;
        max-width: calc(100vw - 24px);
        border-radius: 12px;
        background: var(--card, #1e1f22);
        color: var(--foreground, #e5e7eb);
        border: 1px solid var(--border, rgba(128, 128, 135, 0.28));
        box-shadow: 0 14px 36px rgba(0, 0, 0, 0.45), 0 2px 8px rgba(0, 0, 0, 0.25);
        padding: 12px 14px;
        font-family: inherit;
        font-size: 12px;
        line-height: 1.4;
        user-select: none;
      }
      .bhf-ctx-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 8px;
      }
      .bhf-ctx-title {
        font-weight: 600;
        font-size: 12.5px;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .bhf-ctx-sub {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        margin-bottom: 6px;
        font-variant-numeric: tabular-nums;
      }
      .bhf-ctx-bar-track {
        display: flex;
        width: 100%;
        height: 8px;
        border-radius: 9999px;
        overflow: hidden;
        background: rgba(128, 128, 135, 0.2);
        margin-bottom: 10px;
      }
      .bhf-ctx-bar-seg {
        height: 100%;
        transition: width 0.25s ease;
      }
      .bhf-ctx-rows {
        display: flex;
        flex-direction: column;
        gap: 5px;
        padding: 8px 0;
        border-top: 1px solid var(--border, rgba(128, 128, 135, 0.18));
        border-bottom: 1px solid var(--border, rgba(128, 128, 135, 0.18));
      }
      .bhf-ctx-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        font-size: 11.5px;
        font-variant-numeric: tabular-nums;
      }
      .bhf-ctx-row-left {
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
      }
      .bhf-ctx-dot {
        width: 8px;
        height: 8px;
        border-radius: 2px;
        flex-shrink: 0;
      }
      .bhf-ctx-meta-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 6px;
        margin-top: 8px;
      }
      .bhf-ctx-meta-box {
        padding: 5px 7px;
        border-radius: 6px;
        background: rgba(128, 128, 135, 0.1);
        display: flex;
        flex-direction: column;
        gap: 1px;
      }
      .bhf-ctx-meta-label {
        font-size: 10px;
        opacity: 0.65;
      }
      .bhf-ctx-meta-val {
        font-size: 11.5px;
        font-weight: 600;
        font-variant-numeric: tabular-nums;
      }
      .bhf-ctx-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-top: 10px;
      }
      .bhf-ctx-action-btn {
        flex: 1;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        height: 27px;
        padding: 0 10px;
        border-radius: 6px;
        font-size: 11.5px;
        font-weight: 500;
        background: rgba(99, 102, 241, 0.16);
        color: #818cf8;
        border: 1px solid rgba(99, 102, 241, 0.3);
        cursor: pointer;
        transition: background 0.15s ease;
      }
      .bhf-ctx-action-btn:hover {
        background: rgba(99, 102, 241, 0.26);
      }
      .bhf-ctx-icon-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 22px;
        height: 22px;
        border-radius: 5px;
        background: transparent;
        color: inherit;
        opacity: 0.65;
        border: none;
        cursor: pointer;
      }
      .bhf-ctx-icon-btn:hover {
        opacity: 1;
        background: rgba(128, 128, 135, 0.18);
      }
    \`;
    document.head.appendChild(style);
  }

  function getActiveCascadeId() {
    let found = '';
    try {
      const loc = window.__bhfRouter?.state?.location || window.location;
      const search = loc?.search;
      if (search && typeof search === 'object') {
        if (typeof search.focused === 'string' && search.focused) found = search.focused;
        else if (typeof search.cascadeId === 'string' && search.cascadeId) found = search.cascadeId;
      }
      if (!found) {
        const pathname = String(loc?.pathname || window.location.pathname || '');
        const m = pathname.match(/^\\/c\\/([^/?#]+)/);
        if (m && m[1] && m[1].toLowerCase() !== 'new') found = m[1];
      }
      if (found) {
        if (typeof window.__bhfNotifyTabBind === 'function') {
          window.__bhfNotifyTabBind(found);
        } else {
          window.__bhfLastCascadeId = found;
        }
      }
    } catch {}
    return found;
  }

  function parseWindowString(raw) {
    const clean = String(raw || '').trim().toUpperCase();
    if (!clean) return 0;
    const m = clean.match(/^(\\d+(?:\\.\\d+)?)\\s*([KM])$/);
    if (!m) return 0;
    const val = parseFloat(m[1]);
    return m[2] === 'M' ? Math.round(val * 1000000) : Math.round(val * 1000);
  }

  function inferFallbackMaxTokens() {
    const modelBtn = document.querySelector('[data-testid="model-selector-trigger"]');
    if (modelBtn) {
      const cwAttr = modelBtn.getAttribute('data-context-window');
      const parsedAttr = parseWindowString(cwAttr);
      if (parsedAttr > 0) return parsedAttr;
      const text = (modelBtn.textContent || '') + ' ' + (modelBtn.getAttribute('aria-label') || '');
      const m = text.match(/\\b(256K|512K|900K|1M|2M|200K)\\b/i);
      if (m) {
        const p = parseWindowString(m[1]);
        if (p > 0) return p;
      }
    }
    return 256000;
  }

  function getSelectedModelLabel() {
    const modelBtn = document.querySelector('[data-testid="model-selector-trigger"]');
    if (!modelBtn) return '';
    return (modelBtn.textContent || '').trim();
  }

  function formatCompactTokens(num) {
    const n = Number(num || 0);
    if (!Number.isFinite(n) || n <= 0) return '0';
    if (n >= 1000000) {
      const m = n / 1000000;
      return (m >= 10 ? Math.round(m) : Number(m.toFixed(1))) + 'M';
    }
    if (n >= 1000) {
      const k = n / 1000;
      return (k >= 100 ? Math.round(k) : Number(k.toFixed(1))) + 'k';
    }
    return String(Math.round(n));
  }

  function formatExactTokens(num) {
    return Number(num || 0).toLocaleString('en-US');
  }

  function getStatusColor(pct) {
    if (pct >= 85) return '#f43f5e';
    if (pct >= 65) return '#f59e0b';
    return '#10b981';
  }

  function buildRingSvg(pct, color) {
    const r = 5.2;
    const c = 2 * Math.PI * r;
    const clamped = Math.max(0, Math.min(100, pct));
    const offset = c - (clamped / 100) * c;
    return \`<svg width="14" height="14" viewBox="0 0 14 14" style="flex-shrink:0;transform:rotate(-90deg)">
      <circle cx="7" cy="7" r="\${r}" fill="none" stroke="currentColor" stroke-opacity="0.22" stroke-width="2"></circle>
      <circle cx="7" cy="7" r="\${r}" fill="none" stroke="\${color}" stroke-width="2" stroke-dasharray="\${c.toFixed(2)}" stroke-dashoffset="\${offset.toFixed(2)}" stroke-linecap="round"></circle>
    </svg>\`;
  }

  function getEffectiveMetrics() {
    const maxTokens = (latestStatus && latestStatus.maxContextTokens > 0)
      ? latestStatus.maxContextTokens
      : inferFallbackMaxTokens();
    const usedTokens = (latestStatus && latestStatus.usedTokens > 0)
      ? latestStatus.usedTokens
      : 0;
    const pct = maxTokens > 0 ? Math.min(100, (usedTokens / maxTokens) * 100) : 0;
    return { usedTokens, maxTokens, pct };
  }

  function updateAllButtons() {
    const { usedTokens, maxTokens, pct } = getEffectiveMetrics();
    const color = getStatusColor(pct);
    const usedText = formatCompactTokens(usedTokens);
    const maxText = formatCompactTokens(maxTokens);
    const pctRound = Math.round(pct);
    const tooltip = \`Context Window: \${formatExactTokens(usedTokens)} / \${formatExactTokens(maxTokens)} tokens (\${pct.toFixed(1)}%) — Click for breakdown\`;

    const buttons = document.querySelectorAll(\`[data-testid="\${BTN_TESTID}"]\`);
    buttons.forEach((btn) => {
      btn.title = tooltip;
      btn.setAttribute('aria-label', tooltip);
      btn.setAttribute('data-open', popoverOpen ? 'true' : 'false');
      const html = \`\${buildRingSvg(pct, color)}<span>\${usedText} / \${maxText}</span><span class="bhf-ctx-pct">\${pctRound}%</span>\`;
      if (btn.__lastHtml !== html) {
        btn.innerHTML = html;
        btn.__lastHtml = html;
      }
    });

    if (popoverOpen) {
      renderPopoverContent();
    }
  }

  async function refreshContextStatus(force = false) {
    const cid = getActiveCascadeId();
    if (cid !== activeCascadeId) {
      activeCascadeId = cid;
      latestStatus = null;
      updateAllButtons();
    }
    if (!cid) {
      latestStatus = { ok: true, empty: true, cascadeId: '', usedTokens: 0, maxContextTokens: 0 };
      updateAllButtons();
      return;
    }
    const now = Date.now();
    if (isFetching || (!force && now - lastFetchAt < 900)) {
      return;
    }
    isFetching = true;
    lastFetchAt = now;
    try {
      const resp = await fetch(\`/__bhf_context_status?id=\${encodeURIComponent(cid)}\${force ? '&force=1' : ''}\`, {
        cache: 'no-store'
      });
      if (resp.ok) {
        const data = await resp.json();
        if (cid === getActiveCascadeId()) {
          latestStatus = data;
          updateAllButtons();
        }
      }
    } catch {} finally {
      isFetching = false;
    }
  }

  function openNativeTrajectoryModal() {
    closePopover();
    try {
      if (window.__bhfRouter && typeof window.__bhfRouter.navigate === 'function') {
        window.__bhfRouter.navigate({
          search: (prev) => ({ ...(prev || {}), trajectoryDebugOpen: true }),
          replace: true,
          unsafeRelative: 'path'
        });
      }
    } catch (err) {
      console.error('[bhf-context-window] Failed to open native inspector:', err);
    }
  }

  function closePopover() {
    popoverOpen = false;
    const existing = document.getElementById(POPOVER_ID);
    if (existing) existing.remove();
    updateAllButtons();
  }

  function positionPopover(popoverEl, anchorEl) {
    if (!popoverEl || !anchorEl) return;
    const rect = anchorEl.getBoundingClientRect();
    const popRect = popoverEl.getBoundingClientRect();
    const margin = 8;

    let left = rect.left;
    if (left + popRect.width > window.innerWidth - 12) {
      left = Math.max(12, window.innerWidth - popRect.width - 12);
    }
    if (left < 12) left = 12;

    let top = rect.top - popRect.height - margin;
    if (top < 12) {
      top = Math.min(window.innerHeight - popRect.height - 12, rect.bottom + margin);
    }

    popoverEl.style.left = \`\${Math.round(left)}px\`;
    popoverEl.style.top = \`\${Math.round(top)}px\`;
  }

  function renderPopoverContent() {
    let pop = document.getElementById(POPOVER_ID);
    if (!pop) {
      pop = document.createElement('div');
      pop.id = POPOVER_ID;
      pop.className = 'bhf-ctx-popover no-focus-agent-input';
      document.body.appendChild(pop);
    }

    const { usedTokens, maxTokens, pct } = getEffectiveMetrics();
    const remainingTokens = Math.max(0, maxTokens - usedTokens);
    const bd = latestStatus?.breakdown || {};
    const sysTokens = Number(bd.systemPromptTokens || 0);
    const toolsTokens = Number(bd.toolsTokens || 0);
    const toolResTokens = Number(bd.toolResultsTokens || 0);
    const assistantTokens = Number(bd.assistantTokens || 0);
    const userPlusCpTokens = Number(bd.userTokens || 0) + Number(bd.checkpointTokens || 0);

    const breakdownSum = sysTokens + toolsTokens + toolResTokens + assistantTokens + userPlusCpTokens;
    const scale = (breakdownSum > 0 && usedTokens > 0) ? (usedTokens / breakdownSum) : 1;

    const categories = [
      { label: 'System Prompt & Rules', tokens: Math.round(sysTokens * scale), color: '#6366f1' },
      { label: 'Tool Definitions', tokens: Math.round(toolsTokens * scale), color: '#06b6d4' },
      { label: 'Tool Outputs & Files', tokens: Math.round(toolResTokens * scale), color: '#10b981' },
      { label: 'Model Responses', tokens: Math.round(assistantTokens * scale), color: '#f59e0b' },
      { label: 'User & Checkpoints', tokens: Math.round(userPlusCpTokens * scale), color: '#3b82f6' }
    ];

    if (breakdownSum === 0 && usedTokens > 0) {
      categories.splice(0, categories.length, {
        label: 'Active Conversation Context',
        tokens: usedTokens,
        color: '#10b981'
      });
    }

    const modelLabel = getSelectedModelLabel() || latestStatus?.modelName || 'Current Model';
    const hasCascade = Boolean(getActiveCascadeId());

    const segsHtml = categories
      .filter((c) => c.tokens > 0 && maxTokens > 0)
      .map((c) => {
        const w = Math.max(0.8, Math.min(100, (c.tokens / maxTokens) * 100));
        return \`<div class="bhf-ctx-bar-seg" style="width:\${w.toFixed(2)}%;background:\${c.color}" title="\${c.label}: \${formatExactTokens(c.tokens)} tokens"></div>\`;
      })
      .join('');

    const rowsHtml = categories
      .map((c) => {
        const cPct = maxTokens > 0 ? ((c.tokens / maxTokens) * 100).toFixed(1) : '0.0';
        return \`<div class="bhf-ctx-row">
          <div class="bhf-ctx-row-left">
            <span class="bhf-ctx-dot" style="background:\${c.color}"></span>
            <span>\${c.label}</span>
          </div>
          <span>\${formatExactTokens(c.tokens)} <span style="opacity:0.6">(\${cPct}%)</span></span>
        </div>\`;
      })
      .join('');

    const remPct = maxTokens > 0 ? ((remainingTokens / maxTokens) * 100).toFixed(1) : '100.0';

    pop.innerHTML = \`
      <div class="bhf-ctx-header">
        <div class="bhf-ctx-title">
          <span>Context Window</span>
          <span style="font-size:10.5px;font-weight:500;opacity:0.65;max-width:170px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">\${modelLabel}</span>
        </div>
        <div style="display:flex;align-items:center;gap:2px">
          <button type="button" class="bhf-ctx-icon-btn" data-bhf-action="refresh" title="Refresh token usage">↻</button>
          <button type="button" class="bhf-ctx-icon-btn" data-bhf-action="close" title="Close">✕</button>
        </div>
      </div>
      <div class="bhf-ctx-sub">
        <span style="font-weight:600;font-size:13px">\${formatExactTokens(usedTokens)} <span style="opacity:0.65;font-weight:400">/ \${formatExactTokens(maxTokens)} tokens</span></span>
        <span style="font-weight:600;color:\${getStatusColor(pct)}">\${pct.toFixed(1)}% used</span>
      </div>
      <div class="bhf-ctx-bar-track">\${segsHtml}</div>
      <div class="bhf-ctx-rows">
        \${rowsHtml}
        <div class="bhf-ctx-row" style="padding-top:2px;opacity:0.8">
          <div class="bhf-ctx-row-left">
            <span class="bhf-ctx-dot" style="background:rgba(128,128,135,0.35)"></span>
            <span>Available Capacity</span>
          </div>
          <span>\${formatExactTokens(remainingTokens)} <span style="opacity:0.6">(\${remPct}%)</span></span>
        </div>
      </div>
      <div class="bhf-ctx-meta-grid">
        <div class="bhf-ctx-meta-box">
          <span class="bhf-ctx-meta-label">Cached Input</span>
          <span class="bhf-ctx-meta-val">\${formatCompactTokens(latestStatus?.cacheReadTokens || 0)}</span>
        </div>
        <div class="bhf-ctx-meta-box">
          <span class="bhf-ctx-meta-label">New Input</span>
          <span class="bhf-ctx-meta-val">\${formatCompactTokens(latestStatus?.inputTokens || 0)}</span>
        </div>
        <div class="bhf-ctx-meta-box">
          <span class="bhf-ctx-meta-label">Last Output</span>
          <span class="bhf-ctx-meta-val">\${formatCompactTokens(latestStatus?.outputTokens || 0)}</span>
        </div>
      </div>
      \${hasCascade ? \`
      <div class="bhf-ctx-footer">
        <button type="button" class="bhf-ctx-action-btn" data-bhf-action="inspector">
          <span>Open Full Context & Step Inspector</span>
        </button>
      </div>\` : ''}
    \`;

    pop.querySelector('[data-bhf-action="close"]')?.addEventListener('click', (e) => {
      e.stopPropagation();
      closePopover();
    });
    pop.querySelector('[data-bhf-action="refresh"]')?.addEventListener('click', (e) => {
      e.stopPropagation();
      refreshContextStatus(true);
    });
    pop.querySelector('[data-bhf-action="inspector"]')?.addEventListener('click', (e) => {
      e.stopPropagation();
      openNativeTrajectoryModal();
    });

    if (activeTriggerEl) {
      positionPopover(pop, activeTriggerEl);
    }
  }

  function togglePopover(triggerEl) {
    if (popoverOpen && activeTriggerEl === triggerEl) {
      closePopover();
      return;
    }
    activeTriggerEl = triggerEl;
    popoverOpen = true;
    renderPopoverContent();
    updateAllButtons();
    refreshContextStatus(true);
  }

  function normalizeProjectLabels() {
    document
      .querySelectorAll('[data-testid="workspace-mismatch-banner"]')
      .forEach((el) => {
        el.style.display = 'none';
      });
    const projectEls = document.querySelectorAll(
      '[data-testid="project-selector-trigger"], [data-testid="project-selector-item"]'
    );
    projectEls.forEach((el) => {
      const aria = el.getAttribute('aria-label');
      if (aria && /current:\s*Claude$/i.test(aria)) {
        el.setAttribute('aria-label', aria.replace(/Claude$/i, 'THEO'));
      }
      const pName = el.getAttribute('data-project-name');
      if (pName && pName.trim().toLowerCase() === 'claude') {
        el.setAttribute('data-project-name', 'THEO');
      }
      el.querySelectorAll('span').forEach((sp) => {
        if ((sp.textContent || '').trim() === 'Claude') {
          sp.textContent = 'THEO';
        }
        const t = sp.getAttribute('title');
        if (t && t.trim() === 'Claude') {
          sp.setAttribute('title', 'THEO');
        }
      });
    });
  }

  function dismissSecurityNoticeModal() {
    try {
      const headings = document.querySelectorAll('h2');
      for (const h of headings) {
        const title = (h.textContent || '').replace(/\\s+/g, ' ').trim();
        if (title !== 'Security Notice & Data Use' && title !== 'Terms of Service & Data Use') {
          continue;
        }
        const box = h.closest('[role="dialog"]') || h.parentElement?.parentElement || h.parentElement;
        if (!box) continue;
        const checkboxes = box.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach((cb) => {
          if (cb.checked) {
            cb.click();
          }
        });
        const buttons = box.querySelectorAll('button');
        for (const btn of buttons) {
          if (btn.disabled) continue;
          const bTxt = (btn.textContent || '').replace(/\\s+/g, ' ').trim();
          if (/^Accept and continue$/i.test(bTxt)) {
            btn.click();
            break;
          }
        }
      }
    } catch {}
  }

  function injectContextButtons() {
    ensureStyles();
    normalizeProjectLabels();
    dismissSecurityNoticeModal();
    const modelTriggers = document.querySelectorAll('[data-testid="model-selector-trigger"]');
    modelTriggers.forEach((trigger) => {
      const modelWrapper = trigger.closest('.no-focus-agent-input') || trigger.parentElement;
      if (!modelWrapper || !modelWrapper.parentElement) return;
      const parentRow = modelWrapper.parentElement;
      if (parentRow.querySelector(\`[\${WRAPPER_ATTR}="true"]\`)) return;

      const wrapper = document.createElement('div');
      wrapper.setAttribute(WRAPPER_ATTR, 'true');
      wrapper.className = 'no-focus-agent-input shrink-0 flex items-center';

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.setAttribute('data-testid', BTN_TESTID);
      btn.className = 'bhf-ctx-btn';
      btn.addEventListener('mousedown', (e) => {
        e.preventDefault();
      });
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.altKey || e.shiftKey) {
          openNativeTrajectoryModal();
          return;
        }
        togglePopover(btn);
      });

      wrapper.appendChild(btn);
      modelWrapper.insertAdjacentElement('afterend', wrapper);
      updateAllButtons();
    });
  }

  document.addEventListener('mousedown', (e) => {
    if (!popoverOpen) return;
    const pop = document.getElementById(POPOVER_ID);
    const target = e.target;
    if (pop && target instanceof Node && (pop.contains(target) || (activeTriggerEl && activeTriggerEl.contains(target)))) {
      return;
    }
    closePopover();
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && popoverOpen) {
      closePopover();
    }
  });

  window.addEventListener('resize', () => {
    if (popoverOpen && activeTriggerEl) {
      const pop = document.getElementById(POPOVER_ID);
      if (pop) positionPopover(pop, activeTriggerEl);
    }
  });

  const observer = new MutationObserver(() => {
    injectContextButtons();
    const cid = getActiveCascadeId();
    if (cid !== activeCascadeId) {
      refreshContextStatus(true);
    }
  });

  function scanApprovalButtons() {
    const buttons = Array.from(document.querySelectorAll('button'));
    const found = [];
    let hasSkip = false;
    let hasSubmitAny = false;
    for (const btn of buttons) {
      if (btn.offsetParent === null) continue;
      if (btn.closest('#' + POPOVER_ID) || btn.getAttribute('data-testid') === BTN_TESTID) continue;
      const txt = (btn.textContent || '').replace(/\\s+/g, ' ').trim();
      if (/^Skip$/i.test(txt) && !btn.disabled) hasSkip = true;
      if (/^Submit$/i.test(txt)) hasSubmitAny = true;
      if (btn.disabled) continue;
      if (/^(Run|Accept|Approve|Proceed|Submit|Allow|Reject|Deny|Cancel)$/i.test(txt)) {
        if (!found.includes(txt)) found.push(txt);
      }
    }
    if (hasSkip && hasSubmitAny) {
      if (!found.includes('Submit')) found.push('Submit');
      if (!found.includes('Skip')) found.push('Skip');
    }
    return found;
  }

  function hasTerminatedErrorBanner() {
    try {
      const buttons = Array.from(document.querySelectorAll('button'));
      let hasRetry = false;
      let hasCopyDebug = false;
      for (const btn of buttons) {
        if (btn.offsetParent === null) continue;
        const txt = (btn.textContent || '').replace(/\\s+/g, ' ').trim();
        if (!btn.disabled && /^Retry$/i.test(txt)) hasRetry = true;
        if (/^Copy debug info$/i.test(txt)) hasCopyDebug = true;
        if (hasRetry && hasCopyDebug) return true;
      }
    } catch {}
    return false;
  }

  function executeRemoteAction(act) {
    if (!act || typeof act !== 'object') return;
    if (act.kind === 'approve' || act.kind === 'reject') {
      const targetRe = act.targetLabel
        ? new RegExp('^' + act.targetLabel.replace(/[.*+?^\${}()|[\\]\\\\]/g, '\\\\$&') + '$', 'i')
        : act.kind === 'approve'
          ? /^(Run|Accept|Approve|Proceed|Submit|Allow)$/i
          : /^(Reject|Deny|Cancel|Skip)$/i;
      const buttons = Array.from(document.querySelectorAll('button'));
      for (const btn of buttons) {
        if (btn.disabled || btn.offsetParent === null) continue;
        const txt = (btn.textContent || '').replace(/\\s+/g, ' ').trim();
        if (targetRe.test(txt)) {
          btn.click();
          break;
        }
      }
    } else if (act.kind === 'answerQuestion') {
      if (act.skipped) {
        const skipBtn = Array.from(document.querySelectorAll('button')).find((b) => {
          if (b.disabled || b.offsetParent === null) return false;
          const t = (b.textContent || '').replace(/\\s+/g, ' ').trim();
          return /^Skip$/i.test(t);
        });
        if (skipBtn) skipBtn.click();
        return;
      }
      const selIds = Array.isArray(act.selectedOptionIds)
        ? act.selectedOptionIds.map((x) => String(x))
        : [];
      const selTexts = Array.isArray(act.selectedTexts)
        ? act.selectedTexts.map((x) => String(x).trim().toLowerCase())
        : [];
      const optLabels = Array.from(
        document.querySelectorAll('[data-testid="ask-question-option"]')
      );
      for (const lbl of optLabels) {
        const inp = lbl.querySelector('input');
        const txtEl = lbl.querySelector('[data-testid="ask-question-option-text"]');
        const val = inp ? String(inp.value || '') : '';
        const optTxt = txtEl ? (txtEl.textContent || '').replace(/\\s+/g, ' ').trim().toLowerCase() : '';
        const want =
          (val && selIds.includes(val)) ||
          (optTxt && selTexts.includes(optTxt));
        if (want && inp && !inp.checked) {
          lbl.click();
        }
      }
      if (act.writeInResponse) {
        const writeIn = document.querySelector('[data-testid="ask-question-writein"]');
        if (writeIn) {
          writeIn.click();
          const setter = Object.getOwnPropertyDescriptor(
            window.HTMLTextAreaElement.prototype,
            'value'
          )?.set;
          if (setter) setter.call(writeIn, String(act.writeInResponse));
          else writeIn.value = String(act.writeInResponse);
          writeIn.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
      setTimeout(() => {
        const submitBtn = Array.from(document.querySelectorAll('button')).find((b) => {
          if (b.disabled || b.offsetParent === null) return false;
          const t = (b.textContent || '').replace(/\\s+/g, ' ').trim();
          return /^Submit$/i.test(t);
        });
        if (submitBtn) submitBtn.click();
      }, 120);
    } else if (act.kind === 'prompt' && act.text) {
      const editor =
        document.querySelector('[data-lexical-editor="true"]') ||
        document.querySelector('[contenteditable="true"]') ||
        document.querySelector('textarea');
      if (editor) {
        editor.focus();
        const lex = editor.__lexicalEditor;
        if (
          lex &&
          typeof lex.parseEditorState === 'function' &&
          typeof lex.setEditorState === 'function'
        ) {
          try {
            const stateJson = JSON.stringify({
              root: {
                children: [
                  {
                    children: [
                      {
                        detail: 0,
                        format: 0,
                        mode: 'normal',
                        text: String(act.text),
                        type: 'text',
                        version: 1,
                        style: ''
                      }
                    ],
                    type: 'paragraph',
                    direction: 'ltr',
                    indent: 0,
                    version: 1,
                    format: '',
                    textFormat: 0,
                    textStyle: 'paragraph'
                  }
                ],
                type: 'root',
                direction: 'ltr',
                indent: 0,
                version: 1,
                format: ''
              }
            });
            lex.setEditorState(lex.parseEditorState(stateJson));
          } catch {}
        } else if (editor.tagName === 'TEXTAREA') {
          editor.value = act.text;
          editor.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          document.execCommand('selectAll', false, null);
          document.execCommand('insertText', false, act.text);
        }
        setTimeout(() => {
          const sendBtn =
            document.querySelector('[data-testid="send-button"]') ||
            document.querySelector('[data-tooltip-id="input-send-button-send-tooltip"]') ||
            Array.from(document.querySelectorAll('button')).find((b) =>
              /send|submit/i.test(b.getAttribute('aria-label') || b.title || '')
            );
          if (sendBtn && !sendBtn.disabled) {
            sendBtn.click();
          } else {
            editor.dispatchEvent(
              new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true })
            );
          }
        }, 120);
      }
    } else if (act.kind === 'cancel' || act.kind === 'stop' || act.kind === 'interrupt') {
      const cancelBtn =
        document.querySelector('[data-tooltip-id=input-send-button-cancel-tooltip]') ||
        Array.from(document.querySelectorAll('button')).find((b) =>
          /^cancel|^stop/i.test(b.getAttribute('aria-label') || b.title || '')
        );
      if (cancelBtn && !cancelBtn.disabled) {
        cancelBtn.click();
      }
    } else if (act.kind === 'refresh_auth') {
      try {
        if (typeof BroadcastChannel === 'function') {
          const ch = new BroadcastChannel('jetski_ls_auth_channel');
          ch.postMessage({
            type: 'SIGN_IN',
            timestamp: Date.now(),
            payload: act.payload || { isGcpTos: false, project: '', location: '', grantedScopes: [] }
          });
          setTimeout(() => {
            try {
              ch.close();
            } catch {}
          }, 250);
        }
      } catch {}
    }
  }

  async function pollRemoteBridge() {
    try {
      const cid = getActiveCascadeId() || '';
      const btns = scanApprovalButtons();
      const terminatedErr = hasTerminatedErrorBanner();
      const q = new URLSearchParams({
        id: cid,
        tabId: String(window.__bhfTabId || ''),
        approvals: JSON.stringify(btns),
        ...(terminatedErr ? { terminatedError: '1' } : {})
      });
      const res = await fetch('/__bhf_remote_poll?' + q.toString(), { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      const nextPort = Number(data?.targetPort || 0);
      if (nextPort > 0) {
        if (lastKnownHubPort > 0 && nextPort !== lastKnownHubPort) {
          lastKnownHubPort = nextPort;
          try {
            if (typeof window.__bhfCloseAllActiveWs === 'function') {
              window.__bhfCloseAllActiveWs('bhf_hub_switch');
            } else if (window.__bhfActiveWs && window.__bhfActiveWs.readyState === 1) {
              window.__bhfActiveWs.close(1001, 'bhf_hub_switch');
            }
          } catch {}
        } else if (!lastKnownHubPort) {
          lastKnownHubPort = nextPort;
        }
      }
      if (Array.isArray(data?.actions)) {
        for (const act of data.actions) {
          executeRemoteAction(act);
        }
      }
    } catch {}
  }

  let hiddenTick = 0;

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
      hiddenTick = 0;
      injectContextButtons();
      refreshContextStatus(false);
      pollRemoteBridge();
    }
  });

  async function maybeRecoverStuckAuthBoot() {
    try {
      const rootEl = document.getElementById('root');
      if (!rootEl) return;
      const hasSpin = Boolean(rootEl.querySelector('.animate-spin'));
      if (!hasSpin) return;
      const hasInteractiveUi = Boolean(
        document.querySelector(
          '[data-testid="model-selector-trigger"], [data-lexical-editor="true"], [role="dialog"]'
        )
      );
      if (hasInteractiveUi) return;
      const rootText = String(rootEl.innerText || '').trim();
      if (
        rootText.length > 120 ||
        rootEl.querySelector('button, input, textarea, [contenteditable="true"]')
      ) {
        return;
      }
      const cid = getActiveCascadeId() || '';
      const resp = await fetch(
        '/__bhf_auth_fastcheck' + (cid ? '?id=' + encodeURIComponent(cid) : ''),
        { cache: 'no-store' }
      );
      if (!resp.ok) return;
      const data = await resp.json();
      if (data?.signedIn === true) {
        executeRemoteAction({
          kind: 'refresh_auth',
          payload: data.signInPayload || { isGcpTos: false, project: '', location: '', grantedScopes: [] }
        });
      }
    } catch {}
  }

  function start() {
    injectContextButtons();
    if (!document.hidden) {
      refreshContextStatus(true);
    }
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    }
    setTimeout(maybeRecoverStuckAuthBoot, 2000);
    setTimeout(maybeRecoverStuckAuthBoot, 5000);
    setInterval(() => {
      if (document.hidden) {
        hiddenTick += 1;
        if (hiddenTick % 2 === 0) {
          pollRemoteBridge();
        }
        return;
      }
      hiddenTick = 0;
      injectContextButtons();
      refreshContextStatus(false);
      pollRemoteBridge();
    }, 2000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();`;
}

function findBalancedCallEnd(text, openIdx) {
  // openIdx points at the '(' of a call; returns the index just past its matching ')', or -1.
  let depth = 0;
  let quote = null;
  for (let i = openIdx; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (ch === '\\') {
        i++;
        continue;
      }
      if (ch === quote) {
        quote = null;
      }
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') {
      quote = ch;
      continue;
    }
    if (ch === '(' || ch === '{' || ch === '[') {
      depth++;
    } else if (ch === ')' || ch === '}' || ch === ']') {
      depth--;
      if (depth === 0) {
        return i + 1;
      }
    }
  }
  return -1;
}

function patchMainJsSource(jsText) {
  let patched = jsText;
  const routeMarker = '{routeTree:';
  const routeIdx = patched.indexOf(routeMarker);
  if (routeIdx !== -1 && !patched.includes('window.__bhfRouter=')) {
    // Expect `<id>=<id>=new <Ctor>(` immediately before `{routeTree:`; the bundle's argument
    // list after InnerWrap has changed before (context, basepath were added), so the closing
    // paren is found by scanning for the balanced `)` instead of assuming a fixed shape.
    const head = patched.slice(Math.max(0, routeIdx - 80), routeIdx);
    const m = head.match(/([A-Za-z0-9_$]+=[A-Za-z0-9_$]+=new [A-Za-z0-9_$]+\()$/);
    if (m) {
      const exprStart = routeIdx - m[1].length;
      const exprEnd = findBalancedCallEnd(patched, routeIdx - 1);
      if (exprEnd !== -1 && exprEnd - exprStart < 2000) {
        patched =
          patched.slice(0, exprStart) +
          '(window.__bhfRouter=' +
          patched.slice(exprStart, exprEnd) +
          ')' +
          patched.slice(exprEnd);
      }
    }
  }
  patched = patched.replace(
    'trajectoryDebugTools:{feature:!1,',
    'trajectoryDebugTools:{feature:!0,'
  );
  if (!patched.includes('/*bhf-theo-proj*/')) {
    const baseNeedle = '.basename(';
    let bIdx = patched.indexOf(baseNeedle);
    while (bIdx !== -1) {
      const winStart = Math.max(0, bIdx - 32);
      const winEnd = Math.min(patched.length, bIdx + 48);
      const slice = patched.slice(winStart, winEnd);
      if (slice.includes('||void 0')) {
        const replaced = slice.replace(
          /return ([A-Za-z0-9_$]+)\.basename\(([A-Za-z0-9_$]+)\)\|\|void 0/,
          'return(/^claude$/i.test($1.basename($2)||"")?"THEO"/*bhf-theo-proj*/:$1.basename($2))||void 0'
        );
        if (replaced !== slice) {
          patched = patched.slice(0, winStart) + replaced + patched.slice(winEnd);
          break;
        }
      }
      bIdx = patched.indexOf(baseNeedle, bIdx + baseNeedle.length);
    }
    const projNeedle = '?.project?.name??';
    let pIdx = patched.indexOf(projNeedle);
    while (pIdx !== -1) {
      const winStart = Math.max(0, pIdx - 16);
      const winEnd = Math.min(patched.length, pIdx + projNeedle.length + 16);
      const slice = patched.slice(winStart, winEnd);
      let nextSearchFrom = pIdx + projNeedle.length;
      const replaced = slice.replace(
        /([A-Za-z0-9_$]+)\?\.project\?\.name\?\?([A-Za-z0-9_$]+)/,
        (_m, lhs, rhs, offset) => {
          const rep = `(${lhs}?.project?.name==="Claude"?"THEO":${lhs}?.project?.name)??${rhs}`;
          nextSearchFrom = winStart + offset + rep.length;
          return rep;
        }
      );
      if (replaced !== slice) {
        patched = patched.slice(0, winStart) + replaced + patched.slice(winEnd);
      }
      pIdx = patched.indexOf(projNeedle, nextSearchFrom);
    }
    patched = patched.replace(
      /\b([A-Za-z0-9_$]+)&&\1\.userTier\?\.description\b/g,
      '$1&&($1.userTier?.id==="g1-ultra-tier"?($1.userTier?.description||"Google AI Ultra")+" (20x)":$1.userTier?.id==="g1-ultra-lite-tier"?($1.userTier?.description||"Google AI Ultra")+" (5x)":$1.userTier?.description)'
    );
  }
  if (!patched.includes('/*bhf-notif-dedupe*/')) {
    const notifNeedle = 'id:`agent-finished-${';
    const nIdx = patched.indexOf(notifNeedle);
    if (nIdx !== -1) {
      const winStart = Math.max(0, nIdx - 280);
      const winEnd = Math.min(patched.length, nIdx + 160);
      const slice = patched.slice(winStart, winEnd);
      const replaced = slice.replace(
        /id:`agent-finished-\$\{([A-Za-z0-9_$]+)\}-\$\{Date\.now\(\)\}`/,
        (_m, idVar) => {
          const escapedId = idVar.replace(/\$/g, '\\$');
          const sumMatch =
            slice.match(/\b([A-Za-z0-9_$]+)\.(?:stepCount|summary)\b/) ||
            slice.match(new RegExp(`\\b([A-Za-z0-9_$]+)=[A-Za-z0-9_$.]+\\.get\\(${escapedId}\\)`));
          const stepExpr = sumMatch?.[1]
            ? `(${sumMatch[1]}?.stepCount||Math.floor(Date.now()/90000))`
            : 'Math.floor(Date.now()/90000)';
          return `id:\`agent-finished-\${${idVar}}-\${/*bhf-notif-dedupe*/${stepExpr}}\``;
        }
      );
      if (replaced !== slice) {
        patched = patched.slice(0, winStart) + replaced + patched.slice(winEnd);
      }
    }
  }
  if (!patched.includes('/*bhf-trigger-send*/')) {
    const mediaNeedle = '.current?.getMediaAttachments()??[]';
    let mIdx = patched.indexOf(mediaNeedle);
    while (mIdx !== -1) {
      const winStart = Math.max(0, mIdx - 160);
      const winEnd = Math.min(patched.length, mIdx + 160);
      const slice = patched.slice(winStart, winEnd);
      const replaced = slice.replace(
        /([A-Za-z0-9_$]+)=\(0,([A-Za-z0-9_$]+)\.useCallback\)\(async\(([A-Za-z0-9_$]+),([A-Za-z0-9_$]+)\)=>\{var ([A-Za-z0-9_$]+)=([A-Za-z0-9_$]+),([A-Za-z0-9_$]+)=\6;try\{([A-Za-z0-9_$]+)\(await \5\(([A-Za-z0-9_$]+)\(\3,([A-Za-z0-9_$]+)\.current\?\.getMediaAttachments\(\)\?\?\[\],\4\)\)\)\}finally\{\5\(\)\}\},\[\9,\10\]\);([A-Za-z0-9_$]+)\(([A-Za-z0-9_$]+),\1\);/,
        (_m, cbVar, reactNs, msgArg, optArg, wrapFn, initFn, outVar, callFn, sendFn, mediaRef, regFn, regArg) =>
          `${cbVar}=(0,${reactNs}.useCallback)(async(${msgArg},${optArg})=>{var ${wrapFn}=${initFn},${outVar}=${initFn};try{return ${callFn}(await ${wrapFn}(${sendFn}(${msgArg},${mediaRef}.current?.getMediaAttachments()??[],${optArg})))}finally{${wrapFn}()}},[${sendFn},${mediaRef}]);${regFn}(${regArg},${cbVar});/*bhf-trigger-send*/`
      );
      if (replaced !== slice) {
        patched = patched.slice(0, winStart) + replaced + patched.slice(winEnd);
        break;
      }
      mIdx = patched.indexOf(mediaNeedle, mIdx + mediaNeedle.length);
    }
  }
  if (!patched.includes('/*bhf-trigger-send-rpc*/') && !patched.includes('"bhf_composer_not_ready"')) {
    const trigNeedle = '.method.triggerSend,async()=>';
    const tIdx = patched.indexOf(trigNeedle);
    if (tIdx !== -1) {
      const winStart = Math.max(0, tIdx - 40);
      const winEnd = Math.min(patched.length, tIdx + 440);
      const slice = patched.slice(winStart, winEnd);
      const replaced = slice.replace(
        /([A-Za-z0-9_$]+)\.rpc\(([A-Za-z0-9_$]+)\.method\.triggerSend,async\(\)=>\{var ([A-Za-z0-9_$]+)=([A-Za-z0-9_$]+),([A-Za-z0-9_$]+)=\4;try\{let ([A-Za-z0-9_$]+)=([A-Za-z0-9_$]+)\(\);\s*if\(!\6\|\|!([A-Za-z0-9_$]+)\.current\)return\{\};let ([A-Za-z0-9_$]+)=\6\.getEditorState\(\),([A-Za-z0-9_$]+)=([A-Za-z0-9_$]+)\(\9\);([A-Za-z0-9_$]+)\(await \3\(\8\.current\(\10,\(\)=>\{([A-Za-z0-9_$]+)\(\6,\{recordPendingMentions:!0\}\);([A-Za-z0-9_$]+)\.current\?\.forgetTrackedUploads\(\);\14\.current\?\.setMediaAttachments\(\[\]\)\}\)\)\);return\{\}\}finally\{\3\(\)\}\}\)/,
        (_m, rpcObj, methodNs, wrapFn, initFn, outVar, edVar, getEdFn, sendRef, stateVar, textVar, serFn, callFn, clearFn, upRef) =>
          `${rpcObj}.rpc(${methodNs}.method.triggerSend,async()=>{var ${wrapFn}=${initFn},${outVar}=${initFn};try{let ${edVar}=${getEdFn}();if(!${edVar}||!${sendRef}.current)throw Error("bhf_composer_not_ready");let ${stateVar}=${edVar}.getEditorState(),${textVar}=${serFn}(${stateVar}),_bhfRes=${callFn}(await ${wrapFn}(${sendRef}.current(${textVar},()=>{${clearFn}(${edVar},{recordPendingMentions:!0});${upRef}.current?.forgetTrackedUploads();${upRef}.current?.setMediaAttachments([])})));if(_bhfRes&&(_bhfRes.status==="empty"||_bhfRes.status==="failed"))throw _bhfRes.error||Error("bhf_send_"+_bhfRes.status);return{/*bhf-trigger-send-rpc*/}}finally{${wrapFn}()}})`
      );
      if (replaced !== slice) {
        patched = patched.slice(0, winStart) + replaced + patched.slice(winEnd);
      }
    }
  }
  if (!patched.includes('/*bhf-ws-keepalive*/')) {
    const wsNeedle = 'no frames for 4000ms and ping unanswered; closing socket';
    const wIdx = patched.indexOf(wsNeedle);
    if (wIdx !== -1) {
      const winStart = Math.max(0, wIdx - 40);
      const winEnd = Math.min(patched.length, wIdx + 180);
      const slice = patched.slice(winStart, winEnd);
      const replaced = slice.replace(
        /(Error\("no frames for 4000ms and ping unanswered; closing socket"\)[^}]*\},)2E3(\)\}else\s+[A-Za-z0-9_$]+\([A-Za-z0-9_$]+\)\},\s*)2E3(\)\})/,
        (_m, g1, g2, g3) => `${g1}20E3/*bhf-ws-keepalive*/${g2}6E3${g3}`
      );
      if (replaced !== slice) {
        patched = patched.slice(0, winStart) + replaced + patched.slice(winEnd);
      }
    }
  }
  if (!patched.includes('/*bhf-no-terms-modal*/')) {
    const termsNeedle = 'return"no_prior_acceptance"';
    const tmIdx = patched.indexOf(termsNeedle);
    if (tmIdx !== -1) {
      const winStart = Math.max(0, tmIdx - 60);
      const winEnd = Math.min(patched.length, tmIdx + 240);
      const slice = patched.slice(winStart, winEnd);
      const replaced = slice.replace(
        /if\([A-Za-z0-9_$]+\([A-Za-z0-9_$]+\)\)\{if\(![A-Za-z0-9_$]+\.email\)return"no_prior_acceptance";if\([A-Za-z0-9_$]+\.email!==[A-Za-z0-9_$]+\.email\)return"account_changed"\}else if\([A-Za-z0-9_$]+\.isGcpTos===void 0\)return"no_prior_acceptance";return [A-Za-z0-9_$]+\.isGcpTos===[A-Za-z0-9_$]+\.isGcpTos\?void 0:"tos_type_changed"/,
        'return void 0/*bhf-no-terms-modal*/'
      );
      if (replaced !== slice) {
        patched = patched.slice(0, winStart) + replaced + patched.slice(winEnd);
      }
    }
    patched = patched.replaceAll('defaultTelemetryOnError:!0', 'defaultTelemetryOnError:!1');
    patched = patched
      .replaceAll('screens:[2,7,8]', 'screens:[2,8]')
      .replaceAll('screens:[2,7]', 'screens:[2]')
      .replaceAll('screens:[2,9,7]', 'screens:[2,9]')
      .replaceAll('screens:[2,10,7]', 'screens:[2,10]')
      .replaceAll('screens:[7]', 'screens:[]');
    const ccsNeedle = '[CloudCodeService] fetchUserInfo returned no userSettings';
    const ccsIdx = patched.indexOf(ccsNeedle);
    if (ccsIdx !== -1) {
      const winStart = Math.max(0, ccsIdx - 120);
      const winEnd = Math.min(patched.length, ccsIdx + 480);
      const slice = patched.slice(winStart, winEnd);
      const replaced = slice
        .replace(
          /if\(!([A-Za-z0-9_$]+)\.userSettings\)throw Error\("\[CloudCodeService\] fetchUserInfo returned no userSettings"\);return \1\.userSettings/,
          'if(!$1.userSettings)throw Error("[CloudCodeService] fetchUserInfo returned no userSettings");$1.userSettings.telemetryEnabled=!1;$1.userSettings.marketingEmailsEnabled=!1;return $1.userSettings'
        )
        .replace(
          /([A-Za-z0-9_$]+)\.setUserInfo\(([A-Za-z0-9_$]+)\(([A-Za-z0-9_$]+),\{userSettings:([A-Za-z0-9_$]+)\}\)\)\);if\(!([A-Za-z0-9_$]+)\.userSettings\)throw Error\("\[CloudCodeService\] setUserInfo returned no userSettings"\);return \5\.userSettings/,
          '$1.setUserInfo($2($3,{userSettings:{...$4,telemetryEnabled:!1,marketingEmailsEnabled:!1}})));if(!$5.userSettings)throw Error("[CloudCodeService] setUserInfo returned no userSettings");$5.userSettings.telemetryEnabled=!1;$5.userSettings.marketingEmailsEnabled=!1;return $5.userSettings'
        );
      if (replaced !== slice) {
        patched = patched.slice(0, winStart) + replaced + patched.slice(winEnd);
      }
    }
  }
  if (!patched.includes('/*bhf-workspace-routing*/')) {
    patched = patched.replace(
      /strictWorkspaceRouting:!0,get workspaceUri\(\)\{if\(typeof window==="undefined"\)return null;var ([A-Za-z0-9_$]+)=new URLSearchParams\(window\.location\.search\);return\(\1=\1\.get\("workspaceUri"\)\|\|\1\.get\("ws"\)\)\?\1\.startsWith\("file:\/\/"\)\?\1:`file:\/\/\$\{\1\}`:null\}/,
      'strictWorkspaceRouting:!1/*bhf-workspace-routing*/,get workspaceUri(){if(typeof window==="undefined")return null;var $1=new URLSearchParams(window.location.search);return($1=$1.get("workspaceUri")||$1.get("ws")||window.__bhfDefaultWorkspaceUri)?$1.startsWith("file://")?$1:`file://${$1}`:null}'
    );
    patched = patched.replace(
      /(?<![A-Za-z0-9_$])([A-Za-z0-9_$]+)\.get\("workspaceUri"\)\|\|\1\.get\("ws"\)(?!\|\|window\.__bhfDefaultWorkspaceUri)/g,
      '($1.get("workspaceUri")||$1.get("ws")||window.__bhfDefaultWorkspaceUri||null)'
    );
  }
  if (!patched.includes('/*bhf-fast-auth-status*/')) {
    const authNeedle = '._lsClient.getAuthStatus(';
    let aIdx = patched.indexOf(authNeedle);
    while (aIdx !== -1) {
      let nextFrom = aIdx + authNeedle.length;
      const head = patched.slice(Math.max(0, aIdx - 64), aIdx);
      const clientMatch = head.match(/((?:[A-Za-z0-9_$]+\.)*[A-Za-z0-9_$]+)$/);
      const openParenIdx = aIdx + authNeedle.length - 1;
      const callEnd = findBalancedCallEnd(patched, openParenIdx);
      if (clientMatch && callEnd !== -1 && callEnd - aIdx < 240) {
        const exprStart = aIdx - clientMatch[1].length;
        const prevCh = exprStart > 0 ? patched[exprStart - 1] : '';
        const boundarySafe =
          exprStart === 0 || !/[A-Za-z0-9_$.\]\)'"`]/.test(prevCh);
        if (boundarySafe) {
          const origCall = patched.slice(exprStart, callEnd);
          const clientExpr = clientMatch[1];
          const wrapped = `(typeof window!=="undefined"&&typeof window.__bhfFastGetAuthStatus==="function"?window.__bhfFastGetAuthStatus(${clientExpr},()=>${origCall}):${origCall})/*bhf-fast-auth-status*/`;
          patched = patched.slice(0, exprStart) + wrapped + patched.slice(callEnd);
          nextFrom = exprStart + wrapped.length;
        }
      }
      aIdx = patched.indexOf(authNeedle, nextFrom);
    }
  }
  if (!patched.includes('/*bhf-ws-boot-inline*/') && patched.includes('/connect-websocket')) {
    patched = `/*bhf-ws-boot-inline*/${buildClientWsBootScript()}\n${patched}`;
  }
  return patched;
}

function fetchAndPatchMainJs(proxyState, reqPath, forwardHeaders) {
  const origin = proxyState.upstreamOrigin;
  if (proxyState.mainJsCache && proxyState.mainJsCache.origin === origin) {
    return Promise.resolve(proxyState.mainJsCache);
  }
  if (proxyState.mainJsInFlight) {
    return proxyState.mainJsInFlight;
  }

  const cleanHeaders = { ...forwardHeaders };
  delete cleanHeaders['accept-encoding'];
  delete cleanHeaders['if-none-match'];
  delete cleanHeaders['if-modified-since'];

  const inFlight = new Promise((resolve, reject) => {
    const upReq = http.request(
      {
        agent: UPSTREAM_HTTP_AGENT,
        hostname: proxyState.upstreamHost,
        port: proxyState.upstreamPort,
        path: reqPath || '/main.js',
        method: 'GET',
        headers: cleanHeaders
      },
      (upRes) => {
        if (upRes.statusCode !== 200) {
          upRes.resume();
          reject(new Error(`Upstream /main.js HTTP ${upRes.statusCode}`));
          return;
        }
        const chunks = [];
        upRes.on('data', (chunk) => chunks.push(chunk));
        upRes.on('end', () => {
          try {
            const rawText = Buffer.concat(chunks).toString('utf8');
            const patchedText = (proxyState.patchMainJsSource || patchMainJsSource)(rawText);
            const outBuf = Buffer.from(patchedText, 'utf8');
            const outHeaders = { ...upRes.headers };
            delete outHeaders['content-encoding'];
            delete outHeaders['transfer-encoding'];
            outHeaders['content-length'] = String(outBuf.length);
            const rawEtag = typeof upRes.headers.etag === 'string' ? upRes.headers.etag : '';
            const patchedEtag = rawEtag
              ? rawEtag.replace(/"$/, '-bhf12"')
              : `"bhf12-${outBuf.length}"`;
            outHeaders.etag = patchedEtag;
            const entry = {
              origin,
              buffer: outBuf,
              headers: outHeaders,
              etag: patchedEtag
            };
            proxyState.mainJsCache = entry;
            resolve(entry);
          } catch (err) {
            reject(err);
          }
        });
        upRes.on('error', reject);
      }
    );
    upReq.on('error', reject);
    upReq.end();
  }).finally(() => {
    if (proxyState.mainJsInFlight === inFlight) {
      proxyState.mainJsInFlight = null;
    }
  });

  proxyState.mainJsInFlight = inFlight;
  return inFlight;
}

function notifyWorkerCsrf(csrfToken) {
  if (!isMainThread && parentPort && csrfToken) {
    try {
      parentPort.postMessage({ type: 'updateCsrf', csrfToken });
    } catch {}
  }
}

function injectScriptIntoHtml(htmlText, proxyState) {
  const csrfMatch = htmlText.match(/"csrfToken"\s*:\s*"([^"]+)"/);
  if (csrfMatch && csrfMatch[1] && proxyState.csrfToken !== csrfMatch[1]) {
    proxyState.csrfToken = csrfMatch[1];
    notifyWorkerCsrf(csrfMatch[1]);
  }
  let out = htmlText;
  const bootTag = '<script src="/__bhf_ws_boot.js"></script>';
  if (!out.includes('/__bhf_ws_boot.js')) {
    if (/<head[^>]*>/i.test(out)) {
      out = out.replace(/<head[^>]*>/i, (m) => `${m}${bootTag}`);
    } else {
      out = `${bootTag}${out}`;
    }
  }
  const scriptTag = '<script defer src="/__bhf_context_ui.js"></script>';
  if (!out.includes('/__bhf_context_ui.js')) {
    if (out.includes('</body>')) {
      out = out.replace('</body>', `${scriptTag}</body>`);
    } else {
      out = `${out}${scriptTag}`;
    }
  }
  return out;
}

function rewriteUpstreamHeaders(reqHeaders, proxyState, targetOverride = null) {
  const headers = { ...reqHeaders };
  delete headers['x-bhf-tab-id'];
  delete headers['x-bhf-cascade-id'];
  const targetHost = targetOverride?.host || proxyState.upstreamHost;
  const targetPort = Number(targetOverride?.port || proxyState.upstreamPort || 0);
  const targetCsrf =
    targetOverride && typeof targetOverride.csrfToken === 'string' && targetOverride.csrfToken
      ? targetOverride.csrfToken
      : proxyState.csrfToken;
  const hostAuthority = `${targetHost}:${targetPort}`;
  headers.host = hostAuthority;
  if (headers.origin) {
    headers.origin = `http://${hostAuthority}`;
  }
  if (headers.referer) {
    try {
      const refUrl = new URL(headers.referer);
      refUrl.host = hostAuthority;
      headers.referer = refUrl.toString();
    } catch {}
  }
  const csrf = headers['x-codeium-csrf-token'];
  if (targetCsrf) {
    if (typeof csrf === 'string' && csrf.trim()) {
      headers['x-codeium-csrf-token'] = targetCsrf;
    }
  } else if (typeof csrf === 'string' && csrf.trim()) {
    proxyState.csrfToken = csrf.trim();
    notifyWorkerCsrf(proxyState.csrfToken);
  }
  return headers;
}

const PROXY_HANDLER_VERSION = 9;
const BRIDGE_STATE_SYMBOL = Symbol.for('bhfirms.antigravityHub.bridgeState');

function readPersistentHubStateForProxy() {
  try {
    const filePath =
      process.env.THEO_PERSISTENT_HUB_STATE_PATH ||
      path.join(os.homedir(), '.gemini', 'antigravity', 'bhf-persistent-hub.json');
    if (!fs.existsSync(filePath)) {
      return null;
    }
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const port = Number(parsed?.port || 0);
    const csrfToken = String(parsed?.csrfToken || '').trim();
    if (port > 0 && csrfToken) {
      return {
        port,
        csrfToken,
        serverUrl:
          typeof parsed.serverUrl === 'string' && parsed.serverUrl.trim()
            ? parsed.serverUrl.trim()
            : `http://127.0.0.1:${port}`
      };
    }
  } catch {}
  return null;
}

function probeUpstreamPortAlive(host, port, csrfToken, timeoutMs = 900) {
  return new Promise((resolve) => {
    const cleanPort = Number(port || 0);
    if (cleanPort <= 0) {
      resolve(false);
      return;
    }
    const sock = net.connect(cleanPort, host || '127.0.0.1');
    let settled = false;
    const done = (ok) => {
      if (settled) return;
      settled = true;
      try {
        sock.destroy();
      } catch {}
      resolve(ok);
    };
    sock.setTimeout(timeoutMs);
    sock.on('connect', () => done(true));
    sock.on('timeout', () => done(false));
    sock.on('error', () => done(false));
  });
}

const pendingWorkerRecoverReqs = new Map();
let workerRecoverSeq = 0;

async function recoverUpstreamMainThread(proxyState, failedPort = 0) {
  try {
    const bridgeState = globalThis[BRIDGE_STATE_SYMBOL];
    if (bridgeState && typeof bridgeState.ensureUpstreamAlive === 'function') {
      const res = await bridgeState.ensureUpstreamAlive(failedPort);
      const nextPort = Number(
        res?.port || bridgeState.serverManager?.port || proxyState?.upstreamPort || 0
      );
      if (nextPort > 0) {
        updateUpstreamTarget(
          proxyState,
          bridgeState.serverManager?.serverUrl || `http://127.0.0.1:${nextPort}`
        );
        if (bridgeState.serverManager?.csrfToken) {
          proxyState.csrfToken = String(bridgeState.serverManager.csrfToken).trim();
        }
        return true;
      }
    }
  } catch {}
  return (
    Number(proxyState?.upstreamPort || 0) > 0 &&
    Number(proxyState?.upstreamPort) !== Number(failedPort)
  );
}

async function recoverUpstreamIfDead(proxyState, failedPort = 0) {
  const diskHub = readPersistentHubStateForProxy();
  if (diskHub && diskHub.port > 0 && diskHub.port !== Number(failedPort)) {
    const alive = await probeUpstreamPortAlive('127.0.0.1', diskHub.port, diskHub.csrfToken, 800);
    if (alive) {
      updateUpstreamTarget(proxyState, diskHub.serverUrl);
      if (diskHub.csrfToken) {
        proxyState.csrfToken = diskHub.csrfToken;
      }
      if (!isMainThread && parentPort) {
        try {
          parentPort.postMessage({
            type: 'upstreamRecoveredFromDisk',
            port: diskHub.port,
            csrfToken: diskHub.csrfToken,
            serverUrl: diskHub.serverUrl
          });
        } catch {}
      }
      return true;
    }
  }

  if (isMainThread) {
    return recoverUpstreamMainThread(proxyState, failedPort);
  }

  if (!parentPort) {
    return false;
  }

  const reqId = `rec-${++workerRecoverSeq}`;
  const res = await new Promise((resolve) => {
    const timer = setTimeout(() => {
      pendingWorkerRecoverReqs.delete(reqId);
      resolve(null);
    }, 4500);
    pendingWorkerRecoverReqs.set(reqId, (msg) => {
      clearTimeout(timer);
      pendingWorkerRecoverReqs.delete(reqId);
      resolve(msg);
    });
    try {
      parentPort.postMessage({ type: 'recoverUpstream', reqId, failedPort: Number(failedPort || 0) });
    } catch {
      clearTimeout(timer);
      pendingWorkerRecoverReqs.delete(reqId);
      resolve(null);
    }
  });

  if (res && Number(res.upstreamPort || 0) > 0) {
    updateUpstreamTarget(
      proxyState,
      res.upstreamOrigin || `http://${res.upstreamHost || '127.0.0.1'}:${res.upstreamPort}`
    );
    if (res.csrfToken) {
      proxyState.csrfToken = String(res.csrfToken).trim();
    }
    return Boolean(res.ok || Number(proxyState.upstreamPort) !== Number(failedPort));
  }

  const diskHubAfter = readPersistentHubStateForProxy();
  if (diskHubAfter && diskHubAfter.port > 0 && diskHubAfter.port !== Number(failedPort)) {
    updateUpstreamTarget(proxyState, diskHubAfter.serverUrl);
    if (diskHubAfter.csrfToken) {
      proxyState.csrfToken = diskHubAfter.csrfToken;
    }
    return true;
  }

  return (
    Number(proxyState?.upstreamPort || 0) > 0 &&
    Number(proxyState?.upstreamPort) !== Number(failedPort)
  );
}

function attachProxyServerHandlers(server, proxyState) {
  if (!server || proxyState.handlerVersion === PROXY_HANDLER_VERSION) {
    return;
  }
  proxyState.handlerVersion = PROXY_HANDLER_VERSION;
  server.removeAllListeners('request');
  server.removeAllListeners('upgrade');

  server.on('request', async (req, res) => {
    try {
      const reqUrl = new URL(req.url || '/', `http://127.0.0.1:${proxyState.proxyPort || 80}`);
      const pathname = reqUrl.pathname;

      // 1a. Synchronous <head> WebSocket + fetch boot script
      if (req.method === 'GET' && pathname === '/__bhf_ws_boot.js') {
        const body = Buffer.from(buildClientWsBootScript(), 'utf8');
        res.writeHead(200, {
          'Content-Type': 'application/javascript; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Length': body.length
        });
        res.end(body);
        return;
      }

      // 1b. Tab -> Cascade live route binding endpoint
      if (req.method === 'GET' && pathname === '/__bhf_tab_bind') {
        const tabId = reqUrl.searchParams.get('tabId') || String(req.headers['x-bhf-tab-id'] || '');
        const cid = reqUrl.searchParams.get('id') || String(req.headers['x-bhf-cascade-id'] || '');
        bindTabCascade(proxyState, tabId, cid);
        const targetUp = resolveUpstreamForCascade(proxyState, cid);
        const body = Buffer.from(
          JSON.stringify({ ok: true, targetPort: Number(targetUp.port || 0) }),
          'utf8'
        );
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Length': body.length
        });
        res.end(body);
        return;
      }

      // 1c. Client UI script
      if (req.method === 'GET' && pathname === '/__bhf_context_ui.js') {
        const body = Buffer.from(buildClientContextUiScript(), 'utf8');
        res.writeHead(200, {
          'Content-Type': 'application/javascript; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Length': body.length
        });
        res.end(body);
        return;
      }

      // 2. Context Window status JSON endpoint
      if (req.method === 'GET' && pathname === '/__bhf_context_status') {
        const cid = reqUrl.searchParams.get('id') || '';
        const tabId = reqUrl.searchParams.get('tabId') || String(req.headers['x-bhf-tab-id'] || '');
        if (tabId && cid) {
          bindTabCascade(proxyState, tabId, cid);
        }
        const force = reqUrl.searchParams.get('force') === '1';
        const status = await fetchContextWindowStatus(proxyState, cid, force);
        const body = Buffer.from(JSON.stringify(status), 'utf8');
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Length': body.length
        });
        res.end(body);
        return;
      }

      // 2a. Local hub auth fast-check when outbound GetAuthStatus is wedged
      if (req.method === 'GET' && pathname === '/__bhf_auth_fastcheck') {
        if (!isAllowedLoopbackOrigin(req, proxyState.proxyPort)) {
          res.writeHead(403, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end('{"ok":false,"error":"forbidden_origin"}');
          return;
        }
        const cid = reqUrl.searchParams.get('id') || String(req.headers['x-bhf-cascade-id'] || '');
        if (!proxyState.upstreamPort || proxyState.upstreamPort <= 0) {
          await recoverUpstreamIfDead(proxyState, 0);
        }
        const target = resolveUpstreamForCascade(proxyState, cid);
        const check = await probeUpstreamLocalSignedIn(proxyState, target, 1200);
        const body = Buffer.from(
          JSON.stringify({
            ok: true,
            signedIn: Boolean(check?.signedIn),
            authResult: check?.signedIn ? check.authResult : null,
            signInPayload: check?.signedIn ? check.signInPayload : null
          }),
          'utf8'
        );
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Length': body.length
        });
        res.end(body);
        return;
      }

      // 2b. Remote Bridge poll & approval reporting endpoint
      if (req.method === 'GET' && pathname === '/__bhf_remote_poll') {
        const cid = reqUrl.searchParams.get('id') || '';
        const tabId = reqUrl.searchParams.get('tabId') || String(req.headers['x-bhf-tab-id'] || '');
        if (tabId && cid) {
          bindTabCascade(proxyState, tabId, cid);
        }
        const effectiveCid =
          cid ||
          (tabId && proxyState.cascadeByTabId instanceof Map
            ? proxyState.cascadeByTabId.get(tabId)?.cascadeId || ''
            : '');
        const rawApprovals = reqUrl.searchParams.get('approvals') || '[]';
        try {
          const buttons = JSON.parse(rawApprovals);
          if (effectiveCid) {
            const cleanButtons = Array.isArray(buttons) ? buttons : [];
            const nowAt = Date.now();
            if (cleanButtons.length > 0) {
              proxyState.pendingApprovalsById.set(effectiveCid, {
                buttons: cleanButtons,
                updatedAt: nowAt
              });
            } else {
              proxyState.pendingApprovalsById.delete(effectiveCid);
            }
            if (!isMainThread && parentPort) {
              try {
                parentPort.postMessage({
                  type: 'updateApprovals',
                  cid: effectiveCid,
                  buttons: cleanButtons,
                  updatedAt: nowAt
                });
              } catch {}
            }
          }
        } catch {}
        if (effectiveCid && reqUrl.searchParams.get('terminatedError') === '1') {
          if (!isMainThread && parentPort) {
            try {
              parentPort.postMessage({
                type: 'cascadeTerminatedError',
                cid: effectiveCid
              });
            } catch {}
          } else {
            try {
              globalThis[BRIDGE_STATE_SYMBOL]?.notifyCascadeTerminatedError?.(effectiveCid);
            } catch {}
          }
        }
        if (!(proxyState.broadcastDeliveredById instanceof Map)) {
          proxyState.broadcastDeliveredById = new Map();
        }
        const nowPollMs = Date.now();
        const peerKey = String(tabId || effectiveCid || '__anon__').trim() || '__anon__';
        const matchedActions = [];
        const remaining = [];
        const drainedActionIds = [];
        for (const item of proxyState.remoteActionQueue) {
          if (!item || typeof item !== 'object') {
            continue;
          }
          if (item.id === '*') {
            const ttlMs = Math.min(60000, Math.max(2000, Number(item.broadcastTtlMs || 15000)));
            if (nowPollMs - Number(item.createdAt || 0) >= ttlMs) {
              if (item.actionId) {
                proxyState.broadcastDeliveredById.delete(item.actionId);
                drainedActionIds.push(item.actionId);
              }
              continue;
            }
            remaining.push(item);
            const mapKey = item.actionId || `anon-${item.createdAt || 0}`;
            let deliveredSet = proxyState.broadcastDeliveredById.get(mapKey);
            if (!(deliveredSet instanceof Set)) {
              deliveredSet = new Set();
              proxyState.broadcastDeliveredById.set(mapKey, deliveredSet);
            }
            if (!deliveredSet.has(peerKey)) {
              deliveredSet.add(peerKey);
              matchedActions.push(item);
            }
            continue;
          }
          if (
            item.id === '__new__'
              ? !effectiveCid
              : !item.id || (effectiveCid && item.id === effectiveCid)
          ) {
            matchedActions.push(item);
            if (item.actionId) {
              drainedActionIds.push(item.actionId);
            }
          } else if (nowPollMs - Number(item.createdAt || 0) < 60000) {
            remaining.push(item);
          } else if (item.actionId) {
            drainedActionIds.push(item.actionId);
          }
        }
        if (proxyState.broadcastDeliveredById.size > 64) {
          const activeBroadcastIds = new Set(
            remaining.filter((x) => x.id === '*' && x.actionId).map((x) => x.actionId)
          );
          for (const k of Array.from(proxyState.broadcastDeliveredById.keys())) {
            if (!activeBroadcastIds.has(k)) {
              proxyState.broadcastDeliveredById.delete(k);
            }
          }
        }
        proxyState.remoteActionQueue = remaining;
        if (!isMainThread && parentPort && drainedActionIds.length > 0) {
          try {
            parentPort.postMessage({
              type: 'actionsDrained',
              actionIds: drainedActionIds
            });
          } catch {}
        }
        const targetUp = resolveUpstreamForCascade(proxyState, effectiveCid);
        const body = Buffer.from(
          JSON.stringify({
            ok: true,
            actions: matchedActions,
            targetPort: Number(targetUp.port || 0)
          }),
          'utf8'
        );
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
          'Content-Length': body.length
        });
        res.end(body);
        return;
      }

      if (!proxyState.upstreamPort || proxyState.upstreamPort <= 0) {
        await recoverUpstreamIfDead(proxyState, 0);
      }

      // 3. Intercept /main.js or HTML navigation to inject UI hook
      const isMainJs = req.method === 'GET' && pathname === '/main.js';
      const isHtmlRoute =
        req.method === 'GET' &&
        (pathname === '/' || pathname === '/index.html' || pathname.startsWith('/c/'));

      if (isMainJs) {
        let cached;
        const attemptedPort = Number(proxyState.upstreamPort || 0);
        try {
          cached = await fetchAndPatchMainJs(
            proxyState,
            req.url,
            rewriteUpstreamHeaders(req.headers, proxyState)
          );
        } catch (err) {
          if (err && (err.code === 'ECONNREFUSED' || /ECONNREFUSED/i.test(String(err.message || '')))) {
            const recovered = await recoverUpstreamIfDead(proxyState, attemptedPort);
            if (recovered) {
              cached = await fetchAndPatchMainJs(
                proxyState,
                req.url,
                rewriteUpstreamHeaders(req.headers, proxyState)
              );
            } else {
              throw err;
            }
          } else {
            throw err;
          }
        }
        const ifNoneMatch = req.headers['if-none-match'];
        if (ifNoneMatch && cached.etag && ifNoneMatch === cached.etag) {
          res.writeHead(304, { ETag: cached.etag });
          res.end();
          return;
        }
        res.writeHead(200, cached.headers);
        res.end(cached.buffer);
        return;
      }

      const reqTabId = String(req.headers['x-bhf-tab-id'] || reqUrl.searchParams.get('bhfTabId') || '').trim();
      const headerCascadeId = String(
        req.headers['x-bhf-cascade-id'] || reqUrl.searchParams.get('bhfCid') || ''
      ).trim();
      let routeCascadeId = '';
      if (isValidCascadeIdToken(headerCascadeId)) {
        routeCascadeId = headerCascadeId;
      } else {
        routeCascadeId =
          extractCascadeIdFromPathOrReferer(pathname) ||
          extractCascadeIdFromPathOrReferer(req.headers.referer || '');
      }
      if (!routeCascadeId && reqTabId && proxyState.cascadeByTabId instanceof Map) {
        routeCascadeId = proxyState.cascadeByTabId.get(reqTabId)?.cascadeId || '';
      }
      if (reqTabId && routeCascadeId) {
        bindTabCascade(proxyState, reqTabId, routeCascadeId);
      }

      // 3b. Guard HTTP GetAuthStatus against wedged outbound Cloud Code calls on busy hubs
      if (
        req.method === 'POST' &&
        pathname === '/exa.language_server_pb.LanguageServerService/GetAuthStatus'
      ) {
        if (!proxyState.upstreamPort || proxyState.upstreamPort <= 0) {
          await recoverUpstreamIfDead(proxyState, 0);
        }
        const initialTarget = resolveUpstreamForCascade(proxyState, routeCascadeId);
        if (Number(initialTarget.port || 0) > 0) {
          const reqChunks = [];
          let reqBytes = 0;
          let bodyTooLarge = false;
          await new Promise((resolve) => {
            req.on('data', (c) => {
              if (bodyTooLarge) return;
              reqBytes += c.length;
              if (reqBytes <= 16384) {
                reqChunks.push(c);
              } else {
                bodyTooLarge = true;
                resolve();
              }
            });
            req.on('end', resolve);
            req.on('error', resolve);
          });
          if (bodyTooLarge) {
            if (!res.headersSent) {
              res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
            }
            res.end('{"error":"payload_too_large"}');
            try {
              req.destroy();
            } catch {}
            return;
          }
          const reqBuf = Buffer.concat(reqChunks);
          const attemptAuthPost = (allowRetry) => {
            const target = resolveUpstreamForCascade(proxyState, routeCascadeId);
            const targetPort = Number(target.port || 0);
            if (!targetPort || targetPort <= 0) {
              if (!res.headersSent) {
                res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' });
              }
              res.end('Proxy upstream error: upstream port unavailable');
              return;
            }
            const forwardHeaders = rewriteUpstreamHeaders(req.headers, proxyState, target);
            forwardHeaders['content-length'] = String(reqBuf.length);
            let settled = false;
            let upReq = null;
            const cleanupTimers = () => {
              clearTimeout(fallbackTimer);
              res.removeListener('close', onClientClose);
            };
            const onClientClose = () => {
              if (!settled) {
                settled = true;
                clearTimeout(fallbackTimer);
                try {
                  upReq?.destroy();
                } catch {}
              }
            };
            res.on('close', onClientClose);
            const fallbackTimer = setTimeout(async () => {
              if (settled || res.headersSent) return;
              try {
                const check = await probeUpstreamLocalSignedIn(proxyState, target, 1100);
                if (check?.signedIn && !settled && !res.headersSent) {
                  settled = true;
                  cleanupTimers();
                  try {
                    upReq?.destroy();
                  } catch {}
                  const outBuf = Buffer.from(
                    JSON.stringify({ authResult: check.authResult }),
                    'utf8'
                  );
                  res.writeHead(200, {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Cache-Control': 'no-store',
                    'Content-Length': String(outBuf.length)
                  });
                  res.end(outBuf);
                }
              } catch {}
            }, 2200);
            upReq = http.request(
              {
                agent: UPSTREAM_HTTP_AGENT,
                hostname: target.host,
                port: targetPort,
                path: req.url,
                method: 'POST',
                headers: forwardHeaders,
                timeout: 8000
              },
              (upRes) => {
                if (settled || res.headersSent) {
                  cleanupTimers();
                  upRes.resume();
                  return;
                }
                settled = true;
                cleanupTimers();
                res.writeHead(upRes.statusCode || 200, upRes.headers);
                upRes.pipe(res);
              }
            );
            upReq.on('timeout', () => {
              upReq.destroy(new Error('GetAuthStatus upstream timeout'));
            });
            upReq.on('error', async (err) => {
              cleanupTimers();
              if (settled || res.headersSent) return;
              const isRefused =
                err &&
                (err.code === 'ECONNREFUSED' || /ECONNREFUSED/i.test(String(err.message || '')));
              if (isRefused) {
                const recovered = await recoverUpstreamIfDead(proxyState, targetPort);
                if (recovered && allowRetry && !settled && !res.headersSent) {
                  attemptAuthPost(false);
                  return;
                }
              }
              try {
                const freshTarget = resolveUpstreamForCascade(proxyState, routeCascadeId);
                const check = await probeUpstreamLocalSignedIn(proxyState, freshTarget, 900);
                if (check?.signedIn && !settled && !res.headersSent) {
                  settled = true;
                  const outBuf = Buffer.from(
                    JSON.stringify({ authResult: check.authResult }),
                    'utf8'
                  );
                  res.writeHead(200, {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Cache-Control': 'no-store',
                    'Content-Length': String(outBuf.length)
                  });
                  res.end(outBuf);
                  return;
                }
              } catch {}
              settled = true;
              if (!res.headersSent) {
                res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' });
              }
              res.end(`Proxy upstream error: ${err.message}`);
            });
            upReq.write(reqBuf);
            upReq.end();
          };
          attemptAuthPost(true);
          return;
        }
      }

      const canRetryBodyless = req.method === 'GET' || req.method === 'HEAD';
      const sendToUpstream = (allowRetry) => {
        const target = resolveUpstreamForCascade(proxyState, routeCascadeId);
        const targetPort = Number(target.port || 0);
        const forwardHeaders = rewriteUpstreamHeaders(req.headers, proxyState, target);
        if (isHtmlRoute) {
          delete forwardHeaders['accept-encoding'];
          delete forwardHeaders['if-none-match'];
          delete forwardHeaders['if-modified-since'];
        }
        const upReq = http.request(
          {
            agent: UPSTREAM_HTTP_AGENT,
            hostname: target.host,
            port: targetPort,
            path: req.url,
            method: req.method,
            headers: forwardHeaders
          },
          (upRes) => {
            const contentType = String(upRes.headers['content-type'] || '');
            const shouldTransformHtml =
              isHtmlRoute && upRes.statusCode === 200 && contentType.includes('text/html');

            if (!shouldTransformHtml) {
              res.writeHead(upRes.statusCode || 200, upRes.headers);
              upRes.pipe(res);
              return;
            }

            const chunks = [];
            upRes.on('data', (chunk) => chunks.push(chunk));
            upRes.on('end', () => {
              const text = injectScriptIntoHtml(Buffer.concat(chunks).toString('utf8'), proxyState);
              const outBuf = Buffer.from(text, 'utf8');
              const outHeaders = { ...upRes.headers };
              delete outHeaders['content-encoding'];
              delete outHeaders['transfer-encoding'];
              outHeaders['content-length'] = String(outBuf.length);
              outHeaders['cache-control'] = 'no-store';
              res.writeHead(upRes.statusCode || 200, outHeaders);
              res.end(outBuf);
            });
          }
        );

        upReq.on('error', async (err) => {
          const isRefused =
            err && (err.code === 'ECONNREFUSED' || /ECONNREFUSED/i.test(String(err.message || '')));
          if (isRefused) {
            if (allowRetry && canRetryBodyless && !res.headersSent) {
              const recovered = await recoverUpstreamIfDead(proxyState, targetPort);
              if (recovered && !res.headersSent) {
                sendToUpstream(false);
                return;
              }
            } else {
              recoverUpstreamIfDead(proxyState, targetPort).catch(() => {});
            }
          }
          if (!res.headersSent) {
            res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' });
          }
          res.end(`Proxy upstream error: ${err.message}`);
        });

        if (canRetryBodyless) {
          upReq.end();
        } else {
          req.pipe(upReq);
        }
      };

      sendToUpstream(true);
    } catch (err) {
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      }
      res.end(`Proxy internal error: ${err.message}`);
    }
  });

  server.on('upgrade', (req, clientSocket, head) => {
    clientSocket.setNoDelay(true);
    let initialCascadeId = '';
    let bhfTabId = '';
    let forwardUrl = req.url || '/';
    try {
      const upUrl = new URL(req.url || '/', `http://127.0.0.1:${proxyState.proxyPort || 80}`);
      const bhfCid = String(upUrl.searchParams.get('bhfCid') || '').trim();
      const rawTabId = String(upUrl.searchParams.get('bhfTabId') || '').trim();
      let mutated = false;
      if (bhfCid && isValidCascadeIdToken(bhfCid)) {
        initialCascadeId = bhfCid;
        upUrl.searchParams.delete('bhfCid');
        mutated = true;
      } else if (upUrl.searchParams.has('bhfCid')) {
        upUrl.searchParams.delete('bhfCid');
        mutated = true;
      }
      if (rawTabId) {
        bhfTabId = rawTabId;
        upUrl.searchParams.delete('bhfTabId');
        mutated = true;
      }
      if (mutated) {
        forwardUrl = upUrl.pathname + (upUrl.search || '');
      }
    } catch {}
    if (!initialCascadeId && bhfTabId && proxyState.cascadeByTabId instanceof Map) {
      initialCascadeId = proxyState.cascadeByTabId.get(bhfTabId)?.cascadeId || '';
    }
    if (!initialCascadeId && head && head.length > 0) {
      initialCascadeId = extractCascadeIdFromWsChunk(head);
    }
    if (bhfTabId && initialCascadeId) {
      bindTabCascade(proxyState, bhfTabId, initialCascadeId);
    }

    const target = resolveUpstreamForCascade(proxyState, initialCascadeId);
    const targetPort = Number(target.port || 0);
    const targetHost = target.host || proxyState.upstreamHost || '127.0.0.1';
    const targetCsrf = target.csrfToken || proxyState.csrfToken || '';
    if (!targetPort || targetPort <= 0) {
      recoverUpstreamIfDead(proxyState, 0).catch(() => {});
      try {
        clientSocket.destroy();
      } catch {}
      return;
    }

    const socketEntry = {
      clientSocket,
      upSocket: null,
      targetPort,
      tabId: bhfTabId || '',
      cascadeId: initialCascadeId || ''
    };
    let sniffChunks = 0;
    const onClientDataSniff = (chunk) => {
      if (socketEntry.cascadeId || sniffChunks >= 300) {
        clientSocket.removeListener('data', onClientDataSniff);
        return;
      }
      sniffChunks += 1;
      const detected = extractCascadeIdFromWsChunk(chunk);
      if (detected) {
        socketEntry.cascadeId = detected;
        clientSocket.removeListener('data', onClientDataSniff);
        if (socketEntry.tabId) {
          bindTabCascade(proxyState, socketEntry.tabId, detected);
        } else {
          const expected = resolveUpstreamForCascade(proxyState, detected);
          if (
            Number(expected?.port || 0) > 0 &&
            Number(socketEntry.targetPort || 0) > 0 &&
            Number(expected.port) !== Number(socketEntry.targetPort)
          ) {
            try {
              socketEntry.upSocket?.destroy();
            } catch {}
            try {
              socketEntry.clientSocket?.destroy();
            } catch {}
          }
        }
      }
    };
    if (!socketEntry.cascadeId) {
      clientSocket.on('data', onClientDataSniff);
    }

    const upSocket = net.connect(targetPort, targetHost, () => {
      upSocket.setNoDelay(true);
      const hostAuthority = `${targetHost}:${targetPort}`;
      const lines = [`${req.method || 'GET'} ${forwardUrl} HTTP/${req.httpVersion || '1.1'}`];
      const rawHeaders = req.rawHeaders || [];
      for (let i = 0; i < rawHeaders.length; i += 2) {
        const k = rawHeaders[i];
        let v = rawHeaders[i + 1];
        const lower = k.toLowerCase();
        if (lower === 'host') {
          v = hostAuthority;
        } else if (lower === 'origin') {
          v = `http://${hostAuthority}`;
        } else if (lower === 'x-codeium-csrf-token' && targetCsrf) {
          v = targetCsrf;
        }
        lines.push(`${k}: ${v}`);
      }
      lines.push('', '');
      upSocket.write(lines.join('\r\n'));
      if (head && head.length > 0) {
        upSocket.write(head);
      }
      upSocket.pipe(clientSocket);
      clientSocket.pipe(upSocket);
    });
    socketEntry.upSocket = upSocket;

    if (proxyState.activeUpgradeSockets instanceof Set) {
      proxyState.activeUpgradeSockets.add(socketEntry);
    }

    const cleanup = (err) => {
      clientSocket.removeListener('data', onClientDataSniff);
      if (proxyState.activeUpgradeSockets instanceof Set) {
        proxyState.activeUpgradeSockets.delete(socketEntry);
      }
      if (err && (err.code === 'ECONNREFUSED' || /ECONNREFUSED/i.test(String(err.message || '')))) {
        recoverUpstreamIfDead(proxyState, targetPort).catch(() => {});
      }
      try {
        clientSocket.destroy();
      } catch {}
      try {
        upSocket.destroy();
      } catch {}
    };
    upSocket.on('error', cleanup);
    upSocket.on('close', () => {
      clientSocket.removeListener('data', onClientDataSniff);
      if (proxyState.activeUpgradeSockets instanceof Set) {
        proxyState.activeUpgradeSockets.delete(socketEntry);
      }
    });
    clientSocket.on('error', () => cleanup(null));
    clientSocket.on('close', () => {
      clientSocket.removeListener('data', onClientDataSniff);
      if (proxyState.activeUpgradeSockets instanceof Set) {
        proxyState.activeUpgradeSockets.delete(socketEntry);
      }
    });
  });
}

function attachWorkerBridgeListeners(proxyState, worker) {
  worker.on('message', (msg) => {
    if (!msg || typeof msg !== 'object') {
      return;
    }
    if (msg.type === 'updateApprovals' && msg.cid) {
      if (Array.isArray(msg.buttons) && msg.buttons.length > 0) {
        proxyState.pendingApprovalsById.set(msg.cid, {
          buttons: msg.buttons,
          updatedAt: Number(msg.updatedAt || Date.now())
        });
      } else {
        proxyState.pendingApprovalsById.delete(msg.cid);
      }
    } else if (msg.type === 'cascadeTerminatedError' && msg.cid) {
      try {
        globalThis[BRIDGE_STATE_SYMBOL]?.notifyCascadeTerminatedError?.(String(msg.cid));
      } catch {}
    } else if (msg.type === 'actionsDrained' && Array.isArray(msg.actionIds)) {
      const drainedSet = new Set(msg.actionIds);
      proxyState.remoteActionQueue = proxyState.remoteActionQueue.filter(
        (item) => !drainedSet.has(item.actionId)
      );
    } else if (msg.type === 'updateCsrf' && msg.csrfToken) {
      proxyState._suppressWorkerSync = true;
      try {
        proxyState.csrfToken = String(msg.csrfToken);
      } finally {
        proxyState._suppressWorkerSync = false;
      }
    } else if (msg.type === 'upstreamRecoveredFromDisk' && Number(msg.port) > 0) {
      proxyState._suppressWorkerSync = true;
      try {
        updateUpstreamTarget(proxyState, msg.serverUrl || `http://127.0.0.1:${Number(msg.port)}`);
        if (msg.csrfToken) {
          proxyState.csrfToken = String(msg.csrfToken);
        }
      } finally {
        proxyState._suppressWorkerSync = false;
      }
    } else if (msg.type === 'recoverUpstream' && msg.reqId) {
      recoverUpstreamMainThread(proxyState, Number(msg.failedPort || 0))
        .then((ok) => {
          try {
            worker.postMessage({
              type: 'recoverUpstreamResult',
              reqId: msg.reqId,
              ok: Boolean(ok),
              upstreamHost: proxyState.upstreamHost || '127.0.0.1',
              upstreamPort: Number(proxyState.upstreamPort || 0),
              upstreamOrigin: proxyState.upstreamOrigin || '',
              csrfToken: proxyState.csrfToken || ''
            });
          } catch {}
        })
        .catch(() => {
          try {
            worker.postMessage({
              type: 'recoverUpstreamResult',
              reqId: msg.reqId,
              ok: false,
              upstreamHost: proxyState.upstreamHost || '127.0.0.1',
              upstreamPort: Number(proxyState.upstreamPort || 0),
              upstreamOrigin: proxyState.upstreamOrigin || '',
              csrfToken: proxyState.csrfToken || ''
            });
          } catch {}
        });
    }
  });

  worker.on('error', () => {});
  worker.on('exit', () => {
    if (proxyState.worker === worker && !proxyState._stoppingProxy) {
      proxyState.worker = null;
      proxyState.listenPromise = null;
      const reboundPort = Number(proxyState.proxyPort || 0);
      if (reboundPort > 0 && !shouldDisableProxyWorker()) {
        startProxyWorkerWithRetry(proxyState, reboundPort).catch(() => {});
      }
    }
  });
}

function startProxyWorkerOnce(proxyState, bindPort = 0) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const worker = new Worker(__filename, {
      workerData: {
        isTheoProxyWorker: true,
        bindPort: Number(bindPort || 0),
        initialConfig: {
          upstreamHost: proxyState.upstreamHost || '127.0.0.1',
          upstreamPort: Number(proxyState.upstreamPort || 0),
          upstreamOrigin: proxyState.upstreamOrigin || '',
          csrfToken: proxyState.csrfToken || '',
          retiringHubs: Array.isArray(proxyState.retiringHubs)
            ? proxyState.retiringHubs.map((h) => ({
                pid: Number(h?.pid || 0),
                port: Number(h?.port || 0),
                csrfToken: String(h?.csrfToken || ''),
                serverUrl: String(h?.serverUrl || ''),
                cascadeIds: Array.isArray(h?.cascadeIds) ? h.cascadeIds.map(String) : []
              }))
            : [],
          remoteActionQueue: Array.isArray(proxyState.remoteActionQueue)
            ? proxyState.remoteActionQueue.slice()
            : []
        }
      }
    });

    const startupTimer = setTimeout(() => {
      if (settled) return;
      settled = true;
      worker.terminate().catch(() => {});
      reject(new Error('Proxy worker startup timeout'));
    }, 4000);

    const onStartupMsg = (msg) => {
      if (!msg || typeof msg !== 'object') return;
      if (msg.type === 'listening' && Number(msg.port) > 0) {
        if (settled) return;
        settled = true;
        clearTimeout(startupTimer);
        worker.removeListener('message', onStartupMsg);
        proxyState.worker = worker;
        proxyState.workerCodeSig = PROXY_WORKER_CODE_SIG;
        proxyState.proxyPort = Number(msg.port);
        attachWorkerBridgeListeners(proxyState, worker);
        worker.unref();
        resolve(`http://127.0.0.1:${Number(msg.port)}`);
      } else if (msg.type === 'listenError') {
        if (settled) return;
        settled = true;
        clearTimeout(startupTimer);
        worker.removeListener('message', onStartupMsg);
        worker.terminate().catch(() => {});
        const err = new Error(msg.message || 'Proxy worker listen error');
        err.code = msg.code || 'ERR_WORKER_LISTEN';
        reject(err);
      }
    };

    worker.on('message', onStartupMsg);
    worker.once('error', (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(startupTimer);
      worker.terminate().catch(() => {});
      reject(err);
    });
    worker.once('exit', (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(startupTimer);
      reject(new Error(`Proxy worker exited before listening (code ${code})`));
    });
  });
}

async function startProxyWorkerWithRetry(proxyState, bindPort = 0) {
  let lastErr = null;
  const maxAttempts = bindPort > 0 ? 4 : 1;
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    try {
      return await startProxyWorkerOnce(proxyState, bindPort);
    } catch (err) {
      lastErr = err;
      if (bindPort > 0 && attempt + 1 < maxAttempts) {
        await new Promise((r) => setTimeout(r, 45 * (attempt + 1)));
        continue;
      }
      break;
    }
  }
  throw lastErr || new Error('Failed to start proxy worker');
}

function startInProcessProxyServer(proxyState, bindPort = 0) {
  return new Promise((resolve, reject) => {
    const server = http.createServer();
    attachProxyServerHandlers(server, proxyState);
    server.once('error', (err) => {
      reject(err);
    });
    server.listen(Number(bindPort || 0), '127.0.0.1', () => {
      const addr = server.address();
      proxyState.server = server;
      proxyState.proxyPort = addr.port;
      scheduleInitialProxyAuthBroadcast(proxyState);
      resolve(`http://127.0.0.1:${addr.port}`);
    });
  });
}

function migrateOrUpgradeProxyWorker(proxyState, state = null) {
  if (!proxyState || shouldDisableProxyWorker()) {
    return null;
  }
  const existingPort = Number(proxyState.proxyPort || 0);
  if (existingPort <= 0) {
    return null;
  }
  const needsFromMainServer = Boolean(proxyState.server);
  const needsWorkerCodeUpgrade = Boolean(
    proxyState.worker && proxyState.workerCodeSig !== PROXY_WORKER_CODE_SIG
  );
  if (!needsFromMainServer && !needsWorkerCodeUpgrade) {
    return null;
  }
  if (proxyState.migrationPromise) {
    return proxyState.migrationPromise;
  }

  proxyState._suppressWorkerSync = true;
  try {
    proxyState.mainJsCache = null;
    proxyState.mainJsInFlight = null;
  } finally {
    proxyState._suppressWorkerSync = false;
  }

  if (state?.serverManager?.port > 0) {
    updateUpstreamTarget(
      proxyState,
      state.serverManager.serverUrl || `http://127.0.0.1:${state.serverManager.port}`
    );
    if (state.serverManager.csrfToken) {
      proxyState.csrfToken = String(state.serverManager.csrfToken).trim();
    }
  } else if (!proxyState.upstreamPort) {
    const diskHub = readPersistentHubStateForProxy();
    if (diskHub) {
      updateUpstreamTarget(proxyState, diskHub.serverUrl);
      proxyState.csrfToken = diskHub.csrfToken;
    }
  }

  const mig = (async () => {
    proxyState._stoppingProxy = true;
    try {
      if (proxyState.server) {
        const oldServer = proxyState.server;
        proxyState.server = null;
        closeUpstreamSocketsForPortLocal(proxyState, 0);
        try {
          oldServer.closeAllConnections?.();
        } catch {}
        await new Promise((r) => {
          try {
            oldServer.close(() => r());
          } catch {
            r();
          }
        });
      }
      if (proxyState.worker) {
        const oldWorker = proxyState.worker;
        proxyState.worker = null;
        try {
          oldWorker.ref?.();
          await oldWorker.terminate();
        } catch {}
      }
    } finally {
      proxyState._stoppingProxy = false;
    }

    try {
      const url = await startProxyWorkerWithRetry(proxyState, existingPort);
      proxyState.listenPromise = Promise.resolve(url);
      return url;
    } catch {
      const fallbackUrl = await startInProcessProxyServer(proxyState, existingPort);
      proxyState.listenPromise = Promise.resolve(fallbackUrl);
      return fallbackUrl;
    }
  })().finally(() => {
    if (proxyState.migrationPromise === mig) {
      proxyState.migrationPromise = null;
    }
  });

  proxyState.migrationPromise = mig;
  proxyState.listenPromise = mig;
  return mig;
}

async function stopContextProxy(proxyState = getProxyState()) {
  if (!proxyState) {
    return;
  }
  proxyState._stoppingProxy = true;
  try {
    closeUpstreamSocketsForPortLocal(proxyState, 0);
    if (proxyState.worker) {
      const w = proxyState.worker;
      proxyState.worker = null;
      w.ref?.();
      await w.terminate().catch(() => {});
    }
    if (proxyState.server) {
      const s = proxyState.server;
      proxyState.server = null;
      try {
        s.closeAllConnections?.();
      } catch {}
      await new Promise((r) => {
        try {
          s.close(() => r());
        } catch {
          r();
        }
      });
    }
    proxyState.listenPromise = null;
    proxyState.migrationPromise = null;
    proxyState.proxyPort = 0;
  } finally {
    proxyState._stoppingProxy = false;
  }
}

function ensureContextProxy(state, serverUrl) {
  const proxyState = getProxyState();
  const liveServerUrl =
    state?.serverManager?.port > 0
      ? state.serverManager.serverUrl || `http://127.0.0.1:${state.serverManager.port}`
      : serverUrl;
  updateUpstreamTarget(proxyState, liveServerUrl);
  if (state?.serverManager?.csrfToken) {
    proxyState.csrfToken = String(state.serverManager.csrfToken).trim();
  }

  // Also capture csrfToken from extension exports if available
  try {
    const ext = state?.vscode?.extensions?.getExtension?.('google.google-antigravity');
    if (!proxyState.csrfToken && ext?.isActive && ext?.exports?.csrfToken) {
      proxyState.csrfToken = String(ext.exports.csrfToken).trim();
    }
  } catch {}

  const migrated = migrateOrUpgradeProxyWorker(proxyState, state);
  if (migrated) {
    return migrated;
  }

  if (proxyState.worker && proxyState.proxyPort > 0) {
    scheduleWorkerConfigSync(proxyState, false);
    const url = `http://127.0.0.1:${proxyState.proxyPort}`;
    proxyState.listenPromise = Promise.resolve(url);
    return proxyState.listenPromise;
  }

  if (proxyState.server) {
    attachProxyServerHandlers(proxyState.server, proxyState);
  }

  if (proxyState.listenPromise) {
    return proxyState.listenPromise;
  }

  proxyState.listenPromise = (async () => {
    try {
      if (!shouldDisableProxyWorker()) {
        return await startProxyWorkerWithRetry(proxyState, 0);
      }
      return await startInProcessProxyServer(proxyState, 0);
    } catch (err) {
      if (!shouldDisableProxyWorker()) {
        try {
          return await startInProcessProxyServer(proxyState, 0);
        } catch {}
      }
      proxyState.listenPromise = null;
      throw err;
    }
  })();

  return proxyState.listenPromise;
}

const CONTEXT_WINDOW_PATCH_VERSION = 4;

function patchWebviewConnectionScript(scriptHtml) {
  if (typeof scriptHtml !== 'string' || !scriptHtml) {
    return scriptHtml;
  }
  return scriptHtml
    .replace(/\bconst\s+MAX_ATTEMPTS\s*=\s*\d+\s*;/, 'const MAX_ATTEMPTS = 36;')
    .replace(/\bconst\s+ATTEMPT_INTERVAL_MS\s*=\s*\d+\s*;/, 'const ATTEMPT_INTERVAL_MS = 1000;')
    .replace(/\bconst\s+INITIAL_DELAY_MS\s*=\s*\d+\s*;/, 'const INITIAL_DELAY_MS = 800;');
}

function installContextWindowSupport(state) {
  const proxyState = getProxyState();
  if (proxyState?.proxyPort > 0 && !shouldDisableProxyWorker()) {
    migrateOrUpgradeProxyWorker(proxyState, state)?.catch?.(() => {});
  } else if (proxyState?.server) {
    attachProxyServerHandlers(proxyState.server, proxyState);
  }
  const delegate = state?.renderer?.delegate;
  if (!delegate || delegate.__bhfContextWindowVersion === CONTEXT_WINDOW_PATCH_VERSION) {
    return;
  }
  delegate.__bhfContextWindowPatched = true;
  delegate.__bhfContextWindowVersion = CONTEXT_WINDOW_PATCH_VERSION;

  if (typeof delegate.buildIframeUrl === 'function') {
    const origBuildIframeUrl =
      delegate.__bhfOrigBuildIframeUrl || delegate.buildIframeUrl.bind(delegate);
    delegate.__bhfOrigBuildIframeUrl = origBuildIframeUrl;
    delegate.buildIframeUrl = function (serverUrl, options) {
      const built = origBuildIframeUrl(serverUrl, options);
      try {
        const defaultWsUri = getDefaultTheoWorkspaceUri();
        if (defaultWsUri && typeof built === 'string' && built) {
          const u = new URL(built);
          if (!u.searchParams.get('workspaceUri') && !u.searchParams.get('ws')) {
            u.searchParams.set('workspaceUri', defaultWsUri);
            return u.toString();
          }
        }
      } catch {}
      return built;
    };
  }

  if (typeof delegate.getConnectionScript === 'function') {
    const origGetConnScript =
      delegate.__bhfOrigGetConnectionScript || delegate.getConnectionScript.bind(delegate);
    delegate.__bhfOrigGetConnectionScript = origGetConnScript;
    delegate.getConnectionScript = function (...args) {
      return patchWebviewConnectionScript(origGetConnScript(...args));
    };
  }

  const origRenderIframe =
    delegate.__bhfOrigRenderIframe || delegate.renderIframe.bind(delegate);
  delegate.__bhfOrigRenderIframe = origRenderIframe;
  delegate.renderIframe = async function (webview, serverUrl, options) {
    let effectiveUrl = serverUrl;
    try {
      effectiveUrl = await ensureContextProxy(state, serverUrl);
    } catch (err) {
      console.error('[antigravity-hub-bridge] context proxy error:', err);
    }
    return origRenderIframe(webview, effectiveUrl, options);
  };
}

function runProxyWorkerMain() {
  const initCfg = workerData?.initialConfig || {};
  const workerProxyState = {
    server: null,
    worker: null,
    listenPromise: null,
    proxyPort: 0,
    upstreamHost: String(initCfg.upstreamHost || '127.0.0.1'),
    upstreamPort: Number(initCfg.upstreamPort || 0),
    upstreamOrigin: String(initCfg.upstreamOrigin || ''),
    csrfToken: String(initCfg.csrfToken || ''),
    retiringHubs: Array.isArray(initCfg.retiringHubs) ? initCfg.retiringHubs : [],
    cacheById: new Map(),
    mainJsCache: null,
    mainJsInFlight: null,
    remoteActionQueue: Array.isArray(initCfg.remoteActionQueue) ? initCfg.remoteActionQueue : [],
    broadcastDeliveredById: new Map(),
    lastValidAuthResultByPort: new Map(),
    pendingApprovalsById: new Map(),
    activeUpgradeSockets: new Set(),
    cascadeByTabId: new Map()
  };

  const server = http.createServer();
  workerProxyState.server = server;
  attachProxyServerHandlers(server, workerProxyState);

  parentPort.on('message', (msg) => {
    if (!msg || typeof msg !== 'object') {
      return;
    }
    if (msg.type === 'syncConfig') {
      const nextOrigin = String(msg.upstreamOrigin || '');
      if (
        msg.clearMainJsCache ||
        (workerProxyState.upstreamOrigin && nextOrigin && workerProxyState.upstreamOrigin !== nextOrigin)
      ) {
        workerProxyState.mainJsCache = null;
        workerProxyState.mainJsInFlight = null;
      }
      workerProxyState.upstreamHost = String(msg.upstreamHost || '127.0.0.1');
      workerProxyState.upstreamPort = Number(msg.upstreamPort || 0);
      workerProxyState.upstreamOrigin = nextOrigin;
      workerProxyState.csrfToken = String(msg.csrfToken || '');
      if (Array.isArray(msg.retiringHubs)) {
        workerProxyState.retiringHubs = msg.retiringHubs;
      }
    } else if (msg.type === 'enqueueAction' && msg.entry) {
      if (msg.entry.kind === 'refresh_auth') {
        workerProxyState._localAuthProbeCache = null;
        workerProxyState._localAuthProbeInFlight = null;
        workerProxyState._authStatusRefreshThrottle?.clear?.();
      }
      workerProxyState.remoteActionQueue.push(msg.entry);
      if (workerProxyState.remoteActionQueue.length > 50) {
        workerProxyState.remoteActionQueue.splice(
          0,
          workerProxyState.remoteActionQueue.length - 50
        );
      }
    } else if (msg.type === 'bindTabCascade') {
      bindTabCascade(workerProxyState, msg.tabId, msg.cascadeId);
    } else if (msg.type === 'closeSockets') {
      closeUpstreamSocketsForPortLocal(
        workerProxyState,
        Number(msg.portToClose || 0),
        msg.options || null
      );
    } else if (msg.type === 'recoverUpstreamResult' && msg.reqId) {
      const cb = pendingWorkerRecoverReqs.get(msg.reqId);
      if (cb) {
        cb(msg);
      }
    } else if (msg.type === 'shutdown') {
      closeUpstreamSocketsForPortLocal(workerProxyState, 0);
      try {
        server.closeAllConnections?.();
      } catch {}
      server.close(() => {
        process.exit(0);
      });
    }
  });

  server.once('error', (err) => {
    try {
      parentPort.postMessage({
        type: 'listenError',
        code: err?.code || 'ERR_LISTEN',
        message: err?.message || String(err)
      });
    } catch {}
  });

  const bindPort = Number(workerData?.bindPort || 0);
  server.listen(bindPort, '127.0.0.1', () => {
    const addr = server.address();
    workerProxyState.proxyPort = addr.port;
    scheduleInitialProxyAuthBroadcast(workerProxyState);
    try {
      parentPort.postMessage({ type: 'listening', port: addr.port });
    } catch {}
  });
}

if (!isMainThread && workerData?.isTheoProxyWorker) {
  runProxyWorkerMain();
}

module.exports = {
  installContextWindowSupport,
  ensureContextProxy,
  stopContextProxy,
  getProxyState,
  closeUpstreamSocketsForPort,
  resolveUpstreamForCascade,
  extractCascadeIdFromWsChunk,
  bindTabCascade,
  buildClientWsBootScript,
  buildClientContextUiScript,
  injectScriptIntoHtml,
  patchMainJsSource,
  patchWebviewConnectionScript,
  fetchContextWindowStatus,
  probeUpstreamLocalSignedIn,
  enqueueRemoteWebviewAction,
  getPendingApprovals
};



