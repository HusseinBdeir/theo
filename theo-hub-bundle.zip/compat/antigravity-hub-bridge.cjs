const crypto = require('crypto');
const dns = require('dns');
const fs = require('fs');
const http = require('http');
const net = require('net');
const os = require('os');
const path = require('path');
const childProcess = require('child_process');
const {
  SESSION_TAB_SCHEME,
  SESSION_TAB_VIEW_TYPE,
  normalizeTabText,
  normalizeUriKey,
  buildNewSessionUriString,
  buildThreadUriString,
  parseSessionUri,
  readTabState,
  writeTabState,
  deleteTabState,
  findDraftTabEntryForThread
} = require('./antigravity-tab-state.cjs');
const {
  installContextWindowSupport,
  fetchContextWindowStatus,
  enqueueRemoteWebviewAction,
  getPendingApprovals,
  getProxyState,
  closeUpstreamSocketsForPort
} = require('./antigravity-context-window.cjs');
let excelPreview = null;
try {
  excelPreview = require('./excel-preview.cjs');
} catch {}

const BRIDGE_VERSION = '0.1.0';
const BRIDGE_MODULE_LOAD_ID = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const STATE_SYMBOL = Symbol.for('bhfirms.antigravityHub.bridgeState');
const TAB_ICON_FILES = {
  plain: 'antigravity-logo-color.svg',
  done: 'antigravity-logo-done.svg',
  pending: 'antigravity-logo-pending.svg'
};

function getPersistentHubStateFilePath() {
  if (process.env.THEO_PERSISTENT_HUB_STATE_PATH) {
    return process.env.THEO_PERSISTENT_HUB_STATE_PATH;
  }
  return path.join(os.homedir(), '.gemini', 'antigravity', 'bhf-persistent-hub.json');
}

function getPersistentHubLogFilePath() {
  return path.join(os.homedir(), '.gemini', 'antigravity', 'bhf-persistent-hub.log');
}

function normalizeRetiringHubsList(rawList) {
  if (!Array.isArray(rawList)) {
    return [];
  }
  const out = [];
  const seenPorts = new Set();
  for (const item of rawList) {
    if (!item || typeof item !== 'object') continue;
    const port = Number(item.port || 0);
    const csrfToken = String(item.csrfToken || '').trim();
    const cascadeIds = Array.isArray(item.cascadeIds)
      ? Array.from(
          new Set(item.cascadeIds.map((id) => String(id || '').trim()).filter(Boolean))
        )
      : [];
    if (port <= 0 || !csrfToken || cascadeIds.length === 0 || seenPorts.has(port)) {
      continue;
    }
    const initialCascadeIds = Array.isArray(item.initialCascadeIds)
      ? Array.from(
          new Set([
            ...item.initialCascadeIds.map((id) => String(id || '').trim()).filter(Boolean),
            ...cascadeIds
          ])
        )
      : cascadeIds.slice();
    seenPorts.add(port);
    out.push({
      pid: Number(item.pid || 0),
      port,
      csrfToken,
      serverUrl:
        typeof item.serverUrl === 'string' && item.serverUrl.trim()
          ? item.serverUrl.trim()
          : `http://127.0.0.1:${port}`,
      startedAt: Number(item.startedAt || Math.floor(Date.now() / 1000)),
      initialCascadeIds,
      cascadeIds
    });
  }
  return out;
}

function readPersistentHubState() {
  try {
    const filePath = getPersistentHubStateFilePath();
    if (!fs.existsSync(filePath)) {
      return null;
    }
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    if (
      parsed &&
      Number.isFinite(Number(parsed.port)) &&
      Number(parsed.port) > 0 &&
      typeof parsed.csrfToken === 'string' &&
      parsed.csrfToken.trim()
    ) {
      return {
        pid: Number(parsed.pid || 0),
        port: Number(parsed.port),
        csrfToken: parsed.csrfToken.trim(),
        serverUrl:
          typeof parsed.serverUrl === 'string' && parsed.serverUrl.trim()
            ? parsed.serverUrl.trim()
            : `http://127.0.0.1:${Number(parsed.port)}`,
        startedAt: Number(parsed.startedAt || 0),
        consoleHidden: Boolean(parsed.consoleHidden),
        retiringHubs: normalizeRetiringHubsList(parsed.retiringHubs)
      };
    }
  } catch {}
  return null;
}

function writePersistentHubState(data = {}) {
  try {
    const filePath = getPersistentHubStateFilePath();
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const existing = readPersistentHubState();
    const port = Number(data.port || 0);
    const csrfToken = String(data.csrfToken || '').trim();
    if (!port || !csrfToken) {
      return false;
    }
    const sameServer =
      existing &&
      existing.port === port &&
      existing.csrfToken === csrfToken &&
      (!data.pid || !existing.pid || Number(data.pid) === existing.pid);
    const rawRetiring =
      data.retiringHubs !== undefined
        ? data.retiringHubs
        : Array.isArray(globalThis[STATE_SYMBOL]?.__bhfRetiringHubs)
          ? globalThis[STATE_SYMBOL].__bhfRetiringHubs
          : existing?.retiringHubs || [];
    const retiringHubs = normalizeRetiringHubsList(rawRetiring).filter(
      (h) => h.port !== port
    );
    const payload = {
      pid: Number(data.pid || existing?.pid || 0),
      port,
      csrfToken,
      serverUrl:
        typeof data.serverUrl === 'string' && data.serverUrl.trim()
          ? data.serverUrl.trim()
          : `http://127.0.0.1:${port}`,
      startedAt:
        sameServer && existing.startedAt
          ? existing.startedAt
          : Number(data.startedAt || Math.floor(Date.now() / 1000)),
      consoleHidden:
        data.consoleHidden !== undefined
          ? Boolean(data.consoleHidden)
          : Boolean(sameServer && existing?.consoleHidden),
      retiringHubs,
      updatedAt: Math.floor(Date.now() / 1000)
    };
    fs.writeFileSync(filePath, JSON.stringify(payload, null, 2), 'utf8');
    return true;
  } catch {
    return false;
  }
}

function isPidAlive(pid) {
  const cleanPid = Number(pid || 0);
  if (!Number.isFinite(cleanPid) || cleanPid <= 0) {
    return false;
  }
  try {
    process.kill(cleanPid, 0);
    return true;
  } catch (err) {
    return Boolean(err && err.code === 'EPERM');
  }
}

let jobKillDisarmed = false;
function disarmExtensionHostJobKillOnClose(origSpawnFn) {
  if (jobKillDisarmed || process.platform !== 'win32') {
    return;
  }
  jobKillDisarmed = true;
  try {
    const pyExe = findBridgePythonExe();
    if (!pyExe) {
      return;
    }
    const pyCode = [
      'import ctypes',
      'from ctypes import wintypes',
      'k32 = ctypes.WinDLL("kernel32", use_last_error=True)',
      'k32.GetCurrentProcess.restype = wintypes.HANDLE',
      'k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]',
      'k32.OpenProcess.restype = wintypes.HANDLE',
      'k32.DuplicateHandle.argtypes = [wintypes.HANDLE, wintypes.HANDLE, wintypes.HANDLE, ctypes.POINTER(wintypes.HANDLE), wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]',
      'k32.DuplicateHandle.restype = wintypes.BOOL',
      'k32.CloseHandle.argtypes = [wintypes.HANDLE]',
      'class B(ctypes.Structure): _fields_ = [("a", ctypes.c_int64), ("b", ctypes.c_int64), ("f", wintypes.DWORD), ("c", ctypes.c_size_t), ("d", ctypes.c_size_t), ("e", wintypes.DWORD), ("g", ctypes.c_size_t), ("h", wintypes.DWORD), ("i", wintypes.DWORD)]',
      'class I(ctypes.Structure): _fields_ = [(f"r{x}", ctypes.c_uint64) for x in range(6)]',
      'class E(ctypes.Structure): _fields_ = [("b", B), ("io", I), ("p", ctypes.c_size_t), ("j", ctypes.c_size_t), ("pp", ctypes.c_size_t), ("pj", ctypes.c_size_t)]',
      `hp = k32.OpenProcess(0x0040, False, ${process.pid})`,
      'cur = k32.GetCurrentProcess()',
      'if hp:',
      '  for hv in range(4, 0x8000, 4):',
      '    dup = wintypes.HANDLE()',
      '    if k32.DuplicateHandle(hp, wintypes.HANDLE(hv), cur, ctypes.byref(dup), 0, False, 2):',
      '      info = E(); rl = wintypes.DWORD(0)',
      '      if k32.QueryInformationJobObject(dup, 9, ctypes.byref(info), ctypes.sizeof(info), ctypes.byref(rl)):',
      '        if info.b.f & 0x2000:',
      '          info.b.f &= ~0x2000',
      '          k32.SetInformationJobObject(dup, 9, ctypes.byref(info), ctypes.sizeof(info))',
      '      k32.CloseHandle(dup)',
      '  k32.CloseHandle(hp)'
    ].join('\n');
    const spawnFn = typeof origSpawnFn === 'function' ? origSpawnFn : childProcess.spawn;
    const helper = spawnFn.call(childProcess, pyExe, ['-c', pyCode], {
      detached: true,
      windowsHide: true,
      stdio: 'ignore'
    });
    helper?.unref?.();
  } catch {}
}

const THEO_DEFAULT_PROJECT_ID = 'c509f84b-f012-4596-9da5-8fec208449e8';

function ensureOutsideOfProjectConfig() {
  try {
    const configDir = path.join(os.homedir(), '.gemini', 'config');
    const projectsDir = path.join(configDir, 'projects');
    fs.mkdirSync(projectsDir, { recursive: true });
    const targetFile = path.join(projectsDir, 'outside-of-project.json');
    if (!fs.existsSync(targetFile)) {
      fs.writeFileSync(
        targetFile,
        JSON.stringify(
          { id: 'outside-of-project', name: 'Outside of Project', projectResources: {} },
          null,
          2
        ),
        'utf8'
      );
    }
    const theoDir = path.join(os.homedir(), 'OneDrive - BHFIRMS', 'System', 'System', 'THEO');
    if (fs.existsSync(theoDir)) {
      const theoProjFile = path.join(projectsDir, `${THEO_DEFAULT_PROJECT_ID}.json`);
      const posixUser = path.basename(os.homedir());
      const folderUri = `file:///c%3A/Users/${encodeURIComponent(posixUser)}/OneDrive%20-%20BHFIRMS/System/System/THEO`;
      let needsWrite = !fs.existsSync(theoProjFile);
      if (!needsWrite) {
        try {
          const parsed = JSON.parse(fs.readFileSync(theoProjFile, 'utf8'));
          const curUri = parsed?.projectResources?.resources?.[0]?.folderUri || '';
          if (parsed?.name !== 'THEO' || curUri !== folderUri) {
            needsWrite = true;
          }
        } catch {
          needsWrite = true;
        }
      }
      if (needsWrite) {
        fs.writeFileSync(
          theoProjFile,
          JSON.stringify(
            {
              id: THEO_DEFAULT_PROJECT_ID,
              name: 'THEO',
              projectResources: {
                resources: [{ folderUri }]
              }
            },
            null,
            2
          ),
          'utf8'
        );
      }
      const srcAgents = path.join(theoDir, 'AGENTS.md');
      const dstAgents = path.join(configDir, 'AGENTS.md');
      if (fs.existsSync(srcAgents)) {
        try {
          const srcBuf = fs.readFileSync(srcAgents);
          const dstBuf = fs.existsSync(dstAgents) ? fs.readFileSync(dstAgents) : null;
          if (!dstBuf || !srcBuf.equals(dstBuf)) {
            fs.writeFileSync(dstAgents, srcBuf);
          }
        } catch {}
      }
    }
  } catch {}
}

function readExpectedActiveAntigravityEmail(vaultDirOverride = '') {
  try {
    const claudeDir = String(
      vaultDirOverride ||
        process.env.THEO_ACCOUNTS_VAULT_DIR ||
        path.join(os.homedir(), '.claude')
    ).trim();
    const lockPath = path.join(claudeDir, '.theo-agy-login-lock.json');
    if (fs.existsSync(lockPath)) {
      try {
        const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
        if (lock && Number(lock.startedAt) > 0 && Date.now() - Number(lock.startedAt) < 6 * 60 * 1000) {
          return {
            stagingActive: true,
            expectedEmail: '',
            hasEnrolledAccount: false,
            enrolledEmails: []
          };
        }
      } catch {}
    }
    const vaultPath = path.join(claudeDir, '.theo-accounts-vault.json');
    if (!fs.existsSync(vaultPath)) {
      return {
        stagingActive: false,
        expectedEmail: '',
        hasEnrolledAccount: false,
        enrolledEmails: []
      };
    }
    const vault = JSON.parse(fs.readFileSync(vaultPath, 'utf8'));
    const agyList = Array.isArray(vault?.accounts?.antigravity) ? vault.accounts.antigravity : [];
    const enrolledEmails = [];
    for (const a of agyList) {
      const em = String(a?.email || '').trim().toLowerCase();
      if (em && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em) && !enrolledEmails.includes(em)) {
        enrolledEmails.push(em);
      }
    }
    const activeId = String(vault?.activeAccountId?.antigravity || '').trim();
    const activeEntry =
      agyList.find((a) => a && a.id === activeId && a.hasCredential !== false) ||
      agyList.find((a) => a && a.email && a.hasCredential !== false) ||
      null;
    const expectedEmail = String(activeEntry?.email || '')
      .trim()
      .toLowerCase();
    return {
      stagingActive: false,
      expectedEmail,
      hasEnrolledAccount: Boolean(expectedEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(expectedEmail)),
      enrolledEmails
    };
  } catch {
    return {
      stagingActive: false,
      expectedEmail: '',
      hasEnrolledAccount: false,
      enrolledEmails: []
    };
  }
}

function decodeJwtEmailForBridge(jwtStr) {
  if (typeof jwtStr !== 'string') return '';
  const parts = jwtStr.trim().split('.');
  if (parts.length < 2 || !parts[1]) return '';
  try {
    const obj = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    const em = String(obj?.email || '').trim().toLowerCase();
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em) ? em : '';
  } catch {
    return '';
  }
}

function extractStoredTokenEmailForBridge(parsed) {
  if (!parsed || typeof parsed !== 'object') return '';
  const candidates = [
    parsed.id_token_email,
    parsed.email,
    decodeJwtEmailForBridge(parsed.id_token),
    decodeJwtEmailForBridge(parsed.token?.id_token)
  ];
  for (const c of candidates) {
    const em = String(c || '').trim().toLowerCase();
    if (em && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) {
      return em;
    }
  }
  return '';
}

function hasValidStoredTokenForBridge(parsed) {
  return Boolean(
    parsed &&
      typeof parsed === 'object' &&
      parsed.token &&
      typeof parsed.token === 'object' &&
      typeof parsed.token.access_token === 'string' &&
      parsed.token.access_token.trim().length > 0
  );
}

const PY_BRIDGE_WINCRED_BATCH = `
import ctypes, json, sys
from ctypes import wintypes

CRED_TYPE_GENERIC = 1
CRED_PERSIST_LOCAL_MACHINE = 2

class CREDENTIALW(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD),
        ("Type", wintypes.DWORD),
        ("TargetName", wintypes.LPWSTR),
        ("Comment", wintypes.LPWSTR),
        ("LastWritten", wintypes.FILETIME),
        ("CredentialBlobSize", wintypes.DWORD),
        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
        ("Persist", wintypes.DWORD),
        ("AttributeCount", wintypes.DWORD),
        ("Attributes", ctypes.c_void_p),
        ("TargetAlias", wintypes.LPWSTR),
        ("UserName", wintypes.LPWSTR),
    ]

advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
CredReadW = advapi32.CredReadW
CredReadW.argtypes = [wintypes.LPWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.POINTER(CREDENTIALW))]
CredReadW.restype = wintypes.BOOL
CredWriteW = advapi32.CredWriteW
CredWriteW.argtypes = [ctypes.POINTER(CREDENTIALW), wintypes.DWORD]
CredWriteW.restype = wintypes.BOOL
CredFree = advapi32.CredFree
CredFree.argtypes = [ctypes.c_void_p]

req = json.loads(sys.stdin.read())
op = req.get("op")
if op == "read_many":
    out = {}
    for target in req.get("targets", []):
        pcred = ctypes.POINTER(CREDENTIALW)()
        if CredReadW(target, CRED_TYPE_GENERIC, 0, ctypes.byref(pcred)):
            c = pcred.contents
            raw = bytes(c.CredentialBlob[:c.CredentialBlobSize])
            CredFree(pcred)
            out[target] = raw.decode("utf-8", "replace")
        else:
            out[target] = None
    print(json.dumps({"ok": True, "values": out}))
elif op == "write_many":
    all_ok = True
    for item in req.get("writes", []):
        raw = str(item.get("value", "")).encode("utf-8")
        buf = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
        cred = CREDENTIALW()
        cred.Flags = 0
        cred.Type = CRED_TYPE_GENERIC
        cred.TargetName = item["target"]
        cred.CredentialBlobSize = len(raw)
        cred.CredentialBlob = ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))
        cred.Persist = CRED_PERSIST_LOCAL_MACHINE
        cred.UserName = item.get("userName") or "antigravity"
        if not CredWriteW(ctypes.byref(cred), 0):
            all_ok = False
    print(json.dumps({"ok": all_ok}))
else:
    print(json.dumps({"ok": False}))
`.trim();

function findBridgePythonExe() {
  const candidates = [
    'C:\\Python314\\python.exe',
    'C:\\Python313\\python.exe',
    'C:\\Python312\\python.exe',
    path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Python', 'Python314', 'python.exe'),
    path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Python', 'Python313', 'python.exe')
  ];
  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) return p;
    } catch {}
  }
  return '';
}

function runBridgeWinCredBatch(payloadObj, timeoutMs = 4000) {
  const pyExe = findBridgePythonExe();
  if (!pyExe) {
    return Promise.resolve({ ok: false });
  }
  return new Promise((resolve) => {
    let settled = false;
    const finish = (v) => {
      if (!settled) {
        settled = true;
        resolve(v);
      }
    };
    const origSpawn = childProcess.__bhfOrigSpawn || childProcess.spawn;
    let child;
    try {
      child = origSpawn.call(childProcess, pyExe, ['-c', PY_BRIDGE_WINCRED_BATCH], {
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe']
      });
    } catch {
      finish({ ok: false });
      return;
    }
    const timer = setTimeout(() => {
      try {
        child.kill();
      } catch {}
      finish({ ok: false, timeout: true });
    }, timeoutMs);
    const chunks = [];
    child.stdout.on('data', (c) => chunks.push(c));
    child.on('error', () => {
      clearTimeout(timer);
      finish({ ok: false });
    });
    child.on('close', () => {
      clearTimeout(timer);
      try {
        const text = Buffer.concat(chunks).toString('utf8').trim();
        finish(text ? JSON.parse(text) : { ok: false });
      } catch {
        finish({ ok: false });
      }
    });
    try {
      child.stdin.write(JSON.stringify(payloadObj));
      child.stdin.end();
    } catch {
      clearTimeout(timer);
      finish({ ok: false });
    }
  });
}

function createBridgeWinCredOps() {
  return {
    async readMany(targets) {
      const res = await runBridgeWinCredBatch({ op: 'read_many', targets });
      return res?.ok && res.values ? res.values : null;
    },
    async writeMany(writes) {
      if (!writes || writes.length === 0) return true;
      const res = await runBridgeWinCredBatch({ op: 'write_many', writes });
      return Boolean(res?.ok);
    }
  };
}

const PY_BRIDGE_WAKELOCK_SCRIPT = [
  'import ctypes, sys, threading',
  'k32 = ctypes.windll.kernel32',
  'k32.SetThreadExecutionState.argtypes = [ctypes.c_uint32]',
  'k32.SetThreadExecutionState.restype = ctypes.c_uint32',
  'k32.SetThreadExecutionState(0x80000003)',
  't = threading.Timer(3600.0, lambda: (k32.SetThreadExecutionState(0x80000000), sys.exit(0)))',
  't.daemon = True',
  't.start()',
  'try:',
  '    sys.stdin.read()',
  'finally:',
  '    k32.SetThreadExecutionState(0x80000000)'
].join('\n');

const PY_BRIDGE_POWER_GUARD_SCRIPT = [
  'import subprocess',
  'cmds = [',
  '  ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "238c9fa8-0aad-41ed-83f4-97be242c8f20", "9d7815a6-7ee4-497e-8888-515a05f02364", "0"],',
  '  ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "238c9fa8-0aad-41ed-83f4-97be242c8f20", "9d7815a6-7ee4-497e-8888-515a05f02364", "0"],',
  '  ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "238c9fa8-0aad-41ed-83f4-97be242c8f20", "29f6c1db-86da-48c5-9fdb-f2b67b1f44da", "0"],',
  '  ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "238c9fa8-0aad-41ed-83f4-97be242c8f20", "29f6c1db-86da-48c5-9fdb-f2b67b1f44da", "3600"],',
  '  ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "238c9fa8-0aad-41ed-83f4-97be242c8f20", "94ac6d29-73ce-41a6-809f-6363ba21b47e", "0"],',
  '  ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "238c9fa8-0aad-41ed-83f4-97be242c8f20", "94ac6d29-73ce-41a6-809f-6363ba21b47e", "0"],',
  '  ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "7516b95f-f776-4464-8c53-06167f40cc99", "3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e", "1800"],',
  '  ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "7516b95f-f776-4464-8c53-06167f40cc99", "3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e", "1800"],',
  '  ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "fea3413e-7e05-4911-9a71-700331f1c294", "f15576e8-98b7-4186-b944-eafa664402d9", "1"],',
  '  ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "fea3413e-7e05-4911-9a71-700331f1c294", "f15576e8-98b7-4186-b944-eafa664402d9", "1"],',
  '  ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "19cbb8fa-5279-450e-9fac-8a3d5fedd0c1", "12bbebe6-58d6-4636-95bb-3217ef867c1a", "0"],',
  '  ["powercfg", "/setdcvalueindex", "SCHEME_CURRENT", "19cbb8fa-5279-450e-9fac-8a3d5fedd0c1", "12bbebe6-58d6-4636-95bb-3217ef867c1a", "0"],',
  '  ["powercfg", "/setactive", "SCHEME_CURRENT"]',
  ']',
  'for c in cmds:',
  '    try:',
  '        subprocess.run(c, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3, creationflags=0x08000000)',
  '    except Exception:',
  '        pass'
].join('\n');

function ensureWindowsStandbyNetworkGuard(state = getBridgeState(), options = {}) {
  if (!state) return false;
  const now = Number(options.nowMs || Date.now());
  const minIntervalMs = Number.isFinite(Number(options.minIntervalMs))
    ? Number(options.minIntervalMs)
    : 600000;
  if (
    !options.force &&
    state.__bhfLastPowerGuardAt &&
    now - Number(state.__bhfLastPowerGuardAt) < minIntervalMs
  ) {
    return false;
  }
  const customRunner = options.powerGuardRunner || state.__bhfPowerGuardRunner || null;
  if (!customRunner) {
    if (
      process.platform !== 'win32' ||
      process.env.THEO_SMOKE_TEST === '1' ||
      process.env.THEO_DISABLE_POWER_GUARD === '1'
    ) {
      return false;
    }
  }
  state.__bhfLastPowerGuardAt = now;
  if (typeof customRunner === 'function') {
    try {
      customRunner(PY_BRIDGE_POWER_GUARD_SCRIPT);
      return true;
    } catch {
      return false;
    }
  }
  const pyExe = findBridgePythonExe();
  if (!pyExe) return false;
  try {
    const origSpawn = childProcess.__bhfOrigSpawn || childProcess.spawn;
    const child = origSpawn.call(childProcess, pyExe, ['-c', PY_BRIDGE_POWER_GUARD_SCRIPT], {
      windowsHide: true,
      stdio: 'ignore'
    });
    child.on('error', () => {});
    child.unref?.();
    return true;
  } catch {
    return false;
  }
}

function syncActiveTurnWakeLock(state = getBridgeState(), hasActiveTurns = false, options = {}) {
  if (!state) return { active: false };
  const now = Number(options.nowMs || Date.now());
  const customSpawn = options.spawnWakeLockProcess || state.__bhfSpawnWakeLockProcess || null;
  if (!customSpawn) {
    if (
      process.platform !== 'win32' ||
      process.env.THEO_SMOKE_TEST === '1' ||
      process.env.THEO_DISABLE_WAKELOCK === '1'
    ) {
      return { active: false, skipped: true };
    }
  }
  const existing = state.__bhfWakeLockChild || null;
  const isExistingAlive = Boolean(
    existing && existing.exitCode === null && !existing.killed && !existing.__bhfClosed
  );

  if (hasActiveTurns) {
    state.__bhfLastActiveTurnSeenAt = now;
    if (isExistingAlive && now - Number(state.__bhfWakeLockStartedAt || 0) < 3000000) {
      return { active: true, reused: true };
    }
    if (existing) {
      try {
        existing.__bhfClosed = true;
        existing.stdin?.end?.();
      } catch {}
      try {
        existing.kill?.();
      } catch {}
      state.__bhfWakeLockChild = null;
    }
    try {
      let child = null;
      if (typeof customSpawn === 'function') {
        child = customSpawn(PY_BRIDGE_WAKELOCK_SCRIPT);
      } else {
        const pyExe = findBridgePythonExe();
        if (!pyExe) return { active: false };
        const origSpawn = childProcess.__bhfOrigSpawn || childProcess.spawn;
        child = origSpawn.call(childProcess, pyExe, ['-c', PY_BRIDGE_WAKELOCK_SCRIPT], {
          windowsHide: true,
          stdio: ['pipe', 'ignore', 'ignore']
        });
      }
      if (!child) return { active: false };
      state.__bhfWakeLockChild = child;
      state.__bhfWakeLockStartedAt = now;
      const clearRef = () => {
        if (state.__bhfWakeLockChild === child) {
          state.__bhfWakeLockChild = null;
        }
      };
      child.on?.('exit', clearRef);
      child.on?.('close', clearRef);
      child.on?.('error', clearRef);
      child.unref?.();
      return { active: true, spawned: true };
    } catch {
      return { active: false };
    }
  }

  const releaseGraceMs = Number.isFinite(Number(options.releaseGraceMs))
    ? Number(options.releaseGraceMs)
    : 15000;
  if (
    !options.forceRelease &&
    isExistingAlive &&
    state.__bhfLastActiveTurnSeenAt &&
    now - Number(state.__bhfLastActiveTurnSeenAt) < releaseGraceMs
  ) {
    return { active: true, graceHold: true };
  }

  if (existing) {
    state.__bhfWakeLockChild = null;
    try {
      existing.__bhfClosed = true;
      existing.stdin?.end?.();
    } catch {}
    const killTimer = setTimeout(() => {
      try {
        if (existing.exitCode === null && !existing.killed) {
          existing.kill?.();
        }
      } catch {}
    }, 300);
    killTimer.unref?.();
    return { active: false, released: true };
  }
  return { active: false };
}

// Ensures Windows Credential Manager's shared `gemini:antigravity` slot matches THEO's active
// Antigravity account right before any `agy.exe --hub` spawns — while preserving any refreshed
// token written to `gemini:antigravity` by a concurrent standalone Antigravity.exe process!
async function ensureExpectedAntigravityKeyringSync(state = null, options = {}) {
  const vaultDir = options.vaultDir || state?.__bhfVaultDir || '';
  const authCtx = readExpectedActiveAntigravityEmail(vaultDir);
  if (authCtx.stagingActive || !authCtx.hasEnrolledAccount || !authCtx.expectedEmail) {
    return {
      ok: true,
      skipped: true,
      canSwitch: false,
      stagingActive: authCtx.stagingActive,
      expectedEmail: authCtx.expectedEmail || ''
    };
  }

  const customOps = options.keyringOps || state?.__bhfKeyringOps || null;
  if (!customOps && (process.platform !== 'win32' || process.env.THEO_DISABLE_KEYRING_SYNC === '1')) {
    return {
      ok: true,
      skipped: true,
      canSwitch: false,
      expectedEmail: authCtx.expectedEmail
    };
  }

  const expectedEmail = authCtx.expectedEmail;
  const allEmails = Array.from(new Set([expectedEmail, ...(authCtx.enrolledEmails || [])]));
  const liveTarget = 'gemini:antigravity';
  const expectedTarget = `theo-hub:antigravity:${expectedEmail}`;
  const targetsToRead = [liveTarget, ...allEmails.map((em) => `theo-hub:antigravity:${em}`)];

  try {
    let valuesMap = null;
    if (customOps) {
      valuesMap = {};
      for (const t of targetsToRead) {
        valuesMap[t] = (await customOps.read(t)) ?? null;
      }
    } else {
      valuesMap = await createBridgeWinCredOps().readMany(targetsToRead);
    }
    if (!valuesMap) {
      return { ok: false, canSwitch: false, expectedEmail };
    }

    let expectedParsed = null;
    try {
      expectedParsed = valuesMap[expectedTarget] ? JSON.parse(valuesMap[expectedTarget]) : null;
    } catch {}
    if (!hasValidStoredTokenForBridge(expectedParsed)) {
      return { ok: false, canSwitch: false, expectedEmail };
    }

    let liveParsed = null;
    try {
      liveParsed = valuesMap[liveTarget] ? JSON.parse(valuesMap[liveTarget]) : null;
    } catch {}

    const writes = [];
    let liveOwnerEmail = '';
    if (hasValidStoredTokenForBridge(liveParsed)) {
      liveOwnerEmail = extractStoredTokenEmailForBridge(liveParsed);
      const liveRefresh = String(liveParsed?.token?.refresh_token || '').trim();
      if (!liveOwnerEmail && liveRefresh) {
        for (const em of allEmails) {
          const slotRaw = valuesMap[`theo-hub:antigravity:${em}`];
          if (!slotRaw) continue;
          try {
            const slotObj = JSON.parse(slotRaw);
            if (String(slotObj?.token?.refresh_token || '').trim() === liveRefresh) {
              liveOwnerEmail = em;
              break;
            }
          } catch {}
        }
      }

      if (liveOwnerEmail === expectedEmail) {
        // Already holds expectedEmail! If Go refreshed its access_token or stripped id_token_email, sync back to vault.
        let changedLive = false;
        if (String(liveParsed.id_token_email || '').trim().toLowerCase() !== expectedEmail) {
          liveParsed.id_token_email = expectedEmail;
          changedLive = true;
        }
        const stampedRaw = JSON.stringify(liveParsed);
        if (
          liveParsed.token.access_token !== expectedParsed.token.access_token ||
          stampedRaw !== valuesMap[expectedTarget]
        ) {
          writes.push({ target: expectedTarget, userName: expectedEmail, value: stampedRaw });
        }
        if (changedLive) {
          writes.push({ target: liveTarget, userName: 'antigravity', value: stampedRaw });
        }
        if (writes.length > 0) {
          if (customOps) {
            for (const w of writes) await customOps.write(w.target, w.value, w.userName);
          } else {
            await createBridgeWinCredOps().writeMany(writes);
          }
        }
        if (!customOps) {
          try {
            const jetskiFile = path.join(os.homedir(), '.gemini', 'jetski-standalone-oauth-token');
            if (fs.existsSync(path.dirname(jetskiFile))) {
              fs.writeFileSync(jetskiFile, stampedRaw, { encoding: 'utf8', mode: 0o600 });
            }
          } catch {}
        }
        return {
          ok: true,
          canSwitch: true,
          synced: false,
          expectedEmail,
          liveOwnerEmail
        };
      }

      // Live slot belongs to a different enrolled account (e.g. standalone Antigravity.exe refreshed hbdeir16):
      // back up its fresh token into theo-hub:antigravity:<liveOwnerEmail> BEFORE restoring expectedEmail!
      if (liveOwnerEmail && allEmails.includes(liveOwnerEmail)) {
        liveParsed.id_token_email = liveOwnerEmail;
        const backupRaw = JSON.stringify(liveParsed);
        if (backupRaw !== valuesMap[`theo-hub:antigravity:${liveOwnerEmail}`]) {
          writes.push({
            target: `theo-hub:antigravity:${liveOwnerEmail}`,
            userName: liveOwnerEmail,
            value: backupRaw
          });
        }
      }
    }

    expectedParsed.id_token_email = expectedEmail;
    const expectedRawToWrite = JSON.stringify(expectedParsed);
    writes.push({
      target: liveTarget,
      userName: 'antigravity',
      value: expectedRawToWrite
    });

    let wroteOk = true;
    if (customOps) {
      for (const w of writes) {
        const r = await customOps.write(w.target, w.value, w.userName);
        if (r === false) wroteOk = false;
      }
    } else {
      wroteOk = await createBridgeWinCredOps().writeMany(writes);
      if (wroteOk) {
        try {
          const jetskiFile = path.join(os.homedir(), '.gemini', 'jetski-standalone-oauth-token');
          if (fs.existsSync(path.dirname(jetskiFile))) {
            fs.writeFileSync(jetskiFile, expectedRawToWrite, { encoding: 'utf8', mode: 0o600 });
          }
        } catch {}
      }
    }

    return {
      ok: wroteOk,
      canSwitch: wroteOk,
      synced: wroteOk,
      expectedEmail,
      previousEmail: liveOwnerEmail
    };
  } catch {
    return { ok: false, canSwitch: false, expectedEmail };
  }
}

function probeTcpLoopbackAlive(port, timeoutMs = 1200) {
  const cleanPort = Number(port || 0);
  if (!Number.isFinite(cleanPort) || cleanPort <= 0 || cleanPort > 65535) {
    return Promise.resolve(false);
  }
  return new Promise((resolve) => {
    let settled = false;
    const sock = net.connect(cleanPort, '127.0.0.1');
    const done = (ok) => {
      if (settled) return;
      settled = true;
      try {
        sock.destroy();
      } catch {}
      resolve(Boolean(ok));
    };
    sock.setTimeout(timeoutMs);
    sock.on('connect', () => done(true));
    sock.on('timeout', () => done(false));
    sock.on('error', () => done(false));
  });
}

function probePersistentHubAuthDetailed(port, csrfToken, timeoutMs = 2500, options = {}) {
  return new Promise((resolve) => {
    const checkEmailMatch = options?.checkEmailMatch !== false;
    const authCtx =
      options && typeof options.expectedEmail === 'string'
        ? {
            stagingActive: Boolean(options.stagingActive),
            expectedEmail: options.expectedEmail.trim().toLowerCase(),
            hasEnrolledAccount: Boolean(options.hasEnrolledAccount ?? options.expectedEmail)
          }
        : readExpectedActiveAntigravityEmail(options?.vaultDir || '');

    if (authCtx.stagingActive || !authCtx.hasEnrolledAccount) {
      resolve({ ok: true });
      return;
    }

    const payload = '{}';
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: Number(port),
        path: '/exa.language_server_pb.LanguageServerService/GetUserStatus',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': String(csrfToken || '').trim(),
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const status = res.statusCode || 0;
          const text = Buffer.concat(chunks).toString('utf8');
          // Minimal test mocks that only mount /Heartbeat and / return 404 on GetUserStatus
          if (status === 404) {
            resolve({ ok: true, status });
            return;
          }
          if (status >= 200 && status < 300) {
            let liveEmail = '';
            try {
              const parsed = text ? JSON.parse(text) : {};
              liveEmail = String(parsed?.userStatus?.email || parsed?.email || '')
                .trim()
                .toLowerCase();
            } catch {}
            if (
              checkEmailMatch &&
              authCtx.expectedEmail &&
              liveEmail &&
              /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(liveEmail) &&
              liveEmail !== authCtx.expectedEmail
            ) {
              resolve({ ok: false, status, emailMismatch: true, liveEmail });
              return;
            }
            resolve({ ok: true, status, liveEmail });
            return;
          }
          if (
            status === 401 ||
            /not logged into antigravity|code"\s*:\s*"unauthenticated"/i.test(text)
          ) {
            resolve({ ok: false, status, unauthenticated: true });
            return;
          }
          resolve({ ok: true, status });
        });
      }
    );
    req.on('timeout', () => {
      try {
        req.destroy();
      } catch {}
      resolve({ ok: true, authTimedOut: true });
    });
    req.on('error', (err) => {
      const code = String(err?.code || '');
      resolve({
        ok: false,
        connectionRefused: code === 'ECONNREFUSED' || /ECONNREFUSED/i.test(String(err?.message || '')),
        error: String(err?.message || code || 'error')
      });
    });
    req.write(payload);
    req.end();
  });
}

function probePersistentHubAuth(port, csrfToken, timeoutMs = 2500, options = {}) {
  return probePersistentHubAuthDetailed(port, csrfToken, timeoutMs, options).then(
    (r) => Boolean(r?.ok),
    () => false
  );
}

function ensureAntigravityTelemetryDisabled(port, csrfToken, timeoutMs = 2500) {
  return new Promise((resolve) => {
    const cleanPort = Number(port || 0);
    const cleanToken = String(csrfToken || '').trim();
    if (!cleanPort || !cleanToken) {
      resolve(false);
      return;
    }
    const payload = JSON.stringify({
      userSettings: {
        telemetryEnabled: false,
        marketingEmailsEnabled: false
      }
    });
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: cleanPort,
        path: '/exa.language_server_pb.LanguageServerService/SetUserInfo',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': cleanToken,
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        res.resume();
        resolve(Boolean(res.statusCode && res.statusCode >= 200 && res.statusCode < 300));
      }
    );
    req.on('timeout', () => {
      try {
        req.destroy();
      } catch {}
      resolve(false);
    });
    req.on('error', () => resolve(false));
    req.write(payload);
    req.end();
  });
}

function postHubRpcJson(port, csrfToken, method, bodyObj = {}, timeoutMs = 2500) {
  return new Promise((resolve) => {
    const cleanPort = Number(port || 0);
    const cleanToken = String(csrfToken || '').trim();
    if (!cleanPort || !cleanToken || !method) {
      resolve({ ok: false, status: 0, json: null });
      return;
    }
    const payload = JSON.stringify(bodyObj || {});
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: cleanPort,
        path: `/exa.language_server_pb.LanguageServerService/${method}`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': cleanToken,
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const status = res.statusCode || 0;
          const contentType = String(res.headers['content-type'] || '').toLowerCase();
          const text = Buffer.concat(chunks).toString('utf8').trim();
          if (status < 200 || status >= 300) {
            resolve({ ok: false, status, json: null, text });
            return;
          }
          if (contentType && !contentType.includes('json') && text.startsWith('<')) {
            resolve({ ok: false, status, json: null, nonJson: true });
            return;
          }
          try {
            const parsed = text ? JSON.parse(text) : {};
            if (!parsed || typeof parsed !== 'object') {
              resolve({ ok: false, status, json: null, nonJson: true });
              return;
            }
            resolve({ ok: true, status, json: parsed });
          } catch {
            resolve({ ok: false, status, json: null, nonJson: true });
          }
        });
      }
    );
    req.on('timeout', () => {
      try {
        req.destroy();
      } catch {}
      resolve({ ok: false, status: 0, timedOut: true, json: null });
    });
    req.on('error', (err) => {
      resolve({ ok: false, status: 0, error: String(err?.message || err || ''), json: null });
    });
    req.write(payload);
    req.end();
  });
}

async function tryHotReloadHubAuthInPlace(
  state,
  port,
  csrfToken,
  expectedEmail,
  timeoutMs = 2500
) {
  const cleanPort = Number(port || 0);
  const cleanToken = String(csrfToken || '').trim();
  const cleanExpected = String(expectedEmail || '').trim().toLowerCase();
  if (
    !cleanPort ||
    !cleanToken ||
    !cleanExpected ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanExpected)
  ) {
    return { ok: false, reason: 'invalid_args' };
  }

  // Trigger agy.exe's Go authclient.syncWithStoredToken(gemini:antigravity) via HasAuthToken + GetAuthStatus
  const hasTokRes = await postHubRpcJson(cleanPort, cleanToken, 'HasAuthToken', {}, timeoutMs);
  if (!hasTokRes.ok) {
    return { ok: false, reason: 'has_auth_token_unsupported' };
  }
  const authStatusRes = await postHubRpcJson(cleanPort, cleanToken, 'GetAuthStatus', {}, timeoutMs);
  if (!authStatusRes.ok || authStatusRes.json?.authResult?.hasValidAuth !== true) {
    return { ok: false, reason: 'get_auth_status_not_valid' };
  }
  await postHubRpcJson(cleanPort, cleanToken, 'FetchUserInfo', {}, Math.min(2000, timeoutMs)).catch(
    () => null
  );

  for (let attempt = 0; attempt < 3; attempt += 1) {
    if (attempt > 0) {
      await new Promise((r) => setTimeout(r, 180 * attempt));
      await postHubRpcJson(cleanPort, cleanToken, 'GetAuthStatus', {}, timeoutMs).catch(() => null);
    }
    const probe = await probePersistentHubAuthDetailed(cleanPort, cleanToken, timeoutMs, {
      checkEmailMatch: true,
      expectedEmail: cleanExpected,
      hasEnrolledAccount: true
    });
    if (probe?.ok && probe.liveEmail === cleanExpected) {
      postHubRpcJson(
        cleanPort,
        cleanToken,
        'RetrieveUserQuotaSummary',
        { forceRefresh: true },
        Math.min(3000, timeoutMs + 500)
      ).catch(() => {});
      ensureAntigravityTelemetryDisabled(cleanPort, cleanToken).catch(() => {});

      const authPayload = authStatusRes.json?.authResult || {
        isGcpTos: false,
        project: '',
        location: '',
        grantedScopes: []
      };
      if (state?.entriesByUriKey instanceof Map) {
        for (const entry of state.entriesByUriKey.values()) {
          try {
            const refreshFn = entry?.instance?.api?.refreshAuthStatus;
            if (typeof refreshFn === 'function') {
              Promise.resolve(refreshFn.call(entry.instance.api, {})).catch(() => {});
            }
          } catch {}
        }
      }
      try {
        enqueueRemoteWebviewAction({
          id: '*',
          kind: 'refresh_auth',
          payload: authPayload
        });
      } catch {}

      return {
        ok: true,
        inPlace: true,
        port: cleanPort,
        liveEmail: probe.liveEmail
      };
    }
  }

  return { ok: false, reason: 'email_did_not_converge' };
}

function probePersistentHubDetailed(port, csrfToken, timeoutMs = 3500, options = {}) {
  return new Promise((resolve) => {
    const cleanPort = Number(port || 0);
    const cleanToken = String(csrfToken || '').trim();
    if (!cleanPort || !cleanToken) {
      resolve({ ok: false, invalidArgs: true });
      return;
    }
    const payload = '{}';
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: cleanPort,
        path: '/exa.language_server_pb.LanguageServerService/Heartbeat',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': cleanToken,
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        res.resume();
        const hbStatus = res.statusCode || 0;
        if (!hbStatus || hbStatus < 200 || hbStatus >= 300) {
          resolve({ ok: false, status: hbStatus });
          return;
        }
        // Also verify GET / returns 200 OK (if agy.exe --hub was launched without AGY_ENABLE_HUB=1,
        // Heartbeat returns 200 but GET / and /main.js return 404 Not Found, breaking all webviews).
        const uiReq = http.request(
          {
            hostname: '127.0.0.1',
            port: cleanPort,
            path: '/',
            method: 'GET',
            timeout: timeoutMs
          },
          (uiRes) => {
            uiRes.resume();
            const uiStatus = uiRes.statusCode || 0;
            const webOk = Boolean(uiStatus >= 200 && uiStatus < 300);
            if (!webOk) {
              resolve({ ok: false, status: uiStatus, missingWebUi: true });
              return;
            }
            if (options && options.checkAuth === false) {
              resolve({ ok: true, status: 200 });
              return;
            }
            probePersistentHubAuthDetailed(cleanPort, cleanToken, timeoutMs, options).then(
              (authRes) => resolve(authRes && typeof authRes === 'object' ? authRes : { ok: Boolean(authRes) }),
              () => resolve({ ok: true })
            );
          }
        );
        uiReq.on('timeout', () => {
          try {
            uiReq.destroy();
          } catch {}
          resolve({ ok: false, timedOut: true });
        });
        uiReq.on('error', (err) => {
          const code = String(err?.code || '');
          resolve({
            ok: false,
            connectionRefused: code === 'ECONNREFUSED' || /ECONNREFUSED/i.test(String(err?.message || '')),
            error: String(err?.message || code || 'error')
          });
        });
        uiReq.end();
      }
    );
    req.on('timeout', () => {
      try {
        req.destroy();
      } catch {}
      resolve({ ok: false, timedOut: true });
    });
    req.on('error', (err) => {
      const code = String(err?.code || '');
      resolve({
        ok: false,
        connectionRefused: code === 'ECONNREFUSED' || /ECONNREFUSED/i.test(String(err?.message || '')),
        error: String(err?.message || code || 'error')
      });
    });
    req.write(payload);
    req.end();
  });
}

function probePersistentHub(port, csrfToken, timeoutMs = 3500, options = {}) {
  return probePersistentHubDetailed(port, csrfToken, timeoutMs, options).then(
    (r) => Boolean(r?.ok),
    () => false
  );
}

async function isHubBusyButAlive(port, pid = 0, probeResult = null) {
  if (!port || Number(port) <= 0) {
    return false;
  }
  if (
    probeResult &&
    (probeResult.connectionRefused ||
      probeResult.missingWebUi ||
      probeResult.unauthenticated ||
      probeResult.emailMismatch)
  ) {
    return false;
  }
  const tcpOpen = await probeTcpLoopbackAlive(port, 1200);
  if (!tcpOpen) {
    return false;
  }
  const cleanPid = Number(pid || 0);
  if (cleanPid > 0 && cleanPid !== process.pid && !isPidAlive(cleanPid)) {
    return false;
  }
  return Boolean(!probeResult || probeResult.timedOut);
}

async function probePersistentHubWithRetry(
  port,
  csrfToken,
  attempts = 3,
  timeoutMs = 3500,
  options = {}
) {
  for (let i = 0; i < attempts; i += 1) {
    const ok = await probePersistentHub(port, csrfToken, timeoutMs, options);
    if (ok) {
      return true;
    }
    if (i + 1 < attempts) {
      await new Promise((r) => setTimeout(r, 250));
    }
  }
  return false;
}

// A saved agy --hub may only be reused when it actually answers Heartbeat AND serves GET / (200 OK).
// A live pid is not evidence: after a reboot Windows recycles pids (2026-10-20: saved pid 21540 was
// chrome.exe), and a headless agy.exe launched without AGY_ENABLE_HUB=1 returns 404 on GET /.
function decideSavedHubReuse({ savedHealthy = false, pidAlive = false } = {}) {
  if (savedHealthy) {
    return { reuse: true, reason: 'hub answered Heartbeat and Web UI is mounted' };
  }
  return {
    reuse: false,
    reason: pidAlive
      ? 'port or Web UI not answering although pid is alive (pid recycled after reboot or missing AGY_ENABLE_HUB=1)'
      : 'pid gone and port not answering'
  };
}

function reapBrokenAgyHubPid(targetPid) {
  if (process.env.THEO_DISABLE_HUB_PROCESS_REAP === '1') {
    return Promise.resolve(false);
  }
  const cleanPid = Number(targetPid || 0);
  if (!cleanPid || cleanPid <= 0 || cleanPid === process.pid) {
    return Promise.resolve(false);
  }
  if (!isPidAlive(cleanPid)) {
    return Promise.resolve(true);
  }
  if (process.platform !== 'win32') {
    try {
      process.kill(cleanPid, 'SIGTERM');
    } catch {}
    return Promise.resolve(!isPidAlive(cleanPid));
  }
  return new Promise((resolve) => {
    try {
      childProcess.execFile(
        'tasklist.exe',
        ['/FI', `PID eq ${cleanPid}`, '/FO', 'CSV', '/NH'],
        { timeout: 2500, windowsHide: true },
        (_err, stdout) => {
          const out = String(stdout || '').toLowerCase();
          if (!out.includes('"agy.exe"')) {
            resolve(false);
            return;
          }
          try {
            process.kill(cleanPid);
          } catch {}
          const waitUntilDead = (deadlineMs, usedTaskkill) => {
            if (!isPidAlive(cleanPid)) {
              resolve(true);
              return;
            }
            if (!usedTaskkill) {
              childProcess.execFile(
                'taskkill.exe',
                ['/F', '/T', '/PID', String(cleanPid)],
                { timeout: 3000, windowsHide: true },
                () => waitUntilDead(deadlineMs, true)
              );
              return;
            }
            if (Date.now() >= deadlineMs) {
              resolve(!isPidAlive(cleanPid));
              return;
            }
            setTimeout(() => waitUntilDead(deadlineMs, true), 50);
          };
          waitUntilDead(Date.now() + 2500, false);
        }
      );
    } catch {
      resolve(false);
    }
  });
}

function reapDuplicateAgyHubProcesses(keepPidOrList) {
  if (process.env.THEO_DISABLE_HUB_PROCESS_REAP === '1') return Promise.resolve();
  if (process.platform !== 'win32') return Promise.resolve();
  const rawList = Array.isArray(keepPidOrList) ? keepPidOrList : [keepPidOrList];
  if (rawList.some((p) => Number(p) < 0)) return Promise.resolve();
  const keepSet = new Set(
    rawList
      .map((p) => Number(p || 0))
      .filter((p) => Number.isFinite(p) && p > 0)
  );
  try {
    const retiring = globalThis[STATE_SYMBOL]?.__bhfRetiringHubs;
    if (Array.isArray(retiring)) {
      for (const h of retiring) {
        const rPid = Number(h?.pid || 0);
        if (rPid > 0) keepSet.add(rPid);
      }
    }
  } catch {}
  return new Promise((resolve) => {
    try {
      const keepClause =
        keepSet.size > 0
          ? Array.from(keepSet)
              .map((pid) => `$_.ProcessId -ne ${pid}`)
              .join(' -and ') + ' -and '
          : '';
      const psCmd = `Get-CimInstance Win32_Process -Filter "Name='agy.exe'" | Where-Object { ${keepClause}$_.CommandLine -like '*--hub*' -and $_.CommandLine -notlike '*antigravity-auth-staging*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
      childProcess.execFile(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psCmd],
        { timeout: 6000, windowsHide: true },
        () => resolve()
      );
    } catch {
      resolve();
    }
  });
}

function getProtectedHubPids(state, primaryPid = 0) {
  const pids = [];
  if (Number(primaryPid) > 0) {
    pids.push(Number(primaryPid));
  }
  const retiring = Array.isArray(state?.__bhfRetiringHubs) ? state.__bhfRetiringHubs : [];
  for (const h of retiring) {
    if (Number(h?.pid) > 0) {
      pids.push(Number(h.pid));
    }
  }
  return pids;
}

function detachServerProcessListeners(proc) {
  if (!proc || typeof proc !== 'object') {
    return;
  }
  try {
    proc.removeAllListeners?.('exit');
    proc.removeAllListeners?.('close');
    proc.removeAllListeners?.('error');
    proc.on?.('error', () => {});
  } catch {}
}

function silenceServerManagerCrashSignals(serverManager) {
  if (!serverManager || typeof serverManager !== 'object') {
    return;
  }
  detachServerProcessListeners(serverManager.serverProcess);
  try {
    serverManager.stopHeartbeat?.();
  } catch {}
  try {
    serverManager.cancelPendingRecovery?.();
  } catch {}
}

function clearUpstreamServerState(
  state,
  { mintFreshCsrf = false, preserveProxyUpstream = false, forceClearInFlight = false } = {}
) {
  if (state?.serverManager) {
    silenceServerManagerCrashSignals(state.serverManager);
    state.serverManager.port = undefined;
    state.serverManager.serverUrl = undefined;
    state.serverManager.serverProcess = undefined;
    if (forceClearInFlight) {
      state.serverManager.startingPromise = undefined;
      state.serverManager.__bhfStartPromise = null;
    }
    state.serverManager.isStopping = false;
    state.serverManager.lastStartupError = undefined;
    if (mintFreshCsrf) {
      state.serverManager.csrfToken = crypto.randomUUID();
    }
  }
  if (!preserveProxyUpstream) {
    try {
      const proxySt = getProxyState();
      if (proxySt) {
        proxySt.upstreamPort = 0;
        proxySt.upstreamOrigin = '';
        proxySt.csrfToken = '';
        proxySt.mainJsCache = null;
        proxySt.mainJsInFlight = null;
      }
    } catch {}
    try {
      state?.renderer?.refresh?.();
    } catch {}
    try {
      if (state?.renderer) {
        state.renderer.cachedServerInfo = undefined;
        state.renderer.serverInfo = undefined;
      }
    } catch {}
  }
}

function syncRendererAndProxyServerUrl(state, serverUrl, port, csrfToken) {
  const cleanPort = Number(port || 0);
  const cleanToken = String(csrfToken || '').trim();
  const cleanUrl = String(serverUrl || (cleanPort > 0 ? `http://127.0.0.1:${cleanPort}` : '')).replace(/\/$/, '');
  if (!cleanUrl) {
    return;
  }
  if (state?.serverManager) {
    if (cleanPort > 0) state.serverManager.port = cleanPort;
    if (cleanToken) state.serverManager.csrfToken = cleanToken;
    state.serverManager.serverUrl = cleanUrl;
  }
  try {
    const proxySt = getProxyState();
    if (proxySt) {
      if (proxySt.upstreamOrigin && proxySt.upstreamOrigin !== cleanUrl) {
        proxySt.mainJsCache = null;
        proxySt.mainJsInFlight = null;
      }
      proxySt.upstreamHost = '127.0.0.1';
      if (cleanPort > 0) proxySt.upstreamPort = cleanPort;
      proxySt.upstreamOrigin = cleanUrl;
      if (cleanToken) proxySt.csrfToken = cleanToken;
      if (Array.isArray(state?.__bhfRetiringHubs)) {
        proxySt.retiringHubs = normalizeRetiringHubsList(state.__bhfRetiringHubs).filter(
          (h) => h.port !== cleanPort
        );
      }
    }
  } catch {}
  try {
    if (state?.renderer) {
      const info = { effectiveUrl: cleanUrl, humanReadable: 'Installed Antigravity' };
      state.renderer.cachedServerInfo = info;
      state.renderer.serverInfo = Promise.resolve(info);
    }
  } catch {}
}

function installPersistentServerSupport(state) {
  ensureOutsideOfProjectConfig();
  disarmExtensionHostJobKillOnClose(childProcess.spawn);
  if (state && !Array.isArray(state.__bhfRetiringHubs)) {
    const savedInit = readPersistentHubState();
    state.__bhfRetiringHubs = normalizeRetiringHubsList(savedInit?.retiringHubs || []);
    if (state.__bhfRetiringHubs.length > 0) {
      try {
        const proxySt = getProxyState();
        if (proxySt) {
          proxySt.retiringHubs = state.__bhfRetiringHubs.slice();
        }
      } catch {}
      ensureRetiringHubsMonitor(state);
    }
  }
  if (!childProcess.__bhfPersistentHubSpawnPatched && typeof childProcess.spawn === 'function') {
    childProcess.__bhfPersistentHubSpawnPatched = true;
    const origSpawn = childProcess.spawn;
    childProcess.__bhfOrigSpawn = origSpawn;
    childProcess.spawn = function (command, args, options) {
      const isEphemeralAuthHub =
        (options && options.env && options.env.THEO_EPHEMERAL_LOGIN_HUB === '1') ||
        (Array.isArray(args) && args.some((a) => String(a || '').includes('antigravity-auth-staging')));
      const hasHubFlag =
        Array.isArray(args) &&
        args.some((a) => a === '--hub' || String(a || '').startsWith('--hub='));
      if (hasHubFlag && !isEphemeralAuthHub) {
        ensureOutsideOfProjectConfig();
        disarmExtensionHostJobKillOnClose(origSpawn);
        let logFd = 'ignore';
        try {
          const logPath = getPersistentHubLogFilePath();
          fs.mkdirSync(path.dirname(logPath), { recursive: true });
          logFd = fs.openSync(logPath, 'a');
        } catch {
          logFd = 'ignore';
        }
        // IMPORTANT: Do NOT set detached: true on Windows! In libuv, detached: true sets
        // DETACHED_PROCESS which causes Windows to ignore CREATE_NO_WINDOW (windowsHide: true),
        // leaving agy.exe without a headless conhost.exe 0x4 so every child powershell.exe pops up a window.
        // Always ensure AGY_ENABLE_HUB=1 and ANTIGRAVITY_VSCODE_HOST=1 are present in env so the
        // embedded Jetski Web UI (/ and /main.js) is mounted on the hub port.
        const baseEnv =
          options && options.env && typeof options.env === 'object' ? options.env : process.env;
        const nextOptions = {
          ...(options && typeof options === 'object' ? options : {}),
          env: {
            ...baseEnv,
            AGY_ENABLE_HUB: '1',
            ANTIGRAVITY_VSCODE_HOST: '1'
          },
          detached: false,
          windowsHide: true,
          stdio: ['ignore', logFd, logFd]
        };
        const child = origSpawn.call(this, command, args, nextOptions);
        if (typeof logFd === 'number') {
          try {
            fs.closeSync(logFd);
          } catch {}
        }
        try {
          child?.unref?.();
        } catch {}
        return child;
      }
      return origSpawn.apply(this, arguments);
    };
  }

  const serverManager = state?.serverManager || state?.apiImpl?.hostDiagnosticsProvider || null;
  if (!serverManager) {
    return;
  }
  state.serverManager = serverManager;

  const proto = Object.getPrototypeOf(serverManager);
  if (!serverManager.__bhfOrigStart) {
    const rawStart =
      serverManager.__bhfPersistentHubPatched && typeof proto?.start === 'function'
        ? proto.start
        : serverManager.start;
    if (typeof rawStart === 'function') {
      serverManager.__bhfOrigStart = rawStart.bind(serverManager);
    }
  }
  if (!serverManager.__bhfOrigStop) {
    const rawStop =
      serverManager.__bhfPersistentHubPatched && typeof proto?.stop === 'function'
        ? proto.stop
        : serverManager.stop;
    if (typeof rawStop === 'function') {
      serverManager.__bhfOrigStop = rawStop.bind(serverManager);
    }
  }
  if (!serverManager.__bhfOrigProbeHealth) {
    const rawProbeHealth =
      serverManager.__bhfPersistentHubPatched && typeof proto?.probeHealth === 'function'
        ? proto.probeHealth
        : serverManager.probeHealth;
    if (typeof rawProbeHealth === 'function') {
      serverManager.__bhfOrigProbeHealth = rawProbeHealth.bind(serverManager);
    }
  }

  const origStart = serverManager.__bhfOrigStart || null;
  const origStop = serverManager.__bhfOrigStop || null;
  const origProbeHealth = serverManager.__bhfOrigProbeHealth || null;
  serverManager.__bhfPersistentHubPatched = true;

  if (origProbeHealth) {
    serverManager.__bhfProbeHealthImpl = async function (targetUrl, timeoutMs) {
      const effectiveTimeoutMs = Math.max(8000, Number(timeoutMs) || 8000);
      const res = await origProbeHealth(targetUrl, effectiveTimeoutMs);
      if (res && res.healthy) {
        this.__bhfHeartbeatBusyShieldCount = 0;
        return res;
      }
      if (res && res.failureReason === 'probe_timeout') {
        let parsedPort = Number(this.port || 0);
        if (!parsedPort && typeof targetUrl === 'string') {
          try {
            parsedPort = Number(new URL(targetUrl).port || 0);
          } catch {}
        }
        const livePid = Number(this.serverProcess?.pid || readPersistentHubState()?.pid || 0);
        const busyAlive = await isHubBusyButAlive(parsedPort, livePid, { timedOut: true });
        const shieldCount = Number(this.__bhfHeartbeatBusyShieldCount || 0);
        if (busyAlive && (shieldCount < 8 || findActiveCascadesFromDiskTranscripts().length > 0)) {
          this.__bhfHeartbeatBusyShieldCount = shieldCount + 1;
          return {
            healthy: true,
            status: 200,
            instanceId: this.heartbeatInstanceId
          };
        }
      }
      return res;
    };
    serverManager.probeHealth = function (targetUrl, timeoutMs) {
      return this.__bhfProbeHealthImpl(targetUrl, timeoutMs);
    };
  }

  serverManager.__bhfStopImpl = async function (options = {}) {
    if ((options && options.forceKill) || (this.startingPromise && !this.serverUrl)) {
      if (origStop) {
        return origStop();
      }
      return undefined;
    }
    try {
      this.serverProcess?.unref?.();
    } catch {}
    return undefined;
  };

  serverManager.__bhfStartImpl = async function (a, b, c, d) {
    if (this.__bhfStartPromise) {
      return this.__bhfStartPromise;
    }
    if (this.startingPromise) {
      return this.startingPromise;
    }
    const runPromise = (async () => {
      let replacedPriorPort = 0;
      if (this.serverUrl && this.port && this.csrfToken) {
        const savedCheck = readPersistentHubState();
        // If bhf-persistent-hub.json points to a DIFFERENT healthy hub than this.port, switch to it!
        if (
          savedCheck &&
          savedCheck.port &&
          savedCheck.csrfToken &&
          Number(savedCheck.port) !== Number(this.port)
        ) {
          const altHealthy = await probePersistentHubWithRetry(
            savedCheck.port,
            savedCheck.csrfToken,
            2,
            3000
          );
          if (altHealthy) {
            this.csrfToken = savedCheck.csrfToken;
            this.port = savedCheck.port;
            this.serverUrl = savedCheck.serverUrl || `http://127.0.0.1:${savedCheck.port}`;
            this.isStopping = false;
            this.lastStartupError = undefined;
            syncRendererAndProxyServerUrl(state, this.serverUrl, this.port, this.csrfToken);
            ensureAntigravityTelemetryDisabled(this.port, this.csrfToken).catch(() => {});
            return this.serverUrl;
          }
        }
        const curPid = Number(this.serverProcess?.pid || savedCheck?.pid || 0);
        let curProbe = await probePersistentHubDetailed(this.port, this.csrfToken, 3500);
        if (!curProbe.ok && curProbe.timedOut) {
          await new Promise((r) => setTimeout(r, 250));
          curProbe = await probePersistentHubDetailed(this.port, this.csrfToken, 3500);
        }
        const currentBusyAlive =
          !curProbe.ok && curProbe.timedOut
            ? await isHubBusyButAlive(this.port, curPid, curProbe)
            : false;
        if (curProbe.ok || currentBusyAlive) {
          this.isStopping = false;
          this.lastStartupError = undefined;
          writePersistentHubState({
            pid: curPid,
            port: this.port,
            csrfToken: this.csrfToken,
            serverUrl: this.serverUrl,
            consoleHidden: true
          });
          syncRendererAndProxyServerUrl(state, this.serverUrl, this.port, this.csrfToken);
          if (curProbe.ok) {
            ensureAntigravityTelemetryDisabled(this.port, this.csrfToken).catch(() => {});
          }
          return this.serverUrl;
        }
        replacedPriorPort = Number(this.port || savedCheck?.port || 0);
        const deadPid = curPid;
        silenceServerManagerCrashSignals(this);
        this.port = undefined;
        this.serverUrl = undefined;
        this.serverProcess = undefined;
        if (deadPid > 0) {
          const deadRun = await getRunningCascadeIdsDetailed(
            Number(savedCheck?.port || replacedPriorPort || 0),
            String(savedCheck?.csrfToken || this.csrfToken || ''),
            4500,
            { pid: deadPid }
          );
          if (deadRun.ids.length === 0 && (deadRun.reachable || !isPidAlive(deadPid))) {
            await reapBrokenAgyHubPid(deadPid);
          }
        }
      }

      const saved = readPersistentHubState();
      if (saved && saved.port && saved.csrfToken) {
        const pidAlive = isPidAlive(saved.pid);
        let lastSavedProbe = await probePersistentHubDetailed(saved.port, saved.csrfToken, 3500);
        if (!lastSavedProbe.ok && (pidAlive || lastSavedProbe.timedOut)) {
          await new Promise((r) => setTimeout(r, 250));
          lastSavedProbe = await probePersistentHubDetailed(saved.port, saved.csrfToken, 3500);
        }
        let savedHealthy = Boolean(lastSavedProbe.ok);
        if (!savedHealthy && lastSavedProbe.timedOut) {
          savedHealthy = await isHubBusyButAlive(saved.port, saved.pid, lastSavedProbe);
        }
        let scheduleDrainAfterReuse = false;
        if (!savedHealthy) {
          const authAnyEmail = await probePersistentHub(saved.port, saved.csrfToken, 3000, {
            checkAuth: true,
            checkEmailMatch: false
          });
          if (authAnyEmail) {
            const runningSaved = await getRunningCascadeIds(saved.port, saved.csrfToken, 4500, {
              pid: saved.pid
            });
            if (runningSaved.length > 0) {
              // Never kill a saved hub running active cascades on reload — reuse now and drain-switch once idle!
              savedHealthy = true;
              scheduleDrainAfterReuse = true;
            } else {
              const syncCheck = await ensureExpectedAntigravityKeyringSync(state);
              if (!syncCheck.canSwitch) {
                savedHealthy = true;
              }
            }
          }
        }
        const decision = decideSavedHubReuse({ savedHealthy, pidAlive });
        if (!decision.reuse) {
          replacedPriorPort = replacedPriorPort || Number(saved.port || 0);
          if (pidAlive && saved.pid) {
            const savedRun = await getRunningCascadeIdsDetailed(saved.port, saved.csrfToken, 4500, {
              pid: saved.pid
            });
            if (savedRun.ids.length === 0 && (savedRun.reachable || !lastSavedProbe.timedOut)) {
              silenceServerManagerCrashSignals(this);
              await reapBrokenAgyHubPid(saved.pid);
            }
          }
          try {
            fs.unlinkSync(getPersistentHubStateFilePath());
          } catch {}
          try {
            this.getOrCreateOutputChannel?.()?.appendLine?.(
              `[BHF PERSISTENT HUB] Saved agy --hub at ${saved.serverUrl} not reused (${decision.reason}) -> starting a fresh server`
            );
          } catch {}
        }
        if (decision.reuse) {
          this.csrfToken = saved.csrfToken;
          this.port = saved.port;
          this.serverUrl = saved.serverUrl || `http://127.0.0.1:${saved.port}`;
          this.isStopping = false;
          this.lastStartupError = undefined;
          writePersistentHubState({
            pid: saved.pid || 0,
            port: saved.port,
            csrfToken: saved.csrfToken,
            serverUrl: this.serverUrl,
            startedAt: saved.startedAt,
            consoleHidden: true
          });
          if (saved.pid) {
            reapDuplicateAgyHubProcesses(getProtectedHubPids(state, saved.pid));
          }
          syncRendererAndProxyServerUrl(state, this.serverUrl, this.port, this.csrfToken);
          ensureAntigravityTelemetryDisabled(this.port, this.csrfToken).catch(() => {});
          try {
            this.getOrCreateOutputChannel?.()?.appendLine?.(
              `[BHF PERSISTENT HUB] Reconnected to existing agy --hub at ${this.serverUrl} (pid ${saved.pid || 'unknown'})`
            );
          } catch {}
          if (scheduleDrainAfterReuse) {
            setTimeout(() => {
              restartHubForAccountSwitch(state).catch(() => {});
            }, 400);
          }
          return this.serverUrl;
        }
      }

      if (!this.csrfToken) {
        this.csrfToken = crypto.randomUUID();
      }
      this.isStopping = false;
      this.lastStartupError = undefined;
      await ensureExpectedAntigravityKeyringSync(state);
      const fallbackStartArg = this.lastStartOptions
        ? {
            ...this.lastStartOptions,
            context: state.context || this.lastStartOptions.context,
            skipAcquire: Boolean(this.lastBinaryPath)
          }
        : { context: state.context };
      const startedUrl = await origStart(a || fallbackStartArg, b, c, d);
      if (this.port && this.csrfToken) {
        const spawnedPid = this.serverProcess?.pid || 0;
        const startedAtSec = Math.floor(Date.now() / 1000);
        const finalUrl = startedUrl || this.serverUrl || `http://127.0.0.1:${this.port}`;
        writePersistentHubState({
          pid: spawnedPid,
          port: this.port,
          csrfToken: this.csrfToken,
          serverUrl: finalUrl,
          startedAt: startedAtSec,
          consoleHidden: true
        });
        if (!state?.__bhfDeferProxyCutoverDuringStart) {
          syncRendererAndProxyServerUrl(state, finalUrl, this.port, this.csrfToken);
        }
        ensureAntigravityTelemetryDisabled(this.port, this.csrfToken).catch(() => {});
        if (spawnedPid > 0 && !state?.__bhfSuppressReapDuringStart) {
          reapDuplicateAgyHubProcesses(getProtectedHubPids(state, spawnedPid));
        }
        if (
          replacedPriorPort > 0 &&
          Number(this.port) !== replacedPriorPort &&
          !state?.__bhfDeferProxyCutoverDuringStart
        ) {
          const resumeOpts = {
            bypassMinAge: true,
            forceResumeIds: [],
            hubStartedAtSec: startedAtSec
          };
          scheduleInterruptedCascadeCheck(state, 2200, resumeOpts);
          scheduleInterruptedCascadeCheck(state, 7500, resumeOpts);
        }
      }
      return startedUrl;
    })();
    this.__bhfStartPromise = runPromise;
    try {
      return await runPromise;
    } finally {
      if (this.__bhfStartPromise === runPromise) {
        this.__bhfStartPromise = null;
      }
    }
  };

  if (origStop) {
    serverManager.stop = function (options = {}) {
      return this.__bhfStopImpl(options);
    };
  }
  if (origStart) {
    serverManager.start = function (a, b, c, d) {
      return this.__bhfStartImpl(a, b, c, d);
    };
  }
}

function getBridgeState() {
  if (!globalThis[STATE_SYMBOL]) {
    globalThis[STATE_SYMBOL] = {
      attached: false,
      version: BRIDGE_VERSION,
      vscode: null,
      context: null,
      apiImpl: null,
      serverManager: null,
      provider: null,
      renderer: null,
      naming: null,
      sidebarView: null,
      sidebarDelegate: null,
      sidebarFallbackTimer: null,
      origResolveWebviewView: null,
      origProviderRefresh: null,
      entriesByUriKey: new Map(),
      entryByWebview: new Map(),
      titleById: new Map(),
      badgeById: new Map(),
      pendingConversations: null,
      activityTimer: null
    };
  }
  const st = globalThis[STATE_SYMBOL];
  if (!st.badgeById) {
    st.badgeById = new Map();
  }
  return st;
}

function getTabIconPath(state, badgeState = 'plain') {
  const { vscode, context } = state;
  if (!vscode?.Uri || !context?.extensionUri) {
    return null;
  }
  const fileName = TAB_ICON_FILES[badgeState] || TAB_ICON_FILES.plain;
  const iconUri = vscode.Uri.joinPath(context.extensionUri, 'img', fileName);
  return { light: iconUri, dark: iconUri };
}

function doesIconMatchFileName(iconPath, fileName) {
  if (!iconPath || !fileName) {
    return false;
  }
  const target = iconPath.dark || iconPath.light || iconPath;
  const raw = String(target?.fsPath || target?.path || target || '');
  if (!raw) {
    return false;
  }
  const lower = raw.toLowerCase();
  const suffix = String(fileName).toLowerCase();
  return lower.endsWith(`/${suffix}`) || lower.endsWith(`\\${suffix}`) || lower === suffix;
}

function applyEntryTabIcon(state, entry, badgeState = 'plain') {
  if (!entry || !entry.panel) {
    return false;
  }
  const normalized = TAB_ICON_FILES[badgeState] ? badgeState : 'plain';
  const expectedFile = TAB_ICON_FILES[normalized];
  if (
    entry.badgeState === normalized &&
    entry.iconApplied &&
    doesIconMatchFileName(entry.panel.iconPath, expectedFile)
  ) {
    return false;
  }
  const iconPath = getTabIconPath(state, normalized);
  if (!iconPath) {
    return false;
  }
  try {
    entry.panel.iconPath = iconPath;
    entry.badgeState = normalized;
    entry.iconApplied = true;
    return true;
  } catch {
    return false;
  }
}

function notifyThreadSeen(threadId) {
  const cleanId = String(threadId || '').trim();
  if (!cleanId) {
    return;
  }
  const state = getBridgeState();
  if (state.badgeById.get(cleanId) === 'done') {
    state.badgeById.set(cleanId, 'plain');
  }
  const entry = findOpenEntryByThreadId(cleanId);
  if (entry && entry.badgeState === 'done') {
    applyEntryTabIcon(state, entry, 'plain');
  }
  if (state.vscode?.commands) {
    state.vscode.commands
      .executeCommand('antigravityHub.markThreadSeen', {
        id: cleanId,
        seenAt: Math.floor(Date.now() / 1000)
      })
      .then(
        () => {},
        () => {}
      );
  }
}

function syncTabBadges(badgesById = {}) {
  const state = getBridgeState();
  if (!badgesById || typeof badgesById !== 'object') {
    return false;
  }
  for (const [id, badge] of Object.entries(badgesById)) {
    if (id && TAB_ICON_FILES[badge]) {
      state.badgeById.set(id, badge);
    }
  }
  let changed = false;
  for (const entry of state.entriesByUriKey.values()) {
    if (!entry || !entry.panel) {
      continue;
    }
    const threadId = entry.conversationId || '';
    let targetBadge =
      (threadId && (badgesById[threadId] || state.badgeById.get(threadId))) || 'plain';
    if (targetBadge === 'done' && entry.panel.active) {
      targetBadge = 'plain';
      if (threadId) {
        state.badgeById.set(threadId, 'plain');
      }
    }
    if (applyEntryTabIcon(state, entry, targetBadge)) {
      changed = true;
    }
  }
  return changed;
}

function makeDraftId() {
  if (typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
}

function notifyActivityChanged(payload = {}) {
  const state = getBridgeState();
  const vscode = state.vscode;
  if (!vscode?.commands) {
    return;
  }
  if (Array.isArray(payload?.conversations)) {
    state.pendingConversations = payload.conversations;
  }
  if (payload?.type === 'tab-closed') {
    try {
      state.sidebarDelegate?.handleTabClosedFast?.({
        id: payload.threadId || '',
        key: payload.uri || ''
      });
    } catch {}
  }
  const isForegroundTabPayload = (p) => {
    const t = String(p?.type || '');
    return (
      t === 'tab-closed' ||
      (!p?.preserveFocus &&
        !p?.beside &&
        (t === 'open-thread' ||
          t === 'reveal' ||
          t === 'open-new' ||
          t === 'reveal-draft' ||
          t === 'focus' ||
          (t === 'tab-state' && p?.active)))
    );
  };
  const prevPayload = state.pendingActivityPayload;
  if (
    !prevPayload ||
    payload?.type === 'tab-closed' ||
    (isForegroundTabPayload(payload) && prevPayload?.type !== 'tab-closed') ||
    !isForegroundTabPayload(prevPayload)
  ) {
    state.pendingActivityPayload = { ...payload };
  }
  if (state.activityTimer) {
    clearTimeout(state.activityTimer);
  }
  const delayMs = payload?.type === 'tab-closed' || state.pendingActivityPayload?.type === 'tab-closed' ? 5 : 60;
  state.activityTimer = setTimeout(() => {
    state.activityTimer = null;
    const mergedPayload = { ...(state.pendingActivityPayload || payload) };
    state.pendingActivityPayload = null;
    if (state.pendingConversations && !Array.isArray(mergedPayload.conversations)) {
      mergedPayload.conversations = state.pendingConversations;
    }
    state.pendingConversations = null;
    vscode.commands.executeCommand('antigravityHub.activityChanged', mergedPayload).then(
      () => {},
      () => {}
    );
  }, delayMs);
}

function resolveTabTitle(threadId, preferredTitle = '') {
  const state = getBridgeState();
  const cleanPreferred = normalizeTabText(preferredTitle, 56);
  if (cleanPreferred && cleanPreferred !== 'Antigravity') {
    if (threadId) {
      state.titleById.set(threadId, cleanPreferred);
    }
    return cleanPreferred;
  }
  if (threadId && state.titleById.has(threadId)) {
    return state.titleById.get(threadId);
  }
  if (threadId && state.context?.workspaceState) {
    const directUri = buildThreadUriString(threadId);
    const savedDirect = readTabState(state.context.workspaceState, directUri);
    if (savedDirect?.title && savedDirect.title !== 'Antigravity') {
      const clean = normalizeTabText(savedDirect.title, 56);
      state.titleById.set(threadId, clean);
      return clean;
    }
    const draftMatch = findDraftTabEntryForThread(state.context.workspaceState, threadId);
    if (draftMatch?.state?.title && draftMatch.state.title !== 'Antigravity') {
      const clean = normalizeTabText(draftMatch.state.title, 56);
      state.titleById.set(threadId, clean);
      return clean;
    }
  }
  return 'Antigravity';
}

const LAZY_REVEAL_VERSION = 2;

function attachEntryLazyRevealListener(state, entry) {
  if (
    !entry?.panel ||
    typeof entry.panel.onDidChangeViewState !== 'function' ||
    entry.__bhfLazyRevealVer === LAZY_REVEAL_VERSION
  ) {
    return;
  }
  if (entry.__bhfLazyRevealDisposable) {
    try {
      entry.__bhfLazyRevealDisposable.dispose();
    } catch {}
    entry.__bhfLazyRevealDisposable = null;
  }
  entry.__bhfLazyRevealVer = LAZY_REVEAL_VERSION;
  try {
    entry.__bhfLazyRevealDisposable = entry.panel.onDidChangeViewState(() => {
      if (!entry.panel || entry.panel.visible === false) {
        return;
      }
      const curPort = Number(state?.serverManager?.port || getProxyState()?.upstreamPort || 0);
      const portChanged =
        curPort > 0 && entry.renderedPort > 0 && entry.renderedPort !== curPort;
      if (
        (entry.needsDeferredReconnect || portChanged) &&
        !entry.__bhfRenderInFlight &&
        state?.renderer &&
        typeof state.renderer.renderJetskiIframe === 'function'
      ) {
        const parsedUri = entry.uriKey ? parseSessionUri(entry.uriKey) : null;
        const cid = String(
          (parsedUri?.kind === 'thread' ? parsedUri.threadId : '') ||
            entry.conversationId ||
            entry.initialConversationId ||
            ''
        ).trim();
        if (cid && !entry.conversationId) {
          entry.conversationId = cid;
        }
        if (cid && !entry.initialConversationId) {
          entry.initialConversationId = cid;
        }
        entry.needsDeferredReconnect = false;
        entry.iframeReady = false;
        entry.renderedPort = curPort;
        entry.lastRenderAt = Date.now();
        entry.__bhfRenderInFlight = true;
        const renderPromise = Promise.resolve(
          state.renderer.renderJetskiIframe(entry.panel, {
            targetRoute: cid ? `c/${cid}` : '',
            type: 'main',
            location: 'editor'
          })
        )
          .catch(() => {})
          .finally(() => {
            entry.__bhfRenderInFlight = false;
            if (entry.__bhfRenderPromise === renderPromise) {
              entry.__bhfRenderPromise = null;
            }
          });
        entry.__bhfRenderPromise = renderPromise;
      }
    });
  } catch {}
}

function attachEntryFastCloseListener(state, entry) {
  if (!state || !entry || !entry.panel || entry.__bhfFastCloseHooked) {
    return;
  }
  if (typeof entry.panel.onDidDispose !== 'function') {
    return;
  }
  entry.__bhfFastCloseHooked = true;
  try {
    entry.panel.onDidDispose(() => {
      entry.__bhfDisposed = true;
      const normKey = normalizeUriKey(entry.uriKey || entry.uri);
      if (normKey) {
        state.entriesByUriKey?.delete?.(normKey);
      }
      if (entry.uriKey) {
        state.entriesByUriKey?.delete?.(entry.uriKey);
      }
      if (entry.panel?.webview) {
        state.entryByWebview?.delete?.(entry.panel.webview);
      }
      clearOpeningTargetIfMatched(state, {
        threadId: entry.conversationId || '',
        uriKey: normKey || entry.uriKey || ''
      });
      try {
        state.sidebarDelegate?.handleTabClosedFast?.({
          id: entry.conversationId || '',
          key: normKey || entry.uriKey || ''
        });
      } catch {}
    });
  } catch {}
}

function normalizeLiveEntriesMap(state = getBridgeState()) {
  if (!state || !(state.entriesByUriKey instanceof Map)) {
    return;
  }
  const toMigrate = [];
  for (const [rawKey, entry] of state.entriesByUriKey.entries()) {
    const normKey = normalizeUriKey(rawKey || entry?.uriKey || entry?.uri);
    if (entry && normKey && entry.uriKey !== normKey) {
      entry.uriKey = normKey;
    }
    if (normKey && rawKey !== normKey) {
      toMigrate.push([rawKey, normKey, entry]);
    }
    if (entry && normKey) {
      const parsed = parseSessionUri(normKey);
      if (parsed.kind === 'thread' && parsed.threadId) {
        if (entry.conversationId !== parsed.threadId) {
          entry.conversationId = parsed.threadId;
        }
        if (entry.initialConversationId !== parsed.threadId) {
          entry.initialConversationId = parsed.threadId;
        }
      } else if (entry.conversationId && !entry.initialConversationId) {
        entry.initialConversationId = entry.conversationId;
      }
    }
    if (entry && !entry.instance && entry.panel?.webview && Array.isArray(state.apiImpl?.views)) {
      const matchedView = state.apiImpl.views.find(
        (vw) => vw && vw.type === 'main' && (vw.view?.webview || vw.webview) === entry.panel.webview
      );
      if (matchedView) {
        entry.instance = matchedView;
      }
    }
    if (entry && !entry.conversationId && entry.instance) {
      const instPath = String(
        entry.instance?.currentUrl?.path || entry.instance?.url?.path || ''
      );
      const instMatch = instPath.match(/^\/c\/([^/?#]+)$/);
      if (instMatch && instMatch[1]) {
        entry.conversationId = instMatch[1];
        if (!entry.initialConversationId) {
          entry.initialConversationId = instMatch[1];
        }
      }
    }
    if (entry?.panel) {
      attachEntryLazyRevealListener(state, entry);
      attachEntryFastCloseListener(state, entry);
      if (normKey && !entry.__bhfSeenInTabGroups && isUriOpenInTabGroups(state.vscode, normKey)) {
        entry.__bhfSeenInTabGroups = true;
      }
    }
  }
  for (const [oldKey, normKey, entry] of toMigrate) {
    state.entriesByUriKey.delete(oldKey);
    if (!state.entriesByUriKey.has(normKey)) {
      state.entriesByUriKey.set(normKey, entry);
    }
  }
}

function findEntryByUriKey(state, uriKey) {
  const cleanUri = normalizeUriKey(uriKey);
  if (!cleanUri || !state || !(state.entriesByUriKey instanceof Map)) {
    return null;
  }
  normalizeLiveEntriesMap(state);
  const direct = state.entriesByUriKey.get(cleanUri);
  if (direct) {
    return direct;
  }
  for (const [k, entry] of state.entriesByUriKey.entries()) {
    if (normalizeUriKey(k) === cleanUri || normalizeUriKey(entry?.uri) === cleanUri) {
      return entry;
    }
  }
  return null;
}

function findOpenEntryByThreadId(threadId) {
  const cleanId = String(threadId || '').trim();
  if (!cleanId) {
    return null;
  }
  const state = getBridgeState();
  normalizeLiveEntriesMap(state);
  for (const entry of state.entriesByUriKey.values()) {
    if (entry && entry.conversationId === cleanId && entry.panel) {
      return entry;
    }
  }
  return null;
}

function findTabGroupColumnForUri(vscode, targetUriKey) {
  const cleanTarget = normalizeUriKey(targetUriKey);
  if (!cleanTarget || !vscode?.window?.tabGroups?.all) {
    return null;
  }
  for (const group of vscode.window.tabGroups.all) {
    for (const tab of group.tabs || []) {
      const inputUri = tab?.input?.uri;
      if (inputUri && normalizeUriKey(inputUri) === cleanTarget) {
        return typeof group.viewColumn === 'number' ? group.viewColumn : null;
      }
    }
  }
  return null;
}

function resolveTargetColumn(vscode, options = {}) {
  if (typeof options.viewColumn === 'number') {
    return options.viewColumn;
  }
  if (options.beside) {
    return vscode.ViewColumn.Beside;
  }
  if (options.uriKey) {
    const uriCol = findTabGroupColumnForUri(vscode, options.uriKey);
    if (typeof uriCol === 'number') {
      return uriCol;
    }
  }
  const activeGroup = vscode?.window?.tabGroups?.activeTabGroup;
  const groupHasSessionTab = (grp) =>
    Array.isArray(grp?.tabs) &&
    grp.tabs.some((tab) => tab?.input?.uri?.scheme === SESSION_TAB_SCHEME);
  if (activeGroup && groupHasSessionTab(activeGroup) && typeof activeGroup.viewColumn === 'number') {
    return activeGroup.viewColumn;
  }
  if (Array.isArray(vscode?.window?.tabGroups?.all)) {
    for (const grp of vscode.window.tabGroups.all) {
      if (groupHasSessionTab(grp) && typeof grp.viewColumn === 'number') {
        return grp.viewColumn;
      }
    }
  }
  if (typeof activeGroup?.viewColumn === 'number') {
    return activeGroup.viewColumn;
  }
  return vscode.ViewColumn.One || vscode.ViewColumn.Active;
}

function setOpeningTarget(state, { threadId = '', uriKey = '', durationMs = 1600 } = {}) {
  if (!state) {
    return 0;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = normalizeUriKey(uriKey);
  if (!cleanId && !cleanUri) {
    state.__bhfOpeningTarget = null;
    return Number(state.__bhfOpenSeq || 0);
  }
  const nextSeq = Number(state.__bhfOpenSeq || 0) + 1;
  state.__bhfOpenSeq = nextSeq;
  if (state.__bhfPendingFocusByUri instanceof Map) {
    state.__bhfPendingFocusByUri.clear();
  }
  const now = Date.now();
  const prev =
    state.__bhfOpeningTarget && now < Number(state.__bhfOpeningTarget.until || 0)
      ? state.__bhfOpeningTarget
      : null;
  const outgoingThreadIds = new Set(prev?.outgoingThreadIds instanceof Set ? prev.outgoingThreadIds : []);
  const outgoingUriKeys = new Set(prev?.outgoingUriKeys instanceof Set ? prev.outgoingUriKeys : []);
  if (prev?.outgoingThreadId) outgoingThreadIds.add(prev.outgoingThreadId);
  if (prev?.outgoingUriKey) outgoingUriKeys.add(prev.outgoingUriKey);
  if (prev) {
    const sameAsPrev =
      (cleanId && prev.threadId === cleanId) || (cleanUri && prev.uriKey === cleanUri);
    if (!sameAsPrev) {
      if (prev.threadId) outgoingThreadIds.add(prev.threadId);
      if (prev.uriKey) outgoingUriKeys.add(prev.uriKey);
    }
  }
  let outgoingThreadId = '';
  let outgoingUriKey = '';
  if (state.entriesByUriKey instanceof Map) {
    for (const entry of state.entriesByUriKey.values()) {
      if (entry?.panel?.active) {
        const eId = String(entry.conversationId || '').trim();
        const eUri = normalizeUriKey(entry.uriKey || entry.uri);
        if ((cleanId && eId && eId !== cleanId) || (cleanUri && eUri && eUri !== cleanUri)) {
          outgoingThreadId = eId;
          outgoingUriKey = eUri;
          if (eId) outgoingThreadIds.add(eId);
          if (eUri) outgoingUriKeys.add(eUri);
          break;
        }
      }
    }
  }
  const groups = state.vscode?.window?.tabGroups?.all || [];
  const activeGroup =
    state.vscode?.window?.tabGroups?.activeTabGroup ||
    groups.find((g) => Boolean(g?.isActive)) ||
    (groups.length === 1 ? groups[0] : null);
  if (activeGroup) {
    const activeTab =
      activeGroup.activeTab ||
      (Array.isArray(activeGroup.tabs) ? activeGroup.tabs.find((t) => Boolean(t?.isActive)) : null);
    const inputUri = activeTab?.input?.uri;
    if (inputUri && inputUri.scheme === SESSION_TAB_SCHEME) {
      const eUri = normalizeUriKey(inputUri);
      const parsed = parseSessionUri(eUri);
      const saved = readTabState(state.context?.workspaceState, eUri);
      const eId = parsed.kind === 'thread' ? parsed.threadId : saved?.id || '';
      if ((cleanId && eId && eId !== cleanId) || (cleanUri && eUri && eUri !== cleanUri)) {
        if (!outgoingThreadId) outgoingThreadId = eId;
        if (!outgoingUriKey) outgoingUriKey = eUri;
        if (eId) outgoingThreadIds.add(eId);
        if (eUri) outgoingUriKeys.add(eUri);
      }
    }
  }
  if (cleanId) outgoingThreadIds.delete(cleanId);
  if (cleanUri) outgoingUriKeys.delete(cleanUri);
  state.__bhfOpeningTarget = {
    seq: nextSeq,
    threadId: cleanId,
    uriKey: cleanUri,
    outgoingThreadId,
    outgoingUriKey,
    outgoingThreadIds,
    outgoingUriKeys,
    setAt: now,
    until: now + Math.max(120, Number(durationMs) || 1600)
  };
  return nextSeq;
}

function clearOpeningTargetIfMatched(state, { threadId = '', uriKey = '' } = {}) {
  const cur = state?.__bhfOpeningTarget;
  if (!cur) {
    return;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = normalizeUriKey(uriKey);
  if ((cleanId && cur.threadId === cleanId) || (cleanUri && cur.uriKey === cleanUri)) {
    state.__bhfOpeningTarget = null;
  }
}

function isOpeningOtherTarget(state, { threadId = '', uriKey = '' } = {}) {
  const cur = state?.__bhfOpeningTarget;
  if (!cur) {
    return false;
  }
  if (Date.now() >= Number(cur.until || 0)) {
    state.__bhfOpeningTarget = null;
    return false;
  }
  const cleanId = String(threadId || '').trim();
  const cleanUri = normalizeUriKey(uriKey);
  if ((cleanId && cur.threadId === cleanId) || (cleanUri && cur.uriKey === cleanUri)) {
    return false;
  }
  if (cleanId && cur.outgoingThreadIds instanceof Set && cur.outgoingThreadIds.has(cleanId)) {
    return true;
  }
  if (cleanUri && cur.outgoingUriKeys instanceof Set && cur.outgoingUriKeys.has(cleanUri)) {
    return true;
  }
  if (cur.outgoingThreadId || cur.outgoingUriKey) {
    return Boolean(
      (cur.outgoingThreadId && cleanId === cur.outgoingThreadId) ||
        (cur.outgoingUriKey && cleanUri === cur.outgoingUriKey)
    );
  }
  return false;
}

function isUriOpenInTabGroups(vscode, targetUriKey) {
  return findTabGroupColumnForUri(vscode, targetUriKey) !== null;
}

async function reconnectAllOpenTabs(state = getBridgeState(), options = {}) {
  if (!state) {
    return { ok: false, reconnected: 0 };
  }
  normalizeLiveEntriesMap(state);
  const forceRender = Boolean(options.forceRender);
  const forceRestart = Boolean(options.forceRestart);
  const skipEmailMismatchAutoSwitch = Boolean(options.skipEmailMismatchAutoSwitch);
  const probeTimeoutMs = Math.max(250, Number(options.probeTimeoutMs) || 3500);
  const runStateTimeoutMs = Math.max(probeTimeoutMs, Number(options.runStateTimeoutMs) || 4500);
  const vaultDir = state.__bhfVaultDir || '';
  try {
    if (!forceRestart && state.serverManager) {
      const inFlightStart =
        state.serverManager.__bhfStartPromise || state.serverManager.startingPromise || null;
      if (inFlightStart && typeof inFlightStart.then === 'function') {
        try {
          await inFlightStart;
        } catch {}
      }
    }

    const proxySt = getProxyState();
    const savedBefore = readPersistentHubState();
    const initialActivePort = Number(
      state.serverManager?.port || proxySt?.upstreamPort || savedBefore?.port || 0
    );
    const initialActiveCsrf = String(
      state.serverManager?.csrfToken || proxySt?.csrfToken || savedBefore?.csrfToken || ''
    ).trim();
    let activePort = forceRestart
      ? 0
      : Number(state.serverManager?.port || proxySt?.upstreamPort || 0);
    let activeCsrf = forceRestart
      ? ''
      : String(state.serverManager?.csrfToken || proxySt?.csrfToken || '').trim();
    let activeUrl = forceRestart
      ? ''
      : state.serverManager?.serverUrl ||
        (activePort > 0 ? `http://127.0.0.1:${activePort}` : '');
    const activePid = Number(
      state.serverManager?.serverProcess?.pid ||
        (savedBefore && Number(savedBefore.port) === activePort ? savedBefore.pid : 0) ||
        0
    );

    const checkAuthDuringProbe = !state.__bhfPendingAccountSwitchDrain;
    let probeRes = { ok: false };
    let healthy = false;
    if (!forceRestart && activePort > 0 && activeCsrf) {
      probeRes = await probePersistentHubDetailed(activePort, activeCsrf, probeTimeoutMs, {
        checkAuth: checkAuthDuringProbe,
        checkEmailMatch: !skipEmailMismatchAutoSwitch,
        vaultDir
      });
      if (!probeRes.ok && probeRes.timedOut) {
        await new Promise((r) => setTimeout(r, Math.min(250, probeTimeoutMs)));
        probeRes = await probePersistentHubDetailed(activePort, activeCsrf, probeTimeoutMs, {
          checkAuth: checkAuthDuringProbe,
          checkEmailMatch: !skipEmailMismatchAutoSwitch,
          vaultDir
        });
      }
      if (probeRes.ok) {
        healthy = true;
        state.__bhfConsecutiveBusyTimeouts = 0;
      } else if (probeRes.timedOut) {
        const busyAlive = await isHubBusyButAlive(activePort, activePid, probeRes);
        const prevBusyCount = Number(state.__bhfConsecutiveBusyTimeouts || 0);
        if (busyAlive && (prevBusyCount < 8 || findActiveCascadesFromDiskTranscripts().length > 0)) {
          state.__bhfConsecutiveBusyTimeouts = prevBusyCount + 1;
          healthy = true;
        }
      }
    }

    if (
      !healthy &&
      !forceRestart &&
      activePort > 0 &&
      activeCsrf &&
      checkAuthDuringProbe &&
      !skipEmailMismatchAutoSwitch &&
      !probeRes.timedOut &&
      !probeRes.connectionRefused
    ) {
      // Check whether the hub is 100% alive and authenticated, and ONLY differed on expectedEmail:
      const authAliveAnyEmail = probeRes.emailMismatch
        ? true
        : await probePersistentHub(activePort, activeCsrf, probeTimeoutMs, {
            checkAuth: true,
            checkEmailMatch: false,
            vaultDir
          });
      if (authAliveAnyEmail) {
        const authCtx = readExpectedActiveAntigravityEmail(vaultDir);
        const recentlySwitchedSameTarget =
          Boolean(authCtx.expectedEmail) &&
          state.__bhfLastAutoEmailSwitchTarget === authCtx.expectedEmail &&
          Date.now() - Number(state.__bhfLastAutoEmailSwitchAt || 0) < 180000;
        if (recentlySwitchedSameTarget) {
          healthy = true;
        } else {
          const syncRes = await ensureExpectedAntigravityKeyringSync(state);
          if (!syncRes.canSwitch) {
            healthy = true;
          } else {
            state.__bhfLastAutoEmailSwitchTarget = authCtx.expectedEmail;
            state.__bhfLastAutoEmailSwitchAt = Date.now();
            return restartHubForAccountSwitch(state, { preserveAutoSwitchCooldown: true });
          }
        }
      }
    }

    if (!healthy && !forceRestart) {
      const saved = readPersistentHubState();
      const savedPort = Number(saved?.port || 0);
      const savedCsrf = String(saved?.csrfToken || '').trim();
      if (savedPort > 0 && savedCsrf && savedPort !== activePort) {
        let savedProbe = await probePersistentHubDetailed(savedPort, savedCsrf, probeTimeoutMs, {
          checkAuth: checkAuthDuringProbe,
          checkEmailMatch: !skipEmailMismatchAutoSwitch,
          vaultDir
        });
        if (!savedProbe.ok && savedProbe.timedOut) {
          savedProbe.busyAlive = await isHubBusyButAlive(savedPort, saved?.pid || 0, savedProbe);
        }
        healthy = Boolean(savedProbe.ok || savedProbe.busyAlive);
        if (!healthy && checkAuthDuringProbe && !savedProbe.timedOut && !savedProbe.connectionRefused) {
          const savedAuthAnyEmail = savedProbe.emailMismatch
            ? true
            : await probePersistentHub(savedPort, savedCsrf, probeTimeoutMs, {
                checkAuth: true,
                checkEmailMatch: false,
                vaultDir
              });
          if (savedAuthAnyEmail) {
            const syncRes = await ensureExpectedAntigravityKeyringSync(state);
            if (!syncRes.canSwitch) {
              healthy = true;
            }
          }
        }
        if (healthy) {
          activePort = savedPort;
          activeCsrf = savedCsrf;
          activeUrl = saved.serverUrl || `http://127.0.0.1:${savedPort}`;
          state.__bhfConsecutiveBusyTimeouts = 0;
        } else if (saved?.pid) {
          const runSaved = await getRunningCascadeIdsDetailed(
            savedPort,
            savedCsrf,
            runStateTimeoutMs,
            { pid: saved.pid }
          );
          const canSafelyReap =
            runSaved.ids.length === 0 &&
            (runSaved.reachable ||
              savedProbe.connectionRefused ||
              savedProbe.missingWebUi ||
              savedProbe.unauthenticated ||
              !isPidAlive(saved.pid));
          if (canSafelyReap) {
            silenceServerManagerCrashSignals(state.serverManager);
            await reapBrokenAgyHubPid(saved.pid);
          }
        }
      } else if (saved?.pid) {
        const savedBusyAlive =
          probeRes.timedOut &&
          (await isHubBusyButAlive(savedPort || activePort, saved.pid, probeRes));
        if (!savedBusyAlive) {
          const runSaved =
            savedPort > 0 && savedCsrf
              ? await getRunningCascadeIdsDetailed(savedPort, savedCsrf, runStateTimeoutMs, {
                  pid: saved.pid
                })
              : { reachable: true, ids: [] };
          const canSafelyReap =
            runSaved.ids.length === 0 &&
            (runSaved.reachable ||
              probeRes.connectionRefused ||
              probeRes.missingWebUi ||
              probeRes.unauthenticated ||
              !isPidAlive(saved.pid));
          if (canSafelyReap) {
            silenceServerManagerCrashSignals(state.serverManager);
            await reapBrokenAgyHubPid(saved.pid);
          }
        }
      }
    }

    const prevPortBeforeStart = initialActivePort;
    const prevCsrfBeforeStart = initialActiveCsrf;
    let spawnedReplacementHub = false;
    let hubSpawnedAtSec = 0;

    if (!healthy && state.serverManager && typeof state.serverManager.start === 'function') {
      clearUpstreamServerState(state, { mintFreshCsrf: false });
      if (state.serverManager && !state.serverManager.csrfToken && prevCsrfBeforeStart) {
        state.serverManager.csrfToken = prevCsrfBeforeStart;
      }
      await ensureExpectedAntigravityKeyringSync(state);
      hubSpawnedAtSec = Math.floor(Date.now() / 1000);
      await state.serverManager.start({ context: state.context });
      activePort = Number(state.serverManager.port || 0);
      activeCsrf = String(state.serverManager.csrfToken || '').trim();
      activeUrl =
        state.serverManager.serverUrl ||
        (activePort > 0 ? `http://127.0.0.1:${activePort}` : '');
      healthy =
        activePort > 0 && activeCsrf
          ? await probePersistentHubWithRetry(
              activePort,
              activeCsrf,
              3,
              Math.max(2000, probeTimeoutMs),
              { checkAuth: false }
            )
          : false;
      if (healthy) {
        state.__bhfConsecutiveBusyTimeouts = 0;
        spawnedReplacementHub =
          prevPortBeforeStart > 0 && activePort > 0 && activePort !== prevPortBeforeStart;
      }
    }

    if (activePort > 0 && activeCsrf) {
      syncRendererAndProxyServerUrl(state, activeUrl, activePort, activeCsrf);
    }

    const switchedUpstreamPort =
      initialActivePort > 0 && activePort > 0 && activePort !== initialActivePort;
    let seamlessCutoverCount = 0;
    if (
      healthy &&
      switchedUpstreamPort &&
      !forceRender &&
      prevCsrfBeforeStart &&
      prevCsrfBeforeStart === activeCsrf &&
      state.entriesByUriKey instanceof Map
    ) {
      for (const entry of state.entriesByUriKey.values()) {
        if (!entry?.panel) continue;
        if (entry.iframeReady && entry.renderedPort > 0) {
          entry.renderedPort = activePort;
          entry.needsDeferredReconnect = false;
          seamlessCutoverCount += 1;
        }
      }
      closeUpstreamSocketsForPort(proxySt, initialActivePort);
    }

    let reconnected = 0;
    let deferred = 0;
    if (healthy && state.renderer && state.entriesByUriKey instanceof Map) {
      for (const entry of state.entriesByUriKey.values()) {
        if (!entry?.panel) continue;
        attachEntryLazyRevealListener(state, entry);
        const portMismatch =
          activePort > 0 && entry.renderedPort > 0 && entry.renderedPort !== activePort;
        const neverRendered =
          !entry.renderedPort && !entry.lastRenderAt && !entry.needsDeferredReconnect;
        const needsRender = forceRender || portMismatch || neverRendered;
        if (!needsRender) continue;
        const isVisible = entry.panel.visible !== false || Boolean(entry.pendingPromptSend);
        if (!isVisible) {
          entry.iframeReady = false;
          entry.renderedPort = 0;
          entry.needsDeferredReconnect = true;
          deferred++;
          continue;
        }
        if (entry.__bhfRenderInFlight && !forceRender) continue;
        const cid = String(entry.conversationId || entry.initialConversationId || '').trim();
        try {
          entry.needsDeferredReconnect = false;
          entry.iframeReady = false;
          entry.renderedPort = activePort;
          entry.lastRenderAt = Date.now();
          entry.__bhfRenderInFlight = true;
          await state.renderer.renderJetskiIframe(entry.panel, {
            targetRoute: cid ? `c/${cid}` : '',
            type: 'main',
            location: 'editor'
          });
          reconnected++;
        } catch {} finally {
          entry.__bhfRenderInFlight = false;
        }
      }
    }
    if (healthy && spawnedReplacementHub && !options.skipEmailMismatchAutoSwitch) {
      const resumeOpts = {
        bypassMinAge: true,
        forceResumeIds: [],
        hubStartedAtSec: hubSpawnedAtSec || Math.floor(Date.now() / 1000)
      };
      scheduleInterruptedCascadeCheck(state, 2200, resumeOpts);
      scheduleInterruptedCascadeCheck(state, 7500, resumeOpts);
    }
    if (forceRender && (reconnected > 0 || deferred > 0)) {
      notifyActivityChanged({ type: 'reconnected', port: activePort, reconnected, deferred });
    }
    return {
      ok: healthy,
      port: activePort,
      reconnected,
      deferred,
      seamlessCutoverCount
    };
  } catch (err) {
    return { ok: false, error: String(err?.message || err || '') };
  }
}

function hasActiveBackgroundWorkInTranscript(cascadeId, nowMs = Date.now()) {
  try {
    const cleanId = String(cascadeId || '').trim();
    if (!cleanId) return false;
    const brainRoot =
      process.env.THEO_BRAIN_ROOT_DIR ||
      path.join(os.homedir(), '.gemini', 'antigravity', 'brain');
    const transcriptPath = path.join(
      brainRoot,
      cleanId,
      '.system_generated',
      'logs',
      'transcript.jsonl'
    );
    if (!fs.existsSync(transcriptPath)) {
      return false;
    }
    const st = fs.statSync(transcriptPath);
    if (nowMs - st.mtimeMs > 4 * 3600 * 1000) {
      return false;
    }
    const raw = fs.readFileSync(transcriptPath, 'utf8');
    if (!raw || !raw.trim()) return false;
    const lines = raw.trim().split('\n');
    const pendingTasks = new Map();
    const recentRunCmdIsDaemonQueue = [];
    for (const line of lines) {
      if (!line || line[0] !== '{') continue;
      let step;
      try {
        step = JSON.parse(line);
      } catch {
        continue;
      }
      const stType = step.type || '';
      const stStatus = step.status || '';
      const content = typeof step.content === 'string' ? step.content : '';
      if (stType === 'USER_INPUT' && step.source !== 'SYSTEM' && !content.includes('<SYSTEM_MESSAGE')) {
        pendingTasks.clear();
        recentRunCmdIsDaemonQueue.length = 0;
      } else if (
        stType === 'SYSTEM_MESSAGE' &&
        content.includes('All your subagents and background tasks have been stopped')
      ) {
        pendingTasks.clear();
      }
      if (stType === 'PLANNER_RESPONSE' && Array.isArray(step.tool_calls)) {
        recentRunCmdIsDaemonQueue.length = 0;
        for (const tc of step.tool_calls) {
          if (!tc || typeof tc !== 'object') continue;
          const tcName = String(tc.name || '').replace(/^default_api:/, '');
          let parsedArgs = tc.arguments ?? tc.args ?? null;
          if (typeof parsedArgs === 'string') {
            try {
              parsedArgs = JSON.parse(parsedArgs);
            } catch {
              parsedArgs = null;
            }
          }
          if (tcName === 'run_command' || tcName === 'schedule') {
            recentRunCmdIsDaemonQueue.push(Boolean(parsedArgs?.IsDaemon));
          } else if (tcName === 'manage_task' && pendingTasks.size > 0) {
            if (parsedArgs?.Action === 'kill' && parsedArgs?.TaskId) {
              pendingTasks.delete(String(parsedArgs.TaskId).trim());
            }
          }
        }
      }
      if (
        stType === 'GENERIC' &&
        stStatus === 'RUNNING' &&
        (content.includes('background task with task id:') || content.includes('Task ID:'))
      ) {
        const mId =
          content.match(/background task with task id:\s*(\S+)/i) ||
          content.match(/Task ID:\s*(\S+)/i);
        const isDaemon =
          recentRunCmdIsDaemonQueue.length > 0 ? Boolean(recentRunCmdIsDaemonQueue.shift()) : false;
        if (mId && !isDaemon) {
          pendingTasks.set(mId[1].trim(), true);
        }
      } else if (
        stType === 'GENERIC' &&
        (stStatus === 'RUNNING' || stStatus === 'DONE') &&
        /conversationId["\s:=]+([0-9a-f]{8}-[0-9a-f]{4}-)/i.test(content) &&
        content.includes('logAbsoluteUri')
      ) {
        const mSub = content.match(/conversationId["\s:=]+([0-9a-f-]{36})/i);
        if (mSub) {
          pendingTasks.set(mSub[1].trim(), true);
        }
      } else if (stType === 'GENERIC' && stStatus === 'DONE' && recentRunCmdIsDaemonQueue.length > 0) {
        recentRunCmdIsDaemonQueue.shift();
      } else if (content && pendingTasks.size > 0) {
        const senderRe = /sender=([^\s>"<]+)/g;
        let m;
        while ((m = senderRe.exec(content)) !== null) {
          const cleanSender = m[1].trim();
          pendingTasks.delete(cleanSender);
        }
        const cancelRe = /Task "([^"]+)" cancel/g;
        while ((m = cancelRe.exec(content)) !== null) {
          pendingTasks.delete(m[1]);
        }
      }
    }
    return pendingTasks.size > 0;
  } catch {
    return false;
  }
}

function findActiveCascadesFromDiskTranscripts(nowMs = Date.now(), options = {}) {
  try {
    let effectiveNowMs = Date.now();
    let effectiveOpts = options && typeof options === 'object' ? { ...options } : {};
    if (typeof nowMs === 'number' && Number.isFinite(nowMs) && nowMs > 0) {
      if (nowMs < 1e11) {
        effectiveOpts.maxInterruptedAgeMs = Math.max(
          Number(effectiveOpts.maxInterruptedAgeMs || 0),
          nowMs * 1000
        );
      } else {
        effectiveNowMs = nowMs;
      }
    } else if (nowMs && typeof nowMs === 'object') {
      effectiveOpts = { ...nowMs };
    }
    const maxInterruptedAgeMs =
      Number(effectiveOpts.maxInterruptedAgeMs || 0) > 0
        ? Number(effectiveOpts.maxInterruptedAgeMs)
        : 90000;
    const maxTranscriptAgeMs = Math.max(4 * 3600 * 1000, maxInterruptedAgeMs);

    const brainRoot =
      process.env.THEO_BRAIN_ROOT_DIR ||
      path.join(os.homedir(), '.gemini', 'antigravity', 'brain');
    if (!fs.existsSync(brainRoot)) {
      return [];
    }
    const includeBackgroundWaiters = effectiveOpts.includeBackgroundWaiters !== false;
    const onlyCandidates =
      Array.isArray(effectiveOpts.onlyCascadeIds) && effectiveOpts.onlyCascadeIds.length > 0
        ? Array.from(new Set(effectiveOpts.onlyCascadeIds.map((id) => String(id || '').trim()).filter(Boolean)))
        : null;

    let candidateIds = onlyCandidates;
    if (!candidateIds) {
      const idSet = new Set();
      try {
        for (const t of getOpenTabsSnapshot()) {
          const tid = String(t?.id || '').trim();
          if (tid) idSet.add(tid);
        }
      } catch {}
      try {
        const entries = fs.readdirSync(brainRoot, { withFileTypes: true });
        for (const ent of entries) {
          if (ent && ent.isDirectory() && /^[0-9a-f-]{8,}$/i.test(ent.name)) {
            idSet.add(ent.name);
          }
        }
      } catch {}
      candidateIds = Array.from(idSet);
    }

    const nowSec = Math.floor(effectiveNowMs / 1000);
    const active = [];
    for (const id of candidateIds) {
      try {
        const transcriptPath = path.join(
          brainRoot,
          id,
          '.system_generated',
          'logs',
          'transcript.jsonl'
        );
        if (!fs.existsSync(transcriptPath)) {
          continue;
        }
        const st = fs.statSync(transcriptPath);
        const ageMs = effectiveNowMs - st.mtimeMs;
        if (ageMs > maxTranscriptAgeMs) {
          continue;
        }
        if (includeBackgroundWaiters && hasActiveBackgroundWorkInTranscript(id, effectiveNowMs)) {
          active.push(id);
          continue;
        }
        if (ageMs <= maxInterruptedAgeMs) {
          const check = inspectCascadeInterruptedState(id, nowSec, { bypassMinAge: true });
          if (check && check.interrupted) {
            active.push(id);
          }
        }
      } catch {}
    }
    return active;
  } catch {
    return [];
  }
}

async function getRunningCascadeIdsDetailed(port, csrfToken, timeoutMs = 4500, options = {}) {
  try {
    const rpc = await fetchCascadeRunStatesDetailed(port, csrfToken, timeoutMs);
    if (!rpc || !rpc.reachable || !rpc.summaries || typeof rpc.summaries !== 'object') {
      const timedOut = Boolean(rpc?.timedOut);
      const connectionRefused = Boolean(rpc?.connectionRefused);
      let fallbackIds = [];
      if (
        options.fallbackToDisk !== false &&
        !connectionRefused &&
        timedOut &&
        (await isHubBusyButAlive(port, options.pid || 0, { timedOut: true }))
      ) {
        const diskOpts =
          !options.onlyCascadeIds && Array.isArray(options.bgWaiterCandidateIds)
            ? { ...options, onlyCascadeIds: options.bgWaiterCandidateIds }
            : options;
        fallbackIds = findActiveCascadesFromDiskTranscripts(Date.now(), diskOpts);
      }
      return {
        reachable: false,
        timedOut,
        connectionRefused,
        ids: fallbackIds,
        fromDiskFallback: fallbackIds.length > 0
      };
    }
    const summaries = rpc.summaries;
    const nowMs = Date.now();
    const brainRoot =
      process.env.THEO_BRAIN_ROOT_DIR ||
      path.join(os.homedir(), '.gemini', 'antigravity', 'brain');
    const includeBackgroundWaiters = options.includeBackgroundWaiters !== false;
    const onlyCandidateSet =
      Array.isArray(options.onlyCascadeIds) && options.onlyCascadeIds.length > 0
        ? new Set(options.onlyCascadeIds.map((id) => String(id || '').trim()).filter(Boolean))
        : null;
    const bgWaiterCandidateSet =
      Array.isArray(options.bgWaiterCandidateIds) && options.bgWaiterCandidateIds.length > 0
        ? new Set(options.bgWaiterCandidateIds.map((id) => String(id || '').trim()).filter(Boolean))
        : null;
    const running = [];
    for (const [id, info] of Object.entries(summaries)) {
      if (onlyCandidateSet && !onlyCandidateSet.has(id)) {
        continue;
      }
      if (!info) {
        continue;
      }
      if (Array.isArray(info.waitingForUserSteps) && info.waitingForUserSteps.length > 0) {
        continue;
      }
      const allowBgWaiterForId =
        includeBackgroundWaiters && (!bgWaiterCandidateSet || bgWaiterCandidateSet.has(id));
      if (info.status === 'CASCADE_RUN_STATUS_RUNNING') {
        if (typeof info.lastModifiedTime === 'string' && info.lastModifiedTime.trim()) {
          const modMs = Date.parse(info.lastModifiedTime);
          if (Number.isFinite(modMs) && nowMs - modMs > 45000) {
            let recentDiskWrite = false;
            try {
              const transcriptPath = path.join(
                brainRoot,
                String(id).trim(),
                '.system_generated',
                'logs',
                'transcript.jsonl'
              );
              if (fs.existsSync(transcriptPath)) {
                const st = fs.statSync(transcriptPath);
                if (nowMs - st.mtimeMs <= 45000) {
                  recentDiskWrite = true;
                }
              }
            } catch {}
            if (!recentDiskWrite && (!allowBgWaiterForId || !hasActiveBackgroundWorkInTranscript(id, nowMs))) {
              continue;
            }
          }
        }
        running.push(id);
        continue;
      }
      // Also protect cascades whose LLM turn is temporarily IDLE waiting for a background command/timer/subagent
      // owned by this hub process to finish and deliver its wakeup notification!
      if (allowBgWaiterForId) {
        const modMs =
          typeof info.lastModifiedTime === 'string' && info.lastModifiedTime.trim()
            ? Date.parse(info.lastModifiedTime)
            : 0;
        if ((!modMs || nowMs - modMs <= 4 * 3600 * 1000) && hasActiveBackgroundWorkInTranscript(id, nowMs)) {
          running.push(id);
        }
      }
    }
    return {
      reachable: true,
      timedOut: false,
      connectionRefused: false,
      ids: running,
      fromDiskFallback: false
    };
  } catch {
    return {
      reachable: false,
      timedOut: false,
      connectionRefused: false,
      ids: [],
      fromDiskFallback: false
    };
  }
}

async function getRunningCascadeIds(port, csrfToken, timeoutMs = 4500, options = {}) {
  const res = await getRunningCascadeIdsDetailed(port, csrfToken, timeoutMs, options);
  return Array.isArray(res?.ids) ? res.ids : [];
}

function clearPendingAccountSwitchDrain(state) {
  if (!state || !state.__bhfPendingAccountSwitchDrain) {
    return;
  }
  try {
    if (state.__bhfPendingAccountSwitchDrain.timer) {
      clearInterval(state.__bhfPendingAccountSwitchDrain.timer);
    }
  } catch {}
  state.__bhfPendingAccountSwitchDrain = null;
}

function syncRetiringHubsToProxyAndDisk(state) {
  if (!state) return;
  const activePort = Number(state.serverManager?.port || getProxyState()?.upstreamPort || 0);
  const cleanList = normalizeRetiringHubsList(state.__bhfRetiringHubs || []).filter(
    (h) => h.port !== activePort
  );
  state.__bhfRetiringHubs = cleanList;
  try {
    const proxySt = getProxyState();
    if (proxySt) {
      proxySt.retiringHubs = cleanList.slice();
    }
  } catch {}
  try {
    const saved = readPersistentHubState();
    const curPort = Number(state.serverManager?.port || saved?.port || 0);
    const curCsrf = String(state.serverManager?.csrfToken || saved?.csrfToken || '').trim();
    if (curPort > 0 && curCsrf) {
      writePersistentHubState({
        pid: Number(state.serverManager?.serverProcess?.pid || saved?.pid || 0),
        port: curPort,
        csrfToken: curCsrf,
        serverUrl: state.serverManager?.serverUrl || saved?.serverUrl || `http://127.0.0.1:${curPort}`,
        startedAt: saved?.startedAt || Math.floor(Date.now() / 1000),
        consoleHidden: true,
        retiringHubs: cleanList
      });
    }
  } catch {}
}

function registerRetiringHub(state, hubEntry) {
  if (!state || !hubEntry) return;
  const port = Number(hubEntry.port || 0);
  const csrfToken = String(hubEntry.csrfToken || '').trim();
  const cascadeIds = Array.isArray(hubEntry.cascadeIds)
    ? Array.from(new Set(hubEntry.cascadeIds.map((id) => String(id || '').trim()).filter(Boolean)))
    : [];
  if (port <= 0 || !csrfToken || cascadeIds.length === 0) {
    return;
  }
  const currentList = Array.isArray(state.__bhfRetiringHubs) ? state.__bhfRetiringHubs.slice() : [];
  // Remove any newly claimed cascadeIds from older retiring hubs
  const claimedSet = new Set(cascadeIds);
  const updated = [];
  for (const existing of currentList) {
    if (!existing || Number(existing.port) === port) continue;
    const remIds = (existing.cascadeIds || []).filter((id) => !claimedSet.has(id));
    if (remIds.length > 0) {
      updated.push({ ...existing, cascadeIds: remIds });
    }
  }
  updated.push({
    pid: Number(hubEntry.pid || 0),
    port,
    csrfToken,
    serverUrl:
      typeof hubEntry.serverUrl === 'string' && hubEntry.serverUrl.trim()
        ? hubEntry.serverUrl.trim()
        : `http://127.0.0.1:${port}`,
    startedAt: Number(hubEntry.startedAt || Math.floor(Date.now() / 1000)),
    initialCascadeIds: cascadeIds.slice(),
    cascadeIds
  });
  state.__bhfRetiringHubs = updated;
  syncRetiringHubsToProxyAndDisk(state);
  ensureRetiringHubsMonitor(state);
}

function isCascadeRunningOnRetiringHub(state, cascadeId) {
  const cleanId = String(cascadeId || '').trim();
  if (!cleanId || !state || !Array.isArray(state.__bhfRetiringHubs)) {
    return false;
  }
  for (const h of state.__bhfRetiringHubs) {
    if (Array.isArray(h?.cascadeIds) && h.cascadeIds.includes(cleanId)) {
      return true;
    }
  }
  return false;
}

async function drainRetiringHubsOnce(state = getBridgeState(), options = {}) {
  if (!state || state.__bhfDrainingRetiringHubs) {
    return { activeRetiringHubs: state?.__bhfRetiringHubs?.length || 0, reapedHubs: 0 };
  }
  const list = Array.isArray(state.__bhfRetiringHubs) ? state.__bhfRetiringHubs.slice() : [];
  if (list.length === 0) {
    clearRetiringHubsMonitor(state);
    return { activeRetiringHubs: 0, reapedHubs: 0 };
  }
  const runTimeoutMs = Math.max(250, Number(options.runStateTimeoutMs) || 4500);
  state.__bhfDrainingRetiringHubs = true;
  let reapedHubs = 0;
  let changed = false;
  try {
    const proxySt = getProxyState();
    const activePort = Number(state.serverManager?.port || proxySt?.upstreamPort || 0);
    const remainingHubs = [];

    for (const hub of list) {
      const hPort = Number(hub?.port || 0);
      const hPid = Number(hub?.pid || 0);
      const hCsrf = String(hub?.csrfToken || '').trim();
      const prevIds = Array.isArray(hub?.cascadeIds) ? hub.cascadeIds.slice() : [];
      const bgCandidateIds = Array.from(
        new Set([
          ...(Array.isArray(hub?.initialCascadeIds) ? hub.initialCascadeIds : []),
          ...prevIds
        ])
      );
      if (hPort <= 0 || !hCsrf || hPort === activePort || prevIds.length === 0) {
        changed = true;
        continue;
      }

      const alive =
        hPid > 0
          ? isPidAlive(hPid)
          : (await probePersistentHub(hPort, hCsrf, Math.min(2500, runTimeoutMs), {
              checkAuth: false
            })) || (await probeTcpLoopbackAlive(hPort, 1000));

      let stillRunning = [];
      if (alive) {
        // Inspect ALL cascades on hPort for live CASCADE_RUN_STATUS_RUNNING (never filter by
        // onlyCascadeIds: prevIds, which would kill turns started after switch or after a brief
        // inter-step IDLE dip!), while scoping transcript background-task checks to bgCandidateIds.
        const runRes = await getRunningCascadeIdsDetailed(hPort, hCsrf, runTimeoutMs, {
          bgWaiterCandidateIds: bgCandidateIds,
          pid: hPid
        });
        if (
          !runRes.reachable &&
          !runRes.connectionRefused &&
          (runRes.timedOut || (await isHubBusyButAlive(hPort, hPid, { timedOut: true })))
        ) {
          // Retiring hub RPC timed out while busy: NEVER reap it prematurely!
          remainingHubs.push({
            ...hub,
            initialCascadeIds: bgCandidateIds,
            cascadeIds: prevIds
          });
          continue;
        }
        stillRunning = runRes.ids;
      }

      const stillSet = new Set(stillRunning);
      const prevSet = new Set(prevIds);
      const membershipChanged =
        stillRunning.length !== prevIds.length || stillRunning.some((id) => !prevSet.has(id));
      const finishedIds = prevIds.filter((id) => !stillSet.has(id));

      if (stillRunning.length === 0) {
        changed = true;
        reapedHubs += 1;
        // Update retiringHubs first so reconnecting sockets route to the active hub!
        state.__bhfRetiringHubs = (state.__bhfRetiringHubs || []).filter(
          (item) => Number(item?.port) !== hPort
        );
        syncRetiringHubsToProxyAndDisk(state);
        closeUpstreamSocketsForPort(proxySt, hPort);
        if (hPid > 0 && hPid !== Number(state.serverManager?.serverProcess?.pid || 0)) {
          await reapBrokenAgyHubPid(hPid);
        }
        notifyActivityChanged({
          type: 'retiring-hub-drained',
          port: hPort,
          finishedCascadeIds: prevIds
        });
      } else {
        if (finishedIds.length > 0 || membershipChanged) {
          changed = true;
        }
        closeUpstreamSocketsForPort(proxySt, hPort, { keepOnlyCascadeIds: stillRunning });
        remainingHubs.push({
          ...hub,
          initialCascadeIds: Array.from(new Set([...bgCandidateIds, ...stillRunning])),
          cascadeIds: stillRunning
        });
      }
    }

    if (changed) {
      state.__bhfRetiringHubs = remainingHubs;
      syncRetiringHubsToProxyAndDisk(state);
    }
    if (remainingHubs.length === 0) {
      clearRetiringHubsMonitor(state);
      if (reapedHubs > 0) {
        state.__bhfNeedsPostDrainDiskSync = true;
        schedulePostDrainTrajectoryDiskSync(state, 4000);
        scheduleInterruptedCascadeCheck(state, 2000, {
          bypassMinAge: true,
          hubStartedAtSec: Math.floor(Date.now() / 1000)
        });
      }
    }
    return { activeRetiringHubs: remainingHubs.length, reapedHubs };
  } finally {
    state.__bhfDrainingRetiringHubs = false;
  }
}

function clearPostDrainDiskSyncTimer(state) {
  if (!state || !state.__bhfPostDrainSyncTimer) return;
  try {
    clearTimeout(state.__bhfPostDrainSyncTimer);
  } catch {}
  state.__bhfPostDrainSyncTimer = null;
}

async function maybeSyncDrainedTrajectoriesWhenIdle(state = getBridgeState()) {
  if (!state || !state.__bhfNeedsPostDrainDiskSync) {
    return false;
  }
  if (
    state.__bhfAccountSwitchRestartPromise ||
    state.__bhfDrainingRetiringHubs ||
    (Array.isArray(state.__bhfRetiringHubs) && state.__bhfRetiringHubs.length > 0) ||
    process.env.THEO_DISABLE_HUB_PROCESS_REAP === '1'
  ) {
    return false;
  }
  const saved = readPersistentHubState();
  const proxySt = getProxyState();
  const curPid = Number(state.serverManager?.serverProcess?.pid || saved?.pid || 0);
  const curPort = Number(state.serverManager?.port || proxySt?.upstreamPort || saved?.port || 0);
  const curCsrf = String(
    state.serverManager?.csrfToken || proxySt?.csrfToken || saved?.csrfToken || ''
  ).trim();
  if (curPid <= 0 || curPort <= 0 || !curCsrf) {
    state.__bhfNeedsPostDrainDiskSync = false;
    return false;
  }
  const runRes = await getRunningCascadeIdsDetailed(curPort, curCsrf, 3500, { pid: curPid });
  if (!runRes.reachable || runRes.ids.length > 0) {
    return false;
  }
  state.__bhfNeedsPostDrainDiskSync = false;
  await restartHubForAccountSwitch(state, {
    forceSpawnNewHub: true,
    preserveAutoSwitchCooldown: true,
    forceRenderTabs: false
  });
  return true;
}

function schedulePostDrainTrajectoryDiskSync(state, delayMs = 4000) {
  if (!state || !state.__bhfNeedsPostDrainDiskSync) return;
  clearPostDrainDiskSyncTimer(state);
  const curPid = Number(
    state.serverManager?.serverProcess?.pid || readPersistentHubState()?.pid || 0
  );
  if (curPid <= 0 || process.env.THEO_DISABLE_HUB_PROCESS_REAP === '1') {
    state.__bhfNeedsPostDrainDiskSync = false;
    return;
  }
  const timer = setTimeout(() => {
    state.__bhfPostDrainSyncTimer = null;
    maybeSyncDrainedTrajectoriesWhenIdle(state).catch(() => {});
  }, delayMs);
  if (typeof timer?.unref === 'function') {
    timer.unref();
  }
  state.__bhfPostDrainSyncTimer = timer;
}

function clearRetiringHubsMonitor(state) {
  if (!state) {
    return;
  }
  clearPostDrainDiskSyncTimer(state);
  if (!state.__bhfRetiringHubsTimer) {
    return;
  }
  try {
    clearInterval(state.__bhfRetiringHubsTimer);
  } catch {}
  state.__bhfRetiringHubsTimer = null;
}

function ensureRetiringHubsMonitor(state = getBridgeState()) {
  if (!state) return;
  if (!Array.isArray(state.__bhfRetiringHubs) || state.__bhfRetiringHubs.length === 0) {
    clearRetiringHubsMonitor(state);
    return;
  }
  if (state.__bhfRetiringHubsTimer) {
    return;
  }
  const timer = setInterval(() => {
    drainRetiringHubsOnce(state).catch(() => {});
  }, 1000);
  if (typeof timer?.unref === 'function') {
    timer.unref();
  }
  state.__bhfRetiringHubsTimer = timer;
}

async function restartHubForAccountSwitch(state = getBridgeState(), options = {}) {
  if (!state) {
    return { ok: false, error: 'Bridge state unavailable' };
  }
  if (!options.preserveAutoSwitchCooldown) {
    state.__bhfLastAutoEmailSwitchTarget = '';
    state.__bhfLastAutoEmailSwitchAt = 0;
  }
  if (state.__bhfAccountSwitchRestartPromise) {
    return state.__bhfAccountSwitchRestartPromise;
  }
  const runTimeoutMs = Math.max(250, Number(options.runStateTimeoutMs) || 4500);
  state.__bhfAccountSwitchRestartPromise = (async () => {
    try {
      const saved = readPersistentHubState();
      const proxySt = getProxyState();
      const oldPid = Number(state.serverManager?.serverProcess?.pid || saved?.pid || 0);
      const oldPort = Number(
        state.serverManager?.port || proxySt?.upstreamPort || saved?.port || 0
      );
      const oldStartedAt = Number(saved?.startedAt || Math.floor(Date.now() / 1000));
      const keepCsrf = String(
        state.serverManager?.csrfToken || proxySt?.csrfToken || saved?.csrfToken || ''
      ).trim();

      clearPendingAccountSwitchDrain(state);
      clearPostDrainDiskSyncTimer(state);

      // 0. Sync keyring to target account FIRST, then attempt fast in-place credential hot-swap on the
      // already-running agy.exe --hub process (HasAuthToken + GetAuthStatus -> syncWithStoredToken).
      // When agy.exe updates its OAuth client in-place, active sessions keep running uninterrupted on the
      // single hub with zero split-brain Go RAM cache and zero WebSocket drop!
      const syncInfo = await ensureExpectedAntigravityKeyringSync(state, options);
      const targetEmail = String(options.expectedEmail || syncInfo?.expectedEmail || '')
        .trim()
        .toLowerCase();
      if (oldPort > 0 && keepCsrf && targetEmail && !options.forceSpawnNewHub) {
        const hotRes = await tryHotReloadHubAuthInPlace(
          state,
          oldPort,
          keepCsrf,
          targetEmail,
          Math.min(2500, runTimeoutMs)
        );
        if (hotRes.ok) {
          const oldUrl =
            state.serverManager?.serverUrl ||
            saved?.serverUrl ||
            `http://127.0.0.1:${oldPort}`;
          syncRendererAndProxyServerUrl(state, oldUrl, oldPort, keepCsrf);
          if (saved?.port === oldPort || oldPid > 0) {
            writePersistentHubState({
              pid: oldPid,
              port: oldPort,
              csrfToken: keepCsrf,
              serverUrl: oldUrl,
              startedAt: oldStartedAt,
              consoleHidden: true,
              retiringHubs: Array.isArray(state.__bhfRetiringHubs) ? state.__bhfRetiringHubs : []
            });
          }
          notifyActivityChanged({
            type: 'account-switched-in-place',
            port: oldPort,
            email: hotRes.liveEmail
          });
          return {
            ok: true,
            inPlaceAuthReload: true,
            port: oldPort,
            liveEmail: hotRes.liveEmail,
            seamlessCutoverCount:
              state.entriesByUriKey instanceof Map ? state.entriesByUriKey.size : 0,
            retiringHubPort: 0,
            retiringCascadeIds: [],
            interruptedIds: []
          };
        }
      }

      // 1. Snapshot any cascades actively running (or waiting on background tasks/subagents) on oldPort BEFORE spawning newPort.
      let initialOldRunningIds = [];
      if (oldPort > 0 && keepCsrf) {
        try {
          const initCheck = await getRunningCascadeIdsDetailed(oldPort, keepCsrf, runTimeoutMs, {
            pid: oldPid
          });
          initialOldRunningIds = initCheck.ids;
        } catch {}
      }

      // 2. Parallel-Hub Make-Before-Break Cutover:
      // Spawn newPid immediately (zero waiting for 10-40 min turns!) while oldPid stays alive serving oldPort.
      // Because each conversation is stored in its own per-conversation SQLite file (conversations/<cascadeId>.db),
      // oldPid can continue running active turns on its conversation DBs in the background while newPid immediately
      // takes over all idle tabs and new sessions under the newly selected account!
      try {
        fs.unlinkSync(getPersistentHubStateFilePath());
      } catch {}

      silenceServerManagerCrashSignals(state.serverManager);
      clearUpstreamServerState(state, {
        mintFreshCsrf: false,
        preserveProxyUpstream: oldPort > 0
      });
      if (state.serverManager && keepCsrf) {
        state.serverManager.csrfToken = keepCsrf;
      }

      let newPort = 0;
      let newCsrf = keepCsrf;
      let newUrl = '';
      let newPid = 0;
      let healthy = false;

      if (state.serverManager && typeof state.serverManager.start === 'function') {
        await ensureExpectedAntigravityKeyringSync(state, options);
        state.__bhfSuppressReapDuringStart = true;
        state.__bhfDeferProxyCutoverDuringStart = true;
        try {
          await state.serverManager.start({ context: state.context });
        } finally {
          state.__bhfSuppressReapDuringStart = false;
          state.__bhfDeferProxyCutoverDuringStart = false;
        }
        newPort = Number(state.serverManager.port || 0);
        newCsrf = String(state.serverManager.csrfToken || keepCsrf || '').trim();
        newUrl =
          state.serverManager.serverUrl ||
          (newPort > 0 ? `http://127.0.0.1:${newPort}` : '');
        newPid = Number(
          state.serverManager.serverProcess?.pid || readPersistentHubState()?.pid || 0
        );
        healthy =
          newPort > 0 && newCsrf
            ? await probePersistentHubWithRetry(newPort, newCsrf, 3, 2000, {
                checkAuth: false
              })
            : false;
        // On real agy.exe processes, wait up to ~3.5s for OAuth initialization ("Auth succeeded") while oldPort
        // continues serving open tabs uninterrupted!
        if (
          healthy &&
          newPid > 0 &&
          process.env.THEO_DISABLE_HUB_PROCESS_REAP !== '1'
        ) {
          await probePersistentHubWithRetry(newPort, newCsrf, 4, 1500, {
            checkAuth: true,
            checkEmailMatch: false
          }).catch(() => false);
        }
      }

      // Re-check which cascades are still actively running on oldPort right as newPort is ready
      let stillRunningOnOld = [];
      if (oldPort > 0 && keepCsrf && oldPort !== newPort) {
        try {
          const liveCheck = await getRunningCascadeIdsDetailed(oldPort, keepCsrf, runTimeoutMs, {
            pid: oldPid
          });
          if (liveCheck.reachable) {
            stillRunningOnOld = liveCheck.ids;
          } else if (!liveCheck.connectionRefused) {
            // Never clear stillRunningOnOld when GetAllCascadeTrajectories timed out on a busy retiring hub!
            stillRunningOnOld = Array.from(
              new Set([...initialOldRunningIds, ...(liveCheck.ids || [])])
            );
          }
        } catch {
          stillRunningOnOld = initialOldRunningIds;
        }
      }

      const hubCutoverAtSec = Math.floor(Date.now() / 1000);
      const keepOldAliveForRetiring =
        healthy &&
        oldPort > 0 &&
        oldPort !== newPort &&
        stillRunningOnOld.length > 0 &&
        !options.forceKillRunning;

      if (keepOldAliveForRetiring) {
        // Register oldPort as a retiring background drain hub for its active cascades!
        registerRetiringHub(state, {
          pid: oldPid,
          port: oldPort,
          csrfToken: keepCsrf,
          serverUrl: `http://127.0.0.1:${oldPort}`,
          startedAt: oldStartedAt,
          cascadeIds: stillRunningOnOld
        });
      } else if (healthy && oldPid > 0 && oldPid !== newPid) {
        // No cascades are running on oldPort: reap oldPid BEFORE redirecting traffic so *.db handles are released first.
        await reapBrokenAgyHubPid(oldPid);
        if (process.env.THEO_DISABLE_HUB_PROCESS_REAP !== '1') {
          await new Promise((r) => setTimeout(r, 60));
        }
      }

      if (healthy && newPort > 0 && newCsrf) {
        syncRendererAndProxyServerUrl(state, newUrl, newPort, newCsrf);
        syncRetiringHubsToProxyAndDisk(state);
        ensureAntigravityTelemetryDisabled(newPort, newCsrf).catch(() => {});
      }

      // 3. Zero-reload WebSocket cutover when csrfToken is preserved; keep retiring cascades pinned to oldPort until done.
      const csrfPreserved = Boolean(keepCsrf && newCsrf && keepCsrf === newCsrf);
      const retiringCascadeSet = new Set(keepOldAliveForRetiring ? stillRunningOnOld : []);
      let seamlessCutoverCount = 0;
      if (healthy && csrfPreserved && newPort > 0 && state.entriesByUriKey instanceof Map) {
        for (const entry of state.entriesByUriKey.values()) {
          if (!entry?.panel) continue;
          const entryCid = String(entry.conversationId || entry.initialConversationId || '').trim();
          if (entry.iframeReady && entry.renderedPort > 0) {
            if (entryCid && retiringCascadeSet.has(entryCid)) {
              entry.renderedPort = newPort;
              entry.needsDeferredReconnect = false;
              continue;
            }
            entry.renderedPort = newPort;
            entry.needsDeferredReconnect = false;
            seamlessCutoverCount += 1;
          }
        }
      }

      if (healthy && oldPort > 0 && oldPort !== newPort) {
        if (keepOldAliveForRetiring) {
          closeUpstreamSocketsForPort(proxySt, oldPort, {
            keepOnlyCascadeIds: stillRunningOnOld
          });
        } else {
          closeUpstreamSocketsForPort(proxySt, oldPort);
        }
      }

      // 4. Reap duplicate hub processes while protecting newPid and any retiring hub PIDs.
      if (!keepOldAliveForRetiring && oldPid > 0 && oldPid !== newPid) {
        await reapBrokenAgyHubPid(oldPid);
      }
      if (newPid > 0) {
        await reapDuplicateAgyHubProcesses(getProtectedHubPids(state, newPid));
      }

      const res = await reconnectAllOpenTabs(state, {
        forceRestart: !healthy,
        forceRender: !csrfPreserved || Boolean(options.forceRenderTabs),
        skipEmailMismatchAutoSwitch: true
      });
      if (healthy && !keepOldAliveForRetiring) {
        const resumeOpts = {
          bypassMinAge: true,
          forceResumeIds: [],
          hubStartedAtSec: hubCutoverAtSec
        };
        scheduleInterruptedCascadeCheck(state, 2200, resumeOpts);
        scheduleInterruptedCascadeCheck(state, 7500, resumeOpts);
      }
      return {
        ...res,
        ok: Boolean(healthy || res?.ok),
        port: Number(res?.port || newPort || 0),
        seamlessCutoverCount,
        retiringHubPort: keepOldAliveForRetiring ? oldPort : 0,
        retiringCascadeIds: keepOldAliveForRetiring ? stillRunningOnOld : [],
        interruptedIds: []
      };
    } catch (err) {
      return { ok: false, error: String(err?.message || err || '') };
    } finally {
      state.__bhfAccountSwitchRestartPromise = null;
    }
  })();
  return state.__bhfAccountSwitchRestartPromise;
}

function ensureUpstreamAlive(failedPort = 0, state = getBridgeState()) {
  if (!state || !state.serverManager) {
    return Promise.resolve({ ok: false });
  }
  if (state.__bhfAccountSwitchRestartPromise) {
    return state.__bhfAccountSwitchRestartPromise;
  }
  if (state.__bhfEnsureUpstreamPromise) {
    return state.__bhfEnsureUpstreamPromise;
  }
  const now = Date.now();
  const proxySt = getProxyState();
  const currentPort = Number(state.serverManager?.port || proxySt?.upstreamPort || 0);
  if (
    failedPort > 0 &&
    currentPort > 0 &&
    currentPort !== Number(failedPort) &&
    now - Number(state.__bhfLastEnsureUpstreamAt || 0) < 4000
  ) {
    return Promise.resolve({ ok: true, port: currentPort });
  }
  if (now - Number(state.__bhfLastEnsureUpstreamAt || 0) < 2500) {
    return Promise.resolve({ ok: currentPort > 0, port: currentPort });
  }
  state.__bhfLastEnsureUpstreamAt = now;
  state.__bhfEnsureUpstreamPromise = reconnectAllOpenTabs(state, {
    forceRestart: false,
    forceRender: false
  })
    .catch((err) => ({ ok: false, error: String(err?.message || err || '') }))
    .finally(() => {
      state.__bhfEnsureUpstreamPromise = null;
    });
  return state.__bhfEnsureUpstreamPromise;
}

async function openNewSessionTab(options = {}) {
  const state = getBridgeState();
  const vscode = state.vscode;
  if (!vscode) {
    return null;
  }
  normalizeLiveEntriesMap(state);
  if (!(state.pendingPromptUriKeys instanceof Set)) {
    state.pendingPromptUriKeys = new Set();
  }

  // If reuseEmptyDraft is requested (e.g. when sending a prompt to a new session while an
  // untouched blank draft tab is already open), reuse the existing empty draft tab only if
  // its iframe is alive and ready, and close any extra or broken blank draft tabs.
  if (options.reuseEmptyDraft) {
    const emptyDraftEntries = [];
    for (const entry of state.entriesByUriKey.values()) {
      if (
        entry &&
        entry.panel &&
        !entry.conversationId &&
        !entry.initialConversationId &&
        !entry.promptSent &&
        parseSessionUri(entry.uriKey).kind === 'new'
      ) {
        if (entry.instance && entry.iframeReady) {
          emptyDraftEntries.push(entry);
        } else {
          try {
            entry.panel?.dispose?.();
          } catch {}
        }
      }
    }
    if (emptyDraftEntries.length > 0) {
      const chosen =
        emptyDraftEntries.find((e) => e.panel?.active) ||
        emptyDraftEntries[emptyDraftEntries.length - 1];
      for (const extra of emptyDraftEntries) {
        if (extra !== chosen) {
          try {
            extra.panel?.dispose?.();
          } catch {}
        }
      }
      if (options.pendingPromptSend) {
        chosen.pendingPromptSend = true;
      }
      const viewColumn = resolveTargetColumn(vscode, { ...options, uriKey: chosen.uriKey });
      const wantReuseFocus = !options.preserveFocus && !options.beside;
      if (wantReuseFocus) {
        setOpeningTarget(state, { uriKey: chosen.uriKey });
      }
      if (!(options.avoidTabReveal && options.preserveFocus)) {
        try {
          chosen.panel.reveal(
            options.beside ? vscode.ViewColumn.Beside : chosen.panel.viewColumn || viewColumn,
            Boolean(options.preserveFocus)
          );
        } catch {}
      }
      const parsedDraft = parseSessionUri(chosen.uriKey);
      notifyActivityChanged({
        type: wantReuseFocus ? 'open-new' : 'open-new-bg',
        uri: chosen.uriKey,
        preserveFocus: Boolean(options.preserveFocus),
        beside: Boolean(options.beside)
      });
      return { uri: chosen.uriKey, draftId: parsedDraft.draftId || '', reused: true };
    }
  }

  const draftId = options.draftId || makeDraftId();
  const uriString = buildNewSessionUriString(draftId);
  const wantFocus = !options.preserveFocus;
  const openSeq = wantFocus && !options.beside ? setOpeningTarget(state, { uriKey: uriString }) : 0;
  if (wantFocus) {
    if (!(state.__bhfPendingFocusByUri instanceof Map)) {
      state.__bhfPendingFocusByUri = new Map();
    }
    state.__bhfPendingFocusByUri.set(uriString, {
      until: Date.now() + 4500,
      seq: openSeq
    });
  }
  if (options.pendingPromptSend) {
    state.pendingPromptUriKeys.add(uriString);
  }
  const uri = vscode.Uri.parse(uriString);
  await writeTabState(state.context?.workspaceState, uriString, {
    id: '',
    title: 'Antigravity',
    createdAt: Date.now()
  });
  const viewColumn = resolveTargetColumn(vscode, { ...options, uriKey: uriString });
  // Open with preserveFocus: true first so VS Code's EditorGroupView resolves custom-editor input
  // and swaps WebviewEditor to the new tab's overlay before activating Group 1 (zero focus bounce on outgoing tab).
  await vscode.commands.executeCommand('vscode.openWith', uri, SESSION_TAB_VIEW_TYPE, {
    viewColumn,
    preview: false,
    preserveFocus: true
  });
  normalizeLiveEntriesMap(state);
  const openedEntry = findEntryByUriKey(state, uriString);
  if (options.pendingPromptSend && openedEntry) {
    openedEntry.pendingPromptSend = true;
  }
  const isSuperseded = Boolean(openSeq && state.__bhfOpenSeq !== openSeq);
  if (wantFocus && !isSuperseded && openedEntry?.panel) {
    state.__bhfPendingFocusByUri?.delete?.(uriString);
    try {
      openedEntry.panel.reveal(
        options.beside ? vscode.ViewColumn.Beside : openedEntry.panel.viewColumn || viewColumn,
        false
      );
    } catch {}
  }
  notifyActivityChanged({
    type: !wantFocus || options.beside || isSuperseded ? 'open-new-bg' : 'open-new',
    uri: uriString,
    preserveFocus: Boolean(options.preserveFocus || isSuperseded),
    beside: Boolean(options.beside)
  });
  return { uri: uriString, draftId, reused: false };
}

async function openConversationTab(options = {}) {
  const state = getBridgeState();
  const vscode = state.vscode;
  if (!vscode) {
    return null;
  }
  const threadId = String(options.id || options.threadId || '').trim();
  if (!threadId) {
    return openNewSessionTab(options);
  }

  const title = resolveTabTitle(threadId, options.title || '');

  // If this thread is already open in any panel (whether opened via /local/<id> or bound from /new?draft=...),
  // reveal the existing panel immediately (unless avoidTabReveal+preserveFocus is set for background resume),
  // then recover/re-render its iframe only if disconnected or on a stale upstream port.
  const existingEntry = findOpenEntryByThreadId(threadId);
  if (existingEntry?.panel) {
    const viewColumn = resolveTargetColumn(vscode, {
      ...options,
      uriKey: existingEntry.uriKey
    });
    const wantForegroundReveal = !options.preserveFocus && !options.beside;
    const openSeq = wantForegroundReveal
      ? setOpeningTarget(state, { threadId, uriKey: existingEntry.uriKey })
      : 0;
    if (options.pendingPromptSend) {
      existingEntry.pendingPromptSend = true;
    }
    const prevConversationId = existingEntry.conversationId;
    existingEntry.conversationId = threadId;
    if (!existingEntry.initialConversationId) {
      existingEntry.initialConversationId = threadId;
    }
    if (!(options.avoidTabReveal && options.preserveFocus)) {
      existingEntry.panel.reveal(
        options.beside ? vscode.ViewColumn.Beside : existingEntry.panel.viewColumn || viewColumn,
        Boolean(options.preserveFocus)
      );
    }
    if (title && title !== 'Antigravity') {
      existingEntry.title = title;
      existingEntry.panel.title = title;
    }
    if (!options.preserveFocus) {
      if (existingEntry.badgeState === 'done' || state.badgeById.get(threadId) === 'done') {
        applyEntryTabIcon(state, existingEntry, 'plain');
      }
      notifyThreadSeen(threadId);
    }
    const curPort = Number(state.serverManager?.port || getProxyState()?.upstreamPort || 0);
    const renderAgeMs = Date.now() - Number(existingEntry.lastRenderAt || 0);
    const needsReRender =
      !existingEntry.__bhfRenderInFlight &&
      (Boolean(options.forceReconnect) ||
        Boolean(existingEntry.needsDeferredReconnect) ||
        (curPort > 0 && existingEntry.renderedPort > 0 && existingEntry.renderedPort !== curPort) ||
        ((!existingEntry.instance || !existingEntry.iframeReady) && renderAgeMs >= 8000));
    if (existingEntry.__bhfRenderInFlight && existingEntry.__bhfRenderPromise) {
      if (options.pendingPromptSend || options.forceReconnect) {
        await existingEntry.__bhfRenderPromise;
      }
    } else if (needsReRender && state.renderer && typeof state.renderer.renderJetskiIframe === 'function') {
      existingEntry.needsDeferredReconnect = false;
      existingEntry.iframeReady = false;
      existingEntry.renderedPort = curPort;
      existingEntry.lastRenderAt = Date.now();
      existingEntry.__bhfRenderInFlight = true;
      const renderPromise = Promise.resolve(
        state.renderer.renderJetskiIframe(existingEntry.panel, {
          targetRoute: `c/${threadId}`,
          type: 'main',
          location: 'editor'
        })
      )
        .catch(() => {})
        .finally(() => {
          existingEntry.__bhfRenderInFlight = false;
          if (existingEntry.__bhfRenderPromise === renderPromise) {
            existingEntry.__bhfRenderPromise = null;
          }
        });
      existingEntry.__bhfRenderPromise = renderPromise;
      if (options.pendingPromptSend || options.forceReconnect) {
        await renderPromise;
      }
    } else if (prevConversationId !== threadId || Boolean(options.forceNavigate)) {
      try {
        existingEntry.instance?.api?.navigate?.({ path: `/c/${threadId}` });
      } catch {}
    }
    const isSupersededReveal = Boolean(openSeq && state.__bhfOpenSeq !== openSeq);
    notifyActivityChanged({
      type: !wantForegroundReveal || isSupersededReveal ? 'reveal-bg' : 'reveal',
      threadId,
      uri: existingEntry.uriKey,
      preserveFocus: Boolean(options.preserveFocus || isSupersededReveal),
      beside: Boolean(options.beside)
    });
    return { uri: existingEntry.uriKey, id: threadId, revealed: true };
  }

  // Check if a draft tab in workspaceState was already bound to this threadId (including restored unresolved background tabs)
  let uriString = buildThreadUriString(threadId);
  const draftBound = findDraftTabEntryForThread(state.context?.workspaceState, threadId);
  if (
    draftBound?.uriKey &&
    (state.entriesByUriKey.has(draftBound.uriKey) || isUriOpenInTabGroups(vscode, draftBound.uriKey))
  ) {
    uriString = draftBound.uriKey;
  }

  const viewColumn = resolveTargetColumn(vscode, { ...options, uriKey: uriString });
  const wantFocus = !options.preserveFocus;
  const openSeq =
    wantFocus && !options.beside ? setOpeningTarget(state, { threadId, uriKey: uriString }) : 0;
  if (wantFocus) {
    if (!(state.__bhfPendingFocusByUri instanceof Map)) {
      state.__bhfPendingFocusByUri = new Map();
    }
    state.__bhfPendingFocusByUri.set(uriString, {
      until: Date.now() + 4500,
      seq: openSeq
    });
  }

  if (options.pendingPromptSend) {
    if (!(state.pendingPromptUriKeys instanceof Set)) {
      state.pendingPromptUriKeys = new Set();
    }
    state.pendingPromptUriKeys.add(uriString);
  }

  if (title && title !== 'Antigravity') {
    state.titleById.set(threadId, title);
  }
  const saveStatePromise = Promise.resolve(
    writeTabState(state.context?.workspaceState, uriString, {
      id: threadId,
      title
    })
  ).catch(() => {});

  if (wantFocus && !options.beside) {
    notifyThreadSeen(threadId);
  }

  const uri = vscode.Uri.parse(uriString);
  // Open with preserveFocus: true first so VS Code's EditorGroupView resolves custom-editor input
  // and swaps WebviewEditor to the target tab's overlay before activating Group 1 (zero focus bounce on outgoing tab).
  await vscode.commands.executeCommand('vscode.openWith', uri, SESSION_TAB_VIEW_TYPE, {
    viewColumn,
    preview: false,
    preserveFocus: true
  });
  normalizeLiveEntriesMap(state);
  const isSuperseded = Boolean(openSeq && state.__bhfOpenSeq !== openSeq);
  if (wantFocus && !isSuperseded) {
    const openedEntry =
      findEntryByUriKey(state, uriString) || (threadId ? findOpenEntryByThreadId(threadId) : null);
    if (openedEntry?.panel) {
      state.__bhfPendingFocusByUri?.delete?.(uriString);
      try {
        openedEntry.panel.reveal(
          options.beside ? vscode.ViewColumn.Beside : openedEntry.panel.viewColumn || viewColumn,
          false
        );
      } catch {}
    }
  }
  await saveStatePromise;
  notifyActivityChanged({
    type: !wantFocus || options.beside || isSuperseded ? 'open-thread-bg' : 'open-thread',
    threadId,
    uri: uriString,
    preserveFocus: Boolean(options.preserveFocus || isSuperseded),
    beside: Boolean(options.beside)
  });
  return { uri: uriString, id: threadId, revealed: false };
}

async function syncTabTitle(options = {}) {
  const state = getBridgeState();
  const threadId = String(options.id || options.threadId || '').trim();
  const cleanTitle = normalizeTabText(options.title || '', 56);
  if (!threadId || !cleanTitle) {
    return false;
  }
  state.titleById.set(threadId, cleanTitle);

  let updated = false;
  for (const entry of state.entriesByUriKey.values()) {
    if (entry && entry.conversationId === threadId && entry.panel) {
      entry.title = cleanTitle;
      entry.panel.title = cleanTitle;
      await writeTabState(state.context?.workspaceState, entry.uriKey, {
        id: threadId,
        title: cleanTitle
      });
      updated = true;
    }
  }

  const directUri = buildThreadUriString(threadId);
  await writeTabState(state.context?.workspaceState, directUri, {
    id: threadId,
    title: cleanTitle
  });
  return updated;
}

async function closeConversationTab(options = {}) {
  const state = getBridgeState();
  normalizeLiveEntriesMap(state);
  const vscode = state.vscode;
  const threadId = String(options.id || options.threadId || '').trim();
  const rawUri = String(options.uri || options.key || '').trim();
  const cleanUri = rawUri ? normalizeUriKey(rawUri) : '';
  if (!threadId && !cleanUri) {
    return false;
  }
  let closed = false;
  for (const entry of Array.from(state.entriesByUriKey.values())) {
    if (
      entry &&
      entry.panel &&
      ((threadId && entry.conversationId === threadId) ||
        (cleanUri && normalizeUriKey(entry.uriKey) === cleanUri))
    ) {
      try {
        entry.panel.dispose();
        closed = true;
      } catch {}
    }
  }
  const groups = vscode?.window?.tabGroups?.all || [];
  for (const group of groups) {
    for (const tab of group.tabs || []) {
      const inputUri = tab?.input?.uri;
      if (!inputUri || inputUri.scheme !== SESSION_TAB_SCHEME) {
        continue;
      }
      const uriKey = normalizeUriKey(inputUri);
      const parsed = parseSessionUri(uriKey);
      const saved = readTabState(state.context?.workspaceState, uriKey);
      const tabThreadId = parsed.kind === 'thread' ? parsed.threadId : saved?.id || '';
      if (
        (cleanUri && uriKey === cleanUri) ||
        (threadId && tabThreadId === threadId)
      ) {
        try {
          await vscode.window.tabGroups.close(tab);
          closed = true;
        } catch {}
      }
    }
  }
  return closed;
}

function getSessionTabGroupsSnapshot(vscode) {
  const byColumn = new Map();
  const tabInfoByUriKey = new Map();
  const groups = Array.isArray(vscode?.window?.tabGroups?.all) ? vscode.window.tabGroups.all : [];
  const activeGroup =
    vscode?.window?.tabGroups?.activeTabGroup ||
    groups.find((g) => Boolean(g?.isActive)) ||
    (groups.length === 1 ? groups[0] : null);
  let activeGroupHasAnyActiveTab = false;

  for (const group of groups) {
    const tabs = Array.isArray(group?.tabs) ? group.tabs : [];
    const activeTab = group?.activeTab || tabs.find((t) => Boolean(t?.isActive)) || null;
    const col = group?.viewColumn || 1;
    const groupActive = Boolean(activeGroup ? group === activeGroup : group?.isActive);
    if (groupActive && activeTab) {
      activeGroupHasAnyActiveTab = true;
    }
    for (const tab of tabs) {
      const inputUri = tab?.input?.uri;
      if (!inputUri || inputUri.scheme !== SESSION_TAB_SCHEME) {
        continue;
      }
      const uKey = normalizeUriKey(inputUri);
      if (!uKey) {
        continue;
      }
      const tabActiveInGroup = Boolean(tab === activeTab || tab?.isActive);
      const isAuthoritativeActive = Boolean(groupActive && tabActiveInGroup);
      const prev = tabInfoByUriKey.get(uKey);
      if (!prev || isAuthoritativeActive || (!prev.isAuthoritativeActive && tabActiveInGroup)) {
        tabInfoByUriKey.set(uKey, {
          viewColumn: col,
          groupActive,
          tabActiveInGroup,
          isAuthoritativeActive,
          label: tab?.label || ''
        });
      }
    }
    if (!activeTab) {
      continue;
    }
    const inputUri = activeTab?.input?.uri;
    const isAgySession = Boolean(inputUri && inputUri.scheme === SESSION_TAB_SCHEME);
    byColumn.set(col, {
      groupActive,
      activeSessionUriKey: isAgySession ? normalizeUriKey(inputUri) : '',
      hasOtherActiveTab: !isAgySession
    });
  }

  return {
    hasTabGroups: groups.length > 0,
    groups,
    activeGroup,
    activeGroupHasAnyActiveTab,
    byColumn,
    tabInfoByUriKey
  };
}

function getActiveGroupInfoByColumn(vscode) {
  return getSessionTabGroupsSnapshot(vscode).byColumn;
}

function getOpenTabsSnapshot() {
  const state = getBridgeState();
  normalizeLiveEntriesMap(state);
  const vscode = state.vscode;
  const result = [];
  const seenKeys = new Set();
  const tg = getSessionTabGroupsSnapshot(vscode);

  const nowMs = Date.now();
  const curOpening =
    state.__bhfOpeningTarget && nowMs < Number(state.__bhfOpeningTarget.until || 0)
      ? state.__bhfOpeningTarget
      : null;

  for (const entry of state.entriesByUriKey.values()) {
    if (!entry || !entry.panel || entry.__bhfDisposed) {
      continue;
    }
    const normKey = normalizeUriKey(entry.uriKey || entry.uri);
    if (normKey) {
      entry.uriKey = normKey;
    }
    const tabInfo = normKey ? tg.tabInfoByUriKey.get(normKey) : null;
    if (tabInfo) {
      entry.__bhfSeenInTabGroups = true;
    } else if (tg.hasTabGroups && normKey && (entry.__bhfSeenInTabGroups || Boolean(vscode?.version))) {
      const isJustOpening = Boolean(
        nowMs - Number(entry.resolvedAt || 0) < 450 &&
          curOpening &&
          ((curOpening.uriKey && curOpening.uriKey === normKey) ||
            (curOpening.threadId &&
              entry.conversationId &&
              curOpening.threadId === entry.conversationId))
      );
      if (!isJustOpening) {
        // Tab was already closed in vscode.window.tabGroups while WebviewPanel teardown is still async
        continue;
      }
    }
    if (normKey) {
      seenKeys.add(normKey);
    }
    const viewColumn = tabInfo?.viewColumn || entry.panel.viewColumn || 1;
    let isActive = Boolean(entry.panel.active);
    let isVisible = Boolean(entry.panel.visible);
    if (tabInfo) {
      // Authoritative tabGroups resolution: promotes active=true when workbench focus is in
      // THEO Sidebar / Terminal / external window, and strictly demotes inactive tabs.
      isActive = tabInfo.isAuthoritativeActive;
      isVisible = Boolean(tabInfo.tabActiveInGroup);
    } else if (tg.hasTabGroups) {
      const colInfo = tg.byColumn.get(viewColumn);
      if (isActive && colInfo) {
        if (
          !colInfo.groupActive ||
          colInfo.hasOtherActiveTab ||
          (colInfo.activeSessionUriKey && normKey && colInfo.activeSessionUriKey !== normKey)
        ) {
          isActive = false;
        }
      } else if (isActive && tg.activeGroupHasAnyActiveTab) {
        isActive = false;
      }
    }
    const parsedEntry = normKey ? parseSessionUri(normKey) : null;
    const effectiveId =
      (parsedEntry?.kind === 'thread' ? parsedEntry.threadId : '') || entry.conversationId || '';
    result.push({
      uri: normKey || entry.uriKey,
      id: effectiveId,
      title: entry.title || entry.panel.title || 'Antigravity',
      active: isActive,
      visible: isVisible,
      viewColumn,
      createdAt: Number(entry.resolvedAt || 0)
    });
  }

  // Also inspect vscode.window.tabGroups for any tab restored by VS Code that hasn't resolved yet
  for (const group of tg.groups) {
    const groupActive = Boolean(tg.activeGroup ? group === tg.activeGroup : group?.isActive);
    const tabs = Array.isArray(group?.tabs) ? group.tabs : [];
    const activeTab = group?.activeTab || tabs.find((t) => Boolean(t?.isActive)) || null;
    for (const tab of tabs) {
      const inputUri = tab?.input?.uri;
      if (!inputUri || inputUri.scheme !== SESSION_TAB_SCHEME) {
        continue;
      }
      const uriKey = normalizeUriKey(inputUri);
      if (!uriKey || seenKeys.has(uriKey)) {
        continue;
      }
      seenKeys.add(uriKey);
      const parsed = parseSessionUri(uriKey);
      const saved = readTabState(state.context?.workspaceState, uriKey);
      const id = parsed.kind === 'thread' ? parsed.threadId : saved?.id || '';
      const tabActiveInGroup = Boolean(tab === activeTab || tab?.isActive);
      result.push({
        uri: uriKey,
        id,
        title: saved?.title || tab.label || 'Antigravity',
        active: Boolean(groupActive && tabActiveInGroup),
        visible: tabActiveInGroup,
        viewColumn: group.viewColumn || 1,
        createdAt: Number(saved?.createdAt || 0)
      });
    }
  }

  return result;
}

function handleConversationsChanged(payload) {
  const state = getBridgeState();
  const conversations = Array.isArray(payload?.conversations) ? payload.conversations : [];
  for (const item of conversations) {
    const id = String(item?.id || item?.cascadeId || item?.conversationId || '').trim();
    const openEntry = id ? findOpenEntryByThreadId(id) : null;
    const rawTitle =
      item?.summary?.annotations?.title ||
      item?.summary?.title ||
      item?.summary?.summary ||
      '';
    if (id && rawTitle) {
      const clean = normalizeTabText(rawTitle, 56);
      if (clean && clean !== 'Antigravity') {
        state.titleById.set(id, clean);
        if (openEntry?.panel && openEntry.panel.title !== clean) {
          openEntry.title = clean;
          openEntry.panel.title = clean;
        }
      }
    }
    if (id && item?.summary && typeof item.summary === 'object') {
      const waitingSteps = Array.isArray(item.summary.waitingSteps)
        ? item.summary.waitingSteps
        : [];
      if (waitingSteps.length > 0) {
        state.badgeById.set(id, 'pending');
        if (openEntry?.panel) {
          applyEntryTabIcon(state, openEntry, 'pending');
        }
      } else if (state.badgeById.get(id) === 'pending' || openEntry?.badgeState === 'pending') {
        state.badgeById.set(id, 'plain');
        if (openEntry?.panel) {
          applyEntryTabIcon(state, openEntry, 'plain');
        }
      }
    }
  }
  notifyActivityChanged({
    type: 'conversations',
    conversations
  });
}

function installMultiInstanceSupport(state) {
  state.__handleConversationsChanged = handleConversationsChanged;
  const { apiImpl } = state;
  if (!apiImpl) {
    return;
  }
  const existingMains =
    apiImpl.mainViews ||
    (Array.isArray(apiImpl.views) ? apiImpl.views.filter((v) => v && v.type === 'main') : []);
  for (const inst of existingMains) {
    if (inst && !inst.__bhfConvListenerHooked) {
      inst.__bhfConvListenerHooked = true;
      try {
        inst.api?.onDidChangeConversations?.((payload) => {
          (state.__handleConversationsChanged || handleConversationsChanged)(payload);
        });
      } catch {}
    }
  }
  apiImpl.getMainInstance = function () {
    const mains = this.mainViews || (Array.isArray(this.views) ? this.views.filter((v) => v && v.type === 'main') : []);
    if (this.__bhfLockedInstance && mains.includes(this.__bhfLockedInstance)) {
      return this.__bhfLockedInstance;
    }
    if (this.__activeMainInstance && mains.includes(this.__activeMainInstance)) {
      return this.__activeMainInstance;
    }
    const activePanel = mains.find((v) => v?.view?.active);
    if (activePanel) {
      this.__activeMainInstance = activePanel;
      return activePanel;
    }
    return mains[mains.length - 1] || mains[0];
  };

  // Override handleDidChangeUrl so each editor tab tracks its own conversationId & tab title
  // without auto-resolving diffs in other open tabs, and ignores initial boot redirects to
  // lastConversationId on newly opened blank draft tabs.
  apiImpl.handleDidChangeUrl = async function (instance, urlObj) {
    if (!instance || instance.type !== 'main' || !urlObj || typeof urlObj.path !== 'string') {
      return;
    }
    const webview = instance.view?.webview || instance.webview;
    const entry = webview ? state.entryByWebview.get(webview) : null;
    if (entry) {
      entry.instance = instance;
      entry.iframeReady = true;
      entry.renderedPort = Number(state.serverManager?.port || getProxyState()?.upstreamPort || 0);
    }
    const match = urlObj.path.match(/^\/c\/([^/]+)$/);
    if (match) {
      const threadId = match[1];
      if (entry) {
        const parsedEntryUri = entry.uriKey ? parseSessionUri(entry.uriKey) : null;
        const pinnedThreadId = parsedEntryUri?.kind === 'thread' ? parsedEntryUri.threadId : '';
        if (pinnedThreadId && threadId !== pinnedThreadId) {
          if (
            instance.api?.navigate &&
            (!entry.__bhfRedirectRecoverAt || Date.now() - entry.__bhfRedirectRecoverAt > 3000)
          ) {
            entry.__bhfRedirectRecoverAt = Date.now();
            try {
              instance.api.navigate({ path: `/c/${pinnedThreadId}` });
            } catch {}
          }
          return;
        }
        const recentBootAge =
          Date.now() - Math.max(Number(entry.resolvedAt || 0), Number(entry.lastRenderAt || 0));
        if (
          !pinnedThreadId &&
          entry.initialConversationId &&
          threadId !== entry.initialConversationId &&
          !entry.pendingPromptSend &&
          (!entry.panel?.active || recentBootAge < 8000)
        ) {
          return;
        }
        if (
          !entry.initialConversationId &&
          !entry.pendingPromptSend &&
          !entry.newSessionReady &&
          Date.now() - (entry.resolvedAt || 0) < 4000 &&
          threadId === this.context?.workspaceState?.get?.('lastConversationId')
        ) {
          return;
        }
      }
      if (!entry || Boolean(entry.panel?.active)) {
        await this.context?.workspaceState?.update?.('lastConversationId', threadId);
      }
      if (entry) {
        entry.conversationId = threadId;
        if (!entry.initialConversationId) {
          entry.initialConversationId = threadId;
        }
        entry.newSessionReady = true;
        const resolvedTitle = resolveTabTitle(threadId, entry.title);
        entry.title = resolvedTitle;
        if (entry.panel) {
          entry.panel.title = resolvedTitle || 'Antigravity';
          if (entry.panel.active) {
            notifyThreadSeen(threadId);
          } else {
            applyEntryTabIcon(state, entry, state.badgeById.get(threadId) || 'plain');
          }
        }
        await writeTabState(this.context?.workspaceState, entry.uriKey, {
          id: threadId,
          title: resolvedTitle
        });
      }
      notifyActivityChanged({ type: 'url', threadId, uri: entry?.uriKey || '' });
    } else if (urlObj.path === '/') {
      if (entry) {
        const parsedEntryUri = entry.uriKey ? parseSessionUri(entry.uriKey) : null;
        const pinnedThreadId = parsedEntryUri?.kind === 'thread' ? parsedEntryUri.threadId : '';
        if (pinnedThreadId) {
          entry.conversationId = pinnedThreadId;
          entry.initialConversationId = pinnedThreadId;
          if (
            !entry.__bhfRenderInFlight &&
            instance.api?.navigate &&
            (!entry.__bhfRedirectRecoverAt || Date.now() - entry.__bhfRedirectRecoverAt > 3000)
          ) {
            entry.__bhfRedirectRecoverAt = Date.now();
            try {
              instance.api.navigate({ path: `/c/${pinnedThreadId}` });
            } catch {}
          }
          return;
        }
        const boundId = String(entry.conversationId || entry.initialConversationId || '').trim();
        if (boundId) {
          const recentBootAge =
            Date.now() - Math.max(Number(entry.resolvedAt || 0), Number(entry.lastRenderAt || 0));
          if (entry.__bhfRenderInFlight || recentBootAge < 12000 || !entry.panel?.active) {
            entry.conversationId = boundId;
            if (!entry.initialConversationId) {
              entry.initialConversationId = boundId;
            }
            if (
              !entry.__bhfRenderInFlight &&
              recentBootAge < 12000 &&
              instance.api?.navigate &&
              (!entry.__bhfRedirectRecoverAt || Date.now() - entry.__bhfRedirectRecoverAt > 3000)
            ) {
              entry.__bhfRedirectRecoverAt = Date.now();
              try {
                instance.api.navigate({ path: `/c/${boundId}` });
              } catch {}
            }
            return;
          }
        }
        entry.conversationId = '';
        entry.initialConversationId = '';
        entry.newSessionReady = true;
        entry.title = 'Antigravity';
        if (entry.panel) {
          entry.panel.title = 'Antigravity';
          applyEntryTabIcon(state, entry, 'plain');
        }
        await writeTabState(this.context?.workspaceState, entry.uriKey, {
          id: '',
          title: 'Antigravity'
        });
      }
      notifyActivityChanged({ type: 'url', threadId: '', uri: entry?.uriKey || '' });
    }
  };

  if (!apiImpl.__bhfMultiInstanceReadyHook) {
    apiImpl.__bhfMultiInstanceReadyHook = true;
    try {
      apiImpl.onDidRegisterView((instance) => {
        if (!instance || instance.type !== 'main') {
          return;
        }
        const initWebview = instance.view?.webview || instance.webview;
        const initEntry = initWebview ? state.entryByWebview.get(initWebview) : null;
        if (!initEntry) {
          return;
        }
        initEntry.instance = instance;
        Promise.resolve(instance.ready)
          .then(async () => {
            initEntry.iframeReady = true;
            initEntry.renderedPort = Number(
              state.serverManager?.port || getProxyState()?.upstreamPort || 0
            );
            if (!initEntry.initialConversationId && !initEntry.pendingPromptSend) {
              initEntry.newSessionReady = true;
            }
          })
          .catch(() => {});
      });
    } catch {}
  }

  state.__handleInstanceFocusOrActive = (instance) => {
    const webview = instance?.view?.webview || instance?.webview;
    const entry = webview ? state.entryByWebview.get(webview) : null;
    if (entry) {
      entry.instance = instance;
    }
    const panel = entry?.panel || instance?.view;
    if (panel && panel.active === false) {
      return;
    }
    const cid = entry?.conversationId || '';
    const eUri = normalizeUriKey(entry?.uriKey || entry?.uri);
    const tg = getSessionTabGroupsSnapshot(state.vscode);
    const tabInfo = eUri ? tg.tabInfoByUriKey.get(eUri) : null;
    if (tabInfo && !tabInfo.isAuthoritativeActive) {
      return;
    }
    const colInfo = tg.byColumn.get(tabInfo?.viewColumn || panel?.viewColumn || 1);
    if (
      colInfo &&
      (!colInfo.groupActive ||
        colInfo.hasOtherActiveTab ||
        (colInfo.activeSessionUriKey && eUri && colInfo.activeSessionUriKey !== eUri))
    ) {
      return;
    }
    if (isOpeningOtherTarget(state, { threadId: cid, uriKey: eUri })) {
      return;
    }
    clearOpeningTargetIfMatched(state, { threadId: cid, uriKey: eUri });
    apiImpl.__activeMainInstance = instance;
    if (cid) {
      notifyThreadSeen(cid);
    }
    notifyActivityChanged({ type: 'focus', threadId: cid, uri: eUri });
  };

  if (apiImpl.__bhfMultiInstancePatched) {
    return;
  }
  apiImpl.__bhfMultiInstancePatched = true;

  // 1. Patch registerWebview so registering a new 'main' view in an editor tab
  // never disposes existing 'main' views in other tabs.
  const origRegisterWebview = apiImpl.registerWebview.bind(apiImpl);
  apiImpl.registerWebview = async function (view, type) {
    if (Array.isArray(this.views)) {
      const sameIdx = this.views.findIndex((item) => item && item.webview === view?.webview);
      if (sameIdx > -1) {
        try {
          this.views.splice(sameIdx, 1)[0]?.dispose?.();
        } catch {}
      }
      const origFindIndex = this.views.findIndex;
      this.views.findIndex = function () {
        return -1;
      };
      try {
        return await origRegisterWebview(view, type);
      } finally {
        this.views.findIndex = origFindIndex;
      }
    }
    return await origRegisterWebview(view, type);
  };

  // 2. Track active 'main' instance and hook per-view events
  apiImpl.onDidRegisterView((instance) => {
    if (!instance || instance.type !== 'main') {
      return;
    }
    const initWebview = instance.view?.webview || instance.webview;
    const initEntry = initWebview ? state.entryByWebview.get(initWebview) : null;
    if (initEntry) {
      initEntry.instance = instance;
      const cleanEntryUri = normalizeUriKey(initEntry.uriKey || initEntry.uri);
      if (cleanEntryUri) {
        initEntry.uriKey = cleanEntryUri;
        if (state.pendingPromptUriKeys?.has?.(cleanEntryUri)) {
          initEntry.pendingPromptSend = true;
          state.pendingPromptUriKeys.delete(cleanEntryUri);
        }
      }
      Promise.resolve(instance.ready)
        .then(async () => {
          initEntry.iframeReady = true;
          initEntry.renderedPort = Number(
            state.serverManager?.port || getProxyState()?.upstreamPort || 0
          );
          if (
            !initEntry.conversationId &&
            !initEntry.initialConversationId &&
            !initEntry.pendingPromptSend
          ) {
            await instance.api?.newConversation?.({});
            initEntry.newSessionReady = true;
          }
        })
        .catch(() => {});
    }
    if (!apiImpl.__activeMainInstance || instance.view?.active) {
      apiImpl.__activeMainInstance = instance;
    }
    try {
      instance.api?.onWebviewFocused?.(() => {
        state.__handleInstanceFocusOrActive?.(instance);
      });
    } catch {}
    try {
      if (typeof instance.view?.onDidChangeViewState === 'function') {
        instance.view.onDidChangeViewState((e) => {
          const webview = instance.view?.webview || instance.webview;
          const entry = webview ? state.entryByWebview.get(webview) : null;
          if (entry) {
            entry.instance = instance;
          }
          if (e?.webviewPanel?.active || instance.view?.active) {
            state.__handleInstanceFocusOrActive?.(instance);
          }
        });
      }
    } catch {}
    try {
      instConvHook: {
        if (instance.__bhfConvListenerHooked) break instConvHook;
        instance.__bhfConvListenerHooked = true;
        instance.api?.onDidChangeConversations?.((payload) => {
          (state.__handleConversationsChanged || handleConversationsChanged)(payload);
        });
      }
    } catch {}
  });

  // 4. Override ensureMainInstance to open a conversation tab in the middle editor when none is open
  apiImpl.ensureMainInstance = async function () {
    const existing = this.getMainInstance();
    if (existing) {
      await existing.ready;
      return existing;
    }
    let sub;
    const waitRegistered = new Promise((resolve) => {
      sub = this.onDidRegisterView((inst) => {
        if (inst && inst.type === 'main') {
          resolve(inst);
        }
      });
    });
    try {
      const lastId = this.context?.workspaceState?.get?.('lastConversationId');
      if (lastId) {
        await openConversationTab({ id: lastId });
      } else {
        await openNewSessionTab({});
      }
      const inst = await waitRegistered;
      await inst.ready;
      return inst;
    } finally {
      try {
        sub?.dispose?.();
      } catch {}
    }
  };

  // 6. Route newConversation and openConversation to middle editor tabs
  apiImpl.newConversation = async function () {
    await openNewSessionTab({});
  };

  apiImpl.openConversation = async function (id, path) {
    let targetId = id;
    if (!targetId && typeof path === 'string') {
      const m = path.match(/^\/c\/([^/]+)$/);
      if (m) {
        targetId = m[1];
      }
    }
    if (targetId) {
      await openConversationTab({ id: targetId });
    } else {
      await openNewSessionTab({});
    }
  };

  // 7. Prevent agent edits / approvals from dirtying background buffers or popping open
  // .py / code files as tabs in the main VS Code editor view alongside session tabs.
  const editMgr = apiImpl.agentEditManager;
  if (editMgr) {
    try {
      if (editMgr.renderer?.disposeForShutdown) {
        editMgr.renderer.disposeForShutdown();
      } else {
        editMgr.renderer?.dispose?.();
      }
    } catch {}
    const disabledRenderer = {
      type: 'disabled',
      dispose() {},
      disposeForShutdown() {}
    };
    editMgr.createDiffZoneRenderer = () => disabledRenderer;
    editMgr.renderer = disabledRenderer;
    editMgr.openSideBySideDiffs = false;
    editMgr.autoAcceptOnChat = false;
    try {
      editMgr.activeDiffZoneDetails?.clear?.();
      editMgr.fileDiffStats?.clear?.();
      editMgr.priorTurnContents?.clear?.();
      editMgr.resolvedDiffMarks?.clear?.();
    } catch {}
    try {
      state.context?.workspaceState?.update?.('jetski.pendingInlineEdits', []);
    } catch {}
    editMgr.updateDiffZoneRenderer = function () {
      this.renderer = disabledRenderer;
    };
    editMgr.restorePendingInlineEdits = async function () {};
    editMgr.revealDocument = async function () {};
    editMgr.forceResolveFromFile = async function () {};
    editMgr.onChatSent = async function () {};
    editMgr.handleAddAgentEdit = async function () {};
  }

  apiImpl.addAgentEdit = async function () {
    return {};
  };

  installTelemetryAndTermsGuard(state);
  installNotificationDedupeSupport(state);
  installRichFileOpenSupport(state);
}

// 7a. Route .xlsx/.xlsm spreadsheets to an in-editor VS Code Workbook Tab and binary files (.pdf/.png/etc.)
// through vscode.open instead of openTextDocument (which throws "File seems to be binary").
function installRichFileOpenSupport(state) {
  const apiImpl = state?.apiImpl;
  const vscode = resolveVscodeApi(state?.vscode);
  if (vscode && excelPreview?.ensureExcelPreviewRegistered) {
    excelPreview.ensureExcelPreviewRegistered(vscode, state?.context);
  }
  if (!apiImpl || typeof apiImpl.openFile !== 'function' || !excelPreview?.openFileUriSmart) {
    return;
  }
  if (!apiImpl.__bhfOrigOpenFile) {
    apiImpl.__bhfOrigOpenFile = apiImpl.openFile.bind(apiImpl);
  }
  state.__bhfOpenFileImpl = async function (req) {
    const activeVscode = resolveVscodeApi(state?.vscode) || vscode;
    if (!req || !req.fileUri || !activeVscode) {
      return apiImpl.__bhfOrigOpenFile(req);
    }
    const outcome = await excelPreview.openFileUriSmart(activeVscode, req.fileUri, () =>
      apiImpl.__bhfOrigOpenFile(req)
    );
    return outcome && outcome.mode === 'orig' ? outcome.result : {};
  };
  if (!apiImpl.__bhfOpenFileWrapped) {
    apiImpl.__bhfOpenFileWrapped = true;
    apiImpl.openFile = function (req) {
      const impl = state.__bhfOpenFileImpl;
      return typeof impl === 'function' ? impl(req) : apiImpl.__bhfOrigOpenFile(req);
    };
  }
}

// 7b. Disable interaction data collection (telemetryEnabled: false) across all accounts and
// prevent the "Security Notice & Data Use" modal from popping up on every account login/switch.
function installTelemetryAndTermsGuard(state) {
  const apiImpl = state?.apiImpl;
  const globalState = state?.context?.globalState || apiImpl?.context?.globalState;
  const activeEmail = readExpectedActiveAntigravityEmail(state?.__bhfVaultDir).expectedEmail || '';
  const hasTheoWorkspace = fs.existsSync(
    path.join(os.homedir(), 'OneDrive - BHFIRMS', 'System', 'System', 'THEO')
  );
  ensureOutsideOfProjectConfig();

  if (globalState && typeof globalState.update === 'function') {
    try {
      Promise.resolve(globalState.update('antigravity.accountTelemetryEnabled', false)).catch(() => {});
    } catch {}
    try {
      const existingMap =
        typeof globalState.get === 'function' ? globalState.get('antigravity-storage', {}) : {};
      const nextMap = {
        ...(existingMap && typeof existingMap === 'object' ? existingMap : {}),
        'jetski.onboarding.welcomeModalSeen': 'true',
        'jetski.onboarding.cloudResourceDisclosureSeen': 'true',
        'jetski.onboarding.lastLoginIsGcpTos': 'false'
      };
      if (activeEmail) {
        nextMap['jetski.onboarding.lastLoginUsername'] = activeEmail;
      }
      if (hasTheoWorkspace) {
        if (
          !nextMap['new-convo-last-selected-project'] ||
          nextMap['new-convo-last-selected-project'] === 'outside-of-project'
        ) {
          nextMap['new-convo-last-selected-project'] = THEO_DEFAULT_PROJECT_ID;
        }
        nextMap['new-convo-magic-workspace-selected'] = 'false';
        if (!nextMap['projectsOrder']) {
          nextMap['projectsOrder'] = JSON.stringify([THEO_DEFAULT_PROJECT_ID]);
        }
      }
      Promise.resolve(globalState.update('antigravity-storage', nextMap)).catch(() => {});
    } catch {}
  }

  if (apiImpl) {
    if (
      typeof apiImpl.storageGetItems === 'function' &&
      apiImpl.__bhfStorageTermsGuardVersion !== 2
    ) {
      const origStorageGetItems =
        apiImpl.__bhfOrigStorageGetItems || apiImpl.storageGetItems.bind(apiImpl);
      apiImpl.__bhfOrigStorageGetItems = origStorageGetItems;
      apiImpl.__bhfStorageTermsGuardPatched = true;
      apiImpl.__bhfStorageTermsGuardVersion = 2;
      apiImpl.storageGetItems = async function (req) {
        const res = await origStorageGetItems(req);
        try {
          const items = res && typeof res === 'object' && res.items && typeof res.items === 'object'
            ? { ...res.items }
            : {};
          const keys = Array.isArray(req?.keys) ? req.keys : Object.keys(items);
          if (keys.includes('jetski.onboarding.welcomeModalSeen')) {
            items['jetski.onboarding.welcomeModalSeen'] = 'true';
          }
          if (keys.includes('jetski.onboarding.cloudResourceDisclosureSeen')) {
            items['jetski.onboarding.cloudResourceDisclosureSeen'] = 'true';
          }
          if (keys.includes('jetski.onboarding.lastLoginIsGcpTos')) {
            items['jetski.onboarding.lastLoginIsGcpTos'] = 'false';
          }
          if (keys.includes('jetski.onboarding.lastLoginUsername')) {
            const curExpected =
              readExpectedActiveAntigravityEmail(state?.__bhfVaultDir).expectedEmail || '';
            if (curExpected) {
              items['jetski.onboarding.lastLoginUsername'] = curExpected;
            }
          }
          if (hasTheoWorkspace) {
            if (
              keys.includes('new-convo-last-selected-project') &&
              (!items['new-convo-last-selected-project'] ||
                items['new-convo-last-selected-project'] === 'outside-of-project')
            ) {
              items['new-convo-last-selected-project'] = THEO_DEFAULT_PROJECT_ID;
            }
            if (
              keys.includes('new-convo-magic-workspace-selected') &&
              items['new-convo-magic-workspace-selected'] === undefined
            ) {
              items['new-convo-magic-workspace-selected'] = 'false';
            }
            if (keys.includes('projectsOrder') && !items['projectsOrder']) {
              items['projectsOrder'] = JSON.stringify([THEO_DEFAULT_PROJECT_ID]);
            }
          }
          return { ...(res && typeof res === 'object' ? res : {}), items };
        } catch {
          return res;
        }
      };
    }

    if (
      typeof apiImpl.storageUpdateItems === 'function' &&
      apiImpl.__bhfStorageUpdateTermsGuardVersion !== 2
    ) {
      const origStorageUpdateItems =
        apiImpl.__bhfOrigStorageUpdateItems || apiImpl.storageUpdateItems.bind(apiImpl);
      apiImpl.__bhfOrigStorageUpdateItems = origStorageUpdateItems;
      apiImpl.__bhfStorageUpdateTermsGuardPatched = true;
      apiImpl.__bhfStorageUpdateTermsGuardVersion = 2;
      apiImpl.storageUpdateItems = async function (req) {
        try {
          if (req && typeof req === 'object' && req.updates && typeof req.updates === 'object') {
            const nextUpdates = {
              ...req.updates,
              'jetski.onboarding.welcomeModalSeen': 'true',
              'jetski.onboarding.cloudResourceDisclosureSeen': 'true',
              'jetski.onboarding.lastLoginIsGcpTos': 'false'
            };
            if (
              hasTheoWorkspace &&
              nextUpdates['new-convo-last-selected-project'] === 'outside-of-project'
            ) {
              nextUpdates['new-convo-last-selected-project'] = THEO_DEFAULT_PROJECT_ID;
            }
            req = {
              ...req,
              updates: nextUpdates
            };
          }
        } catch {}
        return origStorageUpdateItems(req);
      };
    }

    if (apiImpl.telemetrySettingDelegate && typeof apiImpl.telemetrySettingDelegate === 'object') {
      apiImpl.telemetrySettingDelegate.isEnabled = () => false;
    }
    if (typeof apiImpl.onDidChangeTelemetrySetting === 'function' && !apiImpl.__bhfTelemetryLocked) {
      apiImpl.__bhfTelemetryLocked = true;
      try {
        apiImpl.onDidChangeTelemetrySetting((enabled) => {
          if (enabled && globalState && typeof globalState.update === 'function') {
            Promise.resolve(globalState.update('antigravity.accountTelemetryEnabled', false)).catch(
              () => {}
            );
          }
        });
      } catch {}
    }
  }

  try {
    const proxySt = getProxyState();
    if (
      proxySt &&
      (!state?.__bhfFlushedMainJsNoTermsV1 || !state?.__bhfFlushedMainJsWorkspaceV1)
    ) {
      const needsBlankTabReload = !state?.__bhfFlushedMainJsWorkspaceV1;
      if (state) {
        state.__bhfFlushedMainJsNoTermsV1 = true;
        state.__bhfFlushedMainJsWorkspaceV1 = true;
      }
      proxySt.mainJsCache = null;
      proxySt.mainJsInFlight = null;
      if (needsBlankTabReload && state?.renderer && state?.entriesByUriKey instanceof Map) {
        for (const entry of state.entriesByUriKey.values()) {
          const cid = String(entry?.conversationId || entry?.initialConversationId || '').trim();
          if (!cid && entry?.panel && entry.panel.visible !== false && !entry.__bhfRenderInFlight) {
            entry.__bhfRenderInFlight = true;
            Promise.resolve(
              state.renderer.renderJetskiIframe(entry.panel, {
                targetRoute: '',
                type: 'main',
                location: 'editor'
              })
            )
              .catch(() => {})
              .finally(() => {
                entry.__bhfRenderInFlight = false;
              });
          }
        }
      }
    }
    const curPort = Number(state?.serverManager?.port || proxySt?.upstreamPort || 0);
    const curCsrf = String(state?.serverManager?.csrfToken || proxySt?.csrfToken || '').trim();
    if (curPort > 0 && curCsrf) {
      ensureAntigravityTelemetryDisabled(curPort, curCsrf)
        .catch(() => {})
        .finally(() => {
          if (state && !state.__bhfDismissedSecurityNoticeModalV1 && state.entriesByUriKey instanceof Map) {
            state.__bhfDismissedSecurityNoticeModalV1 = true;
            const seenCids = new Set();
            for (const entry of state.entriesByUriKey.values()) {
              const cid = String(entry?.conversationId || entry?.initialConversationId || '').trim();
              if (!cid || seenCids.has(cid)) continue;
              seenCids.add(cid);
              try {
                enqueueRemoteWebviewAction({
                  id: cid,
                  kind: 'approve',
                  targetLabel: 'Accept and continue'
                });
              } catch {}
            }
          }
        });
    }
  } catch {}

  return true;
}

// 8. Prevent multi-tab notification amplification & Windows Toast queue pile-ups:
// Every open Antigravity editor tab (retainContextWhenHidden: true) runs its own /main.js iframe
// subscribed to the global StreamCascadeTrajectorySummaries stream. When a cascade finishes, all N
// unfocused tabs fire showBrowserNotification with `agent-finished-<cascadeId>-<Date.now()>` at
// slightly different milliseconds (bypassing stock sentNotificationIds.has(id) deduplication) and
// spawn N separate PowerShell WinRT Toast notifications without a Tag/Group, which Windows queues
// sequentially for ~6s each.
function installNotificationDedupeSupport(state) {
  const apiImpl = state?.apiImpl;
  if (!apiImpl) {
    return false;
  }
  if (!(state.recentBrowserNotifications instanceof Map)) {
    state.recentBrowserNotifications = new Map();
  }
  const COOLDOWN_MS = 90000;

  const isDuplicateNotification = (rawId, cascadeId, title, body) => {
    const now = Date.now();
    for (const [k, ts] of state.recentBrowserNotifications.entries()) {
      if (now - ts > 600000) {
        state.recentBrowserNotifications.delete(k);
      }
    }
    const cleanId = String(rawId || '').trim();
    const normId = cleanId.replace(/^agent-finished-([0-9a-f-]+)-\d+$/i, 'agent-finished-$1');
    const cleanCascade = String(cascadeId || '').trim();
    const cleanTitle = String(title || 'Antigravity').trim();
    const cleanBody = String(body || '').trim();
    const isAgentFinished =
      /^agent-finished-/i.test(cleanId) || /^Agent finished\b/i.test(cleanBody);

    const keys = [
      normId || cleanId,
      `${cleanCascade}::${cleanTitle}::${cleanBody}`,
      isAgentFinished ? `finish::${cleanCascade || cleanBody}` : ''
    ].filter(Boolean);

    for (const k of keys) {
      const prevTs = state.recentBrowserNotifications.get(k) || 0;
      if (prevTs > 0 && now - prevTs < COOLDOWN_MS) {
        return true;
      }
    }
    for (const k of keys) {
      state.recentBrowserNotifications.set(k, now);
    }
    return false;
  };

  if (
    typeof apiImpl.showBrowserNotification === 'function' &&
    !apiImpl.__bhfNotifDedupePatched
  ) {
    apiImpl.__bhfNotifDedupePatched = true;
    const origShowBrowserNotification = apiImpl.showBrowserNotification.bind(apiImpl);
    apiImpl.showBrowserNotification = async function (a) {
      try {
        const payload = a?.payload || {};
        const rawId = String(payload.id || '').trim();
        const cascadeId = String(payload.cascadeId || '').trim();
        const title = String(payload.title || 'Antigravity').trim();
        const body = String(payload.body || '').trim();

        if (isDuplicateNotification(rawId, cascadeId, title, body)) {
          return {};
        }

        if (this.sentNotificationIds instanceof Set) {
          if (rawId) this.sentNotificationIds.add(rawId);
          const normId = rawId.replace(/^agent-finished-([0-9a-f-]+)-\d+$/i, 'agent-finished-$1');
          if (normId) this.sentNotificationIds.add(normId);
        }

        // Suppress if VS Code is focused and the target conversation tab is active/visible,
        // or if it is an "Agent finished" event while VS Code is focused (THEO Hub handles
        // in-editor completion badges and notifications).
        const isWindowFocused = Boolean(state.vscode?.window?.state?.focused);
        if (isWindowFocused) {
          const openEntry = cascadeId ? findOpenEntryByThreadId(cascadeId) : null;
          if (openEntry?.panel?.active || openEntry?.panel?.visible) {
            return {};
          }
          if (/^agent-finished-/i.test(rawId) || /^Agent finished\b/i.test(body)) {
            return {};
          }
        }
      } catch {}
      return origShowBrowserNotification(a);
    };
  }

  const delegate = apiImpl.browserNotificationDelegate;
  if (delegate && !delegate.__bhfWindowsToastPatched) {
    delegate.__bhfWindowsToastPatched = true;
    delegate.suppressWhenWindowFocused = true;
    delegate.showWindowsNotification = function (title, body, launchUri, onFallback) {
      try {
        const rawKey = `${launchUri || ''}::${title || ''}::${body || ''}`;
        const tagHash = crypto.createHash('sha1').update(rawKey).digest('hex').slice(0, 11);
        const toastTag = `agy-${tagHash}`;
        const now = Date.now();
        if (!(state.recentWindowsToasts instanceof Map)) {
          state.recentWindowsToasts = new Map();
        }
        const prevToastAt = state.recentWindowsToasts.get(toastTag) || 0;
        if (prevToastAt > 0 && now - prevToastAt < COOLDOWN_MS) {
          return;
        }
        state.recentWindowsToasts.set(toastTag, now);

        const logoPath = typeof this.getLogoPath === 'function' ? this.getLogoPath() : undefined;
        const env = { ...process.env };
        delete env.ELECTRON_RUN_AS_NODE;
        env.AGY_NOTIFY_APP_ID = 'Microsoft.VisualStudioCode';
        env.AGY_NOTIFY_TITLE = `Antigravity \u2014 ${title}`;
        env.AGY_NOTIFY_BODY = body || title;
        env.AGY_NOTIFY_URI = launchUri || '';
        env.AGY_NOTIFY_TAG = toastTag;
        if (logoPath) {
          try {
            const { pathToFileURL } = require('url');
            env.AGY_NOTIFY_ICON = pathToFileURL(logoPath).href;
          } catch {}
        }
        const psScript = [
          'try {',
          '  $ErrorActionPreference = "Stop";',
          '  if ($ExecutionContext.SessionState.LanguageMode -ne "FullLanguage") { exit 1 };',
          '  $Apps = @(Get-StartApps);',
          '  $App = $Apps | Where-Object {$_.AppID -eq $env:AGY_NOTIFY_APP_ID} | Select-Object -First 1;',
          '  if (-not $App) { $App = $Apps | Where-Object {$_.Name -like "*Visual Studio Code*"} | Select-Object -First 1 };',
          '  if (-not $App -or -not $App.AppID) { exit 1 };',
          '  [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null;',
          '  [Windows.UI.Notifications.ToastNotification, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null;',
          '  [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null;',
          '  $TemplateType = if ($env:AGY_NOTIFY_ICON) { [Windows.UI.Notifications.ToastTemplateType]::ToastImageAndText02 } else { [Windows.UI.Notifications.ToastTemplateType]::ToastText02 };',
          '  $Template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent($TemplateType);',
          '  $RawXml = [xml] $Template.GetXml();',
          '  $RawXml.toast.SetAttribute("activationType", "protocol");',
          '  $RawXml.toast.SetAttribute("launch", $env:AGY_NOTIFY_URI);',
          '  if ($env:AGY_NOTIFY_ICON) {',
          '    $RawXml.toast.visual.binding.SetAttribute("template", "ToastGeneric");',
          '    ($RawXml.toast.visual.binding.image | Where-Object {$_.id -eq "1"}).SetAttribute("src", $env:AGY_NOTIFY_ICON);',
          '    ($RawXml.toast.visual.binding.image | Where-Object {$_.id -eq "1"}).SetAttribute("placement", "appLogoOverride")',
          '  };',
          '  ($RawXml.toast.visual.binding.text | Where-Object {$_.id -eq "1"}).AppendChild($RawXml.CreateTextNode($env:AGY_NOTIFY_TITLE)) | Out-Null;',
          '  ($RawXml.toast.visual.binding.text | Where-Object {$_.id -eq "2"}).AppendChild($RawXml.CreateTextNode($env:AGY_NOTIFY_BODY)) | Out-Null;',
          '  $SerializedXml = New-Object Windows.Data.Xml.Dom.XmlDocument;',
          '  $SerializedXml.LoadXml($RawXml.OuterXml);',
          '  $Toast = [Windows.UI.Notifications.ToastNotification]::new($SerializedXml);',
          '  if ($env:AGY_NOTIFY_TAG) { $Toast.Tag = $env:AGY_NOTIFY_TAG; $Toast.Group = "Antigravity" };',
          '  $Toast.ExpirationTime = [DateTimeOffset]::Now.AddSeconds(15);',
          '  [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($App.AppID).Show($Toast)',
          '} catch { exit 1 }'
        ].join(' ');
        childProcess.execFile(
          'powershell.exe',
          ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psScript],
          { timeout: 10000, windowsHide: true, env },
          (err) => {
            if (err && typeof onFallback === 'function') {
              onFallback();
            }
          }
        );
      } catch {
        if (typeof onFallback === 'function') {
          onFallback();
        }
      }
    };
  }
  return true;
}

function installSidebarDelegation(state) {
  const { provider } = state;
  if (!provider) {
    return;
  }
  if (!state.origResolveWebviewView && typeof provider.resolveWebviewView === 'function') {
    state.origResolveWebviewView = provider.resolveWebviewView.bind(provider);
  }
  if (!state.origProviderRefresh && typeof provider.refresh === 'function') {
    state.origProviderRefresh = provider.refresh.bind(provider);
  }

  provider.refresh = function () {
    try {
      this.renderer?.refresh?.();
    } catch {}
    reconnectAllOpenTabs(state, { forceRender: true }).catch(() => {});
    if (state.sidebarDelegate && typeof state.sidebarDelegate.refresh === 'function') {
      state.sidebarDelegate.refresh();
      return;
    }
    return state.origProviderRefresh?.();
  };

  if (provider.__bhfSidebarPatched) {
    return;
  }
  provider.__bhfSidebarPatched = true;

  provider.resolveWebviewView = async function (webviewView, resolveContext, token) {
    this.sidebarView = webviewView;
    state.sidebarView = webviewView;

    if (state.sidebarDelegate && typeof state.sidebarDelegate.resolveWebviewView === 'function') {
      return state.sidebarDelegate.resolveWebviewView(webviewView, resolveContext, token);
    }

    // Wait briefly for bhfirms.antigravity-hub to finish activating and attach its sidebar delegate
    return new Promise((resolve) => {
      if (state.sidebarFallbackTimer) {
        clearTimeout(state.sidebarFallbackTimer);
      }
      state.sidebarFallbackTimer = setTimeout(async () => {
        state.sidebarFallbackTimer = null;
        if (state.sidebarDelegate && typeof state.sidebarDelegate.resolveWebviewView === 'function') {
          resolve(await state.sidebarDelegate.resolveWebviewView(webviewView, resolveContext, token));
        } else {
          resolve(await state.origResolveWebviewView(webviewView, resolveContext, token));
        }
      }, 4000);
    });
  };
}

function resolveVscodeApi(candidate) {
  if (
    candidate &&
    typeof candidate === 'object' &&
    candidate.workspace &&
    candidate.window &&
    candidate.commands
  ) {
    return candidate;
  }
  try {
    const realVscode = require('vscode');
    if (realVscode && realVscode.workspace && realVscode.window && realVscode.commands) {
      return realVscode;
    }
  } catch {}
  return null;
}

function installConversationEditorProvider(state) {
  const vscode = resolveVscodeApi(state?.vscode);
  if (vscode && state.vscode !== vscode) {
    state.vscode = vscode;
  }
  const { context, renderer } = state || {};
  if (!vscode?.workspace || !vscode?.window || !context || !renderer) {
    return;
  }

  const handleResolveCustomEditor = async (document, webviewPanel) => {
    const uriKey = normalizeUriKey(document.uri);
    const parsed = parseSessionUri(uriKey);
    const savedState = readTabState(context.workspaceState, uriKey);

    let conversationId = '';
    if (parsed.kind === 'thread') {
      conversationId = parsed.threadId || '';
    } else if (parsed.kind === 'new' && savedState?.id) {
      conversationId = savedState.id;
    }

    const initialTitle = resolveTabTitle(conversationId, savedState?.title || '');
    const hasPendingPrompt = Boolean(state.pendingPromptUriKeys?.has?.(uriKey));
    if (hasPendingPrompt) {
      state.pendingPromptUriKeys.delete(uriKey);
    }
    const shouldRenderImmediately =
      !state.__bhfHealingTabMetadataOnly && (webviewPanel.visible !== false || hasPendingPrompt);
    const curPort = Number(state.serverManager?.port || getProxyState()?.upstreamPort || 0);
    const entry = {
      uriKey,
      uri: document.uri,
      panel: webviewPanel,
      instance: null,
      iframeReady: false,
      newSessionReady: Boolean(conversationId),
      renderedPort: shouldRenderImmediately ? curPort : 0,
      lastRenderAt: shouldRenderImmediately ? Date.now() : 0,
      needsDeferredReconnect: !shouldRenderImmediately,
      __bhfRenderInFlight: false,
      conversationId,
      initialConversationId: conversationId,
      pendingPromptSend: hasPendingPrompt,
      promptSent: false,
      resolvedAt: Date.now(),
      title: initialTitle,
      badgeState: 'plain',
      iconApplied: false
    };

    const panelWebview = webviewPanel.webview;
    state.entriesByUriKey.set(uriKey, entry);
    state.entryByWebview.set(panelWebview, entry);

    webviewPanel.title = initialTitle || 'Antigravity';
    const initialBadge =
      !webviewPanel.active && conversationId
        ? state.badgeById.get(conversationId) || 'plain'
        : 'plain';
    applyEntryTabIcon(state, entry, initialBadge);
    if (webviewPanel.active && conversationId) {
      notifyThreadSeen(conversationId);
    }

    panelWebview.options = {
      enableScripts: true,
      localResourceRoots: [context.extensionUri]
    };

    attachEntryLazyRevealListener(state, entry);
    attachEntryFastCloseListener(state, entry);

    webviewPanel.onDidChangeViewState(() => {
      const cid = entry.conversationId || '';
      const tg = getSessionTabGroupsSnapshot(state.vscode);
      const tabInfo = uriKey ? tg.tabInfoByUriKey.get(uriKey) : null;
      const isAuthoritativeActive = tabInfo
        ? tabInfo.isAuthoritativeActive
        : Boolean(webviewPanel.active);
      if (isAuthoritativeActive) {
        if (isOpeningOtherTarget(state, { threadId: cid, uriKey })) {
          return;
        }
        clearOpeningTargetIfMatched(state, { threadId: cid, uriKey });
        if (entry.badgeState === 'done') {
          applyEntryTabIcon(state, entry, 'plain');
        }
        if (cid) {
          context.workspaceState.update('lastConversationId', cid);
          notifyThreadSeen(cid);
        }
      }
      notifyActivityChanged({
        type: 'tab-state',
        uri: uriKey,
        threadId: cid,
        active: isAuthoritativeActive
      });
    });

    webviewPanel.onDidDispose(() => {
      if (entry.__bhfLazyRevealDisposable) {
        try {
          entry.__bhfLazyRevealDisposable.dispose();
        } catch {}
        entry.__bhfLazyRevealDisposable = null;
      }
      state.entriesByUriKey.delete(uriKey);
      state.entryByWebview.delete(panelWebview);
      if (parsed.kind === 'new' && !entry.conversationId) {
        deleteTabState(context.workspaceState, uriKey).catch(() => {});
      }
      notifyActivityChanged({
        type: 'tab-closed',
        uri: uriKey,
        threadId: entry.conversationId || ''
      });
    });

    if (shouldRenderImmediately) {
      entry.__bhfRenderInFlight = true;
      const initRenderPromise = Promise.resolve(
        renderer.renderJetskiIframe(webviewPanel, {
          targetRoute: conversationId ? `c/${conversationId}` : '',
          type: 'main',
          location: 'editor'
        })
      );
      entry.__bhfRenderPromise = initRenderPromise;
      try {
        await initRenderPromise;
      } finally {
        entry.__bhfRenderInFlight = false;
        if (entry.__bhfRenderPromise === initRenderPromise) {
          entry.__bhfRenderPromise = null;
        }
      }
    }

    if (state.__bhfPendingFocusByUri instanceof Map) {
      const rawPending = state.__bhfPendingFocusByUri.get(uriKey);
      const focusUntil =
        typeof rawPending === 'number' ? rawPending : Number(rawPending?.until || 0);
      const focusSeq = typeof rawPending === 'object' ? Number(rawPending?.seq || 0) : 0;
      if (focusUntil > Date.now() && (!focusSeq || state.__bhfOpenSeq === focusSeq)) {
        setTimeout(() => {
          const curPending = state.__bhfPendingFocusByUri?.get?.(uriKey);
          const curUntil =
            typeof curPending === 'number' ? curPending : Number(curPending?.until || 0);
          const curSeq = typeof curPending === 'object' ? Number(curPending?.seq || 0) : 0;
          if (curUntil > Date.now() && (!curSeq || state.__bhfOpenSeq === curSeq)) {
            state.__bhfPendingFocusByUri.delete(uriKey);
            try {
              webviewPanel.reveal(webviewPanel.viewColumn || 1, false);
            } catch {}
          }
        }, 0);
      }
    }

    notifyActivityChanged({
      type: 'tab-resolved',
      uri: uriKey,
      threadId: conversationId
    });
  };

  state.__resolveCustomEditorHandler = handleResolveCustomEditor;
  if (state.customEditorDisposable) {
    return;
  }

  const contentProviderDisposable = vscode.workspace.registerTextDocumentContentProvider(
    SESSION_TAB_SCHEME,
    {
      provideTextDocumentContent() {
        return '';
      }
    }
  );
  context.subscriptions.push(contentProviderDisposable);

  const customEditorProvider = {
    openCustomDocument(uri) {
      return {
        uri,
        dispose() {}
      };
    },
    async resolveCustomEditor(document, webviewPanel) {
      return (state.__resolveCustomEditorHandler || handleResolveCustomEditor)(
        document,
        webviewPanel
      );
    }
  };

  const customEditorDisposable = vscode.window.registerCustomEditorProvider(
    SESSION_TAB_VIEW_TYPE,
    customEditorProvider,
    {
      webviewOptions: {
        retainContextWhenHidden: true
      },
      supportsMultipleEditorsPerDocument: false
    }
  );
  state.customEditorDisposable = customEditorDisposable;
  state.editorProviderRegistered = true;
  context.subscriptions.push(customEditorDisposable);

  scheduleHealClobberedSessionTabs(state);
}

async function healClobberedSessionTabs(state) {
  if (!state || state.__bhfHealingTabMetadataOnly) {
    return 0;
  }
  const vscode = resolveVscodeApi(state.vscode);
  const groups = vscode?.window?.tabGroups?.all;
  if (!vscode?.commands || !Array.isArray(groups) || groups.length === 0) {
    return 0;
  }

  let healedCount = 0;
  for (const group of groups) {
    const tabs = Array.isArray(group?.tabs) ? group.tabs : [];
    const origActiveTab = tabs.find((t) => Boolean(t?.isActive)) || group?.activeTab || null;
    const clobberedBgTabs = [];

    for (const tab of tabs) {
      if (tab === origActiveTab) {
        continue;
      }
      const inputUri = tab?.input?.uri;
      if (!inputUri || inputUri.scheme !== SESSION_TAB_SCHEME) {
        continue;
      }
      const uriKey = normalizeUriKey(inputUri);
      if (!uriKey || state.entriesByUriKey.has(uriKey)) {
        continue;
      }
      const label = String(tab.label || '').trim();
      if (label === 'new' || !label) {
        clobberedBgTabs.push({ tab, inputUri, uriKey });
      }
    }

    if (clobberedBgTabs.length === 0) {
      continue;
    }

    const viewColumn = group.viewColumn || 1;
    state.__bhfHealingTabMetadataOnly = true;
    try {
      for (const item of clobberedBgTabs) {
        try {
          await vscode.commands.executeCommand(
            'vscode.openWith',
            item.inputUri,
            SESSION_TAB_VIEW_TYPE,
            {
              viewColumn,
              preview: false,
              preserveFocus: true
            }
          );
          healedCount += 1;
        } catch {}
      }
    } finally {
      state.__bhfHealingTabMetadataOnly = false;
    }

    // Restore the group's originally active tab immediately
    if (origActiveTab?.input) {
      try {
        const origUri = origActiveTab.input.uri;
        const origViewType = origActiveTab.input.viewType;
        if (origUri && origUri.scheme === SESSION_TAB_SCHEME) {
          await vscode.commands.executeCommand('vscode.openWith', origUri, SESSION_TAB_VIEW_TYPE, {
            viewColumn,
            preview: false,
            preserveFocus: !group.isActive
          });
        } else if (origUri && origViewType) {
          await vscode.commands.executeCommand('vscode.openWith', origUri, origViewType, {
            viewColumn,
            preview: false,
            preserveFocus: !group.isActive
          });
        } else if (origUri && vscode.window?.showTextDocument) {
          await vscode.window.showTextDocument(origUri, {
            viewColumn,
            preview: false,
            preserveFocus: !group.isActive
          });
        }
      } catch {}
    }
  }
  return healedCount;
}

function scheduleHealClobberedSessionTabs(state, delayMs = 450) {
  if (!state || state.__bhfScheduledClobberedTabHeal) {
    return;
  }
  state.__bhfScheduledClobberedTabHeal = true;
  const timer = setTimeout(() => {
    healClobberedSessionTabs(state).catch(() => {});
  }, delayMs);
  if (typeof timer?.unref === 'function') {
    timer.unref();
  }
}

async function waitForEntryInstance(state, { uriKey = '', threadId = '', timeoutMs = 6500 } = {}) {
  const cleanUri = uriKey ? normalizeUriKey(uriKey) : '';
  const cleanThread = String(threadId || '').trim();
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    normalizeLiveEntriesMap(state);
    let entry = null;
    if (cleanUri) {
      entry = findEntryByUriKey(state, cleanUri);
    }
    if (!entry && cleanThread) {
      entry = findOpenEntryByThreadId(cleanThread);
    }
    if (entry?.instance) {
      return { entry, instance: entry.instance };
    }
    await new Promise((r) => setTimeout(r, 60));
  }
  normalizeLiveEntriesMap(state);
  const finalEntry =
    (cleanUri && findEntryByUriKey(state, cleanUri)) ||
    (cleanThread && findOpenEntryByThreadId(cleanThread)) ||
    null;
  return { entry: finalEntry, instance: finalEntry?.instance || null };
}

async function sendDirectCascadeRpcMessage(port, csrfToken, cascadeId, options = {}) {
  const cleanPort = Number(port || 0);
  const cleanToken = String(csrfToken || '').trim();
  const cleanId = String(cascadeId || '').trim();
  const cleanPrompt = String(options.prompt || options.text || '').trim();
  const timeoutMs = Math.max(2500, Number(options.timeoutMs || 6500));
  const stepHint = Math.max(0, Number(options.stepHint || 0));
  if (!cleanPort || !cleanToken || !cleanId || !cleanPrompt) {
    return { ok: false, reason: 'invalid_args' };
  }
  const extractLastUserInput = (rawList) => {
    if (!Array.isArray(rawList)) return null;
    for (let i = rawList.length - 1; i >= 0; i -= 1) {
      const st = rawList[i];
      if (st?.type === 'CORTEX_STEP_TYPE_USER_INPUT' && st?.userInput?.userConfig) {
        return st.userInput;
      }
    }
    return null;
  };
  let lastUserInput = null;
  if (stepHint > 8) {
    const tailRes = await postHubRpcJson(
      cleanPort,
      cleanToken,
      'GetCascadeTrajectorySteps',
      {
        cascadeId: cleanId,
        stepOffset: Math.max(0, stepHint - 6),
        stepLimit: 10
      },
      Math.min(3500, timeoutMs)
    );
    lastUserInput = extractLastUserInput(tailRes?.json?.steps);
  }
  if (!lastUserInput?.userConfig) {
    const headRes = await postHubRpcJson(
      cleanPort,
      cleanToken,
      'GetCascadeTrajectorySteps',
      {
        cascadeId: cleanId,
        stepOffset: 0,
        stepLimit: 8
      },
      Math.min(3500, timeoutMs)
    );
    lastUserInput = extractLastUserInput(headRes?.json?.steps);
  }
  if (!lastUserInput?.userConfig) {
    const fullRes = await postHubRpcJson(
      cleanPort,
      cleanToken,
      'GetCascadeTrajectorySteps',
      { cascadeId: cleanId },
      Math.min(4500, timeoutMs)
    );
    lastUserInput = extractLastUserInput(fullRes?.json?.steps);
  }
  if (!lastUserInput?.userConfig) {
    return { ok: false, reason: 'missing_user_config' };
  }
  const isCompactSlash =
    cleanPrompt === '/compact' || /^\[\/compact\]\(slashCommand;compact\)$/i.test(cleanPrompt);
  const items = isCompactSlash
    ? [
        {
          item: {
            slashCommand: {
              info: {
                name: 'compact',
                type: 'SLASH_COMMAND_TYPE_SYSTEM',
                icon: 'collapse_all'
              }
            }
          }
        },
        { text: ' ' }
      ]
    : [{ text: cleanPrompt }];
  const planModelOverride = String(options.planModel || '').trim();
  let effectiveCascadeConfig = lastUserInput.userConfig;
  if (planModelOverride && /^MODEL_(?:PLACEHOLDER_M\d+|OPENAI_GPT_OSS_120B_MEDIUM)$/i.test(planModelOverride)) {
    try {
      effectiveCascadeConfig = JSON.parse(JSON.stringify(lastUserInput.userConfig));
      if (!effectiveCascadeConfig.plannerConfig || typeof effectiveCascadeConfig.plannerConfig !== 'object') {
        effectiveCascadeConfig.plannerConfig = {};
      }
      effectiveCascadeConfig.plannerConfig.planModel = planModelOverride;
    } catch {}
  }
  const rpcRes = await postHubRpcJson(
    cleanPort,
    cleanToken,
    'SendUserCascadeMessage',
    {
      cascadeId: cleanId,
      items,
      cascadeConfig: effectiveCascadeConfig,
      ...(lastUserInput.userAgentSpec ? { customAgentSpec: lastUserInput.userAgentSpec } : {}),
      clientMessageId:
        typeof crypto.randomUUID === 'function'
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(16).slice(2, 10)}`
    },
    timeoutMs
  );
  if (rpcRes?.ok) {
    return {
      ok: true,
      sendSucceeded: true,
      method: 'directRpc',
      id: cleanId
    };
  }
  return {
    ok: false,
    status: Number(rpcRes?.status || 0),
    reason: 'rpc_failed'
  };
}

async function sendPromptToAntigravity(options = {}) {
  const state = getBridgeState();
  normalizeLiveEntriesMap(state);
  const promptText = String(options.prompt || options.text || '').trim();
  const threadId = String(options.id || options.threadId || '').trim();
  const isNew = Boolean(options.newSession || !threadId);
  const preserveFocus = Boolean(options.preserveFocus);
  const avoidTabReveal = Boolean(options.avoidTabReveal);
  const planModel = String(options.planModel || '').trim();
  const preferDirectRpc = Boolean(options.preferDirectRpc || planModel || promptText === '/compact');
  if (!promptText) {
    return { ok: false, error: 'Empty prompt' };
  }

  let directRpcAttempted = false;
  let directRpcReason = '';
  if (!isNew && threadId && preferDirectRpc) {
    const savedHub = readPersistentHubState();
    const port = Number(
      state.serverManager?.port || getProxyState()?.upstreamPort || savedHub?.port || 0
    );
    const csrfToken = String(
      state.serverManager?.csrfToken || getProxyState()?.csrfToken || savedHub?.csrfToken || ''
    ).trim();
    if (port > 0 && csrfToken) {
      directRpcAttempted = true;
      const directRes = await sendDirectCascadeRpcMessage(port, csrfToken, threadId, {
        prompt: promptText,
        stepHint: Number(options.stepHint || 0),
        planModel
      });
      if (directRes?.ok) {
        syncActiveTurnWakeLock(state, true);
        notifyActivityChanged({ type: 'remote-send', threadId });
        return {
          ok: true,
          sendSucceeded: true,
          method: 'directRpc',
          id: threadId,
          uri: ''
        };
      }
      directRpcReason = String(directRes?.reason || 'rpc_failed');
    }
  }
  const lexicalContextText =
    promptText === '/compact' ? '[/compact](slashCommand;compact) ' : promptText;

  let existingReadyEntry =
    !isNew && avoidTabReveal && threadId ? findOpenEntryByThreadId(threadId) : null;
  if (existingReadyEntry && !existingReadyEntry.instance) {
    existingReadyEntry = null;
  }
  if (
    !isNew &&
    threadId &&
    avoidTabReveal &&
    preferDirectRpc &&
    directRpcAttempted &&
    (!existingReadyEntry || existingReadyEntry.panel?.active !== true)
  ) {
    return {
      ok: false,
      sendSucceeded: false,
      error: directRpcReason || 'direct_rpc_failed_background_tab'
    };
  }

  let opened = null;
  if (isNew) {
    opened = await openNewSessionTab({
      preserveFocus,
      reuseEmptyDraft: options.reuseEmptyDraft !== false,
      pendingPromptSend: true
    });
  } else if (existingReadyEntry) {
    opened = { id: threadId, uri: existingReadyEntry.uriKey, reused: true };
  } else {
    opened = await openConversationTab({
      id: threadId,
      preserveFocus,
      avoidTabReveal,
      pendingPromptSend: true
    });
  }

  const apiImpl = state.apiImpl;
  if (apiImpl) {
    try {
      const { entry: targetEntry, instance: waitedInst } = await waitForEntryInstance(state, {
        uriKey: opened?.uri || '',
        threadId: isNew ? '' : threadId,
        timeoutMs: 6500
      });
      let inst = waitedInst;
      // Only fall back to the active/main instance when neither a new session nor a specific tab was requested
      if (!inst && !isNew && !opened?.uri && !threadId) {
        if (typeof apiImpl.ensureMainInstance === 'function') {
          inst = await apiImpl.ensureMainInstance();
        } else if (typeof apiImpl.getMainInstance === 'function') {
          inst = apiImpl.getMainInstance();
        }
      }
      if (inst?.ready) {
        await inst.ready;
      }
      if (targetEntry) {
        targetEntry.pendingPromptSend = true;
      }
      if (typeof apiImpl.addContext === 'function' && typeof inst?.api?.triggerSend === 'function') {
        const origFocus = inst.focus;
        let resolvedId = '';
        let sendSucceeded = false;
        try {
          if (preserveFocus && typeof origFocus === 'function') {
            inst.focus = () => {};
          }
          if (isNew && typeof inst.api?.newConversation === 'function') {
            try {
              await inst.api.newConversation({});
              await new Promise((r) => setTimeout(r, 80));
            } catch {}
          }

          let needContext = true;
          const maxAttempts = avoidTabReveal ? 18 : 10;
          for (let attempt = 0; attempt < maxAttempts; attempt++) {
            try {
              if (needContext) {
                const prevLocked = apiImpl.__bhfLockedInstance;
                apiImpl.__bhfLockedInstance = inst;
                try {
                  await apiImpl.addContext(lexicalContextText);
                } finally {
                  if (apiImpl.__bhfLockedInstance === inst) {
                    apiImpl.__bhfLockedInstance = prevLocked || null;
                  }
                }
                await new Promise((r) => setTimeout(r, 60));
                needContext = false;
              }
              await inst.api.triggerSend({});
              sendSucceeded = true;
              break;
            } catch (sendErr) {
              const errMsg = String(sendErr?.message || sendErr || '');
              if (errMsg.includes('bhf_send_empty') || errMsg.includes('Lexical editor')) {
                needContext = true;
                await new Promise((r) => setTimeout(r, 220));
              } else {
                await new Promise((r) => setTimeout(r, 280));
              }
            }
          }

          if (sendSucceeded && targetEntry) {
            targetEntry.promptSent = true;
          }

          const readResolvedId = () => {
            if (!isNew) {
              return threadId || targetEntry?.conversationId || opened?.id || '';
            }
            const byUri = opened?.uri ? state.entriesByUriKey.get(opened.uri) : null;
            return targetEntry?.conversationId || byUri?.conversationId || '';
          };

          resolvedId = readResolvedId();
          if (isNew && !resolvedId) {
            const idDeadline = Date.now() + 3800;
            let retriedTrigger = false;
            while (Date.now() < idDeadline && !resolvedId) {
              await new Promise((r) => setTimeout(r, 120));
              resolvedId = readResolvedId();
              if (
                !retriedTrigger &&
                !resolvedId &&
                idDeadline - Date.now() < 2400 &&
                typeof inst?.api?.triggerSend === 'function'
              ) {
                retriedTrigger = true;
                try {
                  const prevLocked = apiImpl.__bhfLockedInstance;
                  apiImpl.__bhfLockedInstance = inst;
                  try {
                    await apiImpl.addContext(promptText);
                  } finally {
                    if (apiImpl.__bhfLockedInstance === inst) {
                      apiImpl.__bhfLockedInstance = prevLocked || null;
                    }
                  }
                  await new Promise((r) => setTimeout(r, 60));
                  await inst.api.triggerSend({});
                  sendSucceeded = true;
                } catch {}
              }
            }
          }
        } finally {
          if (preserveFocus && typeof origFocus === 'function') {
            inst.focus = origFocus;
          }
        }
        if (targetEntry) {
          targetEntry.pendingPromptSend = false;
        }
        if (sendSucceeded && (!isNew || resolvedId)) {
          syncActiveTurnWakeLock(state, true);
          notifyActivityChanged({ type: 'remote-send', threadId: resolvedId });
          return {
            ok: true,
            sendSucceeded: true,
            method: 'apiImpl',
            id: resolvedId,
            uri: opened?.uri || ''
          };
        }
      }
    } catch {}
  }

  const queued = enqueueRemoteWebviewAction({
    id: isNew ? '__new__' : threadId || '*',
    kind: 'prompt',
    text: promptText
  });
  notifyActivityChanged({ type: 'remote-send-queued', threadId: isNew ? '' : threadId });
  return {
    ok: true,
    sendSucceeded: true,
    method: 'webviewQueue',
    id: isNew ? '' : threadId || opened?.id || '',
    uri: opened?.uri || '',
    actionId: queued.actionId
  };
}

function getResumedCascadesFilePath() {
  if (process.env.THEO_RESUMED_CASCADES_PATH) {
    return process.env.THEO_RESUMED_CASCADES_PATH;
  }
  return path.join(os.homedir(), '.gemini', 'antigravity', 'bhf-resumed-cascades.json');
}

function readResumedCascadesState() {
  try {
    const filePath = getResumedCascadesFilePath();
    if (!fs.existsSync(filePath)) {
      return {};
    }
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function writeResumedCascadesState(mapObj = {}) {
  try {
    const filePath = getResumedCascadesFilePath();
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, JSON.stringify(mapObj, null, 2), 'utf8');
  } catch {}
}

function fetchCascadeRunStatesDetailed(port, csrfToken, timeoutMs = 4500) {
  return new Promise((resolve) => {
    const cleanPort = Number(port || 0);
    const cleanToken = String(csrfToken || '').trim();
    if (!cleanPort || !cleanToken) {
      resolve({ reachable: false, invalidArgs: true, summaries: null });
      return;
    }
    const payload = '{}';
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: cleanPort,
        path: '/exa.language_server_pb.LanguageServerService/GetAllCascadeTrajectories',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': cleanToken,
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        if (!res.statusCode || res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          resolve({
            reachable: false,
            status: res.statusCode || 0,
            httpError: true,
            summaries: null
          });
          return;
        }
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          try {
            const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            resolve({
              reachable: true,
              status: res.statusCode,
              summaries: parsed?.trajectorySummaries || {}
            });
          } catch {
            resolve({ reachable: false, parseError: true, summaries: null });
          }
        });
      }
    );
    req.on('timeout', () => {
      try {
        req.destroy();
      } catch {}
      resolve({ reachable: false, timedOut: true, summaries: null });
    });
    req.on('error', (err) => {
      const code = String(err?.code || '');
      const msg = String(err?.message || code || 'error');
      resolve({
        reachable: false,
        connectionRefused: code === 'ECONNREFUSED' || /ECONNREFUSED/i.test(msg),
        error: msg,
        summaries: null
      });
    });
    req.write(payload);
    req.end();
  });
}

function fetchCascadeRunStates(port, csrfToken, timeoutMs = 4500) {
  return fetchCascadeRunStatesDetailed(port, csrfToken, timeoutMs).then(
    (r) => (r && r.reachable ? r.summaries : null),
    () => null
  );
}

function fetchCascadeStepsRange(
  port,
  csrfToken,
  cascadeId,
  stepOffset,
  stepLimit = 10,
  timeoutMs = 3500
) {
  return new Promise((resolve) => {
    const cleanPort = Number(port || 0);
    const cleanToken = String(csrfToken || '').trim();
    const cleanId = String(cascadeId || '').trim();
    const offset = Math.max(0, Number(stepOffset || 0));
    const limit = Math.max(1, Math.min(50, Number(stepLimit || 10)));
    if (!cleanPort || !cleanToken || !cleanId) {
      resolve(null);
      return;
    }
    const payload = JSON.stringify({
      cascadeId: cleanId,
      stepOffset: offset,
      stepLimit: limit
    });
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: cleanPort,
        path: '/exa.language_server_pb.LanguageServerService/GetCascadeTrajectorySteps',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': cleanToken,
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        if (!res.statusCode || res.statusCode < 200 || res.statusCode >= 300) {
          res.resume();
          resolve(null);
          return;
        }
        const chunks = [];
        res.on('data', (chunk) => chunks.push(chunk));
        res.on('end', () => {
          try {
            const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            const rawSteps = Array.isArray(parsed?.steps) ? parsed.steps : [];
            const byIndex = new Map();
            rawSteps.forEach((st, i) => {
              const idx =
                typeof st?.metadata?.stepIndex === 'number'
                  ? st.metadata.stepIndex
                  : offset + i;
              byIndex.set(idx, st);
            });
            resolve(byIndex);
          } catch {
            resolve(null);
          }
        });
      }
    );
    req.on('timeout', () => {
      try {
        req.destroy();
      } catch {}
      resolve(null);
    });
    req.on('error', () => resolve(null));
    req.write(payload);
    req.end();
  });
}

const TRANSIENT_NETWORK_ERROR_RE =
  /\b(no such host|wsarecv|wsasend|dial tcp|connection reset|connection refused|connection loss|cannot rewind body|network is unreachable|tls handshake timeout|stream was interrupted|network issue connecting to the server|unexpected eof|eof|i\/o timeout|socket hang up|broken pipe|connection closed|http2: client connection lost|client connection force closed|clientconn\.close|forcibly closed by the remote host|server closed idle connection|temporary failure in name resolution)\b/i;

const STREAM_INTERRUPTION_HINT_RE =
  /\b(stream was interrupted|stream idle timeout|stream reading error|client connection force closed|clientconn\.close|http2: client connection lost|cannot rewind body|connection loss|forcibly closed by the remote host|network issue connecting to the server|unexpected eof|eof|wsarecv|wsasend|connection reset)\b/i;

const CHUNKED_STREAM_RESUME_PROMPT =
  'continue — Note: the previous response stream was interrupted or timed out before completing its tool call. Do NOT emit a single giant write_file or edit_file call; apply file changes in smaller incremental chunks (<200 lines per call) or via a compact script so each step finishes quickly.';

function isAutoContinueUserPrompt(raw) {
  const s = String(raw || '').trim();
  if (!s) return false;
  return (
    /^<USER_REQUEST>\s*continue(?:\s*(?:\/compact|\[\/compact\]\(slashCommand;compact\)))?(?:\s+—\s+Note:\s+the previous response stream was interrupted[\s\S]*?)?\s*<\/USER_REQUEST>/i.test(
      s
    ) ||
    /^continue(?:\s*(?:\/compact|\[\/compact\]\(slashCommand;compact\)))?(?:\s+—\s+Note:\s+the previous response stream was interrupted[\s\S]*?)?$/i.test(
      s
    ) ||
    /^<USER_REQUEST>\s*(?:\/compact|\[\/compact\]\(slashCommand;compact\))(?=\s|<|$)[\s\S]*?<\/USER_REQUEST>/i.test(
      s
    ) ||
    /^(?:\/compact|\[\/compact\]\(slashCommand;compact\))(?:\s+.*)?$/i.test(s)
  );
}

function isTransientNetworkErrorText(raw) {
  const s = String(raw || '').trim();
  if (!s) return false;
  if (
    /\b(context deadline exceeded|quota|rate limit|resource_exhausted|invalid_argument|context length|token limit|permission_denied)\b/i.test(
      s
    )
  ) {
    return false;
  }
  return TRANSIENT_NETWORK_ERROR_RE.test(s);
}

let __bhfNetOnlineCache = { ok: false, checkedAt: 0 };

function probeUpstreamNetworkOnline(timeoutMs = 2500) {
  const now = Date.now();
  if (
    __bhfNetOnlineCache.ok &&
    __bhfNetOnlineCache.checkedAt > 0 &&
    now - __bhfNetOnlineCache.checkedAt < 3000
  ) {
    return Promise.resolve(true);
  }
  return new Promise((resolve) => {
    let settled = false;
    let tcpSock = null;
    const finish = (ok) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (tcpSock) {
        try {
          tcpSock.destroy();
        } catch {}
        tcpSock = null;
      }
      __bhfNetOnlineCache = { ok: Boolean(ok), checkedAt: ok ? Date.now() : 0 };
      resolve(Boolean(ok));
    };
    const timer = setTimeout(() => {
      finish(false);
    }, timeoutMs);
    if (typeof timer?.unref === 'function') timer.unref();
    try {
      dns.lookup('daily-cloudcode-pa.googleapis.com', (err, address) => {
        if (settled) return;
        if (err || !address) {
          finish(false);
          return;
        }
        if (process.env.THEO_SMOKE_TEST === '1') {
          finish(true);
          return;
        }
        try {
          tcpSock = net.createConnection({ host: address, port: 443 });
          if (typeof tcpSock?.unref === 'function') tcpSock.unref();
          tcpSock.once('connect', () => finish(true));
          tcpSock.once('error', () => finish(false));
          tcpSock.once('timeout', () => finish(false));
        } catch {
          finish(false);
        }
      });
    } catch {
      finish(false);
    }
  });
}

function inspectCascadeInterruptedState(
  conversationId,
  nowSec = Math.floor(Date.now() / 1000),
  options = {}
) {
  const cleanId = String(conversationId || '').trim();
  if (!cleanId) {
    return { interrupted: false };
  }
  const bypassMinAge = Boolean(options?.bypassMinAge);
  const forceResume = Boolean(options?.forceResume);
  const pendingPostCompactResume = Boolean(options?.pendingPostCompactResume);
  const pendingCompactStepIndex = Math.max(0, Number(options?.pendingCompactStepIndex || 0));
  const pendingCompactAt = Math.max(0, Number(options?.pendingCompactAt || 0));
  const hubStartedAtSec = Number(options?.hubStartedAtSec || 0);
  try {
    const brainRoot =
      process.env.THEO_BRAIN_ROOT_DIR || path.join(os.homedir(), '.gemini', 'antigravity', 'brain');
    const transcriptPath = path.join(
      brainRoot,
      cleanId,
      '.system_generated',
      'logs',
      'transcript.jsonl'
    );
    if (!fs.existsSync(transcriptPath)) {
      return { interrupted: false };
    }
    const stat = fs.statSync(transcriptPath);
    const mtimeSec = Math.floor(stat.mtimeMs / 1000);
    const raw = fs.readFileSync(transcriptPath, 'utf8');
    const lines = raw.split(/\r?\n/);
    const steps = [];
    let maxStepIndex = 0;
    let maxInputTokens = 0;
    let postCheckpointMaxInputTokens = 0;
    let lastStepAt = mtimeSec;
    const pendingTasks = new Map();
    const recentRunCmdIsDaemonQueue = [];

    for (const line of lines) {
      if (!line || line[0] !== '{') {
        continue;
      }
      let step;
      try {
        step = JSON.parse(line);
      } catch {
        continue;
      }
      steps.push(step);
      const idx = Number(step.step_index || 0);
      if (idx > maxStepIndex) {
        maxStepIndex = idx;
      }
      if (step.type === 'CHECKPOINT') {
        postCheckpointMaxInputTokens = 0;
      }
      const stepInTokens =
        Number(step.input_tokens || 0) + Number(step.cache_read_tokens || 0);
      if (stepInTokens > maxInputTokens) {
        maxInputTokens = stepInTokens;
      }
      if (stepInTokens > postCheckpointMaxInputTokens) {
        postCheckpointMaxInputTokens = stepInTokens;
      }
      let stepTs = 0;
      if (typeof step.created_at === 'string') {
        const ts = Math.floor(Date.parse(step.created_at) / 1000);
        if (Number.isFinite(ts) && ts > 0) {
          stepTs = ts;
          if (ts > lastStepAt) {
            lastStepAt = ts;
          }
        }
      }
      const stType = step.type || '';
      const stStatus = step.status || '';
      const content = typeof step.content === 'string' ? step.content : '';
      if (stType === 'USER_INPUT') {
        pendingTasks.clear();
        recentRunCmdIsDaemonQueue.length = 0;
      } else if (
        stType === 'SYSTEM_MESSAGE' &&
        content.includes('All your subagents and background tasks have been stopped')
      ) {
        pendingTasks.clear();
      }
      if (stType === 'PLANNER_RESPONSE' && Array.isArray(step.tool_calls)) {
        recentRunCmdIsDaemonQueue.length = 0;
        for (const tc of step.tool_calls) {
          if (!tc || typeof tc !== 'object') continue;
          if (tc.name === 'run_command') {
            let parsedArgs = tc.arguments ?? tc.args ?? null;
            if (typeof parsedArgs === 'string') {
              try {
                parsedArgs = JSON.parse(parsedArgs);
              } catch {
                parsedArgs = null;
              }
            }
            recentRunCmdIsDaemonQueue.push(Boolean(parsedArgs?.IsDaemon));
          } else if (
            tc.name === 'manage_task' &&
            pendingTasks.size > 0
          ) {
            let parsedArgs = tc.arguments ?? tc.args ?? null;
            if (typeof parsedArgs === 'string') {
              try {
                parsedArgs = JSON.parse(parsedArgs);
              } catch {
                parsedArgs = null;
              }
            }
            if (parsedArgs?.Action === 'kill' && parsedArgs?.TaskId) {
              pendingTasks.delete(String(parsedArgs.TaskId).trim());
            }
          }
        }
      }
      if (
        stType === 'GENERIC' &&
        stStatus === 'RUNNING' &&
        content.includes('background task with task id:')
      ) {
        const mId = content.match(/background task with task id:\s*(\S+)/);
        const isDaemon =
          recentRunCmdIsDaemonQueue.length > 0 ? Boolean(recentRunCmdIsDaemonQueue.shift()) : false;
        if (mId) {
          pendingTasks.set(mId[1].trim(), {
            stepIndex: idx,
            startedAtSec: stepTs || mtimeSec,
            isDaemon
          });
        }
      } else if (stType === 'GENERIC' && stStatus === 'DONE' && recentRunCmdIsDaemonQueue.length > 0) {
        recentRunCmdIsDaemonQueue.shift();
      } else if (content && pendingTasks.size > 0) {
        const senderRe = /sender=(\S+\/task-\d+)/g;
        let m;
        while ((m = senderRe.exec(content)) !== null) {
          pendingTasks.delete(m[1]);
        }
        const cancelRe = /Task "(\S+\/task-\d+)" cancel/g;
        while ((m = cancelRe.exec(content)) !== null) {
          pendingTasks.delete(m[1]);
        }
      }
    }

    if (steps.length === 0) {
      return { interrupted: false };
    }

    const validPendingPostCompact =
      Boolean(pendingPostCompactResume) &&
      (!pendingCompactAt || nowSec - pendingCompactAt <= 900) &&
      (!pendingCompactStepIndex ||
        (maxStepIndex > pendingCompactStepIndex && maxStepIndex <= pendingCompactStepIndex + 4));
    const minAgeSec = bypassMinAge || forceResume ? 0 : validPendingPostCompact ? 4 : 25;
    const maxAgeSec =
      Number.isFinite(Number(options?.maxAgeSec)) && Number(options.maxAgeSec) > 0
        ? Number(options.maxAgeSec)
        : 86400;
    const ageSec = nowSec - Math.max(mtimeSec, lastStepAt);
    if (ageSec > maxAgeSec) {
      return { interrupted: false };
    }
    if (ageSec < minAgeSec) {
      return {
        interrupted: false,
        reason: 'below_min_age',
        maxStepIndex,
        lastStepAt,
        ageSec
      };
    }

    let killedNonDaemonTaskOnRestart = false;
    const recentPendingTaskSteps = [];
    for (const [taskId, taskInfo] of pendingTasks.entries()) {
      const startedBeforeCurrentHub =
        hubStartedAtSec > 0 &&
        taskInfo.startedAtSec > 0 &&
        taskInfo.startedAtSec < hubStartedAtSec;
      if (startedBeforeCurrentHub) {
        if (!taskInfo.isDaemon && nowSec - taskInfo.startedAtSec <= 3600) {
          killedNonDaemonTaskOnRestart = true;
        }
        continue;
      }
      if (maxStepIndex - taskInfo.stepIndex <= 25) {
        recentPendingTaskSteps.push({
          taskId,
          stepIndex: taskInfo.stepIndex,
          startedAtSec: taskInfo.startedAtSec,
          isDaemon: Boolean(taskInfo.isDaemon)
        });
      }
    }
    if (recentPendingTaskSteps.length > 0) {
      return {
        interrupted: false,
        reason: 'pending_bg_task',
        stepIndex: Math.max(1, maxStepIndex),
        lastStepAt,
        pendingTaskSteps: recentPendingTaskSteps
      };
    }

    let last = null;
    for (let i = steps.length - 1; i >= 0; i -= 1) {
      if (steps[i].type !== 'SYSTEM_MESSAGE') {
        last = steps[i];
        break;
      }
    }
    if (!last) {
      return { interrupted: false };
    }

    const rawLast = steps[steps.length - 1];
    const lType = last.type || '';
    const lStatus = last.status || '';
    const lContent = String(last.content || '').trim();
    const lToolCalls = Array.isArray(last.tool_calls) ? last.tool_calls : [];
    const lIdx = Number(last.step_index || 0);

    for (const tc of lToolCalls) {
      if (tc && tc.name === 'ask_question') {
        return { interrupted: false, reason: 'ask_question' };
      }
    }

    let lastUserIdx = -1;
    let lastUserTxt = '';
    let lastUserTxtSinceCheckpoint = '';
    let sawCheckpointAfterLastUser = false;
    for (let i = steps.length - 1; i >= 0; i -= 1) {
      if (steps[i].type === 'CHECKPOINT') {
        sawCheckpointAfterLastUser = true;
      } else if (steps[i].type === 'USER_INPUT') {
        lastUserIdx = i;
        lastUserTxt = String(steps[i].content || '').trim();
        if (!sawCheckpointAfterLastUser) {
          lastUserTxtSinceCheckpoint = lastUserTxt;
        }
        break;
      }
    }
    const alreadyTriedCompactSinceCheckpoint =
      Boolean(validPendingPostCompact) ||
      /^<USER_REQUEST>\s*(?:\/compact|\[\/compact\]\(slashCommand;compact\))(?=\s|<|$)/i.test(
        lastUserTxtSinceCheckpoint
      ) ||
      /^(?:\/compact|\[\/compact\]\(slashCommand;compact\))(?=\s|$)/i.test(
        lastUserTxtSinceCheckpoint
      );
    const alreadyTriedChunkedSinceCheckpoint =
      alreadyTriedCompactSinceCheckpoint ||
      /\bNote:\s+the previous response stream was interrupted\b/i.test(lastUserTxtSinceCheckpoint) ||
      /\bNote:\s+the previous response stream was interrupted\b/i.test(lastUserTxt);
    let turnPrecededByAutoContinue = false;
    if (lastUserIdx >= 0 && lastUserTxt && isAutoContinueUserPrompt(lastUserTxt)) {
      let hasCompletedToolSinceUser = false;
      for (let k = lastUserIdx + 1; k < steps.length; k += 1) {
        const tk = steps[k]?.type || '';
        const sk = steps[k]?.status || '';
        if ((tk === 'GENERIC' || tk === 'TOOL_RESPONSE') && sk === 'DONE') {
          hasCompletedToolSinceUser = true;
          break;
        }
      }
      if (!hasCompletedToolSinceUser) {
        for (let j = lastUserIdx - 1; j >= 0; j -= 1) {
          const sj = steps[j];
          const tj = sj.type || '';
          if (tj === 'SYSTEM_MESSAGE') continue;
          const tcsJ = Array.isArray(sj.tool_calls) ? sj.tool_calls : [];
          const txtJ = String(sj.content || '').trim();
          if (tj === 'PLANNER_RESPONSE' && !txtJ && tcsJ.length === 0) continue;
          if (tj === 'ERROR_MESSAGE' || tj === 'CHECKPOINT') {
            turnPrecededByAutoContinue = true;
          }
          break;
        }
      }
    }

    if (lType === 'ERROR_MESSAGE') {
      let consecutiveErrors = 0;
      let allTransientNetworkErrors = true;
      let hasExplicitTransientNetworkError = false;
      let hasStreamIdleTimeoutError = false;
      let hasStreamInterruptionHint = false;
      let preErrorIdx = -1;
      for (let i = steps.length - 1; i >= 0; i -= 1) {
        const st = steps[i];
        const t = st.type || '';
        if (t === 'SYSTEM_MESSAGE') continue;
        // agy.exe appends an empty PLANNER_RESPONSE (no content, no tool_calls) before each
        // retry attempt in run.go; skip those so alternating PLANNER_RESPONSE -> ERROR_MESSAGE
        // retry loops are counted as consecutive errors.
        const tcs = Array.isArray(st.tool_calls) ? st.tool_calls : [];
        const txt = String(st.content || '').trim();
        if (t === 'PLANNER_RESPONSE' && !txt && tcs.length === 0) continue;
        if (t === 'ERROR_MESSAGE') {
          consecutiveErrors += 1;
          const errText = `${st.error || ''} ${st.content || ''}`.trim();
          if (STREAM_INTERRUPTION_HINT_RE.test(errText)) {
            hasStreamInterruptionHint = true;
          }
          if (isTransientNetworkErrorText(errText)) {
            hasExplicitTransientNetworkError = true;
          } else if (
            /\bstream idle timeout\b/i.test(errText) &&
            !/\b(quota|rate limit|resource_exhausted|invalid_argument|context length|token limit|permission_denied)\b/i.test(
              errText
            )
          ) {
            hasStreamIdleTimeoutError = true;
          } else {
            allTransientNetworkErrors = false;
          }
        } else {
          preErrorIdx = i;
          break;
        }
      }
      const effectiveAllTransient =
        allTransientNetworkErrors &&
        (!hasStreamIdleTimeoutError || hasExplicitTransientNetworkError);
      let prevUserTxt = '';
      if (preErrorIdx >= 0 && steps[preErrorIdx]?.type === 'USER_INPUT') {
        prevUserTxt = String(steps[preErrorIdx].content || '').trim();
      }
      const alreadyTriedCompact =
        Boolean(alreadyTriedCompactSinceCheckpoint) ||
        /^<USER_REQUEST>\s*(?:\/compact|\[\/compact\]\(slashCommand;compact\))(?=\s|<|$)/i.test(
          prevUserTxt
        ) ||
        /^(?:\/compact|\[\/compact\]\(slashCommand;compact\))(?=\s|$)/i.test(prevUserTxt);
      const alreadyTriedChunked =
        alreadyTriedCompact ||
        alreadyTriedChunkedSinceCheckpoint ||
        /\bNote:\s+the previous response stream was interrupted\b/i.test(prevUserTxt);
      let isRetryAfterPriorErrorOrCheckpoint = false;
      if (prevUserTxt && isAutoContinueUserPrompt(prevUserTxt)) {
        for (let j = preErrorIdx - 1; j >= 0; j -= 1) {
          const sj = steps[j];
          const tj = sj.type || '';
          if (tj === 'SYSTEM_MESSAGE') continue;
          const tcsJ = Array.isArray(sj.tool_calls) ? sj.tool_calls : [];
          const txtJ = String(sj.content || '').trim();
          if (tj === 'PLANNER_RESPONSE' && !txtJ && tcsJ.length === 0) continue;
          if (tj === 'ERROR_MESSAGE' || tj === 'CHECKPOINT') {
            isRetryAfterPriorErrorOrCheckpoint = true;
          }
          break;
        }
      }
      const useChunkedResume =
        !alreadyTriedChunked &&
        hasStreamInterruptionHint &&
        (consecutiveErrors >= 2 ||
          postCheckpointMaxInputTokens >= 180000 ||
          isRetryAfterPriorErrorOrCheckpoint);
      const needsCompactionFirst =
        !alreadyTriedCompact &&
        hasStreamInterruptionHint &&
        postCheckpointMaxInputTokens >= 215000;
      const effectiveErrorResumePrompt = needsCompactionFirst
        ? '/compact'
        : useChunkedResume
          ? CHUNKED_STREAM_RESUME_PROMPT
          : 'continue';
      const precededByAutoContinue =
        isRetryAfterPriorErrorOrCheckpoint &&
        (alreadyTriedChunked || (!needsCompactionFirst && !useChunkedResume));
      if (precededByAutoContinue) {
        return { interrupted: false, reason: 'repeated_error_message' };
      }
      if (consecutiveErrors >= 2) {
        // Allow ONE automatic recovery once upstream DNS/network returns if every consecutive
        // error was a transient network/stream drop (e.g. Wi-Fi drop, EOF, or mid-stream cut-off),
        // while still blocking pure context-deadline / quota / repeated continue-to-error loops.
        if (effectiveAllTransient) {
          return {
            interrupted: true,
            stepIndex: maxStepIndex,
            lastStepAt,
            ageSec,
            reason: 'transient_network_error',
            requiresNetworkCheck: true,
            maxInputTokens,
            postCheckpointMaxInputTokens,
            alreadyTriedCompact,
            alreadyTriedChunked,
            needsCompactionFirst,
            resumePrompt: effectiveErrorResumePrompt
          };
        }
        return { interrupted: false, reason: 'repeated_error_message' };
      }
      const singleErrText = `${last.error || ''} ${last.content || ''}`.trim();
      return {
        interrupted: true,
        stepIndex: maxStepIndex,
        lastStepAt,
        ageSec,
        reason: 'error_message',
        requiresNetworkCheck: isTransientNetworkErrorText(singleErrText),
        maxInputTokens,
        postCheckpointMaxInputTokens,
        alreadyTriedCompact,
        alreadyTriedChunked,
        needsCompactionFirst,
        resumePrompt: effectiveErrorResumePrompt
      };
    }
    if (lType === 'CHECKPOINT' && validPendingPostCompact) {
      return {
        interrupted: true,
        stepIndex: maxStepIndex,
        lastStepAt,
        ageSec,
        reason: 'post_compact_auto_resume',
        resumePrompt: CHUNKED_STREAM_RESUME_PROMPT
      };
    }
    if (lType === 'USER_INPUT') {
      const lastUserTs =
        typeof last.created_at === 'string'
          ? Math.floor(Date.parse(last.created_at) / 1000)
          : 0;
      if (
        isAutoContinueUserPrompt(lContent) &&
        (!hubStartedAtSec || !lastUserTs || lastUserTs >= hubStartedAtSec)
      ) {
        return {
          interrupted: false,
          reason: 'already_sent_continue',
          maxStepIndex,
          lastStepAt,
          ageSec,
          lastType: lType,
          maxInputTokens,
          postCheckpointMaxInputTokens,
          alreadyTriedCompact: alreadyTriedCompactSinceCheckpoint,
          alreadyTriedChunked: alreadyTriedChunkedSinceCheckpoint,
          turnPrecededByAutoContinue
        };
      }
      return {
        interrupted: true,
        stepIndex: maxStepIndex,
        lastStepAt,
        ageSec,
        reason: 'unanswered_user_input'
      };
    }
    if (lType === 'GENERIC' && (lStatus === 'DONE' || lStatus === 'ERROR')) {
      for (let i = steps.length - 2; i >= 0; i -= 1) {
        if (steps[i].type === 'PLANNER_RESPONSE') {
          const prevTcs = Array.isArray(steps[i].tool_calls) ? steps[i].tool_calls : [];
          if (prevTcs.some((tc) => tc && tc.name === 'ask_question')) {
            return { interrupted: false, reason: 'preceding_ask_question' };
          }
          break;
        }
      }
      return {
        interrupted: true,
        stepIndex: maxStepIndex,
        lastStepAt,
        ageSec,
        reason: 'unfinished_tool_turn',
        maxInputTokens,
        postCheckpointMaxInputTokens,
        alreadyTriedCompact: alreadyTriedCompactSinceCheckpoint,
        alreadyTriedChunked: alreadyTriedChunkedSinceCheckpoint,
        turnPrecededByAutoContinue
      };
    }
    if (
      lType === 'PLANNER_RESPONSE' &&
      lStatus !== 'CANCELED' &&
      (!lContent || lToolCalls.length > 0) &&
      lIdx === maxStepIndex
    ) {
      const needsCompactionFirst =
        !alreadyTriedCompactSinceCheckpoint && postCheckpointMaxInputTokens >= 215000;
      const useChunkedResume =
        !alreadyTriedChunkedSinceCheckpoint && postCheckpointMaxInputTokens >= 180000;
      const plannerResumePrompt = needsCompactionFirst
        ? '/compact'
        : useChunkedResume
          ? CHUNKED_STREAM_RESUME_PROMPT
          : 'continue';
      return {
        interrupted: true,
        stepIndex: maxStepIndex,
        lastStepAt,
        ageSec,
        reason: 'unfinished_planner_tool_call',
        maxInputTokens,
        postCheckpointMaxInputTokens,
        alreadyTriedCompact: alreadyTriedCompactSinceCheckpoint,
        alreadyTriedChunked: alreadyTriedChunkedSinceCheckpoint,
        turnPrecededByAutoContinue,
        needsCompactionFirst,
        resumePrompt: plannerResumePrompt
      };
    }
    if (killedNonDaemonTaskOnRestart) {
      return {
        interrupted: true,
        stepIndex: Math.max(1, maxStepIndex),
        lastStepAt,
        ageSec,
        reason: 'interrupted_bg_task_on_hub_restart'
      };
    }
    if (
      rawLast &&
      rawLast.type === 'SYSTEM_MESSAGE' &&
      !String(rawLast.content || '').includes('All your subagents and background tasks have been stopped')
    ) {
      return {
        interrupted: true,
        stepIndex: Math.max(1, maxStepIndex),
        lastStepAt,
        ageSec,
        reason: 'unanswered_system_wakeup'
      };
    }
    if (forceResume) {
      return {
        interrupted: true,
        stepIndex: Math.max(1, maxStepIndex),
        lastStepAt,
        ageSec,
        reason: 'interrupted_on_account_switch'
      };
    }

    return {
      interrupted: false,
      maxStepIndex,
      lastStepAt,
      ageSec,
      lastType: lType,
      maxInputTokens,
      postCheckpointMaxInputTokens,
      alreadyTriedCompact: alreadyTriedCompactSinceCheckpoint,
      alreadyTriedChunked: alreadyTriedChunkedSinceCheckpoint,
      turnPrecededByAutoContinue
    };
  } catch {
    return { interrupted: false };
  }
}

async function checkAndResumeInterruptedCascades(state, options = {}) {
  if (!state || state.resumeCheckInFlight) {
    return { resumed: 0, skippedInFlight: true };
  }
  state.resumeCheckInFlight = true;
  let resumedCount = 0;
  try {
    const openTabs = getOpenTabsSnapshot();
    const extraCandidateIds = Array.isArray(options.candidateIds)
      ? options.candidateIds.map((id) => String(id || '').trim()).filter(Boolean)
      : [];
    const forceIds = Array.isArray(options.forceResumeIds)
      ? options.forceResumeIds.map((id) => String(id || '').trim()).filter(Boolean)
      : [];
    const forceSet = new Set(forceIds);
    const candidateIds = Array.from(
      new Set([
        ...openTabs.map((t) => String(t.id || '').trim()).filter(Boolean),
        ...extraCandidateIds,
        ...forceIds
      ])
    );
    const includeIdleSummaries = Boolean(options.includeIdleSummaries);
    if (candidateIds.length === 0 && !includeIdleSummaries) {
      return { resumed: 0 };
    }

    const savedHub = readPersistentHubState();
    const port = Number(state.serverManager?.port || savedHub?.port || 0);
    const csrfToken = String(
      state.serverManager?.csrfToken || getProxyState()?.csrfToken || savedHub?.csrfToken || ''
    ).trim();
    if (!port || !csrfToken) {
      return { resumed: 0 };
    }

    let summaries = await fetchCascadeRunStates(port, csrfToken, 5000);
    if (!summaries && (options.bypassMinAge || options.hubStartedAtSec)) {
      await new Promise((r) => setTimeout(r, 500));
      summaries = await fetchCascadeRunStates(port, csrfToken, 5000);
    }
    if (!summaries || typeof summaries !== 'object') {
      return { resumed: 0 };
    }
    if (includeIdleSummaries) {
      const seenSet = new Set(candidateIds);
      for (const [tid, sumObj] of Object.entries(summaries)) {
        const cleanTid = String(tid || '').trim();
        if (cleanTid && !seenSet.has(cleanTid) && sumObj?.status === 'CASCADE_RUN_STATUS_IDLE') {
          seenSet.add(cleanTid);
          candidateIds.push(cleanTid);
        }
      }
    }
    if (candidateIds.length === 0) {
      return { resumed: 0 };
    }

    const nowSec =
      Number(options.nowSec) > 0
        ? Math.floor(Number(options.nowSec))
        : Math.floor(Date.now() / 1000);
    const hubStartedAtSec = Number(options.hubStartedAtSec || savedHub?.startedAt || 0);
    const hubFreshlyBooted =
      Boolean(options.bypassMinAge) ||
      (hubStartedAtSec > 0 && nowSec - hubStartedAtSec < 120);

    const anyRunningInSummaries = Object.values(summaries).some(
      (sumObj) => sumObj?.status === 'CASCADE_RUN_STATUS_RUNNING'
    );

    const pendingApprovals = getPendingApprovals();
    const approvalIds = new Set(
      Array.isArray(pendingApprovals) ? pendingApprovals.map((a) => a.id) : []
    );
    const resumedMap = readResumedCascadesState();
    const onlyReasons = Array.isArray(options.onlyReasons) ? new Set(options.onlyReasons) : null;
    let changedResumed = false;

    for (const threadId of candidateIds) {
      if (approvalIds.has(threadId) || isCascadeRunningOnRetiringHub(state, threadId)) {
        continue;
      }
      const liveSummary = summaries[threadId];
      if (
        liveSummary?.status === 'CASCADE_RUN_STATUS_RUNNING' ||
        (Array.isArray(liveSummary?.waitingForUserSteps) &&
          liveSummary.waitingForUserSteps.length > 0) ||
        (!liveSummary && !hubFreshlyBooted && !forceSet.has(threadId))
      ) {
        continue;
      }
      const prevEntry = resumedMap[threadId];
      const prevCompactAt = Number(prevEntry?.resumedAt || 0);
      if (prevEntry?.pendingPostCompactResume && prevCompactAt > 0 && nowSec - prevCompactAt > 900) {
        delete prevEntry.pendingPostCompactResume;
        changedResumed = true;
      }
      let check = inspectCascadeInterruptedState(threadId, nowSec, {
        bypassMinAge: Boolean(options.bypassMinAge),
        forceResume: forceSet.has(threadId),
        pendingPostCompactResume: Boolean(prevEntry?.pendingPostCompactResume),
        pendingCompactStepIndex: Number(prevEntry?.stepIndex || 0),
        pendingCompactAt: prevCompactAt,
        hubStartedAtSec
      });
      if (prevEntry?.pendingPostCompactResume && check.reason !== 'post_compact_auto_resume') {
        const prevIdx = Math.max(0, Number(prevEntry.stepIndex || 0));
        const liveStepsAfterCompact = await fetchCascadeStepsRange(
          port,
          csrfToken,
          threadId,
          prevIdx,
          8,
          3500
        );
        if (liveStepsAfterCompact && liveStepsAfterCompact.size > 0) {
          let maxLiveIdx = -1;
          let latestLiveStep = null;
          let compactStillRunning = false;
          for (const [sIdx, st] of liveStepsAfterCompact.entries()) {
            if (sIdx > maxLiveIdx) {
              maxLiveIdx = sIdx;
              latestLiveStep = st;
            }
            const stStatus = String(st?.status || '');
            if (
              sIdx > prevIdx &&
              (stStatus === 'CORTEX_STEP_STATUS_RUNNING' ||
                stStatus === 'CORTEX_STEP_STATUS_GENERATING' ||
                stStatus === 'CORTEX_STEP_STATUS_PENDING' ||
                stStatus === 'CORTEX_STEP_STATUS_WAITING')
            ) {
              compactStillRunning = true;
            }
          }
          if (
            !compactStillRunning &&
            maxLiveIdx > prevIdx &&
            maxLiveIdx <= prevIdx + 2 &&
            latestLiveStep?.type === 'CORTEX_STEP_TYPE_USER_INPUT' &&
            nowSec - prevCompactAt <= 300
          ) {
            compactStillRunning = true;
          }
          if (compactStillRunning) {
            check = { interrupted: false, reason: 'compact_in_progress' };
          } else if (
            maxLiveIdx > prevIdx &&
            maxLiveIdx <= prevIdx + 4 &&
            latestLiveStep?.type === 'CORTEX_STEP_TYPE_CHECKPOINT' &&
            latestLiveStep?.status === 'CORTEX_STEP_STATUS_DONE'
          ) {
            check = {
              interrupted: true,
              stepIndex: maxLiveIdx,
              lastStepAt: nowSec,
              ageSec: 5,
              reason: 'post_compact_auto_resume',
              resumePrompt: CHUNKED_STREAM_RESUME_PROMPT
            };
          } else if (
            maxLiveIdx > prevIdx + 1 &&
            latestLiveStep?.type !== 'CORTEX_STEP_TYPE_USER_INPUT' &&
            latestLiveStep?.type !== 'CORTEX_STEP_TYPE_CHECKPOINT'
          ) {
            delete prevEntry.pendingPostCompactResume;
            prevEntry.stepIndex = Math.max(prevIdx, maxLiveIdx);
            changedResumed = true;
          }
        }
      }
      if (
        !check.interrupted &&
        check.reason === 'pending_bg_task' &&
        Array.isArray(check.pendingTaskSteps) &&
        check.pendingTaskSteps.length > 0
      ) {
        const nonDaemonPending = check.pendingTaskSteps.filter((t) => !t.isDaemon);
        const cancelledTasksMap =
          resumedMap._cancelledTasks && typeof resumedMap._cancelledTasks === 'object'
            ? resumedMap._cancelledTasks
            : {};
        const anyUserCancelledTask = nonDaemonPending.some((t) => {
          const shortId = String(t.taskId || '').split('/').pop();
          const cTs1 = Number(cancelledTasksMap[`${threadId}:${t.taskId}`] || 0);
          const cTs2 = shortId ? Number(cancelledTasksMap[`${threadId}:${shortId}`] || 0) : 0;
          const minStart = Math.max(0, Number(t.startedAtSec || 0) - 2);
          return (cTs1 > 0 && cTs1 >= minStart) || (cTs2 > 0 && cTs2 >= minStart);
        });
        if (nonDaemonPending.length > 0 && !anyUserCancelledTask) {
          const minIdx = Math.min(...nonDaemonPending.map((t) => Number(t.stepIndex || 0)));
          const maxIdx = Math.max(
            Number(check.stepIndex || 0),
            ...nonDaemonPending.map((t) => Number(t.stepIndex || 0))
          );
          const liveSteps = await fetchCascadeStepsRange(
            port,
            csrfToken,
            threadId,
            minIdx,
            Math.max(5, maxIdx - minIdx + 2),
            3500
          );
          if (liveSteps && liveSteps.size > 0) {
            const allDeadOrCanceled = nonDaemonPending.every((t) => {
              const st = liveSteps.get(Number(t.stepIndex));
              if (!st || typeof st.status !== 'string') return false;
              if (st.status === 'CORTEX_STEP_STATUS_CANCELED') {
                return true;
              }
              if (
                st.status === 'CORTEX_STEP_STATUS_DONE' ||
                st.status === 'CORTEX_STEP_STATUS_ERROR'
              ) {
                const compAt = st?.metadata?.completedAt
                  ? Math.floor(Date.parse(st.metadata.completedAt) / 1000)
                  : 0;
                return compAt > 0 && nowSec - compAt >= 20;
              }
              return false;
            });
            if (allDeadOrCanceled) {
              check = {
                interrupted: true,
                stepIndex: Math.max(1, Number(check.stepIndex || maxIdx)),
                lastStepAt: check.lastStepAt,
                reason: 'canceled_bg_task_wakeup'
              };
            }
          }
        }
      }
      const prevResumedStep =
        prevEntry?.reason === 'user_cancelled' &&
        check.lastStepAt &&
        Number(prevEntry.resumedAt || 0) > 0 &&
        check.lastStepAt > Number(prevEntry.resumedAt) + 5
          ? 0
          : Number(prevEntry?.stepIndex || 0);
      if (!(state.__bhfVerifiedIdleProseCache instanceof Map)) {
        state.__bhfVerifiedIdleProseCache = new Map();
      }
      const proseCacheSig = `${Number(check.maxStepIndex || 0)}:${Number(liveSummary?.stepCount || 0)}:${Number(check.lastStepAt || 0)}`;
      const liveStepCount = Number(liveSummary?.stepCount || 0);
      if (
        !check.interrupted &&
        liveSummary &&
        liveSummary.status === 'CASCADE_RUN_STATUS_IDLE' &&
        Number.isFinite(check.maxStepIndex) &&
        check.maxStepIndex >= 0 &&
        state.__bhfVerifiedIdleProseCache.get(threadId) !== proseCacheSig &&
        !['ask_question', 'preceding_ask_question', 'repeated_error_message', 'compact_in_progress', 'pending_bg_task', 'below_min_age'].includes(
          String(check.reason || '')
        ) &&
        !(check.reason === 'already_sent_continue' && liveStepCount <= Number(check.maxStepIndex) + 1)
      ) {
        const effectiveCandidateStep = Math.max(
          Number(check.maxStepIndex || 0),
          liveStepCount - 1
        );
        if (
          (liveStepCount > Number(check.maxStepIndex) + 1 ||
            check.lastType === 'PLANNER_RESPONSE') &&
          prevResumedStep < effectiveCandidateStep
        ) {
          check = {
            ...check,
            interrupted: true,
            stepIndex: Math.max(1, Number(check.maxStepIndex || 1)),
            reason: 'unflushed_live_stream_error'
          };
        }
      }
      if (!check.interrupted || !check.stepIndex) {
        if (
          prevEntry?.pendingPostCompactResume &&
          (check.reason === 'repeated_error_message' ||
            (check.reason !== 'compact_in_progress' &&
              check.reason !== 'pending_bg_task' &&
              prevCompactAt > 0 &&
              nowSec - prevCompactAt > 900))
        ) {
          delete prevEntry.pendingPostCompactResume;
          changedResumed = true;
        }
        continue;
      }
      if (
        onlyReasons &&
        !onlyReasons.has(check.reason) &&
        !(check.reason === 'unflushed_live_stream_error' && onlyReasons.has('error_message'))
      ) {
        continue;
      }
      const candidateMaxStep = Math.max(
        Number(check.stepIndex || 0),
        Number(liveSummary?.stepCount || 0) - 1
      );
      if (prevResumedStep >= candidateMaxStep) {
        continue;
      }
      if (check.requiresNetworkCheck) {
        const netOk =
          typeof options.networkOnlineCheck === 'function'
            ? await Promise.resolve(options.networkOnlineCheck()).catch(() => false)
            : await probeUpstreamNetworkOnline(2500);
        if (!netOk) {
          continue;
        }
      }
      let liveVerifiedMaxIdx = Number(check.stepIndex || 0);
      const isSteadyStatePoll =
        !hubFreshlyBooted && !forceSet.has(threadId) && !options.bypassMinAge;
      const needsLiveStepVerify =
        Boolean(liveSummary) &&
        (check.reason === 'unfinished_tool_turn' ||
          check.reason === 'unfinished_planner_tool_call' ||
          check.reason === 'error_message' ||
          check.reason === 'transient_network_error' ||
          check.reason === 'unflushed_live_stream_error');
      if (needsLiveStepVerify) {
        if (
          isSteadyStatePoll &&
          Number(check.ageSec || 0) < 45 &&
          (check.reason === 'unfinished_tool_turn' ||
            check.reason === 'unfinished_planner_tool_call')
        ) {
          continue;
        }
        const verifyOffset = Math.max(0, check.stepIndex - 1);
        const verifyLimit = Math.min(
          50,
          Math.max(16, Number(liveSummary?.stepCount || 0) - verifyOffset + 4)
        );
        const verifySteps = await fetchCascadeStepsRange(
          port,
          csrfToken,
          threadId,
          verifyOffset,
          verifyLimit,
          3500
        );
        if (!verifySteps || verifySteps.size === 0) {
          if (isSteadyStatePoll || check.reason === 'unflushed_live_stream_error') {
            continue;
          }
        } else if (verifySteps.size > 0) {
          let maxLiveIdx = -1;
          let latestErrorStepIdx = -1;
          let latestErrorStep = null;
          let hasClientStreamError = false;
          let consecutiveLiveErrors = 0;
          let liveMaxInputTokens = 0;
          let lastLiveUserBeforeErrorTxt = '';
          let liveToolProgressSinceUser = false;
          const sortedVerifyIndices = Array.from(verifySteps.keys()).sort((a, b) => a - b);
          for (const sIdx of sortedVerifyIndices) {
            const st = verifySteps.get(sIdx);
            if (sIdx > maxLiveIdx) maxLiveIdx = sIdx;
            const stType = String(st?.type || '');
            const stStatus = String(st?.status || '');
            const stopReason = String(st?.plannerResponse?.stopReason || '');
            const usage = st?.metadata?.modelUsage;
            const stepTokens =
              Number(usage?.inputTokens || 0) + Number(usage?.cacheReadTokens || 0);
            if (stepTokens > liveMaxInputTokens) {
              liveMaxInputTokens = stepTokens;
            }
            if (stType === 'CORTEX_STEP_TYPE_USER_INPUT') {
              hasClientStreamError = false;
              latestErrorStep = null;
              latestErrorStepIdx = -1;
              consecutiveLiveErrors = 0;
              liveToolProgressSinceUser = false;
              const items = st?.userInput?.items;
              const itemTxt = Array.isArray(items)
                ? items
                    .map((it) =>
                      it?.item?.slashCommand?.info?.name === 'compact'
                        ? '/compact'
                        : String(it?.text || '')
                    )
                    .join(' ')
                    .trim()
                : String(st?.userInput?.userResponse || '').trim();
              if (itemTxt) {
                lastLiveUserBeforeErrorTxt = itemTxt;
              }
            } else if (stType === 'CORTEX_STEP_TYPE_CHECKPOINT') {
              hasClientStreamError = false;
              latestErrorStep = null;
              latestErrorStepIdx = -1;
              consecutiveLiveErrors = 0;
              liveToolProgressSinceUser = true;
            } else if (
              stStatus === 'CORTEX_STEP_STATUS_DONE' &&
              stType !== 'CORTEX_STEP_TYPE_PLANNER_RESPONSE' &&
              stType !== 'CORTEX_STEP_TYPE_ERROR_MESSAGE' &&
              stType !== 'CORTEX_STEP_TYPE_SYSTEM_MESSAGE'
            ) {
              liveToolProgressSinceUser = true;
            }
            if (
              sIdx >= check.stepIndex - 1 &&
              stType === 'CORTEX_STEP_TYPE_PLANNER_RESPONSE'
            ) {
              if (
                stopReason === 'STOP_REASON_CLIENT_STREAM_ERROR' ||
                stopReason === 'STOP_REASON_ERROR'
              ) {
                hasClientStreamError = true;
              } else if (
                stopReason === 'STOP_REASON_STOP_PATTERN' ||
                (st?.status === 'CORTEX_STEP_STATUS_DONE' &&
                  (!Array.isArray(st?.plannerResponse?.toolCalls) ||
                    st.plannerResponse.toolCalls.length === 0) &&
                  Boolean(
                    st?.plannerResponse?.response || st?.plannerResponse?.modifiedResponse
                  ))
              ) {
                hasClientStreamError = false;
                latestErrorStep = null;
                latestErrorStepIdx = -1;
                consecutiveLiveErrors = 0;
              }
            }
            if (sIdx >= check.stepIndex && stType === 'CORTEX_STEP_TYPE_ERROR_MESSAGE') {
              if (sIdx > latestErrorStepIdx) {
                latestErrorStepIdx = sIdx;
                latestErrorStep = st;
              }
              consecutiveLiveErrors += 1;
            }
          }
          let activeOrAskStep = false;
          for (const [sIdx, st] of verifySteps.entries()) {
            const stStatus = String(st?.status || '');
            const stType = String(st?.type || '');
            if (
              sIdx >= check.stepIndex &&
              sIdx > latestErrorStepIdx &&
              stType === 'CORTEX_STEP_TYPE_ASK_QUESTION'
            ) {
              activeOrAskStep = true;
              break;
            }
            if (
              stStatus === 'CORTEX_STEP_STATUS_RUNNING' ||
              stStatus === 'CORTEX_STEP_STATUS_GENERATING' ||
              stStatus === 'CORTEX_STEP_STATUS_PENDING' ||
              stStatus === 'CORTEX_STEP_STATUS_WAITING'
            ) {
              const orphanedByTerminalError =
                latestErrorStepIdx > sIdx ||
                (stStatus === 'CORTEX_STEP_STATUS_PENDING' &&
                  hasClientStreamError &&
                  liveSummary?.status === 'CASCADE_RUN_STATUS_IDLE');
              if (!orphanedByTerminalError) {
                activeOrAskStep = true;
                break;
              }
            }
          }
          if (activeOrAskStep) {
            continue;
          }
          if (maxLiveIdx > liveVerifiedMaxIdx) {
            liveVerifiedMaxIdx = maxLiveIdx;
          }
          if (prevResumedStep >= liveVerifiedMaxIdx) {
            continue;
          }
          const latestLiveStep = maxLiveIdx >= 0 ? verifySteps.get(maxLiveIdx) : null;
          if (latestLiveStep?.status === 'CORTEX_STEP_STATUS_CANCELED') {
            resumedMap[threadId] = {
              stepIndex: Math.max(check.stepIndex, maxLiveIdx),
              reason: 'user_cancelled',
              resumedAt: nowSec
            };
            changedResumed = true;
            continue;
          }
          if (
            maxLiveIdx > check.stepIndex &&
            (latestLiveStep?.type === 'CORTEX_STEP_TYPE_USER_INPUT' ||
              latestLiveStep?.type === 'CORTEX_STEP_TYPE_CHECKPOINT')
          ) {
            continue;
          }
          if (
            maxLiveIdx >= check.stepIndex &&
            !hasClientStreamError &&
            !latestErrorStep &&
            latestLiveStep?.type === 'CORTEX_STEP_TYPE_PLANNER_RESPONSE' &&
            latestLiveStep?.status === 'CORTEX_STEP_STATUS_DONE' &&
            (!Array.isArray(latestLiveStep?.plannerResponse?.toolCalls) ||
              latestLiveStep.plannerResponse.toolCalls.length === 0) &&
            Boolean(
              latestLiveStep?.plannerResponse?.response ||
                latestLiveStep?.plannerResponse?.modifiedResponse
            )
          ) {
            state.__bhfVerifiedIdleProseCache.set(threadId, proseCacheSig);
            continue;
          }
          if (
            check.reason === 'unflushed_live_stream_error' &&
            !latestErrorStep &&
            !hasClientStreamError
          ) {
            state.__bhfVerifiedIdleProseCache.set(threadId, proseCacheSig);
            continue;
          }
          if (latestErrorStep || hasClientStreamError) {
            if (check.reason === 'unflushed_live_stream_error') {
              check.reason = 'error_message';
            }
            const liveErrObj =
              latestErrorStep?.errorMessage?.error || latestErrorStep?.errorMessage || {};
            const liveErrText =
              `${liveErrObj.shortError || ''} ${liveErrObj.userErrorMessage || ''} ${liveErrObj.fullError || ''} ${latestErrorStep?.error || ''}`.trim();
            if (
              liveErrText &&
              /\b(quota|rate limit|resource_exhausted|invalid_argument|context length|token limit|permission_denied)\b/i.test(
                liveErrText
              )
            ) {
              continue;
            }
            const liveStreamHint =
              hasClientStreamError || STREAM_INTERRUPTION_HINT_RE.test(liveErrText);
            const postCkptTokens = Math.max(
              Number(check.postCheckpointMaxInputTokens || 0),
              liveMaxInputTokens
            );
            const liveAutoContinueBeforeError =
              Boolean(lastLiveUserBeforeErrorTxt) &&
              !liveToolProgressSinceUser &&
              isAutoContinueUserPrompt(lastLiveUserBeforeErrorTxt);
            const liveAlreadyTriedCompact =
              Boolean(check.alreadyTriedCompact) ||
              /^<USER_REQUEST>\s*(?:\/compact|\[\/compact\]\(slashCommand;compact\))(?=\s|<|$)/i.test(
                lastLiveUserBeforeErrorTxt
              ) ||
              /^(?:\/compact|\[\/compact\]\(slashCommand;compact\))(?=\s|$)/i.test(
                lastLiveUserBeforeErrorTxt
              );
            const liveAlreadyTriedChunked =
              liveAlreadyTriedCompact ||
              Boolean(check.alreadyTriedChunked) ||
              /\bNote:\s+the previous response stream was interrupted\b/i.test(
                lastLiveUserBeforeErrorTxt
              );
            const canPromoteToCompact =
              !liveAlreadyTriedCompact && liveStreamHint && postCkptTokens >= 215000;
            const canPromoteToChunked =
              !liveAlreadyTriedChunked &&
              liveStreamHint &&
              (consecutiveLiveErrors >= 2 ||
                postCkptTokens >= 180000 ||
                check.turnPrecededByAutoContinue ||
                liveAutoContinueBeforeError);
            if (
              (check.turnPrecededByAutoContinue || liveAutoContinueBeforeError) &&
              (liveAlreadyTriedChunked || (!canPromoteToCompact && !canPromoteToChunked))
            ) {
              continue;
            }
            const liveErrCreatedAtSec =
              typeof latestErrorStep?.metadata?.createdAt === 'string'
                ? Math.floor(Date.parse(latestErrorStep.metadata.createdAt) / 1000)
                : check.reason === 'error_message' || check.reason === 'transient_network_error'
                  ? Number(check.lastStepAt || 0)
                  : 0;
            if (
              process.env.THEO_SMOKE_TEST !== '1' &&
              typeof options.networkOnlineCheck !== 'function' &&
              (hasClientStreamError || isTransientNetworkErrorText(liveErrText)) &&
              liveErrCreatedAtSec > 0 &&
              nowSec >= liveErrCreatedAtSec &&
              nowSec - liveErrCreatedAtSec < 6
            ) {
              scheduleInterruptedCascadeCheck(
                state,
                (6 - (nowSec - liveErrCreatedAtSec) + 1) * 1000,
                {
                  candidateIds: [threadId],
                  bypassMinAge: true,
                  onlyReasons: PERIODIC_AUTO_RESUME_REASONS
                }
              );
              continue;
            }
            if (
              !check.requiresNetworkCheck &&
              (hasClientStreamError || isTransientNetworkErrorText(liveErrText))
            ) {
              const netOk =
                typeof options.networkOnlineCheck === 'function'
                  ? await Promise.resolve(options.networkOnlineCheck()).catch(() => false)
                  : await probeUpstreamNetworkOnline(2500);
              if (!netOk) {
                continue;
              }
            }
            if (canPromoteToCompact) {
              check.needsCompactionFirst = true;
              check.resumePrompt = '/compact';
            } else {
              check.needsCompactionFirst = false;
              if (canPromoteToChunked) {
                check.resumePrompt = CHUNKED_STREAM_RESUME_PROMPT;
              } else if (check.resumePrompt === '/compact') {
                check.resumePrompt = 'continue';
              }
            }
          }
        }
      }
      if (check.reason === 'unflushed_live_stream_error') {
        continue;
      }
      const resumePromptText =
        typeof check.resumePrompt === 'string' && check.resumePrompt.trim()
          ? check.resumePrompt.trim()
          : 'continue';
      try {
        state.serverManager?.getOrCreateOutputChannel?.()?.appendLine?.(
          `[BHF AUTO-RESUME] Resuming interrupted cascade ${threadId} at step ${liveVerifiedMaxIdx} (${check.reason})`
        );
      } catch {}
      const sendRes = await sendPromptToAntigravity({
        id: threadId,
        prompt: resumePromptText,
        preserveFocus: true,
        avoidTabReveal: true,
        preferDirectRpc: true,
        stepHint: liveVerifiedMaxIdx
      });
      if (sendRes?.ok && sendRes?.sendSucceeded !== false) {
        resumedMap[threadId] = {
          stepIndex: liveVerifiedMaxIdx,
          reason: check.needsCompactionFirst ? 'auto_compact_before_resume' : check.reason,
          resumedAt: nowSec,
          ...(check.needsCompactionFirst ? { pendingPostCompactResume: true } : {})
        };
        changedResumed = true;
        resumedCount += 1;
      }
    }

    if (changedResumed) {
      writeResumedCascadesState(resumedMap);
    }
    syncActiveTurnWakeLock(state, anyRunningInSummaries || resumedCount > 0);
    ensureWindowsStandbyNetworkGuard(state);
    return { resumed: resumedCount };
  } catch {
    return { resumed: resumedCount };
  } finally {
    state.resumeCheckInFlight = false;
  }
}

function scheduleInterruptedCascadeCheck(state, delayMs = 3500, options = {}) {
  const timer = setTimeout(() => {
    checkAndResumeInterruptedCascades(state, options).catch(() => {});
  }, delayMs);
  if (typeof timer?.unref === 'function') {
    timer.unref();
  }
}

function notifyCascadeTerminatedError(state = getBridgeState(), cascadeId = '') {
  if (!state) return false;
  const cleanId = String(cascadeId || '').trim();
  if (!cleanId) return false;
  if (!(state.__bhfLastTerminatedErrorCheckByCid instanceof Map)) {
    state.__bhfLastTerminatedErrorCheckByCid = new Map();
  }
  const now = Date.now();
  const prevAt = Number(state.__bhfLastTerminatedErrorCheckByCid.get(cleanId) || 0);
  if (prevAt > 0 && now - prevAt < 15000) {
    return false;
  }
  state.__bhfLastTerminatedErrorCheckByCid.set(cleanId, now);
  scheduleInterruptedCascadeCheck(state, 2000, {
    candidateIds: [cleanId],
    bypassMinAge: true,
    onlyReasons: PERIODIC_AUTO_RESUME_REASONS
  });
  scheduleInterruptedCascadeCheck(state, 9500, {
    candidateIds: [cleanId],
    bypassMinAge: true,
    onlyReasons: PERIODIC_AUTO_RESUME_REASONS
  });
  return true;
}

function registerBridgeCommands(state) {
  const vscode = resolveVscodeApi(state?.vscode);
  if (vscode && state.vscode !== vscode) {
    state.vscode = vscode;
  }
  state.ensureUpstreamAlive = (failedPort) => ensureUpstreamAlive(failedPort, state);
  state.notifyCascadeTerminatedError = (cid) => notifyCascadeTerminatedError(state, cid);
  state.__cmdHandlers = {
    openNewSessionTab,
    openConversationTab,
    syncTabTitle,
    syncTabBadges,
    closeConversationTab,
    getOpenTabsSnapshot,
    sendPromptToAntigravity,
    reconnectAllOpenTabs,
    restartHubForAccountSwitch,
    ensureUpstreamAlive
  };
  const { context } = state || {};
  if (!vscode?.commands || !context) {
    return;
  }
  if (!state.reconnectCommandRegistered) {
    state.reconnectCommandRegistered = true;
    try {
      context.subscriptions.push(
        vscode.commands.registerCommand('antigravityHub.reconnectTabs', async (options = {}) =>
          (state.__cmdHandlers?.reconnectAllOpenTabs || reconnectAllOpenTabs)(state, {
            forceRender: true,
            ...(options && typeof options === 'object' ? options : {})
          })
        ),
        vscode.commands.registerCommand('antigravityHub.restartHubForAccountSwitch', async (options = {}) =>
          (state.__cmdHandlers?.restartHubForAccountSwitch || restartHubForAccountSwitch)(
            state,
            options && typeof options === 'object' ? options : {}
          )
        )
      );
    } catch {}
  }
  if (state.commandsRegistered) {
    return;
  }
  state.commandsRegistered = true;

  context.subscriptions.push(
    vscode.commands.registerCommand('antigravityHub.bridgeStatus', () => ({
      active: true,
      version: BRIDGE_VERSION,
      hubPort: Number(state.serverManager?.port || getProxyState()?.upstreamPort || 0),
      proxyPort: Number(getProxyState()?.proxyPort || 0),
      openTabs: (state.__cmdHandlers?.getOpenTabsSnapshot || getOpenTabsSnapshot)(),
      hasSidebarView: Boolean(state.sidebarView),
      hasSidebarDelegate: Boolean(state.sidebarDelegate)
    })),
    vscode.commands.registerCommand('antigravityHub.attachSidebar', async (delegate) => {
      state.sidebarDelegate = delegate || null;
      if (state.sidebarFallbackTimer) {
        clearTimeout(state.sidebarFallbackTimer);
        state.sidebarFallbackTimer = null;
      }
      if (state.sidebarView && delegate && typeof delegate.resolveWebviewView === 'function') {
        await delegate.resolveWebviewView(state.sidebarView);
      }
      return { attached: Boolean(delegate), hadSidebarView: Boolean(state.sidebarView) };
    }),
    vscode.commands.registerCommand('antigravityHub.openTab', async (options = {}) => {
      if (options?.newSession || !options?.id) {
        return (state.__cmdHandlers?.openNewSessionTab || openNewSessionTab)(options);
      }
      return (state.__cmdHandlers?.openConversationTab || openConversationTab)(options);
    }),
    vscode.commands.registerCommand('antigravityHub.syncTabTitle', async (options = {}) =>
      (state.__cmdHandlers?.syncTabTitle || syncTabTitle)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.syncTabBadges', (badgesById = {}) =>
      (state.__cmdHandlers?.syncTabBadges || syncTabBadges)(badgesById)
    ),
    vscode.commands.registerCommand('antigravityHub.closeTab', async (options = {}) =>
      (state.__cmdHandlers?.closeConversationTab || closeConversationTab)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.getOpenTabs', () =>
      (state.__cmdHandlers?.getOpenTabsSnapshot || getOpenTabsSnapshot)()
    ),
    vscode.commands.registerCommand('antigravityHub.getLastConversationId', () =>
      state.context?.workspaceState?.get?.('lastConversationId') || ''
    ),
    vscode.commands.registerCommand('antigravityHub.sendPrompt', async (options = {}) =>
      (state.__cmdHandlers?.sendPromptToAntigravity || sendPromptToAntigravity)(options)
    ),
    vscode.commands.registerCommand('antigravityHub.remoteAction', async (options = {}) => {
      const targetId = String(
        options.id || options.threadId || options.approvalId || options.sessionId || ''
      ).trim();
      if (
        targetId &&
        targetId !== '*' &&
        (options.kind === 'cancel' || options.kind === 'stop' || options.kind === 'interrupt')
      ) {
        try {
          const resumedMap = readResumedCascadesState();
          resumedMap[targetId] = {
            stepIndex: 999999,
            reason: 'user_cancelled',
            resumedAt: Math.floor(Date.now() / 1000)
          };
          writeResumedCascadesState(resumedMap);
        } catch {}
      } else if (targetId && targetId !== '*') {
        try {
          await openConversationTab({ id: targetId, preserveFocus: false });
        } catch {}
      }
      return enqueueRemoteWebviewAction({
        ...options,
        id: targetId
      });
    }),
    vscode.commands.registerCommand('antigravityHub.getContextStatus', async (options = {}) => {
      const targetId =
        typeof options === 'string'
          ? options.trim()
          : String(options?.id || options?.threadId || '').trim();
      const force = typeof options === 'object' ? Boolean(options?.force) : false;
      return fetchContextWindowStatus(getProxyState(), targetId, force);
    }),
    vscode.commands.registerCommand('antigravityHub.getPendingApprovals', () =>
      getPendingApprovals()
    )
  );
}

const PERIODIC_AUTO_RESUME_REASONS = [
  'canceled_bg_task_wakeup',
  'interrupted_bg_task_on_hub_restart',
  'unanswered_system_wakeup',
  'unfinished_tool_turn',
  'unfinished_planner_tool_call',
  'error_message',
  'unflushed_live_stream_error',
  'transient_network_error',
  'post_compact_auto_resume'
];

function runPeriodicBridgeHealthProbe(state) {
  try {
    if (
      !state ||
      !state.serverManager ||
      state.__bhfSwitchingHubPort ||
      state.__bhfAccountSwitchRestartPromise ||
      state.__bhfPendingAccountSwitchDrain
    ) {
      return;
    }
    if (readExpectedActiveAntigravityEmail().stagingActive) {
      return;
    }
    const saved = readPersistentHubState();
    const proxySt = getProxyState();
    const curPort = Number(state.serverManager?.port || proxySt?.upstreamPort || 0);
    const nextPort = Number(saved?.port || 0);
    const now = Date.now();
    const shouldProbe =
      curPort <= 0 ||
      (nextPort > 0 && nextPort !== curPort) ||
      now - Number(state.__bhfLastHubProbeAt || 0) > 25000;
    if (shouldProbe) {
      state.__bhfSwitchingHubPort = 1;
      state.__bhfLastHubProbeAt = now;
      reconnectAllOpenTabs(state, { forceRender: false })
        .then(async (res) => {
          if (state.__bhfNeedsPostDrainDiskSync) {
            await maybeSyncDrainedTrajectoriesWhenIdle(state).catch(() => false);
          }
          if (res?.ok) {
            return checkAndResumeInterruptedCascades(state, {
              onlyReasons: PERIODIC_AUTO_RESUME_REASONS
            });
          }
        })
        .catch(() => {})
        .finally(() => {
          state.__bhfSwitchingHubPort = 0;
        });
    }
  } catch {}
}

function tickLiveBridgeHealth(hubDelegate = null) {
  const state = getBridgeState();
  if (!state || (!state.attached && !state.context && !state.apiImpl)) {
    return false;
  }
  if (state.__bhfModuleLoadId !== BRIDGE_MODULE_LOAD_ID) {
    return hotUpgradeLiveState(state, null, hubDelegate);
  }
  if (hubDelegate && !state.sidebarDelegate) {
    state.sidebarDelegate = hubDelegate;
  }
  runPeriodicBridgeHealthProbe(state);
  return true;
}

function hotUpgradeLiveState(state = getBridgeState(), fallbackVscode = null, hubDelegate = null) {
  if (!state) {
    return false;
  }
  const resolvedVscode =
    resolveVscodeApi(state.vscode) || resolveVscodeApi(fallbackVscode) || state.vscode;
  if (resolvedVscode) {
    state.vscode = resolvedVscode;
  }
  if (!state.context && !state.apiImpl) {
    return false;
  }
  state.__bhfModuleLoadId = BRIDGE_MODULE_LOAD_ID;
  if (state.resumeWatchdogTimer) {
    try {
      clearInterval(state.resumeWatchdogTimer);
    } catch {}
    state.resumeWatchdogTimer = null;
  }
  const wasEditorRegistered = Boolean(state.customEditorDisposable);
  normalizeLiveEntriesMap(state);
  installPersistentServerSupport(state);
  installContextWindowSupport(state);
  installMultiInstanceSupport(state);
  installTelemetryAndTermsGuard(state);
  installNotificationDedupeSupport(state);
  installSidebarDelegation(state);
  installConversationEditorProvider(state);
  registerBridgeCommands(state);

  if (hubDelegate && !state.sidebarDelegate) {
    state.sidebarDelegate = hubDelegate;
    if (state.sidebarFallbackTimer) {
      clearTimeout(state.sidebarFallbackTimer);
      state.sidebarFallbackTimer = null;
    }
    if (state.sidebarView && typeof hubDelegate.resolveWebviewView === 'function') {
      Promise.resolve(hubDelegate.resolveWebviewView(state.sidebarView)).catch(() => {});
    }
  }

  // One-time heal when hot-upgrading out of the cross-process keyring clobber / crash-recovery error view,
  // otherwise run the lightweight port/upstream health check.
  if (!state.__bhfHealedKeyringLoopV3) {
    state.__bhfHealedRenderStormV2 = true;
    state.__bhfHealedKeyringLoopV3 = true;
    state.__bhfLastHubProbeAt = Date.now();
    setTimeout(async () => {
      try {
        await ensureExpectedAntigravityKeyringSync(state);
        const proxySt = getProxyState();
        const curPort = Number(state.serverManager?.port || proxySt?.upstreamPort || 0);
        const curCsrf = String(state.serverManager?.csrfToken || proxySt?.csrfToken || '').trim();
        const runningNow =
          curPort > 0 && curCsrf ? await getRunningCascadeIds(curPort, curCsrf, 4500) : [];
        if (runningNow.length > 0) {
          await reconnectAllOpenTabs(state, { forceRender: false });
          await checkAndResumeInterruptedCascades(state, {
            onlyReasons: PERIODIC_AUTO_RESUME_REASONS
          });
          return;
        }
        const acctProbe =
          curPort > 0 && curCsrf
            ? await probePersistentHubDetailed(curPort, curCsrf, 4500, {
                checkAuth: true,
                checkEmailMatch: true
              })
            : { ok: false };
        if ((acctProbe.emailMismatch || acctProbe.unauthenticated) && curPort > 0) {
          await restartHubForAccountSwitch(state, { forceRenderTabs: false });
        } else {
          await reconnectAllOpenTabs(state, { forceRender: false });
          await checkAndResumeInterruptedCascades(state, {
            onlyReasons: PERIODIC_AUTO_RESUME_REASONS
          });
        }
      } catch {}
    }, 200);
  } else {
    state.__bhfLastHubProbeAt = 0;
    runPeriodicBridgeHealthProbe(state);
  }

  // If customEditorProvider was just hot-registered after failing at startup, revive any stuck antigravity-session tabs
  if (!wasEditorRegistered && state.customEditorDisposable && state.vscode?.window?.tabGroups) {
    setTimeout(async () => {
      try {
        const vscode = state.vscode;
        const groups = vscode.window.tabGroups.all || [];
        const stuckDraftTabs = [];
        const stuckThreadTabs = [];
        for (const group of groups) {
          for (const tab of group.tabs || []) {
            const inputUri = tab?.input?.uri;
            if (!inputUri || inputUri.scheme !== SESSION_TAB_SCHEME) {
              continue;
            }
            const uriKey = normalizeUriKey(inputUri);
            if (!uriKey || state.entriesByUriKey.has(uriKey)) {
              continue;
            }
            const parsed = parseSessionUri(uriKey);
            const saved = readTabState(state.context?.workspaceState, uriKey);
            const threadId = parsed.kind === 'thread' ? parsed.threadId : saved?.id || '';
            if (threadId) {
              stuckThreadTabs.push({ tab, group, uriKey, threadId });
            } else {
              stuckDraftTabs.push({ tab, group, uriKey });
            }
          }
        }
        for (const item of stuckDraftTabs) {
          try {
            await vscode.window.tabGroups.close(item.tab);
          } catch {}
        }
        for (const item of stuckThreadTabs) {
          try {
            await vscode.window.tabGroups.close(item.tab);
          } catch {}
          try {
            await openConversationTab({
              id: item.threadId,
              viewColumn: item.group?.viewColumn || 1,
              preserveFocus: !item.tab.isActive
            });
          } catch {}
        }
        if (stuckThreadTabs.length === 0 && stuckDraftTabs.length > 0) {
          const lastId = state.context?.workspaceState?.get?.('lastConversationId') || '';
          if (lastId) {
            await openConversationTab({ id: lastId, preserveFocus: false });
          } else {
            await openNewSessionTab({ preserveFocus: false });
          }
        }
      } catch {}
    }, 300);
  }
  return true;
}

function attach({ vscode, context, apiImpl, serverManager, provider, renderer, naming }) {
  const state = getBridgeState();
  state.vscode = resolveVscodeApi(vscode) || resolveVscodeApi(state.vscode);
  state.context = context || state.context;
  state.apiImpl = apiImpl || state.apiImpl;
  state.serverManager = serverManager || apiImpl?.hostDiagnosticsProvider || state.serverManager;
  state.provider = provider || state.provider;
  state.renderer = renderer || provider?.renderer || state.renderer;
  state.naming = naming || state.naming;
  state.attached = true;

  if (state.resumeWatchdogTimer) {
    try {
      clearInterval(state.resumeWatchdogTimer);
    } catch {}
    state.resumeWatchdogTimer = null;
  }

  installPersistentServerSupport(state);
  installContextWindowSupport(state);
  installMultiInstanceSupport(state);
  installTelemetryAndTermsGuard(state);
  installSidebarDelegation(state);
  installConversationEditorProvider(state);
  registerBridgeCommands(state);

  return state;
}

module.exports = {
  BRIDGE_VERSION,
  attach,
  getBridgeState,
  resolveVscodeApi,
  hotUpgradeLiveState,
  tickLiveBridgeHealth,
  normalizeLiveEntriesMap,
  findEntryByUriKey,
  findTabGroupColumnForUri,
  resolveTargetColumn,
  setOpeningTarget,
  isOpeningOtherTarget,
  openNewSessionTab,
  openConversationTab,
  closeConversationTab,
  syncTabBadges,
  syncTabTitle,
  applyEntryTabIcon,
  handleConversationsChanged,
  reconnectAllOpenTabs,
  restartHubForAccountSwitch,
  tryHotReloadHubAuthInPlace,
  maybeSyncDrainedTrajectoriesWhenIdle,
  getRunningCascadeIds,
  getRunningCascadeIdsDetailed,
  findActiveCascadesFromDiskTranscripts,
  hasActiveBackgroundWorkInTranscript,
  clearPendingAccountSwitchDrain,
  registerRetiringHub,
  drainRetiringHubsOnce,
  ensureRetiringHubsMonitor,
  clearRetiringHubsMonitor,
  isCascadeRunningOnRetiringHub,
  ensureUpstreamAlive,
  clearUpstreamServerState,
  reapBrokenAgyHubPid,
  getOpenTabsSnapshot,
  sendDirectCascadeRpcMessage,
  sendPromptToAntigravity,
  readPersistentHubState,
  writePersistentHubState,
  ensureExpectedAntigravityKeyringSync,
  silenceServerManagerCrashSignals,
  probeTcpLoopbackAlive,
  probePersistentHub,
  probePersistentHubDetailed,
  probePersistentHubAuth,
  isHubBusyButAlive,
  fetchCascadeRunStatesDetailed,
  fetchCascadeStepsRange,
  decideSavedHubReuse,
  ensureAntigravityTelemetryDisabled,
  installPersistentServerSupport,
  installTelemetryAndTermsGuard,
  installNotificationDedupeSupport,
  installRichFileOpenSupport,
  healClobberedSessionTabs,
  CHUNKED_STREAM_RESUME_PROMPT,
  isAutoContinueUserPrompt,
  isTransientNetworkErrorText,
  probeUpstreamNetworkOnline,
  inspectCascadeInterruptedState,
  checkAndResumeInterruptedCascades,
  notifyCascadeTerminatedError,
  syncActiveTurnWakeLock,
  ensureWindowsStandbyNetworkGuard
};



