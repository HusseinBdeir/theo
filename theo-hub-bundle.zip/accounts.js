const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const https = require('https');
const net = require('net');
const os = require('os');
const path = require('path');
const readline = require('readline');
const { execFile, spawn } = require('child_process');
const {
  formatAntigravityPlanName,
  parseAntigravityAccountStatus,
  parseAntigravityQuotaSummary,
  parseClaudeAccountStatus,
  parseClaudeQuotaSummary
} = require('./data');

const CLAUDE_OAUTH_CLIENT_ID = '9d1c250a-e61b-44d9-88ed-5944d1962f5e';
const AGY_OAUTH_CLIENT_ID =
  '1071006060591-tmhssin2h21lcre235vtolojh4g403ep.apps.googleusercontent.com';
const AGY_OAUTH_CLIENT_SECRET = ['GOCSPX', 'K58FWR486LdLJ1mLB8sXC4z6qDAf'].join('-');
const AGY_CLOUDCODE_PA_BASE = 'https://daily-cloudcode-pa.googleapis.com';
const AGY_QUOTA_USER_AGENT = 'antigravity/2.26.0 (windows_amd64)';
const AGY_KEYRING_LIVE_TARGET = 'gemini:antigravity';
const AGY_KEYRING_RESTORE_TARGET = 'theo-hub:antigravity:__restore__';
// GCP project IDs are strictly 6-30 chars; 36-char UUIDs are local Antigravity workspace project IDs
// (~/.gemini/config/projects/<uuid>.json) mistakenly persisted by AGY_CLI_CDE_AUTH_ACTION=login.
const WORKSPACE_UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isBogusWorkspaceProjectId(value) {
  const s = String(value || '').trim();
  return Boolean(s && WORKSPACE_UUID_RE.test(s));
}

function hasValidAntigravityStoredToken(parsed) {
  return Boolean(
    parsed &&
      typeof parsed === 'object' &&
      parsed.token &&
      typeof parsed.token === 'object' &&
      typeof parsed.token.access_token === 'string' &&
      parsed.token.access_token.trim().length > 0
  );
}

function inspectAntigravityLoginResult(loginResp) {
  if (!loginResp || typeof loginResp !== 'object') {
    return { status: 'unknown', authResult: null };
  }
  const ar = loginResp.authResult || loginResp.auth_result || null;
  if (!ar || typeof ar !== 'object') {
    return { status: 'unknown', authResult: null };
  }
  const hasValidAuth = Boolean(ar.hasValidAuth ?? ar.has_valid_auth);
  if (hasValidAuth) {
    return { status: 'ok', authResult: ar };
  }

  const fdCase = ar.failureDetails?.case || '';
  const fdVal = ar.failureDetails?.value || {};
  const verReq =
    ar.verificationRequired ||
    ar.verification_required ||
    (fdCase === 'verificationRequired' ? fdVal : null);
  const inelig = ar.ineligible || (fdCase === 'ineligible' ? fdVal : null);
  const tosViol =
    ar.tosViolation || ar.tos_violation || (fdCase === 'tosViolation' ? fdVal : null);
  const genErr =
    ar.generalError || ar.general_error || (fdCase === 'generalError' ? fdVal : null);
  const projReq =
    ar.projectRequired || ar.project_required || (fdCase === 'projectRequired' ? fdVal : null);
  const licReq =
    ar.licenseRequired || ar.license_required || (fdCase === 'licenseRequired' ? fdVal : null);

  const verificationUrl = String(
    verReq?.verificationUrl ||
      verReq?.verification_url ||
      inelig?.verificationUrl ||
      inelig?.verification_url ||
      ''
  ).trim();
  const appealUrl = String(tosViol?.appealUrl || tosViol?.appeal_url || '').trim();
  const uiMessage = String(
    ar.uiMessage ||
      ar.ui_message ||
      inelig?.reason ||
      genErr?.reason ||
      tosViol?.reason ||
      ''
  ).trim();

  if (verificationUrl) {
    return {
      status: 'verification_required',
      verificationUrl,
      message:
        uiMessage ||
        'Google requires a one-time account verification check ("Verify your account to continue") before activating Antigravity.',
      authResult: ar
    };
  }
  if (projReq || licReq) {
    return {
      status: 'failed',
      reasonCode: projReq ? 'project_required' : 'license_required',
      message:
        uiMessage ||
        'This Google account does not yet have an active consumer Antigravity / Google AI plan assigned.',
      authResult: ar
    };
  }
  return {
    status: 'failed',
    reasonCode: tosViol ? 'tos_violation' : inelig ? 'ineligible' : 'general_error',
    appealUrl,
    message: uiMessage || 'Google Antigravity sign-in did not complete.',
    authResult: ar
  };
}

function sanitizeAntigravityStoredTokenJson(rawCred) {
  const rawStr = typeof rawCred === 'string' ? rawCred : '';
  if (!rawStr) {
    return { raw: '', parsed: null, sanitized: false, strippedProjectId: '' };
  }
  let obj;
  try {
    obj = JSON.parse(rawStr);
  } catch {
    return { raw: rawStr, parsed: null, sanitized: false, strippedProjectId: '' };
  }
  if (!obj || typeof obj !== 'object') {
    return { raw: rawStr, parsed: null, sanitized: false, strippedProjectId: '' };
  }

  let sanitized = false;
  let strippedProjectId = '';
  const projectKeys = ['project_id', 'projectId', 'project', 'quota_project_id'];
  for (const k of projectKeys) {
    if (k in obj && isBogusWorkspaceProjectId(obj[k])) {
      if (!strippedProjectId) {
        strippedProjectId = String(obj[k]).trim();
      }
      delete obj[k];
      sanitized = true;
    }
  }

  const hasValidGcpProject = projectKeys.some((k) => {
    const v = String(obj[k] || '').trim();
    return Boolean(v && !isBogusWorkspaceProjectId(v));
  });

  const isPoisonedPaygoTier =
    obj.user_tier === 'agy-business-paygo-tier' ||
    obj.userTier === 'agy-business-paygo-tier' ||
    obj.tier_display_name === 'Agent Platform' ||
    obj.tierDisplayName === 'Agent Platform';

  const isOrphanedGcpAuthMethod =
    !hasValidGcpProject &&
    (obj.auth_method === 'gcp' ||
      obj.authMethod === 'gcp' ||
      obj.auth_mode === 'gcp' ||
      obj.authMode === 'gcp');

  if (
    hasValidAntigravityStoredToken(obj) &&
    (strippedProjectId || (isPoisonedPaygoTier && !hasValidGcpProject) || isOrphanedGcpAuthMethod)
  ) {
    for (const k of ['location', 'region', 'is_gcp_tos', 'isGcpTos', 'gcp', 'auth_mode', 'authMode', 'authMethod']) {
      if (k in obj) {
        delete obj[k];
        sanitized = true;
      }
    }
    if (!hasValidGcpProject && obj.auth_method !== 'consumer') {
      obj.auth_method = 'consumer';
      sanitized = true;
    }
    if (isPoisonedPaygoTier) {
      for (const k of ['user_tier', 'userTier', 'tier_display_name', 'tierDisplayName']) {
        if (k in obj) {
          delete obj[k];
          sanitized = true;
        }
      }
    }
  }

  return {
    raw: sanitized ? JSON.stringify(obj) : rawStr,
    parsed: obj,
    sanitized,
    strippedProjectId
  };
}

function normalizeEmail(raw) {
  return String(raw || '').trim().toLowerCase();
}

function isPlausibleEmail(raw) {
  const e = normalizeEmail(raw);
  return Boolean(e && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e));
}

function decodeJwtPayload(jwtStr) {
  if (typeof jwtStr !== 'string') return null;
  const parts = jwtStr.trim().split('.');
  if (parts.length < 2 || !parts[1]) return null;
  try {
    const jsonText = Buffer.from(parts[1], 'base64url').toString('utf8');
    const obj = JSON.parse(jsonText);
    return obj && typeof obj === 'object' ? obj : null;
  } catch {
    return null;
  }
}

function extractAntigravityStoredTokenEmail(parsed) {
  if (!parsed || typeof parsed !== 'object') return '';
  const candidates = [
    parsed.id_token_email,
    parsed.email,
    decodeJwtPayload(parsed.id_token)?.email,
    decodeJwtPayload(parsed.token?.id_token)?.email
  ];
  for (const cand of candidates) {
    if (isPlausibleEmail(cand)) {
      return normalizeEmail(cand);
    }
  }
  return '';
}

function makeAccountId(provider, email) {
  const p = provider === 'claude' ? 'claude' : 'antigravity';
  const e = normalizeEmail(email);
  return e ? `${p}:${e}` : '';
}

function makeSafeSlug(provider, email) {
  const p = provider === 'claude' ? 'claude' : 'antigravity';
  const slug = normalizeEmail(email)
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return `${p}-${slug || 'account'}`;
}

function defaultHttpsJsonRequest(urlString, options = {}) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(urlString);
    } catch (err) {
      reject(err);
      return;
    }
    let settled = false;
    const timeoutMs = Math.max(1000, Number(options.timeoutMs) || 6000);
    let wallTimer = null;
    const finishResolve = (val) => {
      if (settled) return;
      settled = true;
      if (wallTimer) clearTimeout(wallTimer);
      resolve(val);
    };
    const finishReject = (err) => {
      if (settled) return;
      settled = true;
      if (wallTimer) clearTimeout(wallTimer);
      reject(err);
    };
    const bodyStr = options.body ? String(options.body) : '';
    const headers = { ...(options.headers || {}) };
    if (bodyStr && !headers['Content-Length']) {
      headers['Content-Length'] = Buffer.byteLength(bodyStr);
    }
    const req = https.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: parsed.pathname + parsed.search,
        method: options.method || 'GET',
        headers,
        timeout: timeoutMs
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('error', finishReject);
        res.on('aborted', () => finishReject(new Error('HTTPS response aborted')));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          const status = res.statusCode || 0;
          if (status >= 200 && status < 300) {
            try {
              finishResolve(text ? JSON.parse(text) : {});
            } catch (err) {
              finishReject(err);
            }
          } else {
            const err = new Error(`HTTP ${status}`);
            err.statusCode = status;
            err.responseBody = text.slice(0, 300);
            finishReject(err);
          }
        });
        res.on('close', () => {
          if (!settled) {
            finishReject(new Error('HTTPS response closed before end'));
          }
        });
      }
    );
    wallTimer = setTimeout(() => {
      const err = new Error('HTTPS request hard timeout');
      try {
        req.destroy(err);
      } catch {}
      finishReject(err);
    }, timeoutMs + 1000);
    if (typeof wallTimer?.unref === 'function') {
      wallTimer.unref();
    }
    req.on('timeout', () => {
      const err = new Error('HTTPS request timeout');
      try {
        req.destroy(err);
      } catch {}
      finishReject(err);
    });
    req.on('error', finishReject);
    if (bodyStr) {
      req.write(bodyStr);
    }
    req.end();
  });
}

const PY_KEYRING_SCRIPT = `
import ctypes, json, sys
from ctypes import wintypes

CRED_TYPE_GENERIC = 1
CRED_PERSIST_LOCAL_MACHINE = 2

class CREDENTIALW(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD),
        ("Type", wintypes.DWORD),
        ("TargetName", wintypes.LPWSTR),
        ("Comment", wintypes.LPWSTR),
        ("LastWritten", wintypes.FILETIME),
        ("CredentialBlobSize", wintypes.DWORD),
        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
        ("Persist", wintypes.DWORD),
        ("AttributeCount", wintypes.DWORD),
        ("Attributes", ctypes.c_void_p),
        ("TargetAlias", wintypes.LPWSTR),
        ("UserName", wintypes.LPWSTR),
    ]

advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
CredReadW = advapi32.CredReadW
CredReadW.argtypes = [wintypes.LPWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.POINTER(CREDENTIALW))]
CredReadW.restype = wintypes.BOOL
CredWriteW = advapi32.CredWriteW
CredWriteW.argtypes = [ctypes.POINTER(CREDENTIALW), wintypes.DWORD]
CredWriteW.restype = wintypes.BOOL
CredDeleteW = advapi32.CredDeleteW
CredDeleteW.argtypes = [wintypes.LPWSTR, wintypes.DWORD, wintypes.DWORD]
CredDeleteW.restype = wintypes.BOOL
CredFree = advapi32.CredFree
CredFree.argtypes = [ctypes.c_void_p]

req = json.loads(sys.stdin.read())
op = req.get("op")
target = req.get("target", "")

def _read_target(t):
    pcred = ctypes.POINTER(CREDENTIALW)()
    ok = CredReadW(t, CRED_TYPE_GENERIC, 0, ctypes.byref(pcred))
    if not ok:
        return None
    c = pcred.contents
    raw = bytes(c.CredentialBlob[:c.CredentialBlobSize])
    uname = c.UserName or ""
    CredFree(pcred)
    return {"userName": uname, "value": raw.decode("utf-8", "replace")}

if op == "read":
    res = _read_target(target)
    if res is None:
        print(json.dumps({"ok": False}))
    else:
        print(json.dumps({"ok": True, "userName": res["userName"], "value": res["value"]}))
elif op == "read_many":
    values = {}
    for t in (req.get("targets") or []):
        ts = str(t or "")
        if not ts:
            continue
        res = _read_target(ts)
        values[ts] = res["value"] if res is not None else None
    print(json.dumps({"ok": True, "values": values}))
elif op == "write":
    raw = req.get("value", "").encode("utf-8")
    buf = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    cred = CREDENTIALW()
    cred.Flags = 0
    cred.Type = CRED_TYPE_GENERIC
    cred.TargetName = target
    cred.CredentialBlobSize = len(raw)
    cred.CredentialBlob = ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))
    cred.Persist = CRED_PERSIST_LOCAL_MACHINE
    cred.UserName = req.get("userName") or "antigravity"
    ok = CredWriteW(ctypes.byref(cred), 0)
    print(json.dumps({"ok": bool(ok)}))
elif op == "delete":
    ok = CredDeleteW(target, CRED_TYPE_GENERIC, 0)
    err = ctypes.get_last_error()
    print(json.dumps({"ok": bool(ok or err == 1168)}))
else:
    print(json.dumps({"ok": False, "error": "unknown op"}))
`.trim();

const PS_KEYRING_SCRIPT = `
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class TheoWinCred {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct CREDENTIAL {
    public uint Flags;
    public uint Type;
    public string TargetName;
    public string Comment;
    public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
    public uint CredentialBlobSize;
    public IntPtr CredentialBlob;
    public uint Persist;
    public uint AttributeCount;
    public IntPtr Attributes;
    public string TargetAlias;
    public string UserName;
  }
  [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
  public static extern bool CredRead(string target, uint type, int reservedFlag, out IntPtr credentialPtr);
  [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
  public static extern bool CredWrite([In] ref CREDENTIAL userCredential, [In] uint flags);
  [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
  public static extern bool CredDelete(string target, uint type, int flags);
  [DllImport("advapi32.dll", SetLastError = true)]
  public static extern void CredFree([In] IntPtr cred);

  public static string ReadUtf8(string target) {
    IntPtr ptr;
    if (!CredRead(target, 1, 0, out ptr)) return null;
    try {
      CREDENTIAL c = (CREDENTIAL)Marshal.PtrToStructure(ptr, typeof(CREDENTIAL));
      if (c.CredentialBlob == IntPtr.Zero || c.CredentialBlobSize == 0) return "";
      byte[] bytes = new byte[c.CredentialBlobSize];
      Marshal.Copy(c.CredentialBlob, bytes, 0, (int)c.CredentialBlobSize);
      return Encoding.UTF8.GetString(bytes);
    } finally {
      CredFree(ptr);
    }
  }
  public static bool WriteUtf8(string target, string userName, string value) {
    byte[] bytes = Encoding.UTF8.GetBytes(value ?? "");
    IntPtr blob = Marshal.AllocCoTaskMem(bytes.Length);
    try {
      Marshal.Copy(bytes, 0, blob, bytes.Length);
      CREDENTIAL c = new CREDENTIAL();
      c.Type = 1;
      c.TargetName = target;
      c.UserName = string.IsNullOrEmpty(userName) ? "antigravity" : userName;
      c.Persist = 2;
      c.CredentialBlobSize = (uint)bytes.Length;
      c.CredentialBlob = blob;
      return CredWrite(ref c, 0);
    } finally {
      Marshal.FreeCoTaskMem(blob);
    }
  }
  public static bool DeleteCred(string target) {
    if (CredDelete(target, 1, 0)) return true;
    return Marshal.GetLastWin32Error() == 1168;
  }
}
"@
$rawIn = [Console]::In.ReadToEnd()
$req = $rawIn | ConvertFrom-Json
if ($req.op -eq 'read') {
  $val = [TheoWinCred]::ReadUtf8([string]$req.target)
  if ($null -eq $val) { @{ ok = $false } | ConvertTo-Json -Compress }
  else { @{ ok = $true; value = $val } | ConvertTo-Json -Compress }
} elseif ($req.op -eq 'read_many') {
  $vals = @{}
  foreach ($t in @($req.targets)) {
    $ts = [string]$t
    if (-not [string]::IsNullOrEmpty($ts)) {
      $vals[$ts] = [TheoWinCred]::ReadUtf8($ts)
    }
  }
  @{ ok = $true; values = $vals } | ConvertTo-Json -Compress -Depth 4
} elseif ($req.op -eq 'write') {
  $ok = [TheoWinCred]::WriteUtf8([string]$req.target, [string]$req.userName, [string]$req.value)
  @{ ok = [bool]$ok } | ConvertTo-Json -Compress
} elseif ($req.op -eq 'delete') {
  $ok = [TheoWinCred]::DeleteCred([string]$req.target)
  @{ ok = [bool]$ok } | ConvertTo-Json -Compress
} else {
  @{ ok = $false } | ConvertTo-Json -Compress
}
`.trim();

function findPythonExe() {
  const candidates = [
    'C:\\Python314\\python.exe',
    'C:\\Python313\\python.exe',
    'C:\\Python312\\python.exe',
    path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Python', 'Python314', 'python.exe'),
    path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Python', 'Python313', 'python.exe')
  ];
  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) return p;
    } catch {}
  }
  return '';
}

function runStdinJsonProcess(exe, args, payloadObj, timeoutMs = 5000) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (val) => {
      if (!settled) {
        settled = true;
        resolve(val);
      }
    };
    let child;
    try {
      child = spawn(exe, args, {
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe']
      });
    } catch {
      finish({ ok: false });
      return;
    }
    const timer = setTimeout(() => {
      try {
        child.kill();
      } catch {}
      finish({ ok: false, timeout: true });
    }, timeoutMs);
    const outChunks = [];
    child.stdout.on('data', (c) => outChunks.push(c));
    child.on('error', () => {
      clearTimeout(timer);
      finish({ ok: false });
    });
    child.on('close', () => {
      clearTimeout(timer);
      const txt = Buffer.concat(outChunks).toString('utf8').trim();
      if (!txt) {
        finish({ ok: false });
        return;
      }
      try {
        finish(JSON.parse(txt));
      } catch {
        finish({ ok: false });
      }
    });
    try {
      child.stdin.write(JSON.stringify(payloadObj));
      child.stdin.end();
    } catch {
      clearTimeout(timer);
      finish({ ok: false });
    }
  });
}

function createDefaultKeyringOps(fallbackDir) {
  if (process.platform === 'win32') {
    const pyExe = findPythonExe();
    const runOp = async (payload) => {
      if (pyExe) {
        const res = await runStdinJsonProcess(pyExe, ['-c', PY_KEYRING_SCRIPT], payload, 4000);
        if (res && typeof res.ok === 'boolean') {
          return res;
        }
      }
      return runStdinJsonProcess(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', PS_KEYRING_SCRIPT],
        payload,
        6000
      );
    };
    const credCache = new Map();
    const ttlFor = (t) => (String(t || '') === AGY_KEYRING_LIVE_TARGET ? 20000 : 60000);
    const getCached = (target, opts) => {
      if (opts?.bypassCache) return { hit: false, value: null };
      const entry = credCache.get(target);
      if (!entry) return { hit: false, value: null };
      if (Date.now() < entry.expiresAt) return { hit: true, value: entry.value };
      credCache.delete(target);
      return { hit: false, value: null };
    };
    const setCached = (target, value) => {
      credCache.set(target, {
        value: typeof value === 'string' ? value : null,
        expiresAt: Date.now() + ttlFor(target)
      });
    };
    const ops = {
      async read(target, opts = {}) {
        const key = String(target || '');
        if (!key) return null;
        const cached = getCached(key, opts);
        if (cached.hit) return cached.value;
        const res = await runOp({ op: 'read', target: key });
        const val = res?.ok && typeof res.value === 'string' ? res.value : null;
        if (val !== null) {
          setCached(key, val);
        } else if (res && res.ok === false && !res.timeout) {
          credCache.delete(key);
        }
        return val;
      },
      async readMany(targets, opts = {}) {
        const unique = Array.from(
          new Set((Array.isArray(targets) ? targets : []).map((t) => String(t || '').trim()).filter(Boolean))
        );
        const out = {};
        const misses = [];
        for (const t of unique) {
          const cached = getCached(t, opts);
          if (cached.hit) {
            out[t] = cached.value;
          } else {
            misses.push(t);
          }
        }
        if (misses.length === 0) return out;
        if (misses.length === 1) {
          out[misses[0]] = await ops.read(misses[0], opts);
          return out;
        }
        const res = await runOp({ op: 'read_many', targets: misses });
        if (res?.ok && res.values && typeof res.values === 'object') {
          for (const t of misses) {
            const v = typeof res.values[t] === 'string' ? res.values[t] : null;
            if (v !== null) {
              setCached(t, v);
            } else {
              credCache.delete(t);
            }
            out[t] = v;
          }
          return out;
        }
        for (const t of misses) {
          out[t] = null;
        }
        return out;
      },
      async write(target, value, userName = 'antigravity') {
        const text = String(value || '');
        const res = await runOp({ op: 'write', target, value: text, userName });
        if (res?.ok) {
          setCached(String(target || ''), text);
        } else {
          credCache.delete(String(target || ''));
        }
        return Boolean(res?.ok);
      },
      async remove(target) {
        const res = await runOp({ op: 'delete', target });
        credCache.delete(String(target || ''));
        return Boolean(res?.ok);
      }
    };
    return ops;
  }

  // Non-Windows fallback: mode 0600 local store inside ~/.claude/accounts/.keyring/
  const ringDir = path.join(fallbackDir, '.keyring');
  const fileFor = (target) =>
    path.join(ringDir, `${Buffer.from(String(target)).toString('base64url')}.cred`);
  const fallbackOps = {
    async read(target) {
      try {
        const fp = fileFor(target);
        return fs.existsSync(fp) ? fs.readFileSync(fp, 'utf8') : null;
      } catch {
        return null;
      }
    },
    async readMany(targets) {
      const out = {};
      for (const t of Array.from(new Set((Array.isArray(targets) ? targets : []).filter(Boolean)))) {
        out[t] = await fallbackOps.read(t);
      }
      return out;
    },
    async write(target, value) {
      try {
        fs.mkdirSync(ringDir, { recursive: true, mode: 0o700 });
        fs.writeFileSync(fileFor(target), String(value || ''), { encoding: 'utf8', mode: 0o600 });
        return true;
      } catch {
        return false;
      }
    },
    async remove(target) {
      try {
        const fp = fileFor(target);
        if (fs.existsSync(fp)) fs.unlinkSync(fp);
        return true;
      } catch {
        return false;
      }
    }
  };
  return fallbackOps;
}

function findClaudeBinaryPath() {
  const extRoot = path.join(os.homedir(), '.vscode', 'extensions');
  try {
    if (fs.existsSync(extRoot)) {
      const dirs = fs
        .readdirSync(extRoot)
        .filter((d) => d.startsWith('anthropic.claude-code-'))
        .sort();
      for (let i = dirs.length - 1; i >= 0; i -= 1) {
        const binName = process.platform === 'win32' ? 'claude.exe' : 'claude';
        const candidate = path.join(extRoot, dirs[i], 'resources', 'native-binary', binName);
        if (fs.existsSync(candidate)) {
          return candidate;
        }
      }
    }
  } catch {}
  const localBin = path.join(
    os.homedir(),
    '.local',
    'bin',
    process.platform === 'win32' ? 'claude.exe' : 'claude'
  );
  if (fs.existsSync(localBin)) {
    return localBin;
  }
  return process.platform === 'win32' ? 'claude.exe' : 'claude';
}

function findAgyBinaryPath() {
  const candidates = [
    path.join(os.homedir(), '.gemini', 'bin', process.platform === 'win32' ? 'agy.exe' : 'agy'),
    path.join(os.homedir(), '.antigravity', 'bin', process.platform === 'win32' ? 'agy.exe' : 'agy')
  ];
  for (const c of candidates) {
    try {
      if (fs.existsSync(c)) return c;
    } catch {}
  }
  return process.platform === 'win32' ? 'agy.exe' : 'agy';
}

function safeReadJson(filePath) {
  try {
    if (!filePath || !fs.existsSync(filePath)) return null;
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function safeWriteJson(filePath, obj, mode = 0o600) {
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const tmp = `${filePath}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), { encoding: 'utf8', mode });
    fs.renameSync(tmp, filePath);
    return true;
  } catch {
    try {
      fs.writeFileSync(filePath, JSON.stringify(obj, null, 2), { encoding: 'utf8', mode });
      return true;
    } catch {
      return false;
    }
  }
}

function hashText(str) {
  return crypto.createHash('sha256').update(String(str || '')).digest('hex').slice(0, 16);
}

function getAvailableLoopbackPort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.unref();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const addr = srv.address();
      const port = typeof addr === 'object' && addr ? addr.port : 0;
      srv.close(() => resolve(port));
    });
  });
}

function callLocalHubRpc(port, csrfToken, method, bodyObj = {}, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(bodyObj || {});
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: Number(port),
        path: `/exa.language_server_pb.LanguageServerService/${method}`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Connect-Protocol-Version': '1',
          'x-codeium-csrf-token': String(csrfToken || ''),
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          const status = res.statusCode || 0;
          if (status >= 200 && status < 300) {
            try {
              resolve(text ? JSON.parse(text) : {});
            } catch (err) {
              reject(err);
            }
          } else {
            const err = new Error(`Hub RPC ${method} HTTP ${status}`);
            err.statusCode = status;
            err.responseBody = text.slice(0, 300);
            reject(err);
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error(`Hub RPC ${method} timeout`)));
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

async function defaultAgyConsumerLoginLauncher({ agyBin, vscode, onAuthUrl, onLog }) {
  const port = await getAvailableLoopbackPort();
  const csrfToken = crypto.randomUUID();
  const stagingAppDataName = `antigravity-auth-staging-${process.pid}-${Date.now().toString(36)}`;
  const stagingAppDataPath = path.join(os.homedir(), '.gemini', stagingAppDataName);

  const cleanEnv = { ...process.env };
  delete cleanEnv.AGY_CLI_CDE_AUTH_ACTION;
  delete cleanEnv.ANTIGRAVITY_CDE;
  delete cleanEnv.AGY_CDE_SEAMLESS_AUTH;
  cleanEnv.HOME = os.homedir();
  cleanEnv.USERPROFILE = os.homedir();
  cleanEnv.AGY_ENABLE_HUB = '1';
  cleanEnv.ANTIGRAVITY_VSCODE_HOST = '1';
  cleanEnv.ANTIGRAVITY_AUTH_SUCCESS_APP = vscode?.env?.uriScheme || 'vscode';
  cleanEnv.THEO_EPHEMERAL_LOGIN_HUB = '1';

  const persistentLogPath = path.join(
    os.homedir(),
    '.gemini',
    'antigravity',
    'bhf-persistent-hub.log'
  );
  let initialLogOffset = 0;
  try {
    if (fs.existsSync(persistentLogPath)) {
      initialLogOffset = fs.statSync(persistentLogPath).size;
    }
  } catch {}

  // Prefer unwrapped __bhfOrigSpawn when available, and pass --hub=true (not bare --hub) so a
  // pre-reload Extension Host child_process.spawn hook checking args.includes('--hub') never hijacks
  // stdio away from our pipe to bhf-persistent-hub.log.
  // Never pass detached: true on Windows (keeps headless conhost 0x4 so zero console window flashes).
  const rawSpawn =
    typeof require('child_process').__bhfOrigSpawn === 'function'
      ? require('child_process').__bhfOrigSpawn
      : spawn;
  const child = rawSpawn(
    agyBin,
    [
      '--hub=true',
      `--hub-port=${port}`,
      `--app_data_dir=${stagingAppDataName}`,
      `--csrf_token=${csrfToken}`
    ],
    {
      cwd: os.homedir(),
      env: cleanEnv,
      detached: false,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    }
  );

  let stopped = false;
  let emittedAuthUrl = false;
  const emitAuthUrlOnce = (rawUrl) => {
    const cleanUrl = String(rawUrl || '').trim();
    if (!cleanUrl || emittedAuthUrl || stopped) return;
    emittedAuthUrl = true;
    if (typeof onAuthUrl === 'function') {
      onAuthUrl(cleanUrl);
    }
  };

  const handleOutputLine = (line) => {
    const trimmed = String(line || '').trim();
    if (!trimmed) return;
    const markerIdx = trimmed.indexOf('ANTIGRAVITY_OPEN_URL:');
    if (markerIdx !== -1) {
      emitAuthUrlOnce(trimmed.slice(markerIdx + 'ANTIGRAVITY_OPEN_URL:'.length));
    }
  };

  let rlOut = null;
  let rlErr = null;
  if (child.stdout) {
    rlOut = readline.createInterface({ input: child.stdout, terminal: false });
    rlOut.on('line', handleOutputLine);
  }
  if (child.stderr) {
    rlErr = readline.createInterface({ input: child.stderr, terminal: false });
    rlErr.on('line', handleOutputLine);
  }

  let logFallbackTimer = null;
  if (!child.stdout) {
    logFallbackTimer = setInterval(() => {
      if (stopped || emittedAuthUrl) return;
      try {
        if (!fs.existsSync(persistentLogPath)) return;
        const st = fs.statSync(persistentLogPath);
        if (st.size <= initialLogOffset) return;
        const fd = fs.openSync(persistentLogPath, 'r');
        try {
          const len = Math.min(st.size - initialLogOffset, 65536);
          const buf = Buffer.alloc(len);
          fs.readSync(fd, buf, 0, len, initialLogOffset);
          initialLogOffset += len;
          for (const ln of buf.toString('utf8').split(/\r?\n/)) {
            handleOutputLine(ln);
          }
        } finally {
          fs.closeSync(fd);
        }
      } catch {}
    }, 250);
  }

  const stop = async () => {
    if (stopped) return;
    stopped = true;
    if (logFallbackTimer) {
      clearInterval(logFallbackTimer);
      logFallbackTimer = null;
    }
    try {
      rlOut?.close?.();
    } catch {}
    try {
      rlErr?.close?.();
    } catch {}
    try {
      child.kill();
    } catch {}
    await new Promise((r) => setTimeout(r, 150));
    try {
      if (fs.existsSync(stagingAppDataPath)) {
        fs.rmSync(stagingAppDataPath, { recursive: true, force: true });
      }
    } catch {}
  };

  let ready = false;
  for (let i = 0; i < 40 && !stopped; i += 1) {
    try {
      await callLocalHubRpc(port, csrfToken, 'Heartbeat', {}, 1000);
      ready = true;
      break;
    } catch {
      await new Promise((r) => setTimeout(r, 200));
    }
  }

  if (!ready && !stopped) {
    await stop();
    throw new Error('Could not start local Antigravity sign-in helper.');
  }

  const startLoginAttempt = () => {
    if (stopped) {
      return Promise.reject(new Error('Sign-in helper stopped.'));
    }
    emittedAuthUrl = false;
    if (typeof onLog === 'function') {
      onLog('Requesting standard Google Antigravity consumer OAuth URL…');
    }
    // Matches Jetski native desktop "Sign in with Google": isGcpTos=false, enableBusinessLogin=true
    return callLocalHubRpc(
      port,
      csrfToken,
      'Login',
      { isGcpTos: false, enableBusinessLogin: true },
      5 * 60 * 1000
    );
  };

  const loginPromise = startLoginAttempt();

  const fetchProfileAndQuota = async () => {
    if (stopped) return { userStatusRaw: null, quotaRaw: null };
    const [uRes, qRes] = await Promise.allSettled([
      callLocalHubRpc(port, csrfToken, 'GetUserStatus', {}, 4000),
      callLocalHubRpc(port, csrfToken, 'RetrieveUserQuotaSummary', { forceRefresh: true }, 4000),
      callLocalHubRpc(
        port,
        csrfToken,
        'SetUserInfo',
        { userSettings: { telemetryEnabled: false, marketingEmailsEnabled: false } },
        3000
      )
    ]);
    return {
      userStatusRaw: uRes.status === 'fulfilled' ? uRes.value : null,
      quotaRaw: qRes.status === 'fulfilled' ? qRes.value : null
    };
  };

  return {
    port,
    csrfToken,
    loginPromise,
    startLoginAttempt,
    fetchProfileAndQuota,
    stop
  };
}

function hasUsableAntigravityQuotaBars(rawQuota) {
  if (!rawQuota || typeof rawQuota !== 'object') return false;
  return Boolean(parseAntigravityQuotaSummary(rawQuota).available);
}

class AccountVaultManager {
  constructor(options = {}) {
    this.claudeHomeDir = options.claudeHomeDir || path.join(os.homedir(), '.claude');
    this.globalClaudeJsonPath =
      options.globalClaudeJsonPath || path.join(os.homedir(), '.claude.json');
    this.vaultPath = options.vaultPath || path.join(this.claudeHomeDir, '.theo-accounts-vault.json');
    this.loginLockPath =
      options.loginLockPath || path.join(this.claudeHomeDir, '.theo-agy-login-lock.json');
    this.accountsRootDir = options.accountsRootDir || path.join(this.claudeHomeDir, 'accounts');
    this.keyring = options.keyringOps || createDefaultKeyringOps(this.accountsRootDir);
    this.hasCustomHttpsJsonRequest = Boolean(options.httpsJsonRequest);
    this.httpsJsonRequest = options.httpsJsonRequest || defaultHttpsJsonRequest;
    this.restartHubHook = typeof options.restartHubHook === 'function' ? options.restartHubHook : null;
    this.agyLoginLauncher =
      typeof options.agyLoginLauncher === 'function' ? options.agyLoginLauncher : null;
    this.hubStatePath =
      options.hubStatePath || path.join(os.homedir(), '.gemini', 'antigravity', 'bhf-persistent-hub.json');
    this.onStateChange = typeof options.onStateChange === 'function' ? options.onStateChange : null;

    this.lastAgyKeyringCheckAt = 0;
    this.lastAgyKeyringHash = '';
    this.expectedAgyEmailUntil = null;
    this.didInitialVaultSanitize = false;
    this.hasCustomKeyring = Boolean(options.keyringOps);
    this.jetskiTokenFilePath =
      options.jetskiTokenFilePath ||
      (this.hasCustomKeyring
        ? ''
        : path.join(os.homedir(), '.gemini', 'jetski-standalone-oauth-token'));
    this.agyQuotaInFlightById = new Map();
    this.agyBackoffUntilById = new Map();
    this.claudeQuotaInFlightById = new Map();
    this.claudeBackoffUntilById = new Map();
    this.lastAutoHubAlignAt = 0;
    this.pendingLogin = null;
  }

  syncJetskiStandaloneOauthFile(rawTokenJson) {
    if (!this.jetskiTokenFilePath || !rawTokenJson) return;
    try {
      const dir = path.dirname(this.jetskiTokenFilePath);
      if (fs.existsSync(dir)) {
        fs.writeFileSync(this.jetskiTokenFilePath, String(rawTokenJson), {
          encoding: 'utf8',
          mode: 0o600
        });
      }
    } catch {}
  }

  getLoginLockPath() {
    if (!this.loginLockPath) {
      this.loginLockPath = path.join(
        this.claudeHomeDir || path.join(os.homedir(), '.claude'),
        '.theo-agy-login-lock.json'
      );
    }
    return this.loginLockPath;
  }

  writeAgyLoginLock() {
    safeWriteJson(this.getLoginLockPath(), { pid: process.pid, startedAt: Date.now() }, 0o600);
  }

  clearAgyLoginLock() {
    try {
      const lockFile = this.getLoginLockPath();
      if (lockFile && fs.existsSync(lockFile)) {
        fs.unlinkSync(lockFile);
      }
    } catch {}
  }

  isAgyLoginStagingActive() {
    if (this.pendingLogin?.provider === 'antigravity') {
      return true;
    }
    const lock = safeReadJson(this.getLoginLockPath());
    if (lock && Number(lock.startedAt) > 0) {
      if (Date.now() - Number(lock.startedAt) < 6 * 60 * 1000) {
        return true;
      }
      this.clearAgyLoginLock();
    }
    return false;
  }

  readVault() {
    const raw = safeReadJson(this.vaultPath);
    const base = {
      version: 1,
      updatedAt: Number(raw?.updatedAt || 0),
      activeAccountId: {
        antigravity: String(raw?.activeAccountId?.antigravity || ''),
        claude: String(raw?.activeAccountId?.claude || '')
      },
      signedOut: {
        antigravity: Boolean(raw?.signedOut?.antigravity),
        claude: Boolean(raw?.signedOut?.claude)
      },
      accountOrder: Array.isArray(raw?.accountOrder)
        ? raw.accountOrder.map((id) => String(id || '').trim()).filter(Boolean)
        : [],
      accounts: {
        antigravity: Array.isArray(raw?.accounts?.antigravity) ? raw.accounts.antigravity : [],
        claude: Array.isArray(raw?.accounts?.claude) ? raw.accounts.claude : []
      }
    };
    return base;
  }

  sortVaultProviderAccounts(list, accountOrder = []) {
    if (!Array.isArray(list) || list.length <= 1) {
      return Array.isArray(list) ? [...list] : [];
    }
    const orderIdx = new Map(
      (Array.isArray(accountOrder) ? accountOrder : []).map((id, i) => [String(id || '').trim(), i])
    );
    const hasCustomSort = list.some(
      (a) => a && (orderIdx.has(a.id) || typeof a.sortOrder === 'number')
    );
    return list
      .map((item, idx) => ({ item, idx }))
      .sort((a, b) => {
        const oa = a.item?.id && orderIdx.has(a.item.id) ? orderIdx.get(a.item.id) : null;
        const ob = b.item?.id && orderIdx.has(b.item.id) ? orderIdx.get(b.item.id) : null;
        if (oa !== null && ob !== null && oa !== ob) {
          return oa - ob;
        }
        const sa = typeof a.item?.sortOrder === 'number' ? a.item.sortOrder : null;
        const sb = typeof b.item?.sortOrder === 'number' ? b.item.sortOrder : null;
        if (sa !== null && sb !== null && sa !== sb) {
          return sa - sb;
        }
        if (hasCustomSort) {
          return a.idx - b.idx;
        }
        return (
          Number(a.item?.addedAt || 0) - Number(b.item?.addedAt || 0) || a.idx - b.idx
        );
      })
      .map((x) => x.item);
  }

  getEffectiveAccountOrder(vault = null) {
    const v = vault || this.readVault();
    const rawOrder = Array.isArray(v?.accountOrder) ? v.accountOrder : [];
    const agySorted = this.sortVaultProviderAccounts(v?.accounts?.antigravity || [], rawOrder);
    const claudeSorted = this.sortVaultProviderAccounts(v?.accounts?.claude || [], rawOrder);
    const knownIds = new Set();
    for (const a of agySorted) {
      if (a?.id) knownIds.add(a.id);
    }
    for (const a of claudeSorted) {
      if (a?.id) knownIds.add(a.id);
    }
    const out = [];
    for (const id of rawOrder) {
      const cleanId = String(id || '').trim();
      if (cleanId && !out.includes(cleanId) && (knownIds.has(cleanId) || cleanId.endsWith(':default'))) {
        out.push(cleanId);
      }
    }
    for (const a of agySorted) {
      if (a?.id && !out.includes(a.id)) out.push(a.id);
    }
    for (const a of claudeSorted) {
      if (a?.id && !out.includes(a.id)) out.push(a.id);
    }
    return out;
  }

  hasSignedInProvider(provider = 'claude') {
    const cleanProv = provider === 'claude' ? 'claude' : 'antigravity';
    const vault = this.readVault();
    const enrolled = Array.isArray(vault?.accounts?.[cleanProv])
      ? vault.accounts[cleanProv].filter((a) => isPlausibleEmail(a?.email))
      : [];
    if (enrolled.length > 0) {
      return true;
    }
    if (vault?.signedOut?.[cleanProv]) {
      return false;
    }
    if (cleanProv === 'claude') {
      const activeCreds = safeReadJson(path.join(this.claudeHomeDir, '.credentials.json'));
      const activeCfg = safeReadJson(this.globalClaudeJsonPath);
      return Boolean(
        activeCreds?.claudeAiOauth?.accessToken &&
          isPlausibleEmail(activeCfg?.oauthAccount?.emailAddress)
      );
    }
    return true;
  }

  syncClaudeVscAutoUpdateState(signedOut) {
    if (this.hasCustomKeyring || process.env.THEO_SMOKE_TEST === '1') {
      return;
    }
    const realClaudeHome = path.resolve(path.join(os.homedir(), '.claude'));
    if (path.resolve(this.claudeHomeDir || '') !== realClaudeHome) {
      return;
    }
    const disableAutoUpdate = Boolean(signedOut);
    try {
      const extJsonPath = path.join(os.homedir(), '.vscode', 'extensions', 'extensions.json');
      if (fs.existsSync(extJsonPath)) {
        const entries = JSON.parse(fs.readFileSync(extJsonPath, 'utf8'));
        if (Array.isArray(entries)) {
          let mutated = false;
          for (const item of entries) {
            const id = String(item?.identifier?.id || '').toLowerCase();
            if (id === 'anthropic.claude-code') {
              item.metadata = item.metadata || {};
              if (Boolean(item.metadata.pinned) !== disableAutoUpdate) {
                item.metadata.pinned = disableAutoUpdate;
                mutated = true;
              }
            }
          }
          if (mutated) {
            fs.writeFileSync(extJsonPath, JSON.stringify(entries), 'utf8');
          }
        }
      }
    } catch {}
    try {
      const pyBin = findPythonExe();
      if (!pyBin) return;
      const pyScript = [
        'import json, pathlib, sqlite3, sys',
        'disable = sys.argv[1] == "1"',
        'p = pathlib.Path.home() / "AppData/Roaming/Code/User/globalStorage/state.vscdb"',
        'if p.exists():',
        '    con = sqlite3.connect(str(p), timeout=2.0)',
        '    row = con.execute("SELECT value FROM ItemTable WHERE key=?", ("extensions.donotAutoUpdate",)).fetchone()',
        '    arr = json.loads(row[0]) if row and row[0] else []',
        '    if not isinstance(arr, list): arr = []',
        '    ext_id = "anthropic.claude-code"',
        '    norm = [str(x).lower() for x in arr]',
        '    changed = False',
        '    if disable and ext_id not in norm:',
        '        arr.append(ext_id)',
        '        changed = True',
        '    elif not disable and ext_id in norm:',
        '        arr = [x for x in arr if str(x).lower() != ext_id]',
        '        changed = True',
        '    if changed:',
        '        con.execute("INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)", ("extensions.donotAutoUpdate", json.dumps(arr)))',
        '        con.commit()',
        '    con.close()'
      ].join('\n');
      execFile(
        pyBin,
        ['-c', pyScript, disableAutoUpdate ? '1' : '0'],
        { timeout: 3500, windowsHide: true },
        () => {}
      );
    } catch {}
  }

  async ensureClaudeExtensionActiveIfNeeded(vscode) {
    if (!vscode?.extensions?.getExtension) return;
    try {
      const claudeExt = vscode.extensions.getExtension('anthropic.claude-code');
      if (claudeExt && !claudeExt.isActive && typeof claudeExt.activate === 'function') {
        await claudeExt.activate();
      }
      if (this.hubRef && vscode?.commands?.executeCommand) {
        await vscode.commands
          .executeCommand('antigravityHub.claudeAttachSidebar', this.hubRef)
          .then(() => {}, () => {});
      }
    } catch {}
  }

  writeVault(vault) {
    vault.updatedAt = Date.now();
    safeWriteJson(this.vaultPath, vault, 0o600);
    return vault;
  }

  notifyChanged() {
    if (this.onStateChange) {
      try {
        this.onStateChange();
      } catch {}
    }
  }

  getPendingLoginState() {
    if (!this.pendingLogin) return null;
    return {
      active: true,
      provider: this.pendingLogin.provider,
      label: this.pendingLogin.label || '',
      emailHint: this.pendingLogin.emailHint || '',
      switchOnComplete: this.pendingLogin.switchOnComplete !== false,
      startedAt: this.pendingLogin.startedAt,
      awaitingVerification: Boolean(this.pendingLogin.awaitingVerification),
      verificationUrl: this.pendingLogin.verificationUrl || '',
      authUrl: this.pendingLogin.authUrl || '',
      message: this.pendingLogin.message || ''
    };
  }

  continuePendingLoginAfterVerification() {
    if (
      this.pendingLogin?.provider === 'antigravity' &&
      typeof this.pendingLogin.continueAfterVerification === 'function'
    ) {
      this.pendingLogin.continueAfterVerification();
      return { ok: true };
    }
    return { ok: false };
  }

  reopenPendingAuthOrVerificationUrl() {
    if (
      this.pendingLogin?.provider === 'antigravity' &&
      typeof this.pendingLogin.openActiveBrowserUrl === 'function'
    ) {
      this.pendingLogin.openActiveBrowserUrl();
      return { ok: true };
    }
    return { ok: false };
  }

  upsertVaultAccount(provider, fields = {}, options = {}) {
    const cleanProv = provider === 'claude' ? 'claude' : 'antigravity';
    const email = normalizeEmail(fields.email);
    if (!isPlausibleEmail(email)) return null;
    const id = makeAccountId(cleanProv, email);
    const vault = this.readVault();
    const list = vault.accounts[cleanProv];
    const now = Date.now();
    let entry = list.find((a) => a && (a.id === id || normalizeEmail(a.email) === email));
    let changed = false;

    if (!entry) {
      entry = {
        id,
        provider: cleanProv,
        email,
        name: String(fields.name || '').trim() || email.split('@')[0],
        label: String(fields.label || '').trim(),
        plan: String(fields.plan || '').trim(),
        tierId: String(fields.tierId || '').trim(),
        subscriptionType: String(fields.subscriptionType || '').trim(),
        rateLimitTier: String(fields.rateLimitTier || '').trim(),
        orgId: String(fields.orgId || '').trim(),
        orgName: String(fields.orgName || '').trim(),
        configDir: fields.configDir || '',
        hasCredential: Boolean(fields.hasCredential),
        addedAt: now,
        lastActiveAt: options.markActive ? now : 0,
        rawQuota: fields.rawQuota || null,
        quotaSavedAt: fields.rawQuota ? Number(fields.quotaSavedAt || now) : 0
      };
      list.push(entry);
      changed = true;
    } else {
      if (fields.name && fields.name !== entry.name) {
        entry.name = String(fields.name).trim();
        changed = true;
      }
      if (typeof fields.label === 'string' && fields.label !== entry.label) {
        entry.label = fields.label.trim();
        changed = true;
      }
      if (fields.plan && fields.plan !== entry.plan) {
        entry.plan = String(fields.plan).trim();
        changed = true;
      }
      if (fields.tierId && fields.tierId !== entry.tierId) {
        entry.tierId = String(fields.tierId).trim();
        changed = true;
      }
      if (fields.subscriptionType && fields.subscriptionType !== entry.subscriptionType) {
        entry.subscriptionType = String(fields.subscriptionType).trim();
        changed = true;
      }
      if (fields.rateLimitTier && fields.rateLimitTier !== entry.rateLimitTier) {
        entry.rateLimitTier = String(fields.rateLimitTier).trim();
        changed = true;
      }
      if (fields.orgId && fields.orgId !== entry.orgId) {
        entry.orgId = String(fields.orgId).trim();
        changed = true;
      }
      if (fields.configDir && fields.configDir !== entry.configDir) {
        entry.configDir = fields.configDir;
        changed = true;
      }
      if (fields.hasCredential && !entry.hasCredential) {
        entry.hasCredential = true;
        changed = true;
      }
      if (fields.rawQuota) {
        const incomingHasBars =
          cleanProv !== 'antigravity' || hasUsableAntigravityQuotaBars(fields.rawQuota);
        const existingHasBars =
          cleanProv === 'antigravity' && hasUsableAntigravityQuotaBars(entry.rawQuota);
        if (incomingHasBars || !existingHasBars) {
          const nextSavedAt = Number(fields.quotaSavedAt || now);
          let sameQuota = false;
          if (entry.rawQuota && entry.quotaSavedAt) {
            try {
              sameQuota = JSON.stringify(entry.rawQuota) === JSON.stringify(fields.rawQuota);
            } catch {}
          }
          const minDeltaMs = sameQuota ? 30000 : 1000;
          if (!entry.quotaSavedAt || Math.abs(nextSavedAt - entry.quotaSavedAt) >= minDeltaMs) {
            entry.rawQuota = fields.rawQuota;
            entry.quotaSavedAt = nextSavedAt;
            changed = true;
          }
        }
      }
    }

    if (!Array.isArray(vault.accountOrder)) {
      vault.accountOrder = [];
    }
    if (!vault.accountOrder.includes(id)) {
      vault.accountOrder.push(id);
      changed = true;
    }

    const wasSignedOut = Boolean(vault.signedOut?.[cleanProv]);
    if (wasSignedOut) {
      vault.signedOut[cleanProv] = false;
      changed = true;
    }

    if (options.markActive && vault.activeAccountId[cleanProv] !== id) {
      vault.activeAccountId[cleanProv] = id;
      entry.lastActiveAt = now;
      changed = true;
    } else if (!vault.activeAccountId[cleanProv]) {
      vault.activeAccountId[cleanProv] = id;
      changed = true;
    }

    if (changed) {
      this.writeVault(vault);
      if (cleanProv === 'claude' && wasSignedOut) {
        this.syncClaudeVscAutoUpdateState(false);
      }
    }
    return entry;
  }

  syncActiveClaudeFromDisk(claudeConfigObj, claudeCredsObj, rawActiveQuota = null, quotaSavedAt = 0) {
    const parsedAcct = parseClaudeAccountStatus(claudeConfigObj, claudeCredsObj);
    const email = normalizeEmail(parsedAcct?.email || claudeConfigObj?.oauthAccount?.emailAddress);
    if (!email || !claudeCredsObj?.claudeAiOauth?.accessToken) {
      return null;
    }

    // Do not overwrite active pointer if a Claude staging login is mid-flight, though staging uses an isolated dir anyway
    const slug = makeSafeSlug('claude', email);
    const acctDir = path.join(this.accountsRootDir, slug);
    const dstCredsPath = path.join(acctDir, '.credentials.json');
    const dstCfgPath = path.join(acctDir, '.claude.json');

    try {
      const existingCreds = safeReadJson(dstCredsPath);
      if (
        !existingCreds ||
        existingCreds?.claudeAiOauth?.accessToken !== claudeCredsObj?.claudeAiOauth?.accessToken ||
        existingCreds?.claudeAiOauth?.refreshToken !== claudeCredsObj?.claudeAiOauth?.refreshToken
      ) {
        safeWriteJson(
          dstCredsPath,
          {
            claudeAiOauth: claudeCredsObj.claudeAiOauth,
            organizationUuid:
              claudeCredsObj.organizationUuid || claudeConfigObj?.oauthAccount?.organizationUuid || ''
          },
          0o600
        );
      }
      if (claudeConfigObj?.oauthAccount) {
        const existingCfg = safeReadJson(dstCfgPath);
        if (
          !existingCfg ||
          existingCfg?.oauthAccount?.emailAddress !== claudeConfigObj.oauthAccount.emailAddress ||
          existingCfg?.oauthAccount?.accountUuid !== claudeConfigObj.oauthAccount.accountUuid
        ) {
          safeWriteJson(dstCfgPath, { oauthAccount: claudeConfigObj.oauthAccount }, 0o600);
        }
      }
    } catch {}

    return this.upsertVaultAccount(
      'claude',
      {
        email,
        name: parsedAcct.name,
        plan: parsedAcct.plan,
        subscriptionType: claudeCredsObj?.claudeAiOauth?.subscriptionType || '',
        rateLimitTier: claudeCredsObj?.claudeAiOauth?.rateLimitTier || '',
        orgId:
          claudeCredsObj?.organizationUuid ||
          claudeConfigObj?.oauthAccount?.organizationUuid ||
          '',
        configDir: acctDir,
        hasCredential: true,
        rawQuota: rawActiveQuota,
        quotaSavedAt
      },
      { markActive: true }
    );
  }

  async repairCorruptedVaultAccounts() {
    const repairedEmails = [];
    const vault = this.readVault();
    let vaultChanged = false;
    const stagingAgy = this.isAgyLoginStagingActive();

    for (const prov of ['antigravity', 'claude']) {
      const beforeLen = vault.accounts[prov].length;
      const bogus = vault.accounts[prov].filter((a) => !isPlausibleEmail(a?.email));
      if (bogus.length > 0) {
        vault.accounts[prov] = vault.accounts[prov].filter((a) => isPlausibleEmail(a?.email));
        vaultChanged = vault.accounts[prov].length !== beforeLen || vaultChanged;
        if (
          vault.activeAccountId[prov] &&
          !vault.accounts[prov].some((a) => a.id === vault.activeAccountId[prov])
        ) {
          vault.activeAccountId[prov] = vault.accounts[prov][0]?.id || '';
        }
        if (prov === 'antigravity') {
          for (const bad of bogus) {
            const badEmail = normalizeEmail(bad?.email);
            if (badEmail) {
              await this.keyring.remove(`theo-hub:antigravity:${badEmail}`).catch(() => {});
            }
          }
        }
      }
    }

    if (typeof this.keyring?.readMany === 'function') {
      const prefetchKeys = vault.accounts.antigravity
        .filter((e) => e?.email)
        .map((e) => `theo-hub:antigravity:${normalizeEmail(e.email)}`);
      if (!stagingAgy) {
        prefetchKeys.push(AGY_KEYRING_LIVE_TARGET, AGY_KEYRING_RESTORE_TARGET);
      }
      if (prefetchKeys.length > 0) {
        await this.keyring.readMany(prefetchKeys).catch(() => null);
      }
    }

    for (const entry of vault.accounts.antigravity) {
      if (!entry?.email) continue;
      const email = normalizeEmail(entry.email);
      const vaultKey = `theo-hub:antigravity:${email}`;
      let wasTokenSanitized = false;
      try {
        const raw = await this.keyring.read(vaultKey);
        if (raw) {
          const res = sanitizeAntigravityStoredTokenJson(raw);
          if (!hasValidAntigravityStoredToken(res.parsed) && !stagingAgy) {
            // Heal an accidentally nulled vault slot from __restore__ or gemini:antigravity if email matches
            for (const candidateKey of [AGY_KEYRING_RESTORE_TARGET, AGY_KEYRING_LIVE_TARGET]) {
              const candRaw = await this.keyring.read(candidateKey);
              if (!candRaw) continue;
              const candRes = sanitizeAntigravityStoredTokenJson(candRaw);
              if (
                hasValidAntigravityStoredToken(candRes.parsed) &&
                extractAntigravityStoredTokenEmail(candRes.parsed) === email
              ) {
                if (!candRes.parsed.id_token_email) {
                  candRes.parsed.id_token_email = email;
                }
                await this.keyring.write(vaultKey, JSON.stringify(candRes.parsed), email);
                wasTokenSanitized = true;
                repairedEmails.push(email);
                break;
              }
            }
          } else if (res.sanitized && hasValidAntigravityStoredToken(res.parsed)) {
            await this.keyring.write(vaultKey, res.raw, email);
            wasTokenSanitized = true;
            repairedEmails.push(email);
          }
        }
      } catch {}

      const hadPoisonedPaygoMeta =
        entry.tierId === 'agy-business-paygo-tier' || entry.plan === 'Agent Platform';
      if (wasTokenSanitized || hadPoisonedPaygoMeta) {
        if (hadPoisonedPaygoMeta || (wasTokenSanitized && !entry.tierId)) {
          entry.plan = '';
          entry.tierId = '';
          entry.rawQuota = null;
          entry.quotaSavedAt = 0;
          vaultChanged = true;
        } else if (entry.rawQuota && !hasUsableAntigravityQuotaBars(entry.rawQuota)) {
          entry.rawQuota = null;
          entry.quotaSavedAt = 0;
          vaultChanged = true;
        }
        if (!repairedEmails.includes(email) && vaultChanged) {
          repairedEmails.push(email);
        }
      }
    }

    if (!stagingAgy) {
      try {
        const liveRaw = await this.keyring.read(AGY_KEYRING_LIVE_TARGET);
        if (liveRaw) {
          const liveRes = sanitizeAntigravityStoredTokenJson(liveRaw);
          if (liveRes.sanitized && hasValidAntigravityStoredToken(liveRes.parsed)) {
            await this.keyring.write(AGY_KEYRING_LIVE_TARGET, liveRes.raw, 'antigravity');
            this.lastAgyKeyringHash = hashText(liveRes.raw);
            const liveEmail = extractAntigravityStoredTokenEmail(liveRes.parsed);
            if (liveEmail) {
              if (!liveRes.parsed.id_token_email) {
                liveRes.parsed.id_token_email = liveEmail;
              }
              await this.keyring.write(
                `theo-hub:antigravity:${liveEmail}`,
                JSON.stringify(liveRes.parsed),
                liveEmail
              );
              if (!repairedEmails.includes(liveEmail)) {
                repairedEmails.push(liveEmail);
              }
            }
          }
        }
      } catch {}
    }

    if (vaultChanged) {
      this.writeVault(vault);
    }
    return { ok: true, repairedEmails, vaultChanged };
  }

  async resolveAntigravityStoredTokenOwnerEmail(
    credObj,
    vault = null,
    liveAccount = null,
    options = {}
  ) {
    const explicit = extractAntigravityStoredTokenEmail(credObj);
    if (explicit) {
      return explicit;
    }

    const bypassCache = Boolean(options?.bypassCache);
    const effectiveVault = vault || this.readVault();
    const enrolledList = Array.isArray(effectiveVault?.accounts?.antigravity)
      ? effectiveVault.accounts.antigravity
      : [];

    // Go's StoredToken struct drops custom fields like id_token_email when refreshing an expired access_token,
    // and Google desktop OAuth2 refresh responses omit id_token — match the immutable refresh_token against
    // vaulted theo-hub:antigravity:<email> slots first so cross-process refreshes never misattribute accounts!
    const incomingRefresh = String(credObj?.token?.refresh_token || '').trim();
    if (incomingRefresh) {
      let prefetched = null;
      if (typeof this.keyring?.readMany === 'function' && enrolledList.length > 1) {
        const candKeys = enrolledList
          .map((e) => normalizeEmail(e?.email))
          .filter((em) => isPlausibleEmail(em))
          .map((em) => `theo-hub:antigravity:${em}`);
        if (candKeys.length > 1) {
          prefetched = await this.keyring
            .readMany(candKeys, { bypassCache })
            .catch(() => null);
        }
      }
      for (const entry of enrolledList) {
        const candEmail = normalizeEmail(entry?.email);
        if (!isPlausibleEmail(candEmail)) continue;
        try {
          const slotKey = `theo-hub:antigravity:${candEmail}`;
          const slotRaw =
            prefetched && Object.prototype.hasOwnProperty.call(prefetched, slotKey)
              ? prefetched[slotKey]
              : await this.keyring.read(slotKey, { bypassCache });
          if (!slotRaw) continue;
          const slotParsed = JSON.parse(slotRaw);
          const slotRefresh = String(slotParsed?.token?.refresh_token || '').trim();
          if (slotRefresh && slotRefresh === incomingRefresh) {
            return candEmail;
          }
        } catch {}
      }
    }

    const incomingAccess = String(credObj?.token?.access_token || '').trim();
    if (incomingAccess && typeof this.httpsJsonRequest === 'function') {
      try {
        const info = await this.httpsJsonRequest(
          'https://www.googleapis.com/oauth2/v2/userinfo',
          {
            method: 'GET',
            headers: {
              Authorization: `Bearer ${incomingAccess}`,
              Accept: 'application/json'
            },
            timeoutMs: 3500
          }
        );
        if (isPlausibleEmail(info?.email)) {
          return normalizeEmail(info.email);
        }
      } catch {}
    }

    // Only fall back to liveAccount.email when at most 1 Antigravity account is enrolled and its vaulted
    // refresh_token does not conflict with credObj's refresh_token.
    if (enrolledList.length <= 1 && isPlausibleEmail(liveAccount?.email)) {
      const liveEmail = normalizeEmail(liveAccount.email);
      if (incomingRefresh) {
        try {
          const slotRaw = await this.keyring.read(`theo-hub:antigravity:${liveEmail}`, {
            bypassCache
          });
          if (slotRaw) {
            const slotParsed = JSON.parse(slotRaw);
            const slotRefresh = String(slotParsed?.token?.refresh_token || '').trim();
            if (slotRefresh && slotRefresh !== incomingRefresh) {
              return '';
            }
          }
        } catch {}
      }
      return liveEmail;
    }

    return '';
  }

  async syncActiveAntigravityFromLive(liveAccount, rawActiveQuota = null, options = {}) {
    if (!this.didInitialVaultSanitize) {
      this.didInitialVaultSanitize = true;
      await this.repairCorruptedVaultAccounts().catch(() => null);
    }

    if (
      this.pendingLogin?.provider === 'antigravity' &&
      !this.pendingLogin.authUrl &&
      !this.pendingLogin.verificationUrl &&
      Date.now() - Number(this.pendingLogin.startedAt || 0) > 20000
    ) {
      await this.cancelAddAccount().catch(() => null);
    }

    const stagingAgy = this.isAgyLoginStagingActive();
    const isLiveAvail = Boolean(
      liveAccount && (liveAccount.available || liveAccount.email || liveAccount.name)
    );
    if (isLiveAvail && liveAccount?.email && !stagingAgy) {
      const liveEmail = normalizeEmail(liveAccount.email);
      const curVault = this.readVault();
      let canSyncLiveAgy = true;
      if (curVault.signedOut?.antigravity && curVault.accounts.antigravity.length === 0) {
        const liveKr = await this.keyring
          .read(AGY_KEYRING_LIVE_TARGET, { bypassCache: true })
          .catch(() => '');
        const cleanKr = liveKr ? sanitizeAntigravityStoredTokenJson(liveKr) : null;
        canSyncLiveAgy = Boolean(cleanKr && hasValidAntigravityStoredToken(cleanKr.parsed));
      }
      if (canSyncLiveAgy) {
        const curActiveId = String(curVault?.activeAccountId?.antigravity || '').trim();
        const hasEnrolledActive = Boolean(
          curActiveId &&
            Array.isArray(curVault?.accounts?.antigravity) &&
            curVault.accounts.antigravity.some((a) => a && a.id === curActiveId)
        );
        const liveId = makeAccountId('antigravity', liveEmail);
        let allowMarkActive = !hasEnrolledActive || liveId === curActiveId;
        if (this.expectedAgyEmailUntil && Date.now() < this.expectedAgyEmailUntil.until) {
          if (liveEmail === this.expectedAgyEmailUntil.email) {
            this.expectedAgyEmailUntil = null;
            allowMarkActive = true;
          } else {
            allowMarkActive = false;
          }
        }
        const isPoisonedLivePaygo =
          liveAccount.tierId === 'agy-business-paygo-tier' &&
          !hasUsableAntigravityQuotaBars(rawActiveQuota);
        this.upsertVaultAccount(
          'antigravity',
          {
            email: liveAccount.email,
            name: liveAccount.name,
            plan: isPoisonedLivePaygo ? '' : liveAccount.plan,
            tierId: isPoisonedLivePaygo ? '' : liveAccount.tierId || '',
            hasCredential: true,
            rawQuota: isPoisonedLivePaygo ? null : rawActiveQuota,
            quotaSavedAt:
              !isPoisonedLivePaygo && rawActiveQuota
                ? Number(options.rawActiveQuotaAt || 0) || Date.now()
                : 0
          },
          { markActive: allowMarkActive }
        );
      }
    }

    const now = Date.now();
    if (
      !stagingAgy &&
      (options.forceKeyring || now - this.lastAgyKeyringCheckAt >= 25000)
    ) {
      this.lastAgyKeyringCheckAt = now;
      try {
        const rawCred = await this.keyring.read(AGY_KEYRING_LIVE_TARGET, {
          bypassCache: Boolean(options.forceKeyring)
        });
        if (rawCred) {
          const cleanRes = sanitizeAntigravityStoredTokenJson(rawCred);
          // Never persist cleared/empty tokens such as {"token":null} into any vault slot!
          if (!hasValidAntigravityStoredToken(cleanRes.parsed)) {
            return;
          }
          let effectiveRaw = cleanRes.raw;
          if (cleanRes.sanitized) {
            await this.keyring.write(AGY_KEYRING_LIVE_TARGET, effectiveRaw, 'antigravity');
          }
          const h = hashText(effectiveRaw);
          if (options.forceKeyring || cleanRes.sanitized || h !== this.lastAgyKeyringHash) {
            this.lastAgyKeyringHash = h;
            const credObj = cleanRes.parsed;
            const curVault = this.readVault();
            const credEmail = await this.resolveAntigravityStoredTokenOwnerEmail(
              credObj,
              curVault,
              liveAccount,
              { bypassCache: true }
            );
            if (credEmail) {
              if (normalizeEmail(credObj.id_token_email) !== credEmail) {
                credObj.id_token_email = credEmail;
                effectiveRaw = JSON.stringify(credObj);
              }
              const vaultTarget = `theo-hub:antigravity:${credEmail}`;
              await this.keyring.write(vaultTarget, effectiveRaw, credEmail);
              const liveMatchesCred = normalizeEmail(liveAccount?.email) === credEmail;
              const curActiveId = String(curVault?.activeAccountId?.antigravity || '').trim();
              const hasEnrolledActive = Boolean(
                curActiveId &&
                  Array.isArray(curVault?.accounts?.antigravity) &&
                  curVault.accounts.antigravity.some((a) => a && a.id === curActiveId)
              );
              this.upsertVaultAccount(
                'antigravity',
                {
                  email: credEmail,
                  name: liveMatchesCred ? liveAccount?.name : '',
                  plan:
                    liveMatchesCred && liveAccount?.tierId !== 'agy-business-paygo-tier'
                      ? liveAccount?.plan
                      : '',
                  hasCredential: true
                },
                { markActive: !hasEnrolledActive && !liveAccount?.email }
              );

              // If an external Antigravity.exe process refreshed a DIFFERENT account into gemini:antigravity,
              // we have now safely vaulted its refreshed token above — restore THEO's active account into
              // gemini:antigravity so future agy.exe --hub spawns stay aligned with THEO's active account!
              const activeEntry = Array.isArray(curVault?.accounts?.antigravity)
                ? curVault.accounts.antigravity.find((a) => a && a.id === curActiveId)
                : null;
              const activeEmail = normalizeEmail(activeEntry?.email);
              const switchGracePending = Boolean(
                this.expectedAgyEmailUntil && Date.now() < this.expectedAgyEmailUntil.until
              );
              if (
                activeEmail &&
                isPlausibleEmail(activeEmail) &&
                activeEmail !== credEmail &&
                !switchGracePending
              ) {
                const activeSlotRaw = await this.keyring.read(
                  `theo-hub:antigravity:${activeEmail}`,
                  { bypassCache: true }
                );
                if (activeSlotRaw) {
                  const activeClean = sanitizeAntigravityStoredTokenJson(activeSlotRaw);
                  if (hasValidAntigravityStoredToken(activeClean.parsed)) {
                    if (normalizeEmail(activeClean.parsed.id_token_email) !== activeEmail) {
                      activeClean.parsed.id_token_email = activeEmail;
                    }
                    const restoredRaw = JSON.stringify(activeClean.parsed);
                    await this.keyring.write(
                      AGY_KEYRING_LIVE_TARGET,
                      restoredRaw,
                      'antigravity'
                    );
                    this.syncJetskiStandaloneOauthFile(restoredRaw);
                    this.lastAgyKeyringHash = hashText(restoredRaw);
                  }
                }
              } else if (activeEmail === credEmail && effectiveRaw !== rawCred) {
                await this.keyring.write(AGY_KEYRING_LIVE_TARGET, effectiveRaw, 'antigravity');
                this.syncJetskiStandaloneOauthFile(effectiveRaw);
                this.lastAgyKeyringHash = hashText(effectiveRaw);
              }
            }
          }
        }
      } catch {}
    }
  }

  async refreshAntigravityAccountTokenIfNeeded(acct, credObj, vaultKey, isActive) {
    const tok = credObj?.token;
    if (!tok || typeof tok !== 'object') return '';
    const accessToken = String(tok.access_token || '').trim();
    const refreshToken = String(tok.refresh_token || '').trim();
    const expiryMs = tok.expiry ? Date.parse(String(tok.expiry)) : 0;
    const now = Date.now();
    if (
      accessToken &&
      (!Number.isFinite(expiryMs) || expiryMs <= 0 || expiryMs - now > 5 * 60 * 1000 || !refreshToken)
    ) {
      return accessToken;
    }
    if (!refreshToken) {
      return accessToken;
    }
    try {
      const refreshed = await this.httpsJsonRequest('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        body: JSON.stringify({
          client_id: AGY_OAUTH_CLIENT_ID,
          client_secret: AGY_OAUTH_CLIENT_SECRET,
          refresh_token: refreshToken,
          grant_type: 'refresh_token'
        }),
        timeoutMs: 6000
      });
      if (refreshed?.access_token) {
        const cleanEmail = normalizeEmail(acct?.email);
        const nextCred = {
          ...credObj,
          id_token_email: cleanEmail || credObj.id_token_email,
          token: {
            ...tok,
            access_token: refreshed.access_token,
            refresh_token: refreshed.refresh_token || refreshToken,
            expiry: refreshed.expires_in
              ? new Date(Date.now() + Number(refreshed.expires_in) * 1000).toISOString()
              : tok.expiry
          }
        };
        const nextRaw = JSON.stringify(nextCred);
        if (vaultKey) {
          await this.keyring.write(vaultKey, nextRaw, cleanEmail || 'antigravity').catch(() => {});
        }
        if (isActive && !this.isAgyLoginStagingActive()) {
          await this.keyring.write(AGY_KEYRING_LIVE_TARGET, nextRaw, 'antigravity').catch(() => {});
          this.syncJetskiStandaloneOauthFile(nextRaw);
          this.lastAgyKeyringHash = hashText(nextRaw);
        }
        return String(refreshed.access_token).trim();
      }
    } catch {}
    return accessToken;
  }

  async fetchVaultedAntigravityAccountQuota(acct, options = {}) {
    if (!acct || !acct.id || !isPlausibleEmail(acct.email)) return acct?.rawQuota || null;
    if (this.isAgyLoginStagingActive()) return acct?.rawQuota || null;
    const now = Date.now();
    const force = Boolean(options.forceQuota);
    const cachedAgeMs = now - Number(acct.quotaSavedAt || 0);
    const cachedExpiredWindow = Boolean(
      acct.rawQuota &&
        parseAntigravityQuotaSummary(acct.rawQuota, now)?.primaryBars?.some((b) => b.windowExpired)
    );
    const recentlyActive = now - Number(acct.lastActiveAt || 0) < 15 * 60 * 1000;
    const ttlMs = cachedExpiredWindow ? 20000 : recentlyActive ? 30000 : 90000;
    if (!force && acct.rawQuota && cachedAgeMs < ttlMs) {
      return acct.rawQuota;
    }
    const backoffUntil = Number(this.agyBackoffUntilById.get(acct.id) || 0);
    if (!force && now < backoffUntil) {
      return acct.rawQuota || null;
    }
    if (this.agyQuotaInFlightById.has(acct.id)) {
      return this.agyQuotaInFlightById.get(acct.id);
    }

    let inFlightTimer = null;
    const rawRunPromise = (async () => {
      try {
        const cleanEmail = normalizeEmail(acct.email);
        const vaultKey = `theo-hub:antigravity:${cleanEmail}`;
        const rawCred = await this.keyring.read(vaultKey);
        if (!rawCred) return acct.rawQuota || null;
        const cleanRes = sanitizeAntigravityStoredTokenJson(rawCred);
        if (!hasValidAntigravityStoredToken(cleanRes.parsed)) {
          return acct.rawQuota || null;
        }
        const vault = this.readVault();
        const isActive = vault.activeAccountId.antigravity === acct.id;
        const accessToken = await this.refreshAntigravityAccountTokenIfNeeded(
          acct,
          cleanRes.parsed,
          vaultKey,
          isActive
        );
        if (!accessToken) return acct.rawQuota || null;

        const reqHeaders = {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'User-Agent': AGY_QUOTA_USER_AGENT
        };

        let resolvedPlan = acct.plan || '';
        let resolvedTierId = acct.tierId || '';
        let projectId = 'aicode-consumers';
        const needsTierCheck =
          !resolvedPlan ||
          resolvedPlan === 'Saved Account' ||
          !resolvedTierId ||
          resolvedTierId === 'agy-business-paygo-tier';
        if (needsTierCheck) {
          try {
            const codeAssist = await this.httpsJsonRequest(
              `${AGY_CLOUDCODE_PA_BASE}/v1internal:loadCodeAssist`,
              {
                method: 'POST',
                headers: reqHeaders,
                body: JSON.stringify({
                  mode: 'FULL_ELIGIBILITY_CHECK',
                  metadata: {
                    ideType: 'ANTIGRAVITY',
                    platform: 'WINDOWS_AMD64',
                    pluginType: 'GEMINI'
                  }
                }),
                timeoutMs: 4500
              }
            );
            if (codeAssist && typeof codeAssist === 'object') {
              if (
                typeof codeAssist.cloudaicompanionProject === 'string' &&
                codeAssist.cloudaicompanionProject.trim()
              ) {
                projectId = codeAssist.cloudaicompanionProject.trim();
              }
              const paidTier = codeAssist.paidTier || codeAssist.currentTier || null;
              if (paidTier?.id && paidTier.id !== 'agy-business-paygo-tier') {
                resolvedTierId = String(paidTier.id).trim();
                resolvedPlan = formatAntigravityPlanName(
                  paidTier.name || paidTier.description || 'Google AI',
                  resolvedTierId,
                  paidTier.upgradeSubscriptionUri || codeAssist.upgradeSubscriptionUri || ''
                );
              }
            }
          } catch {}
        }

        const payload = await this.httpsJsonRequest(
          `${AGY_CLOUDCODE_PA_BASE}/v1internal:retrieveUserQuotaSummary`,
          {
            method: 'POST',
            headers: reqHeaders,
            body: JSON.stringify({ project: projectId }),
            timeoutMs: 5000
          }
        );
        if (payload && hasUsableAntigravityQuotaBars(payload)) {
          this.agyBackoffUntilById.delete(acct.id);
          this.upsertVaultAccount('antigravity', {
            email: acct.email,
            plan: resolvedPlan || acct.plan,
            tierId: resolvedTierId || acct.tierId,
            rawQuota: payload,
            quotaSavedAt: Date.now()
          });
          return payload;
        }
      } catch (err) {
        if (err && (err.statusCode === 429 || err.statusCode === 403)) {
          this.agyBackoffUntilById.set(acct.id, Date.now() + 2 * 60 * 1000);
        }
      }
      return acct.rawQuota || null;
    })();

    const runPromise = Promise.race([
      rawRunPromise,
      new Promise((resolve) => {
        inFlightTimer = setTimeout(() => resolve(acct.rawQuota || null), 10000);
        if (typeof inFlightTimer?.unref === 'function') inFlightTimer.unref();
      })
    ]).finally(() => {
      if (inFlightTimer) clearTimeout(inFlightTimer);
      this.agyQuotaInFlightById.delete(acct.id);
    });

    this.agyQuotaInFlightById.set(acct.id, runPromise);
    return runPromise;
  }

  async refreshClaudeAccountTokenIfNeeded(acct, credsObj, credsPath, isActive) {
    const oauth = credsObj?.claudeAiOauth;
    if (!oauth) return null;
    const expiresAt = Number(oauth.expiresAt || 0);
    const now = Date.now();
    if (!expiresAt || expiresAt - now > 5 * 60 * 1000 || !oauth.refreshToken) {
      return oauth.accessToken || '';
    }
    try {
      const refreshed = await this.httpsJsonRequest('https://platform.claude.com/v1/oauth/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        body: JSON.stringify({
          grant_type: 'refresh_token',
          refresh_token: oauth.refreshToken,
          client_id: CLAUDE_OAUTH_CLIENT_ID
        }),
        timeoutMs: 6000
      });
      if (refreshed?.access_token) {
        const nextOauth = {
          ...oauth,
          accessToken: refreshed.access_token,
          refreshToken: refreshed.refresh_token || oauth.refreshToken,
          expiresAt: refreshed.expires_in
            ? Date.now() + Number(refreshed.expires_in) * 1000
            : oauth.expiresAt
        };
        const nextCreds = {
          ...credsObj,
          claudeAiOauth: nextOauth
        };
        safeWriteJson(credsPath, nextCreds, 0o600);
        if (isActive) {
          const activeCredsPath = path.join(this.claudeHomeDir, '.credentials.json');
          safeWriteJson(activeCredsPath, nextCreds, 0o600);
        }
        return nextOauth.accessToken;
      }
    } catch {}
    return oauth.accessToken || '';
  }

  async fetchVaultedClaudeAccountQuota(acct, options = {}) {
    if (!acct || !acct.id) return acct?.rawQuota || null;
    const now = Date.now();
    const force = Boolean(options.forceQuota);
    if (!force && acct.rawQuota && now - Number(acct.quotaSavedAt || 0) < 90000) {
      return acct.rawQuota;
    }
    const backoffUntil = Number(this.claudeBackoffUntilById.get(acct.id) || 0);
    if (!force && now < backoffUntil) {
      return acct.rawQuota || null;
    }
    if (this.claudeQuotaInFlightById.has(acct.id)) {
      return this.claudeQuotaInFlightById.get(acct.id);
    }

    let claudeInFlightTimer = null;
    const rawClaudePromise = (async () => {
      try {
        const vault = this.readVault();
        const isActive = vault.activeAccountId.claude === acct.id;
        const credsPath =
          acct.configDir && fs.existsSync(path.join(acct.configDir, '.credentials.json'))
            ? path.join(acct.configDir, '.credentials.json')
            : isActive
              ? path.join(this.claudeHomeDir, '.credentials.json')
              : '';
        if (!credsPath) return acct.rawQuota || null;

        const credsObj = safeReadJson(credsPath);
        const accessToken = await this.refreshClaudeAccountTokenIfNeeded(
          acct,
          credsObj,
          credsPath,
          isActive
        );
        if (!accessToken) return acct.rawQuota || null;

        const payload = await this.httpsJsonRequest('https://api.anthropic.com/api/oauth/usage', {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'anthropic-beta': 'oauth-2025-04-20',
            Accept: 'application/json',
            'User-Agent': 'claude-code/2.1.112'
          },
          timeoutMs: 5000
        });
        if (payload && typeof payload === 'object') {
          this.claudeBackoffUntilById.delete(acct.id);
          const freshAcctStatus = parseClaudeAccountStatus(
            acct.configDir ? safeReadJson(path.join(acct.configDir, '.claude.json')) : null,
            credsObj
          );
          this.upsertVaultAccount('claude', {
            email: acct.email,
            plan: freshAcctStatus?.plan || acct.plan,
            rawQuota: payload,
            quotaSavedAt: Date.now()
          });
          return payload;
        }
      } catch (err) {
        if (err && err.statusCode === 429) {
          this.claudeBackoffUntilById.set(acct.id, Date.now() + 5 * 60 * 1000);
        }
      }
      return acct.rawQuota || null;
    })();

    const runPromise = Promise.race([
      rawClaudePromise,
      new Promise((resolve) => {
        claudeInFlightTimer = setTimeout(() => resolve(acct.rawQuota || null), 10000);
        if (typeof claudeInFlightTimer?.unref === 'function') claudeInFlightTimer.unref();
      })
    ]).finally(() => {
      if (claudeInFlightTimer) clearTimeout(claudeInFlightTimer);
      this.claudeQuotaInFlightById.delete(acct.id);
    });

    this.claudeQuotaInFlightById.set(acct.id, runPromise);
    return runPromise;
  }

  async resolveAccountsSnapshot(options = {}) {
    if (!this.hasCustomHttpsJsonRequest) {
      this.httpsJsonRequest = defaultHttpsJsonRequest;
    }
    const nowMs = options.nowMs || Date.now();
    const forceQuota = Boolean(options.forceQuota);
    const liveAgyAccount = options.antigravityAccount || { available: false };
    const liveAgyLimits = options.antigravityLimits || { available: false, primaryBars: [], allBuckets: [] };
    const rawAgyQuota = options.rawAntigravityQuota || null;

    const liveClaudeAccount = options.claudeAccount || { available: false };
    const liveClaudeLimits = options.claudeLimits || { available: false, primaryBars: [], allBuckets: [] };
    const rawClaudeQuota = options.rawClaudeQuota || null;
    const claudeRelayMerged = options.claudeRelayMerged || null;
    const collapsedMap = options.collapsedProviders || {};

    await Promise.race([
      this.syncActiveAntigravityFromLive(liveAgyAccount, rawAgyQuota, {
        forceKeyring: forceQuota,
        rawActiveQuotaAt: Number(options.rawActiveQuotaAt || 0)
      }).catch(() => null),
      new Promise((resolve) => {
        const t = setTimeout(() => resolve(null), 6000);
        if (typeof t?.unref === 'function') t.unref();
      })
    ]);

    const vaultAfterSync = this.readVault();

    // Refresh any Antigravity accounts not currently served by liveAgyLimits and any secondary Claude accounts in parallel
    const liveAgyEmailNorm = normalizeEmail(liveAgyAccount?.email);
    const agyToRefresh = vaultAfterSync.accounts.antigravity.filter(
      (a) =>
        a &&
        isPlausibleEmail(a.email) &&
        (normalizeEmail(a.email) !== liveAgyEmailNorm || !liveAgyLimits?.available)
    );
    const secondaryClaude = vaultAfterSync.accounts.claude.filter(
      (a) => a && a.id !== vaultAfterSync.activeAccountId.claude
    );
    if (agyToRefresh.length > 0 || secondaryClaude.length > 0) {
      if (agyToRefresh.length > 1 && typeof this.keyring?.readMany === 'function') {
        await this.keyring
          .readMany(agyToRefresh.map((a) => `theo-hub:antigravity:${normalizeEmail(a.email)}`))
          .catch(() => null);
      }
      await Promise.race([
        Promise.all([
          ...agyToRefresh.map((acct) =>
            this.fetchVaultedAntigravityAccountQuota(acct, { forceQuota }).catch(() => null)
          ),
          ...secondaryClaude.map((acct) =>
            this.fetchVaultedClaudeAccountQuota(acct, { forceQuota }).catch(() => null)
          )
        ]),
        new Promise((resolve) => {
          const t = setTimeout(() => resolve(null), 7000);
          if (typeof t?.unref === 'function') t.unref();
        })
      ]);
    }

    const latestVault = this.readVault();
    const effectiveOrder = this.getEffectiveAccountOrder(latestVault);

    // Build Antigravity accounts view models (preserving user-configured accountOrder / sortOrder)
    const agyList = this.sortVaultProviderAccounts(
      latestVault.accounts.antigravity,
      effectiveOrder
    );
    const agyLiveAvail = Boolean(
      liveAgyAccount && (liveAgyAccount.available || liveAgyAccount.email || liveAgyAccount.name)
    );
    if (
      !this.hasCustomKeyring &&
      agyLiveAvail &&
      isPlausibleEmail(liveAgyAccount.email) &&
      latestVault.activeAccountId.antigravity &&
      !this.isAgyLoginStagingActive()
    ) {
      const expectedActive = agyList.find(
        (a) => a && a.id === latestVault.activeAccountId.antigravity
      );
      if (
        expectedActive &&
        isPlausibleEmail(expectedActive.email) &&
        normalizeEmail(expectedActive.email) !== normalizeEmail(liveAgyAccount.email) &&
        nowMs - Number(this.lastAutoHubAlignAt || 0) > 25000
      ) {
        this.lastAutoHubAlignAt = nowMs;
        this.restartAntigravityHubForSwitch(null, { userInitiated: false }).catch(() => {});
      }
    }
    let agyAccounts = agyList.map((item) => {
      const isActive = latestVault.activeAccountId.antigravity
        ? latestVault.activeAccountId.antigravity === item.id
        : Boolean(
            agyLiveAvail &&
              normalizeEmail(liveAgyAccount.email) === normalizeEmail(item.email)
          );
      const liveMatchesItem =
        agyLiveAvail &&
        normalizeEmail(liveAgyAccount.email) === normalizeEmail(item.email);
      const hubPendingCutover = Boolean(
        isActive &&
          agyLiveAvail &&
          isPlausibleEmail(liveAgyAccount.email) &&
          !liveMatchesItem
      );
      const acctInfo = liveMatchesItem
        ? {
            ...liveAgyAccount,
            available: true,
            label: item.label || ''
          }
        : {
            available: true,
            name: item.name || item.email,
            email: item.email,
            plan: item.plan || 'Saved Account',
            tierId: item.tierId || '',
            label: item.label || ''
          };
      const rateLimits =
        liveMatchesItem && liveAgyLimits?.available
          ? liveAgyLimits
          : item.rawQuota
            ? parseAntigravityQuotaSummary(item.rawQuota, nowMs)
            : {
                available: false,
                primaryBars: [],
                allBuckets: [],
                error: 'Switch to this account once to load live quota windows.'
              };
      const collapseKey = item.id;
      const collapsed =
        typeof collapsedMap[collapseKey] === 'boolean'
          ? collapsedMap[collapseKey]
          : Boolean(collapsedMap.antigravity);
      return {
        id: item.id,
        provider: 'antigravity',
        email: item.email,
        name: acctInfo.name || item.email,
        label: item.label || '',
        plan: acctInfo.plan || item.plan || '',
        active: Boolean(isActive),
        hubLive: Boolean(liveMatchesItem),
        hubPendingCutover,
        available: true,
        hasCredential: Boolean(item.hasCredential),
        addedAt: Number(item.addedAt || 0),
        sortOrder: Number.isFinite(Number(item.sortOrder))
          ? Number(item.sortOrder)
          : effectiveOrder.indexOf(item.id),
        lastActiveAt: Number(item.lastActiveAt || 0),
        quotaUpdatedAt: Number(item.quotaSavedAt || 0),
        collapsed,
        account: acctInfo,
        rateLimits
      };
    });

    if (agyAccounts.length === 0) {
      const agyEffectiveAvail = !latestVault.signedOut?.antigravity && agyLiveAvail;
      agyAccounts = [
        {
          id:
            agyEffectiveAvail && liveAgyAccount?.email
              ? makeAccountId('antigravity', liveAgyAccount.email)
              : 'antigravity:default',
          provider: 'antigravity',
          email: agyEffectiveAvail ? liveAgyAccount?.email || '' : '',
          name: agyEffectiveAvail ? liveAgyAccount?.name || 'Antigravity' : 'Antigravity',
          label: '',
          plan: agyEffectiveAvail ? liveAgyAccount?.plan || '' : '',
          active: agyEffectiveAvail,
          available: agyEffectiveAvail,
          signedOut: !agyEffectiveAvail,
          hasCredential: agyEffectiveAvail,
          addedAt: 0,
          lastActiveAt: 0,
          quotaUpdatedAt: 0,
          collapsed: Boolean(collapsedMap.antigravity),
          account: agyEffectiveAvail
            ? liveAgyAccount
            : { available: false, signedOut: true, name: 'Antigravity', email: '', plan: '' },
          rateLimits: agyEffectiveAvail
            ? liveAgyLimits
            : { available: false, primaryBars: [], allBuckets: [], error: 'Not signed in.' }
        }
      ];
    }

    // Build Claude Code accounts view models (preserving user-configured accountOrder / sortOrder)
    const claudeList = this.sortVaultProviderAccounts(
      latestVault.accounts.claude,
      effectiveOrder
    );
    let claudeAccounts = claudeList.map((item) => {
      const isActive = latestVault.activeAccountId.claude
        ? latestVault.activeAccountId.claude === item.id
        : Boolean(
            liveClaudeAccount?.available &&
              normalizeEmail(liveClaudeAccount.email) === normalizeEmail(item.email)
          );
      const liveMatchesItem =
        Boolean(liveClaudeAccount?.available) &&
        normalizeEmail(liveClaudeAccount.email) === normalizeEmail(item.email);
      const acctInfo = liveMatchesItem
        ? {
            ...liveClaudeAccount,
            label: item.label || ''
          }
        : {
            available: true,
            name: item.name || item.email,
            email: item.email,
            plan: item.plan || 'Claude',
            label: item.label || ''
          };
      const effectiveRawQuota = liveMatchesItem && rawClaudeQuota ? rawClaudeQuota : item.rawQuota;
      const rateLimits =
        liveMatchesItem && liveClaudeLimits?.available
          ? liveClaudeLimits
          : effectiveRawQuota
            ? parseClaudeQuotaSummary(
                effectiveRawQuota,
                liveMatchesItem ? claudeRelayMerged : null,
                nowMs
              )
            : {
                available: false,
                primaryBars: [],
                allBuckets: [],
                error: 'Fetching Claude account usage…'
              };
      const collapseKey = item.id;
      const collapsed =
        typeof collapsedMap[collapseKey] === 'boolean'
          ? collapsedMap[collapseKey]
          : Boolean(collapsedMap.claude);
      return {
        id: item.id,
        provider: 'claude',
        email: item.email,
        name: acctInfo.name || item.email,
        label: item.label || '',
        plan: acctInfo.plan || item.plan || '',
        active: Boolean(isActive),
        available: true,
        hasCredential: Boolean(item.hasCredential),
        addedAt: Number(item.addedAt || 0),
        sortOrder: Number.isFinite(Number(item.sortOrder))
          ? Number(item.sortOrder)
          : effectiveOrder.indexOf(item.id),
        lastActiveAt: Number(item.lastActiveAt || 0),
        quotaUpdatedAt: Number(item.quotaSavedAt || 0),
        collapsed,
        account: acctInfo,
        rateLimits
      };
    });

    if (claudeAccounts.length === 0) {
      const claudeEffectiveAvail =
        !latestVault.signedOut?.claude && Boolean(liveClaudeAccount?.available);
      claudeAccounts = [
        {
          id:
            claudeEffectiveAvail && liveClaudeAccount?.email
              ? makeAccountId('claude', liveClaudeAccount.email)
              : 'claude:default',
          provider: 'claude',
          email: claudeEffectiveAvail ? liveClaudeAccount?.email || '' : '',
          name: claudeEffectiveAvail ? liveClaudeAccount?.name || 'Claude Code' : 'Claude Code',
          label: '',
          plan: claudeEffectiveAvail ? liveClaudeAccount?.plan || '' : '',
          active: claudeEffectiveAvail,
          available: claudeEffectiveAvail,
          signedOut: !claudeEffectiveAvail,
          hasCredential: claudeEffectiveAvail,
          addedAt: 0,
          lastActiveAt: 0,
          quotaUpdatedAt: 0,
          collapsed: Boolean(collapsedMap.claude),
          account: claudeEffectiveAvail
            ? liveClaudeAccount
            : { available: false, signedOut: true, name: 'Claude Code', email: '', plan: '' },
          rateLimits: claudeEffectiveAvail
            ? liveClaudeLimits
            : { available: false, primaryBars: [], allBuckets: [], error: 'Not signed in.' }
        }
      ];
    }

    return {
      antigravity: agyAccounts,
      claude: claudeAccounts,
      accountOrder: effectiveOrder,
      pendingAccountLogin: this.getPendingLoginState()
    };
  }

  reorderAccount({
    accountId = '',
    provider = '',
    direction = '',
    targetAccountId = '',
    position = '',
    orderedIds = null
  } = {}) {
    const vault = this.readVault();
    const currentOrder = this.getEffectiveAccountOrder(vault);
    const cleanId = String(accountId || '').trim();
    const cleanTargetId = String(targetAccountId || '').trim();

    if (cleanId && !currentOrder.includes(cleanId)) {
      currentOrder.push(cleanId);
    }
    if (cleanTargetId && !currentOrder.includes(cleanTargetId)) {
      currentOrder.push(cleanTargetId);
    }

    let nextOrder = [...currentOrder];

    if (Array.isArray(orderedIds) && orderedIds.length > 0) {
      const seen = new Set();
      nextOrder = [];
      for (const rawId of orderedIds) {
        const cid = String(rawId || '').trim();
        if (cid && !seen.has(cid)) {
          seen.add(cid);
          nextOrder.push(cid);
        }
      }
      for (const cid of currentOrder) {
        if (cid && !seen.has(cid)) {
          seen.add(cid);
          nextOrder.push(cid);
        }
      }
    } else if (cleanId && cleanTargetId && cleanId !== cleanTargetId) {
      const without = nextOrder.filter((id) => id !== cleanId);
      const targetIdx = without.indexOf(cleanTargetId);
      if (targetIdx === -1) {
        without.push(cleanId);
      } else {
        const insertIdx = position === 'after' ? targetIdx + 1 : targetIdx;
        without.splice(insertIdx, 0, cleanId);
      }
      nextOrder = without;
    } else if (cleanId && direction) {
      const delta =
        direction === 'up' || direction === 'left' || direction === -1 || direction === '-1'
          ? -1
          : 1;
      const idx = nextOrder.indexOf(cleanId);
      const nextIdx = idx + delta;
      if (idx !== -1 && nextIdx >= 0 && nextIdx < nextOrder.length) {
        const tmp = nextOrder[idx];
        nextOrder[idx] = nextOrder[nextIdx];
        nextOrder[nextIdx] = tmp;
      } else if (provider) {
        const cleanProv = provider === 'claude' ? 'claude' : 'antigravity';
        const provIds = this.sortVaultProviderAccounts(
          vault.accounts[cleanProv] || [],
          nextOrder
        ).map((a) => a.id);
        const pIdx = provIds.indexOf(cleanId);
        const pNext = pIdx + delta;
        if (pIdx !== -1 && pNext >= 0 && pNext < provIds.length) {
          const siblingId = provIds[pNext];
          const aGlobal = nextOrder.indexOf(cleanId);
          const bGlobal = nextOrder.indexOf(siblingId);
          if (aGlobal !== -1 && bGlobal !== -1) {
            const tmp = nextOrder[aGlobal];
            nextOrder[aGlobal] = nextOrder[bGlobal];
            nextOrder[bGlobal] = tmp;
          }
        }
      }
    }

    vault.accountOrder = nextOrder;
    const orderIdx = new Map(nextOrder.map((id, i) => [id, i]));
    for (const prov of ['antigravity', 'claude']) {
      vault.accounts[prov] = this.sortVaultProviderAccounts(
        vault.accounts[prov] || [],
        nextOrder
      );
      vault.accounts[prov].forEach((entry, idx) => {
        if (entry && typeof entry === 'object') {
          entry.sortOrder = orderIdx.has(entry.id) ? orderIdx.get(entry.id) : idx;
        }
      });
    }

    this.writeVault(vault);
    this.notifyChanged();
    return { ok: true, accountOrder: nextOrder };
  }

  setAccountLabel({ provider, accountId, label }) {
    const cleanProv = provider === 'claude' ? 'claude' : 'antigravity';
    const vault = this.readVault();
    const entry = vault.accounts[cleanProv].find((a) => a && a.id === accountId);
    if (!entry) {
      return { ok: false, error: 'Account not found' };
    }
    entry.label = String(label || '').trim().slice(0, 36);
    this.writeVault(vault);
    this.notifyChanged();
    return { ok: true, account: entry };
  }

  async switchActiveAccount({ provider, accountId, vscode }) {
    const cleanProv = provider === 'claude' ? 'claude' : 'antigravity';
    const vault = this.readVault();
    const target = vault.accounts[cleanProv].find(
      (a) => a && (a.id === accountId || normalizeEmail(a.email) === normalizeEmail(accountId))
    );
    if (!target) {
      return { ok: false, error: 'Account not found in THEO vault.' };
    }

    if (cleanProv === 'claude') {
      // 1. Ensure current active Claude credentials on disk are synced into their own vault folder first
      const activeCredsPath = path.join(this.claudeHomeDir, '.credentials.json');
      const activeCfgObj = safeReadJson(this.globalClaudeJsonPath) || {};
      const activeCredsObj = safeReadJson(activeCredsPath);
      if (activeCredsObj?.claudeAiOauth?.accessToken && activeCfgObj?.oauthAccount?.emailAddress) {
        this.syncActiveClaudeFromDisk(activeCfgObj, activeCredsObj);
      }

      // 2. Read target account's vaulted credentials & oauthAccount
      const targetDir = target.configDir || path.join(this.accountsRootDir, makeSafeSlug('claude', target.email));
      const targetCreds = safeReadJson(path.join(targetDir, '.credentials.json'));
      const targetCfg = safeReadJson(path.join(targetDir, '.claude.json'));
      if (!targetCreds?.claudeAiOauth?.accessToken) {
        return {
          ok: false,
          error: `Saved credentials for ${target.email} need re-authentication. Click Re-authenticate.`
        };
      }

      // 3. Write target credentials into ~/.claude/.credentials.json and update oauthAccount in ~/.claude.json
      safeWriteJson(
        activeCredsPath,
        {
          claudeAiOauth: targetCreds.claudeAiOauth,
          organizationUuid:
            targetCreds.organizationUuid || targetCfg?.oauthAccount?.organizationUuid || target.orgId || ''
        },
        0o600
      );

      const mergedGlobalCfg = { ...activeCfgObj };
      if (targetCfg?.oauthAccount) {
        mergedGlobalCfg.oauthAccount = targetCfg.oauthAccount;
      } else {
        mergedGlobalCfg.oauthAccount = {
          ...(activeCfgObj.oauthAccount || {}),
          emailAddress: target.email,
          displayName: target.name || target.email.split('@')[0],
          organizationUuid: target.orgId || targetCreds.organizationUuid || ''
        };
      }
      delete mergedGlobalCfg.cachedUsageUtilization;
      safeWriteJson(this.globalClaudeJsonPath, mergedGlobalCfg, 0o600);

      // Clear stale panel relay usage file so previous account's utilization never bleeds into the newly active account
      try {
        const relayFile = path.join(this.claudeHomeDir, '.theo-claude-panel-usage.json');
        if (fs.existsSync(relayFile)) fs.unlinkSync(relayFile);
      } catch {}

      const freshVault = this.readVault();
      freshVault.activeAccountId.claude = target.id;
      if (freshVault.signedOut?.claude) {
        freshVault.signedOut.claude = false;
      }
      const freshEntry = freshVault.accounts.claude.find((a) => a && a.id === target.id);
      if (freshEntry) freshEntry.lastActiveAt = Date.now();
      this.writeVault(freshVault);
      this.syncClaudeVscAutoUpdateState(false);

      await this.ensureClaudeExtensionActiveIfNeeded(vscode);
      if (vscode?.commands) {
        await vscode.commands
          .executeCommand('antigravityHub.claudeResetCachedUsage')
          .then(() => {}, () => {});
      }

      await this.fetchVaultedClaudeAccountQuota(freshEntry || target, { forceQuota: true }).catch(
        () => null
      );
      this.notifyChanged();
      return { ok: true, provider: 'claude', accountId: target.id, email: target.email };
    }

    // Antigravity switch:
    // 1. Save current live keyring entry (sanitized) into its matching email vault slot first
    try {
      const curRaw = await this.keyring.read(AGY_KEYRING_LIVE_TARGET, { bypassCache: true });
      if (curRaw) {
        const curClean = sanitizeAntigravityStoredTokenJson(curRaw);
        const curEmail = extractAntigravityStoredTokenEmail(curClean.parsed);
        if (hasValidAntigravityStoredToken(curClean.parsed) && isPlausibleEmail(curEmail)) {
          if (normalizeEmail(curClean.parsed.id_token_email) !== curEmail) {
            curClean.parsed.id_token_email = curEmail;
          }
          await this.keyring.write(
            `theo-hub:antigravity:${curEmail}`,
            JSON.stringify(curClean.parsed),
            curEmail
          );
        }
      }
    } catch {}

    // 2. Read target account's keyring blob and strip any bogus workspace UUID project_id before activating
    const targetKeyringKey = `theo-hub:antigravity:${normalizeEmail(target.email)}`;
    const rawTarget = await this.keyring.read(targetKeyringKey, { bypassCache: true });
    if (!rawTarget) {
      return {
        ok: false,
        error: `Saved token for ${target.email} was not found. Click "+ Add Account" to sign in ${target.email}.`
      };
    }

    const cleanTarget = sanitizeAntigravityStoredTokenJson(rawTarget);
    if (!hasValidAntigravityStoredToken(cleanTarget.parsed)) {
      return {
        ok: false,
        error: `Saved token for ${target.email} is incomplete. Click "+ Add" to sign in ${target.email}.`
      };
    }
    const targetRaw = cleanTarget.raw;
    if (cleanTarget.sanitized) {
      await this.keyring.write(targetKeyringKey, targetRaw, normalizeEmail(target.email));
    }

    const wrote = await this.keyring.write(AGY_KEYRING_LIVE_TARGET, targetRaw, 'antigravity');
    if (!wrote) {
      return { ok: false, error: 'Failed to update Antigravity keyring credential.' };
    }
    this.syncJetskiStandaloneOauthFile(targetRaw);
    this.lastAgyKeyringHash = hashText(targetRaw);
    this.lastAgyKeyringCheckAt = Date.now();
    this.expectedAgyEmailUntil = {
      email: normalizeEmail(target.email),
      until: Date.now() + 20000
    };

    const freshVault = this.readVault();
    const prevActiveId = freshVault.activeAccountId.antigravity || '';
    const prevActiveEntry = prevActiveId
      ? freshVault.accounts.antigravity.find((a) => a && a.id === prevActiveId)
      : null;
    freshVault.activeAccountId.antigravity = target.id;
    const freshEntry = freshVault.accounts.antigravity.find((a) => a && a.id === target.id);
    if (freshEntry) {
      freshEntry.lastActiveAt = Date.now();
      if (
        cleanTarget.sanitized ||
        freshEntry.tierId === 'agy-business-paygo-tier' ||
        freshEntry.plan === 'Agent Platform'
      ) {
        freshEntry.plan = '';
        freshEntry.tierId = '';
        if (freshEntry.rawQuota && !hasUsableAntigravityQuotaBars(freshEntry.rawQuota)) {
          freshEntry.rawQuota = null;
          freshEntry.quotaSavedAt = 0;
        }
      }
    }
    this.writeVault(freshVault);

    await Promise.all([
      this.fetchVaultedAntigravityAccountQuota(freshEntry || target, { forceQuota: true }).catch(
        () => null
      ),
      prevActiveEntry && prevActiveEntry.id !== target.id
        ? this.fetchVaultedAntigravityAccountQuota(prevActiveEntry, { forceQuota: true }).catch(
            () => null
          )
        : Promise.resolve(null),
      this.restartAntigravityHubForSwitch(vscode, {
        userInitiated: true,
        expectedEmail: normalizeEmail(target.email)
      })
    ]);
    this.notifyChanged();
    return { ok: true, provider: 'antigravity', accountId: target.id, email: target.email };
  }

  async restartAntigravityHubForSwitch(vscode, options = {}) {
    if (this.restartHubHook) {
      return await this.restartHubHook(vscode, options);
    }
    try {
      const directBridge = require('./compat/antigravity-hub-bridge.cjs');
      if (
        directBridge?.getBridgeState?.()?.attached &&
        typeof directBridge.restartHubForAccountSwitch === 'function'
      ) {
        directBridge.hotUpgradeLiveState?.();
        const directRes = await directBridge.restartHubForAccountSwitch(
          directBridge.getBridgeState(),
          options
        );
        if (directRes && directRes.ok) {
          return directRes;
        }
      }
    } catch {}
    if (vscode?.commands) {
      try {
        const res = await vscode.commands.executeCommand(
          'antigravityHub.restartHubForAccountSwitch',
          options
        );
        if (res && res.ok) {
          return res;
        }
      } catch {}
    }

    // Fallback when running from Remote PWA / keepalive or against a pre-reload bridge instance:
    // attempt in-place credential hot-swap on the saved hub first, otherwise unlink bhf-persistent-hub.json
    // so reconnectTabs spawns a fresh hub for the new account immediately.
    try {
      const directBridge = require('./compat/antigravity-hub-bridge.cjs');
      const hubFile = this.hubStatePath;
      if (fs.existsSync(hubFile)) {
        const saved = safeReadJson(hubFile);
        const oldPid = Number(saved?.pid || 0);
        const oldPort = Number(saved?.port || 0);
        const oldCsrf = String(saved?.csrfToken || '').trim();
        if (
          oldPort > 0 &&
          oldCsrf &&
          options.expectedEmail &&
          typeof directBridge?.tryHotReloadHubAuthInPlace === 'function'
        ) {
          const hotRes = await directBridge
            .tryHotReloadHubAuthInPlace(null, oldPort, oldCsrf, options.expectedEmail, 2500)
            .catch(() => null);
          if (hotRes?.ok) {
            return hotRes;
          }
        }
        const runningIds =
          oldPort > 0 && oldCsrf && typeof directBridge?.getRunningCascadeIds === 'function'
            ? await directBridge.getRunningCascadeIds(oldPort, oldCsrf, 1500)
            : [];
        try {
          fs.unlinkSync(hubFile);
        } catch {}
        if (runningIds.length === 0 && oldPid > 0 && process.platform === 'win32') {
          await new Promise((resolve) => {
            execFile(
              'taskkill.exe',
              ['/F', '/T', '/PID', String(oldPid)],
              { timeout: 4000, windowsHide: true },
              () => resolve()
            );
          });
        }
      }
      if (vscode?.commands) {
        await vscode.commands
          .executeCommand('antigravityHub.reconnectTabs', {
            forceRestart: true,
            forceRender: false
          })
          .catch(() => {});
      }
    } catch {}
    return { ok: true };
  }

  async cancelAddAccount() {
    const pending = this.pendingLogin;
    if (!pending) {
      this.clearAgyLoginLock();
      return { ok: true };
    }
    this.pendingLogin = null;
    if (pending.pollTimer) {
      clearInterval(pending.pollTimer);
    }
    if (pending.closeDisposable?.dispose) {
      try {
        pending.closeDisposable.dispose();
      } catch {}
    }
    if (pending.loginSession?.stop) {
      await pending.loginSession.stop().catch(() => {});
    }
    if (pending.terminal) {
      try {
        pending.terminal.dispose();
      } catch {}
    }
    if (pending.provider === 'antigravity' && pending.hadBackup) {
      try {
        const backupRaw = await this.keyring.read(AGY_KEYRING_RESTORE_TARGET, {
          bypassCache: true
        });
        if (backupRaw) {
          const cleanBackup = sanitizeAntigravityStoredTokenJson(backupRaw);
          if (hasValidAntigravityStoredToken(cleanBackup.parsed)) {
            await this.keyring.write(AGY_KEYRING_LIVE_TARGET, cleanBackup.raw, 'antigravity');
            this.lastAgyKeyringHash = hashText(cleanBackup.raw);
          }
        }
      } catch {}
    }
    if (pending.provider === 'antigravity') {
      this.clearAgyLoginLock();
    }
    if (pending.stagingDir && fs.existsSync(pending.stagingDir)) {
      try {
        fs.rmSync(pending.stagingDir, { recursive: true, force: true });
      } catch {}
    }
    this.notifyChanged();
    return { ok: true };
  }

  focusLoginTerminal() {
    if (this.pendingLogin?.terminal) {
      try {
        this.pendingLogin.terminal.show(false);
        return true;
      } catch {}
    }
    return false;
  }

  async startAddAccount(options = {}) {
    const provider = options.provider === 'claude' ? 'claude' : 'antigravity';
    const label = String(options.label || '').trim().slice(0, 36);
    const emailHint = normalizeEmail(options.emailHint || '');
    const switchOnComplete = options.switchOnComplete !== false;
    const vscode = options.vscode;

    if (!vscode?.window?.createTerminal) {
      return { ok: false, error: 'Sign-in must be started from VS Code (or when VS Code is open).' };
    }

    if (this.pendingLogin) {
      await this.cancelAddAccount();
    }

    if (provider === 'claude') {
      const hadExistingClaude = this.readVault().accounts.claude.length > 0;
      const stagingDir = path.join(this.accountsRootDir, `staging-claude-${Date.now()}`);
      fs.mkdirSync(stagingDir, { recursive: true });
      const claudeBin = findClaudeBinaryPath();
      const args = ['auth', 'login'];
      if (emailHint) {
        args.push('--email', emailHint);
      }

      const term = vscode.window.createTerminal({
        name: 'THEO · Add Claude Account',
        shellPath: claudeBin,
        shellArgs: args,
        env: {
          ...process.env,
          CLAUDE_CONFIG_DIR: stagingDir
        }
      });
      term.show(false);

      const state = {
        provider: 'claude',
        label,
        emailHint,
        switchOnComplete,
        stagingDir,
        terminal: term,
        startedAt: Date.now(),
        completing: false,
        message: hadExistingClaude
          ? 'Complete Anthropic sign-in in your browser. Your existing Claude account stays logged in.'
          : 'Complete Anthropic sign-in in your browser.'
      };
      this.pendingLogin = state;
      this.notifyChanged();

      const tryCompleteClaudeLogin = async () => {
        if (this.pendingLogin !== state || state.completing) return false;
        const stagedCredsPath = path.join(stagingDir, '.credentials.json');
        const stagedCreds = safeReadJson(stagedCredsPath);
        if (!stagedCreds?.claudeAiOauth?.accessToken) {
          return false;
        }
        state.completing = true;
        try {
          let statusInfo = null;
          await new Promise((resolve) => {
            execFile(
              claudeBin,
              ['auth', 'status'],
              {
                env: { ...process.env, CLAUDE_CONFIG_DIR: stagingDir },
                timeout: 5000,
                windowsHide: true
              },
              (_err, stdout) => {
                try {
                  statusInfo = JSON.parse(String(stdout || '').trim());
                } catch {}
                resolve();
              }
            );
          });
          const stagedCfg = safeReadJson(path.join(stagingDir, '.claude.json')) || {};
          const email = normalizeEmail(
            statusInfo?.email || stagedCfg?.oauthAccount?.emailAddress || emailHint
          );
          if (!email) {
            state.completing = false;
            return false;
          }

          const finalDir = path.join(this.accountsRootDir, makeSafeSlug('claude', email));
          fs.mkdirSync(finalDir, { recursive: true });
          safeWriteJson(path.join(finalDir, '.credentials.json'), stagedCreds, 0o600);
          const oauthAccount = stagedCfg.oauthAccount || {
            emailAddress: email,
            displayName: email.split('@')[0],
            organizationUuid: statusInfo?.orgId || stagedCreds.organizationUuid || ''
          };
          safeWriteJson(path.join(finalDir, '.claude.json'), { oauthAccount }, 0o600);

          const parsedAcct = parseClaudeAccountStatus({ oauthAccount }, stagedCreds);
          const enrolled = this.upsertVaultAccount(
            'claude',
            {
              email,
              name: parsedAcct.name || email.split('@')[0],
              label: label || undefined,
              plan: parsedAcct.plan,
              subscriptionType:
                stagedCreds?.claudeAiOauth?.subscriptionType || statusInfo?.subscriptionType || '',
              rateLimitTier: stagedCreds?.claudeAiOauth?.rateLimitTier || '',
              orgId: statusInfo?.orgId || stagedCreds.organizationUuid || '',
              orgName: statusInfo?.orgName || '',
              configDir: finalDir,
              hasCredential: true
            },
            { markActive: false }
          );

          if (state.pollTimer) clearInterval(state.pollTimer);
          if (state.closeDisposable?.dispose) state.closeDisposable.dispose();
          this.pendingLogin = null;
          try {
            term.dispose();
          } catch {}
          try {
            fs.rmSync(stagingDir, { recursive: true, force: true });
          } catch {}

          if (enrolled) {
            await this.fetchVaultedClaudeAccountQuota(enrolled, { forceQuota: true }).catch(
              () => null
            );
            if (switchOnComplete || !hadExistingClaude) {
              await this.switchActiveAccount({
                provider: 'claude',
                accountId: enrolled.id,
                vscode
              });
            }
          }
          vscode.window?.showInformationMessage?.(
            hadExistingClaude
              ? `THEO: Connected Claude Code account ${email}${label ? ` (${label})` : ''}. Existing accounts remain logged in.`
              : `THEO: Signed in to Claude Code as ${email}${label ? ` (${label})` : ''}.`
          );
          this.notifyChanged();
          return true;
        } catch {
          state.completing = false;
          return false;
        }
      };

      state.pollTimer = setInterval(() => {
        if (Date.now() - state.startedAt > 5 * 60 * 1000) {
          this.cancelAddAccount();
          return;
        }
        tryCompleteClaudeLogin().catch(() => {});
      }, 1500);

      if (vscode.window.onDidCloseTerminal) {
        state.closeDisposable = vscode.window.onDidCloseTerminal(async (closed) => {
          if (closed === term && this.pendingLogin === state) {
            const ok = await tryCompleteClaudeLogin().catch(() => false);
            if (!ok && this.pendingLogin === state) {
              await this.cancelAddAccount();
            }
          }
        });
      }

      return { ok: true, provider: 'claude', pending: this.getPendingLoginState() };
    }

    // Antigravity standard desktop consumer sign-in flow:
    // NEVER set AGY_CLI_CDE_AUTH_ACTION='login' (that triggers Cloud Workstations enterprise PayGo login
    // and stamps the active local workspace UUID onto StoredToken.project_id -> 403 PERMISSION_DENIED).
    // Instead:
    // 1. Write cross-process staging lock (so relay_keepalive.cjs never reads/writes gemini:antigravity mid-login),
    //    and vault current valid gemini:antigravity into both its email slot and __restore__ safety slot.
    this.writeAgyLoginLock();
    let hadBackup = false;
    let previousEmail = '';
    const rawExisting = await this.keyring.read(AGY_KEYRING_LIVE_TARGET, { bypassCache: true });
    if (rawExisting) {
      const cleanExisting = sanitizeAntigravityStoredTokenJson(rawExisting);
      if (hasValidAntigravityStoredToken(cleanExisting.parsed)) {
        previousEmail = extractAntigravityStoredTokenEmail(cleanExisting.parsed);
        if (previousEmail && normalizeEmail(cleanExisting.parsed.id_token_email) !== previousEmail) {
          cleanExisting.parsed.id_token_email = previousEmail;
        }
        const existingRaw = previousEmail ? JSON.stringify(cleanExisting.parsed) : cleanExisting.raw;
        const wroteRestore = await this.keyring.write(
          AGY_KEYRING_RESTORE_TARGET,
          existingRaw,
          'antigravity'
        );
        if (!wroteRestore) {
          this.clearAgyLoginLock();
          return {
            ok: false,
            error: 'Could not back up current Antigravity credential safely; aborted sign-in.'
          };
        }
        if (isPlausibleEmail(previousEmail)) {
          await this.keyring.write(
            `theo-hub:antigravity:${previousEmail}`,
            existingRaw,
            previousEmail
          );
        }
        hadBackup = true;
      } else {
        // Live slot held an empty stub like {"token":null}; preserve any prior valid __restore__ slot
        const priorRestore = await this.keyring.read(AGY_KEYRING_RESTORE_TARGET, {
          bypassCache: true
        });
        if (
          priorRestore &&
          hasValidAntigravityStoredToken(sanitizeAntigravityStoredTokenJson(priorRestore).parsed)
        ) {
          hadBackup = true;
        }
      }
      await this.keyring.remove(AGY_KEYRING_LIVE_TARGET);
    } else {
      const priorRestore = await this.keyring.read(AGY_KEYRING_RESTORE_TARGET, {
        bypassCache: true
      });
      if (
        priorRestore &&
        hasValidAntigravityStoredToken(sanitizeAntigravityStoredTokenJson(priorRestore).parsed)
      ) {
        hadBackup = true;
      }
    }

    const agyBin = findAgyBinaryPath();
    let ptyWriteEmitter = null;
    const writeTermLine = (line) => {
      if (ptyWriteEmitter) {
        try {
          ptyWriteEmitter.fire(`${String(line || '')}\r\n`);
        } catch {}
      }
    };

    const openAuthUrlInBrowser = (url) => {
      if (!url || typeof vscode?.env?.openExternal !== 'function') return;
      try {
        const uri = vscode.Uri?.parse ? vscode.Uri.parse(url) : url;
        Promise.resolve(vscode.env.openExternal(uri)).catch(() => {});
      } catch {}
    };

    const state = {
      provider: 'antigravity',
      label,
      emailHint,
      switchOnComplete,
      hadBackup,
      previousEmail,
      vscode,
      authUrl: '',
      verificationUrl: '',
      awaitingVerification: false,
      loginSession: null,
      loginRpcSettled: false,
      tokenFirstSeenAt: 0,
      terminal: null,
      startedAt: Date.now(),
      completing: false,
      continueAfterVerification: null,
      openActiveBrowserUrl: null,
      message:
        'Choose your Google account in the browser ("Use another account" for a second account). Your current account stays saved.'
    };

    state.openActiveBrowserUrl = () => {
      const targetUrl =
        state.awaitingVerification && state.verificationUrl
          ? state.verificationUrl
          : state.authUrl || state.verificationUrl;
      if (targetUrl) {
        writeTermLine('Opening link in default browser…');
        openAuthUrlInBrowser(targetUrl);
      }
    };

    let term;
    if (typeof vscode.EventEmitter === 'function') {
      ptyWriteEmitter = new vscode.EventEmitter();
      const ptyCloseEmitter = new vscode.EventEmitter();
      term = vscode.window.createTerminal({
        name: 'THEO · Add Antigravity Account',
        pty: {
          onDidWrite: ptyWriteEmitter.event,
          onDidClose: ptyCloseEmitter.event,
          open: () => {
            writeTermLine('THEO · Google Antigravity Consumer Sign-In');
            writeTermLine('Your existing Antigravity account remains safely vaulted.');
            if (state.awaitingVerification && state.verificationUrl) {
              writeTermLine('');
              writeTermLine('⚠ Google Account Verification Required:');
              writeTermLine(`  ${state.verificationUrl}`);
              writeTermLine('Press [Enter] once verified to finish signing in, or [V] to re-open the link.');
            } else if (state.authUrl) {
              writeTermLine('');
              writeTermLine('Sign-in link (or copy into another browser profile / Incognito):');
              writeTermLine(`  ${state.authUrl}`);
              writeTermLine('');
              writeTermLine('Press [Enter] to re-open in your default browser, or close this terminal to cancel.');
            } else {
              writeTermLine('Preparing Google OAuth sign-in link…');
            }
          },
          close: () => {},
          handleInput: (data) => {
            if (data === '\r' || data === '\n') {
              if (state.awaitingVerification && typeof state.continueAfterVerification === 'function') {
                state.continueAfterVerification();
              } else if (state.authUrl) {
                writeTermLine('Re-opening Google sign-in link in default browser…');
                openAuthUrlInBrowser(state.authUrl);
              }
            } else if (
              (data === 'v' || data === 'V') &&
              state.awaitingVerification &&
              state.verificationUrl
            ) {
              writeTermLine('Re-opening Google account verification link in default browser…');
              openAuthUrlInBrowser(state.verificationUrl);
            }
          }
        }
      });
    } else {
      // Minimal test mock fallback (no EventEmitter): never pass AGY_CLI_CDE_AUTH_ACTION
      term = vscode.window.createTerminal({
        name: 'THEO · Add Antigravity Account',
        cwd: os.homedir(),
        env: {
          HOME: os.homedir(),
          USERPROFILE: os.homedir(),
          AGY_ENABLE_HUB: '1',
          ANTIGRAVITY_VSCODE_HOST: '1',
          ANTIGRAVITY_AUTH_SUCCESS_APP: vscode.env?.uriScheme || 'vscode'
        }
      });
    }
    state.terminal = term;
    term.show(false);

    this.pendingLogin = state;
    this.notifyChanged();

    const tryCompleteAgyLogin = async (completeOpts = {}) => {
      if (this.pendingLogin !== state || state.completing) return false;
      const rawNew = await this.keyring.read(AGY_KEYRING_LIVE_TARGET, { bypassCache: true });
      if (!rawNew) return false;
      const cleanNew = sanitizeAntigravityStoredTokenJson(rawNew);
      const parsed = cleanNew.parsed;
      if (!hasValidAntigravityStoredToken(parsed)) {
        return false;
      }

      // Give the ephemeral consumer Login RPC up to 4s after SaveToken to finish loadCodeAssist/onboardUser
      if (state.loginSession && !completeOpts.fromLoginRpc && !state.loginRpcSettled) {
        if (!state.tokenFirstSeenAt) {
          state.tokenFirstSeenAt = Date.now();
        }
        if (Date.now() - state.tokenFirstSeenAt < 4000) {
          return false;
        }
      }

      state.completing = true;
      try {
        let fetchedProfile = null;
        let fetchedQuota = null;
        if (state.loginSession?.fetchProfileAndQuota) {
          const pq = await state.loginSession.fetchProfileAndQuota().catch(() => null);
          if (pq?.userStatusRaw) {
            fetchedProfile = parseAntigravityAccountStatus(pq.userStatusRaw);
          }
          if (pq?.quotaRaw && hasUsableAntigravityQuotaBars(pq.quotaRaw)) {
            fetchedQuota = pq.quotaRaw;
          }
        }

        const resolvedEmail = [
          extractAntigravityStoredTokenEmail(parsed),
          fetchedProfile?.email,
          emailHint
        ]
          .map((c) => normalizeEmail(c))
          .find((c) => isPlausibleEmail(c));

        if (!resolvedEmail) {
          state.completing = false;
          return false;
        }
        const newEmail = resolvedEmail;

        let mutated = cleanNew.sanitized;
        if (normalizeEmail(parsed.id_token_email) !== newEmail) {
          parsed.id_token_email = newEmail;
          mutated = true;
        }
        if (!parsed.project_id && parsed.auth_method !== 'consumer') {
          parsed.auth_method = 'consumer';
          mutated = true;
        }
        const newRaw = mutated ? JSON.stringify(parsed) : cleanNew.raw;

        await this.keyring.write(`theo-hub:antigravity:${newEmail}`, newRaw, newEmail);
        if (mutated && switchOnComplete) {
          await this.keyring.write(AGY_KEYRING_LIVE_TARGET, newRaw, 'antigravity');
        }

        const safeFetchedPlan =
          fetchedProfile?.tierId === 'agy-business-paygo-tier' ? '' : fetchedProfile?.plan || '';
        const safeFetchedTierId =
          fetchedProfile?.tierId === 'agy-business-paygo-tier' ? '' : fetchedProfile?.tierId || '';

        const enrolled = this.upsertVaultAccount(
          'antigravity',
          {
            email: newEmail,
            name:
              fetchedProfile?.name && !/^local antigravity profile$/i.test(fetchedProfile.name)
                ? fetchedProfile.name
                : newEmail.split('@')[0],
            label: label || undefined,
            plan: safeFetchedPlan || undefined,
            tierId: safeFetchedTierId || undefined,
            hasCredential: true,
            rawQuota: fetchedQuota || undefined,
            quotaSavedAt: fetchedQuota ? Date.now() : undefined
          },
          { markActive: switchOnComplete }
        );

        if (state.pollTimer) clearInterval(state.pollTimer);
        if (state.closeDisposable?.dispose) state.closeDisposable.dispose();
        this.pendingLogin = null;
        this.clearAgyLoginLock();
        if (state.loginSession?.stop) {
          await state.loginSession.stop().catch(() => {});
        }
        try {
          term.dispose();
        } catch {}

        if (switchOnComplete && enrolled) {
          this.lastAgyKeyringHash = hashText(newRaw);
          this.expectedAgyEmailUntil = {
            email: newEmail,
            until: Date.now() + 20000
          };
          await this.restartAntigravityHubForSwitch(vscode);
        } else if (hadBackup) {
          // Restore previous active account while keeping the newly added account vaulted!
          const backupRaw = await this.keyring.read(AGY_KEYRING_RESTORE_TARGET, {
            bypassCache: true
          });
          if (backupRaw) {
            const cleanBackup = sanitizeAntigravityStoredTokenJson(backupRaw);
            if (hasValidAntigravityStoredToken(cleanBackup.parsed)) {
              await this.keyring.write(AGY_KEYRING_LIVE_TARGET, cleanBackup.raw, 'antigravity');
              this.lastAgyKeyringHash = hashText(cleanBackup.raw);
            }
          }
        }

        vscode.window?.showInformationMessage?.(
          `THEO: Connected Antigravity account ${newEmail}${label ? ` (${label})` : ''}. Existing accounts remain logged in.`
        );
        this.notifyChanged();
        return true;
      } catch {
        state.completing = false;
        return false;
      }
    };

    const attachLoginPromise = (promise) => {
      Promise.resolve(promise)
        .then(async (loginResp) => {
          if (this.pendingLogin !== state) return;
          const outcome = inspectAntigravityLoginResult(loginResp);
          if (outcome.status === 'verification_required') {
            state.awaitingVerification = true;
            state.verificationUrl = outcome.verificationUrl;
            state.loginRpcSettled = false;
            state.startedAt = Date.now();
            this.writeAgyLoginLock();
            state.message =
              'Google asked for a one-time security check ("Verify your account"). Complete it in your browser, then click "✓ Verified — Continue" (or press [Enter] in the terminal).';
            this.notifyChanged();

            writeTermLine('');
            writeTermLine('⚠ Google Account Verification Required');
            writeTermLine(`  ${outcome.message}`);
            writeTermLine("  1. Complete Google's one-time verification check in your browser:");
            writeTermLine(`     ${outcome.verificationUrl}`);
            writeTermLine(
              '  2. Once verified, press [Enter] here (or click "✓ Verified — Continue" in THEO) to finish signing in.'
            );
            openAuthUrlInBrowser(outcome.verificationUrl);

            if (typeof vscode.window?.showWarningMessage === 'function') {
              Promise.resolve(
                vscode.window.showWarningMessage(
                  `THEO: Google asked to verify this account ("${outcome.message}"). Complete the verification tab in your browser, then click "Verified — Continue" to finish signing in.`,
                  'Verified — Continue',
                  'Open Verification Link',
                  'Cancel'
                )
              )
                .then((choice) => {
                  if (this.pendingLogin !== state) return;
                  if (choice === 'Verified — Continue') {
                    state.continueAfterVerification?.();
                  } else if (choice === 'Open Verification Link') {
                    openAuthUrlInBrowser(outcome.verificationUrl);
                  } else if (choice === 'Cancel') {
                    this.cancelAddAccount();
                  }
                })
                .catch(() => {});
            }
            return;
          }

          if (outcome.status === 'failed') {
            writeTermLine('');
            writeTermLine(`✖ Sign-in could not complete: ${outcome.message}`);
            if (outcome.appealUrl) {
              writeTermLine(`  Appeal / more info: ${outcome.appealUrl}`);
              openAuthUrlInBrowser(outcome.appealUrl);
            }
            vscode.window?.showWarningMessage?.(
              `THEO: Antigravity sign-in did not complete — ${outcome.message}`
            );
            await this.cancelAddAccount();
            return;
          }

          state.loginRpcSettled = true;
          const ok = await tryCompleteAgyLogin({ fromLoginRpc: true }).catch(() => false);
          if (!ok && this.pendingLogin === state && outcome.status === 'ok') {
            setTimeout(() => {
              if (this.pendingLogin === state) {
                tryCompleteAgyLogin({ fromLoginRpc: true }).catch(() => {});
              }
            }, 600);
          }
        })
        .catch((err) => {
          state.loginRpcSettled = true;
          if (this.pendingLogin === state) {
            writeTermLine(`Sign-in RPC error: ${err?.message || err}`);
          }
        });
    };

    state.continueAfterVerification = () => {
      if (this.pendingLogin !== state) return;
      state.awaitingVerification = false;
      state.verificationUrl = '';
      state.loginRpcSettled = false;
      state.tokenFirstSeenAt = 0;
      state.startedAt = Date.now();
      this.writeAgyLoginLock();
      state.message =
        'Completing Google sign-in after verification — confirm your account in the browser…';
      this.notifyChanged();
      writeTermLine('');
      writeTermLine('Starting post-verification Google sign-in…');
      if (typeof state.loginSession?.startLoginAttempt === 'function') {
        attachLoginPromise(state.loginSession.startLoginAttempt());
      } else if (state.authUrl) {
        openAuthUrlInBrowser(state.authUrl);
      }
    };

    const launcher =
      this.agyLoginLauncher ||
      (typeof vscode?.env?.openExternal === 'function' ? defaultAgyConsumerLoginLauncher : null);

    if (launcher) {
      launcher({
        agyBin,
        vscode,
        emailHint,
        onLog: (msg) => writeTermLine(msg),
        onAuthUrl: (authUrl) => {
          if (this.pendingLogin !== state) return;
          state.authUrl = authUrl;
          this.notifyChanged();
          writeTermLine('');
          writeTermLine('Sign-in link (or copy into another browser profile / Incognito):');
          writeTermLine(`  ${authUrl}`);
          writeTermLine('');
          writeTermLine('Press [Enter] to re-open in your default browser, or close this terminal to cancel.');
          openAuthUrlInBrowser(authUrl);
        }
      })
        .then((session) => {
          if (this.pendingLogin !== state) {
            session?.stop?.().catch(() => {});
            return;
          }
          state.loginSession = session;
          attachLoginPromise(session.loginPromise);
        })
        .catch((err) => {
          if (this.pendingLogin === state) {
            writeTermLine(`Error starting sign-in helper: ${err?.message || err}`);
          }
        });
    }

    state.pollTimer = setInterval(() => {
      if (Date.now() - state.startedAt > 5 * 60 * 1000) {
        this.cancelAddAccount();
        return;
      }
      tryCompleteAgyLogin().catch(() => {});
    }, 1500);

    if (vscode.window.onDidCloseTerminal) {
      state.closeDisposable = vscode.window.onDidCloseTerminal(async (closed) => {
        if (closed === term && this.pendingLogin === state) {
          const ok = await tryCompleteAgyLogin({ fromLoginRpc: true }).catch(() => false);
          if (!ok && this.pendingLogin === state) {
            await this.cancelAddAccount();
          }
        }
      });
    }

    return { ok: true, provider: 'antigravity', pending: this.getPendingLoginState() };
  }

  async removeAccount({ provider, accountId, vscode }) {
    const cleanProv = provider === 'claude' ? 'claude' : 'antigravity';
    const vault = this.readVault();
    const list = vault.accounts[cleanProv];
    const cleanTargetId = String(accountId || '').trim();
    const idx = list.findIndex(
      (a) =>
        a &&
        (a.id === cleanTargetId ||
          (cleanTargetId && normalizeEmail(a.email) === normalizeEmail(cleanTargetId)) ||
          (cleanTargetId === `${cleanProv}:default` && list.length === 1))
    );
    if (idx === -1) {
      return { ok: false, error: 'Account not found.' };
    }

    const victim = list[idx];
    const isLastAccount = list.length <= 1;
    const wasActive = !isLastAccount && vault.activeAccountId[cleanProv] === victim.id;

    // If removing the currently active account while another saved account exists for this provider,
    // switch to the next saved account first so VS Code seamlessly cuts over.
    if (wasActive) {
      const fallback = list.find((a) => a && a.id !== victim.id);
      if (fallback) {
        const sw = await this.switchActiveAccount({
          provider: cleanProv,
          accountId: fallback.id,
          vscode
        });
        if (!sw.ok) {
          return sw;
        }
      }
    }

    // If signing out the last Claude Code account, notify the live VS Code Claude Code extension
    // before deleting ~/.claude/.credentials.json so controller.logout() succeeds cleanly.
    if (cleanProv === 'claude' && isLastAccount) {
      if (vscode?.commands) {
        await vscode.commands
          .executeCommand('claude-vscode.logout')
          .then(() => {}, () => {});
      }
      const realClaudeHome = path.resolve(path.join(os.homedir(), '.claude'));
      if (
        path.resolve(this.claudeHomeDir || '') === realClaudeHome &&
        process.env.THEO_SMOKE_TEST !== '1'
      ) {
        const claudeBin = findClaudeBinaryPath();
        if (claudeBin) {
          await new Promise((resolve) => {
            execFile(
              claudeBin,
              ['auth', 'logout'],
              {
                env: { ...process.env, CLAUDE_CONFIG_DIR: this.claudeHomeDir },
                timeout: 5000,
                windowsHide: true
              },
              () => resolve()
            );
          });
        }
      }
    }

    const updatedVault = this.readVault();
    updatedVault.accounts[cleanProv] = updatedVault.accounts[cleanProv].filter(
      (a) => a && a.id !== victim.id
    );
    if (Array.isArray(updatedVault.accountOrder)) {
      updatedVault.accountOrder = updatedVault.accountOrder.filter((id) => id !== victim.id);
    }
    if (updatedVault.accounts[cleanProv].length === 0) {
      updatedVault.activeAccountId[cleanProv] = '';
      if (!updatedVault.signedOut || typeof updatedVault.signedOut !== 'object') {
        updatedVault.signedOut = { antigravity: false, claude: false };
      }
      updatedVault.signedOut[cleanProv] = true;
    } else if (updatedVault.activeAccountId[cleanProv] === victim.id) {
      updatedVault.activeAccountId[cleanProv] = updatedVault.accounts[cleanProv][0]?.id || '';
    }
    this.writeVault(updatedVault);

    if (cleanProv === 'antigravity') {
      this.agyBackoffUntilById.delete(victim.id);
      await this.keyring.remove(`theo-hub:antigravity:${normalizeEmail(victim.email)}`).catch(
        () => {}
      );
      if (updatedVault.accounts.antigravity.length === 0) {
        await this.keyring.remove(AGY_KEYRING_LIVE_TARGET).catch(() => {});
        await this.keyring.remove(AGY_KEYRING_RESTORE_TARGET).catch(() => {});
        this.lastAgyKeyringHash = '';
        if (!this.hasCustomKeyring) {
          try {
            const jetskiOauthFile = path.join(
              os.homedir(),
              '.gemini',
              'jetski-standalone-oauth-token'
            );
            if (fs.existsSync(jetskiOauthFile)) {
              fs.unlinkSync(jetskiOauthFile);
            }
          } catch {}
        }
        if (vscode || this.restartHubHook) {
          await this.restartAntigravityHubForSwitch(vscode, {
            userInitiated: true,
            expectedEmail: ''
          }).catch(() => {});
        }
      }
    } else {
      this.claudeBackoffUntilById.delete(victim.id);
      const cleanVictimEmail = normalizeEmail(victim.email);
      const candidateDirs = [
        victim.configDir,
        cleanVictimEmail
          ? path.join(this.accountsRootDir, makeSafeSlug('claude', cleanVictimEmail))
          : ''
      ].filter(Boolean);
      for (const dirPath of candidateDirs) {
        if (
          path.resolve(dirPath).startsWith(path.resolve(this.accountsRootDir) + path.sep) &&
          fs.existsSync(dirPath)
        ) {
          try {
            fs.rmSync(dirPath, { recursive: true, force: true });
          } catch {}
        }
      }

      // Clean persisted Claude quota cache for the removed account
      try {
        const quotaCacheFile = path.join(this.claudeHomeDir, '.theo-claude-quota-cache.json');
        if (fs.existsSync(quotaCacheFile)) {
          if (updatedVault.accounts.claude.length === 0) {
            fs.unlinkSync(quotaCacheFile);
          } else {
            const qParsed = safeReadJson(quotaCacheFile);
            if (qParsed && typeof qParsed === 'object') {
              if (qParsed.byEmail && cleanVictimEmail) {
                delete qParsed.byEmail[cleanVictimEmail];
              }
              if (normalizeEmail(qParsed.email) === cleanVictimEmail) {
                qParsed.email = '';
                qParsed.quota = null;
              }
              safeWriteJson(quotaCacheFile, qParsed, 0o600);
            }
          }
        }
      } catch {}

      if (updatedVault.accounts.claude.length === 0) {
        this.syncClaudeVscAutoUpdateState(true);
        try {
          const activeCredsPath = path.join(this.claudeHomeDir, '.credentials.json');
          if (fs.existsSync(activeCredsPath)) {
            fs.unlinkSync(activeCredsPath);
          }
        } catch {}
        try {
          if (this.globalClaudeJsonPath && fs.existsSync(this.globalClaudeJsonPath)) {
            const globalCfg = safeReadJson(this.globalClaudeJsonPath);
            if (globalCfg && typeof globalCfg === 'object') {
              delete globalCfg.oauthAccount;
              delete globalCfg.cachedUsageUtilization;
              safeWriteJson(this.globalClaudeJsonPath, globalCfg, 0o600);
            }
          }
        } catch {}
        try {
          const relayFile = path.join(this.claudeHomeDir, '.theo-claude-panel-usage.json');
          if (fs.existsSync(relayFile)) {
            fs.unlinkSync(relayFile);
          }
        } catch {}
        if (vscode?.commands) {
          await vscode.commands
            .executeCommand('antigravityHub.claudeResetCachedUsage')
            .then(() => {}, () => {});
        }
      }
    }

    this.notifyChanged();
    return {
      ok: true,
      removedId: victim.id,
      signedOutProvider: updatedVault.accounts[cleanProv].length === 0
    };
  }
}

module.exports = {
  AccountVaultManager,
  defaultHttpsJsonRequest,
  normalizeEmail,
  isPlausibleEmail,
  extractAntigravityStoredTokenEmail,
  makeAccountId,
  makeSafeSlug,
  isBogusWorkspaceProjectId,
  hasValidAntigravityStoredToken,
  inspectAntigravityLoginResult,
  sanitizeAntigravityStoredTokenJson
};
