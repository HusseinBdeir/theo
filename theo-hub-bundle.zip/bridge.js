const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
let vscode = null;
try {
  vscode = require('vscode');
} catch {}
const {
  CLAUDE_BRIDGE_MARKER,
  CLAUDE_PIN_MARKER,
  CLAUDE_NOWARN_MARKER,
  CLAUDE_NOBROWSER_MARKER,
  CLAUDE_USAGE_RESET_MARKER,
  CLAUDE_CTX_MARKER,
  CLAUDE_RELOAD_MARKER,
  CLAUDE_CTX_UI_RUNTIME_JS,
  CLAUDE_PATCH_NAMES,
  patchClaudeExtensionSource,
  patchClaudeWebviewSource,
  assertClaudeWebviewSyntax
} = require('./compat/claude-webview-patches.cjs');

// Ids of skipped optional patches (compat/claude-webview-patches.cjs recordSkippedPatches), validated.
function cleanSkippedPatches(list) {
  const out = [];
  for (const id of Array.isArray(list) ? list : []) {
    const s = String(id || '');
    if (/^[a-z][a-z0-9-]{0,39}$/.test(s) && !out.includes(s)) out.push(s);
  }
  return out;
}

// Bundle, backup, package.json and stamp writes go to a temp file and are renamed into place, so a process that
// exits mid-write (daemon respawn, window close) leaves the old file or the new one, never half of one.
function writeFileAtomicSync(targetPath, data, encoding = 'utf8') {
  let threadId = 0;
  try {
    threadId = require('worker_threads').threadId || 0;
  } catch {}
  const tmpPath = `${targetPath}.theo-tmp-${process.pid}-${threadId}`;
  try {
    fs.writeFileSync(tmpPath, data, encoding);
    fs.renameSync(tmpPath, targetPath);
  } catch (error) {
    try {
      fs.unlinkSync(tmpPath);
    } catch {}
    // A target held open without delete sharing refuses the rename on Windows: write in place instead.
    if (error && (error.code === 'EPERM' || error.code === 'EACCES' || error.code === 'EBUSY')) {
      fs.writeFileSync(targetPath, data, encoding);
      return;
    }
    throw error;
  }
}

// Removes temp files a killed process left behind (writeFileAtomicSync names them <file>.theo-tmp-<pid>-<thread>).
function sweepStaleAtomicTmpFiles(dirs, maxAgeMs = 5 * 60 * 1000) {
  const now = Date.now();
  for (const dir of dirs) {
    let names = [];
    try {
      names = fs.readdirSync(dir);
    } catch {
      continue;
    }
    for (const name of names) {
      if (!name.includes('.theo-tmp-')) continue;
      const full = path.join(dir, name);
      try {
        if (now - fs.statSync(full).mtimeMs > maxAgeMs) fs.unlinkSync(full);
      } catch {}
    }
  }
}

// Shared by every copy of this module in the process (hot swap re-requires bridge.js), so the one-writer
// queue survives a hot swap.
const BRIDGE_WORKER_STATE = (() => {
  const key = Symbol.for('bhfirms.theoHub.bridgePatchWorker');
  if (!globalThis[key]) {
    globalThis[key] = {
      tail: Promise.resolve(),
      pending: 0,
      prepatchInFlight: false,
      workerUnavailable: false
    };
  }
  return globalThis[key];
})();

const BRIDGE_MARKER = 'antigravity-hub-bridge-v1';
const PERSISTENT_HUB_MARKER = '/*bhf-persistent-hub*/';
const BRIDGE_FILE_NAMES = [
  'antigravity-hub-bridge.cjs',
  'antigravity-tab-state.cjs',
  'antigravity-context-window.cjs',
  'excel-preview.cjs'
];
const BRIDGE_ICON_FILE_NAMES = [
  'antigravity-logo-color.svg',
  'antigravity-logo-done.svg',
  'antigravity-logo-pending.svg'
];
const CLAUDE_BRIDGE_FILE_NAMES = ['claude-hub-bridge.cjs', 'excel-preview.cjs'];
const CLAUDE_ICON_FILE_NAMES = [
  'claude-logo.svg',
  'claude-logo-done.svg',
  'claude-logo-pending.svg'
];

function getDefaultExtensionsDir() {
  return path.join(os.homedir(), '.vscode', 'extensions');
}

function parseVersionFromFolder(folderName, prefixRegex = /^google\.google-antigravity-(\d+\.\d+\.\d+)/i) {
  const match = String(folderName || '').match(prefixRegex);
  if (!match) {
    return [0, 0, 0];
  }
  return match[1].split('.').map((part) => Number.parseInt(part, 10) || 0);
}

function compareVersions(a, b) {
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    const delta = (b[index] || 0) - (a[index] || 0);
    if (delta !== 0) {
      return delta;
    }
  }
  return 0;
}

function findInstalledAntigravityExtensions(
  extensionsDir = getDefaultExtensionsDir(),
  vscodeApi = vscode
) {
  const results = [];
  const defaultDir = getDefaultExtensionsDir();
  const useActiveExt =
    !extensionsDir || path.resolve(extensionsDir) === path.resolve(defaultDir);
  if (useActiveExt) {
    const activeExtension = vscodeApi?.extensions?.getExtension?.('google.google-antigravity');
    if (activeExtension?.extensionPath && fs.existsSync(activeExtension.extensionPath)) {
      results.push(activeExtension.extensionPath);
    }
  }

  if (fs.existsSync(extensionsDir)) {
    const entries = fs
      .readdirSync(extensionsDir, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && /^google\.google-antigravity-/i.test(entry.name))
      .sort((left, right) =>
        compareVersions(parseVersionFromFolder(left.name), parseVersionFromFolder(right.name))
      );

    for (const entry of entries) {
      const fullPath = path.join(extensionsDir, entry.name);
      if (!results.includes(fullPath)) {
        results.push(fullPath);
      }
    }
  }

  return results;
}

function findInstalledClaudeExtensions(
  extensionsDir = getDefaultExtensionsDir(),
  vscodeApi = vscode
) {
  const results = [];
  const defaultDir = getDefaultExtensionsDir();
  const useActiveExt =
    !extensionsDir || path.resolve(extensionsDir) === path.resolve(defaultDir);
  if (useActiveExt) {
    const activeExtension = vscodeApi?.extensions?.getExtension?.('anthropic.claude-code');
    if (activeExtension?.extensionPath && fs.existsSync(activeExtension.extensionPath)) {
      results.push(activeExtension.extensionPath);
    }
  }

  const claudeRe = /^anthropic\.claude-code-(\d+\.\d+\.\d+)/i;
  if (fs.existsSync(extensionsDir)) {
    const entries = fs
      .readdirSync(extensionsDir, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && claudeRe.test(entry.name))
      .sort((left, right) =>
        compareVersions(
          parseVersionFromFolder(left.name, claudeRe),
          parseVersionFromFolder(right.name, claudeRe)
        )
      );

    for (const entry of entries) {
      const fullPath = path.join(extensionsDir, entry.name);
      if (!results.includes(fullPath)) {
        results.push(fullPath);
      }
    }
  }

  return results;
}

function patchAntigravityExtensionSource(sourceText, options = {}) {
  if (typeof sourceText !== 'string' || !sourceText) {
    throw new Error('Empty Antigravity extension bundle.');
  }
  const validateSyntax = options.validateSyntax !== false;

  let baseSource = sourceText;
  // Anchor 1: flexible return object with apiImpl + provider in any property order / with extra fields
  const attachReturnRe =
    /return\{(?=[^}]{0,160}\bapiImpl:([A-Za-z0-9_$]+))(?=[^}]{0,160}\bprovider:([A-Za-z0-9_$]+))[^}]{0,160}\}\};/;
  const attachMatch = baseSource.match(attachReturnRe);

  // Anchor 2 (structural VS Code API fallback if return{apiImpl,provider} is ever inlined/removed):
  // <apiImpl>.setChatViewProvider(<provider>) ... <ctx>.subscriptions.push(<vscode>.window.registerWebviewViewProvider(<naming>.viewId,<provider>
  let attachNeedle = '';
  let apiImplVar = '';
  let providerVar = '';
  let ctxVar = 'a';
  let namingVar = 'c';
  let useCommaPrefixInjection = false;

  if (attachMatch) {
    attachNeedle = attachMatch[0];
    apiImplVar = attachMatch[1];
    providerVar = attachMatch[2];
    const fnWindow = baseSource.slice(Math.max(0, attachMatch.index - 4000), attachMatch.index);
    const fnHeadMatches = Array.from(
      fnWindow.matchAll(/function [A-Za-z0-9_$]+\(([A-Za-z0-9_$]+),[A-Za-z0-9_$]+,([A-Za-z0-9_$]+)\)\{/g)
    );
    if (fnHeadMatches.length > 0) {
      const lastHead = fnHeadMatches[fnHeadMatches.length - 1];
      ctxVar = lastHead[1] || ctxVar;
      namingVar = lastHead[2] || namingVar;
    }
    const rendererCtxMatch = fnWindow.match(/WebviewRenderer\(\{[^}]{0,120}\bcontext:([A-Za-z0-9_$]+)\b/);
    if (rendererCtxMatch?.[1]) {
      ctxVar = rendererCtxMatch[1];
    }
    const namingViewMatch = fnWindow.match(
      /JetskiWebviewProvider\([A-Za-z0-9_$]+,[A-Za-z0-9_$]+,([A-Za-z0-9_$]+)\.viewId\b/
    );
    if (namingViewMatch?.[1]) {
      namingVar = namingViewMatch[1];
    }
  } else {
    const regViewRe =
      /(?<![A-Za-z0-9_$])([A-Za-z0-9_$]+)\.subscriptions\.push\([A-Za-z0-9_$]+\.window\.registerWebviewViewProvider\(([A-Za-z0-9_$]+)\.viewId,([A-Za-z0-9_$]+)\b/;
    const regMatch = baseSource.match(regViewRe);
    if (regMatch) {
      attachNeedle = regMatch[0];
      ctxVar = regMatch[1];
      namingVar = regMatch[2];
      providerVar = regMatch[3];
      useCommaPrefixInjection = true;
      const preWin = baseSource.slice(Math.max(0, regMatch.index - 2000), regMatch.index);
      const escapedProv = providerVar.replace(/\$/g, '\\$');
      const apiMatch =
        preWin.match(new RegExp(`([A-Za-z0-9_$]+)\\.setChatViewProvider\\(${escapedProv}\\)`)) ||
        preWin.match(/WebviewRenderer\(\{[^}]{0,120}\bapiImpl:([A-Za-z0-9_$]+)\b/);
      if (apiMatch?.[1]) {
        apiImplVar = apiMatch[1];
      }
    }
  }

  if (!attachNeedle || !apiImplVar || !providerVar) {
    throw new Error('Could not find PN(a,b,c) return anchor in Antigravity extension bundle.');
  }

  // Ensure multi-main webviews are allowed even before attach() runs (handles 1.8/1.9 k vs 1.10+ h)
  if (!baseSource.includes('/*antigravity-hub-multi-main*/')) {
    const registerMultiMainRe =
      /(\bregisterWebview\(([A-Za-z0-9_$]+),([A-Za-z0-9_$]+)\)\{var [A-Za-z0-9_$]+=this\.views\.findIndex\(([A-Za-z0-9_$]+)=>\4\.webview===\2\.webview\|\|)\3==="main"&&\4\.type==="main"/;
    const fallbackMultiMainRe = /(?<![A-Za-z0-9_$])([A-Za-z0-9_$]+)==="main"&&([A-Za-z0-9_$]+)\.type==="main"/;
    if (registerMultiMainRe.test(baseSource)) {
      baseSource = baseSource.replace(registerMultiMainRe, '$1!1/*antigravity-hub-multi-main*/');
    } else if (fallbackMultiMainRe.test(baseSource)) {
      baseSource = baseSource.replace(fallbackMultiMainRe, '!1/*antigravity-hub-multi-main*/');
    }
  }

  // Keep agy.exe --hub alive across Developer: Reload Window / extension host restarts
  const stopSubRe = /(?<![A-Za-z0-9_$])([A-Za-z0-9_$]+)\.subscriptions\.push\(\{dispose:\(\)=>\{[A-Za-z0-9_$]+\.stop\(\)\}\}\);/;
  if (stopSubRe.test(baseSource)) {
    baseSource = baseSource.replace(
      stopSubRe,
      `$1.subscriptions.push({dispose:()=>{${PERSISTENT_HUB_MARKER}}});`
    );
  }
  const deactivateStopRe = /(?<![A-Za-z0-9_$])[A-Za-z0-9_$]+\.AntigravityServerManager\.getInstance\(\)\.stop\(\)/;
  if (deactivateStopRe.test(baseSource)) {
    baseSource = baseSource.replace(
      deactivateStopRe,
      `Promise.resolve()${PERSISTENT_HUB_MARKER}`
    );
  }

  const attachCallBody = `try{require("./antigravity-hub-bridge.cjs").attach({vscode:require("vscode"),context:${ctxVar},apiImpl:${apiImplVar},provider:${providerVar},renderer:${providerVar}.renderer,naming:${namingVar}})}catch(_bhfErr){console.error("[antigravity-hub-bridge]",_bhfErr)}`;
  const injection = useCommaPrefixInjection
    ? `(()=>{/*${BRIDGE_MARKER}*/${attachCallBody}})(),${attachNeedle}`
    : `/*${BRIDGE_MARKER}*/${attachCallBody}${attachNeedle}`;

  if (baseSource.includes(`/*${BRIDGE_MARKER}*/`)) {
    baseSource = baseSource.replace(
      /(\/\*antigravity-hub-bridge-v1\*\/try\{require\("\.\/antigravity-hub-bridge\.cjs"\)\.attach\(\{vscode:)[A-Za-z0-9_$]+(,context:)/,
      '$1require("vscode")$2'
    );
    if (validateSyntax) {
      new vm.Script(baseSource, { filename: 'extension.js' });
    }
    return baseSource;
  }

  const patched = baseSource.replace(attachNeedle, () => injection);
  if (patched === baseSource) {
    throw new Error('Failed to inject Antigravity Hub bridge into extension.js.');
  }

  // Validate syntax before writing
  if (validateSyntax) {
    new vm.Script(patched, { filename: 'extension.js' });
  }
  return patched;
}

const BRIDGE_STAMP_VERSION = 3;

let _cachedPatchesPath = '';
let _cachedPatchesMtimeMs = 0;
let _cachedPatchesMod = null;

function loadLatestClaudeWebviewPatches(hubExtensionPath = __dirname) {
  const targetRoot = hubExtensionPath || __dirname;
  const patchesPath = path.join(targetRoot, 'compat', 'claude-webview-patches.cjs');
  try {
    if (fs.existsSync(patchesPath)) {
      const mtimeMs = Math.floor(fs.statSync(patchesPath).mtimeMs);
      if (
        !_cachedPatchesMod ||
        _cachedPatchesPath !== patchesPath ||
        _cachedPatchesMtimeMs !== mtimeMs
      ) {
        const resolved = require.resolve(patchesPath);
        delete require.cache[resolved];
        _cachedPatchesMod = require(patchesPath);
        _cachedPatchesPath = patchesPath;
        _cachedPatchesMtimeMs = mtimeMs;
      }
      return _cachedPatchesMod;
    }
  } catch {}
  return {
    CLAUDE_CTX_UI_RUNTIME_JS,
    patchClaudeExtensionSource,
    patchClaudeWebviewSource
  };
}

function getBridgePatchDigest(overrides = {}, hubExtensionPath = __dirname) {
  const latestPatches = loadLatestClaudeWebviewPatches(hubExtensionPath);
  const ctxRuntimeJs =
    typeof overrides?.claudeCtxUiRuntimeJs === 'string'
      ? overrides.claudeCtxUiRuntimeJs
      : latestPatches.CLAUDE_CTX_UI_RUNTIME_JS || CLAUDE_CTX_UI_RUNTIME_JS;
  const extPatchFn = latestPatches.patchClaudeExtensionSource || patchClaudeExtensionSource;
  const wvPatchFn = latestPatches.patchClaudeWebviewSource || patchClaudeWebviewSource;
  return crypto
    .createHash('sha1')
    .update(
      [
        BRIDGE_MARKER,
        PERSISTENT_HUB_MARKER,
        CLAUDE_BRIDGE_MARKER,
        CLAUDE_PIN_MARKER,
        CLAUDE_NOWARN_MARKER,
        CLAUDE_NOBROWSER_MARKER,
        CLAUDE_USAGE_RESET_MARKER,
        CLAUDE_CTX_MARKER,
        CLAUDE_RELOAD_MARKER,
        ctxRuntimeJs,
        // The unsent-text reporter appended to webview/index.js (auto-reload.js): a change re-patches.
        String(latestPatches.CLAUDE_DRAFT_REPORT_JS || ''),
        // The skipped-patch probes: a release that only changes them must re-check every folder, or the
        // stamp keeps reporting an old skip (red-team gate 2026-11-24, Medium).
        JSON.stringify(latestPatches.CLAUDE_OPTIONAL_PATCHES || null),
        String(latestPatches.recordSkippedPatches || ''),
        patchAntigravityExtensionSource.toString(),
        extPatchFn.toString(),
        wvPatchFn.toString()
      ].join('\n')
    )
    .digest('hex')
    .slice(0, 16);
}

function ensureBridgeInstalledForExtensionDir(extensionDir, hubExtensionPath) {
  const bundlePath = path.join(extensionDir, 'extension.js');
  if (!fs.existsSync(bundlePath)) {
    return { installed: false, updated: false, reason: 'missing-bundle', extensionDir, provider: 'antigravity' };
  }
  sweepStaleAtomicTmpFiles([extensionDir]);

  const backupPath = `${bundlePath}.antigravity-hub-original`;
  const stampPath = path.join(extensionDir, '.theo-bridge-stamp.json');
  const bridgePatchDigest = getBridgePatchDigest();

  let filesUpdated = false;
  for (const fileName of BRIDGE_FILE_NAMES) {
    const srcPath = path.join(hubExtensionPath, 'compat', fileName);
    const destPath = path.join(extensionDir, fileName);
    if (!fs.existsSync(srcPath)) {
      continue;
    }
    const srcContent = fs.readFileSync(srcPath, 'utf8');
    const destContent = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
    if (srcContent !== destContent) {
      writeFileAtomicSync(destPath, srcContent, 'utf8');
      filesUpdated = true;
    }
  }

  const destImgDir = path.join(extensionDir, 'img');
  fs.mkdirSync(destImgDir, { recursive: true });
  const hubLogoSrc = path.join(hubExtensionPath, 'resources', 'logo.svg');
  if (fs.existsSync(hubLogoSrc)) {
    const hubLogoContent = fs.readFileSync(hubLogoSrc, 'utf8');
    const origLogoPath = path.join(destImgDir, 'logo.svg');
    const origLogoBak = `${origLogoPath}.antigravity-hub-original`;
    if (fs.existsSync(origLogoPath) && !fs.existsSync(origLogoBak)) {
      fs.copyFileSync(origLogoPath, origLogoBak);
    }
    for (const targetLogoName of ['logo.svg', 'theo-logo.svg']) {
      const targetLogoPath = path.join(destImgDir, targetLogoName);
      const existingContent = fs.existsSync(targetLogoPath) ? fs.readFileSync(targetLogoPath, 'utf8') : '';
      if (existingContent !== hubLogoContent) {
        writeFileAtomicSync(targetLogoPath, hubLogoContent, 'utf8');
        filesUpdated = true;
      }
    }
  }
  for (const iconName of BRIDGE_ICON_FILE_NAMES) {
    const srcPath = path.join(hubExtensionPath, 'resources', iconName);
    const destPath = path.join(destImgDir, iconName);
    if (!fs.existsSync(srcPath)) {
      continue;
    }
    const srcContent = fs.readFileSync(srcPath, 'utf8');
    const destContent = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
    if (srcContent !== destContent) {
      writeFileAtomicSync(destPath, srcContent, 'utf8');
      filesUpdated = true;
    }
  }

  const pkgPath = path.join(extensionDir, 'package.json');
  try {
    if (fs.existsSync(stampPath) && fs.existsSync(backupPath)) {
      const stamp = JSON.parse(fs.readFileSync(stampPath, 'utf8'));
      const bStat = fs.statSync(bundlePath);
      const pStat = fs.existsSync(pkgPath) ? fs.statSync(pkgPath) : { mtimeMs: 0, size: 0 };
      if (
        stamp &&
        stamp.stampVersion === BRIDGE_STAMP_VERSION &&
        stamp.bridgePatchDigest === bridgePatchDigest &&
        stamp.bundleMtimeMs === Math.floor(bStat.mtimeMs) &&
        stamp.bundleSize === bStat.size &&
        stamp.pkgMtimeMs === Math.floor(pStat.mtimeMs) &&
        stamp.pkgSize === pStat.size
      ) {
        return {
          installed: true,
          updated: filesUpdated,
          filesUpdated,
          bundleUpdated: false,
          pkgUpdated: false,
          extensionDir,
          provider: 'antigravity'
        };
      }
    }
  } catch {}

  // Update package.json (customEditor + THEO Activity Bar branding) BEFORE patching extension.js
  // so customEditors and sidebar branding are always preserved even if a future bundle throws.
  let pkgUpdated = false;
  if (fs.existsSync(pkgPath)) {
    try {
      const pkgText = fs.readFileSync(pkgPath, 'utf8');
      const pkgBackupPath = `${pkgPath}.antigravity-hub-original`;
      if (!fs.existsSync(pkgBackupPath)) {
        writeFileAtomicSync(pkgBackupPath, pkgText, 'utf8');
      }
      const pkgData = JSON.parse(pkgText);
      pkgData.contributes = pkgData.contributes || {};
      pkgData.contributes.customEditors = Array.isArray(pkgData.contributes.customEditors)
        ? pkgData.contributes.customEditors
        : [];
      const hasConvEditor = pkgData.contributes.customEditors.some(
        (item) => item && item.viewType === 'antigravity.conversationEditor'
      );
      let needsPkgWrite = false;
      if (!hasConvEditor) {
        pkgData.contributes.customEditors.push({
          viewType: 'antigravity.conversationEditor',
          displayName: 'Antigravity Conversation',
          selector: [
            { filenamePattern: 'antigravity-session:/**/*' },
            { filenamePattern: 'antigravity-session://**' }
          ],
          priority: 'default'
        });
        needsPkgWrite = true;
      }
      const actBar = pkgData.contributes?.viewsContainers?.activitybar;
      if (Array.isArray(actBar)) {
        for (const item of actBar) {
          if (item && item.id === 'antigravity-sidebar') {
            if (item.title !== 'THEO') {
              item.title = 'THEO';
              needsPkgWrite = true;
            }
            if (item.icon !== 'img/theo-logo.svg') {
              item.icon = 'img/theo-logo.svg';
              needsPkgWrite = true;
            }
          }
        }
      }
      const sideViews = pkgData.contributes?.views?.['antigravity-sidebar'];
      if (Array.isArray(sideViews)) {
        for (const item of sideViews) {
          if (item && item.id === 'antigravity.panel' && item.name !== 'THEO') {
            item.name = 'THEO';
            needsPkgWrite = true;
          }
        }
      }
      if (needsPkgWrite) {
        writeFileAtomicSync(pkgPath, JSON.stringify(pkgData, null, 2), 'utf8');
        pkgUpdated = true;
      }
    } catch {}
  }

  const currentText = fs.readFileSync(bundlePath, 'utf8');
  if (!fs.existsSync(backupPath) && !currentText.includes(BRIDGE_MARKER)) {
    writeFileAtomicSync(backupPath, currentText, 'utf8');
  }

  const cleanSource = fs.existsSync(backupPath)
    ? fs.readFileSync(backupPath, 'utf8')
    : currentText;

  const patchedText = patchAntigravityExtensionSource(cleanSource, { validateSyntax: false });
  let bundleUpdated = false;
  if (currentText !== patchedText) {
    new vm.Script(patchedText, { filename: 'extension.js' });
    writeFileAtomicSync(bundlePath, patchedText, 'utf8');
    bundleUpdated = true;
  }

  try {
    const bStat = fs.statSync(bundlePath);
    const pStat = fs.existsSync(pkgPath) ? fs.statSync(pkgPath) : { mtimeMs: 0, size: 0 };
    writeFileAtomicSync(
      stampPath,
      JSON.stringify({
        stampVersion: BRIDGE_STAMP_VERSION,
        bridgePatchDigest,
        bundleMtimeMs: Math.floor(bStat.mtimeMs),
        bundleSize: bStat.size,
        pkgMtimeMs: Math.floor(pStat.mtimeMs),
        pkgSize: pStat.size
      }),
      'utf8'
    );
  } catch {}

  return {
    installed: true,
    updated: filesUpdated || bundleUpdated || pkgUpdated,
    filesUpdated,
    bundleUpdated,
    pkgUpdated,
    extensionDir,
    provider: 'antigravity'
  };
}

function ensureClaudeBridgeInstalledForExtensionDir(extensionDir, hubExtensionPath) {
  const bundlePath = path.join(extensionDir, 'extension.js');
  if (!fs.existsSync(bundlePath)) {
    return { installed: false, updated: false, reason: 'missing-bundle', extensionDir, provider: 'claude' };
  }
  sweepStaleAtomicTmpFiles([extensionDir, path.join(extensionDir, 'webview')]);

  // Compatible with ~/.claude/hooks/claude-panel-pin.sh which uses .orig backups
  const backupPath = `${bundlePath}.orig`;
  const webviewPath = path.join(extensionDir, 'webview', 'index.js');
  const stampPath = path.join(extensionDir, '.theo-bridge-stamp.json');
  const latestPatches = loadLatestClaudeWebviewPatches(hubExtensionPath);
  const bridgePatchDigest = getBridgePatchDigest({}, hubExtensionPath);

  let filesUpdated = false;
  for (const fileName of CLAUDE_BRIDGE_FILE_NAMES) {
    const srcPath = path.join(hubExtensionPath, 'compat', fileName);
    const destPath = path.join(extensionDir, fileName);
    if (!fs.existsSync(srcPath)) {
      continue;
    }
    const srcContent = fs.readFileSync(srcPath, 'utf8');
    const destContent = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
    if (srcContent !== destContent) {
      writeFileAtomicSync(destPath, srcContent, 'utf8');
      filesUpdated = true;
    }
  }

  const destResDir = path.join(extensionDir, 'resources');
  fs.mkdirSync(destResDir, { recursive: true });
  for (const iconName of CLAUDE_ICON_FILE_NAMES) {
    const srcPath = path.join(hubExtensionPath, 'resources', iconName);
    const destPath = path.join(destResDir, iconName);
    if (!fs.existsSync(srcPath)) {
      continue;
    }
    const srcContent = fs.readFileSync(srcPath, 'utf8');
    const destContent = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
    if (srcContent !== destContent) {
      writeFileAtomicSync(destPath, srcContent, 'utf8');
      filesUpdated = true;
    }
  }

  const pkgPath = path.join(extensionDir, 'package.json');
  try {
    if (fs.existsSync(stampPath) && fs.existsSync(backupPath)) {
      const stamp = JSON.parse(fs.readFileSync(stampPath, 'utf8'));
      const bStat = fs.statSync(bundlePath);
      const wStat = fs.existsSync(webviewPath) ? fs.statSync(webviewPath) : { mtimeMs: 0, size: 0 };
      const pStat = fs.existsSync(pkgPath) ? fs.statSync(pkgPath) : { mtimeMs: 0, size: 0 };
      if (
        stamp &&
        stamp.stampVersion === BRIDGE_STAMP_VERSION &&
        stamp.bridgePatchDigest === bridgePatchDigest &&
        stamp.bundleMtimeMs === Math.floor(bStat.mtimeMs) &&
        stamp.bundleSize === bStat.size &&
        stamp.webviewMtimeMs === Math.floor(wStat.mtimeMs) &&
        stamp.webviewSize === wStat.size &&
        stamp.pkgMtimeMs === Math.floor(pStat.mtimeMs) &&
        stamp.pkgSize === pStat.size
      ) {
        return {
          installed: true,
          updated: filesUpdated,
          filesUpdated,
          bundleUpdated: false,
          webviewUpdated: false,
          pkgUpdated: false,
          skippedPatches: cleanSkippedPatches(stamp.skippedPatches),
          extensionDir,
          provider: 'claude'
        };
      }
    }
  } catch {}

  // Strip "onStartupFinished" from Claude Code's package.json activationEvents so VS Code never
  // auto-activates anthropic.claude-code on startup when 0 Claude accounts are signed in (while
  // keeping "onWebviewPanel:claudeVSCodePanel" and on-demand activation when signed in).
  let pkgUpdated = false;
  if (fs.existsSync(pkgPath)) {
    try {
      const pkgText = fs.readFileSync(pkgPath, 'utf8');
      const pkgBackupPath = `${pkgPath}.orig`;
      if (!fs.existsSync(pkgBackupPath)) {
        writeFileAtomicSync(pkgBackupPath, pkgText, 'utf8');
      }
      const pkgData = JSON.parse(pkgText);
      if (
        Array.isArray(pkgData.activationEvents) &&
        pkgData.activationEvents.includes('onStartupFinished')
      ) {
        pkgData.activationEvents = pkgData.activationEvents.filter(
          (ev) => ev !== 'onStartupFinished'
        );
        writeFileAtomicSync(pkgPath, JSON.stringify(pkgData, null, 2), 'utf8');
        pkgUpdated = true;
      }
    } catch {}
  }

  const currentText = fs.readFileSync(bundlePath, 'utf8');
  if (
    !fs.existsSync(backupPath) &&
    !currentText.includes(CLAUDE_PIN_MARKER) &&
    !currentText.includes(CLAUDE_RELOAD_MARKER) &&
    !currentText.includes(`/*${CLAUDE_BRIDGE_MARKER}*/`)
  ) {
    writeFileAtomicSync(backupPath, currentText, 'utf8');
  }

  const cleanSource = fs.existsSync(backupPath)
    ? fs.readFileSync(backupPath, 'utf8')
    : currentText;

  const extPatchFn = latestPatches.patchClaudeExtensionSource || patchClaudeExtensionSource;
  const wvPatchFn = latestPatches.patchClaudeWebviewSource || patchClaudeWebviewSource;
  // Optional patches the upstream bundle no longer fits are left out; their ids land here (sidebar notice).
  const skippedPatches = [];
  const patchedExtText = extPatchFn(cleanSource, { validateSyntax: false, skipped: skippedPatches });
  let bundleUpdated = false;
  if (currentText !== patchedExtText) {
    new vm.Script(patchedExtText, { filename: 'claude-extension.js' });
    writeFileAtomicSync(bundlePath, patchedExtText, 'utf8');
    bundleUpdated = true;
  }

  // Also patch webview/index.js (usage banner, browser banner, context window pill)
  let webviewUpdated = false;
  if (fs.existsSync(webviewPath)) {
    const webviewBackupPath = `${webviewPath}.orig`;
    const currentWebview = fs.readFileSync(webviewPath, 'utf8');
    if (
      !fs.existsSync(webviewBackupPath) &&
      !currentWebview.includes(CLAUDE_NOWARN_MARKER) &&
      !currentWebview.includes(CLAUDE_NOBROWSER_MARKER) &&
      !currentWebview.includes(CLAUDE_USAGE_RESET_MARKER) &&
      !currentWebview.includes(CLAUDE_CTX_MARKER) &&
      !currentWebview.includes(CLAUDE_RELOAD_MARKER) &&
      !currentWebview.includes('/*bhf-draft-api*/')
    ) {
      writeFileAtomicSync(webviewBackupPath, currentWebview, 'utf8');
    }
    const cleanWebview = fs.existsSync(webviewBackupPath)
      ? fs.readFileSync(webviewBackupPath, 'utf8')
      : currentWebview;
    const patchedWebview = wvPatchFn(cleanWebview, { validateSyntax: false, skipped: skippedPatches });
    if (currentWebview !== patchedWebview) {
      // Module-aware: 2.1.331 ships webview/index.js as an ES module, which a bare vm.Script rejects.
      const assertWebviewSyntax =
        latestPatches.assertClaudeWebviewSyntax || assertClaudeWebviewSyntax;
      assertWebviewSyntax(patchedWebview, 'claude-webview-index.js');
      writeFileAtomicSync(webviewPath, patchedWebview, 'utf8');
      webviewUpdated = true;
    }
  }

  try {
    const bStat = fs.statSync(bundlePath);
    const wStat = fs.existsSync(webviewPath) ? fs.statSync(webviewPath) : { mtimeMs: 0, size: 0 };
    const pStat = fs.existsSync(pkgPath) ? fs.statSync(pkgPath) : { mtimeMs: 0, size: 0 };
    writeFileAtomicSync(
      stampPath,
      JSON.stringify({
        stampVersion: BRIDGE_STAMP_VERSION,
        bridgePatchDigest,
        bundleMtimeMs: Math.floor(bStat.mtimeMs),
        bundleSize: bStat.size,
        webviewMtimeMs: Math.floor(wStat.mtimeMs),
        webviewSize: wStat.size,
        pkgMtimeMs: Math.floor(pStat.mtimeMs),
        pkgSize: pStat.size,
        // Kept so a pass that finds the folder unchanged still reports what was left out.
        skippedPatches: cleanSkippedPatches(skippedPatches)
      }),
      'utf8'
    );
  } catch {}

  return {
    installed: true,
    updated: filesUpdated || bundleUpdated || webviewUpdated || pkgUpdated,
    filesUpdated,
    bundleUpdated,
    webviewUpdated,
    pkgUpdated,
    skippedPatches: cleanSkippedPatches(skippedPatches),
    extensionDir,
    provider: 'claude'
  };
}

function safeStatMtimeMs(targetPath) {
  try {
    return Math.floor(fs.statSync(targetPath).mtimeMs);
  } catch {
    return 0;
  }
}

let _lastPrepatchSig = '';

function prepatchInstalledExtensions(hubExtensionPath = __dirname, options = {}) {
  const extensionsDir = options.extensionsDir || getDefaultExtensionsDir();
  if (!fs.existsSync(extensionsDir)) {
    return { checked: false, skipped: true, updatedDirs: [], reports: [], errors: [] };
  }
  const hubRoot = hubExtensionPath || __dirname;
  const dirMtime = safeStatMtimeMs(extensionsDir);
  const extJsonMtime = safeStatMtimeMs(path.join(extensionsDir, 'extensions.json'));
  const hubBridgeMtime = Math.max(
    safeStatMtimeMs(__filename),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'claude-webview-patches.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'antigravity-hub-bridge.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'antigravity-context-window.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'claude-hub-bridge.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'excel-preview.cjs'))
  );
  const sig = `${path.resolve(extensionsDir)}|${dirMtime}|${extJsonMtime}|${hubBridgeMtime}`;
  if (!options.force && _lastPrepatchSig === sig) {
    return { checked: false, skipped: true, updatedDirs: [], reports: [], errors: [] };
  }

  const agyTargets = findInstalledAntigravityExtensions(extensionsDir, null);
  const claudeTargets = findInstalledClaudeExtensions(extensionsDir, null);
  const reports = [];
  const updatedDirs = [];
  const errors = [];
  let sawTransientIncomplete = false;

  for (const dir of agyTargets) {
    try {
      const res = ensureBridgeInstalledForExtensionDir(dir, hubRoot);
      reports.push(res);
      if (res.reason === 'missing-bundle') {
        sawTransientIncomplete = true;
      } else if (res.updated) {
        updatedDirs.push(dir);
      }
    } catch (error) {
      const code = String(error?.code || '');
      if (code === 'EBUSY' || code === 'EPERM' || code === 'ENOENT') {
        sawTransientIncomplete = true;
      }
      const errObj = {
        installed: false,
        updated: false,
        extensionDir: dir,
        provider: 'antigravity',
        error: error?.message || String(error)
      };
      reports.push(errObj);
      errors.push(errObj);
    }
  }

  for (const dir of claudeTargets) {
    try {
      const res = ensureClaudeBridgeInstalledForExtensionDir(dir, hubRoot);
      reports.push(res);
      if (res.reason === 'missing-bundle') {
        sawTransientIncomplete = true;
      } else if (res.updated) {
        updatedDirs.push(dir);
      }
    } catch (error) {
      const code = String(error?.code || '');
      if (code === 'EBUSY' || code === 'EPERM' || code === 'ENOENT') {
        sawTransientIncomplete = true;
      }
      const errObj = {
        installed: false,
        updated: false,
        extensionDir: dir,
        provider: 'claude',
        error: error?.message || String(error)
      };
      reports.push(errObj);
      errors.push(errObj);
    }
  }

  if (!sawTransientIncomplete && errors.length === 0) {
    _lastPrepatchSig = sig;
  }

  return {
    checked: true,
    skipped: false,
    updatedDirs,
    reports,
    errors
  };
}

// ---- Bundle patching off the Extension Host thread (2026-11-12) ----
// Patching reads, rewrites and writes 4 to 12 MB bundles. On 2026-11-12 four quadratic regexes made one
// Antigravity update freeze the Extension Host for 17.8 s. The regexes are linear now, but any future upstream
// bundle shape could slow a pattern again, so every Extension Host caller patches in a worker thread: the
// sidebar, tabs and streaming stay live whatever the patch costs. The worker loads this same file
// (`isTheoBridgePatchWorker`), runs the jobs and posts plain report objects back.
const BRIDGE_PATCH_WORKER_TIMEOUT_MS = 120000;
const TRANSIENT_PATCH_ERROR_CODES = new Set(['EBUSY', 'EPERM', 'ENOENT', 'ETIMEDOUT', 'EWORKER']);

// ---- A folder that can never be written (2026-11-20) ----
// EPERM and EBUSY mean "locked right now" (antivirus, VS Code still unpacking) far more often than "never
// writable", so one such error stays silent and is retried. A read-only install or a denied folder fails
// the same way on every pass, though, and used to stay silent for good. The streak of write-blocked passes
// per extension folder is counted here; once it is both long enough and old enough the report is flagged
// `writeBlockPersistent` and is treated as a real failure (warning + sidebar notice), still retried.
// The streak lives in BRIDGE_WORKER_STATE so a hot-swapped copy of this module continues it.
const WRITE_BLOCK_ERROR_CODES = new Set(['EPERM', 'EACCES', 'EBUSY', 'EROFS']);
const WRITE_BLOCK_PERSIST_MIN_ATTEMPTS = 3;
const WRITE_BLOCK_PERSIST_MIN_MS = 45 * 1000;
// A pause this long between passes (sleep, a suspended host) starts a new streak: the old one says
// nothing about the folder now.
const WRITE_BLOCK_STREAK_GAP_MS = 5 * 60 * 1000;
const WRITE_BLOCK_PERSISTENT_KEEP_MS = 24 * 60 * 60 * 1000;

function trackPersistentWriteBlocks(reports, now = Date.now()) {
  if (!Array.isArray(reports)) return reports;
  const state = BRIDGE_WORKER_STATE;
  if (!state.writeBlocks) state.writeBlocks = {};
  const streaks = state.writeBlocks;
  for (const key of Object.keys(streaks)) {
    // A streak that already counts as a failure outlives a pause: it ends only when a pass gets through,
    // so the notice does not vanish for a minute each time the PC wakes. One left alone for a day belongs
    // to a folder nobody patches any more.
    const idleMs = now - Number(streaks[key]?.lastAt || 0);
    if (idleMs > (streaks[key]?.persistent ? WRITE_BLOCK_PERSISTENT_KEEP_MS : WRITE_BLOCK_STREAK_GAP_MS)) {
      delete streaks[key];
    }
  }
  return reports.map((r) => {
    if (!r || !r.extensionDir) return r;
    const key = `${r.provider}|${path.resolve(String(r.extensionDir)).toLowerCase()}`;
    const code = String(r.code || '');
    if (r.error && WRITE_BLOCK_ERROR_CODES.has(code)) {
      const streak = streaks[key] || { firstAt: now, attempts: 0, persistent: false };
      streak.attempts += 1;
      streak.lastAt = now;
      if (streak.attempts >= WRITE_BLOCK_PERSIST_MIN_ATTEMPTS && now - streak.firstAt >= WRITE_BLOCK_PERSIST_MIN_MS) {
        streak.persistent = true;
      }
      streaks[key] = streak;
      return { ...r, writeBlockedSince: streak.firstAt, writeBlockPersistent: streak.persistent === true };
    }
    // A worker that timed out or crashed never reached the folder: it neither extends nor ends a streak.
    if (!(r.error && (code === 'ETIMEDOUT' || code === 'EWORKER'))) {
      delete streaks[key];
    }
    return r;
  });
}

// True for a patch failure that is reported to the user; false for one that is only retried.
function isHardPatchError(report) {
  if (!report?.error) return false;
  return !TRANSIENT_PATCH_ERROR_CODES.has(String(report.code || '')) || report.writeBlockPersistent === true;
}

// 'unwritable' = THEO could not write the folder; 'incompatible' = the bundle no longer has what the patch
// anchors on. They need different words: only the second one is fixed by a THEO update.
function patchFailureKind(report) {
  return WRITE_BLOCK_ERROR_CODES.has(String(report?.code || '')) ? 'unwritable' : 'incompatible';
}

// One string for the set of reported failures in a pass, so a caller can tell when that set changed.
// Skipped optional patches count too: a Claude Code update that drops one mid-session must rebuild the
// sidebar notice through the same periodic re-check (createBridgeRecheck), not wait for a window reload.
function getHardFailureSig(reports) {
  const list = Array.isArray(reports) ? reports : [];
  const failures = list
    .filter(isHardPatchError)
    .map((r) => `${r.provider}:${path.basename(String(r.extensionDir || ''))}:${patchFailureKind(r)}`);
  const skips = list
    .filter((r) => r && !r.error && cleanSkippedPatches(r.skippedPatches).length > 0)
    .map((r) => `${r.provider}:${path.basename(String(r.extensionDir || ''))}:skipped:${cleanSkippedPatches(r.skippedPatches).join(',')}`);
  return [...failures, ...skips].sort().join('|');
}

// Plain, serialisable description of skipped optional patches on one extension folder (sidebar notice).
function describePatchSkip(report) {
  const dirName = path.basename(String(report?.extensionDir || ''));
  const m = dirName.match(/-(\d+\.\d+\.\d+)(?:-|$)/);
  const provider = report?.provider === 'claude' ? 'claude' : 'antigravity';
  const ids = cleanSkippedPatches(report?.skippedPatches);
  return {
    provider,
    label: provider === 'claude' ? 'Claude Code' : 'Antigravity',
    version: m ? m[1] : '',
    patches: ids,
    names: ids.map((id) => (CLAUDE_PATCH_NAMES && CLAUDE_PATCH_NAMES[id]) || id)
  };
}

// For the periodic maintenance pass: did the set of reported failures change since the last pass seen?
// `prevSig` is null before the first pass, and then the hub's stored install report is the baseline.
function prepatchFailuresChanged(prevSig, res, storedReport) {
  if (!res || res.checked !== true || typeof res.hardFailureSig !== 'string') {
    return { changed: false, sig: prevSig };
  }
  // A pass whose worker timed out or crashed never reached some folders: its signature lacks their skips and
  // failures for that pass only, so it says nothing new (otherwise one slow pass re-checks twice).
  if (
    Array.isArray(res.reports) &&
    res.reports.some((r) => r && r.error && (r.code === 'ETIMEDOUT' || r.code === 'EWORKER'))
  ) {
    return { changed: false, sig: prevSig };
  }
  const baseline = prevSig === null || prevSig === undefined ? String(storedReport?.hardFailureSig || '') : prevSig;
  return { changed: res.hardFailureSig !== baseline, sig: res.hardFailureSig };
}

// The re-check a window runs after each periodic maintenance pass. The pass patches silently; when the set
// of failures it reports changes (a folder that stayed write-blocked long enough to count as a failure, or
// one that became writable again), the install report behind the sidebar notice is rebuilt, with the
// warning or reload prompt it calls for. Returns a function taking the pass result; it resolves when the
// re-check it started (if any) is done.
//   ensure(opts)      -> Promise<install report> (ensureAntigravityBridgeInstalled bound to the window)
//   setReport(report) -> stores the report the sidebar reads;  refresh() -> redraws the sidebar
//   getStoredReport() -> the report currently stored;          isEnabled() -> false = leave everything as is
function createBridgeRecheck({ ensure, setReport, refresh, getStoredReport, isEnabled }) {
  let lastSig = null;
  let inFlight = false;
  let latestRun = 0;
  return function recheckAfterPrepatch(res) {
    const verdict = prepatchFailuresChanged(lastSig, res, typeof getStoredReport === 'function' ? getStoredReport() : null);
    if (!verdict.changed) {
      lastSig = verdict.sig;
      return Promise.resolve(false);
    }
    // A change seen while a re-check runs, or while maintenance is switched off, is not marked as seen:
    // the next pass acts on it.
    if (inFlight || (typeof isEnabled === 'function' && !isEnabled())) {
      return Promise.resolve(false);
    }
    lastSig = verdict.sig;
    inFlight = true;
    const run = ++latestRun;
    // The sidebar is updated first: with promptReload the call waits for the reload toast to be answered.
    return Promise.resolve()
      .then(() => ensure({ promptReload: false }))
      .then(
        (report) => {
          inFlight = false;
          setReport(report);
          if (typeof refresh === 'function') refresh();
          if (report?.needsReload || (Array.isArray(report?.patchFailures) && report.patchFailures.length > 0)) {
            // A toast answered late must not put its older report over a newer re-check's.
            return ensure({ promptReload: true }).then((prompted) => {
              if (run === latestRun) setReport(prompted);
              return true;
            });
          }
          return true;
        },
        () => {
          // Not delivered: the stored report is the baseline again, so the next pass tries once more.
          inFlight = false;
          lastSig = null;
          return false;
        }
      )
      .catch(() => false);
  };
}

function runBridgeJobsSync(jobs, hubRoot) {
  return (Array.isArray(jobs) ? jobs : []).map(({ provider, dir }) => {
    try {
      return provider === 'claude'
        ? ensureClaudeBridgeInstalledForExtensionDir(dir, hubRoot)
        : ensureBridgeInstalledForExtensionDir(dir, hubRoot);
    } catch (error) {
      return {
        installed: false,
        updated: false,
        extensionDir: dir,
        provider,
        error: error?.message || String(error),
        code: String(error?.code || '')
      };
    }
  });
}

// One worker at a time per process: each run queues behind the previous worker's exit (not its answer), so
// two workers never write the same bundle at once, even after a caller stopped waiting (timeout) or after a
// hot swap re-required this module (the queue lives in BRIDGE_WORKER_STATE). A worker that never exits
// releases the queue after BRIDGE_PATCH_WORKER_QUEUE_RELEASE_MS.
const BRIDGE_PATCH_WORKER_QUEUE_RELEASE_MS = 10 * 60 * 1000;
// After a worker fails once it started, patch in-thread for this long before trying a worker again.
const BRIDGE_WORKER_RETRY_AFTER_FAILURE_MS = 10 * 60 * 1000;

// True while a patch run is queued or its worker is still alive (the daemon waits for it before respawning).
function isBridgePatchWorkerBusy() {
  return BRIDGE_WORKER_STATE.pending > 0;
}

function runBridgeJobsInWorker(jobs, hubRoot, options = {}) {
  const list = Array.isArray(jobs) ? jobs.filter((j) => j && j.dir) : [];
  if (list.length === 0) {
    return Promise.resolve([]);
  }
  const state = BRIDGE_WORKER_STATE;
  state.pending += 1;
  const run = state.tail.then(() => startBridgeWorkerRun(list, hubRoot, options));
  const done = run
    .then((r) => r.exited)
    .catch(() => {})
    .then(() => {
      state.pending = Math.max(0, state.pending - 1);
    });
  state.tail = done;
  return run.then((r) => r.answer).then((reports) => trackPersistentWriteBlocks(reports));
}

// Returns { answer: Promise<reports>, exited: Promise<void> }.
function startBridgeWorkerRun(list, hubRoot, options = {}) {
  const failAll = (message, code) =>
    list.map(({ provider, dir }) => ({
      installed: false,
      updated: false,
      extensionDir: dir,
      provider,
      error: message,
      code
    }));
  const inThread = () => ({ answer: Promise.resolve(runBridgeJobsSync(list, hubRoot)), exited: Promise.resolve() });
  let WorkerCtor = null;
  try {
    WorkerCtor = require('worker_threads').Worker;
  } catch {}
  if (
    !WorkerCtor ||
    options.inThread === true ||
    process.env.THEO_BRIDGE_PATCH_IN_THREAD === '1' ||
    BRIDGE_WORKER_STATE.workerUnavailable ||
    Date.now() < Number(BRIDGE_WORKER_STATE.workerUnavailableUntil || 0)
  ) {
    return inThread();
  }
  let worker = null;
  try {
    worker = new WorkerCtor(__filename, {
      workerData: { isTheoBridgePatchWorker: true, jobs: list, hubRoot }
    });
  } catch {
    // No worker available in this runtime: patching in-thread beats not patching.
    BRIDGE_WORKER_STATE.workerUnavailable = true;
    return inThread();
  }
  // The worker and its answer timer stay referenced: a standalone Node process (daemon, tests) must not exit
  // while a patch is half done or before its answer arrives.
  const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : BRIDGE_PATCH_WORKER_TIMEOUT_MS;
  let workerExited = false;
  const exited = new Promise((resolveExit) => {
    const release = setTimeout(resolveExit, BRIDGE_PATCH_WORKER_QUEUE_RELEASE_MS);
    if (typeof release.unref === 'function') release.unref();
    worker.once('exit', () => {
      workerExited = true;
      clearTimeout(release);
      resolveExit();
    });
  });
  const answer = new Promise((resolve) => {
    let answered = false;
    let gotMessage = false;
    const finish = (reports) => {
      if (answered) return;
      answered = true;
      clearTimeout(timer);
      resolve(reports);
    };
    // The worker could not start or run (init failure, out of memory, or a bridge.js without the worker
    // entry, which exits without a message): patch in-thread once, once its exit guarantees no other writer,
    // and stop trying workers in this process.
    const fallBack = () => {
      if (answered || gotMessage) return;
      // Possibly transient (a half-written bridge.js, one out-of-memory): in-thread for 10 minutes, then retry.
      BRIDGE_WORKER_STATE.workerUnavailableUntil = Date.now() + BRIDGE_WORKER_RETRY_AFTER_FAILURE_MS;
      const runSync = () => {
        if (answered) return;
        try {
          finish(runBridgeJobsSync(list, hubRoot).map((r) => ({ ...r, workerFallback: true })));
        } catch (error) {
          finish(failAll(`bridge patch failed: ${error?.message || error}`, 'EWORKER'));
        }
      };
      if (workerExited) runSync();
      else exited.then(runSync);
    };
    // A timed-out worker is left to finish (terminating it mid-write could truncate a bundle).
    const timer = setTimeout(
      () => finish(failAll(`bridge patch worker still running after ${timeoutMs} ms`, 'ETIMEDOUT')),
      timeoutMs
    );
    worker.once('message', (msg) => {
      gotMessage = true;
      finish(
        Array.isArray(msg?.reports)
          ? msg.reports.map((r) => ({ ...r, viaWorker: true }))
          : failAll('bridge patch worker sent no reports', 'EWORKER')
      );
    });
    worker.once('error', fallBack);
    worker.once('exit', fallBack);
  });
  return { answer, exited };
}

// Same contract as prepatchInstalledExtensions, but the patching runs in a worker thread. The cheap change
// check (a few stat calls) stays here so an unchanged extensions folder never starts a worker. The last good
// signature and the in-flight flag live in BRIDGE_WORKER_STATE, so a hot-swapped copy of this module neither
// repeats a finished run nor starts one beside a running one.
async function prepatchInstalledExtensionsAsync(hubExtensionPath = __dirname, options = {}) {
  const skipped = { checked: false, skipped: true, updatedDirs: [], reports: [], errors: [] };
  const extensionsDir = options.extensionsDir || getDefaultExtensionsDir();
  // `extraDirs` ([{ provider, dir }]): folders outside extensionsDir that must be maintained too. A window
  // passes the extensions it has loaded, which live elsewhere in the Antigravity IDE, VS Code Insiders or
  // a portable VS Code; without them a write block there was only ever seen at start-up (2026-11-20).
  const extraJobs = (Array.isArray(options.extraDirs) ? options.extraDirs : [])
    .filter((j) => j && typeof j.dir === 'string' && j.dir && (j.provider === 'claude' || j.provider === 'antigravity'))
    .map((j) => ({ provider: j.provider, dir: path.resolve(j.dir) }))
    .filter((j) => fs.existsSync(j.dir));
  const hasExtensionsDir = fs.existsSync(extensionsDir);
  if (!hasExtensionsDir && extraJobs.length === 0) {
    return skipped;
  }
  const state = BRIDGE_WORKER_STATE;
  const hubRoot = hubExtensionPath || __dirname;
  const hubBridgeMtime = Math.max(
    safeStatMtimeMs(__filename),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'claude-webview-patches.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'antigravity-hub-bridge.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'antigravity-context-window.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'claude-hub-bridge.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'excel-preview.cjs'))
  );
  const sig = `${path.resolve(extensionsDir)}|${safeStatMtimeMs(extensionsDir)}|${safeStatMtimeMs(
    path.join(extensionsDir, 'extensions.json')
  )}|${hubBridgeMtime}${extraJobs.map((j) => `|${j.provider}:${j.dir}:${getBundleStatSignature(j.dir)}`).join('')}`;
  if (!state.lastPrepatchSigs) state.lastPrepatchSigs = {};
  const sigKey = path.resolve(extensionsDir);
  if ((!options.force && state.lastPrepatchSigs[sigKey] === sig) || state.prepatchInFlight) {
    return skipped;
  }
  state.prepatchInFlight = true;
  try {
    const jobs = hasExtensionsDir
      ? [
          ...findInstalledAntigravityExtensions(extensionsDir, null).map((dir) => ({ provider: 'antigravity', dir })),
          ...findInstalledClaudeExtensions(extensionsDir, null).map((dir) => ({ provider: 'claude', dir }))
        ]
      : [];
    const seenDirs = new Set(jobs.map((j) => path.resolve(j.dir).toLowerCase()));
    for (const extra of extraJobs) {
      if (!seenDirs.has(extra.dir.toLowerCase())) {
        seenDirs.add(extra.dir.toLowerCase());
        jobs.push(extra);
      }
    }
    const reports = await runBridgeJobsInWorker(jobs, hubRoot, options);
    const updatedDirs = [];
    const errors = [];
    let sawTransientIncomplete = false;
    for (const res of reports) {
      if (res.reason === 'missing-bundle') {
        sawTransientIncomplete = true;
      } else if (res.error) {
        errors.push(res);
        if (TRANSIENT_PATCH_ERROR_CODES.has(String(res.code || ''))) {
          sawTransientIncomplete = true;
        }
      } else if (res.updated) {
        updatedDirs.push(res.extensionDir);
      }
    }
    if (!sawTransientIncomplete && errors.length === 0) {
      state.lastPrepatchSigs[sigKey] = sig;
    }
    return { checked: true, skipped: false, updatedDirs, reports, errors, hardFailureSig: getHardFailureSig(reports) };
  } finally {
    state.prepatchInFlight = false;
  }
}

async function queryActiveBridgeStatus(vscodeApi = vscode) {
  let agyStatus = { active: false };
  let claudeStatus = { active: false };
  try {
    const res = await vscodeApi?.commands?.executeCommand?.('antigravityHub.bridgeStatus');
    if (res && res.active) {
      agyStatus = res;
    }
  } catch {}
  try {
    const res = await vscodeApi?.commands?.executeCommand?.('antigravityHub.claudeBridgeStatus');
    if (res && res.active) {
      claudeStatus = res;
    }
  } catch {}
  return {
    active: Boolean(agyStatus.active || claudeStatus.active),
    antigravityActive: Boolean(agyStatus.active),
    claudeActive: Boolean(claudeStatus.active),
    antigravity: agyStatus,
    claude: claudeStatus
  };
}

function getBundleStatSignature(extensionDir) {
  if (!extensionDir) {
    return 'none';
  }
  const bPath = path.join(extensionDir, 'extension.js');
  const pPath = path.join(extensionDir, 'package.json');
  return `${safeStatMtimeMs(bPath)}:${safeStatMtimeMs(pPath)}`;
}

function isClaudeAccountSignedIn(options = {}) {
  if (typeof options.claudeSignedIn === 'boolean') {
    return options.claudeSignedIn;
  }
  const hasExplicitVaultOpts = Boolean(options.vaultPath || options.claudeHomeDir);
  if (!options.isRealHostRun && !hasExplicitVaultOpts) {
    return true;
  }
  try {
    const claudeHome = options.claudeHomeDir || path.join(os.homedir(), '.claude');
    const vaultFile = options.vaultPath || path.join(claudeHome, '.theo-accounts-vault.json');
    if (fs.existsSync(vaultFile)) {
      const vault = JSON.parse(fs.readFileSync(vaultFile, 'utf8'));
      const claudeList = Array.isArray(vault?.accounts?.claude)
        ? vault.accounts.claude.filter(
            (a) => a && typeof a.email === 'string' && a.email.includes('@')
          )
        : [];
      if (claudeList.length > 0) {
        return true;
      }
      if (vault?.signedOut?.claude) {
        return false;
      }
    }
    const credsFile = path.join(claudeHome, '.credentials.json');
    if (fs.existsSync(credsFile)) {
      const creds = JSON.parse(fs.readFileSync(credsFile, 'utf8'));
      if (creds?.claudeAiOauth?.accessToken) {
        return true;
      }
    }
    return false;
  } catch {
    return true;
  }
}

// Plain, serialisable description of a failed bundle patch for the warning toast and the sidebar card.
function describePatchFailure(report) {
  const dirName = path.basename(String(report?.extensionDir || ''));
  const m = dirName.match(/-(\d+\.\d+\.\d+)(?:-|$)/);
  const provider = report?.provider === 'claude' ? 'claude' : 'antigravity';
  return {
    provider,
    label: provider === 'claude' ? 'Claude Code' : 'Antigravity',
    version: m ? m[1] : '',
    kind: patchFailureKind(report),
    error: String(report?.error || '').slice(0, 240)
  };
}

async function ensureAntigravityBridgeInstalled(context, options = {}) {
  const vscodeApi = options.vscodeApi || vscode;
  const hubExtensionPath = context?.extensionPath || __dirname;
  const agyTargets = Array.isArray(options.agyTargets)
    ? options.agyTargets
    : findInstalledAntigravityExtensions(options.extensionsDir, vscodeApi);
  const claudeTargets = Array.isArray(options.claudeTargets)
    ? options.claudeTargets
    : findInstalledClaudeExtensions(options.extensionsDir, vscodeApi);
  // Patched in a worker thread (see runBridgeJobsInWorker); `patchInThread: true` keeps the old in-thread path.
  const reports = await runBridgeJobsInWorker(
    [
      ...agyTargets.map((dir) => ({ provider: 'antigravity', dir })),
      ...claudeTargets.map((dir) => ({ provider: 'claude', dir }))
    ],
    hubExtensionPath,
    { inThread: options.patchInThread === true }
  );

  const liveStatus = await queryActiveBridgeStatus(vscodeApi);
  const hasExtensionsApi = typeof vscodeApi?.extensions?.getExtension === 'function';
  const activeAgyExt = hasExtensionsApi
    ? vscodeApi.extensions.getExtension('google.google-antigravity') || null
    : null;
  const activeClaudeExt = hasExtensionsApi
    ? vscodeApi.extensions.getExtension('anthropic.claude-code') || null
    : null;

  // Match the extension version actually loaded in THIS VS Code window (falling back to highest version
  // when running standalone or before discovery). Background-downloaded future versions are silently
  // pre-patched above without prompting a reload in a window that is still running the active version.
  const activeAgyDir = activeAgyExt?.extensionPath || agyTargets[0] || '';
  const activeClaudeDir = activeClaudeExt?.extensionPath || claudeTargets[0] || '';
  const activeAgyReport = activeAgyDir
    ? reports.find(
        (item) =>
          item.provider === 'antigravity' &&
          path.resolve(item.extensionDir) === path.resolve(activeAgyDir)
      )
    : null;
  const activeClaudeReport = activeClaudeDir
    ? reports.find(
        (item) =>
          item.provider === 'claude' &&
          path.resolve(item.extensionDir) === path.resolve(activeClaudeDir)
      )
    : null;

  // Only Extension Host bundle / package.json changes require a window reload;
  // webview/index.js is read per-panel from disk and compat/*.cjs hot-swaps in memory.
  const agyHostUpdated = Boolean(activeAgyReport?.bundleUpdated || activeAgyReport?.pkgUpdated);
  const claudeHostUpdated = Boolean(
    activeClaudeReport?.bundleUpdated || activeClaudeReport?.pkgUpdated
  );

  // Never misdiagnose a not-yet-activated extension (!ext.isActive) as an unpatched loaded bundle!
  const agyLoadedUnpatched = Boolean(
    activeAgyReport?.installed &&
      !liveStatus.antigravityActive &&
      (!hasExtensionsApi || (activeAgyExt && activeAgyExt.isActive))
  );
  const claudeLoadedUnpatched = Boolean(
    activeClaudeReport?.installed &&
      !liveStatus.claudeActive &&
      (!hasExtensionsApi || (activeClaudeExt && activeClaudeExt.isActive))
  );

  const isRealHostRun =
    !options.extensionsDir &&
    !options.agyTargets &&
    !options.claudeTargets &&
    vscodeApi === vscode;
  const claudeSignedIn = isClaudeAccountSignedIn({ ...options, isRealHostRun });

  // A patch that threw leaves extension.js unpatched however often the window reloads, so a hard failure
  // on the loaded version never asks for a reload; it is reported as a failure (warning + sidebar notice
  // + "Update needed" pill) instead of the old "Reload needed" pill (Claude Code 2.1.327, 2026-11-18).
  // Locked files, a crashed worker or a timeout are temporary: they are retried, not reported. A folder
  // that stays write-blocked pass after pass is reported too (isHardPatchError, trackPersistentWriteBlocks).
  const agyPatchFailed = isHardPatchError(activeAgyReport);
  const claudePatchFailed = isHardPatchError(activeClaudeReport);
  const needsAgyReload = Boolean(!agyPatchFailed && (agyHostUpdated || agyLoadedUnpatched));
  const needsClaudeReload = Boolean(
    claudeSignedIn && !claudePatchFailed && (claudeHostUpdated || claudeLoadedUnpatched)
  );
  const needsReload = Boolean(needsAgyReload || needsClaudeReload);

  // Surface errors from either the active target or the newest downloaded version
  const newestAgyReport = agyTargets[0]
    ? reports.find((item) => item.provider === 'antigravity' && item.extensionDir === agyTargets[0])
    : null;
  const newestClaudeReport = claudeTargets[0]
    ? reports.find((item) => item.provider === 'claude' && item.extensionDir === claudeTargets[0])
    : null;
  // A worker still running at the caller's timeout is not a patch failure: it finishes on its own and the
  // next maintenance pass sees the result, so it never raises the "could not patch" warning.
  const errorCandidates = new Set(
    [activeAgyReport, activeClaudeReport, newestAgyReport, newestClaudeReport].filter(
      (r) => Boolean(r?.error) && r.code !== 'ETIMEDOUT'
    )
  );
  const primaryErrors = [...errorCandidates];
  // Optional patches left out: the bundle works, one THEO fix is missing. Shown as a sidebar notice (hub.js
  // describeBridgeNotice), never as a failure. In a real window the loaded folder sorts first
  // (findInstalledClaudeExtensions), so this is normally the loaded version only; a skip on a version
  // downloaded but not yet loaded shows once the window loads it.
  const patchSkips = [
    ...new Set(
      [activeClaudeReport, newestClaudeReport].filter(
        (r) => r && !r.error && cleanSkippedPatches(r.skippedPatches).length > 0
      )
    )
  ].map((r) => ({ ...describePatchSkip(r), active: r === activeClaudeReport }));
  for (const skip of patchSkips) {
    console.warn(
      `[THEO bridge] ${skip.label} ${skip.version}: patch(es) skipped, upstream code changed shape: ${skip.patches.join(', ')}`
    );
  }

  for (const errReport of primaryErrors) {
    console.error(
      `[THEO bridge] Failed to patch ${errReport.provider} (${errReport.extensionDir}): ${errReport.error}`
    );
  }

  // Names what the reload would load (folder + bundle stat signature): the toast dedupes on it, and the
  // hands-free reload (auto-reload.js) reloads at most once per key.
  const reloadKeyParts = [];
  if (needsAgyReload) {
    reloadKeyParts.push(`agy:${path.resolve(activeAgyDir)}:${getBundleStatSignature(activeAgyDir)}`);
  }
  if (needsClaudeReload) {
    reloadKeyParts.push(`claude:${path.resolve(activeClaudeDir)}:${getBundleStatSignature(activeClaudeDir)}`);
  }
  const reloadKey = reloadKeyParts.join('|');

  let promptShown = false;
  let promptSuppressed = false;
  if (needsReload && options.promptReload && vscodeApi?.window?.showInformationMessage) {
    const reloadStampPath =
      typeof options.reloadStampPath === 'string'
        ? options.reloadStampPath
        : isRealHostRun
          ? path.join(os.homedir(), '.claude', '.theo-reload-prompt-stamp.json')
          : '';
    const cooldownMs =
      typeof options.reloadPromptCooldownMs === 'number'
        ? options.reloadPromptCooldownMs
        : 2 * 60 * 60 * 1000;
    const promptKey = reloadKey;

    if (reloadStampPath && promptKey && !options.forcePromptReload) {
      try {
        if (fs.existsSync(reloadStampPath)) {
          const prev = JSON.parse(fs.readFileSync(reloadStampPath, 'utf8'));
          if (
            prev &&
            prev.key === promptKey &&
            Date.now() - Number(prev.promptedAt || 0) < cooldownMs
          ) {
            promptSuppressed = true;
          }
        }
      } catch {}
    }

    if (!promptSuppressed) {
      if (reloadStampPath && promptKey) {
        try {
          fs.mkdirSync(path.dirname(reloadStampPath), { recursive: true });
          fs.writeFileSync(
            reloadStampPath,
            JSON.stringify({ key: promptKey, promptedAt: Date.now() }),
            'utf8'
          );
        } catch {}
      }
      const targetLabel =
        needsAgyReload && needsClaudeReload
          ? 'Antigravity & Claude Code session bridges'
          : needsAgyReload
            ? 'Antigravity session bridge'
            : 'Claude Code session bridge';
      promptShown = true;
      const choice = await vscodeApi.window.showInformationMessage(
        `THEO updated the ${targetLabel}. Reload the window to activate.`,
        'Reload Window'
      );
      if (choice === 'Reload Window') {
        await vscodeApi.commands.executeCommand('workbench.action.reloadWindow');
      }
    }
  }
  // `active` marks a failure on the version loaded in this window; a failure on a downloaded but not yet
  // loaded version only matters after the next restart and never hides a reload or blocks clicks now.
  const patchFailures = primaryErrors.filter(isHardPatchError).map((r) => ({
    ...describePatchFailure(r),
    active: r === activeAgyReport || r === activeClaudeReport
  }));
  const warnFailures = patchFailures.filter((f) => f.provider !== 'claude' || claudeSignedIn);
  // The same failure is warned about once per 2 h across windows, hot-swaps and boots (the sidebar
  // notice keeps showing it meanwhile); a new version or a different error warns at once.
  let failureWarnSuppressed = false;
  if (warnFailures.length > 0 && options.promptReload) {
    const warnStampPath =
      typeof options.failureWarnStampPath === 'string'
        ? options.failureWarnStampPath
        : isRealHostRun
          ? path.join(os.homedir(), '.claude', '.theo-patch-failure-warn-stamp.json')
          : '';
    const warnKey = warnFailures
      .map((f) => `${f.provider}:${f.version}:${f.active ? 1 : 0}:${f.error.slice(0, 80)}`)
      .join('|');
    if (warnStampPath) {
      try {
        const prev = fs.existsSync(warnStampPath) ? JSON.parse(fs.readFileSync(warnStampPath, 'utf8')) : null;
        if (prev && prev.key === warnKey && Date.now() - Number(prev.warnedAt || 0) < 2 * 60 * 60 * 1000) {
          failureWarnSuppressed = true;
        } else {
          fs.mkdirSync(path.dirname(warnStampPath), { recursive: true });
          fs.writeFileSync(warnStampPath, JSON.stringify({ key: warnKey, warnedAt: Date.now() }), 'utf8');
        }
      } catch {}
    }
  }
  if (
    warnFailures.length > 0 &&
    !failureWarnSuppressed &&
    options.promptReload &&
    vscodeApi?.window?.showWarningMessage
  ) {
    const first = warnFailures.find((f) => f.active) || warnFailures[0];
    // "(and N more)" only counts failures with the same cause; one with the other cause is named apart.
    const nameOfFailure = (f) => `${f.label}${f.version ? ` ${f.version}` : ''}`;
    const sameKind = warnFailures.filter((f) => f !== first && f.kind === first.kind);
    const otherKind = warnFailures.filter((f) => f.kind !== first.kind);
    const others = sameKind.length > 0 ? ` (and ${sameKind.length} more)` : '';
    const separately =
      otherKind.length > 0
        ? ` Separately, THEO ${otherKind[0].kind === 'unwritable' ? 'cannot write to the folder of' : 'does not support'} ` +
          `${otherKind.map(nameOfFailure).join(' and ')}.`
        : '';
    const product = nameOfFailure(first);
    const firstLive = first.provider === 'claude' ? liveStatus.claudeActive : liveStatus.antigravityActive;
    const unwritableText = !first.active
      ? `THEO cannot write to the downloaded ${product} folder${others}: it is read-only or held by another program. ` +
        `Once VS Code switches to it, its sessions will not open from the THEO sidebar until the folder can be written.`
      : firstLive
        ? `THEO cannot write to the ${product} folder${others}: it is read-only or held by another program. ` +
          `Its sessions still open, but THEO's fixes for it are not applied until the folder can be written. THEO keeps retrying.`
        : `THEO cannot write to the ${product} folder${others}: it is read-only or held by another program. ` +
          `Its sessions will not open from the THEO sidebar until the folder can be written. ` +
          `THEO keeps retrying and will ask for a reload once it can.`;
    vscodeApi.window
      .showWarningMessage(
        (first.kind === 'unwritable'
          ? unwritableText
          : first.active
            ? `THEO could not connect to the updated ${product}${others}. ` +
              `Its sessions will not open from the THEO sidebar until THEO is updated for this version; ` +
              `a reload will not fix it.`
            : `THEO could not prepare the downloaded ${product}${others}. ` +
              `Once VS Code switches to it, its sessions will not open from the THEO sidebar until THEO is updated for that version.`) +
          ` (${first.error})` +
          separately
      )
      .then(
        () => {},
        () => {}
      );
  }

  return {
    active: Boolean(liveStatus.active),
    antigravityActive: Boolean(liveStatus.antigravityActive),
    claudeActive: Boolean(liveStatus.claudeActive),
    claudeSignedIn,
    agyHostUpdated,
    claudeHostUpdated,
    needsReload,
    needsAgyReload,
    needsClaudeReload,
    reloadKey,
    promptShown,
    promptSuppressed,
    agyPatchFailed,
    claudePatchFailed,
    patchFailures,
    patchSkips,
    hardFailureSig: getHardFailureSig(reports),
    errors: primaryErrors,
    liveStatus,
    reports
  };
}

module.exports = {
  BRIDGE_MARKER,
  PERSISTENT_HUB_MARKER,
  CLAUDE_BRIDGE_MARKER,
  BRIDGE_STAMP_VERSION,
  getBridgePatchDigest,
  describePatchFailure,
  describePatchSkip,
  trackPersistentWriteBlocks,
  isHardPatchError,
  getHardFailureSig,
  prepatchFailuresChanged,
  createBridgeRecheck,
  WRITE_BLOCK_PERSIST_MIN_ATTEMPTS,
  WRITE_BLOCK_PERSIST_MIN_MS,
  isClaudeAccountSignedIn,
  findInstalledAntigravityExtensions,
  findInstalledClaudeExtensions,
  patchAntigravityExtensionSource,
  patchClaudeExtensionSource,
  patchClaudeWebviewSource,
  prepatchInstalledExtensions,
  prepatchInstalledExtensionsAsync,
  runBridgeJobsInWorker,
  isBridgePatchWorkerBusy,
  writeFileAtomicSync,
  ensureBridgeInstalledForExtensionDir,
  ensureClaudeBridgeInstalledForExtensionDir,
  queryActiveBridgeStatus,
  ensureAntigravityBridgeInstalled
};

// Worker entry: runBridgeJobsInWorker starts this file with `isTheoBridgePatchWorker`.
try {
  const wt = require('worker_threads');
  if (!wt.isMainThread && wt.workerData && wt.workerData.isTheoBridgePatchWorker) {
    let reports;
    try {
      reports = runBridgeJobsSync(wt.workerData.jobs, wt.workerData.hubRoot);
    } catch (error) {
      reports = (wt.workerData.jobs || []).map(({ provider, dir }) => ({
        installed: false,
        updated: false,
        extensionDir: dir,
        provider,
        error: error?.message || String(error),
        code: 'EWORKER'
      }));
    }
    wt.parentPort.postMessage({ reports });
  }
} catch {}

