const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');
let vscode = null;
try {
  vscode = require('vscode');
} catch {}
const {
  CLAUDE_BRIDGE_MARKER,
  CLAUDE_PIN_MARKER,
  CLAUDE_NOWARN_MARKER,
  CLAUDE_NOBROWSER_MARKER,
  CLAUDE_USAGE_RESET_MARKER,
  CLAUDE_CTX_MARKER,
  CLAUDE_RELOAD_MARKER,
  CLAUDE_CTX_UI_RUNTIME_JS,
  patchClaudeExtensionSource,
  patchClaudeWebviewSource
} = require('./compat/claude-webview-patches.cjs');

// Bundle, backup, package.json and stamp writes go to a temp file and are renamed into place, so a process that
// exits mid-write (daemon respawn, window close) leaves the old file or the new one, never half of one.
function writeFileAtomicSync(targetPath, data, encoding = 'utf8') {
  let threadId = 0;
  try {
    threadId = require('worker_threads').threadId || 0;
  } catch {}
  const tmpPath = `${targetPath}.theo-tmp-${process.pid}-${threadId}`;
  try {
    fs.writeFileSync(tmpPath, data, encoding);
    fs.renameSync(tmpPath, targetPath);
  } catch (error) {
    try {
      fs.unlinkSync(tmpPath);
    } catch {}
    // A target held open without delete sharing refuses the rename on Windows: write in place instead.
    if (error && (error.code === 'EPERM' || error.code === 'EACCES' || error.code === 'EBUSY')) {
      fs.writeFileSync(targetPath, data, encoding);
      return;
    }
    throw error;
  }
}

// Removes temp files a killed process left behind (writeFileAtomicSync names them <file>.theo-tmp-<pid>-<thread>).
function sweepStaleAtomicTmpFiles(dirs, maxAgeMs = 5 * 60 * 1000) {
  const now = Date.now();
  for (const dir of dirs) {
    let names = [];
    try {
      names = fs.readdirSync(dir);
    } catch {
      continue;
    }
    for (const name of names) {
      if (!name.includes('.theo-tmp-')) continue;
      const full = path.join(dir, name);
      try {
        if (now - fs.statSync(full).mtimeMs > maxAgeMs) fs.unlinkSync(full);
      } catch {}
    }
  }
}

// Shared by every copy of this module in the process (hot swap re-requires bridge.js), so the one-writer
// queue survives a hot swap.
const BRIDGE_WORKER_STATE = (() => {
  const key = Symbol.for('bhfirms.theoHub.bridgePatchWorker');
  if (!globalThis[key]) {
    globalThis[key] = {
      tail: Promise.resolve(),
      pending: 0,
      prepatchInFlight: false,
      workerUnavailable: false
    };
  }
  return globalThis[key];
})();

const BRIDGE_MARKER = 'antigravity-hub-bridge-v1';
const PERSISTENT_HUB_MARKER = '/*bhf-persistent-hub*/';
const BRIDGE_FILE_NAMES = [
  'antigravity-hub-bridge.cjs',
  'antigravity-tab-state.cjs',
  'antigravity-context-window.cjs',
  'excel-preview.cjs'
];
const BRIDGE_ICON_FILE_NAMES = [
  'antigravity-logo-color.svg',
  'antigravity-logo-done.svg',
  'antigravity-logo-pending.svg'
];
const CLAUDE_BRIDGE_FILE_NAMES = ['claude-hub-bridge.cjs', 'excel-preview.cjs'];
const CLAUDE_ICON_FILE_NAMES = [
  'claude-logo.svg',
  'claude-logo-done.svg',
  'claude-logo-pending.svg'
];

function getDefaultExtensionsDir() {
  return path.join(os.homedir(), '.vscode', 'extensions');
}

function parseVersionFromFolder(folderName, prefixRegex = /^google\.google-antigravity-(\d+\.\d+\.\d+)/i) {
  const match = String(folderName || '').match(prefixRegex);
  if (!match) {
    return [0, 0, 0];
  }
  return match[1].split('.').map((part) => Number.parseInt(part, 10) || 0);
}

function compareVersions(a, b) {
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    const delta = (b[index] || 0) - (a[index] || 0);
    if (delta !== 0) {
      return delta;
    }
  }
  return 0;
}

function findInstalledAntigravityExtensions(
  extensionsDir = getDefaultExtensionsDir(),
  vscodeApi = vscode
) {
  const results = [];
  const defaultDir = getDefaultExtensionsDir();
  const useActiveExt =
    !extensionsDir || path.resolve(extensionsDir) === path.resolve(defaultDir);
  if (useActiveExt) {
    const activeExtension = vscodeApi?.extensions?.getExtension?.('google.google-antigravity');
    if (activeExtension?.extensionPath && fs.existsSync(activeExtension.extensionPath)) {
      results.push(activeExtension.extensionPath);
    }
  }

  if (fs.existsSync(extensionsDir)) {
    const entries = fs
      .readdirSync(extensionsDir, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && /^google\.google-antigravity-/i.test(entry.name))
      .sort((left, right) =>
        compareVersions(parseVersionFromFolder(left.name), parseVersionFromFolder(right.name))
      );

    for (const entry of entries) {
      const fullPath = path.join(extensionsDir, entry.name);
      if (!results.includes(fullPath)) {
        results.push(fullPath);
      }
    }
  }

  return results;
}

function findInstalledClaudeExtensions(
  extensionsDir = getDefaultExtensionsDir(),
  vscodeApi = vscode
) {
  const results = [];
  const defaultDir = getDefaultExtensionsDir();
  const useActiveExt =
    !extensionsDir || path.resolve(extensionsDir) === path.resolve(defaultDir);
  if (useActiveExt) {
    const activeExtension = vscodeApi?.extensions?.getExtension?.('anthropic.claude-code');
    if (activeExtension?.extensionPath && fs.existsSync(activeExtension.extensionPath)) {
      results.push(activeExtension.extensionPath);
    }
  }

  const claudeRe = /^anthropic\.claude-code-(\d+\.\d+\.\d+)/i;
  if (fs.existsSync(extensionsDir)) {
    const entries = fs
      .readdirSync(extensionsDir, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && claudeRe.test(entry.name))
      .sort((left, right) =>
        compareVersions(
          parseVersionFromFolder(left.name, claudeRe),
          parseVersionFromFolder(right.name, claudeRe)
        )
      );

    for (const entry of entries) {
      const fullPath = path.join(extensionsDir, entry.name);
      if (!results.includes(fullPath)) {
        results.push(fullPath);
      }
    }
  }

  return results;
}

function patchAntigravityExtensionSource(sourceText, options = {}) {
  if (typeof sourceText !== 'string' || !sourceText) {
    throw new Error('Empty Antigravity extension bundle.');
  }
  const validateSyntax = options.validateSyntax !== false;

  let baseSource = sourceText;
  // Anchor 1: flexible return object with apiImpl + provider in any property order / with extra fields
  const attachReturnRe =
    /return\{(?=[^}]{0,160}\bapiImpl:([A-Za-z0-9_$]+))(?=[^}]{0,160}\bprovider:([A-Za-z0-9_$]+))[^}]{0,160}\}\};/;
  const attachMatch = baseSource.match(attachReturnRe);

  // Anchor 2 (structural VS Code API fallback if return{apiImpl,provider} is ever inlined/removed):
  // <apiImpl>.setChatViewProvider(<provider>) ... <ctx>.subscriptions.push(<vscode>.window.registerWebviewViewProvider(<naming>.viewId,<provider>
  let attachNeedle = '';
  let apiImplVar = '';
  let providerVar = '';
  let ctxVar = 'a';
  let namingVar = 'c';
  let useCommaPrefixInjection = false;

  if (attachMatch) {
    attachNeedle = attachMatch[0];
    apiImplVar = attachMatch[1];
    providerVar = attachMatch[2];
    const fnWindow = baseSource.slice(Math.max(0, attachMatch.index - 4000), attachMatch.index);
    const fnHeadMatches = Array.from(
      fnWindow.matchAll(/function [A-Za-z0-9_$]+\(([A-Za-z0-9_$]+),[A-Za-z0-9_$]+,([A-Za-z0-9_$]+)\)\{/g)
    );
    if (fnHeadMatches.length > 0) {
      const lastHead = fnHeadMatches[fnHeadMatches.length - 1];
      ctxVar = lastHead[1] || ctxVar;
      namingVar = lastHead[2] || namingVar;
    }
    const rendererCtxMatch = fnWindow.match(/WebviewRenderer\(\{[^}]{0,120}\bcontext:([A-Za-z0-9_$]+)\b/);
    if (rendererCtxMatch?.[1]) {
      ctxVar = rendererCtxMatch[1];
    }
    const namingViewMatch = fnWindow.match(
      /JetskiWebviewProvider\([A-Za-z0-9_$]+,[A-Za-z0-9_$]+,([A-Za-z0-9_$]+)\.viewId\b/
    );
    if (namingViewMatch?.[1]) {
      namingVar = namingViewMatch[1];
    }
  } else {
    const regViewRe =
      /(?<![A-Za-z0-9_$])([A-Za-z0-9_$]+)\.subscriptions\.push\([A-Za-z0-9_$]+\.window\.registerWebviewViewProvider\(([A-Za-z0-9_$]+)\.viewId,([A-Za-z0-9_$]+)\b/;
    const regMatch = baseSource.match(regViewRe);
    if (regMatch) {
      attachNeedle = regMatch[0];
      ctxVar = regMatch[1];
      namingVar = regMatch[2];
      providerVar = regMatch[3];
      useCommaPrefixInjection = true;
      const preWin = baseSource.slice(Math.max(0, regMatch.index - 2000), regMatch.index);
      const escapedProv = providerVar.replace(/\$/g, '\\$');
      const apiMatch =
        preWin.match(new RegExp(`([A-Za-z0-9_$]+)\\.setChatViewProvider\\(${escapedProv}\\)`)) ||
        preWin.match(/WebviewRenderer\(\{[^}]{0,120}\bapiImpl:([A-Za-z0-9_$]+)\b/);
      if (apiMatch?.[1]) {
        apiImplVar = apiMatch[1];
      }
    }
  }

  if (!attachNeedle || !apiImplVar || !providerVar) {
    throw new Error('Could not find PN(a,b,c) return anchor in Antigravity extension bundle.');
  }

  // Ensure multi-main webviews are allowed even before attach() runs (handles 1.8/1.9 k vs 1.10+ h)
  if (!baseSource.includes('/*antigravity-hub-multi-main*/')) {
    const registerMultiMainRe =
      /(\bregisterWebview\(([A-Za-z0-9_$]+),([A-Za-z0-9_$]+)\)\{var [A-Za-z0-9_$]+=this\.views\.findIndex\(([A-Za-z0-9_$]+)=>\4\.webview===\2\.webview\|\|)\3==="main"&&\4\.type==="main"/;
    const fallbackMultiMainRe = /(?<![A-Za-z0-9_$])([A-Za-z0-9_$]+)==="main"&&([A-Za-z0-9_$]+)\.type==="main"/;
    if (registerMultiMainRe.test(baseSource)) {
      baseSource = baseSource.replace(registerMultiMainRe, '$1!1/*antigravity-hub-multi-main*/');
    } else if (fallbackMultiMainRe.test(baseSource)) {
      baseSource = baseSource.replace(fallbackMultiMainRe, '!1/*antigravity-hub-multi-main*/');
    }
  }

  // Keep agy.exe --hub alive across Developer: Reload Window / extension host restarts
  const stopSubRe = /(?<![A-Za-z0-9_$])([A-Za-z0-9_$]+)\.subscriptions\.push\(\{dispose:\(\)=>\{[A-Za-z0-9_$]+\.stop\(\)\}\}\);/;
  if (stopSubRe.test(baseSource)) {
    baseSource = baseSource.replace(
      stopSubRe,
      `$1.subscriptions.push({dispose:()=>{${PERSISTENT_HUB_MARKER}}});`
    );
  }
  const deactivateStopRe = /(?<![A-Za-z0-9_$])[A-Za-z0-9_$]+\.AntigravityServerManager\.getInstance\(\)\.stop\(\)/;
  if (deactivateStopRe.test(baseSource)) {
    baseSource = baseSource.replace(
      deactivateStopRe,
      `Promise.resolve()${PERSISTENT_HUB_MARKER}`
    );
  }

  const attachCallBody = `try{require("./antigravity-hub-bridge.cjs").attach({vscode:require("vscode"),context:${ctxVar},apiImpl:${apiImplVar},provider:${providerVar},renderer:${providerVar}.renderer,naming:${namingVar}})}catch(_bhfErr){console.error("[antigravity-hub-bridge]",_bhfErr)}`;
  const injection = useCommaPrefixInjection
    ? `(()=>{/*${BRIDGE_MARKER}*/${attachCallBody}})(),${attachNeedle}`
    : `/*${BRIDGE_MARKER}*/${attachCallBody}${attachNeedle}`;

  if (baseSource.includes(`/*${BRIDGE_MARKER}*/`)) {
    baseSource = baseSource.replace(
      /(\/\*antigravity-hub-bridge-v1\*\/try\{require\("\.\/antigravity-hub-bridge\.cjs"\)\.attach\(\{vscode:)[A-Za-z0-9_$]+(,context:)/,
      '$1require("vscode")$2'
    );
    if (validateSyntax) {
      new vm.Script(baseSource, { filename: 'extension.js' });
    }
    return baseSource;
  }

  const patched = baseSource.replace(attachNeedle, () => injection);
  if (patched === baseSource) {
    throw new Error('Failed to inject Antigravity Hub bridge into extension.js.');
  }

  // Validate syntax before writing
  if (validateSyntax) {
    new vm.Script(patched, { filename: 'extension.js' });
  }
  return patched;
}

const BRIDGE_STAMP_VERSION = 3;

let _cachedPatchesPath = '';
let _cachedPatchesMtimeMs = 0;
let _cachedPatchesMod = null;

function loadLatestClaudeWebviewPatches(hubExtensionPath = __dirname) {
  const targetRoot = hubExtensionPath || __dirname;
  const patchesPath = path.join(targetRoot, 'compat', 'claude-webview-patches.cjs');
  try {
    if (fs.existsSync(patchesPath)) {
      const mtimeMs = Math.floor(fs.statSync(patchesPath).mtimeMs);
      if (
        !_cachedPatchesMod ||
        _cachedPatchesPath !== patchesPath ||
        _cachedPatchesMtimeMs !== mtimeMs
      ) {
        const resolved = require.resolve(patchesPath);
        delete require.cache[resolved];
        _cachedPatchesMod = require(patchesPath);
        _cachedPatchesPath = patchesPath;
        _cachedPatchesMtimeMs = mtimeMs;
      }
      return _cachedPatchesMod;
    }
  } catch {}
  return {
    CLAUDE_CTX_UI_RUNTIME_JS,
    patchClaudeExtensionSource,
    patchClaudeWebviewSource
  };
}

function getBridgePatchDigest(overrides = {}, hubExtensionPath = __dirname) {
  const latestPatches = loadLatestClaudeWebviewPatches(hubExtensionPath);
  const ctxRuntimeJs =
    typeof overrides?.claudeCtxUiRuntimeJs === 'string'
      ? overrides.claudeCtxUiRuntimeJs
      : latestPatches.CLAUDE_CTX_UI_RUNTIME_JS || CLAUDE_CTX_UI_RUNTIME_JS;
  const extPatchFn = latestPatches.patchClaudeExtensionSource || patchClaudeExtensionSource;
  const wvPatchFn = latestPatches.patchClaudeWebviewSource || patchClaudeWebviewSource;
  return crypto
    .createHash('sha1')
    .update(
      [
        BRIDGE_MARKER,
        PERSISTENT_HUB_MARKER,
        CLAUDE_BRIDGE_MARKER,
        CLAUDE_PIN_MARKER,
        CLAUDE_NOWARN_MARKER,
        CLAUDE_NOBROWSER_MARKER,
        CLAUDE_USAGE_RESET_MARKER,
        CLAUDE_CTX_MARKER,
        CLAUDE_RELOAD_MARKER,
        ctxRuntimeJs,
        patchAntigravityExtensionSource.toString(),
        extPatchFn.toString(),
        wvPatchFn.toString()
      ].join('\n')
    )
    .digest('hex')
    .slice(0, 16);
}

function ensureBridgeInstalledForExtensionDir(extensionDir, hubExtensionPath) {
  const bundlePath = path.join(extensionDir, 'extension.js');
  if (!fs.existsSync(bundlePath)) {
    return { installed: false, updated: false, reason: 'missing-bundle', extensionDir, provider: 'antigravity' };
  }
  sweepStaleAtomicTmpFiles([extensionDir]);

  const backupPath = `${bundlePath}.antigravity-hub-original`;
  const stampPath = path.join(extensionDir, '.theo-bridge-stamp.json');
  const bridgePatchDigest = getBridgePatchDigest();

  let filesUpdated = false;
  for (const fileName of BRIDGE_FILE_NAMES) {
    const srcPath = path.join(hubExtensionPath, 'compat', fileName);
    const destPath = path.join(extensionDir, fileName);
    if (!fs.existsSync(srcPath)) {
      continue;
    }
    const srcContent = fs.readFileSync(srcPath, 'utf8');
    const destContent = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
    if (srcContent !== destContent) {
      writeFileAtomicSync(destPath, srcContent, 'utf8');
      filesUpdated = true;
    }
  }

  const destImgDir = path.join(extensionDir, 'img');
  fs.mkdirSync(destImgDir, { recursive: true });
  const hubLogoSrc = path.join(hubExtensionPath, 'resources', 'logo.svg');
  if (fs.existsSync(hubLogoSrc)) {
    const hubLogoContent = fs.readFileSync(hubLogoSrc, 'utf8');
    const origLogoPath = path.join(destImgDir, 'logo.svg');
    const origLogoBak = `${origLogoPath}.antigravity-hub-original`;
    if (fs.existsSync(origLogoPath) && !fs.existsSync(origLogoBak)) {
      fs.copyFileSync(origLogoPath, origLogoBak);
    }
    for (const targetLogoName of ['logo.svg', 'theo-logo.svg']) {
      const targetLogoPath = path.join(destImgDir, targetLogoName);
      const existingContent = fs.existsSync(targetLogoPath) ? fs.readFileSync(targetLogoPath, 'utf8') : '';
      if (existingContent !== hubLogoContent) {
        writeFileAtomicSync(targetLogoPath, hubLogoContent, 'utf8');
        filesUpdated = true;
      }
    }
  }
  for (const iconName of BRIDGE_ICON_FILE_NAMES) {
    const srcPath = path.join(hubExtensionPath, 'resources', iconName);
    const destPath = path.join(destImgDir, iconName);
    if (!fs.existsSync(srcPath)) {
      continue;
    }
    const srcContent = fs.readFileSync(srcPath, 'utf8');
    const destContent = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
    if (srcContent !== destContent) {
      writeFileAtomicSync(destPath, srcContent, 'utf8');
      filesUpdated = true;
    }
  }

  const pkgPath = path.join(extensionDir, 'package.json');
  try {
    if (fs.existsSync(stampPath) && fs.existsSync(backupPath)) {
      const stamp = JSON.parse(fs.readFileSync(stampPath, 'utf8'));
      const bStat = fs.statSync(bundlePath);
      const pStat = fs.existsSync(pkgPath) ? fs.statSync(pkgPath) : { mtimeMs: 0, size: 0 };
      if (
        stamp &&
        stamp.stampVersion === BRIDGE_STAMP_VERSION &&
        stamp.bridgePatchDigest === bridgePatchDigest &&
        stamp.bundleMtimeMs === Math.floor(bStat.mtimeMs) &&
        stamp.bundleSize === bStat.size &&
        stamp.pkgMtimeMs === Math.floor(pStat.mtimeMs) &&
        stamp.pkgSize === pStat.size
      ) {
        return {
          installed: true,
          updated: filesUpdated,
          filesUpdated,
          bundleUpdated: false,
          pkgUpdated: false,
          extensionDir,
          provider: 'antigravity'
        };
      }
    }
  } catch {}

  // Update package.json (customEditor + THEO Activity Bar branding) BEFORE patching extension.js
  // so customEditors and sidebar branding are always preserved even if a future bundle throws.
  let pkgUpdated = false;
  if (fs.existsSync(pkgPath)) {
    try {
      const pkgText = fs.readFileSync(pkgPath, 'utf8');
      const pkgBackupPath = `${pkgPath}.antigravity-hub-original`;
      if (!fs.existsSync(pkgBackupPath)) {
        writeFileAtomicSync(pkgBackupPath, pkgText, 'utf8');
      }
      const pkgData = JSON.parse(pkgText);
      pkgData.contributes = pkgData.contributes || {};
      pkgData.contributes.customEditors = Array.isArray(pkgData.contributes.customEditors)
        ? pkgData.contributes.customEditors
        : [];
      const hasConvEditor = pkgData.contributes.customEditors.some(
        (item) => item && item.viewType === 'antigravity.conversationEditor'
      );
      let needsPkgWrite = false;
      if (!hasConvEditor) {
        pkgData.contributes.customEditors.push({
          viewType: 'antigravity.conversationEditor',
          displayName: 'Antigravity Conversation',
          selector: [
            { filenamePattern: 'antigravity-session:/**/*' },
            { filenamePattern: 'antigravity-session://**' }
          ],
          priority: 'default'
        });
        needsPkgWrite = true;
      }
      const actBar = pkgData.contributes?.viewsContainers?.activitybar;
      if (Array.isArray(actBar)) {
        for (const item of actBar) {
          if (item && item.id === 'antigravity-sidebar') {
            if (item.title !== 'THEO') {
              item.title = 'THEO';
              needsPkgWrite = true;
            }
            if (item.icon !== 'img/theo-logo.svg') {
              item.icon = 'img/theo-logo.svg';
              needsPkgWrite = true;
            }
          }
        }
      }
      const sideViews = pkgData.contributes?.views?.['antigravity-sidebar'];
      if (Array.isArray(sideViews)) {
        for (const item of sideViews) {
          if (item && item.id === 'antigravity.panel' && item.name !== 'THEO') {
            item.name = 'THEO';
            needsPkgWrite = true;
          }
        }
      }
      if (needsPkgWrite) {
        writeFileAtomicSync(pkgPath, JSON.stringify(pkgData, null, 2), 'utf8');
        pkgUpdated = true;
      }
    } catch {}
  }

  const currentText = fs.readFileSync(bundlePath, 'utf8');
  if (!fs.existsSync(backupPath) && !currentText.includes(BRIDGE_MARKER)) {
    writeFileAtomicSync(backupPath, currentText, 'utf8');
  }

  const cleanSource = fs.existsSync(backupPath)
    ? fs.readFileSync(backupPath, 'utf8')
    : currentText;

  const patchedText = patchAntigravityExtensionSource(cleanSource, { validateSyntax: false });
  let bundleUpdated = false;
  if (currentText !== patchedText) {
    new vm.Script(patchedText, { filename: 'extension.js' });
    writeFileAtomicSync(bundlePath, patchedText, 'utf8');
    bundleUpdated = true;
  }

  try {
    const bStat = fs.statSync(bundlePath);
    const pStat = fs.existsSync(pkgPath) ? fs.statSync(pkgPath) : { mtimeMs: 0, size: 0 };
    writeFileAtomicSync(
      stampPath,
      JSON.stringify({
        stampVersion: BRIDGE_STAMP_VERSION,
        bridgePatchDigest,
        bundleMtimeMs: Math.floor(bStat.mtimeMs),
        bundleSize: bStat.size,
        pkgMtimeMs: Math.floor(pStat.mtimeMs),
        pkgSize: pStat.size
      }),
      'utf8'
    );
  } catch {}

  return {
    installed: true,
    updated: filesUpdated || bundleUpdated || pkgUpdated,
    filesUpdated,
    bundleUpdated,
    pkgUpdated,
    extensionDir,
    provider: 'antigravity'
  };
}

function ensureClaudeBridgeInstalledForExtensionDir(extensionDir, hubExtensionPath) {
  const bundlePath = path.join(extensionDir, 'extension.js');
  if (!fs.existsSync(bundlePath)) {
    return { installed: false, updated: false, reason: 'missing-bundle', extensionDir, provider: 'claude' };
  }
  sweepStaleAtomicTmpFiles([extensionDir, path.join(extensionDir, 'webview')]);

  // Compatible with ~/.claude/hooks/claude-panel-pin.sh which uses .orig backups
  const backupPath = `${bundlePath}.orig`;
  const webviewPath = path.join(extensionDir, 'webview', 'index.js');
  const stampPath = path.join(extensionDir, '.theo-bridge-stamp.json');
  const latestPatches = loadLatestClaudeWebviewPatches(hubExtensionPath);
  const bridgePatchDigest = getBridgePatchDigest({}, hubExtensionPath);

  let filesUpdated = false;
  for (const fileName of CLAUDE_BRIDGE_FILE_NAMES) {
    const srcPath = path.join(hubExtensionPath, 'compat', fileName);
    const destPath = path.join(extensionDir, fileName);
    if (!fs.existsSync(srcPath)) {
      continue;
    }
    const srcContent = fs.readFileSync(srcPath, 'utf8');
    const destContent = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
    if (srcContent !== destContent) {
      writeFileAtomicSync(destPath, srcContent, 'utf8');
      filesUpdated = true;
    }
  }

  const destResDir = path.join(extensionDir, 'resources');
  fs.mkdirSync(destResDir, { recursive: true });
  for (const iconName of CLAUDE_ICON_FILE_NAMES) {
    const srcPath = path.join(hubExtensionPath, 'resources', iconName);
    const destPath = path.join(destResDir, iconName);
    if (!fs.existsSync(srcPath)) {
      continue;
    }
    const srcContent = fs.readFileSync(srcPath, 'utf8');
    const destContent = fs.existsSync(destPath) ? fs.readFileSync(destPath, 'utf8') : '';
    if (srcContent !== destContent) {
      writeFileAtomicSync(destPath, srcContent, 'utf8');
      filesUpdated = true;
    }
  }

  const pkgPath = path.join(extensionDir, 'package.json');
  try {
    if (fs.existsSync(stampPath) && fs.existsSync(backupPath)) {
      const stamp = JSON.parse(fs.readFileSync(stampPath, 'utf8'));
      const bStat = fs.statSync(bundlePath);
      const wStat = fs.existsSync(webviewPath) ? fs.statSync(webviewPath) : { mtimeMs: 0, size: 0 };
      const pStat = fs.existsSync(pkgPath) ? fs.statSync(pkgPath) : { mtimeMs: 0, size: 0 };
      if (
        stamp &&
        stamp.stampVersion === BRIDGE_STAMP_VERSION &&
        stamp.bridgePatchDigest === bridgePatchDigest &&
        stamp.bundleMtimeMs === Math.floor(bStat.mtimeMs) &&
        stamp.bundleSize === bStat.size &&
        stamp.webviewMtimeMs === Math.floor(wStat.mtimeMs) &&
        stamp.webviewSize === wStat.size &&
        stamp.pkgMtimeMs === Math.floor(pStat.mtimeMs) &&
        stamp.pkgSize === pStat.size
      ) {
        return {
          installed: true,
          updated: filesUpdated,
          filesUpdated,
          bundleUpdated: false,
          webviewUpdated: false,
          pkgUpdated: false,
          extensionDir,
          provider: 'claude'
        };
      }
    }
  } catch {}

  // Strip "onStartupFinished" from Claude Code's package.json activationEvents so VS Code never
  // auto-activates anthropic.claude-code on startup when 0 Claude accounts are signed in (while
  // keeping "onWebviewPanel:claudeVSCodePanel" and on-demand activation when signed in).
  let pkgUpdated = false;
  if (fs.existsSync(pkgPath)) {
    try {
      const pkgText = fs.readFileSync(pkgPath, 'utf8');
      const pkgBackupPath = `${pkgPath}.orig`;
      if (!fs.existsSync(pkgBackupPath)) {
        writeFileAtomicSync(pkgBackupPath, pkgText, 'utf8');
      }
      const pkgData = JSON.parse(pkgText);
      if (
        Array.isArray(pkgData.activationEvents) &&
        pkgData.activationEvents.includes('onStartupFinished')
      ) {
        pkgData.activationEvents = pkgData.activationEvents.filter(
          (ev) => ev !== 'onStartupFinished'
        );
        writeFileAtomicSync(pkgPath, JSON.stringify(pkgData, null, 2), 'utf8');
        pkgUpdated = true;
      }
    } catch {}
  }

  const currentText = fs.readFileSync(bundlePath, 'utf8');
  if (
    !fs.existsSync(backupPath) &&
    !currentText.includes(CLAUDE_PIN_MARKER) &&
    !currentText.includes(CLAUDE_RELOAD_MARKER) &&
    !currentText.includes(`/*${CLAUDE_BRIDGE_MARKER}*/`)
  ) {
    writeFileAtomicSync(backupPath, currentText, 'utf8');
  }

  const cleanSource = fs.existsSync(backupPath)
    ? fs.readFileSync(backupPath, 'utf8')
    : currentText;

  const extPatchFn = latestPatches.patchClaudeExtensionSource || patchClaudeExtensionSource;
  const wvPatchFn = latestPatches.patchClaudeWebviewSource || patchClaudeWebviewSource;
  const patchedExtText = extPatchFn(cleanSource, { validateSyntax: false });
  let bundleUpdated = false;
  if (currentText !== patchedExtText) {
    new vm.Script(patchedExtText, { filename: 'claude-extension.js' });
    writeFileAtomicSync(bundlePath, patchedExtText, 'utf8');
    bundleUpdated = true;
  }

  // Also patch webview/index.js (usage banner, browser banner, context window pill)
  let webviewUpdated = false;
  if (fs.existsSync(webviewPath)) {
    const webviewBackupPath = `${webviewPath}.orig`;
    const currentWebview = fs.readFileSync(webviewPath, 'utf8');
    if (
      !fs.existsSync(webviewBackupPath) &&
      !currentWebview.includes(CLAUDE_NOWARN_MARKER) &&
      !currentWebview.includes(CLAUDE_NOBROWSER_MARKER) &&
      !currentWebview.includes(CLAUDE_USAGE_RESET_MARKER) &&
      !currentWebview.includes(CLAUDE_CTX_MARKER) &&
      !currentWebview.includes(CLAUDE_RELOAD_MARKER)
    ) {
      writeFileAtomicSync(webviewBackupPath, currentWebview, 'utf8');
    }
    const cleanWebview = fs.existsSync(webviewBackupPath)
      ? fs.readFileSync(webviewBackupPath, 'utf8')
      : currentWebview;
    const patchedWebview = wvPatchFn(cleanWebview, { validateSyntax: false });
    if (currentWebview !== patchedWebview) {
      new vm.Script(patchedWebview, { filename: 'claude-webview-index.js' });
      writeFileAtomicSync(webviewPath, patchedWebview, 'utf8');
      webviewUpdated = true;
    }
  }

  try {
    const bStat = fs.statSync(bundlePath);
    const wStat = fs.existsSync(webviewPath) ? fs.statSync(webviewPath) : { mtimeMs: 0, size: 0 };
    const pStat = fs.existsSync(pkgPath) ? fs.statSync(pkgPath) : { mtimeMs: 0, size: 0 };
    writeFileAtomicSync(
      stampPath,
      JSON.stringify({
        stampVersion: BRIDGE_STAMP_VERSION,
        bridgePatchDigest,
        bundleMtimeMs: Math.floor(bStat.mtimeMs),
        bundleSize: bStat.size,
        webviewMtimeMs: Math.floor(wStat.mtimeMs),
        webviewSize: wStat.size,
        pkgMtimeMs: Math.floor(pStat.mtimeMs),
        pkgSize: pStat.size
      }),
      'utf8'
    );
  } catch {}

  return {
    installed: true,
    updated: filesUpdated || bundleUpdated || webviewUpdated || pkgUpdated,
    filesUpdated,
    bundleUpdated,
    webviewUpdated,
    pkgUpdated,
    extensionDir,
    provider: 'claude'
  };
}

function safeStatMtimeMs(targetPath) {
  try {
    return Math.floor(fs.statSync(targetPath).mtimeMs);
  } catch {
    return 0;
  }
}

let _lastPrepatchSig = '';

function prepatchInstalledExtensions(hubExtensionPath = __dirname, options = {}) {
  const extensionsDir = options.extensionsDir || getDefaultExtensionsDir();
  if (!fs.existsSync(extensionsDir)) {
    return { checked: false, skipped: true, updatedDirs: [], reports: [], errors: [] };
  }
  const hubRoot = hubExtensionPath || __dirname;
  const dirMtime = safeStatMtimeMs(extensionsDir);
  const extJsonMtime = safeStatMtimeMs(path.join(extensionsDir, 'extensions.json'));
  const hubBridgeMtime = Math.max(
    safeStatMtimeMs(__filename),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'claude-webview-patches.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'antigravity-hub-bridge.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'antigravity-context-window.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'claude-hub-bridge.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'excel-preview.cjs'))
  );
  const sig = `${path.resolve(extensionsDir)}|${dirMtime}|${extJsonMtime}|${hubBridgeMtime}`;
  if (!options.force && _lastPrepatchSig === sig) {
    return { checked: false, skipped: true, updatedDirs: [], reports: [], errors: [] };
  }

  const agyTargets = findInstalledAntigravityExtensions(extensionsDir, null);
  const claudeTargets = findInstalledClaudeExtensions(extensionsDir, null);
  const reports = [];
  const updatedDirs = [];
  const errors = [];
  let sawTransientIncomplete = false;

  for (const dir of agyTargets) {
    try {
      const res = ensureBridgeInstalledForExtensionDir(dir, hubRoot);
      reports.push(res);
      if (res.reason === 'missing-bundle') {
        sawTransientIncomplete = true;
      } else if (res.updated) {
        updatedDirs.push(dir);
      }
    } catch (error) {
      const code = String(error?.code || '');
      if (code === 'EBUSY' || code === 'EPERM' || code === 'ENOENT') {
        sawTransientIncomplete = true;
      }
      const errObj = {
        installed: false,
        updated: false,
        extensionDir: dir,
        provider: 'antigravity',
        error: error?.message || String(error)
      };
      reports.push(errObj);
      errors.push(errObj);
    }
  }

  for (const dir of claudeTargets) {
    try {
      const res = ensureClaudeBridgeInstalledForExtensionDir(dir, hubRoot);
      reports.push(res);
      if (res.reason === 'missing-bundle') {
        sawTransientIncomplete = true;
      } else if (res.updated) {
        updatedDirs.push(dir);
      }
    } catch (error) {
      const code = String(error?.code || '');
      if (code === 'EBUSY' || code === 'EPERM' || code === 'ENOENT') {
        sawTransientIncomplete = true;
      }
      const errObj = {
        installed: false,
        updated: false,
        extensionDir: dir,
        provider: 'claude',
        error: error?.message || String(error)
      };
      reports.push(errObj);
      errors.push(errObj);
    }
  }

  if (!sawTransientIncomplete && errors.length === 0) {
    _lastPrepatchSig = sig;
  }

  return {
    checked: true,
    skipped: false,
    updatedDirs,
    reports,
    errors
  };
}

// ---- Bundle patching off the Extension Host thread (2026-11-12) ----
// Patching reads, rewrites and writes 4 to 12 MB bundles. On 2026-11-12 four quadratic regexes made one
// Antigravity update freeze the Extension Host for 17.8 s. The regexes are linear now, but any future upstream
// bundle shape could slow a pattern again, so every Extension Host caller patches in a worker thread: the
// sidebar, tabs and streaming stay live whatever the patch costs. The worker loads this same file
// (`isTheoBridgePatchWorker`), runs the jobs and posts plain report objects back.
const BRIDGE_PATCH_WORKER_TIMEOUT_MS = 120000;
const TRANSIENT_PATCH_ERROR_CODES = new Set(['EBUSY', 'EPERM', 'ENOENT', 'ETIMEDOUT', 'EWORKER']);

function runBridgeJobsSync(jobs, hubRoot) {
  return (Array.isArray(jobs) ? jobs : []).map(({ provider, dir }) => {
    try {
      return provider === 'claude'
        ? ensureClaudeBridgeInstalledForExtensionDir(dir, hubRoot)
        : ensureBridgeInstalledForExtensionDir(dir, hubRoot);
    } catch (error) {
      return {
        installed: false,
        updated: false,
        extensionDir: dir,
        provider,
        error: error?.message || String(error),
        code: String(error?.code || '')
      };
    }
  });
}

// One worker at a time per process: each run queues behind the previous worker's exit (not its answer), so
// two workers never write the same bundle at once, even after a caller stopped waiting (timeout) or after a
// hot swap re-required this module (the queue lives in BRIDGE_WORKER_STATE). A worker that never exits
// releases the queue after BRIDGE_PATCH_WORKER_QUEUE_RELEASE_MS.
const BRIDGE_PATCH_WORKER_QUEUE_RELEASE_MS = 10 * 60 * 1000;
// After a worker fails once it started, patch in-thread for this long before trying a worker again.
const BRIDGE_WORKER_RETRY_AFTER_FAILURE_MS = 10 * 60 * 1000;

// True while a patch run is queued or its worker is still alive (the daemon waits for it before respawning).
function isBridgePatchWorkerBusy() {
  return BRIDGE_WORKER_STATE.pending > 0;
}

function runBridgeJobsInWorker(jobs, hubRoot, options = {}) {
  const list = Array.isArray(jobs) ? jobs.filter((j) => j && j.dir) : [];
  if (list.length === 0) {
    return Promise.resolve([]);
  }
  const state = BRIDGE_WORKER_STATE;
  state.pending += 1;
  const run = state.tail.then(() => startBridgeWorkerRun(list, hubRoot, options));
  const done = run
    .then((r) => r.exited)
    .catch(() => {})
    .then(() => {
      state.pending = Math.max(0, state.pending - 1);
    });
  state.tail = done;
  return run.then((r) => r.answer);
}

// Returns { answer: Promise<reports>, exited: Promise<void> }.
function startBridgeWorkerRun(list, hubRoot, options = {}) {
  const failAll = (message, code) =>
    list.map(({ provider, dir }) => ({
      installed: false,
      updated: false,
      extensionDir: dir,
      provider,
      error: message,
      code
    }));
  const inThread = () => ({ answer: Promise.resolve(runBridgeJobsSync(list, hubRoot)), exited: Promise.resolve() });
  let WorkerCtor = null;
  try {
    WorkerCtor = require('worker_threads').Worker;
  } catch {}
  if (
    !WorkerCtor ||
    options.inThread === true ||
    process.env.THEO_BRIDGE_PATCH_IN_THREAD === '1' ||
    BRIDGE_WORKER_STATE.workerUnavailable ||
    Date.now() < Number(BRIDGE_WORKER_STATE.workerUnavailableUntil || 0)
  ) {
    return inThread();
  }
  let worker = null;
  try {
    worker = new WorkerCtor(__filename, {
      workerData: { isTheoBridgePatchWorker: true, jobs: list, hubRoot }
    });
  } catch {
    // No worker available in this runtime: patching in-thread beats not patching.
    BRIDGE_WORKER_STATE.workerUnavailable = true;
    return inThread();
  }
  // The worker and its answer timer stay referenced: a standalone Node process (daemon, tests) must not exit
  // while a patch is half done or before its answer arrives.
  const timeoutMs = Number(options.timeoutMs) > 0 ? Number(options.timeoutMs) : BRIDGE_PATCH_WORKER_TIMEOUT_MS;
  let workerExited = false;
  const exited = new Promise((resolveExit) => {
    const release = setTimeout(resolveExit, BRIDGE_PATCH_WORKER_QUEUE_RELEASE_MS);
    if (typeof release.unref === 'function') release.unref();
    worker.once('exit', () => {
      workerExited = true;
      clearTimeout(release);
      resolveExit();
    });
  });
  const answer = new Promise((resolve) => {
    let answered = false;
    let gotMessage = false;
    const finish = (reports) => {
      if (answered) return;
      answered = true;
      clearTimeout(timer);
      resolve(reports);
    };
    // The worker could not start or run (init failure, out of memory, or a bridge.js without the worker
    // entry, which exits without a message): patch in-thread once, once its exit guarantees no other writer,
    // and stop trying workers in this process.
    const fallBack = () => {
      if (answered || gotMessage) return;
      // Possibly transient (a half-written bridge.js, one out-of-memory): in-thread for 10 minutes, then retry.
      BRIDGE_WORKER_STATE.workerUnavailableUntil = Date.now() + BRIDGE_WORKER_RETRY_AFTER_FAILURE_MS;
      const runSync = () => {
        if (answered) return;
        try {
          finish(runBridgeJobsSync(list, hubRoot).map((r) => ({ ...r, workerFallback: true })));
        } catch (error) {
          finish(failAll(`bridge patch failed: ${error?.message || error}`, 'EWORKER'));
        }
      };
      if (workerExited) runSync();
      else exited.then(runSync);
    };
    // A timed-out worker is left to finish (terminating it mid-write could truncate a bundle).
    const timer = setTimeout(
      () => finish(failAll(`bridge patch worker still running after ${timeoutMs} ms`, 'ETIMEDOUT')),
      timeoutMs
    );
    worker.once('message', (msg) => {
      gotMessage = true;
      finish(
        Array.isArray(msg?.reports)
          ? msg.reports.map((r) => ({ ...r, viaWorker: true }))
          : failAll('bridge patch worker sent no reports', 'EWORKER')
      );
    });
    worker.once('error', fallBack);
    worker.once('exit', fallBack);
  });
  return { answer, exited };
}

// Same contract as prepatchInstalledExtensions, but the patching runs in a worker thread. The cheap change
// check (a few stat calls) stays here so an unchanged extensions folder never starts a worker. The last good
// signature and the in-flight flag live in BRIDGE_WORKER_STATE, so a hot-swapped copy of this module neither
// repeats a finished run nor starts one beside a running one.
async function prepatchInstalledExtensionsAsync(hubExtensionPath = __dirname, options = {}) {
  const skipped = { checked: false, skipped: true, updatedDirs: [], reports: [], errors: [] };
  const extensionsDir = options.extensionsDir || getDefaultExtensionsDir();
  if (!fs.existsSync(extensionsDir)) {
    return skipped;
  }
  const state = BRIDGE_WORKER_STATE;
  const hubRoot = hubExtensionPath || __dirname;
  const hubBridgeMtime = Math.max(
    safeStatMtimeMs(__filename),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'claude-webview-patches.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'antigravity-hub-bridge.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'antigravity-context-window.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'claude-hub-bridge.cjs')),
    safeStatMtimeMs(path.join(hubRoot, 'compat', 'excel-preview.cjs'))
  );
  const sig = `${path.resolve(extensionsDir)}|${safeStatMtimeMs(extensionsDir)}|${safeStatMtimeMs(
    path.join(extensionsDir, 'extensions.json')
  )}|${hubBridgeMtime}`;
  if (!state.lastPrepatchSigs) state.lastPrepatchSigs = {};
  const sigKey = path.resolve(extensionsDir);
  if ((!options.force && state.lastPrepatchSigs[sigKey] === sig) || state.prepatchInFlight) {
    return skipped;
  }
  state.prepatchInFlight = true;
  try {
    const jobs = [
      ...findInstalledAntigravityExtensions(extensionsDir, null).map((dir) => ({ provider: 'antigravity', dir })),
      ...findInstalledClaudeExtensions(extensionsDir, null).map((dir) => ({ provider: 'claude', dir }))
    ];
    const reports = await runBridgeJobsInWorker(jobs, hubRoot, options);
    const updatedDirs = [];
    const errors = [];
    let sawTransientIncomplete = false;
    for (const res of reports) {
      if (res.reason === 'missing-bundle') {
        sawTransientIncomplete = true;
      } else if (res.error) {
        errors.push(res);
        if (TRANSIENT_PATCH_ERROR_CODES.has(String(res.code || ''))) {
          sawTransientIncomplete = true;
        }
      } else if (res.updated) {
        updatedDirs.push(res.extensionDir);
      }
    }
    if (!sawTransientIncomplete && errors.length === 0) {
      state.lastPrepatchSigs[sigKey] = sig;
    }
    return { checked: true, skipped: false, updatedDirs, reports, errors };
  } finally {
    state.prepatchInFlight = false;
  }
}

async function queryActiveBridgeStatus(vscodeApi = vscode) {
  let agyStatus = { active: false };
  let claudeStatus = { active: false };
  try {
    const res = await vscodeApi?.commands?.executeCommand?.('antigravityHub.bridgeStatus');
    if (res && res.active) {
      agyStatus = res;
    }
  } catch {}
  try {
    const res = await vscodeApi?.commands?.executeCommand?.('antigravityHub.claudeBridgeStatus');
    if (res && res.active) {
      claudeStatus = res;
    }
  } catch {}
  return {
    active: Boolean(agyStatus.active || claudeStatus.active),
    antigravityActive: Boolean(agyStatus.active),
    claudeActive: Boolean(claudeStatus.active),
    antigravity: agyStatus,
    claude: claudeStatus
  };
}

function getBundleStatSignature(extensionDir) {
  if (!extensionDir) {
    return 'none';
  }
  const bPath = path.join(extensionDir, 'extension.js');
  const pPath = path.join(extensionDir, 'package.json');
  return `${safeStatMtimeMs(bPath)}:${safeStatMtimeMs(pPath)}`;
}

function isClaudeAccountSignedIn(options = {}) {
  if (typeof options.claudeSignedIn === 'boolean') {
    return options.claudeSignedIn;
  }
  const hasExplicitVaultOpts = Boolean(options.vaultPath || options.claudeHomeDir);
  if (!options.isRealHostRun && !hasExplicitVaultOpts) {
    return true;
  }
  try {
    const claudeHome = options.claudeHomeDir || path.join(os.homedir(), '.claude');
    const vaultFile = options.vaultPath || path.join(claudeHome, '.theo-accounts-vault.json');
    if (fs.existsSync(vaultFile)) {
      const vault = JSON.parse(fs.readFileSync(vaultFile, 'utf8'));
      const claudeList = Array.isArray(vault?.accounts?.claude)
        ? vault.accounts.claude.filter(
            (a) => a && typeof a.email === 'string' && a.email.includes('@')
          )
        : [];
      if (claudeList.length > 0) {
        return true;
      }
      if (vault?.signedOut?.claude) {
        return false;
      }
    }
    const credsFile = path.join(claudeHome, '.credentials.json');
    if (fs.existsSync(credsFile)) {
      const creds = JSON.parse(fs.readFileSync(credsFile, 'utf8'));
      if (creds?.claudeAiOauth?.accessToken) {
        return true;
      }
    }
    return false;
  } catch {
    return true;
  }
}

async function ensureAntigravityBridgeInstalled(context, options = {}) {
  const vscodeApi = options.vscodeApi || vscode;
  const hubExtensionPath = context?.extensionPath || __dirname;
  const agyTargets = Array.isArray(options.agyTargets)
    ? options.agyTargets
    : findInstalledAntigravityExtensions(options.extensionsDir, vscodeApi);
  const claudeTargets = Array.isArray(options.claudeTargets)
    ? options.claudeTargets
    : findInstalledClaudeExtensions(options.extensionsDir, vscodeApi);
  // Patched in a worker thread (see runBridgeJobsInWorker); `patchInThread: true` keeps the old in-thread path.
  const reports = await runBridgeJobsInWorker(
    [
      ...agyTargets.map((dir) => ({ provider: 'antigravity', dir })),
      ...claudeTargets.map((dir) => ({ provider: 'claude', dir }))
    ],
    hubExtensionPath,
    { inThread: options.patchInThread === true }
  );

  const liveStatus = await queryActiveBridgeStatus(vscodeApi);
  const hasExtensionsApi = typeof vscodeApi?.extensions?.getExtension === 'function';
  const activeAgyExt = hasExtensionsApi
    ? vscodeApi.extensions.getExtension('google.google-antigravity') || null
    : null;
  const activeClaudeExt = hasExtensionsApi
    ? vscodeApi.extensions.getExtension('anthropic.claude-code') || null
    : null;

  // Match the extension version actually loaded in THIS VS Code window (falling back to highest version
  // when running standalone or before discovery). Background-downloaded future versions are silently
  // pre-patched above without prompting a reload in a window that is still running the active version.
  const activeAgyDir = activeAgyExt?.extensionPath || agyTargets[0] || '';
  const activeClaudeDir = activeClaudeExt?.extensionPath || claudeTargets[0] || '';
  const activeAgyReport = activeAgyDir
    ? reports.find(
        (item) =>
          item.provider === 'antigravity' &&
          path.resolve(item.extensionDir) === path.resolve(activeAgyDir)
      )
    : null;
  const activeClaudeReport = activeClaudeDir
    ? reports.find(
        (item) =>
          item.provider === 'claude' &&
          path.resolve(item.extensionDir) === path.resolve(activeClaudeDir)
      )
    : null;

  // Only Extension Host bundle / package.json changes require a window reload;
  // webview/index.js is read per-panel from disk and compat/*.cjs hot-swaps in memory.
  const agyHostUpdated = Boolean(activeAgyReport?.bundleUpdated || activeAgyReport?.pkgUpdated);
  const claudeHostUpdated = Boolean(
    activeClaudeReport?.bundleUpdated || activeClaudeReport?.pkgUpdated
  );

  // Never misdiagnose a not-yet-activated extension (!ext.isActive) as an unpatched loaded bundle!
  const agyLoadedUnpatched = Boolean(
    activeAgyReport?.installed &&
      !liveStatus.antigravityActive &&
      (!hasExtensionsApi || (activeAgyExt && activeAgyExt.isActive))
  );
  const claudeLoadedUnpatched = Boolean(
    activeClaudeReport?.installed &&
      !liveStatus.claudeActive &&
      (!hasExtensionsApi || (activeClaudeExt && activeClaudeExt.isActive))
  );

  const isRealHostRun =
    !options.extensionsDir &&
    !options.agyTargets &&
    !options.claudeTargets &&
    vscodeApi === vscode;
  const claudeSignedIn = isClaudeAccountSignedIn({ ...options, isRealHostRun });

  const needsAgyReload = Boolean(agyHostUpdated || agyLoadedUnpatched);
  const needsClaudeReload = Boolean(
    claudeSignedIn && (claudeHostUpdated || claudeLoadedUnpatched)
  );
  const needsReload = Boolean(needsAgyReload || needsClaudeReload);

  // Surface errors from either the active target or the newest downloaded version
  const newestAgyReport = agyTargets[0]
    ? reports.find((item) => item.provider === 'antigravity' && item.extensionDir === agyTargets[0])
    : null;
  const newestClaudeReport = claudeTargets[0]
    ? reports.find((item) => item.provider === 'claude' && item.extensionDir === claudeTargets[0])
    : null;
  // A worker still running at the caller's timeout is not a patch failure: it finishes on its own and the
  // next maintenance pass sees the result, so it never raises the "could not patch" warning.
  const errorCandidates = new Set(
    [activeAgyReport, activeClaudeReport, newestAgyReport, newestClaudeReport].filter(
      (r) => Boolean(r?.error) && r.code !== 'ETIMEDOUT'
    )
  );
  const primaryErrors = [...errorCandidates];

  for (const errReport of primaryErrors) {
    console.error(
      `[THEO bridge] Failed to patch ${errReport.provider} (${errReport.extensionDir}): ${errReport.error}`
    );
  }

  let promptShown = false;
  let promptSuppressed = false;
  if (needsReload && options.promptReload && vscodeApi?.window?.showInformationMessage) {
    const reloadStampPath =
      typeof options.reloadStampPath === 'string'
        ? options.reloadStampPath
        : isRealHostRun
          ? path.join(os.homedir(), '.claude', '.theo-reload-prompt-stamp.json')
          : '';
    const cooldownMs =
      typeof options.reloadPromptCooldownMs === 'number'
        ? options.reloadPromptCooldownMs
        : 2 * 60 * 60 * 1000;
    const keyParts = [];
    if (needsAgyReload) {
      keyParts.push(`agy:${path.resolve(activeAgyDir)}:${getBundleStatSignature(activeAgyDir)}`);
    }
    if (needsClaudeReload) {
      keyParts.push(
        `claude:${path.resolve(activeClaudeDir)}:${getBundleStatSignature(activeClaudeDir)}`
      );
    }
    const promptKey = keyParts.join('|');

    if (reloadStampPath && promptKey && !options.forcePromptReload) {
      try {
        if (fs.existsSync(reloadStampPath)) {
          const prev = JSON.parse(fs.readFileSync(reloadStampPath, 'utf8'));
          if (
            prev &&
            prev.key === promptKey &&
            Date.now() - Number(prev.promptedAt || 0) < cooldownMs
          ) {
            promptSuppressed = true;
          }
        }
      } catch {}
    }

    if (!promptSuppressed) {
      if (reloadStampPath && promptKey) {
        try {
          fs.mkdirSync(path.dirname(reloadStampPath), { recursive: true });
          fs.writeFileSync(
            reloadStampPath,
            JSON.stringify({ key: promptKey, promptedAt: Date.now() }),
            'utf8'
          );
        } catch {}
      }
      const targetLabel =
        needsAgyReload && needsClaudeReload
          ? 'Antigravity & Claude Code session bridges'
          : needsAgyReload
            ? 'Antigravity session bridge'
            : 'Claude Code session bridge';
      promptShown = true;
      const choice = await vscodeApi.window.showInformationMessage(
        `THEO updated the ${targetLabel}. Reload the window to activate.`,
        'Reload Window'
      );
      if (choice === 'Reload Window') {
        await vscodeApi.commands.executeCommand('workbench.action.reloadWindow');
      }
    }
  } else if (
    !needsReload &&
    primaryErrors.length > 0 &&
    options.promptReload &&
    vscodeApi?.window?.showWarningMessage
  ) {
    const failedProviders = primaryErrors.map((r) => r.provider).join(', ');
    vscodeApi.window
      .showWarningMessage(
        `THEO could not patch the newly updated ${failedProviders} bundle (${primaryErrors[0].error}).`
      )
      .then(
        () => {},
        () => {}
      );
  }

  return {
    active: Boolean(liveStatus.active),
    antigravityActive: Boolean(liveStatus.antigravityActive),
    claudeActive: Boolean(liveStatus.claudeActive),
    claudeSignedIn,
    agyHostUpdated,
    claudeHostUpdated,
    needsReload,
    needsAgyReload,
    needsClaudeReload,
    promptShown,
    promptSuppressed,
    errors: primaryErrors,
    liveStatus,
    reports
  };
}

module.exports = {
  BRIDGE_MARKER,
  PERSISTENT_HUB_MARKER,
  CLAUDE_BRIDGE_MARKER,
  BRIDGE_STAMP_VERSION,
  getBridgePatchDigest,
  isClaudeAccountSignedIn,
  findInstalledAntigravityExtensions,
  findInstalledClaudeExtensions,
  patchAntigravityExtensionSource,
  patchClaudeExtensionSource,
  patchClaudeWebviewSource,
  prepatchInstalledExtensions,
  prepatchInstalledExtensionsAsync,
  runBridgeJobsInWorker,
  isBridgePatchWorkerBusy,
  writeFileAtomicSync,
  ensureBridgeInstalledForExtensionDir,
  ensureClaudeBridgeInstalledForExtensionDir,
  queryActiveBridgeStatus,
  ensureAntigravityBridgeInstalled
};

// Worker entry: runBridgeJobsInWorker starts this file with `isTheoBridgePatchWorker`.
try {
  const wt = require('worker_threads');
  if (!wt.isMainThread && wt.workerData && wt.workerData.isTheoBridgePatchWorker) {
    let reports;
    try {
      reports = runBridgeJobsSync(wt.workerData.jobs, wt.workerData.hubRoot);
    } catch (error) {
      reports = (wt.workerData.jobs || []).map(({ provider, dir }) => ({
        installed: false,
        updated: false,
        extensionDir: dir,
        provider,
        error: error?.message || String(error),
        code: 'EWORKER'
      }));
    }
    wt.parentPort.postMessage({ reports });
  }
} catch {}

