# Deploys Option A: THEO Cloudflare Edge WebSocket Relay ($0 Workers Free Plan + SQLite Durable Objects)
# Automatically derives AUTH_TOKEN from remote-relay.json and publishes the live wss:// URL to all devices via Cloud Relay!
$ErrorActionPreference = 'Stop'

$relayDir = $PSScriptRoot
$hubRoot = Split-Path -Parent $relayDir
$nodeDir = Join-Path $HOME '.local\node'
if (Test-Path (Join-Path $nodeDir 'node.exe')) {
  $env:PATH = "$nodeDir;$env:PATH"
}

$npxExe = (Get-Command npx.cmd -ErrorAction SilentlyContinue).Source
if (-not $npxExe) { $npxExe = (Get-Command npx -ErrorAction SilentlyContinue).Source }
if (-not $npxExe) {
  throw "npx not found. Run install.ps1 first to bootstrap portable Node.js."
}

$nodeExe = (Get-Command node.exe -ErrorAction SilentlyContinue).Source
if (-not $nodeExe) { $nodeExe = Join-Path $nodeDir 'node.exe' }

Write-Host "=== 1. Checking Cloudflare Wrangler Authentication ===" -ForegroundColor Cyan
$ErrorActionPreference = 'Continue'
$whoami = & $npxExe --yes wrangler whoami 2>&1 | Out-String
if ($whoami -match 'not authenticated|Please run `wrangler login`') {
  Write-Host "Opening Cloudflare browser login (free Workers plan, `$0/month)..." -ForegroundColor Yellow
  & $npxExe --yes wrangler login
}

Write-Host "=== 2. Deploying THEO Edge WebSocket Relay Durable Object ===" -ForegroundColor Cyan
Push-Location $relayDir
try {
  $env:CI = 'true'
  $deployOut = & $npxExe --yes wrangler deploy 2>&1 | Out-String
  Write-Host $deployOut
} finally {
  Pop-Location
}
$ErrorActionPreference = 'Stop'

$workerHttpsUrl = ''
if ($deployOut -match '(https://theo-edge-relay\.[a-zA-Z0-9_-]+\.workers\.dev)') {
  $workerHttpsUrl = $Matches[1]
}
if (-not $workerHttpsUrl) {
  throw "Could not parse deployed *.workers.dev URL from wrangler output."
}
$wssUrl = ($workerHttpsUrl -replace '^https://', 'wss://') + '/ws'

Write-Host "=== 3. Binding Derived AUTH_TOKEN Secret & Broadcasting wss:// URL to All Devices ===" -ForegroundColor Cyan
$cfgPath = Join-Path $hubRoot 'remote-relay.json'
$authToken = & $nodeExe -e "const fs=require('fs'),crypto=require('crypto');const c=JSON.parse(fs.readFileSync(process.argv[1],'utf8'));const k=Buffer.from(c.k,'base64').toString('utf8').trim();process.stdout.write(crypto.createHash('sha256').update('theo-edge-v1:'+k,'utf8').digest('hex'));" $cfgPath

Push-Location $relayDir
try {
  $ErrorActionPreference = 'Continue'
  $authToken | & $npxExe --yes wrangler secret put AUTH_TOKEN 2>&1 | Out-Null
  $ErrorActionPreference = 'Stop'
} finally {
  Pop-Location
}

# Save edgeUrl locally and publish to bhf_theo_remote_control_store so iPhone PWA & sibling PCs auto-connect!
& $nodeExe -e "
const fs = require('fs');
const https = require('https');
const path = require('path');
const { updateDeviceConfig } = require(process.argv[1]);
const cfgPath = process.argv[2];
const wssUrl = process.argv[3];

updateDeviceConfig({ edgeRelayUrl: wssUrl });
const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
cfg.edgeUrl = wssUrl;
fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2), 'utf8');

const relayUrl = Buffer.from(cfg.u, 'base64').toString('utf8').trim();
const relayKey = Buffer.from(cfg.k, 'base64').toString('utf8').trim();
const u = new URL(relayUrl);
const body = JSON.stringify({
  key: relayKey,
  op: 'patch',
  ackOnly: true,
  patch: { edge_relay: { url: wssUrl, updatedAt: new Date().toISOString() } }
});
const req = https.request({
  hostname: u.hostname,
  port: u.port || 443,
  path: u.pathname + u.search,
  method: 'POST',
  headers: { 'Content-Type': 'text/plain;charset=UTF-8', 'Content-Length': Buffer.byteLength(body) }
}, (res) => { res.resume(); console.log('[OK] Broadcasted Edge Relay URL to all devices (HTTP ' + res.statusCode + ')'); });
req.write(body);
req.end();
" (Join-Path $hubRoot 'device-identity.js') $cfgPath $wssUrl

# Nudge local :4318 bridge if running
try {
  Invoke-RestMethod -Uri "http://127.0.0.1:4318/api/edge-config" -Method Post -ContentType "application/json" -Body (@{ edgeRelayUrl = $wssUrl } | ConvertTo-Json) -TimeoutSec 4 | Out-Null
} catch {}

Write-Host ""
Write-Host "=== SUCCESS! THEO Cloudflare Edge Relay is LIVE at: $wssUrl ===" -ForegroundColor Green
Write-Host "Every connected PC and your THEO PWA on iPhone/Web will auto-discover it immediately!" -ForegroundColor Cyan
