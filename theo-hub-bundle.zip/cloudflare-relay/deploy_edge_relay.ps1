# Deploys THEO Cloudflare Edge WebSocket Relay v2 (Cloudflare Workers Paid + SQLite Durable Objects)
# Derives AUTH_TOKEN strictly from ~/.theo/credentials.json (outside git), uploads secret BEFORE deploy, and updates local config.
$ErrorActionPreference = 'Stop'

$relayDir = $PSScriptRoot
$hubRoot = Split-Path -Parent $relayDir
$nodeDir = Join-Path $HOME '.local\node'
if (Test-Path (Join-Path $nodeDir 'node.exe')) {
  $env:PATH = "$nodeDir;$env:PATH"
}

$npxExe = (Get-Command npx.cmd -ErrorAction SilentlyContinue).Source
if (-not $npxExe) { $npxExe = (Get-Command npx -ErrorAction SilentlyContinue).Source }
if (-not $npxExe) {
  throw "npx not found. Run install.ps1 first to bootstrap portable Node.js."
}

$nodeExe = (Get-Command node.exe -ErrorAction SilentlyContinue).Source
if (-not $nodeExe) { $nodeExe = Join-Path $nodeDir 'node.exe' }

Write-Host "=== 1. Checking Cloudflare Wrangler Authentication ===" -ForegroundColor Cyan
$prevEap = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$whoami = & $npxExe --yes wrangler whoami 2>&1 | Out-String
$ErrorActionPreference = $prevEap
if ($whoami -match 'not authenticated|Please run `wrangler login`') {
  Write-Host "Opening Cloudflare browser login..." -ForegroundColor Yellow
  & $npxExe --yes wrangler login
}

$devIdJs = Join-Path $hubRoot 'device-identity.js'
$authToken = & $nodeExe -e "const crypto=require('crypto');const {loadTheoCredentials,saveTheoCredentials,deriveEdgeAuthToken}=require(process.argv[1]);let c=loadTheoCredentials();if(!c.edgeAccessKey||c.edgeAccessKey.length<64){c=saveTheoCredentials({edgeAccessKey:crypto.randomBytes(32).toString('hex')});}process.stdout.write(deriveEdgeAuthToken(c.edgeAccessKey));" $devIdJs
if (-not $authToken -or $authToken.Length -lt 64) {
  throw "Failed to derive 64-hex AUTH_TOKEN from ~/.theo/credentials.json"
}

Write-Host "=== 2. Uploading Dedicated AUTH_TOKEN Secret (Pre-Deploy, Zero TOFU Window) ===" -ForegroundColor Cyan
Push-Location $relayDir
try {
  $env:CI = 'true'
  $prevEap = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  $secOut = $authToken | & $npxExe --yes wrangler secret put AUTH_TOKEN 2>&1 | Out-String
  $secCode = $LASTEXITCODE
  $ErrorActionPreference = $prevEap
  if ($secCode -ne 0 -and $secOut -notmatch 'Creating the secret|Success') {
    Write-Host $secOut -ForegroundColor Yellow
  }
} finally {
  Pop-Location
}

Write-Host "=== 3. Deploying THEO Edge WebSocket Relay v2 Durable Object ===" -ForegroundColor Cyan
Push-Location $relayDir
try {
  $env:CI = 'true'
  $prevEap = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  $deployOut = & $npxExe --yes wrangler deploy 2>&1 | Out-String
  $deployCode = $LASTEXITCODE
  $ErrorActionPreference = $prevEap
  Write-Host $deployOut
  if ($deployCode -ne 0) {
    throw "wrangler deploy exited with code $deployCode"
  }
} finally {
  Pop-Location
}

$workerHttpsUrl = ''
if ($deployOut -match '(https://theo-edge-relay\.[a-zA-Z0-9_-]+\.workers\.dev)') {
  $workerHttpsUrl = $Matches[1]
}
if (-not $workerHttpsUrl) {
  throw "Could not parse deployed *.workers.dev URL from wrangler output."
}
$wssUrl = ($workerHttpsUrl -replace '^https://', 'wss://') + '/ws'

& $nodeExe -e "
const https = require('https');
const { updateDeviceConfig, loadTheoCredentials, saveTheoCredentials } = require(process.argv[1]);
const wssUrl = process.argv[2];
// Read the store address BEFORE saving the relay address: a host's store address is derived from its relay, so after
// the save it already points at the new relay. The move has to be announced in the store the hosts are polling now.
const creds = loadTheoCredentials();
updateDeviceConfig({ edgeRelayUrl: wssUrl });
saveTheoCredentials({ edgeRelayUrl: wssUrl });
if (creds.cloudUrl && creds.cloudKey) {
  const u = new URL(creds.cloudUrl);
  const body = JSON.stringify({
    key: creds.cloudKey,
    op: 'patch',
    ackOnly: true,
    patch: { edge_relay: { url: wssUrl, updatedAt: new Date().toISOString() } }
  });
  const req = https.request({
    hostname: u.hostname,
    port: u.port || 443,
    path: u.pathname + u.search,
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=UTF-8', 'Content-Length': Buffer.byteLength(body) }
  }, (res) => { res.resume(); console.log('[OK] Published Edge Relay URL (HTTP ' + res.statusCode + ')'); });
  req.on('error', () => {});
  req.write(body);
  req.end();
}
" $devIdJs $wssUrl

Write-Host ""
Write-Host "=== SUCCESS! THEO Cloudflare Edge Relay v2 is LIVE at: $wssUrl ===" -ForegroundColor Green
