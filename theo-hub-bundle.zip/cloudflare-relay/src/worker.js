// Worker entry: store paths go to the THEO Store Durable Object, everything else to the unchanged Edge WebSocket relay.
import relay, { TheoRelayRoom } from "./index.js";
import { TheoStoreRoom, routeStoreRequest } from "./store.js";

export { TheoRelayRoom, TheoStoreRoom };

export default {
  async fetch(request, env, ctx) {
    const storeResponse = routeStoreRequest(request, env);
    if (storeResponse) return storeResponse;
    return relay.fetch(request, env, ctx);
  }
};
