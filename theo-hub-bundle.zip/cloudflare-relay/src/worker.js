// Worker entry: release coordinator paths go to IsabiReleaseRoom, store paths go to THEO Store,
// everything else goes to the unchanged Edge WebSocket relay.
import relay, { TheoRelayRoom } from "./index.js";
import { TheoStoreRoom, routeStoreRequest } from "./store.js";
import { IsabiReleaseRoom, routeReleaseRequest } from "./release.js";

export { TheoRelayRoom, TheoStoreRoom, IsabiReleaseRoom };

export default {
  async fetch(request, env, ctx) {
    const releaseResponse = routeReleaseRequest(request, env);
    if (releaseResponse) return releaseResponse;
    const storeResponse = routeStoreRequest(request, env);
    if (storeResponse) return storeResponse;
    return relay.fetch(request, env, ctx);
  }
};
