// THEO Edge WebSocket Relay — Cloudflare Worker + SQLite Durable Object with WebSocket Hibernation ($0 Free Plan)
// Routes <25ms live stream_delta frames, multi-device presence, and targeted RPC commands between THEO Studio PWAs and theo-agent hosts.

import { DurableObject } from "cloudflare:workers";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Theo-Token"
};

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }
    const url = new URL(request.url);
    if (url.pathname === "/health" || url.pathname === "/api/ping") {
      return new Response(
        JSON.stringify({
          ok: true,
          service: "THEO Cloudflare Edge Relay",
          hibernation: true,
          ts: Date.now()
        }),
        {
          status: 200,
          headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
        }
      );
    }

    // Single global Durable Object room keyed by "theo-fleet-v1"
    const id = env.THEO_ROOM.idFromName("theo-fleet-v1");
    const stub = env.THEO_ROOM.get(id);
    return stub.fetch(request);
  }
};

export class TheoRelayRoom extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx = ctx;
    this.env = env;
    this.sql = ctx.storage.sql;
    this.hostSnapshots = new Map();
    this._initSchema();
  }

  _initSchema() {
    this.sql.exec(`
      CREATE TABLE IF NOT EXISTS devices (
        id TEXT PRIMARY KEY,
        name TEXT,
        role TEXT,
        hostname TEXT,
        platform TEXT,
        capabilities TEXT,
        online INTEGER DEFAULT 0,
        last_seen INTEGER DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS kv (
        k TEXT PRIMARY KEY,
        v TEXT
      );
    `);
  }

  _verifyToken(candidate) {
    const clean = String(candidate || "").trim();
    if (!clean || clean.length < 32) return false;
    const expected = String(this.env.AUTH_TOKEN || "").trim();
    if (expected) {
      return clean === expected;
    }
    // First-boot Trust-On-First-Use if AUTH_TOKEN secret was not pre-seeded via wrangler secret
    const rows = [...this.sql.exec("SELECT v FROM kv WHERE k = 'tofu_token'")];
    if (rows.length === 0) {
      this.sql.exec("INSERT OR REPLACE INTO kv (k, v) VALUES ('tofu_token', ?)", clean);
      return true;
    }
    return rows[0].v === clean;
  }

  _upsertDevice(dev, online = true) {
    if (!dev || !dev.id) return;
    const caps = JSON.stringify(Array.isArray(dev.capabilities) ? dev.capabilities : []);
    this.sql.exec(
      `INSERT INTO devices (id, name, role, hostname, platform, capabilities, online, last_seen)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         name = excluded.name,
         role = excluded.role,
         hostname = excluded.hostname,
         platform = excluded.platform,
         capabilities = excluded.capabilities,
         online = excluded.online,
         last_seen = excluded.last_seen`,
      String(dev.id),
      String(dev.name || dev.id),
      String(dev.role || "secondary"),
      String(dev.hostname || ""),
      String(dev.platform || ""),
      caps,
      online ? 1 : 0,
      Date.now()
    );
  }

  _getDevicesList() {
    const liveHostIds = new Set();
    for (const ws of this.ctx.getWebSockets("host")) {
      const att = ws.deserializeAttachment() || {};
      if (att.authenticated && att.deviceId) {
        liveHostIds.add(att.deviceId);
      }
    }
    const rows = [...this.sql.exec("SELECT * FROM devices ORDER BY role ASC, last_seen DESC")];
    return rows.map((r) => {
      let caps = [];
      try {
        caps = JSON.parse(r.capabilities || "[]");
      } catch {}
      const isOnline = liveHostIds.has(r.id);
      return {
        id: r.id,
        name: r.name,
        role: r.role,
        hostname: r.hostname,
        platform: r.platform,
        capabilities: caps,
        online: isOnline,
        lastSeen: Number(r.last_seen || 0)
      };
    });
  }

  _broadcastToTag(tag, obj, filterFn = null) {
    const payload = typeof obj === "string" ? obj : JSON.stringify(obj);
    for (const ws of this.ctx.getWebSockets(tag)) {
      const att = ws.deserializeAttachment() || {};
      if (!att.authenticated) continue;
      if (filterFn && !filterFn(att, ws)) continue;
      try {
        ws.send(payload);
      } catch {}
    }
  }

  _broadcastDevicesPresence() {
    const devices = this._getDevicesList();
    const frame = JSON.stringify({ type: "devices_presence", devices, ts: Date.now() });
    this._broadcastToTag("client", frame);
    this._broadcastToTag("host", frame);
  }

  async fetch(request) {
    const upgradeHeader = request.headers.get("Upgrade") || "";
    if (upgradeHeader.toLowerCase() !== "websocket") {
      return new Response(
        JSON.stringify({ ok: true, devices: this._getDevicesList() }),
        { status: 200, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }

    const url = new URL(request.url);
    const role = url.searchParams.get("role") === "host" ? "host" : "client";
    const deviceId = String(url.searchParams.get("deviceId") || "").trim();
    const connId = crypto.randomUUID();

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    this.ctx.acceptWebSocket(server, [role]);
    server.serializeAttachment({
      connId,
      role,
      deviceId,
      authenticated: false,
      connectedAt: Date.now()
    });

    return new Response(null, { status: 101, webSocket: client });
  }

  async webSocketMessage(ws, message) {
    let msg;
    try {
      msg = JSON.parse(typeof message === "string" ? message : new TextDecoder().decode(message));
    } catch {
      return;
    }
    if (!msg || typeof msg !== "object") return;

    if (msg.type === "ping") {
      ws.send(JSON.stringify({ type: "pong", ts: Date.now(), echoTs: msg.ts || 0 }));
      return;
    }

    const att = ws.deserializeAttachment() || {};

    // 1. Authenticate Host (theo-agent / VS Code bridge)
    if (msg.type === "auth_host") {
      if (!this._verifyToken(msg.token)) {
        ws.send(JSON.stringify({ type: "auth_err", error: "Invalid edge relay token" }));
        ws.close(4001, "Unauthorized");
        return;
      }
      const dev = msg.device || {};
      const devId = String(dev.id || att.deviceId || "host-default").trim();
      ws.serializeAttachment({
        ...att,
        role: "host",
        deviceId: devId,
        deviceName: String(dev.name || devId),
        authenticated: true
      });
      this._upsertDevice({ ...dev, id: devId }, true);
      const devices = this._getDevicesList();
      ws.send(JSON.stringify({ type: "auth_ok", role: "host", deviceId: devId, devices }));
      this._broadcastDevicesPresence();
      return;
    }

    // 2. Authenticate PWA Client
    if (msg.type === "auth_client") {
      if (!this._verifyToken(msg.token)) {
        ws.send(JSON.stringify({ type: "auth_err", error: "Invalid edge relay token" }));
        ws.close(4001, "Unauthorized");
        return;
      }
      ws.serializeAttachment({
        ...att,
        role: "client",
        authenticated: true
      });
      const devices = this._getDevicesList();
      ws.send(
        JSON.stringify({
          type: "auth_ok",
          role: "client",
          connId: att.connId,
          devices,
          cachedSnapshots: Object.fromEntries(this.hostSnapshots.entries())
        })
      );
      // Ask online hosts to push fresh snapshots
      this._broadcastToTag("host", { type: "request_sync", ts: Date.now() });
      return;
    }

    if (!att.authenticated) {
      ws.send(JSON.stringify({ type: "auth_err", error: "Authenticate first" }));
      return;
    }

    // 3. Host -> Clients: State Snapshot or <25ms Stream Delta
    if (att.role === "host") {
      if (msg.type === "host_state") {
        if (msg.device) {
          this._upsertDevice(msg.device, true);
        }
        if (att.deviceId && msg.snapshot) {
          this.hostSnapshots.set(att.deviceId, {
            deviceId: att.deviceId,
            deviceName: att.deviceName || msg.deviceName || att.deviceId,
            snapshot: msg.snapshot,
            updatedAt: Date.now()
          });
        }
        this._broadcastToTag("client", msg);
        this._broadcastToTag("host", msg, (hAtt) => hAtt.deviceId !== att.deviceId);
        return;
      }

      if (msg.type === "stream_delta" || msg.type === "thread_detail") {
        this._broadcastToTag("client", msg);
        this._broadcastToTag("host", msg, (hAtt) => hAtt.deviceId !== att.deviceId);
        return;
      }

      if (msg.type === "rpc_res") {
        const targetConnId = msg.clientConnId || "";
        this._broadcastToTag("client", msg, (cAtt) => !targetConnId || cAtt.connId === targetConnId);
        if (targetConnId) {
          this._broadcastToTag("host", msg, (hAtt) => hAtt.connId === targetConnId);
        }
        return;
      }
      if (msg.type === "rpc_cmd") {
        // Peer host forwarding RPC to another host
        const targetId = String(msg.targetDeviceId || "").trim();
        const enriched = { ...msg, clientConnId: att.connId };
        let sentCount = 0;
        for (const hostWs of this.ctx.getWebSockets("host")) {
          const hAtt = hostWs.deserializeAttachment() || {};
          if (!hAtt.authenticated || hAtt.connId === att.connId) continue;
          if (targetId && targetId !== "auto" && hAtt.deviceId !== targetId) continue;
          try {
            hostWs.send(JSON.stringify(enriched));
            sentCount += 1;
            if (targetId === "auto") break;
          } catch {}
        }
        if (sentCount === 0 && msg.reqId) {
          ws.send(
            JSON.stringify({
              type: "rpc_res",
              reqId: msg.reqId,
              ok: false,
              error: `Device "${targetId || "peer"}" is currently offline.`
            })
          );
        }
        return;
      }
      return;
    }

    // 4. PWA Client -> Target Host(s): RPC Command (send, stop, approve, getThread, getWorkspace)
    if (att.role === "client") {
      if (msg.type === "rpc_cmd") {
        const targetId = String(msg.targetDeviceId || "auto").trim();
        let sentCount = 0;
        const enriched = {
          ...msg,
          clientConnId: att.connId
        };
        for (const hostWs of this.ctx.getWebSockets("host")) {
          const hAtt = hostWs.deserializeAttachment() || {};
          if (!hAtt.authenticated) continue;
          if (targetId && targetId !== "auto" && hAtt.deviceId !== targetId) continue;
          try {
            hostWs.send(JSON.stringify(enriched));
            sentCount += 1;
            if (targetId === "auto") break; // route auto to first active host
          } catch {}
        }
        if (sentCount === 0 && msg.reqId) {
          ws.send(
            JSON.stringify({
              type: "rpc_res",
              reqId: msg.reqId,
              ok: false,
              error:
                targetId && targetId !== "auto"
                  ? `Device "${targetId}" is currently offline.`
                  : "No THEO host devices are currently online."
            })
          );
        }
      }
    }
  }

  async webSocketClose(ws) {
    this._handleSocketGone(ws);
  }

  async webSocketError(ws) {
    this._handleSocketGone(ws);
  }

  _handleSocketGone(ws) {
    try {
      const att = ws.deserializeAttachment() || {};
      if (att.role === "host" && att.deviceId) {
        // Mark offline only if no other active socket exists for this deviceId
        let otherAlive = false;
        for (const hWs of this.ctx.getWebSockets("host")) {
          if (hWs === ws) continue;
          const hAtt = hWs.deserializeAttachment() || {};
          if (hAtt.authenticated && hAtt.deviceId === att.deviceId) {
            otherAlive = true;
            break;
          }
        }
        if (!otherAlive) {
          this.sql.exec(
            "UPDATE devices SET online = 0, last_seen = ? WHERE id = ?",
            Date.now(),
            att.deviceId
          );
          this._broadcastDevicesPresence();
        }
      }
    } catch {}
  }
}
