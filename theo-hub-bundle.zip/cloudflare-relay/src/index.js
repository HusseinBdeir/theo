// THEO Edge WebSocket Relay v2 — Cloudflare Worker + SQLite Durable Object with WebSocket Hibernation (Cloudflare Workers Paid)
// Fixes: SQLite-persisted host_snapshots across Hibernation, constant-time Bearer/WS auth, zero public device leak,
// single-socket host deduplication, thread-aware 'auto' routing, zombie socket alarm reaping, and <1 MiB frame guards.

import { DurableObject } from "cloudflare:workers";

const ALLOWED_ORIGINS = new Set([
  "https://husseinbdeir.github.io",
  "http://127.0.0.1:4318",
  "http://localhost:4318"
]);

const MAX_WS_FRAME_BYTES = 950 * 1024; // Safe headroom under Cloudflare's 1 MiB (1,048,576 B) hard limit

function buildCorsHeaders(request) {
  const origin = request?.headers?.get("Origin") || "";
  const allowOrigin = ALLOWED_ORIGINS.has(origin) ? origin : "https://husseinbdeir.github.io";
  return {
    "Access-Control-Allow-Origin": allowOrigin,
    "Vary": "Origin",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Theo-Token"
  };
}

async function constantTimeEqualStr(a, b) {
  const enc = new TextEncoder();
  const [da, db] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(String(a || ""))),
    crypto.subtle.digest("SHA-256", enc.encode(String(b || "")))
  ]);
  return crypto.subtle.timingSafeEqual(da, db);
}

export default {
  async fetch(request, env) {
    const cors = buildCorsHeaders(request);
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }
    const url = new URL(request.url);
    if (url.pathname === "/health" || url.pathname === "/api/ping") {
      return new Response(
        JSON.stringify({
          ok: true,
          service: "THEO Cloudflare Edge Relay",
          version: 2.1,
          hibernation: true,
          ts: Date.now()
        }),
        {
          status: 200,
          headers: { ...cors, "Content-Type": "application/json" }
        }
      );
    }

    const roomName = url.pathname.startsWith("/pair/") ? "theo-pair-v1" : "theo-fleet-v2";
    const id = env.THEO_ROOM.idFromName(roomName);
    const stub = env.THEO_ROOM.get(id);
    return stub.fetch(request);
  }
};

export class TheoRelayRoom extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx = ctx;
    this.env = env;
    this.sql = ctx.storage.sql;
    this._initSchema();
  }

  _initSchema() {
    this.sql.exec(`
      CREATE TABLE IF NOT EXISTS devices (
        id TEXT PRIMARY KEY,
        name TEXT,
        role TEXT,
        hostname TEXT,
        platform TEXT,
        capabilities TEXT,
        online INTEGER DEFAULT 0,
        last_seen INTEGER DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS host_snapshots (
        device_id TEXT PRIMARY KEY,
        device_name TEXT,
        snapshot_json TEXT,
        updated_at INTEGER DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS kv (
        k TEXT PRIMARY KEY,
        v TEXT
      );
      CREATE TABLE IF NOT EXISTS pair_codes (
        code_hash TEXT PRIMARY KEY,
        bundle TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL
      );
    `);
  }

  async _hashPairCode(digits) {
    const enc = new TextEncoder().encode(`theo-pair-v1:${String(digits || "").trim()}`);
    const digest = await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }

  _generateUniformSixDigitCode() {
    // 4,294,800,000 is the largest multiple of 900,000 <= 2^32 (zero modulo bias)
    const limit = 4294800000;
    const arr = new Uint32Array(1);
    while (true) {
      crypto.getRandomValues(arr);
      if (arr[0] < limit) {
        return String(100000 + (arr[0] % 900000));
      }
    }
  }

  _getPairFailState(now = Date.now()) {
    try {
      const rows = [...this.sql.exec("SELECT v FROM kv WHERE k = 'pair_fail_state'")];
      if (rows.length > 0 && rows[0].v) {
        const parsed = JSON.parse(rows[0].v);
        const windowStart = Number(parsed?.windowStart || 0);
        const count = Number(parsed?.count || 0);
        if (windowStart > 0 && now - windowStart < 10 * 60 * 1000) {
          return { count, windowStart };
        }
      }
    } catch {}
    return { count: 0, windowStart: now };
  }

  _setPairFailState(count, windowStart = Date.now()) {
    try {
      this.sql.exec(
        `INSERT INTO kv (k, v) VALUES ('pair_fail_state', ?)
         ON CONFLICT(k) DO UPDATE SET v = excluded.v`,
        JSON.stringify({ count: Number(count || 0), windowStart: Number(windowStart || Date.now()) })
      );
    } catch {}
  }

  async _verifyToken(candidate) {
    const clean = String(candidate || "").trim();
    if (!clean || clean.length < 32) return false;
    const expected = String(this.env.AUTH_TOKEN || "").trim();
    if (!expected) {
      return false;
    }
    // Support secondary transition token if configured during rotation
    if (await constantTimeEqualStr(clean, expected)) {
      return true;
    }
    const secondary = String(this.env.AUTH_TOKEN_PREV || "").trim();
    if (secondary && secondary.length >= 32 && (await constantTimeEqualStr(clean, secondary))) {
      return true;
    }
    return false;
  }

  _extractBearerToken(request) {
    const authHdr = String(request.headers.get("Authorization") || "").trim();
    if (/^Bearer\s+/i.test(authHdr)) {
      return authHdr.replace(/^Bearer\s+/i, "").trim();
    }
    return String(request.headers.get("X-Theo-Token") || "").trim();
  }

  _upsertDevice(dev, online = true) {
    if (!dev || !dev.id) return;
    const caps = JSON.stringify(Array.isArray(dev.capabilities) ? dev.capabilities : []);
    this.sql.exec(
      `INSERT INTO devices (id, name, role, hostname, platform, capabilities, online, last_seen)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         name = excluded.name,
         role = excluded.role,
         hostname = excluded.hostname,
         platform = excluded.platform,
         capabilities = excluded.capabilities,
         online = excluded.online,
         last_seen = excluded.last_seen`,
      String(dev.id),
      String(dev.name || dev.id),
      String(dev.role || "secondary"),
      String(dev.hostname || ""),
      String(dev.platform || ""),
      caps,
      online ? 1 : 0,
      Date.now()
    );
  }

  _saveHostSnapshot(deviceId, deviceName, snapshotObj) {
    if (!deviceId || !snapshotObj || typeof snapshotObj !== "object") return;
    try {
      const jsonStr = JSON.stringify(snapshotObj);
      if (jsonStr.length > MAX_WS_FRAME_BYTES - 8192) {
        return;
      }
      this.sql.exec(
        `INSERT INTO host_snapshots (device_id, device_name, snapshot_json, updated_at)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(device_id) DO UPDATE SET
           device_name = excluded.device_name,
           snapshot_json = excluded.snapshot_json,
           updated_at = excluded.updated_at`,
        String(deviceId),
        String(deviceName || deviceId),
        jsonStr,
        Date.now()
      );
    } catch {}
  }

  _getPersistedSnapshots() {
    const out = [];
    try {
      const rows = [
        ...this.sql.exec(
          "SELECT device_id, device_name, snapshot_json, updated_at FROM host_snapshots ORDER BY updated_at DESC"
        )
      ];
      for (const r of rows) {
        if (!r.snapshot_json) continue;
        try {
          out.push({
            deviceId: r.device_id,
            deviceName: r.device_name || r.device_id,
            snapshot: JSON.parse(r.snapshot_json),
            updatedAt: Number(r.updated_at || 0)
          });
        } catch {}
      }
    } catch {}
    return out;
  }

  _findOwnerDeviceForThread(threadId) {
    const cleanTid = String(threadId || "").trim();
    if (!cleanTid) return "";
    try {
      const rows = [
        ...this.sql.exec("SELECT device_id, snapshot_json FROM host_snapshots")
      ];
      for (const r of rows) {
        if (!r.snapshot_json || !r.snapshot_json.includes(cleanTid)) continue;
        try {
          const snap = JSON.parse(r.snapshot_json);
          const hit = Array.isArray(snap?.rows) && snap.rows.some((row) => row && row.id === cleanTid);
          if (hit) return String(r.device_id || "");
        } catch {}
      }
    } catch {}
    return "";
  }

  _getHealthyHostSockets() {
    const now = Date.now();
    const list = [];
    for (const ws of this.ctx.getWebSockets("host")) {
      const att = ws.deserializeAttachment() || {};
      if (!att.authenticated || !att.deviceId) continue;
      const lastActive = Number(att.lastSeenAt || att.connectedAt || 0);
      if (lastActive > 0 && now - lastActive > 110000) {
        // Stale half-open socket without keepalive ping
        try {
          ws.close(4003, "Heartbeat timeout");
        } catch {}
        continue;
      }
      list.push({ ws, att, lastActive });
    }
    list.sort((a, b) => b.lastActive - a.lastActive);
    return list;
  }

  _selectTargetHost(targetId, cmdObj = null, excludeConnId = "") {
    const cleanTarget = String(targetId || "auto").trim() || "auto";
    const hosts = this._getHealthyHostSockets().filter(
      (h) => !excludeConnId || h.att.connId !== excludeConnId
    );
    if (hosts.length === 0) return null;

    if (cleanTarget !== "auto") {
      return hosts.find((h) => h.att.deviceId === cleanTarget) || null;
    }

    const refThreadId = String(
      cmdObj?.threadId || cmdObj?.sessionId || cmdObj?.id || ""
    ).trim();
    if (refThreadId && !refThreadId.startsWith("cmd-") && !refThreadId.startsWith("draft-")) {
      const ownerId = this._findOwnerDeviceForThread(refThreadId);
      if (ownerId) {
        const ownerSock = hosts.find((h) => h.att.deviceId === ownerId);
        if (ownerSock) return ownerSock;
      }
    }

    const primarySock = hosts.find(
      (h) => h.att.deviceRole === "primary" || h.att.deviceId === "main-workstation"
    );
    return primarySock || hosts[0];
  }

  _getDevicesList() {
    const liveHostIds = new Set(this._getHealthyHostSockets().map((h) => h.att.deviceId));
    const rows = [...this.sql.exec("SELECT * FROM devices ORDER BY role ASC, last_seen DESC")];
    return rows.map((r) => {
      let caps = [];
      try {
        caps = JSON.parse(r.capabilities || "[]");
      } catch {}
      const isOnline = liveHostIds.has(r.id);
      return {
        id: r.id,
        name: r.name,
        role: r.role,
        hostname: r.hostname,
        platform: r.platform,
        capabilities: caps,
        online: isOnline,
        lastSeen: Number(r.last_seen || 0)
      };
    });
  }

  _safeSend(ws, objOrStr) {
    try {
      const payload = typeof objOrStr === "string" ? objOrStr : JSON.stringify(objOrStr);
      if (payload.length > MAX_WS_FRAME_BYTES) {
        return false;
      }
      ws.send(payload);
      return true;
    } catch {
      return false;
    }
  }

  _broadcastToTag(tag, obj, filterFn = null) {
    const payload = typeof obj === "string" ? obj : JSON.stringify(obj);
    if (payload.length > MAX_WS_FRAME_BYTES) return;
    for (const ws of this.ctx.getWebSockets(tag)) {
      const att = ws.deserializeAttachment() || {};
      if (!att.authenticated) continue;
      if (filterFn && !filterFn(att, ws)) continue;
      try {
        ws.send(payload);
      } catch {}
    }
  }

  _broadcastDevicesPresence() {
    const devices = this._getDevicesList();
    const frame = JSON.stringify({ type: "devices_presence", devices, ts: Date.now() });
    this._broadcastToTag("client", frame);
    this._broadcastToTag("host", frame);
  }

  async _scheduleCleanupAlarm() {
    try {
      const existing = await this.ctx.storage.getAlarm();
      if (!existing || existing < Date.now() + 2000) {
        await this.ctx.storage.setAlarm(Date.now() + 30000);
      }
    } catch {}
  }

  async alarm() {
    const now = Date.now();
    try {
      this.sql.exec("DELETE FROM pair_codes WHERE expires_at <= ?", now);
    } catch {}
    let changed = false;
    for (const ws of this.ctx.getWebSockets()) {
      const att = ws.deserializeAttachment() || {};
      if (!att.authenticated && now - Number(att.connectedAt || 0) > 15000) {
        try {
          ws.close(4001, "Auth timeout");
        } catch {}
        continue;
      }
      if (att.authenticated && att.role === "host") {
        const lastActive = Number(att.lastSeenAt || att.connectedAt || 0);
        if (lastActive > 0 && now - lastActive > 110000) {
          try {
            ws.close(4003, "Heartbeat timeout");
          } catch {}
          if (att.deviceId) {
            this.sql.exec(
              "UPDATE devices SET online = 0, last_seen = ? WHERE id = ?",
              now,
              att.deviceId
            );
            changed = true;
          }
        }
      }
    }
    if (changed) {
      this._broadcastDevicesPresence();
    }
    if (this.ctx.getWebSockets().length > 0) {
      await this.ctx.storage.setAlarm(Date.now() + 45000);
    } else {
      try {
        const minRows = [
          ...this.sql.exec("SELECT MIN(expires_at) AS min_exp FROM pair_codes")
        ];
        const minExp = Number(minRows[0]?.min_exp || 0);
        if (Number.isFinite(minExp) && minExp > 0) {
          await this.ctx.storage.setAlarm(Math.max(Date.now() + 2000, minExp + 500));
        }
      } catch {}
    }
  }

  async fetch(request) {
    const cors = buildCorsHeaders(request);
    const url = new URL(request.url);
    const upgradeHeader = request.headers.get("Upgrade") || "";

    if (upgradeHeader.toLowerCase() !== "websocket") {
      if (url.pathname === "/devices") {
        const bearer = this._extractBearerToken(request);
        if (!(await this._verifyToken(bearer))) {
          return new Response(
            JSON.stringify({ ok: false, error: "Unauthorized" }),
            { status: 401, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        return new Response(
          JSON.stringify({ ok: true, devices: this._getDevicesList() }),
          { status: 200, headers: { ...cors, "Content-Type": "application/json" } }
        );
      }

      if (url.pathname === "/pair/create" && request.method === "POST") {
        const origin = request.headers.get("Origin") || "";
        if (origin && !ALLOWED_ORIGINS.has(origin)) {
          return new Response(
            JSON.stringify({ ok: false, error: "Forbidden Origin" }),
            { status: 403, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        const bearer = this._extractBearerToken(request);
        if (!(await this._verifyToken(bearer))) {
          return new Response(
            JSON.stringify({ ok: false, error: "Unauthorized" }),
            { status: 401, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        let body = null;
        try {
          const raw = await request.text();
          if (raw.length > 12288) {
            return new Response(
              JSON.stringify({ ok: false, error: "Payload too large" }),
              { status: 413, headers: { ...cors, "Content-Type": "application/json" } }
            );
          }
          body = JSON.parse(raw);
        } catch {
          return new Response(
            JSON.stringify({ ok: false, error: "Invalid JSON" }),
            { status: 400, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        const bundle = String(body?.bundle || "").trim();
        if (!bundle || bundle.length > 8192 || !/^[A-Za-z0-9_=-]+$/.test(bundle)) {
          return new Response(
            JSON.stringify({ ok: false, error: "Invalid pairing bundle" }),
            { status: 400, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        const now = Date.now();
        const ttlSec = Math.min(900, Math.max(60, Number(body?.ttlSec || 600) || 600));
        const expiresAt = now + ttlSec * 1000;
        this.sql.exec("DELETE FROM pair_codes WHERE expires_at <= ?", now);
        // Keep at most 4 older active codes before inserting the new one
        const activeRows = [
          ...this.sql.exec("SELECT code_hash FROM pair_codes ORDER BY created_at DESC")
        ];
        for (const r of activeRows.slice(4)) {
          this.sql.exec("DELETE FROM pair_codes WHERE code_hash = ?", r.code_hash);
        }
        const code = this._generateUniformSixDigitCode();
        const codeHash = await this._hashPairCode(code);
        this.sql.exec(
          `INSERT INTO pair_codes (code_hash, bundle, created_at, expires_at)
           VALUES (?, ?, ?, ?)
           ON CONFLICT(code_hash) DO UPDATE SET
             bundle = excluded.bundle,
             created_at = excluded.created_at,
             expires_at = excluded.expires_at`,
          codeHash,
          bundle,
          now,
          expiresAt
        );
        this._setPairFailState(0, now);
        await this._scheduleCleanupAlarm();
        return new Response(
          JSON.stringify({
            ok: true,
            code,
            formatted: `${code.slice(0, 3)}-${code.slice(3)}`,
            expiresAt,
            ttlSec
          }),
          { status: 200, headers: { ...cors, "Content-Type": "application/json" } }
        );
      }

      if (url.pathname === "/pair/claim" && request.method === "POST") {
        const origin = request.headers.get("Origin") || "";
        if (origin && !ALLOWED_ORIGINS.has(origin)) {
          return new Response(
            JSON.stringify({ ok: false, error: "Forbidden Origin" }),
            { status: 403, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        let body = null;
        try {
          const raw = await request.text();
          if (raw.length > 2048) {
            return new Response(
              JSON.stringify({ ok: false, error: "Payload too large" }),
              { status: 413, headers: { ...cors, "Content-Type": "application/json" } }
            );
          }
          body = JSON.parse(raw);
        } catch {
          return new Response(
            JSON.stringify({ ok: false, error: "Invalid JSON" }),
            { status: 400, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        const digits = String(body?.code || "").replace(/\D+/g, "");
        if (digits.length !== 6) {
          return new Response(
            JSON.stringify({ ok: false, error: "Enter a 6-digit pairing code." }),
            { status: 400, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        const now = Date.now();
        this.sql.exec("DELETE FROM pair_codes WHERE expires_at <= ?", now);
        const failState = this._getPairFailState(now);
        if (failState.count >= 5) {
          this.sql.exec("DELETE FROM pair_codes");
          return new Response(
            JSON.stringify({
              ok: false,
              error: "Too many wrong attempts — generate a fresh 6-digit code on your PC."
            }),
            { status: 429, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        const candidateHash = await this._hashPairCode(digits);
        const rows = [
          ...this.sql.exec("SELECT code_hash, bundle FROM pair_codes WHERE expires_at > ?", now)
        ];
        let matched = null;
        for (const r of rows) {
          if (await constantTimeEqualStr(candidateHash, r.code_hash)) {
            matched = r;
          }
        }
        if (matched) {
          this.sql.exec("DELETE FROM pair_codes WHERE code_hash = ?", matched.code_hash);
          this._setPairFailState(0, now);
          return new Response(
            JSON.stringify({ ok: true, bundle: matched.bundle }),
            { status: 200, headers: { ...cors, "Content-Type": "application/json" } }
          );
        }
        const nextCount = failState.count + 1;
        this._setPairFailState(nextCount, failState.windowStart || now);
        if (nextCount >= 5) {
          this.sql.exec("DELETE FROM pair_codes");
        }
        return new Response(
          JSON.stringify({
            ok: false,
            error:
              nextCount >= 5
                ? "Code invalidated after 5 failed attempts — generate a fresh code on your PC."
                : "Invalid or expired 6-digit code."
          }),
          {
            status: nextCount >= 5 ? 429 : 401,
            headers: { ...cors, "Content-Type": "application/json" }
          }
        );
      }

      return new Response(
        JSON.stringify({ ok: false, error: "WebSocket Upgrade required" }),
        { status: 426, headers: { ...cors, "Content-Type": "application/json" } }
      );
    }

    const role = url.searchParams.get("role") === "host" ? "host" : "client";
    const deviceId = String(url.searchParams.get("deviceId") || "").trim();
    const connId = crypto.randomUUID();

    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    this.ctx.acceptWebSocket(server, [role]);
    const now = Date.now();
    server.serializeAttachment({
      connId,
      role,
      deviceId,
      authenticated: false,
      connectedAt: now,
      lastSeenAt: now
    });
    await this._scheduleCleanupAlarm();

    return new Response(null, { status: 101, webSocket: client });
  }

  async webSocketMessage(ws, message) {
    const rawText = typeof message === "string" ? message : new TextDecoder().decode(message);
    if (rawText.length > MAX_WS_FRAME_BYTES) {
      this._safeSend(ws, { type: "error", error: "Frame exceeds 950 KB relay limit" });
      return;
    }

    let msg;
    try {
      msg = JSON.parse(rawText);
    } catch {
      return;
    }
    if (!msg || typeof msg !== "object") return;

    const att = ws.deserializeAttachment() || {};
    const now = Date.now();

    // 1. Authenticate Host (theo-agent / VS Code bridge)
    if (msg.type === "auth_host") {
      if (!(await this._verifyToken(msg.token))) {
        this._safeSend(ws, { type: "auth_err", error: "Invalid edge relay token" });
        try {
          ws.close(4001, "Unauthorized");
        } catch {}
        return;
      }
      const dev = msg.device || {};
      const devId = String(dev.id || att.deviceId || "host-default").trim();
      const devRole = String(dev.role || "secondary").trim();

      // Supersede any stale host sockets for this exact deviceId so RPCs never fan out twice
      for (const oldWs of this.ctx.getWebSockets("host")) {
        if (oldWs === ws) continue;
        const oldAtt = oldWs.deserializeAttachment() || {};
        if (oldAtt.deviceId === devId) {
          try {
            oldWs.close(4002, "Superseded by newer host connection");
          } catch {}
        }
      }

      ws.serializeAttachment({
        ...att,
        role: "host",
        deviceId: devId,
        deviceName: String(dev.name || devId),
        deviceRole: devRole,
        authenticated: true,
        lastSeenAt: now
      });
      this._upsertDevice({ ...dev, id: devId, role: devRole }, true);
      const devices = this._getDevicesList();
      this._safeSend(ws, { type: "auth_ok", role: "host", deviceId: devId, devices });
      this._broadcastDevicesPresence();
      return;
    }

    // 2. Authenticate PWA Client
    if (msg.type === "auth_client") {
      if (!(await this._verifyToken(msg.token))) {
        this._safeSend(ws, { type: "auth_err", error: "Invalid edge relay token" });
        try {
          ws.close(4001, "Unauthorized");
        } catch {}
        return;
      }
      ws.serializeAttachment({
        ...att,
        role: "client",
        authenticated: true,
        lastSeenAt: now
      });
      const devices = this._getDevicesList();
      // Send lean auth_ok first so multi-host snapshots never exceed Cloudflare's 1 MiB WS frame cap
      this._safeSend(ws, {
        type: "auth_ok",
        role: "client",
        connId: att.connId,
        devices,
        cachedSnapshots: {}
      });
      // Immediately stream persisted per-host snapshots from SQLite (survives Hibernation)
      for (const snapEntry of this._getPersistedSnapshots()) {
        this._safeSend(ws, {
          type: "host_state",
          deviceId: snapEntry.deviceId,
          deviceName: snapEntry.deviceName,
          snapshot: snapEntry.snapshot,
          cached: true,
          ts: snapEntry.updatedAt || now
        });
      }
      // Ask online hosts to push fresh snapshots
      this._broadcastToTag("host", { type: "request_sync", ts: now });
      return;
    }

    // Reject ALL unauthenticated traffic (including pre-auth ping holds)
    if (!att.authenticated) {
      this._safeSend(ws, { type: "auth_err", error: "Authenticate first" });
      try {
        ws.close(4001, "Authenticate first");
      } catch {}
      return;
    }

    // Update socket liveness timestamp
    ws.serializeAttachment({ ...att, lastSeenAt: now });

    if (msg.type === "ping") {
      if (att.role === "host" && att.deviceId) {
        this.sql.exec("UPDATE devices SET online = 1, last_seen = ? WHERE id = ?", now, att.deviceId);
      }
      this._safeSend(ws, { type: "pong", ts: now, echoTs: msg.ts || 0 });
      return;
    }

    // 3. Host -> Clients: State Snapshot or <25ms Stream Delta
    if (att.role === "host") {
      if (msg.type === "host_state") {
        if (msg.device) {
          this._upsertDevice(msg.device, true);
        }
        if (att.deviceId && msg.snapshot) {
          this._saveHostSnapshot(
            att.deviceId,
            att.deviceName || msg.deviceName || att.deviceId,
            msg.snapshot
          );
        }
        this._broadcastToTag("client", msg);
        this._broadcastToTag("host", msg, (hAtt) => hAtt.deviceId !== att.deviceId);
        return;
      }

      if (msg.type === "stream_delta" || msg.type === "thread_detail") {
        this._broadcastToTag("client", msg);
        this._broadcastToTag("host", msg, (hAtt) => hAtt.deviceId !== att.deviceId);
        return;
      }

      if (msg.type === "rpc_res") {
        const targetConnId = msg.clientConnId || "";
        this._broadcastToTag("client", msg, (cAtt) => !targetConnId || cAtt.connId === targetConnId);
        if (targetConnId) {
          this._broadcastToTag("host", msg, (hAtt) => hAtt.connId === targetConnId);
        }
        return;
      }

      if (msg.type === "rpc_cmd") {
        const targetId = String(msg.targetDeviceId || "").trim();
        if (!targetId) {
          if (msg.reqId) {
            this._safeSend(ws, {
              type: "rpc_res",
              reqId: msg.reqId,
              ok: false,
              error: "Missing targetDeviceId for peer RPC."
            });
          }
          return;
        }
        const chosen = this._selectTargetHost(targetId, msg.cmd || msg, att.connId);
        if (chosen && this._safeSend(chosen.ws, { ...msg, clientConnId: att.connId })) {
          return;
        }
        if (msg.reqId) {
          this._safeSend(ws, {
            type: "rpc_res",
            reqId: msg.reqId,
            ok: false,
            error: `Device "${targetId}" is currently offline.`
          });
        }
        return;
      }
      return;
    }

    // 4. PWA Client -> Target Host: RPC Command (send, stop, approve, getThread, getWorkspace, getBgTaskLog)
    if (att.role === "client") {
      if (msg.type === "rpc_cmd") {
        const targetId = String(msg.targetDeviceId || "auto").trim() || "auto";
        const chosen = this._selectTargetHost(targetId, msg.cmd || msg);
        if (chosen && this._safeSend(chosen.ws, { ...msg, clientConnId: att.connId })) {
          return;
        }
        if (msg.reqId) {
          this._safeSend(ws, {
            type: "rpc_res",
            reqId: msg.reqId,
            ok: false,
            error:
              targetId !== "auto"
                ? `Device "${targetId}" is currently offline.`
                : "No THEO host devices are currently online."
          });
        }
      }
    }
  }

  async webSocketClose(ws) {
    this._handleSocketGone(ws);
  }

  async webSocketError(ws) {
    this._handleSocketGone(ws);
  }

  _handleSocketGone(ws) {
    try {
      const att = ws.deserializeAttachment() || {};
      if (att.role === "host" && att.deviceId) {
        let otherAlive = false;
        for (const hWs of this.ctx.getWebSockets("host")) {
          if (hWs === ws) continue;
          const hAtt = hWs.deserializeAttachment() || {};
          if (hAtt.authenticated && hAtt.deviceId === att.deviceId) {
            otherAlive = true;
            break;
          }
        }
        if (!otherAlive) {
          this.sql.exec(
            "UPDATE devices SET online = 0, last_seen = ? WHERE id = ?",
            Date.now(),
            att.deviceId
          );
          this._broadcastDevicesPresence();
        }
      }
    } catch {}
  }
}
