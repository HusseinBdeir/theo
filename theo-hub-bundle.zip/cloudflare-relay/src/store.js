// THEO Store v1 — SQLite Durable Object that replaces the Power Automate "Cloud Relay" flows and their Dataverse stores.
// Wire-compatible with the legacy contract so existing clients only change URL and key:
//   POST text/plain JSON { key, op, ... }  ->  { ok, serverTime, docs } | { ok, pushStatus } | { ok, task }
// Ops: get | get_control | get_theo | patch | push | push_delay | claim | delegate_get | delegate_update
// Also owns what the two hourly "Daily Push" flows did: push_registry.items[].slots[<UTC yyyy-MM-ddTHH>].
//
// Equal hosts (v2): no PC is special. The store, on its own clock, decides the two things that need exactly one host:
//   - "coordinator": the host that answers phone commands addressed to no PC and writes the shared `state` snapshot.
//     A host that sends its deviceId with get_control holds the duty while it keeps polling; when it has been silent
//     for HOST_LEASE_MS the next host that polls takes over. Returned as top-level `coordinator` next to `docs`.
//   - `claim`: first host to claim a command key owns it, so a command can never run on two PCs.
// `device_states` is merged per device (newest updatedAt wins), so one host can never overwrite another's sessions.

import { DurableObject } from "cloudflare:workers";

const STORE_ALLOWED_ORIGINS = new Set([
  "https://husseinbdeir.github.io",
  "http://127.0.0.1:4318",
  "http://localhost:4318"
]);

// One isolated Durable Object per namespace. `split` mirrors the legacy state/control store routing.
const STORE_NAMESPACES = {
  theo: {
    name: "theo",
    room: "theo-store-v1",
    secrets: ["AUTH_TOKEN", "AUTH_TOKEN_PREV"],
    split: true,
    delegates: true,
    hosts: true,
    maxBodyBytes: 8 * 1024 * 1024,
    maxDocChars: 6 * 1024 * 1024,
    maxTotalChars: 24 * 1024 * 1024,
    maxDocs: 4000,
    maxTimers: 2000
  },
  fitness: {
    name: "fitness",
    room: "fitness-store-v1",
    secrets: ["FITNESS_KEY"],
    split: false,
    delegates: false,
    maxBodyBytes: 1024 * 1024,
    maxDocChars: 600 * 1024,
    maxTotalChars: 8 * 1024 * 1024,
    maxDocs: 5000,
    maxTimers: 300
  }
};

// Requests that carry no store key (staff task links) are small by nature.
const KEYLESS_MAX_BODY_BYTES = 16 * 1024;
const MAX_ENDPOINT_CHARS = 2048;

const CHUNK_CHARS = 480 * 1024; // worst case 3 UTF-8 bytes per UTF-16 unit stays under the 2 MB row limit
const MAX_DELAY_SEC = 35 * 86400;
const DEFAULT_PUSH_TTL = 14400;
const TERMINAL_TIMER_RETENTION_MS = 14 * 86400 * 1000;
const DELEGATE_STATUSES = new Set(["assigned", "sent", "seen", "working", "blocked", "done"]);
const TIMER_DOC_GLOBS = ["timer_*", "timer/*", "prayer_*", "theo_brief_*", "push_timer/*"];

// Equal hosts
const HOST_LEASE_MS = 90 * 1000; // a coordinator silent for this long loses the duty to the next host that polls
const HOST_LEASE_WRITE_MS = 15 * 1000; // heartbeat rows are rewritten at most this often
const HOST_ACTIVE_INPUT_WINDOW_MS = 5 * 60 * 1000; // user input within this window qualifies a host to take over duty
const HOST_ACTIVITY_MARGIN_MS = 15 * 1000; // hysteresis so simultaneous/jittery polls never flap between hosts
const MAX_TRACKED_HOSTS = 16;
const DEVICE_STATE_RETENTION_MS = 30 * 86400 * 1000; // a device not heard from for this long leaves the fleet list
const MAX_DEVICE_STATES = 32;
const DEVICE_STATE_MAX_SKEW_MS = 5 * 60 * 1000; // a stamp further ahead of this clock than this is not believed
// Longer than a command can stay in the queue, so a claimed command is never run again after its claim is purged.
const CLAIM_RETENTION_MS = 30 * 86400 * 1000;
const CLAIM_MIN_LEASE_MS = 5 * 1000;
const CLAIM_MAX_LEASE_MS = 10 * 60 * 1000;
const MAX_CLAIMS = 5000;

// Store-side Shia Ja'fari prayer Web Push self-arming (continues indefinitely when all PCs are powered off).
const STORE_VAPID_KEYS = {
  pub: "BKAC6gWORFSoi6Yf7XuS3voZnBgflXmG1GzW0K1pt4hcNoY7FNYPK-Jn-gAghKvphbSM_-ieA6U8w0E9yEgKB68",
  d: "MS5ta1KAESpycusDW8d1NMaj3fxc_oNO_F0V23oh5aA",
  x: "oALqBY5EVKiLph_te5Le-hmcGB-VeYbUbNbQrWm3iFw",
  y: "NoY7FNYPK-Jn-gAghKvphbSM_-ieA6U8w0E9yEgKB68",
  sub: "mailto:hussein@bhfirms.com"
};

function cleanDeviceId(value) {
  const s = typeof value === "string" ? value.trim() : "";
  return s.length > 0 && s.length <= 80 && /^[A-Za-z0-9._-]+$/.test(s) ? s : "";
}

function deviceStateStamp(entry) {
  const n = Number(entry?.updatedAt || entry?.device?.lastSeen || 0);
  return Number.isFinite(n) ? n : 0;
}

// Per-device merge for the `device_states` doc.
//  - The sender's own entry (ownerId, from the patch's meta.deviceId) is always taken and is stamped on this
//    object's clock, so a host is the only authority on itself and no PC clock decides how fresh it is.
//  - Any other entry in the patch is a cached copy of a peer: it is taken only when it is not older than what is
//    stored, so a stale copy can never roll a host back. A stamp ahead of this clock is not believed.
//  - `null` removes a device; entries past the retention window are dropped.
function mergeDeviceStates(prev, incoming, now, ownerId = "") {
  const cutoff = now - DEVICE_STATE_RETENTION_MS;
  const maxStamp = now + DEVICE_STATE_MAX_SKEW_MS;
  const believable = (entry) => (deviceStateStamp(entry) > maxStamp ? { ...entry, updatedAt: now } : entry);
  const out = {};
  const prevObj = prev && typeof prev === "object" && !Array.isArray(prev) ? prev : {};
  for (const id of Object.keys(prevObj)) {
    let entry = prevObj[id];
    if (!cleanDeviceId(id) || !entry || typeof entry !== "object" || Array.isArray(entry)) continue;
    entry = believable(entry);
    if (deviceStateStamp(entry) >= cutoff) out[id] = entry;
  }
  for (const id of Object.keys(incoming)) {
    if (!cleanDeviceId(id)) continue;
    let entry = incoming[id];
    if (entry === null) {
      delete out[id];
      continue;
    }
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) continue;
    if (ownerId && id === ownerId) {
      out[id] = { ...entry, updatedAt: now };
      continue;
    }
    if (deviceStateStamp(entry) > maxStamp) {
      // A copy of another host stamped ahead of this clock: never over an entry that is already stored.
      if (out[id]) continue;
      entry = believable(entry);
    }
    const stamp = deviceStateStamp(entry);
    if (stamp < cutoff) continue;
    if (!out[id] || stamp >= deviceStateStamp(out[id])) out[id] = entry;
  }
  const ids = Object.keys(out);
  if (ids.length > MAX_DEVICE_STATES) {
    ids.sort((a, b) => deviceStateStamp(out[b]) - deviceStateStamp(out[a]));
    for (const id of ids.slice(MAX_DEVICE_STATES)) delete out[id];
  }
  return out;
}

// Atomic server-side union-merge for `personal_ledger` across every `control` patch (workstation bridges,
// Planner PWA syncs, and headless producers such as the weekly blind-spot review). Preserves concurrent tasks,
// per-day scores, team roster, and newer prayer/notification configs while honoring `deletedIds` tombstones.
function mergePersonalLedger(prev, incoming, now) {
  const prevObj = prev && typeof prev === "object" && !Array.isArray(prev) ? prev : {};
  const incObj = incoming && typeof incoming === "object" && !Array.isArray(incoming) ? incoming : {};
  const RESERVED = new Set([
    "reminders",
    "deletedIds",
    "dailyScores",
    "teamRoster",
    "prayerConfig",
    "notifPrefs",
    "updatedAt"
  ]);
  const out = { ...prevObj };
  for (const [k, v] of Object.entries(incObj)) {
    if (RESERVED.has(k)) continue;
    if (v !== undefined) out[k] = v;
  }

  const deletedSet = new Set();
  for (const src of [prevObj.deletedIds, incObj.deletedIds]) {
    if (!Array.isArray(src)) continue;
    for (const id of src) {
      if (typeof id === "string" && id.trim() && id.length <= 160) {
        deletedSet.add(id.trim());
      }
    }
  }
  for (const list of [prevObj.reminders, incObj.reminders]) {
    if (!Array.isArray(list)) continue;
    for (const r of list) {
      if (r && typeof r === "object" && r.deleted === true && typeof r.id === "string") {
        const id = r.id.trim();
        if (id && id.length <= 160) deletedSet.add(id);
      }
    }
  }

  if (Array.isArray(prevObj.reminders) || Array.isArray(incObj.reminders)) {
    const byId = new Map();
    if (Array.isArray(prevObj.reminders)) {
      for (const r of prevObj.reminders) {
        if (!r || typeof r !== "object" || Array.isArray(r) || r.deleted === true) continue;
        const id = typeof r.id === "string" ? r.id.trim() : "";
        if (!id || id.length > 160 || deletedSet.has(id)) continue;
        byId.set(id, r);
      }
    }
    if (Array.isArray(incObj.reminders)) {
      for (const r of incObj.reminders) {
        if (!r || typeof r !== "object" || Array.isArray(r) || r.deleted === true) continue;
        const id = typeof r.id === "string" ? r.id.trim() : "";
        if (!id || id.length > 160 || deletedSet.has(id)) continue;
        const existing = byId.get(id);
        if (!existing || Number(r.updatedAt || 0) >= Number(existing.updatedAt || 0)) {
          byId.set(id, r);
        }
      }
    }
    out.reminders = Array.from(byId.values());
  }

  if (deletedSet.size > 0 || Array.isArray(prevObj.deletedIds) || Array.isArray(incObj.deletedIds)) {
    out.deletedIds = Array.from(deletedSet).slice(-2000);
  }

  const prevScores =
    prevObj.dailyScores && typeof prevObj.dailyScores === "object" && !Array.isArray(prevObj.dailyScores)
      ? prevObj.dailyScores
      : null;
  const incScores =
    incObj.dailyScores && typeof incObj.dailyScores === "object" && !Array.isArray(incObj.dailyScores)
      ? incObj.dailyScores
      : null;
  if (prevScores || incScores) {
    const mergedScores = { ...(prevScores || {}) };
    if (incScores) {
      for (const [iso, rec] of Object.entries(incScores)) {
        if (rec === undefined || typeof iso !== "string" || iso.length > 32) continue;
        const cur = mergedScores[iso];
        if (
          cur &&
          typeof cur === "object" &&
          !Array.isArray(cur) &&
          rec &&
          typeof rec === "object" &&
          !Array.isArray(rec)
        ) {
          if (Number(rec.updatedAt || 0) >= Number(cur.updatedAt || 0)) {
            mergedScores[iso] = rec;
          }
        } else {
          mergedScores[iso] = rec;
        }
      }
    }
    out.dailyScores = mergedScores;
  }

  if (Array.isArray(prevObj.teamRoster) || Array.isArray(incObj.teamRoster)) {
    const rosterById = new Map();
    if (Array.isArray(prevObj.teamRoster)) {
      for (const m of prevObj.teamRoster) {
        if (!m || typeof m !== "object" || Array.isArray(m)) continue;
        const id = typeof m.id === "string" ? m.id.trim() : "";
        if (!id || id.length > 160 || deletedSet.has(id)) continue;
        rosterById.set(id, m);
      }
    }
    if (Array.isArray(incObj.teamRoster)) {
      for (const m of incObj.teamRoster) {
        if (!m || typeof m !== "object" || Array.isArray(m)) continue;
        const id = typeof m.id === "string" ? m.id.trim() : "";
        if (!id || id.length > 160 || deletedSet.has(id)) continue;
        const cur = rosterById.get(id);
        if (!cur || Number(m.updatedAt || 0) >= Number(cur.updatedAt || 0)) {
          rosterById.set(id, m);
        }
      }
    }
    out.teamRoster = Array.from(rosterById.values());
  }

  for (const cfgKey of ["prayerConfig", "notifPrefs"]) {
    const incCfg = incObj[cfgKey];
    if (incCfg && typeof incCfg === "object" && !Array.isArray(incCfg)) {
      const curCfg =
        prevObj[cfgKey] && typeof prevObj[cfgKey] === "object" && !Array.isArray(prevObj[cfgKey])
          ? prevObj[cfgKey]
          : null;
      const curTs = Number(curCfg?.updatedAt || 0);
      const incTs = Number(incCfg.updatedAt || 0);
      if (!curCfg || incTs >= curTs) {
        out[cfgKey] = incCfg;
      }
    }
  }

  const maxSkew = now + DEVICE_STATE_MAX_SKEW_MS;
  const prevUp = Math.min(Number(prevObj.updatedAt || 0) || 0, maxSkew);
  const incUp = Math.min(Number(incObj.updatedAt || 0) || 0, maxSkew);
  out.updatedAt = Math.max(prevUp, incUp, now);
  return out;
}

const VALID_CLAUDE_PERMISSION_MODES = new Set([
  "bypassPermissions",
  "auto",
  "plan",
  "acceptEdits",
  "default"
]);

function normalizeStoreClaudePermissionMode(rawMode) {
  const clean = String(rawMode || "").trim();
  if (!clean) return "";
  if (clean === "plan") return "plan";
  if (clean === "accept-edits" || clean === "acceptEdits") return "acceptEdits";
  if (clean === "bypassPermissions" || clean === "bypass" || clean === "bypass-permissions") {
    return "bypassPermissions";
  }
  if (clean === "default" || clean === "manual") return "default";
  if (clean === "auto") return "auto";
  return "";
}

function mergeClaudePermissionMode(prev, incoming, now = Date.now()) {
  const prevObj = prev && typeof prev === "object" && !Array.isArray(prev) ? prev : null;
  const incObj = incoming && typeof incoming === "object" && !Array.isArray(incoming) ? incoming : {};
  const nextMode = normalizeStoreClaudePermissionMode(incObj.defaultMode || incObj.mode);
  if (!nextMode || !VALID_CLAUDE_PERMISSION_MODES.has(nextMode)) {
    return prevObj;
  }
  const prevMode = prevObj ? normalizeStoreClaudePermissionMode(prevObj.defaultMode || prevObj.mode) : "";
  const prevRev = Math.max(0, Math.floor(Number(prevObj?.rev || 0) || 0));
  if (incObj.ifMissing && prevMode && prevRev > 0) {
    return prevObj;
  }
  if (
    incObj.expectedRev !== undefined &&
    incObj.expectedRev !== null &&
    incObj.expectedRev !== "" &&
    Number.isFinite(Number(incObj.expectedRev)) &&
    prevRev > 0 &&
    Math.floor(Number(incObj.expectedRev)) < prevRev
  ) {
    return prevObj;
  }
  return {
    defaultMode: nextMode,
    rev: prevRev + 1,
    updatedAt: now,
    updatedBy: String(incObj.updatedBy || "").trim().slice(0, 80),
    source: String(incObj.source || "store").trim().slice(0, 40)
  };
}

function storeNamespaceFromPath(pathname) {
  const clean = String(pathname || "").replace(/\/+$/, "");
  if (clean === "/store") return STORE_NAMESPACES.theo;
  if (clean === "/store/fitness") return STORE_NAMESPACES.fitness;
  return null;
}

function storeCorsHeaders(request) {
  const origin = request?.headers?.get("Origin") || "";
  return {
    "Access-Control-Allow-Origin": STORE_ALLOWED_ORIGINS.has(origin) ? origin : "https://husseinbdeir.github.io",
    Vary: "Origin",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Cache-Control": "no-store"
  };
}

function storeJson(status, obj, cors) {
  return new Response(typeof obj === "string" ? obj : JSON.stringify(obj), {
    status,
    headers: { ...cors, "Content-Type": "application/json" }
  });
}

async function storeConstantTimeEqual(a, b) {
  const enc = new TextEncoder();
  const [da, db] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(String(a || ""))),
    crypto.subtle.digest("SHA-256", enc.encode(String(b || "")))
  ]);
  return crypto.subtle.timingSafeEqual(da, db);
}

// Web Push subscription endpoints only (exact host + path prefix): the relay must never become an open HTTP
// forwarder, nor a way to call provider APIs such as APNs or FCM v1 with a caller-supplied credential.
function isAllowedPushEndpoint(rawUrl) {
  const raw = String(rawUrl || "");
  if (!raw || raw.length > MAX_ENDPOINT_CHARS) return false;
  let u;
  try {
    u = new URL(raw);
  } catch {
    return false;
  }
  if (u.protocol !== "https:" || u.username || u.password) return false;
  if (u.port && u.port !== "443") return false;
  const h = u.hostname.toLowerCase();
  const p = u.pathname;
  if (h === "web.push.apple.com") return p.length > 1;
  if (h === "fcm.googleapis.com") return p.startsWith("/fcm/send/") || p.startsWith("/wp/");
  if (h === "updates.push.services.mozilla.com") return p.startsWith("/wpush/");
  if (h.endsWith(".notify.windows.com")) return p.startsWith("/w/");
  return false;
}

// RFC 8292 header value only ("vapid t=..., k=..."; "WebPush <jwt>" is the older draft form).
function isValidVapidHeader(value) {
  const v = String(value || "");
  return v.length > 8 && v.length <= 4096 && !/[\r\n]/.test(v) && /^(vapid|WebPush) /i.test(v);
}

async function verifyStoreKey(env, ns, candidate) {
  const clean = String(candidate || "").trim();
  if (clean.length < 16) return false;
  let ok = false;
  for (const name of ns.secrets) {
    const expected = String(env?.[name] || "").trim();
    if (expected.length < 16) continue;
    if (await storeConstantTimeEqual(clean, expected)) ok = true;
  }
  return ok;
}

// Reads at most maxBytes of the body. Returns null when the body is larger, so an oversized upload is dropped
// while it streams instead of being buffered whole.
async function readBodyCapped(request, maxBytes) {
  if (!request.body) return "";
  const reader = request.body.getReader();
  const chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) {
      try {
        await reader.cancel();
      } catch {}
      return null;
    }
    chunks.push(value);
  }
  const buf = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) {
    buf.set(c, off);
    off += c.byteLength;
  }
  return new TextDecoder().decode(buf);
}

function bearerFromRequest(request) {
  const authHdr = String(request.headers.get("Authorization") || "").trim();
  return /^Bearer\s+/i.test(authHdr) ? authHdr.replace(/^Bearer\s+/i, "").trim() : "";
}

function isKeylessOp(ns, body) {
  if (!ns.delegates || !body) return false;
  const op = String(body.op || "");
  if (op === "delegate_get" || op === "delegate_update") return true;
  return op === "push" && !body.key && Boolean(body.taskId) && Boolean(body.token);
}

const B64_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

function encodeBase64Bytes(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let out = "";
  let i = 0;
  for (; i + 2 < u8.length; i += 3) {
    const n = (u8[i] << 16) | (u8[i + 1] << 8) | u8[i + 2];
    out +=
      B64_ALPHABET[(n >> 18) & 63] +
      B64_ALPHABET[(n >> 12) & 63] +
      B64_ALPHABET[(n >> 6) & 63] +
      B64_ALPHABET[n & 63];
  }
  if (i < u8.length) {
    const rem = u8.length - i;
    const n = (u8[i] << 16) | (rem === 2 ? u8[i + 1] << 8 : 0);
    out += B64_ALPHABET[(n >> 18) & 63] + B64_ALPHABET[(n >> 12) & 63];
    out += rem === 2 ? B64_ALPHABET[(n >> 6) & 63] + "=" : "==";
  }
  return out;
}

function encodeBase64UrlBytes(bytes) {
  return encodeBase64Bytes(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function concatStoreU8(...arrs) {
  let total = 0;
  for (const a of arrs) total += a.length;
  const out = new Uint8Array(total);
  let off = 0;
  for (const a of arrs) {
    out.set(a, off);
    off += a.length;
  }
  return out;
}

async function hkdfExtractAndExpandStore(salt, ikm, info, len) {
  const key = await crypto.subtle.importKey(
    "raw",
    salt.length ? salt : new Uint8Array(32),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const prk = new Uint8Array(await crypto.subtle.sign("HMAC", key, ikm));
  const prkKey = await crypto.subtle.importKey(
    "raw",
    prk,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const okm = new Uint8Array(
    await crypto.subtle.sign("HMAC", prkKey, concatStoreU8(info, new Uint8Array([1])))
  );
  return okm.slice(0, len);
}

async function signStoreVapid(endpointUrl, customExpSec = 0, env = null) {
  const u = new URL(endpointUrl);
  const aud = `${u.protocol}//${u.host}`;
  const exp =
    Number(customExpSec) > 0
      ? Math.floor(Number(customExpSec))
      : Math.floor(Date.now() / 1000) + 12 * 3600;
  let keys = STORE_VAPID_KEYS;
  if (env?.VAPID_PRIVATE_JWK) {
    try {
      const parsed = JSON.parse(String(env.VAPID_PRIVATE_JWK));
      if (parsed?.x && parsed?.y && parsed?.d && parsed?.pub) keys = parsed;
    } catch {}
  }
  const enc = new TextEncoder();
  const hdr = encodeBase64UrlBytes(enc.encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const pld = encodeBase64UrlBytes(enc.encode(JSON.stringify({ aud, exp, sub: keys.sub || STORE_VAPID_KEYS.sub })));
  const unsigned = `${hdr}.${pld}`;
  const ecKey = await crypto.subtle.importKey(
    "jwk",
    { kty: "EC", crv: "P-256", x: keys.x, y: keys.y, d: keys.d, ext: true },
    { name: "ECDSA", namedCurve: "P-256" },
    false,
    ["sign"]
  );
  const sig = new Uint8Array(
    await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, ecKey, enc.encode(unsigned))
  );
  return `vapid t=${unsigned}.${encodeBase64UrlBytes(sig)}, k=${keys.pub}`;
}

async function encryptStoreWebPush(subKeys, payloadObj) {
  const enc = new TextEncoder();
  const uaPub = decodeBase64Bytes(subKeys?.p256dh || "");
  const authSecret = decodeBase64Bytes(subKeys?.auth || "");
  if (!uaPub || uaPub.length !== 65 || !authSecret || authSecret.length < 12) {
    return null;
  }
  const asKeyPair = await crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" },
    true,
    ["deriveBits"]
  );
  const asPubRaw = new Uint8Array(await crypto.subtle.exportKey("raw", asKeyPair.publicKey));
  const uaPubKey = await crypto.subtle.importKey(
    "raw",
    uaPub,
    { name: "ECDH", namedCurve: "P-256" },
    false,
    []
  );
  const ecdhBits = new Uint8Array(
    await crypto.subtle.deriveBits({ name: "ECDH", public: uaPubKey }, asKeyPair.privateKey, 256)
  );
  const keyInfo = concatStoreU8(enc.encode("WebPush: info\0"), uaPub, asPubRaw);
  const ikm = await hkdfExtractAndExpandStore(authSecret, ecdhBits, keyInfo, 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdfExtractAndExpandStore(
    salt,
    ikm,
    enc.encode("Content-Encoding: aes128gcm\0"),
    16
  );
  const nonce = await hkdfExtractAndExpandStore(
    salt,
    ikm,
    enc.encode("Content-Encoding: nonce\0"),
    12
  );
  const aesKey = await crypto.subtle.importKey("raw", cek, { name: "AES-GCM" }, false, ["encrypt"]);
  const plainBytes = enc.encode(JSON.stringify(payloadObj));
  const padded = concatStoreU8(plainBytes, new Uint8Array([2]));
  const cipher = new Uint8Array(
    await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, aesKey, padded)
  );
  const rs = new Uint8Array(4);
  new DataView(rs.buffer).setUint32(0, 4096, false);
  const idlen = new Uint8Array([asPubRaw.length]);
  return encodeBase64Bytes(concatStoreU8(salt, rs, idlen, asPubRaw, cipher));
}

function isStorePlannerDevice(d) {
  if (!d || typeof d !== "object") return false;
  const app = String(d.app || "").trim().toLowerCase();
  const id = String(d.id || "").trim().toLowerCase();
  return app === "command" || app === "planner" || id.startsWith("cmd_") || id.startsWith("pln_");
}

function getStoreDevicePlatformClass(d) {
  const ua = String(d?.ua || "").toLowerCase();
  if (ua.includes("iphone")) return "iphone";
  if (ua.includes("ipad")) return "ipad";
  if (ua.includes("android")) return "android";
  if (ua.includes("macintosh") || ua.includes("mac os x")) return "mac";
  if (ua.includes("windows")) return "windows";
  const ep = String(d?.endpoint || "").toLowerCase();
  if (ep.includes("web.push.apple.com")) return "apple";
  return ua ? ua.slice(0, 32) : "default";
}

function dedupeStorePlannerDevices(items) {
  if (!Array.isArray(items)) return [];
  const normalized = [];
  for (const raw of items) {
    if (!raw || typeof raw !== "object") continue;
    const endpoint = String(raw.endpoint || "").trim();
    const p256dh = String(raw.keys?.p256dh || raw.p256dh || "").trim();
    const auth = String(raw.keys?.auth || raw.auth || "").trim();
    if (!endpoint || !p256dh || !auth || !isAllowedPushEndpoint(endpoint)) continue;
    const id = String(raw.id || endpoint.slice(-24)).trim();
    const entry = {
      id,
      app: raw.app || "",
      endpoint,
      keys: { p256dh, auth },
      prefs:
        raw.prefs && typeof raw.prefs === "object"
          ? raw.prefs
          : { enabled: true, prayers: true, tasks: true, timers: true },
      ua: raw.ua || "",
      updatedAt: raw.updatedAt || ""
    };
    normalized.push(entry);
  }
  normalized.sort((a, b) => (Date.parse(a.updatedAt || "") || 0) - (Date.parse(b.updatedAt || "") || 0));
  const byEndpoint = new Map();
  for (const d of normalized) byEndpoint.set(d.endpoint, d);
  const byId = new Map();
  for (const d of byEndpoint.values()) byId.set(d.id, d);
  const byAppAndClass = new Map();
  for (const d of byId.values()) {
    const appKey = isStorePlannerDevice(d) ? "command" : "theo";
    const compositeKey = `${appKey}::${getStoreDevicePlatformClass(d)}`;
    byAppAndClass.set(compositeKey, d);
  }
  return Array.from(byAppAndClass.values())
    .slice(-8)
    .filter((d) => isStorePlannerDevice(d) && d.prefs?.enabled !== false);
}

function dedupeStorePlannerSubs(items) {
  return dedupeStorePlannerDevices(items).filter((d) => d.prefs?.prayers !== false);
}

function dedupeStorePlannerTaskSubs(items) {
  return dedupeStorePlannerDevices(items);
}

function computeStoreShiaPrayers(rawCfg = {}, customIsoDate = "", nowMs = Date.now()) {
  try {
    const lat = Number.isFinite(Number(rawCfg.lat)) ? Number(rawCfg.lat) : 33.8938;
    const rawLng = rawCfg.lng ?? rawCfg.lon;
    const lng = Number.isFinite(Number(rawLng)) ? Number(rawLng) : 35.5018;
    const timeZone = String(rawCfg.timeZone || "Asia/Beirut").trim() || "Asia/Beirut";
    const locationName = String(rawCfg.locationName || "Beirut, Lebanon").trim() || "Beirut, Lebanon";
    const methodMap = {
      jafari_leva: { fajrAngle: 16, maghribAngle: 4, dhuhrMin: 1 },
      jafari_lebanon: { fajrAngle: 18, maghribAngle: 4, dhuhrMin: 1 },
      jafari_tehran: { fajrAngle: 17.7, maghribAngle: 4.5, dhuhrMin: 1 }
    };
    const m = methodMap[rawCfg.method] || methodMap.jafari_leva;

    let year;
    let month;
    let day;
    const customMatch = String(customIsoDate || "").trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (customMatch) {
      year = Number(customMatch[1]);
      month = Number(customMatch[2]);
      day = Number(customMatch[3]);
    } else {
      const now = new Date(nowMs);
      const parts = new Intl.DateTimeFormat("en-US", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
      }).formatToParts(now);
      const pm = {};
      for (const p of parts) pm[p.type] = p.value;
      year = Number(pm.year);
      month = Number(pm.month);
      day = Number(pm.day);
    }
    const isoDate = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;

    const utcNoon = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
    const noonParts = new Intl.DateTimeFormat("en-US", {
      timeZone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    }).formatToParts(utcNoon);
    const nm = {};
    for (const p of noonParts) nm[p.type] = p.value;
    const hr = Number(nm.hour === "24" ? 0 : nm.hour);
    const asUtc = Date.UTC(Number(nm.year), Number(nm.month) - 1, Number(nm.day), hr, Number(nm.minute), Number(nm.second));
    const tzOffsetHours = (asUtc - utcNoon.getTime()) / 3600000;

    const d2r = (d) => (d * Math.PI) / 180;
    const r2d = (r) => (r * 180) / Math.PI;
    let Y = year;
    let M = month;
    const D = day;
    if (M <= 2) {
      Y -= 1;
      M += 12;
    }
    const A = Math.floor(Y / 100);
    const B = 2 - A + Math.floor(A / 4);
    const JD = Math.floor(365.25 * (Y + 4716)) + Math.floor(30.6001 * (M + 1)) + D + B - 1524.5;

    const sunPos = (jd) => {
      const n = jd - 2451545.0;
      const g = d2r((357.529 + 0.98560028 * n) % 360);
      const q = (280.459 + 0.98564736 * n) % 360;
      const L = d2r((q + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)) % 360);
      const e = d2r(23.439 - 0.00000036 * n);
      const ra = r2d(Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L))) / 15;
      const decl = r2d(Math.asin(Math.sin(e) * Math.sin(L)));
      let eqt = q / 15 - ((ra + 24) % 24);
      if (eqt > 12) eqt -= 24;
      if (eqt < -12) eqt += 24;
      return { decl, eqt };
    };

    const baseJd = JD - lng / 360;
    const spNoon = sunPos(baseJd + 0.5);
    const noonUtc = 12 - spNoon.eqt - lng / 15;
    const ha = (angle, decl, nightHrs = 10) => {
      const num = -Math.sin(d2r(angle)) - Math.sin(d2r(lat)) * Math.sin(d2r(decl));
      const den = Math.cos(d2r(lat)) * Math.cos(d2r(decl));
      if (!den || Math.abs(num / den) > 1) return (angle / 60) * nightHrs;
      return r2d(Math.acos(num / den)) / 15;
    };

    const spRise = sunPos(baseJd + (noonUtc - ha(0.833, spNoon.decl)) / 24);
    const sunriseUtc = 12 - spRise.eqt - lng / 15 - ha(0.833, spRise.decl);
    const spSet = sunPos(baseJd + (noonUtc + ha(0.833, spNoon.decl)) / 24);
    const sunsetUtc = 12 - spSet.eqt - lng / 15 + ha(0.833, spSet.decl);
    const nightHrs = Math.max(4, Math.min(20, 24 - (sunsetUtc - sunriseUtc)));

    const spFajr = sunPos(baseJd + (noonUtc - ha(m.fajrAngle, spNoon.decl, nightHrs)) / 24);
    const fajrUtc = 12 - spFajr.eqt - lng / 15 - ha(m.fajrAngle, spFajr.decl, nightHrs) + Number(rawCfg.fajrOffsetMin || 0) / 60;
    const dhuhrUtc = noonUtc + (m.dhuhrMin + Number(rawCfg.dhuhrOffsetMin || 0)) / 60;
    const spMag = sunPos(baseJd + (noonUtc + ha(m.maghribAngle, spNoon.decl, nightHrs)) / 24);
    const maghribUtc = 12 - spMag.eqt - lng / 15 + ha(m.maghribAngle, spMag.decl, nightHrs) + Number(rawCfg.maghribOffsetMin || 0) / 60;

    const toSlot = (utcH) => {
      const rawMin = Math.round((utcH + tzOffsetHours) * 60);
      const wMin = ((rawMin % 1440) + 1440) % 1440;
      const hh = Math.floor(wMin / 60);
      const mm = wMin % 60;
      const time24 = `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
      const epochMs = Date.UTC(year, month - 1, day, 0, 0, 0) + Math.round((wMin - tzOffsetHours * 60) * 60000);
      return { time24, epochMs };
    };

    const fajrT = toSlot(fajrUtc);
    const riseT = toSlot(sunriseUtc);
    const dhuhrT = toSlot(dhuhrUtc);
    const setT = toSlot(sunsetUtc);
    const magT = toSlot(maghribUtc);

    return {
      isoDate,
      locationName,
      prayers: [
        {
          id: "fajr",
          label: "Fajr",
          arabic: "صلاة الصبح",
          icon: "🌅",
          time24: fajrT.time24,
          epochMs: fajrT.epochMs,
          windowNote: `True Dawn (${m.fajrAngle}°) · Sunrise (الشروق) at ${riseT.time24}`,
          enabled: rawCfg.notifyFajr !== false
        },
        {
          id: "dhuhr",
          label: "Dohor",
          arabic: "صلاة الظهرين",
          icon: "☀️",
          time24: dhuhrT.time24,
          epochMs: dhuhrT.epochMs,
          windowNote: `Solar Noon (Zawal) · Sunset at ${setT.time24}`,
          enabled: rawCfg.notifyDhuhr !== false
        },
        {
          id: "maghrib",
          label: "Maghrib",
          arabic: "صلاة المغربين",
          icon: "🌙",
          time24: magT.time24,
          epochMs: magT.epochMs,
          windowNote: `Eastern Redness (${m.maghribAngle}° after Sunset ${setT.time24})`,
          enabled: rawCfg.notifyMaghrib !== false
        }
      ]
    };
  } catch {
    return null;
  }
}

function getStoreDeviceShortKey(d) {
  return String(d?.id || String(d?.endpoint || "").slice(-12))
    .replace(/[^a-zA-Z0-9]/g, "")
    .slice(-12);
}

function getStorePrayerTimerKey(d, isoDate, prayerId, isPre = false) {
  const [yy, mm, dd] = String(isoDate || "").split("-").map(Number);
  const dow = new Date(Date.UTC(yy || 2026, (mm || 1) - 1, dd || 1)).getUTCDay();
  const devShort = getStoreDeviceShortKey(d);
  return isPre ? `prayer_d${dow}_pre_${prayerId}_${devShort}` : `prayer_d${dow}_${prayerId}_${devShort}`;
}

function hasValidStoreTimerExp(doc, targetMs) {
  const expSec = Number(doc?.expSec || 0);
  const baseSec = Math.floor(Number(targetMs || 0) / 1000);
  if (!baseSec || !expSec) return false;
  return expSec >= baseSec + 600 && expSec <= baseSec + 23 * 3600 + 1800;
}

function randomHexBytes(byteLen) {
  const arr = crypto.getRandomValues(new Uint8Array(byteLen));
  let s = "";
  for (let i = 0; i < arr.length; i++) s += arr[i].toString(16).padStart(2, "0");
  return s;
}

async function sha256HexStore(str) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(str || "")));
  const u8 = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < u8.length; i++) s += u8[i].toString(16).padStart(2, "0");
  return s;
}

function decodeBase64Bytes(b64) {
  let s = String(b64 || "").replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/");
  if (!s || /[^A-Za-z0-9+/=]/.test(s)) return null;
  while (s.length % 4) s += "=";
  try {
    const bin = atob(s);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  } catch {
    return null;
  }
}

const LONE_SURROGATE_RE = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/;

function isValidDocKey(k) {
  return (
    typeof k === "string" &&
    k.length > 0 &&
    k.length <= 256 &&
    !/[\u0000-\u001f]/.test(k) &&
    !LONE_SURROGATE_RE.test(k) // a lone surrogate would be stored as U+FFFD and collide with other keys
  );
}

// Delayed pushes may only use the key families the clients use, which are also the ones the daily purge reclaims.
function isTimerDocKey(k) {
  return isValidDocKey(k) && k.length <= 200 && /^(timer_|timer\/|prayer_|theo_brief_|push_timer\/)./.test(k);
}

function clampInt(val, min, max, fallback) {
  const n = Math.round(Number(val));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

// Called by the Worker entry. Returns null when the path is not a store path, otherwise a Promise<Response>.
export function routeStoreRequest(request, env) {
  const url = new URL(request.url);
  if (url.pathname !== "/store" && !url.pathname.startsWith("/store/")) return null;
  return handleStoreRoute(request, env, url);
}

// Runs in the stateless Worker: size cap, JSON shape and the store key are all checked here, so traffic without
// a valid key (or a valid-looking staff request) never reaches, wakes or fills the Durable Object.
async function handleStoreRoute(request, env, url) {
  const cors = storeCorsHeaders(request);
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors });
  }
  if (url.pathname === "/store/health") {
    return storeJson(
      200,
      {
        ok: true,
        service: "THEO Store",
        version: 3,
        capabilities: ["equal_hosts", "self_prayers", "self_task_timers", "ledger_merge"],
        ts: Date.now()
      },
      cors
    );
  }
  const ns = storeNamespaceFromPath(url.pathname);
  if (!ns) {
    return storeJson(404, { ok: false, error: "not found" }, cors);
  }
  if (request.method !== "POST") {
    return storeJson(405, { ok: false, error: "POST required" }, cors);
  }
  const origin = request.headers.get("Origin") || "";
  if (origin && !STORE_ALLOWED_ORIGINS.has(origin)) {
    return storeJson(403, { ok: false, error: "Forbidden Origin" }, cors);
  }
  const declaredLen = Number(request.headers.get("Content-Length") || 0);
  if (declaredLen > ns.maxBodyBytes) {
    return storeJson(413, { ok: false, error: "Payload too large" }, cors);
  }
  let raw = null;
  try {
    raw = await readBodyCapped(request, ns.maxBodyBytes);
  } catch {
    return storeJson(400, { ok: false, error: "unreadable body" }, cors);
  }
  if (raw === null) {
    return storeJson(413, { ok: false, error: "Payload too large" }, cors);
  }
  let body = null;
  try {
    body = JSON.parse(raw);
  } catch {
    return storeJson(400, { ok: false, error: "invalid json" }, cors);
  }
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return storeJson(400, { ok: false, error: "invalid json" }, cors);
  }
  const bearer = bearerFromRequest(request);
  const keyOk = await verifyStoreKey(env, ns, body.key || bearer);
  if (!keyOk) {
    if (!isKeylessOp(ns, body) || raw.length > KEYLESS_MAX_BODY_BYTES) {
      return storeJson(401, { ok: false, error: "bad key" }, cors);
    }
  }
  const stub = env.THEO_STORE.get(env.THEO_STORE.idFromName(ns.room));
  const fwdHeaders = { "Content-Type": "text/plain;charset=UTF-8" };
  if (origin) fwdHeaders.Origin = origin;
  if (bearer) fwdHeaders.Authorization = `Bearer ${bearer}`;
  return stub.fetch(new Request(request.url, { method: "POST", headers: fwdHeaders, body: raw }));
}

export class TheoStoreRoom extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx = ctx;
    this.env = env;
    this.sql = ctx.storage.sql;
    this._initSchema();
  }

  _initSchema() {
    this.sql.exec(`
      CREATE TABLE IF NOT EXISTS docs (
        store TEXT NOT NULL,
        k TEXT NOT NULL,
        chars INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (store, k)
      );
      CREATE TABLE IF NOT EXISTS doc_chunks (
        store TEXT NOT NULL,
        k TEXT NOT NULL,
        seq INTEGER NOT NULL,
        v TEXT NOT NULL,
        PRIMARY KEY (store, k, seq)
      );
      CREATE TABLE IF NOT EXISTS timers (
        timer_key TEXT PRIMARY KEY,
        timer_id TEXT NOT NULL,
        fire_at INTEGER NOT NULL,
        exp_sec INTEGER NOT NULL DEFAULT 0,
        endpoint TEXT NOT NULL,
        vapid TEXT NOT NULL,
        body_b64 TEXT NOT NULL,
        ttl INTEGER NOT NULL DEFAULT 14400,
        created_at INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS meta (
        k TEXT PRIMARY KEY,
        v TEXT
      );
      CREATE TABLE IF NOT EXISTS claims (
        claim_key TEXT PRIMARY KEY,
        device_id TEXT NOT NULL,
        at INTEGER NOT NULL DEFAULT 0,
        expires_at INTEGER NOT NULL DEFAULT 0
      );
    `);
    try {
      this.sql.exec("ALTER TABLE claims ADD COLUMN expires_at INTEGER NOT NULL DEFAULT 0");
    } catch {}
    // A new store only dispatches hourly slots for hours that begin after it was created,
    // so the hour in which a migration happens is never sent twice.
    this.sql.exec(
      "INSERT OR IGNORE INTO meta (k, v) VALUES ('last_slot_hour', ?)",
      new Date().toISOString().slice(0, 13)
    );
  }

  _atomic(fn) {
    if (typeof this.ctx.storage.transactionSync === "function") {
      return this.ctx.storage.transactionSync(fn);
    }
    return fn();
  }

  _getMeta(k) {
    const rows = [...this.sql.exec("SELECT v FROM meta WHERE k = ?", k)];
    return rows.length ? String(rows[0].v ?? "") : "";
  }

  _setMeta(k, v) {
    this.sql.exec(
      "INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v",
      k,
      String(v)
    );
  }

  // ---------- documents ----------

  _writeDocRaw(store, k, jsonStr, now) {
    this.sql.exec("DELETE FROM doc_chunks WHERE store = ? AND k = ?", store, k);
    let seq = 0;
    let i = 0;
    while (i < jsonStr.length) {
      let end = Math.min(jsonStr.length, i + CHUNK_CHARS);
      if (end < jsonStr.length) {
        const c = jsonStr.charCodeAt(end - 1);
        if (c >= 0xd800 && c <= 0xdbff) end -= 1; // never split a surrogate pair across rows
      }
      this.sql.exec(
        "INSERT INTO doc_chunks (store, k, seq, v) VALUES (?, ?, ?, ?)",
        store,
        k,
        seq++,
        jsonStr.slice(i, end)
      );
      i = end;
    }
    this.sql.exec(
      `INSERT INTO docs (store, k, chars, updated_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(store, k) DO UPDATE SET chars = excluded.chars, updated_at = excluded.updated_at`,
      store,
      k,
      jsonStr.length,
      now
    );
  }

  _deleteDoc(store, k) {
    this.sql.exec("DELETE FROM doc_chunks WHERE store = ? AND k = ?", store, k);
    this.sql.exec("DELETE FROM docs WHERE store = ? AND k = ?", store, k);
  }

  _readDocRaw(store, k) {
    const rows = [
      ...this.sql.exec("SELECT v FROM doc_chunks WHERE store = ? AND k = ? ORDER BY seq", store, k)
    ];
    if (!rows.length) return null;
    return rows.map((r) => r.v).join("");
  }

  _readDoc(store, k) {
    const raw = this._readDocRaw(store, k);
    if (raw == null) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  _writeDoc(store, k, obj, now = Date.now()) {
    this._writeDocRaw(store, k, JSON.stringify(obj), now);
  }

  // Raw JSON per key; later stores in the list override earlier ones (control wins over state).
  _collectRawDocs(stores) {
    const out = new Map();
    for (const store of stores) {
      const rows = [
        ...this.sql.exec("SELECT k, v FROM doc_chunks WHERE store = ? ORDER BY k, seq", store)
      ];
      let curKey = null;
      let parts = [];
      const flush = () => {
        if (curKey !== null) out.set(curKey, parts.join(""));
      };
      for (const r of rows) {
        if (r.k !== curKey) {
          flush();
          curKey = r.k;
          parts = [];
        }
        parts.push(r.v);
      }
      flush();
    }
    return out;
  }

  _docsResponse(stores, cors, omitKeys = null, coordinator = null) {
    const raw = this._collectRawDocs(stores);
    const parts = [];
    for (const [k, v] of raw) {
      if (omitKeys && omitKeys.has(k)) continue;
      parts.push(JSON.stringify(k) + ":" + v);
    }
    const body =
      '{"ok":true,"serverTime":' +
      JSON.stringify(new Date().toISOString()) +
      (coordinator ? ',"coordinator":' + JSON.stringify(coordinator) : "") +
      ',"docs":{' +
      parts.join(",") +
      "}}";
    return storeJson(200, body, cors);
  }

  // ---------- equal hosts: coordinator duty and command claims ----------

  // Called with the deviceId (and optional idleMs) a host sends on get_control.
  //  - With no activity signal, the duty stays with the holder while it keeps polling and moves once silent for HOST_LEASE_MS.
  //  - When a host reports recent user input (`idleMs <= HOST_ACTIVE_INPUT_WINDOW_MS`) that is fresher than the current
  //    holder's last input by more than `HOST_ACTIVITY_MARGIN_MS` on this object's clock, the duty moves to the PC the
  //    user last typed on. All timestamps are computed from `now - clampedIdle`, so a skewed PC clock can never forge
  //    a future activity time.
  _touchHostLease(deviceId, now, rawIdleMs = undefined) {
    let cur = null;
    try {
      cur = JSON.parse(this._getMeta("host_lease") || "null");
    } catch {}
    if (!cur || typeof cur !== "object" || !cleanDeviceId(cur.deviceId)) cur = null;

    const prevHosts = cur?.hosts && typeof cur.hosts === "object" && !Array.isArray(cur.hosts) ? cur.hosts : {};
    const hosts = {};
    for (const [hid, hentry] of Object.entries(prevHosts)) {
      if (!cleanDeviceId(hid) || !hentry || typeof hentry !== "object") continue;
      const hb = Number(hentry.lastBeat || 0);
      if (hb > 0 && now - hb <= HOST_LEASE_MS) {
        hosts[hid] = {
          lastBeat: hb,
          lastActiveAt: Math.min(now, Math.max(0, Number(hentry.lastActiveAt || 0)))
        };
      }
    }

    let hasFreshInputSignal = false;
    let clampedIdle = 0;
    let callerInputAt = 0;
    if (rawIdleMs !== undefined && rawIdleMs !== null && rawIdleMs !== "") {
      const n = Number(rawIdleMs);
      if (Number.isFinite(n) && n >= 0) {
        clampedIdle = Math.min(Math.floor(n), DEVICE_STATE_RETENTION_MS);
        callerInputAt = Math.max(1, now - clampedIdle);
        hasFreshInputSignal = true;
      }
    }

    let hostEntryChanged = false;
    if (deviceId) {
      const prevSelf = hosts[deviceId];
      const prevActiveAt = Number(prevSelf?.lastActiveAt || 0);
      // Avoid jitter drift when the user is idle and `now - idleMs` wiggles by a few ms across polls.
      let nextActiveAt = prevActiveAt;
      if (hasFreshInputSignal) {
        if (prevActiveAt <= 0 || Math.abs(callerInputAt - prevActiveAt) > 2500 || callerInputAt > prevActiveAt) {
          nextActiveAt = Math.max(prevActiveAt, callerInputAt);
        }
      }
      if (!prevSelf || now - prevSelf.lastBeat >= HOST_LEASE_WRITE_MS || nextActiveAt !== prevActiveAt) {
        hostEntryChanged = true;
      }
      hosts[deviceId] = { lastBeat: now, lastActiveAt: nextActiveAt };
      const hostIds = Object.keys(hosts);
      if (hostIds.length > MAX_TRACKED_HOSTS) {
        hostIds.sort((a, b) => Number(hosts[b].lastBeat || 0) - Number(hosts[a].lastBeat || 0));
        for (const dropId of hostIds.slice(MAX_TRACKED_HOSTS)) delete hosts[dropId];
      }
    }

    const lastBeat = Number(cur?.lastBeat || 0);
    const expired = !cur || now - lastBeat > HOST_LEASE_MS;
    const holderActiveAt = cur ? Number(hosts[cur.deviceId]?.lastActiveAt || cur.lastActiveAt || 0) : 0;
    const myActiveAt = deviceId ? Number(hosts[deviceId]?.lastActiveAt || 0) : 0;
    const activityHandoff =
      Boolean(deviceId) &&
      !expired &&
      cur.deviceId !== deviceId &&
      hasFreshInputSignal &&
      clampedIdle <= HOST_ACTIVE_INPUT_WINDOW_MS &&
      myActiveAt > holderActiveAt + HOST_ACTIVITY_MARGIN_MS;

    if (deviceId && (expired || cur.deviceId === deviceId || activityHandoff)) {
      const takeover = expired || !cur || cur.deviceId !== deviceId;
      if (takeover || hostEntryChanged || now - lastBeat >= HOST_LEASE_WRITE_MS || lastBeat > now) {
        cur = {
          deviceId,
          since: !takeover && Number(cur.since) > 0 ? Number(cur.since) : now,
          lastBeat: now,
          lastActiveAt: myActiveAt,
          hosts
        };
        this._setMeta("host_lease", JSON.stringify(cur));
      }
    } else if (cur && deviceId && hostEntryChanged) {
      cur = {
        ...cur,
        hosts
      };
      this._setMeta("host_lease", JSON.stringify(cur));
    }

    if (!cur || now - Number(cur.lastBeat || 0) > HOST_LEASE_MS) return null;
    return {
      deviceId: cur.deviceId,
      since: Number(cur.since || 0),
      lastBeat: Number(cur.lastBeat || 0),
      lastActiveAt: Number(hosts[cur.deviceId]?.lastActiveAt || cur.lastActiveAt || 0),
      ttlMs: HOST_LEASE_MS,
      legacyLead: this._legacyLeadActive(now)
    };
  }

  // A host on a build from before equal hosts never asks for the duty: it decides by itself that it leads, answers
  // every command addressed to no PC and writes `primary_state` each cycle. Only such a host writes that document,
  // and its write time is stamped here, so a recent write is proof one is online. While that is so the named
  // coordinator stands back, which keeps a command from running on both an old and a new host.
  _legacyLeadActive(now) {
    const rows = [
      ...this.sql.exec("SELECT updated_at FROM docs WHERE store = 'state' AND k = 'primary_state'")
    ];
    if (!rows.length) return false;
    const age = now - Number(rows[0].updated_at || 0);
    return age >= 0 && age <= HOST_LEASE_MS;
  }

  _purgeOldClaims(now) {
    this.sql.exec("DELETE FROM claims WHERE at < ?", now - CLAIM_RETENTION_MS);
  }

  // First device to claim a key owns it. Asking again as the owner answers `claimed: true` (a retry after a dropped
  // reply is safe); `release: true` hands a claim back; `leaseMs` bounds an in-flight execution so a host killed
  // mid-run does not strand a pending queued command forever; `complete: true` (or closing the command in `queue`)
  // seals the claim for the full 30-day retention window.
  _handleClaim(body, cors) {
    const claimKey = typeof body.claimKey === "string" ? body.claimKey : "";
    const deviceId = cleanDeviceId(body.deviceId);
    if (!isValidDocKey(claimKey) || claimKey.length > 200 || !deviceId) {
      return storeJson(400, { ok: false, error: "claimKey and deviceId are required" }, cors);
    }
    const now = Date.now();
    if (body.release) {
      this.sql.exec("DELETE FROM claims WHERE claim_key = ? AND device_id = ?", claimKey, deviceId);
      return storeJson(200, { ok: true, released: true }, cors);
    }
    const rawLease = Number(body.leaseMs || 0);
    const leaseMs =
      Number.isFinite(rawLease) && rawLease > 0
        ? clampInt(rawLease, CLAIM_MIN_LEASE_MS, CLAIM_MAX_LEASE_MS, 120000)
        : 0;
    const nextExpiresAt = body.complete ? 0 : leaseMs > 0 ? now + leaseMs : 0;

    if (body.complete) {
      this.sql.exec(
        "UPDATE claims SET expires_at = 0, at = ? WHERE claim_key = ? AND device_id = ?",
        now,
        claimKey,
        deviceId
      );
      const doneRows = [...this.sql.exec("SELECT device_id, at, expires_at FROM claims WHERE claim_key = ?", claimKey)];
      if (doneRows.length) {
        const owner = String(doneRows[0].device_id || "");
        return storeJson(
          200,
          { ok: true, claimed: owner === deviceId, completed: owner === deviceId, by: owner, at: Number(doneRows[0].at || 0), leaseUntil: Number(doneRows[0].expires_at || 0) },
          cors
        );
      }
    }

    let rows = [...this.sql.exec("SELECT device_id, at, expires_at FROM claims WHERE claim_key = ?", claimKey)];
    if (rows.length) {
      const curExp = Number(rows[0].expires_at || 0);
      const curOwner = String(rows[0].device_id || "");
      if (curExp > 0 && curExp <= now) {
        // Previous holder's in-flight lease expired without completing (crashed mid-run): allow takeover.
        this.sql.exec(
          "UPDATE claims SET device_id = ?, at = ?, expires_at = ? WHERE claim_key = ? AND expires_at > 0 AND expires_at <= ?",
          deviceId,
          now,
          nextExpiresAt,
          claimKey,
          now
        );
        rows = [...this.sql.exec("SELECT device_id, at, expires_at FROM claims WHERE claim_key = ?", claimKey)];
      } else if (curOwner === deviceId && curExp > 0) {
        // Owner re-asking: either seal (nextExpiresAt === 0) or refresh its lease.
        this.sql.exec(
          "UPDATE claims SET at = ?, expires_at = ? WHERE claim_key = ? AND device_id = ?",
          now,
          nextExpiresAt,
          claimKey,
          deviceId
        );
        rows = [...this.sql.exec("SELECT device_id, at, expires_at FROM claims WHERE claim_key = ?", claimKey)];
      }
    } else {
      let cnt = [...this.sql.exec("SELECT COUNT(*) AS n FROM claims")];
      if (Number(cnt[0]?.n || 0) >= MAX_CLAIMS) {
        this._purgeOldClaims(now);
        cnt = [...this.sql.exec("SELECT COUNT(*) AS n FROM claims")];
        if (Number(cnt[0]?.n || 0) >= MAX_CLAIMS) {
          return storeJson(429, { ok: false, error: "too many claims" }, cors);
        }
      }
      this.sql.exec(
        "INSERT OR IGNORE INTO claims (claim_key, device_id, at, expires_at) VALUES (?, ?, ?, ?)",
        claimKey,
        deviceId,
        now,
        nextExpiresAt
      );
      rows = [...this.sql.exec("SELECT device_id, at, expires_at FROM claims WHERE claim_key = ?", claimKey)];
    }
    const owner = String(rows[0]?.device_id || "");
    const leaseUntil = Number(rows[0]?.expires_at || 0);
    return storeJson(
      200,
      {
        ok: true,
        claimed: owner === deviceId,
        by: owner,
        at: Number(rows[0]?.at || 0),
        ...(leaseUntil > 0 ? { leaseUntil } : {})
      },
      cors
    );
  }

  // ---------- auth ----------

  _verifyKey(ns, candidate) {
    return verifyStoreKey(this.env, ns, candidate);
  }

  async _findDelegatedTask(taskId, token) {
    const cleanId = String(taskId || "");
    const cleanTok = String(token || "");
    if (!cleanId || cleanTok.length < 8) return null;
    const map = this._readDoc("control", "delegated_tasks");
    if (!map || typeof map !== "object" || !Object.prototype.hasOwnProperty.call(map, cleanId)) {
      return null;
    }
    const task = map[cleanId];
    if (!task || typeof task !== "object" || !task.token) return null;
    if (!(await storeConstantTimeEqual(cleanTok, String(task.token)))) return null;
    return { map, task, taskId: cleanId };
  }

  // ---------- web push ----------

  async _sendPush(endpoint, vapid, bodyB64, ttl) {
    if (!isAllowedPushEndpoint(endpoint)) return 0;
    const auth = String(vapid || "");
    if (!isValidVapidHeader(auth)) return 0;
    const bytes = decodeBase64Bytes(bodyB64);
    if (!bytes || bytes.length === 0 || bytes.length > 8192) return 0;
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        redirect: "manual", // a push service never redirects; following one would leave the allowlist
        headers: {
          Authorization: auth,
          "Content-Encoding": "aes128gcm",
          "Content-Type": "application/octet-stream",
          TTL: String(clampInt(ttl, 0, 2419200, DEFAULT_PUSH_TTL)),
          Urgency: "high"
        },
        body: bytes,
        signal: AbortSignal.timeout(10000)
      });
      try {
        await res.arrayBuffer();
      } catch {}
      return Number(res.status || 0);
    } catch {
      return 0;
    }
  }

  // ---------- alarm: delayed pushes, hourly slots, housekeeping ----------

  async _armAlarm() {
    const now = Date.now();
    const rows = [...this.sql.exec("SELECT MIN(fire_at) AS m FROM timers")];
    const minFire = Number(rows[0]?.m || 0);
    let next = Math.floor(now / 3600000) * 3600000 + 3600000 + 5000;
    if (minFire > 0) next = Math.min(next, Math.max(minFire, now + 250));
    await this.ctx.storage.setAlarm(next);
  }

  async _ensureAlarm() {
    try {
      const existing = await this.ctx.storage.getAlarm();
      if (!existing) await this._armAlarm();
    } catch {}
  }

  async _fireTimer(row) {
    const timerKey = String(row.timer_key);
    const timerId = String(row.timer_id);
    const cur = this._readDoc("control", timerKey);
    this.sql.exec("DELETE FROM timers WHERE timer_key = ? AND timer_id = ?", timerKey, timerId);
    if (!cur || typeof cur !== "object" || String(cur.id || "") !== timerId) {
      return "skipped"; // cancelled or re-armed with a newer id
    }
    const expPart = Number(cur.expSec) > 0 ? { expSec: Number(cur.expSec) } : {};
    // Pre-claim before the network call: a retried alarm can never send the same timer twice.
    this._writeDoc("control", timerKey, { id: `sending_${timerId}`, ...expPart });
    const status = await this._sendPush(row.endpoint, row.vapid, row.body_b64, row.ttl);
    const after = this._readDoc("control", timerKey);
    if (!after || String(after.id || "") !== `sending_${timerId}`) {
      return "superseded";
    }
    const delivered = (status >= 200 && status < 300) || status === 404 || status === 410;
    const stamp = new Date().toISOString();
    if (delivered) {
      this._writeDoc("control", timerKey, {
        id: `fired_${timerId}`,
        ...expPart,
        firedAt: stamp,
        pushStatus: status
      });
      return "fired";
    }
    this._writeDoc("control", timerKey, {
      id: `failed_${status}_${timerId}`,
      ...expPart,
      failedAt: stamp,
      pushStatus: status
    });
    return "failed";
  }

  async _dispatchHourlySlots(hourKey) {
    const registry = this._readDoc("control", "push_registry");
    const items = Array.isArray(registry?.items) ? registry.items : [];
    let sent = 0;
    for (const item of items) {
      const slot = item && item.slots && typeof item.slots === "object" ? item.slots[hourKey] : null;
      if (!slot || !item.endpoint || !slot.vapid || !slot.bodyB64) continue;
      await this._sendPush(item.endpoint, slot.vapid, slot.bodyB64, DEFAULT_PUSH_TTL);
      sent++;
    }
    return sent;
  }

  _purgeTerminalTimerDocs(now) {
    const cutoff = now - TERMINAL_TIMER_RETENTION_MS;
    for (const glob of TIMER_DOC_GLOBS) {
      const rows = [
        ...this.sql.exec(
          "SELECT k FROM docs WHERE store = 'control' AND k GLOB ? AND updated_at < ? LIMIT 500",
          glob,
          cutoff
        )
      ];
      for (const r of rows) {
        const doc = this._readDoc("control", r.k);
        const id = String(doc?.id || "");
        // sending_ older than the retention window is a send that was interrupted and can never complete.
        if (/^(fired_|failed_|cancelled|sending_)/.test(id)) this._deleteDoc("control", r.k);
      }
    }
  }

  _cancelPendingPrayerTimersByGlob(globPattern, now = Date.now()) {
    const rows = [...this.sql.exec("SELECT timer_key FROM timers WHERE timer_key GLOB ?", globPattern)];
    if (!rows.length) return 0;
    this._atomic(() => {
      for (const r of rows) {
        const k = String(r.timer_key || "");
        if (!k) continue;
        this.sql.exec("DELETE FROM timers WHERE timer_key = ?", k);
        this._writeDoc("control", k, { id: "cancelled" }, now);
      }
    });
    return rows.length;
  }

  // Self-arms a rolling 4-day window of Shia Ja'fari prayer Web Push timers directly inside the Durable Object so
  // prayer notifications keep firing indefinitely even when every PC is powered off for weeks.
  async _ensureStorePrayersArmed(now = Date.now()) {
    if (this._getMeta("ns") === "fitness") return 0;
    const ledger = this._readDoc("control", "personal_ledger");
    if (!ledger || typeof ledger !== "object") return 0;
    const pCfg = ledger.prayerConfig && typeof ledger.prayerConfig === "object" ? ledger.prayerConfig : {};
    if (pCfg.enabled === false) {
      this._cancelPendingPrayerTimersByGlob("prayer_d*", now);
      return 0;
    }
    const registry = this._readDoc("control", "push_registry");
    const subs = dedupeStorePlannerSubs(registry?.items);
    if (!subs.length) {
      this._cancelPendingPrayerTimersByGlob("prayer_d*", now);
      return 0;
    }

    // Cancel pending prayer timers belonging to any device that unsubscribed or disabled prayer pushes.
    const activeDevShorts = new Set(subs.map((s) => getStoreDeviceShortKey(s)).filter(Boolean));
    const existingPrayerRows = [
      ...this.sql.exec("SELECT timer_key FROM timers WHERE timer_key GLOB 'prayer_d*'")
    ];
    const staleDeviceKeys = existingPrayerRows
      .map((r) => String(r.timer_key || ""))
      .filter((k) => {
        const m = /^prayer_d\d_(?:pre_)?(?:fajr|dhuhr|maghrib)_([A-Za-z0-9]+)$/.exec(k);
        return m && !activeDevShorts.has(m[1]);
      });
    if (staleDeviceKeys.length > 0) {
      this._atomic(() => {
        for (const k of staleDeviceKeys) {
          this.sql.exec("DELETE FROM timers WHERE timer_key = ?", k);
          this._writeDoc("control", k, { id: "cancelled" }, now);
        }
      });
    }

    const preMin = Number(pCfg.preRemindMin ?? pCfg.preAlertMin ?? 0);
    if (!(preMin > 0)) {
      this._cancelPendingPrayerTimersByGlob("prayer_d*_pre_*", now);
    }
    if (pCfg.notifyFajr === false) {
      this._cancelPendingPrayerTimersByGlob("prayer_d*_fajr_*", now);
      this._cancelPendingPrayerTimersByGlob("prayer_d*_pre_fajr_*", now);
    }
    if (pCfg.notifyDhuhr === false) {
      this._cancelPendingPrayerTimersByGlob("prayer_d*_dhuhr_*", now);
      this._cancelPendingPrayerTimersByGlob("prayer_d*_pre_dhuhr_*", now);
    }
    if (pCfg.notifyMaghrib === false) {
      this._cancelPendingPrayerTimersByGlob("prayer_d*_maghrib_*", now);
      this._cancelPendingPrayerTimersByGlob("prayer_d*_pre_maghrib_*", now);
    }

    const todaySched = computeStoreShiaPrayers(pCfg, "", now);
    if (!todaySched?.isoDate) return 0;
    const [by, bm, bd] = todaySched.isoDate.split("-").map(Number);
    let armedCount = 0;

    for (let dayOffset = 0; dayOffset < 4; dayOffset++) {
      const dt = new Date(Date.UTC(by, bm - 1, bd + dayOffset));
      const iso = `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, "0")}-${String(dt.getUTCDate()).padStart(2, "0")}`;
      const sched = dayOffset === 0 ? todaySched : computeStoreShiaPrayers(pCfg, iso, now);
      if (!sched || !Array.isArray(sched.prayers)) continue;

      for (const p of sched.prayers) {
        if (!p.enabled) continue;
        for (const sub of subs) {
          const curNow = Date.now();
          if (preMin > 0) {
            const preTargetMs = p.epochMs - preMin * 60000;
            const preDelaySec = Math.round((preTargetMs - curNow) / 1000);
            if (preDelaySec >= 20 && preDelaySec <= 4 * 86400) {
              const preKey = getStorePrayerTimerKey(sub, iso, p.id, true);
              const prePrefix = `${iso}_pre_${p.id}_${preTargetMs}`;
              const ok = await this._tryArmStoreTimer(preKey, prePrefix, preTargetMs, sub, {
                title: `${p.icon} ${p.label} in ${preMin} min · ${p.time24}`,
                body: `${p.arabic} at ${p.time24} in ${sched.locationName}. ${p.windowNote}`,
                tag: `prayer-${iso}-${p.id}-pre`,
                tab: "prayers",
                openPrayer: true,
                url: "./?tab=prayers",
                ts: preTargetMs
              });
              if (ok) armedCount++;
            }
          }

          const delaySec = Math.round((p.epochMs - curNow) / 1000);
          if (delaySec >= 15 && delaySec <= 4 * 86400) {
            const timerKey = getStorePrayerTimerKey(sub, iso, p.id, false);
            const specPrefix = `${iso}_${p.id}_${p.epochMs}`;
            const ok = await this._tryArmStoreTimer(timerKey, specPrefix, p.epochMs, sub, {
              title: `🕌 ${p.label} Prayer Time · ${p.time24} (${p.arabic})`,
              body: `${p.label} has entered in ${sched.locationName}. ${p.windowNote}. Hayya 'ala Khayr al-'Amal.`,
              tag: `prayer-${iso}-${p.id}`,
              tab: "prayers",
              openPrayer: true,
              url: "./?tab=prayers",
              requireInteraction: true,
              ts: p.epochMs
            });
            if (ok) armedCount++;
          }
        }
      }
    }
    return armedCount;
  }

  async _tryArmStoreTimer(timerKey, specPrefix, targetMs, sub, payloadObj) {
    const ns = STORE_NAMESPACES.theo;
    const curDoc = this._readDoc("control", timerKey);
    const curId = String(curDoc?.id || "");
    const hasTimerRow = [...this.sql.exec("SELECT 1 AS ok FROM timers WHERE timer_key = ?", timerKey)].length > 0;
    const alreadyValid =
      curId.startsWith(`fired_${specPrefix}`) ||
      curId.startsWith(`sending_${specPrefix}`) ||
      (hasTimerRow &&
        (curId === specPrefix || curId.startsWith(`${specPrefix}__`)) &&
        hasValidStoreTimerExp(curDoc, targetMs));
    if (alreadyValid) return false;

    const expSec = Math.floor(targetMs / 1000) + 12 * 3600;
    const vapid = await signStoreVapid(sub.endpoint, expSec, this.env);
    const bodyB64 = await encryptStoreWebPush(sub.keys, payloadObj);
    if (!vapid || !bodyB64 || bodyB64.length > 12288) return false;

    const timerId = `${specPrefix}__${randomHexBytes(6)}`;
    const writeNow = Date.now();
    const fireAt = Math.max(writeNow + 1000, targetMs);
    const timerDocStr = JSON.stringify({ id: timerId, expSec });

    let wrote = false;
    this._atomic(() => {
      // Re-check inside transaction in case an interleaved alarm/patch fired or cancelled across the await.
      const latestDoc = this._readDoc("control", timerKey);
      const latestId = String(latestDoc?.id || "");
      const latestHasRow = [...this.sql.exec("SELECT 1 AS ok FROM timers WHERE timer_key = ?", timerKey)].length > 0;
      if (
        latestId.startsWith(`fired_${specPrefix}`) ||
        latestId.startsWith(`sending_${specPrefix}`) ||
        (latestHasRow &&
          (latestId === specPrefix || latestId.startsWith(`${specPrefix}__`)) &&
          hasValidStoreTimerExp(latestDoc, targetMs))
      ) {
        return;
      }
      if (!latestHasRow) {
        const cnt = [...this.sql.exec("SELECT COUNT(*) AS n FROM timers")];
        if (Number(cnt[0]?.n || 0) >= ns.maxTimers) return;
      }
      const prevDoc = [...this.sql.exec("SELECT chars FROM docs WHERE store = 'control' AND k = ?", timerKey)];
      const totals = [...this.sql.exec("SELECT COALESCE(SUM(chars), 0) AS c, COUNT(*) AS n FROM docs")];
      const addedChars = timerDocStr.length - Number(prevDoc[0]?.chars || 0);
      if (addedChars > 0 && Number(totals[0]?.c || 0) + addedChars > ns.maxTotalChars) return;
      if (!prevDoc.length && Number(totals[0]?.n || 0) + 1 > ns.maxDocs) return;

      this.sql.exec(
        `INSERT INTO timers (timer_key, timer_id, fire_at, exp_sec, endpoint, vapid, body_b64, ttl, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(timer_key) DO UPDATE SET
           timer_id = excluded.timer_id,
           fire_at = excluded.fire_at,
           exp_sec = excluded.exp_sec,
           endpoint = excluded.endpoint,
           vapid = excluded.vapid,
           body_b64 = excluded.body_b64,
           ttl = excluded.ttl,
           created_at = excluded.created_at`,
        timerKey,
        timerId,
        fireAt,
        expSec,
        sub.endpoint,
        vapid,
        bodyB64,
        DEFAULT_PUSH_TTL,
        writeNow
      );
      this._writeDocRaw("control", timerKey, timerDocStr, writeNow);
      wrote = true;
    });
    return wrote;
  }

  // Self-arms upcoming Planner task and wait-hold due Web Push timers directly inside the Durable Object so tasks
  // patched to `personal_ledger` while VS Code and Planner are closed (such as the weekly blind-spot review) still
  // send their exact due notification, and completed/deleted tasks cancel their pending timers immediately.
  async _ensureStoreTaskTimersArmed(now = Date.now()) {
    if (this._getMeta("ns") === "fitness") return 0;
    const ledger = this._readDoc("control", "personal_ledger");
    if (
      !ledger ||
      typeof ledger !== "object" ||
      (!Array.isArray(ledger.reminders) && !Array.isArray(ledger.deletedIds))
    ) {
      return 0;
    }

    const inactiveRemIds = new Set();
    if (Array.isArray(ledger.deletedIds)) {
      for (const id of ledger.deletedIds) {
        if (typeof id === "string" && id.trim()) inactiveRemIds.add(id.trim());
      }
    }

    const activeTargetByRemId = new Map();
    const activeIsHoldByRemId = new Map();
    const upcoming = [];
    const reminders = Array.isArray(ledger.reminders) ? ledger.reminders : [];
    for (const rem of reminders) {
      if (!rem || typeof rem !== "object" || !rem.id) continue;
      const remId = String(rem.id).trim();
      if (!remId || remId.length > 140 || !/^[A-Za-z0-9._-]+$/.test(remId)) continue;
      const targetAt = Math.floor(Number(rem.matureAt || rem.dueAt || 0));
      const noAlarm = rem.hasAlarm === false && !(Number(rem.matureAt || 0) > 0);
      if (rem.completed || rem.deleted || inactiveRemIds.has(remId) || noAlarm || !(targetAt > 0)) {
        inactiveRemIds.add(remId);
      } else {
        const isHold = Boolean(
          Number(rem.matureAt || 0) > 0 ||
            rem.kind === "wait" ||
            rem.category === "verify" ||
            rem.category === "shipping" ||
            rem.category === "payments"
        );
        activeTargetByRemId.set(remId, targetAt);
        activeIsHoldByRemId.set(remId, isHold);
        upcoming.push({ rem, remId, targetAt, isHold });
      }
    }

    const registry = this._readDoc("control", "push_registry");
    const subs = dedupeStorePlannerTaskSubs(registry?.items);
    const holdDevShorts = new Set();
    const taskDevShorts = new Set();
    for (const sub of subs) {
      const devShort = String(sub.id || String(sub.endpoint || "").slice(-10))
        .replace(/[^a-zA-Z0-9]/g, "")
        .slice(-10);
      if (!devShort) continue;
      if (sub.prefs?.timers !== false) holdDevShorts.add(devShort);
      if (sub.prefs?.tasks !== false) taskDevShorts.add(devShort);
    }

    // Cancel pending `timer_*` rows whose reminder was completed, deleted, removed, rescheduled, or opted out per device.
    const pendingRows = [
      ...this.sql.exec("SELECT timer_key, timer_id FROM timers WHERE timer_key GLOB 'timer_*'")
    ];
    if (pendingRows.length) {
      const toCancel = [];
      for (const r of pendingRows) {
        const tk = String(r.timer_key || "");
        if (!tk.startsWith("timer_")) continue;
        const rest = tk.slice(6);
        if (inactiveRemIds.has(rest)) {
          toCancel.push(tk);
          continue;
        }
        const idx = rest.lastIndexOf("_");
        if (idx <= 0) {
          if (!activeTargetByRemId.has(rest)) toCancel.push(tk);
          continue;
        }
        const remId = rest.slice(0, idx);
        const devPart = rest.slice(idx + 1);
        if (!activeTargetByRemId.has(remId)) {
          toCancel.push(tk);
          continue;
        }
        const isHold = activeIsHoldByRemId.get(remId);
        const allowedSet = isHold ? holdDevShorts : taskDevShorts;
        if (!allowedSet.has(devPart)) {
          toCancel.push(tk);
          continue;
        }
        const curTarget = activeTargetByRemId.get(remId);
        const expectedPrefix = `${remId}_${curTarget}_${devPart}`;
        const tid = String(r.timer_id || "");
        if (tid !== expectedPrefix && !tid.startsWith(`${expectedPrefix}__`)) {
          toCancel.push(tk);
        }
      }
      if (toCancel.length) {
        this._atomic(() => {
          for (const tk of toCancel) {
            this.sql.exec("DELETE FROM timers WHERE timer_key = ?", tk);
            this._writeDoc("control", tk, { id: "cancelled" }, now);
          }
        });
      }
    }

    if (!subs.length || !upcoming.length) return 0;

    upcoming.sort((a, b) => a.targetAt - b.targetAt);
    let armedCount = 0;

    for (const { rem, remId, targetAt, isHold } of upcoming.slice(0, 120)) {
      const delaySec = Math.round((targetAt - Date.now()) / 1000);
      if (delaySec < 5 || delaySec > 25 * 86400) continue;
      const isDel = Boolean(rem.isDelegated || rem.assigneeName || rem.category === "people");
      const cat = String(rem.category || "work");
      let pushTitle = "⏰ Task Due — Planner";
      if (cat === "verify") pushTitle = "🔍 Verify on App — Planner";
      else if (cat === "shipping") pushTitle = "📦 Shipping Timer Ready — Planner";
      else if (cat === "payments") pushTitle = "💸 Payment Hold Matured — Planner";
      else if (isDel) pushTitle = `👤 Follow-Up Due: ${rem.assigneeName || "Team"} — Planner`;
      else if (isHold) pushTitle = "⏳ Wait Timer Ready — Planner";
      else if (rem.recur && rem.recur !== "none") {
        pushTitle = `🔁 ${rem.recur === "weekly" ? "Weekly" : "Daily"} Task Due — Planner`;
      }
      const targetTab = isDel ? "delegated" : "tasks";
      const ctxTag = rem.subTag || rem.subGroup || (rem.assigneeName ? `👤 ${rem.assigneeName}` : "");
      const amtNum = Number(rem.amount || 0);
      const amtTag = amtNum > 0 ? ` · $${amtNum.toLocaleString("en-US")}` : "";
      const titleText = String(rem.title || "Task").slice(0, 300);
      const payloadObj = {
        id: `rem-due-${remId}-${targetAt}`,
        title: pushTitle,
        body: `${titleText}${ctxTag ? ` (${String(ctxTag).slice(0, 80)})` : ""}${amtTag}`,
        tag: `cmd-timer-${remId}`,
        tab: targetTab,
        taskId: remId,
        reminderId: remId,
        url: `./?tab=${targetTab}&taskId=${encodeURIComponent(remId)}`,
        requireInteraction: true,
        ts: targetAt
      };

      for (const sub of subs) {
        if (isHold && sub.prefs?.timers === false) continue;
        if (!isHold && sub.prefs?.tasks === false) continue;
        const devShort = String(sub.id || String(sub.endpoint || "").slice(-10))
          .replace(/[^a-zA-Z0-9]/g, "")
          .slice(-10);
        if (!devShort) continue;
        const timerKey = `timer_${remId}_${devShort}`;
        const specPrefix = `${remId}_${targetAt}_${devShort}`;
        const ok = await this._tryArmStoreTimer(timerKey, specPrefix, targetAt, sub, payloadObj);
        if (ok) armedCount++;
      }
    }
    return armedCount;
  }

  async alarm() {
    const now = Date.now();
    try {
      const due = [
        ...this.sql.exec("SELECT * FROM timers WHERE fire_at <= ? ORDER BY fire_at LIMIT 60", now)
      ];
      for (const row of due) {
        try {
          await this._fireTimer(row);
        } catch {}
      }
      // Read the clock again: slow pushes above can carry this run across an hour boundary, and the hour that
      // has just begun must be dispatched now because the next alarm is armed for the hour after it.
      const hourKey = new Date(Date.now()).toISOString().slice(0, 13);
      if (this._getMeta("last_slot_hour") !== hourKey) {
        // Stamp first: an hour is dispatched at most once even if the alarm is retried.
        this._setMeta("last_slot_hour", hourKey);
        try {
          await this._dispatchHourlySlots(hourKey);
        } catch {}
      }
      if (this._getMeta("last_prayer_arm_hour") !== hourKey) {
        this._setMeta("last_prayer_arm_hour", hourKey);
        try {
          await this._ensureStorePrayersArmed(Date.now());
        } catch {}
        try {
          await this._ensureStoreTaskTimersArmed(Date.now());
        } catch {}
      }
      const dayKey = hourKey.slice(0, 10);
      if (this._getMeta("last_purge_day") !== dayKey) {
        this._setMeta("last_purge_day", dayKey);
        try {
          this._purgeTerminalTimerDocs(now);
        } catch {}
        try {
          this._purgeOldClaims(now);
        } catch {}
      }
    } finally {
      await this._armAlarm();
    }
  }

  // ---------- request handling ----------

  async fetch(request) {
    const cors = storeCorsHeaders(request);
    const ns = storeNamespaceFromPath(new URL(request.url).pathname);
    if (!ns) return storeJson(404, { ok: false, error: "not found" }, cors);
    if (request.method !== "POST") return storeJson(405, { ok: false, error: "POST required" }, cors);

    // The Worker has already capped and authenticated this request; the object repeats both checks so that it
    // stays safe if it is ever reached another way.
    let raw = null;
    try {
      raw = await readBodyCapped(request, ns.maxBodyBytes);
    } catch {
      return storeJson(400, { ok: false, error: "unreadable body" }, cors);
    }
    if (raw === null) {
      return storeJson(413, { ok: false, error: "Payload too large" }, cors);
    }
    let body = null;
    try {
      body = JSON.parse(raw);
    } catch {
      return storeJson(400, { ok: false, error: "invalid json" }, cors);
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return storeJson(400, { ok: false, error: "invalid json" }, cors);
    }
    const op = String(body.op || "");

    // Staff task links carry their own per-task token and never the store key.
    if (ns.delegates && (op === "delegate_get" || op === "delegate_update")) {
      if (raw.length > KEYLESS_MAX_BODY_BYTES) {
        return storeJson(413, { ok: false, error: "Payload too large" }, cors);
      }
      return this._handleDelegate(op, body, cors);
    }

    const keyOk = await this._verifyKey(ns, body.key || bearerFromRequest(request));
    if (!keyOk) {
      if (isKeylessOp(ns, body) && raw.length <= KEYLESS_MAX_BODY_BYTES) {
        return this._handleDelegatePush(body, cors);
      }
      return storeJson(401, { ok: false, error: "bad key" }, cors);
    }

    if (this._getMeta("ns") !== ns.name) {
      this._setMeta("ns", ns.name);
    }
    await this._ensureAlarm();

    if (op === "get_control") {
      // A host that names itself takes part in the coordinator duty; phones and older hosts send no deviceId.
      const hostId = ns.hosts ? cleanDeviceId(body.deviceId) : "";
      const coordinator = hostId ? this._touchHostLease(hostId, Date.now(), body.idleMs) : null;
      return this._docsResponse(["control"], cors, null, coordinator);
    }
    if (op === "get") return this._docsResponse(["control"], cors);
    if (op === "get_theo") return this._docsResponse(ns.split ? ["state", "control"] : ["control"], cors);
    if (op === "patch") return this._handlePatch(ns, body, cors);
    if (op === "claim" && ns.hosts) return this._handleClaim(body, cors);
    if (op === "push") return this._handlePush(body, cors);
    if (op === "push_delay") return this._handlePushDelay(ns, body, cors);
    if (op === "get_mfg") return storeJson(410, { ok: false, error: "gone" }, cors);
    return storeJson(400, { ok: false, error: "unknown op" }, cors);
  }

  async _handlePatch(ns, body, cors) {
    const patch = body.patch;
    if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
      return storeJson(400, { ok: false, error: "patch must be an object" }, cors);
    }
    const keys = Object.keys(patch);
    if (keys.length > 500) {
      return storeJson(413, { ok: false, error: "too many keys in one patch" }, cors);
    }
    const store = ns.split && (patch.state != null || patch.threads != null) ? "state" : "control";
    for (const k of keys) {
      if (!isValidDocKey(k)) {
        return storeJson(400, { ok: false, error: "invalid doc key" }, cors);
      }
    }

    // Compute claim seals before the synchronous read-merge-write block so no `await` sits between reading
    // `device_states` / `personal_ledger` and committing `_atomic`.
    const sealClaimKeys = new Set();
    if (ns.hosts) {
      if (Array.isArray(body.sealClaims)) {
        for (const ck of body.sealClaims.slice(0, 50)) {
          if (typeof ck === "string" && isValidDocKey(ck) && ck.length <= 200) {
            sealClaimKeys.add(ck);
          }
        }
      }
      if (store === "control" && patch.queue && Array.isArray(patch.queue.commands)) {
        for (const c of patch.queue.commands.slice(-40)) {
          if (c && c.id && (c.status === "done" || c.status === "error")) {
            const hex = await sha256HexStore(`${c.id}:${c.createdAt || 0}`);
            sealClaimKeys.add(`cmd:${hex}`);
          }
        }
      }
    }

    const writes = [];
    let addedChars = 0;
    let addedDocs = 0;
    let mergedClaudeMode = null;
    const now = Date.now();
    for (const k of keys) {
      let val = patch[k];
      // `claude_permission_mode` always lives in the `control` store so every `get_control` host poll and
      // `get_theo` client sync sees one canonical fleet mode regardless of whether `state`/`threads` were also in `patch`.
      const targetStore = ns.hosts && k === "claude_permission_mode" ? "control" : store;
      if (val === null || val === undefined) {
        writes.push({ targetStore, k, del: true });
        continue;
      }
      if (ns.hosts && k === "claude_permission_mode") {
        if (typeof val !== "object" || Array.isArray(val)) {
          return storeJson(400, { ok: false, error: "invalid claude_permission_mode" }, cors);
        }
        const candidateMode = normalizeStoreClaudePermissionMode(val.defaultMode || val.mode);
        if (!candidateMode || !VALID_CLAUDE_PERMISSION_MODES.has(candidateMode)) {
          return storeJson(400, { ok: false, error: "invalid claude_permission_mode" }, cors);
        }
        val = mergeClaudePermissionMode(this._readDoc("control", k), val, now);
        mergedClaudeMode = val;
      } else if (ns.hosts && k === "device_states" && typeof val === "object" && !Array.isArray(val)) {
        // Whichever store a host's patch lands in, the fleet map is merged per device and never replaced whole.
        const ownerId = cleanDeviceId(patch.meta && typeof patch.meta === "object" ? patch.meta.deviceId : "");
        val = mergeDeviceStates(this._readDoc(targetStore, k), val, now, ownerId);
      } else if (
        ns.hosts &&
        targetStore === "control" &&
        k === "personal_ledger" &&
        typeof val === "object" &&
        !Array.isArray(val)
      ) {
        // Every `personal_ledger` write (workstation bridge, Planner PWA, or headless blind-spot review)
        // union-merges against stored state so concurrent patches never clobber tasks, scores, or configs.
        val = mergePersonalLedger(this._readDoc(targetStore, k), val, now);
      }
      const jsonStr = JSON.stringify(val);
      if (jsonStr.length > ns.maxDocChars) {
        return storeJson(413, { ok: false, error: `doc too large: ${k.slice(0, 80)}` }, cors);
      }
      const prev = [...this.sql.exec("SELECT chars FROM docs WHERE store = ? AND k = ?", targetStore, k)];
      addedChars += jsonStr.length - Number(prev[0]?.chars || 0);
      if (!prev.length) addedDocs++;
      writes.push({
        targetStore,
        k,
        jsonStr,
        id: val && typeof val === "object" ? String(val.id ?? "") : ""
      });
    }
    const totals = [...this.sql.exec("SELECT COALESCE(SUM(chars), 0) AS c, COUNT(*) AS n FROM docs")];
    if (addedChars > 0 && Number(totals[0]?.c || 0) + addedChars > ns.maxTotalChars) {
      return storeJson(507, { ok: false, error: "store is full" }, cors);
    }
    if (addedDocs > 0 && Number(totals[0]?.n || 0) + addedDocs > ns.maxDocs) {
      return storeJson(507, { ok: false, error: "too many docs" }, cors);
    }

    this._atomic(() => {
      for (const w of writes) {
        if (w.del) {
          this._deleteDoc(w.targetStore, w.k);
          if (w.targetStore === "control") this.sql.exec("DELETE FROM timers WHERE timer_key = ?", w.k);
          continue;
        }
        this._writeDocRaw(w.targetStore, w.k, w.jsonStr, now);
        if (w.targetStore === "control") {
          // A patch that replaces a timer doc (cancel, or a stamp written by a host) retires the pending timer.
          this.sql.exec("DELETE FROM timers WHERE timer_key = ? AND timer_id != ?", w.k, w.id);
        }
      }
      for (const ck of sealClaimKeys) {
        this.sql.exec("UPDATE claims SET expires_at = 0, at = ? WHERE claim_key = ?", now, ck);
      }
    });

    if (ns.hosts && store === "control" && ("personal_ledger" in patch || "push_registry" in patch)) {
      try {
        await this._ensureStorePrayersArmed(Date.now());
      } catch {}
      try {
        await this._ensureStoreTaskTimersArmed(Date.now());
      } catch {}
      try {
        await this._armAlarm();
      } catch {}
    }

    if (body.ackOnly) {
      return storeJson(
        200,
        {
          ok: true,
          serverTime: new Date().toISOString(),
          ...(mergedClaudeMode ? { claude_permission_mode: mergedClaudeMode } : {})
        },
        cors
      );
    }
    const respStores =
      store === "state" && writes.some((w) => w.targetStore === "control")
        ? ["state", "control"]
        : [store];
    return this._docsResponse(respStores, cors);
  }

  async _handlePush(body, cors) {
    const endpoint = String(body.endpoint || "");
    if (!isAllowedPushEndpoint(endpoint)) {
      return storeJson(400, { ok: false, error: "push endpoint not allowed" }, cors);
    }
    const vapid = String(body.vapid || body.auth || "");
    const bodyB64 = String(body.bodyB64 || "");
    if (!vapid || !bodyB64) {
      return storeJson(400, { ok: false, error: "vapid and bodyB64 are required" }, cors);
    }
    if (!isValidVapidHeader(vapid)) {
      return storeJson(400, { ok: false, error: "vapid must be a VAPID Authorization value" }, cors);
    }
    const pushStatus = await this._sendPush(endpoint, vapid, bodyB64, body.ttl);
    return storeJson(200, { ok: pushStatus >= 200 && pushStatus < 300, pushStatus }, cors);
  }

  async _handlePushDelay(ns, body, cors) {
    const timerKey = String(body.timerKey || "");
    const timerId = String(body.timerId || "");
    if (!isTimerDocKey(timerKey) || !timerId || timerId.length > 300 || LONE_SURROGATE_RE.test(timerId)) {
      return storeJson(400, { ok: false, error: "timerKey and timerId are required" }, cors);
    }
    const endpoint = String(body.endpoint || "");
    if (!isAllowedPushEndpoint(endpoint)) {
      return storeJson(400, { ok: false, error: "push endpoint not allowed" }, cors);
    }
    const vapid = String(body.vapid || body.auth || "");
    const bodyB64 = String(body.bodyB64 || "");
    if (!isValidVapidHeader(vapid) || !bodyB64 || bodyB64.length > 12288) {
      return storeJson(400, { ok: false, error: "vapid and bodyB64 are required" }, cors);
    }
    const rawDelay = Number(body.delaySec);
    if (!Number.isFinite(rawDelay) || rawDelay < 0) {
      return storeJson(400, { ok: false, error: "delaySec must be a non-negative number" }, cors);
    }
    const existing = [...this.sql.exec("SELECT timer_key FROM timers WHERE timer_key = ?", timerKey)];
    if (!existing.length) {
      const cnt = [...this.sql.exec("SELECT COUNT(*) AS n FROM timers")];
      if (Number(cnt[0]?.n || 0) >= ns.maxTimers) {
        return storeJson(429, { ok: false, error: "too many pending timers" }, cors);
      }
    }
    const now = Date.now();
    const delaySec = clampInt(rawDelay, 0, MAX_DELAY_SEC, 0);
    const fireAt = now + delaySec * 1000;
    const expSec = clampInt(body.expSec, 0, 4102444800, 0);
    const ttl = clampInt(body.ttl, 0, 2419200, DEFAULT_PUSH_TTL);
    // The timer's control doc counts against the same store caps as a patch would.
    const timerDoc = expSec > 0 ? { id: timerId, expSec } : { id: timerId };
    const timerDocStr = JSON.stringify(timerDoc);
    const prevDoc = [...this.sql.exec("SELECT chars FROM docs WHERE store = 'control' AND k = ?", timerKey)];
    const totals = [...this.sql.exec("SELECT COALESCE(SUM(chars), 0) AS c, COUNT(*) AS n FROM docs")];
    const addedChars = timerDocStr.length - Number(prevDoc[0]?.chars || 0);
    if (addedChars > 0 && Number(totals[0]?.c || 0) + addedChars > ns.maxTotalChars) {
      return storeJson(507, { ok: false, error: "store is full" }, cors);
    }
    if (!prevDoc.length && Number(totals[0]?.n || 0) + 1 > ns.maxDocs) {
      return storeJson(507, { ok: false, error: "too many docs" }, cors);
    }
    this._atomic(() => {
      this.sql.exec(
        `INSERT INTO timers (timer_key, timer_id, fire_at, exp_sec, endpoint, vapid, body_b64, ttl, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(timer_key) DO UPDATE SET
           timer_id = excluded.timer_id,
           fire_at = excluded.fire_at,
           exp_sec = excluded.exp_sec,
           endpoint = excluded.endpoint,
           vapid = excluded.vapid,
           body_b64 = excluded.body_b64,
           ttl = excluded.ttl,
           created_at = excluded.created_at`,
        timerKey,
        timerId,
        fireAt,
        expSec,
        endpoint,
        vapid,
        bodyB64,
        ttl,
        now
      );
      this._writeDocRaw("control", timerKey, timerDocStr, now);
    });
    await this._armAlarm();
    return storeJson(200, { ok: true, timerKey, timerId, fireAt }, cors);
  }

  async _handleDelegate(op, body, cors) {
    const found = await this._findDelegatedTask(body.taskId, body.token);
    if (!found) {
      return storeJson(403, { ok: false, error: "Invalid or expired task link" }, cors);
    }
    const { map, task, taskId } = found;
    // The staff page only needs to know whether a completion notice exists, never its pre-signed contents.
    const staffView = (t) => ({ ...t, pushOnDone: t.pushOnDone ? true : null });
    if (op === "delegate_get") {
      return storeJson(200, { ok: true, task: staffView(task) }, cors);
    }
    const status = String(body.status || "").trim();
    if (!DELEGATE_STATUSES.has(status)) {
      return storeJson(400, { ok: false, error: "invalid status" }, cors);
    }
    const becameDone = status === "done" && task.delegationStatus !== "done";
    task.delegationStatus = status;
    if (typeof body.staffNote === "string") {
      task.staffNote = body.staffNote.slice(0, 2000);
    }
    task.staffUpdatedAt = new Date().toISOString();
    map[taskId] = task;
    this._writeDoc("control", "delegated_tasks", map);
    if (becameDone && task.pushOnDone) {
      const list = Array.isArray(task.pushOnDone) ? task.pushOnDone : [task.pushOnDone];
      for (const p of list.slice(0, 8)) {
        if (!p || !p.endpoint || !p.vapid || !p.bodyB64) continue;
        try {
          await this._sendPush(p.endpoint, p.vapid, p.bodyB64, DEFAULT_PUSH_TTL);
        } catch {}
      }
    }
    return storeJson(200, { ok: true, task: staffView(task) }, cors);
  }

  // A staff page may notify the task owner, and only the owner devices listed on that task.
  async _handleDelegatePush(body, cors) {
    const found = await this._findDelegatedTask(body.taskId, body.token);
    if (!found) {
      return storeJson(401, { ok: false, error: "bad key" }, cors);
    }
    const endpoint = String(body.endpoint || "");
    const targets = Array.isArray(found.task.ownerPushTargets) ? found.task.ownerPushTargets : [];
    if (!endpoint || !targets.some((t) => t && t.endpoint === endpoint)) {
      return storeJson(403, { ok: false, error: "push target not allowed for this task" }, cors);
    }
    return this._handlePush(body, cors);
  }
}
