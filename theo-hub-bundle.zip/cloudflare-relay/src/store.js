// THEO Store v1 — SQLite Durable Object that replaces the Power Automate "Cloud Relay" flows and their Dataverse stores.
// Wire-compatible with the legacy contract so existing clients only change URL and key:
//   POST text/plain JSON { key, op, ... }  ->  { ok, serverTime, docs } | { ok, pushStatus } | { ok, task }
// Ops: get | get_control | get_theo | patch | push | push_delay | delegate_get | delegate_update
// Also owns what the two hourly "Daily Push" flows did: push_registry.items[].slots[<UTC yyyy-MM-ddTHH>].

import { DurableObject } from "cloudflare:workers";

const STORE_ALLOWED_ORIGINS = new Set([
  "https://husseinbdeir.github.io",
  "http://127.0.0.1:4318",
  "http://localhost:4318"
]);

// One isolated Durable Object per namespace. `split` mirrors the legacy state/control store routing.
const STORE_NAMESPACES = {
  theo: {
    name: "theo",
    room: "theo-store-v1",
    secrets: ["AUTH_TOKEN", "AUTH_TOKEN_PREV"],
    split: true,
    delegates: true,
    maxBodyBytes: 8 * 1024 * 1024,
    maxDocChars: 6 * 1024 * 1024,
    maxTotalChars: 24 * 1024 * 1024,
    maxDocs: 4000,
    maxTimers: 2000
  },
  fitness: {
    name: "fitness",
    room: "fitness-store-v1",
    secrets: ["FITNESS_KEY"],
    split: false,
    delegates: false,
    maxBodyBytes: 1024 * 1024,
    maxDocChars: 600 * 1024,
    maxTotalChars: 8 * 1024 * 1024,
    maxDocs: 5000,
    maxTimers: 300
  }
};

// Requests that carry no store key (staff task links) are small by nature.
const KEYLESS_MAX_BODY_BYTES = 16 * 1024;
const MAX_ENDPOINT_CHARS = 2048;

const CHUNK_CHARS = 480 * 1024; // worst case 3 UTF-8 bytes per UTF-16 unit stays under the 2 MB row limit
const MAX_DELAY_SEC = 35 * 86400;
const DEFAULT_PUSH_TTL = 14400;
const TERMINAL_TIMER_RETENTION_MS = 14 * 86400 * 1000;
const DELEGATE_STATUSES = new Set(["assigned", "sent", "seen", "working", "blocked", "done"]);
const TIMER_DOC_GLOBS = ["timer_*", "timer/*", "prayer_*", "theo_brief_*", "push_timer/*"];

function storeNamespaceFromPath(pathname) {
  const clean = String(pathname || "").replace(/\/+$/, "");
  if (clean === "/store") return STORE_NAMESPACES.theo;
  if (clean === "/store/fitness") return STORE_NAMESPACES.fitness;
  return null;
}

function storeCorsHeaders(request) {
  const origin = request?.headers?.get("Origin") || "";
  return {
    "Access-Control-Allow-Origin": STORE_ALLOWED_ORIGINS.has(origin) ? origin : "https://husseinbdeir.github.io",
    Vary: "Origin",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Cache-Control": "no-store"
  };
}

function storeJson(status, obj, cors) {
  return new Response(typeof obj === "string" ? obj : JSON.stringify(obj), {
    status,
    headers: { ...cors, "Content-Type": "application/json" }
  });
}

async function storeConstantTimeEqual(a, b) {
  const enc = new TextEncoder();
  const [da, db] = await Promise.all([
    crypto.subtle.digest("SHA-256", enc.encode(String(a || ""))),
    crypto.subtle.digest("SHA-256", enc.encode(String(b || "")))
  ]);
  return crypto.subtle.timingSafeEqual(da, db);
}

// Web Push subscription endpoints only (exact host + path prefix): the relay must never become an open HTTP
// forwarder, nor a way to call provider APIs such as APNs or FCM v1 with a caller-supplied credential.
function isAllowedPushEndpoint(rawUrl) {
  const raw = String(rawUrl || "");
  if (!raw || raw.length > MAX_ENDPOINT_CHARS) return false;
  let u;
  try {
    u = new URL(raw);
  } catch {
    return false;
  }
  if (u.protocol !== "https:" || u.username || u.password) return false;
  if (u.port && u.port !== "443") return false;
  const h = u.hostname.toLowerCase();
  const p = u.pathname;
  if (h === "web.push.apple.com") return p.length > 1;
  if (h === "fcm.googleapis.com") return p.startsWith("/fcm/send/") || p.startsWith("/wp/");
  if (h === "updates.push.services.mozilla.com") return p.startsWith("/wpush/");
  if (h.endsWith(".notify.windows.com")) return p.startsWith("/w/");
  return false;
}

// RFC 8292 header value only ("vapid t=..., k=..."; "WebPush <jwt>" is the older draft form).
function isValidVapidHeader(value) {
  const v = String(value || "");
  return v.length > 8 && v.length <= 4096 && !/[\r\n]/.test(v) && /^(vapid|WebPush) /i.test(v);
}

async function verifyStoreKey(env, ns, candidate) {
  const clean = String(candidate || "").trim();
  if (clean.length < 16) return false;
  let ok = false;
  for (const name of ns.secrets) {
    const expected = String(env?.[name] || "").trim();
    if (expected.length < 16) continue;
    if (await storeConstantTimeEqual(clean, expected)) ok = true;
  }
  return ok;
}

// Reads at most maxBytes of the body. Returns null when the body is larger, so an oversized upload is dropped
// while it streams instead of being buffered whole.
async function readBodyCapped(request, maxBytes) {
  if (!request.body) return "";
  const reader = request.body.getReader();
  const chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) {
      try {
        await reader.cancel();
      } catch {}
      return null;
    }
    chunks.push(value);
  }
  const buf = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) {
    buf.set(c, off);
    off += c.byteLength;
  }
  return new TextDecoder().decode(buf);
}

function bearerFromRequest(request) {
  const authHdr = String(request.headers.get("Authorization") || "").trim();
  return /^Bearer\s+/i.test(authHdr) ? authHdr.replace(/^Bearer\s+/i, "").trim() : "";
}

function isKeylessOp(ns, body) {
  if (!ns.delegates || !body) return false;
  const op = String(body.op || "");
  if (op === "delegate_get" || op === "delegate_update") return true;
  return op === "push" && !body.key && Boolean(body.taskId) && Boolean(body.token);
}

function decodeBase64Bytes(b64) {
  let s = String(b64 || "").replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/");
  if (!s || /[^A-Za-z0-9+/=]/.test(s)) return null;
  while (s.length % 4) s += "=";
  try {
    const bin = atob(s);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  } catch {
    return null;
  }
}

const LONE_SURROGATE_RE = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/;

function isValidDocKey(k) {
  return (
    typeof k === "string" &&
    k.length > 0 &&
    k.length <= 256 &&
    !/[\u0000-\u001f]/.test(k) &&
    !LONE_SURROGATE_RE.test(k) // a lone surrogate would be stored as U+FFFD and collide with other keys
  );
}

// Delayed pushes may only use the key families the clients use, which are also the ones the daily purge reclaims.
function isTimerDocKey(k) {
  return isValidDocKey(k) && k.length <= 200 && /^(timer_|timer\/|prayer_|theo_brief_|push_timer\/)./.test(k);
}

function clampInt(val, min, max, fallback) {
  const n = Math.round(Number(val));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

// Called by the Worker entry. Returns null when the path is not a store path, otherwise a Promise<Response>.
export function routeStoreRequest(request, env) {
  const url = new URL(request.url);
  if (url.pathname !== "/store" && !url.pathname.startsWith("/store/")) return null;
  return handleStoreRoute(request, env, url);
}

// Runs in the stateless Worker: size cap, JSON shape and the store key are all checked here, so traffic without
// a valid key (or a valid-looking staff request) never reaches, wakes or fills the Durable Object.
async function handleStoreRoute(request, env, url) {
  const cors = storeCorsHeaders(request);
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors });
  }
  if (url.pathname === "/store/health") {
    return storeJson(200, { ok: true, service: "THEO Store", version: 1, ts: Date.now() }, cors);
  }
  const ns = storeNamespaceFromPath(url.pathname);
  if (!ns) {
    return storeJson(404, { ok: false, error: "not found" }, cors);
  }
  if (request.method !== "POST") {
    return storeJson(405, { ok: false, error: "POST required" }, cors);
  }
  const origin = request.headers.get("Origin") || "";
  if (origin && !STORE_ALLOWED_ORIGINS.has(origin)) {
    return storeJson(403, { ok: false, error: "Forbidden Origin" }, cors);
  }
  const declaredLen = Number(request.headers.get("Content-Length") || 0);
  if (declaredLen > ns.maxBodyBytes) {
    return storeJson(413, { ok: false, error: "Payload too large" }, cors);
  }
  let raw = null;
  try {
    raw = await readBodyCapped(request, ns.maxBodyBytes);
  } catch {
    return storeJson(400, { ok: false, error: "unreadable body" }, cors);
  }
  if (raw === null) {
    return storeJson(413, { ok: false, error: "Payload too large" }, cors);
  }
  let body = null;
  try {
    body = JSON.parse(raw);
  } catch {
    return storeJson(400, { ok: false, error: "invalid json" }, cors);
  }
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return storeJson(400, { ok: false, error: "invalid json" }, cors);
  }
  const bearer = bearerFromRequest(request);
  const keyOk = await verifyStoreKey(env, ns, body.key || bearer);
  if (!keyOk) {
    if (!isKeylessOp(ns, body) || raw.length > KEYLESS_MAX_BODY_BYTES) {
      return storeJson(401, { ok: false, error: "bad key" }, cors);
    }
  }
  const stub = env.THEO_STORE.get(env.THEO_STORE.idFromName(ns.room));
  const fwdHeaders = { "Content-Type": "text/plain;charset=UTF-8" };
  if (origin) fwdHeaders.Origin = origin;
  if (bearer) fwdHeaders.Authorization = `Bearer ${bearer}`;
  return stub.fetch(new Request(request.url, { method: "POST", headers: fwdHeaders, body: raw }));
}

export class TheoStoreRoom extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx = ctx;
    this.env = env;
    this.sql = ctx.storage.sql;
    this._initSchema();
  }

  _initSchema() {
    this.sql.exec(`
      CREATE TABLE IF NOT EXISTS docs (
        store TEXT NOT NULL,
        k TEXT NOT NULL,
        chars INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (store, k)
      );
      CREATE TABLE IF NOT EXISTS doc_chunks (
        store TEXT NOT NULL,
        k TEXT NOT NULL,
        seq INTEGER NOT NULL,
        v TEXT NOT NULL,
        PRIMARY KEY (store, k, seq)
      );
      CREATE TABLE IF NOT EXISTS timers (
        timer_key TEXT PRIMARY KEY,
        timer_id TEXT NOT NULL,
        fire_at INTEGER NOT NULL,
        exp_sec INTEGER NOT NULL DEFAULT 0,
        endpoint TEXT NOT NULL,
        vapid TEXT NOT NULL,
        body_b64 TEXT NOT NULL,
        ttl INTEGER NOT NULL DEFAULT 14400,
        created_at INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS meta (
        k TEXT PRIMARY KEY,
        v TEXT
      );
    `);
    // A new store only dispatches hourly slots for hours that begin after it was created,
    // so the hour in which a migration happens is never sent twice.
    this.sql.exec(
      "INSERT OR IGNORE INTO meta (k, v) VALUES ('last_slot_hour', ?)",
      new Date().toISOString().slice(0, 13)
    );
  }

  _atomic(fn) {
    if (typeof this.ctx.storage.transactionSync === "function") {
      return this.ctx.storage.transactionSync(fn);
    }
    return fn();
  }

  _getMeta(k) {
    const rows = [...this.sql.exec("SELECT v FROM meta WHERE k = ?", k)];
    return rows.length ? String(rows[0].v ?? "") : "";
  }

  _setMeta(k, v) {
    this.sql.exec(
      "INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v",
      k,
      String(v)
    );
  }

  // ---------- documents ----------

  _writeDocRaw(store, k, jsonStr, now) {
    this.sql.exec("DELETE FROM doc_chunks WHERE store = ? AND k = ?", store, k);
    let seq = 0;
    let i = 0;
    while (i < jsonStr.length) {
      let end = Math.min(jsonStr.length, i + CHUNK_CHARS);
      if (end < jsonStr.length) {
        const c = jsonStr.charCodeAt(end - 1);
        if (c >= 0xd800 && c <= 0xdbff) end -= 1; // never split a surrogate pair across rows
      }
      this.sql.exec(
        "INSERT INTO doc_chunks (store, k, seq, v) VALUES (?, ?, ?, ?)",
        store,
        k,
        seq++,
        jsonStr.slice(i, end)
      );
      i = end;
    }
    this.sql.exec(
      `INSERT INTO docs (store, k, chars, updated_at) VALUES (?, ?, ?, ?)
       ON CONFLICT(store, k) DO UPDATE SET chars = excluded.chars, updated_at = excluded.updated_at`,
      store,
      k,
      jsonStr.length,
      now
    );
  }

  _deleteDoc(store, k) {
    this.sql.exec("DELETE FROM doc_chunks WHERE store = ? AND k = ?", store, k);
    this.sql.exec("DELETE FROM docs WHERE store = ? AND k = ?", store, k);
  }

  _readDocRaw(store, k) {
    const rows = [
      ...this.sql.exec("SELECT v FROM doc_chunks WHERE store = ? AND k = ? ORDER BY seq", store, k)
    ];
    if (!rows.length) return null;
    return rows.map((r) => r.v).join("");
  }

  _readDoc(store, k) {
    const raw = this._readDocRaw(store, k);
    if (raw == null) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  _writeDoc(store, k, obj, now = Date.now()) {
    this._writeDocRaw(store, k, JSON.stringify(obj), now);
  }

  // Raw JSON per key; later stores in the list override earlier ones (control wins over state).
  _collectRawDocs(stores) {
    const out = new Map();
    for (const store of stores) {
      const rows = [
        ...this.sql.exec("SELECT k, v FROM doc_chunks WHERE store = ? ORDER BY k, seq", store)
      ];
      let curKey = null;
      let parts = [];
      const flush = () => {
        if (curKey !== null) out.set(curKey, parts.join(""));
      };
      for (const r of rows) {
        if (r.k !== curKey) {
          flush();
          curKey = r.k;
          parts = [];
        }
        parts.push(r.v);
      }
      flush();
    }
    return out;
  }

  _docsResponse(stores, cors, omitKeys = null) {
    const raw = this._collectRawDocs(stores);
    const parts = [];
    for (const [k, v] of raw) {
      if (omitKeys && omitKeys.has(k)) continue;
      parts.push(JSON.stringify(k) + ":" + v);
    }
    const body =
      '{"ok":true,"serverTime":' +
      JSON.stringify(new Date().toISOString()) +
      ',"docs":{' +
      parts.join(",") +
      "}}";
    return storeJson(200, body, cors);
  }

  // ---------- auth ----------

  _verifyKey(ns, candidate) {
    return verifyStoreKey(this.env, ns, candidate);
  }

  async _findDelegatedTask(taskId, token) {
    const cleanId = String(taskId || "");
    const cleanTok = String(token || "");
    if (!cleanId || cleanTok.length < 8) return null;
    const map = this._readDoc("control", "delegated_tasks");
    if (!map || typeof map !== "object" || !Object.prototype.hasOwnProperty.call(map, cleanId)) {
      return null;
    }
    const task = map[cleanId];
    if (!task || typeof task !== "object" || !task.token) return null;
    if (!(await storeConstantTimeEqual(cleanTok, String(task.token)))) return null;
    return { map, task, taskId: cleanId };
  }

  // ---------- web push ----------

  async _sendPush(endpoint, vapid, bodyB64, ttl) {
    if (!isAllowedPushEndpoint(endpoint)) return 0;
    const auth = String(vapid || "");
    if (!isValidVapidHeader(auth)) return 0;
    const bytes = decodeBase64Bytes(bodyB64);
    if (!bytes || bytes.length === 0 || bytes.length > 8192) return 0;
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        redirect: "manual", // a push service never redirects; following one would leave the allowlist
        headers: {
          Authorization: auth,
          "Content-Encoding": "aes128gcm",
          "Content-Type": "application/octet-stream",
          TTL: String(clampInt(ttl, 0, 2419200, DEFAULT_PUSH_TTL)),
          Urgency: "high"
        },
        body: bytes,
        signal: AbortSignal.timeout(10000)
      });
      try {
        await res.arrayBuffer();
      } catch {}
      return Number(res.status || 0);
    } catch {
      return 0;
    }
  }

  // ---------- alarm: delayed pushes, hourly slots, housekeeping ----------

  async _armAlarm() {
    const now = Date.now();
    const rows = [...this.sql.exec("SELECT MIN(fire_at) AS m FROM timers")];
    const minFire = Number(rows[0]?.m || 0);
    let next = Math.floor(now / 3600000) * 3600000 + 3600000 + 5000;
    if (minFire > 0) next = Math.min(next, Math.max(minFire, now + 250));
    await this.ctx.storage.setAlarm(next);
  }

  async _ensureAlarm() {
    try {
      const existing = await this.ctx.storage.getAlarm();
      if (!existing) await this._armAlarm();
    } catch {}
  }

  async _fireTimer(row) {
    const timerKey = String(row.timer_key);
    const timerId = String(row.timer_id);
    const cur = this._readDoc("control", timerKey);
    this.sql.exec("DELETE FROM timers WHERE timer_key = ? AND timer_id = ?", timerKey, timerId);
    if (!cur || typeof cur !== "object" || String(cur.id || "") !== timerId) {
      return "skipped"; // cancelled or re-armed with a newer id
    }
    const expPart = Number(cur.expSec) > 0 ? { expSec: Number(cur.expSec) } : {};
    // Pre-claim before the network call: a retried alarm can never send the same timer twice.
    this._writeDoc("control", timerKey, { id: `sending_${timerId}`, ...expPart });
    const status = await this._sendPush(row.endpoint, row.vapid, row.body_b64, row.ttl);
    const after = this._readDoc("control", timerKey);
    if (!after || String(after.id || "") !== `sending_${timerId}`) {
      return "superseded";
    }
    const delivered = (status >= 200 && status < 300) || status === 404 || status === 410;
    const stamp = new Date().toISOString();
    if (delivered) {
      this._writeDoc("control", timerKey, {
        id: `fired_${timerId}`,
        ...expPart,
        firedAt: stamp,
        pushStatus: status
      });
      return "fired";
    }
    this._writeDoc("control", timerKey, {
      id: `failed_${status}_${timerId}`,
      ...expPart,
      failedAt: stamp,
      pushStatus: status
    });
    return "failed";
  }

  async _dispatchHourlySlots(hourKey) {
    const registry = this._readDoc("control", "push_registry");
    const items = Array.isArray(registry?.items) ? registry.items : [];
    let sent = 0;
    for (const item of items) {
      const slot = item && item.slots && typeof item.slots === "object" ? item.slots[hourKey] : null;
      if (!slot || !item.endpoint || !slot.vapid || !slot.bodyB64) continue;
      await this._sendPush(item.endpoint, slot.vapid, slot.bodyB64, DEFAULT_PUSH_TTL);
      sent++;
    }
    return sent;
  }

  _purgeTerminalTimerDocs(now) {
    const cutoff = now - TERMINAL_TIMER_RETENTION_MS;
    for (const glob of TIMER_DOC_GLOBS) {
      const rows = [
        ...this.sql.exec(
          "SELECT k FROM docs WHERE store = 'control' AND k GLOB ? AND updated_at < ? LIMIT 500",
          glob,
          cutoff
        )
      ];
      for (const r of rows) {
        const doc = this._readDoc("control", r.k);
        const id = String(doc?.id || "");
        // sending_ older than the retention window is a send that was interrupted and can never complete.
        if (/^(fired_|failed_|cancelled|sending_)/.test(id)) this._deleteDoc("control", r.k);
      }
    }
  }

  async alarm() {
    const now = Date.now();
    try {
      const due = [
        ...this.sql.exec("SELECT * FROM timers WHERE fire_at <= ? ORDER BY fire_at LIMIT 60", now)
      ];
      for (const row of due) {
        try {
          await this._fireTimer(row);
        } catch {}
      }
      // Read the clock again: slow pushes above can carry this run across an hour boundary, and the hour that
      // has just begun must be dispatched now because the next alarm is armed for the hour after it.
      const hourKey = new Date(Date.now()).toISOString().slice(0, 13);
      if (this._getMeta("last_slot_hour") !== hourKey) {
        // Stamp first: an hour is dispatched at most once even if the alarm is retried.
        this._setMeta("last_slot_hour", hourKey);
        try {
          await this._dispatchHourlySlots(hourKey);
        } catch {}
      }
      const dayKey = hourKey.slice(0, 10);
      if (this._getMeta("last_purge_day") !== dayKey) {
        this._setMeta("last_purge_day", dayKey);
        try {
          this._purgeTerminalTimerDocs(now);
        } catch {}
      }
    } finally {
      await this._armAlarm();
    }
  }

  // ---------- request handling ----------

  async fetch(request) {
    const cors = storeCorsHeaders(request);
    const ns = storeNamespaceFromPath(new URL(request.url).pathname);
    if (!ns) return storeJson(404, { ok: false, error: "not found" }, cors);
    if (request.method !== "POST") return storeJson(405, { ok: false, error: "POST required" }, cors);

    // The Worker has already capped and authenticated this request; the object repeats both checks so that it
    // stays safe if it is ever reached another way.
    let raw = null;
    try {
      raw = await readBodyCapped(request, ns.maxBodyBytes);
    } catch {
      return storeJson(400, { ok: false, error: "unreadable body" }, cors);
    }
    if (raw === null) {
      return storeJson(413, { ok: false, error: "Payload too large" }, cors);
    }
    let body = null;
    try {
      body = JSON.parse(raw);
    } catch {
      return storeJson(400, { ok: false, error: "invalid json" }, cors);
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return storeJson(400, { ok: false, error: "invalid json" }, cors);
    }
    const op = String(body.op || "");

    // Staff task links carry their own per-task token and never the store key.
    if (ns.delegates && (op === "delegate_get" || op === "delegate_update")) {
      if (raw.length > KEYLESS_MAX_BODY_BYTES) {
        return storeJson(413, { ok: false, error: "Payload too large" }, cors);
      }
      return this._handleDelegate(op, body, cors);
    }

    const keyOk = await this._verifyKey(ns, body.key || bearerFromRequest(request));
    if (!keyOk) {
      if (isKeylessOp(ns, body) && raw.length <= KEYLESS_MAX_BODY_BYTES) {
        return this._handleDelegatePush(body, cors);
      }
      return storeJson(401, { ok: false, error: "bad key" }, cors);
    }

    await this._ensureAlarm();

    if (op === "get_control") return this._docsResponse(["control"], cors);
    if (op === "get") return this._docsResponse(["control"], cors);
    if (op === "get_theo") return this._docsResponse(ns.split ? ["state", "control"] : ["control"], cors);
    if (op === "patch") return this._handlePatch(ns, body, cors);
    if (op === "push") return this._handlePush(body, cors);
    if (op === "push_delay") return this._handlePushDelay(ns, body, cors);
    if (op === "get_mfg") return storeJson(410, { ok: false, error: "gone" }, cors);
    return storeJson(400, { ok: false, error: "unknown op" }, cors);
  }

  _handlePatch(ns, body, cors) {
    const patch = body.patch;
    if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
      return storeJson(400, { ok: false, error: "patch must be an object" }, cors);
    }
    const keys = Object.keys(patch);
    if (keys.length > 500) {
      return storeJson(413, { ok: false, error: "too many keys in one patch" }, cors);
    }
    const store = ns.split && (patch.state != null || patch.threads != null) ? "state" : "control";
    const writes = [];
    let addedChars = 0;
    let addedDocs = 0;
    for (const k of keys) {
      if (!isValidDocKey(k)) {
        return storeJson(400, { ok: false, error: "invalid doc key" }, cors);
      }
      const val = patch[k];
      if (val === null || val === undefined) {
        writes.push({ k, del: true });
        continue;
      }
      const jsonStr = JSON.stringify(val);
      if (jsonStr.length > ns.maxDocChars) {
        return storeJson(413, { ok: false, error: `doc too large: ${k.slice(0, 80)}` }, cors);
      }
      const prev = [...this.sql.exec("SELECT chars FROM docs WHERE store = ? AND k = ?", store, k)];
      addedChars += jsonStr.length - Number(prev[0]?.chars || 0);
      if (!prev.length) addedDocs++;
      writes.push({ k, jsonStr, id: val && typeof val === "object" ? String(val.id ?? "") : "" });
    }
    const totals = [...this.sql.exec("SELECT COALESCE(SUM(chars), 0) AS c, COUNT(*) AS n FROM docs")];
    if (addedChars > 0 && Number(totals[0]?.c || 0) + addedChars > ns.maxTotalChars) {
      return storeJson(507, { ok: false, error: "store is full" }, cors);
    }
    if (addedDocs > 0 && Number(totals[0]?.n || 0) + addedDocs > ns.maxDocs) {
      return storeJson(507, { ok: false, error: "too many docs" }, cors);
    }
    const now = Date.now();
    this._atomic(() => {
      for (const w of writes) {
        if (w.del) {
          this._deleteDoc(store, w.k);
          if (store === "control") this.sql.exec("DELETE FROM timers WHERE timer_key = ?", w.k);
          continue;
        }
        this._writeDocRaw(store, w.k, w.jsonStr, now);
        if (store === "control") {
          // A patch that replaces a timer doc (cancel, or a stamp written by a host) retires the pending timer.
          this.sql.exec("DELETE FROM timers WHERE timer_key = ? AND timer_id != ?", w.k, w.id);
        }
      }
    });
    if (body.ackOnly) {
      return storeJson(200, { ok: true, serverTime: new Date().toISOString() }, cors);
    }
    return this._docsResponse([store], cors);
  }

  async _handlePush(body, cors) {
    const endpoint = String(body.endpoint || "");
    if (!isAllowedPushEndpoint(endpoint)) {
      return storeJson(400, { ok: false, error: "push endpoint not allowed" }, cors);
    }
    const vapid = String(body.vapid || body.auth || "");
    const bodyB64 = String(body.bodyB64 || "");
    if (!vapid || !bodyB64) {
      return storeJson(400, { ok: false, error: "vapid and bodyB64 are required" }, cors);
    }
    if (!isValidVapidHeader(vapid)) {
      return storeJson(400, { ok: false, error: "vapid must be a VAPID Authorization value" }, cors);
    }
    const pushStatus = await this._sendPush(endpoint, vapid, bodyB64, body.ttl);
    return storeJson(200, { ok: pushStatus >= 200 && pushStatus < 300, pushStatus }, cors);
  }

  async _handlePushDelay(ns, body, cors) {
    const timerKey = String(body.timerKey || "");
    const timerId = String(body.timerId || "");
    if (!isTimerDocKey(timerKey) || !timerId || timerId.length > 300 || LONE_SURROGATE_RE.test(timerId)) {
      return storeJson(400, { ok: false, error: "timerKey and timerId are required" }, cors);
    }
    const endpoint = String(body.endpoint || "");
    if (!isAllowedPushEndpoint(endpoint)) {
      return storeJson(400, { ok: false, error: "push endpoint not allowed" }, cors);
    }
    const vapid = String(body.vapid || body.auth || "");
    const bodyB64 = String(body.bodyB64 || "");
    if (!isValidVapidHeader(vapid) || !bodyB64 || bodyB64.length > 12288) {
      return storeJson(400, { ok: false, error: "vapid and bodyB64 are required" }, cors);
    }
    const rawDelay = Number(body.delaySec);
    if (!Number.isFinite(rawDelay) || rawDelay < 0) {
      return storeJson(400, { ok: false, error: "delaySec must be a non-negative number" }, cors);
    }
    const existing = [...this.sql.exec("SELECT timer_key FROM timers WHERE timer_key = ?", timerKey)];
    if (!existing.length) {
      const cnt = [...this.sql.exec("SELECT COUNT(*) AS n FROM timers")];
      if (Number(cnt[0]?.n || 0) >= ns.maxTimers) {
        return storeJson(429, { ok: false, error: "too many pending timers" }, cors);
      }
    }
    const now = Date.now();
    const delaySec = clampInt(rawDelay, 0, MAX_DELAY_SEC, 0);
    const fireAt = now + delaySec * 1000;
    const expSec = clampInt(body.expSec, 0, 4102444800, 0);
    const ttl = clampInt(body.ttl, 0, 2419200, DEFAULT_PUSH_TTL);
    // The timer's control doc counts against the same store caps as a patch would.
    const timerDoc = expSec > 0 ? { id: timerId, expSec } : { id: timerId };
    const timerDocStr = JSON.stringify(timerDoc);
    const prevDoc = [...this.sql.exec("SELECT chars FROM docs WHERE store = 'control' AND k = ?", timerKey)];
    const totals = [...this.sql.exec("SELECT COALESCE(SUM(chars), 0) AS c, COUNT(*) AS n FROM docs")];
    const addedChars = timerDocStr.length - Number(prevDoc[0]?.chars || 0);
    if (addedChars > 0 && Number(totals[0]?.c || 0) + addedChars > ns.maxTotalChars) {
      return storeJson(507, { ok: false, error: "store is full" }, cors);
    }
    if (!prevDoc.length && Number(totals[0]?.n || 0) + 1 > ns.maxDocs) {
      return storeJson(507, { ok: false, error: "too many docs" }, cors);
    }
    this._atomic(() => {
      this.sql.exec(
        `INSERT INTO timers (timer_key, timer_id, fire_at, exp_sec, endpoint, vapid, body_b64, ttl, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(timer_key) DO UPDATE SET
           timer_id = excluded.timer_id,
           fire_at = excluded.fire_at,
           exp_sec = excluded.exp_sec,
           endpoint = excluded.endpoint,
           vapid = excluded.vapid,
           body_b64 = excluded.body_b64,
           ttl = excluded.ttl,
           created_at = excluded.created_at`,
        timerKey,
        timerId,
        fireAt,
        expSec,
        endpoint,
        vapid,
        bodyB64,
        ttl,
        now
      );
      this._writeDocRaw("control", timerKey, timerDocStr, now);
    });
    await this._armAlarm();
    return storeJson(200, { ok: true, timerKey, timerId, fireAt }, cors);
  }

  async _handleDelegate(op, body, cors) {
    const found = await this._findDelegatedTask(body.taskId, body.token);
    if (!found) {
      return storeJson(403, { ok: false, error: "Invalid or expired task link" }, cors);
    }
    const { map, task, taskId } = found;
    // The staff page only needs to know whether a completion notice exists, never its pre-signed contents.
    const staffView = (t) => ({ ...t, pushOnDone: t.pushOnDone ? true : null });
    if (op === "delegate_get") {
      return storeJson(200, { ok: true, task: staffView(task) }, cors);
    }
    const status = String(body.status || "").trim();
    if (!DELEGATE_STATUSES.has(status)) {
      return storeJson(400, { ok: false, error: "invalid status" }, cors);
    }
    const becameDone = status === "done" && task.delegationStatus !== "done";
    task.delegationStatus = status;
    if (typeof body.staffNote === "string") {
      task.staffNote = body.staffNote.slice(0, 2000);
    }
    task.staffUpdatedAt = new Date().toISOString();
    map[taskId] = task;
    this._writeDoc("control", "delegated_tasks", map);
    if (becameDone && task.pushOnDone) {
      const list = Array.isArray(task.pushOnDone) ? task.pushOnDone : [task.pushOnDone];
      for (const p of list.slice(0, 8)) {
        if (!p || !p.endpoint || !p.vapid || !p.bodyB64) continue;
        try {
          await this._sendPush(p.endpoint, p.vapid, p.bodyB64, DEFAULT_PUSH_TTL);
        } catch {}
      }
    }
    return storeJson(200, { ok: true, task: staffView(task) }, cors);
  }

  // A staff page may notify the task owner, and only the owner devices listed on that task.
  async _handleDelegatePush(body, cors) {
    const found = await this._findDelegatedTask(body.taskId, body.token);
    if (!found) {
      return storeJson(401, { ok: false, error: "bad key" }, cors);
    }
    const endpoint = String(body.endpoint || "");
    const targets = Array.isArray(found.task.ownerPushTargets) ? found.task.ownerPushTargets : [];
    if (!endpoint || !targets.some((t) => t && t.endpoint === endpoint)) {
      return storeJson(403, { ok: false, error: "push target not allowed for this task" }, cors);
    }
    return this._handlePush(body, cors);
  }
}
