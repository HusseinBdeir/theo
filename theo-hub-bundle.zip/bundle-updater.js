'use strict';

const fs = require('fs');
const http = require('http');
const https = require('https');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const vm = require('vm');
const { execFileSync } = require('child_process');
const { loadTheoCredentials, deriveBundleSignKey } = require('./device-identity');

const BUNDLE_MANIFEST_NAME = '.theo-bundle-manifest.json';
const BUNDLE_CANONICAL_PREFIX = 'theo-hub-bundle-v1';
const DEFAULT_BUNDLE_URL = 'https://husseinbdeir.github.io/theo/theo-hub-bundle.zip';
const MAX_BUNDLE_BYTES = 8 * 1024 * 1024;
const MAX_SINGLE_FILE_BYTES = 4 * 1024 * 1024;
const MAX_TOTAL_UNCOMPRESSED_BYTES = 20 * 1024 * 1024;
const MAX_ZIP_ENTRIES = 128;
const MAX_FUTURE_SKEW_MS = 10 * 60 * 1000;
const MIN_VALID_BUILT_AT_MS = 1700000000000;

const ALLOWED_EXTENSIONS = new Set([
  '.js',
  '.cjs',
  '.mjs',
  '.json',
  '.py',
  '.ps1',
  '.cs',
  '.ico',
  '.png',
  '.svg',
  '.md',
  '.css',
  '.html',
  '.txt',
  '.toml'
]);

const FORBIDDEN_BASENAMES = new Set([
  'remote-relay.json',
  'credentials.json',
  '.dev.vars',
  '.secretscan-allow'
]);

const REQUIRED_CORE_FILES = [
  'package.json',
  'extension.js',
  'remote.js',
  'store.js',
  'device-identity.js',
  'scripts/relay_keepalive.cjs'
];

// Precomputed IEEE 802.3 CRC-32 table for ZIP integrity verification.
const CRC32_TABLE = (() => {
  const tbl = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    tbl[i] = c >>> 0;
  }
  return tbl;
})();

function crc32Buffer(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC32_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function sha256Hex(bufOrStr) {
  return crypto.createHash('sha256').update(bufOrStr).digest('hex');
}

function bundleStampPath(customPath = '') {
  return (
    customPath ||
    process.env.THEO_BUNDLE_STAMP_PATH ||
    path.join(os.homedir(), '.claude', '.theo-hub-bundle-stamp.json')
  );
}

function bundleLockPath(customPath = '') {
  return (
    customPath ||
    process.env.THEO_BUNDLE_LOCK_PATH ||
    path.join(os.homedir(), '.claude', '.theo-hub-bundle-update.lock')
  );
}

function readInstalledBundleStamp(customPath = '') {
  const p = bundleStampPath(customPath);
  try {
    if (!fs.existsSync(p)) return null;
    const parsed = JSON.parse(fs.readFileSync(p, 'utf8'));
    if (!parsed || typeof parsed !== 'object') return null;
    return {
      version: String(parsed.version || ''),
      builtAt: Number(parsed.builtAt || 0),
      sha256: String(parsed.sha256 || '').toLowerCase(),
      appliedAt: Number(parsed.appliedAt || 0)
    };
  } catch {
    return null;
  }
}

const SLEEP_ARRAY = new Int32Array(new SharedArrayBuffer(4));

function sleepSyncMs(ms) {
  try {
    Atomics.wait(SLEEP_ARRAY, 0, 0, Math.max(1, Math.floor(ms)));
  } catch {}
}

function atomicReplaceFileSync(tmpPath, destPath) {
  let lastErr = null;
  for (let attempt = 0; attempt < 6; attempt++) {
    try {
      fs.renameSync(tmpPath, destPath);
      return;
    } catch (err) {
      lastErr = err;
      const code = err && err.code;
      if (code !== 'EPERM' && code !== 'EACCES' && code !== 'EBUSY') {
        throw err;
      }
      sleepSyncMs(15 * (attempt + 1));
    }
  }
  if (process.platform === 'win32') {
    fs.copyFileSync(tmpPath, destPath);
    try {
      fs.unlinkSync(tmpPath);
    } catch {}
    return;
  }
  throw lastErr;
}

function writeInstalledBundleStamp(stamp, customPath = '') {
  const p = bundleStampPath(customPath);
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const tmp = `${p}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(stamp, null, 2), 'utf8');
    atomicReplaceFileSync(tmp, p);
    return true;
  } catch {
    return false;
  }
}

function isAllowedBundleUrl(rawUrl, opts = {}) {
  const clean = String(rawUrl || '').trim();
  if (!clean || clean.length > 512) return false;
  let u;
  try {
    u = new URL(clean);
  } catch {
    return false;
  }
  if (u.username || u.password || u.hash) return false;
  if (opts.allowLoopbackTest && u.protocol === 'http:' && u.hostname === '127.0.0.1') {
    return u.pathname.endsWith('.zip');
  }
  if (u.protocol !== 'https:' || (u.port && u.port !== '443')) return false;
  const host = u.hostname.toLowerCase();
  if (host === 'husseinbdeir.github.io') {
    return u.pathname === '/theo/theo-hub-bundle.zip';
  }
  if (host === 'raw.githubusercontent.com') {
    return /^\/HusseinBdeir\/theo\/[A-Za-z0-9._-]+\/theo-hub-bundle\.zip$/i.test(u.pathname);
  }
  return false;
}

function canonicalHubReleaseMessage(rec) {
  return [
    BUNDLE_CANONICAL_PREFIX,
    String(rec?.version || '').trim(),
    String(Math.floor(Number(rec?.builtAt || 0))),
    String(rec?.sha256 || '').trim().toLowerCase(),
    String(rec?.url || '').trim()
  ].join('|');
}

function signHubReleaseRecord(rec, edgeAccessKey) {
  const signKey = deriveBundleSignKey(edgeAccessKey);
  if (!signKey) return '';
  return crypto
    .createHmac('sha256', signKey)
    .update(canonicalHubReleaseMessage(rec), 'utf8')
    .digest('hex');
}

function verifyHubReleaseRecord(rec, edgeAccessKey, opts = {}) {
  if (!rec || typeof rec !== 'object') {
    return { ok: false, reason: 'invalid_record' };
  }
  const signKey = deriveBundleSignKey(edgeAccessKey);
  if (!signKey) {
    return { ok: false, reason: 'missing_edge_access_key' };
  }
  const version = String(rec.version || '').trim();
  if (!/^\d+\.\d+\.\d+(?:-[A-Za-z0-9._-]+)?$/.test(version) || version.length > 40) {
    return { ok: false, reason: 'invalid_version' };
  }
  const nowMs = Number.isFinite(Number(opts.nowMs)) ? Number(opts.nowMs) : Date.now();
  const builtAt = Number(rec.builtAt);
  if (!Number.isFinite(builtAt) || builtAt < MIN_VALID_BUILT_AT_MS || builtAt > nowMs + MAX_FUTURE_SKEW_MS) {
    return { ok: false, reason: 'invalid_built_at' };
  }
  const sha256 = String(rec.sha256 || '').trim().toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(sha256)) {
    return { ok: false, reason: 'invalid_sha256' };
  }
  const url = String(rec.url || DEFAULT_BUNDLE_URL).trim();
  if (!isAllowedBundleUrl(url, opts)) {
    return { ok: false, reason: 'disallowed_url' };
  }
  const candidateHmac = String(rec.sig || rec.hmac || '').trim().toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(candidateHmac)) {
    return { ok: false, reason: 'invalid_hmac_shape' };
  }
  const expectedHex = crypto
    .createHmac('sha256', signKey)
    .update(
      canonicalHubReleaseMessage({
        version,
        builtAt: Math.floor(builtAt),
        sha256,
        url
      }),
      'utf8'
    )
    .digest('hex');
  const ok = crypto.timingSafeEqual(Buffer.from(expectedHex, 'hex'), Buffer.from(candidateHmac, 'hex'));
  if (!ok) {
    return { ok: false, reason: 'bad_signature' };
  }
  return {
    ok: true,
    release: {
      version,
      builtAt: Math.floor(builtAt),
      sha256,
      url,
      sig: candidateHmac,
      hmac: candidateHmac
    }
  };
}

function validateSafeZipEntryPath(rawName, externalAttr = 0) {
  if (typeof rawName !== 'string' || !rawName || rawName.length > 240) {
    return { ok: false, reason: 'invalid_entry_name' };
  }
  if (/[\u0000-\u001f\\:]/.test(rawName)) {
    return { ok: false, reason: 'unsafe_entry_chars' };
  }
  if (rawName.startsWith('/') || rawName.endsWith('/')) {
    return { ok: false, reason: 'unexpected_directory_or_abs_entry' };
  }
  // Reject UNIX symlink entries in external file attributes.
  const unixMode = (externalAttr >>> 16) & 0o170000;
  if (unixMode === 0o120000) {
    return { ok: false, reason: 'symlink_entry_forbidden' };
  }
  const parts = rawName.split('/');
  if (parts.some((seg) => !seg || seg === '.' || seg === '..')) {
    return { ok: false, reason: 'traversal_segment' };
  }
  const topLower = parts[0].toLowerCase();
  if (topLower === '.git' || topLower === '.wrangler' || topLower === 'node_modules') {
    return { ok: false, reason: 'forbidden_top_dir' };
  }
  const baseLower = parts[parts.length - 1].toLowerCase();
  if (FORBIDDEN_BASENAMES.has(baseLower) || baseLower.startsWith('.env')) {
    return { ok: false, reason: 'forbidden_secret_filename' };
  }
  if (rawName === BUNDLE_MANIFEST_NAME) {
    return { ok: true, relPath: rawName };
  }
  const ext = path.posix.extname(baseLower);
  if (!ALLOWED_EXTENSIONS.has(ext)) {
    return { ok: false, reason: `disallowed_extension:${ext || 'none'}` };
  }
  return { ok: true, relPath: rawName };
}

function extractAndVerifyBundleZip(zipBuf, expectedBuiltAt, opts = {}) {
  if (expectedBuiltAt && typeof expectedBuiltAt === 'object') {
    opts = expectedBuiltAt;
    expectedBuiltAt = opts.expectedBuiltAt;
  }
  if (!Buffer.isBuffer(zipBuf) || zipBuf.length < 22 || zipBuf.length > MAX_BUNDLE_BYTES) {
    throw new Error('Bundle ZIP size out of bounds');
  }

  // Locate End of Central Directory (EOCD) signature 0x06054b50 from tail.
  const minEocdOffset = Math.max(0, zipBuf.length - 65557);
  let eocdOffset = -1;
  for (let i = zipBuf.length - 22; i >= minEocdOffset; i--) {
    if (zipBuf.readUInt32LE(i) === 0x06054b50) {
      const commentLen = zipBuf.readUInt16LE(i + 20);
      if (i + 22 + commentLen === zipBuf.length) {
        eocdOffset = i;
        break;
      }
    }
  }
  if (eocdOffset < 0) {
    throw new Error('Missing or malformed ZIP End-of-Central-Directory');
  }

  const diskNo = zipBuf.readUInt16LE(eocdOffset + 4);
  const cdDiskNo = zipBuf.readUInt16LE(eocdOffset + 6);
  const totalEntries = zipBuf.readUInt16LE(eocdOffset + 10);
  const cdSize = zipBuf.readUInt32LE(eocdOffset + 12);
  const cdOffset = zipBuf.readUInt32LE(eocdOffset + 16);

  if (diskNo !== 0 || cdDiskNo !== 0) {
    throw new Error('Multi-disk ZIP archives are forbidden');
  }
  if (totalEntries === 0 || totalEntries > MAX_ZIP_ENTRIES) {
    throw new Error(`Invalid ZIP entry count (${totalEntries})`);
  }
  if (cdOffset + cdSize > eocdOffset) {
    throw new Error('Corrupt ZIP Central Directory bounds');
  }

  const files = new Map();
  let totalUncompressed = 0;
  let ptr = cdOffset;

  for (let idx = 0; idx < totalEntries; idx++) {
    if (ptr + 46 > eocdOffset || zipBuf.readUInt32LE(ptr) !== 0x02014b50) {
      throw new Error('Corrupt Central Directory file header');
    }
    const gpFlag = zipBuf.readUInt16LE(ptr + 8);
    const method = zipBuf.readUInt16LE(ptr + 10);
    const expectedCrc = zipBuf.readUInt32LE(ptr + 16);
    const compSize = zipBuf.readUInt32LE(ptr + 20);
    const uncompSize = zipBuf.readUInt32LE(ptr + 24);
    const nameLen = zipBuf.readUInt16LE(ptr + 28);
    const extraLen = zipBuf.readUInt16LE(ptr + 30);
    const commentLen = zipBuf.readUInt16LE(ptr + 32);
    const externalAttr = zipBuf.readUInt32LE(ptr + 38);
    const localHeaderOffset = zipBuf.readUInt32LE(ptr + 42);

    const headerEnd = ptr + 46 + nameLen + extraLen + commentLen;
    if (headerEnd > eocdOffset) {
      throw new Error('Central Directory entry overflows bounds');
    }
    if (gpFlag & 0x0001) {
      throw new Error('Encrypted ZIP entries are forbidden');
    }
    const rawName = zipBuf.subarray(ptr + 46, ptr + 46 + nameLen).toString('utf8');
    ptr = headerEnd;

    if (rawName.endsWith('/')) {
      continue;
    }

    const pathCheck = validateSafeZipEntryPath(rawName, externalAttr);
    if (!pathCheck.ok) {
      throw new Error(`Unsafe ZIP entry "${rawName}": ${pathCheck.reason}`);
    }
    if (files.has(pathCheck.relPath)) {
      throw new Error(`Duplicate ZIP entry "${pathCheck.relPath}"`);
    }
    if (
      compSize === 0xffffffff ||
      uncompSize === 0xffffffff ||
      uncompSize > MAX_SINGLE_FILE_BYTES
    ) {
      throw new Error(`ZIP entry "${rawName}" exceeds per-file size limit`);
    }
    totalUncompressed += uncompSize;
    if (totalUncompressed > MAX_TOTAL_UNCOMPRESSED_BYTES) {
      throw new Error('Bundle uncompressed size exceeds total cap');
    }

    if (localHeaderOffset + 30 > cdOffset || zipBuf.readUInt32LE(localHeaderOffset) !== 0x04034b50) {
      throw new Error(`Missing local header for "${rawName}"`);
    }
    const localNameLen = zipBuf.readUInt16LE(localHeaderOffset + 26);
    const localExtraLen = zipBuf.readUInt16LE(localHeaderOffset + 28);
    const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
    const dataEnd = dataStart + compSize;
    if (dataEnd > cdOffset) {
      throw new Error(`Compressed data out of bounds for "${rawName}"`);
    }
    const compSlice = zipBuf.subarray(dataStart, dataEnd);
    let contentBuf;
    if (method === 0) {
      contentBuf = Buffer.from(compSlice);
    } else if (method === 8) {
      contentBuf = zlib.inflateRawSync(compSlice, {
        maxOutputLength: Math.max(1, uncompSize)
      });
    } else {
      throw new Error(`Unsupported ZIP compression method ${method} for "${rawName}"`);
    }
    if (contentBuf.length !== uncompSize) {
      throw new Error(`Uncompressed length mismatch for "${rawName}"`);
    }
    if (crc32Buffer(contentBuf) !== expectedCrc) {
      throw new Error(`CRC-32 mismatch for "${rawName}"`);
    }
    files.set(pathCheck.relPath, contentBuf);
  }

  const manifestBuf = files.get(BUNDLE_MANIFEST_NAME);
  if (!manifestBuf) {
    throw new Error('Bundle is missing .theo-bundle-manifest.json');
  }
  let manifest;
  try {
    manifest = JSON.parse(manifestBuf.toString('utf8'));
  } catch {
    throw new Error('Invalid JSON in .theo-bundle-manifest.json');
  }
  if (
    !manifest ||
    manifest.formatVersion !== 1 ||
    !manifest.files ||
    typeof manifest.files !== 'object' ||
    Array.isArray(manifest.files)
  ) {
    throw new Error('Malformed .theo-bundle-manifest.json schema');
  }
  if (
    expectedBuiltAt !== undefined &&
    expectedBuiltAt !== null &&
    Math.floor(Number(manifest.builtAt || 0)) !== Math.floor(Number(expectedBuiltAt))
  ) {
    throw new Error('Manifest builtAt does not match signed hub_release record');
  }

  files.delete(BUNDLE_MANIFEST_NAME);
  const manifestEntries = Object.entries(manifest.files);
  if (manifestEntries.length !== files.size) {
    throw new Error(`Manifest file count (${manifestEntries.length}) != extracted count (${files.size})`);
  }
  for (const [relPath, expectedFileSha] of manifestEntries) {
    const fileBuf = files.get(relPath);
    if (!fileBuf) {
      throw new Error(`Manifest file "${relPath}" missing from archive`);
    }
    if (sha256Hex(fileBuf) !== String(expectedFileSha || '').toLowerCase()) {
      throw new Error(`Per-file SHA-256 mismatch on "${relPath}"`);
    }
  }

  const requiredFiles = Array.isArray(opts.requiredFiles) ? opts.requiredFiles : REQUIRED_CORE_FILES;
  for (const reqRel of requiredFiles) {
    if (!files.has(reqRel)) {
      throw new Error(`Bundle missing required entrypoint "${reqRel}"`);
    }
  }

  // Syntax-gate every CommonJS script before touching disk so a bad edit can never brick a host.
  for (const [relPath, fileBuf] of files.entries()) {
    if (relPath.startsWith('cloudflare-relay/')) continue;
    if (relPath.endsWith('.js') || relPath.endsWith('.cjs')) {
      // Compile-only syntax check (never executes code).
      // eslint-disable-next-line no-new
      new vm.Script(fileBuf.toString('utf8'), { filename: relPath });
    }
  }

  return { manifest, files };
}

function downloadBundleBuffer(rawUrl, opts = {}) {
  return new Promise((resolve, reject) => {
    if (!isAllowedBundleUrl(rawUrl, opts)) {
      reject(new Error('Disallowed bundle URL'));
      return;
    }
    const u = new URL(rawUrl);
    const mod = u.protocol === 'http:' ? http : https;
    const timeoutMs = Number(opts.timeoutMs || 20000);
    let settled = false;
    const done = (err, buf) => {
      if (settled) return;
      settled = true;
      if (err) reject(err);
      else resolve(buf);
    };

    const req = mod.request(
      {
        protocol: u.protocol,
        hostname: u.hostname,
        port: u.port || (u.protocol === 'http:' ? 80 : 443),
        path: `${u.pathname}${u.search}`,
        method: 'GET',
        headers: {
          'Cache-Control': 'no-cache',
          'User-Agent': 'THEO-BundleUpdater/1.0'
        },
        timeout: timeoutMs
      },
      (res) => {
        if (res.statusCode !== 200) {
          res.resume();
          done(new Error(`Bundle HTTP status ${res.statusCode}`));
          return;
        }
        const declared = Number(res.headers['content-length'] || 0);
        if (declared > MAX_BUNDLE_BYTES) {
          res.destroy();
          done(new Error('Bundle Content-Length exceeds cap'));
          return;
        }
        const chunks = [];
        let total = 0;
        res.on('data', (chunk) => {
          total += chunk.length;
          if (total > MAX_BUNDLE_BYTES) {
            res.destroy();
            done(new Error('Bundle stream exceeded 8 MB cap'));
            return;
          }
          chunks.push(chunk);
        });
        res.on('end', () => done(null, Buffer.concat(chunks)));
        res.on('error', (err) => done(err));
      }
    );
    req.on('timeout', () => {
      req.destroy();
      done(new Error('Bundle download timed out'));
    });
    req.on('error', (err) => done(err));
    req.end();
  });
}

function isGitRepoDirtyOrAhead(repoDir) {
  const gitDir = path.join(repoDir, '.git');
  if (!fs.existsSync(gitDir)) {
    return { hasGit: false, blocked: false, reason: '' };
  }
  try {
    const statusOut = execFileSync(
      'git',
      ['-C', repoDir, 'status', '--porcelain'],
      { encoding: 'utf8', timeout: 4000, windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] }
    );
    if (String(statusOut || '').trim().length > 0) {
      return { hasGit: true, blocked: true, reason: 'dirty_worktree' };
    }
    try {
      const aheadOut = execFileSync(
        'git',
        ['-C', repoDir, 'rev-list', '--count', '@{u}..HEAD'],
        { encoding: 'utf8', timeout: 4000, windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] }
      );
      if (Number(String(aheadOut || '0').trim()) > 0) {
        return { hasGit: true, blocked: true, reason: 'unpushed_commits' };
      }
    } catch {
      const localUnpushed = execFileSync(
        'git',
        ['-C', repoDir, 'log', '--branches', '--not', '--remotes', '--oneline'],
        { encoding: 'utf8', timeout: 4000, windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] }
      );
      if (String(localUnpushed || '').trim().length > 0) {
        return { hasGit: true, blocked: true, reason: 'unpushed_commits' };
      }
    }
    return { hasGit: true, blocked: false, reason: '' };
  } catch {
    // Fail closed if git inspection itself fails: never overwrite unknown git state.
    return { hasGit: true, blocked: true, reason: 'git_check_failed' };
  }
}

function tryFastForwardCleanGitRepo(repoDir) {
  try {
    execFileSync('git', ['-C', repoDir, 'fetch', 'origin', '--quiet'], {
      timeout: 10000,
      windowsHide: true,
      stdio: 'ignore'
    });
    execFileSync('git', ['-C', repoDir, 'merge', '--ff-only', '@{u}'], {
      timeout: 6000,
      windowsHide: true,
      stdio: 'ignore'
    });
    return true;
  } catch {
    return false;
  }
}

function writeVerifiedFilesAtomically(targetRoot, filesMap) {
  fs.mkdirSync(targetRoot, { recursive: true });
  const realRoot = (fs.realpathSync.native || fs.realpathSync)(targetRoot);
  for (const [relPath, buf] of filesMap.entries()) {
    const destPath = path.resolve(realRoot, ...relPath.split('/'));
    const relCheck = path.relative(realRoot, destPath);
    if (!relCheck || relCheck.startsWith('..') || path.isAbsolute(relCheck)) {
      throw new Error(`Refusing path outside target root: ${relPath}`);
    }
    const parentDir = path.dirname(destPath);
    fs.mkdirSync(parentDir, { recursive: true });
    const tmpPath = `${destPath}.tmp-${process.pid}-${Date.now()}`;
    try {
      fs.writeFileSync(tmpPath, buf);
      atomicReplaceFileSync(tmpPath, destPath);
    } finally {
      if (fs.existsSync(tmpPath)) {
        try {
          fs.unlinkSync(tmpPath);
        } catch {}
      }
    }
  }
}

function acquireUpdateLock(lockFile) {
  try {
    fs.mkdirSync(path.dirname(lockFile), { recursive: true });
    if (fs.existsSync(lockFile)) {
      const ageMs = Date.now() - fs.statSync(lockFile).mtimeMs;
      if (ageMs < 120000) return false;
      try {
        fs.unlinkSync(lockFile);
      } catch {}
    }
    fs.writeFileSync(lockFile, JSON.stringify({ pid: process.pid, at: Date.now() }), {
      encoding: 'utf8',
      flag: 'wx'
    });
    return true;
  } catch {
    return false;
  }
}

function releaseUpdateLock(lockFile) {
  try {
    if (fs.existsSync(lockFile)) fs.unlinkSync(lockFile);
  } catch {}
}

function resolveDefaultExtensionTargets(version, homeDir = os.homedir()) {
  const targets = [path.join(homeDir, '.vscode', 'extensions', `bhfirms.theo-hub-${version}`)];
  const agyExtParent = path.join(homeDir, '.antigravity', 'extensions');
  if (fs.existsSync(agyExtParent)) {
    targets.push(path.join(agyExtParent, `bhfirms.theo-hub-${version}`));
  }
  return targets;
}

function registerExtensionTargetInJson(extDir, version, homeDir = os.homedir()) {
  try {
    const folderName = path.basename(extDir);
    if (!/^bhfirms\.theo-hub-/i.test(folderName)) return false;
    const extParent = path.dirname(extDir);
    if (!fs.existsSync(extParent)) return false;
    const extJsonPath = path.join(extParent, 'extensions.json');
    let entries = [];
    if (fs.existsSync(extJsonPath)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(extJsonPath, 'utf8'));
        if (Array.isArray(parsed)) entries = parsed;
      } catch {}
    }
    const extId = 'bhfirms.theo-hub';
    const legacyId = 'bhfirms.antigravity-hub';
    entries = entries.filter((e) => {
      const id = String(e?.identifier?.id || '').toLowerCase();
      return id !== extId && id !== legacyId;
    });
    let posixPath = '/' + path.resolve(extDir).replace(/\\/g, '/');
    if (/^\/[A-Za-z]:/.test(posixPath)) {
      posixPath = '/' + posixPath[1].toLowerCase() + posixPath.slice(2);
    }
    entries.push({
      identifier: { id: extId },
      version,
      location: { $mid: 1, path: posixPath, scheme: 'file' },
      relativeLocation: folderName,
      metadata: {
        isApplicationScoped: false,
        isMachineScoped: false,
        isBuiltin: false,
        installedTimestamp: Date.now(),
        pinned: true,
        source: 'vsix'
      }
    });
    let claudeSignedOut = false;
    const vaultPath = path.join(homeDir, '.claude', '.theo-accounts-vault.json');
    if (fs.existsSync(vaultPath)) {
      try {
        const vd = JSON.parse(fs.readFileSync(vaultPath, 'utf8'));
        const claudeAccts = (vd?.accounts?.claude || []).filter(
          (a) => a && typeof a === 'object' && String(a.email || '').includes('@')
        );
        if (claudeAccts.length === 0 && vd?.signedOut?.claude) claudeSignedOut = true;
      } catch {}
    }
    for (const entry of entries) {
      if (String(entry?.identifier?.id || '').toLowerCase() === 'anthropic.claude-code') {
        entry.metadata = entry.metadata && typeof entry.metadata === 'object' ? entry.metadata : {};
        entry.metadata.pinned = Boolean(claudeSignedOut);
      }
    }
    const tmpJson = `${extJsonPath}.tmp-${process.pid}-${Date.now()}`;
    fs.writeFileSync(tmpJson, JSON.stringify(entries), 'utf8');
    atomicReplaceFileSync(tmpJson, extJsonPath);
    return true;
  } catch {
    return false;
  }
}

function targetCarriesBundleSha(targetDir, expectedSha) {
  try {
    const raw = fs.readFileSync(path.join(targetDir, '.theo-bundle-applied.json'), 'utf8');
    const parsed = JSON.parse(raw);
    return Boolean(parsed && String(parsed.sha256 || '').toLowerCase() === expectedSha);
  } catch {
    return false;
  }
}

function writeAppliedTargetMarker(targetDir, rel) {
  try {
    const markerPath = path.join(targetDir, '.theo-bundle-applied.json');
    const tmp = `${markerPath}.tmp-${process.pid}-${Date.now()}`;
    fs.writeFileSync(
      tmp,
      JSON.stringify({
        version: rel.version,
        builtAt: rel.builtAt,
        sha256: rel.sha256,
        appliedAt: Date.now()
      }),
      'utf8'
    );
    atomicReplaceFileSync(tmp, markerPath);
  } catch {}
}

const failureBackoffBySha = new Map();
let updateInFlight = false;

async function maybeApplyHubReleaseUpdate(hubRelease, opts = {}) {
  if (!hubRelease || typeof hubRelease !== 'object') {
    return { ok: false, updated: false, reason: 'no_release_doc' };
  }
  if (updateInFlight) {
    return { ok: false, updated: false, reason: 'in_flight' };
  }

  const creds = opts.credentials || loadTheoCredentials();
  const edgeAccessKey = String(opts.edgeAccessKey || creds?.edgeAccessKey || '').trim();
  const verified = verifyHubReleaseRecord(hubRelease, edgeAccessKey, opts);
  if (!verified.ok) {
    return { ok: false, updated: false, reason: verified.reason };
  }
  const rel = verified.release;
  const homeDir = opts.homeDir || os.homedir();
  const extTargets = Array.isArray(opts.extTargets)
    ? opts.extTargets
    : resolveDefaultExtensionTargets(rel.version, homeDir);

  const curStamp = readInstalledBundleStamp(opts.stampPath);
  if (curStamp) {
    if (curStamp.builtAt > rel.builtAt) {
      return { ok: true, updated: false, reason: 'not_newer_than_installed' };
    }
    const allTargetsCurrent =
      extTargets.length === 0 || extTargets.every((t) => targetCarriesBundleSha(t, rel.sha256));
    if (curStamp.sha256 === rel.sha256 && allTargetsCurrent) {
      return { ok: true, updated: false, reason: 'already_installed_sha' };
    }
    if (curStamp.builtAt === rel.builtAt && curStamp.sha256 !== rel.sha256) {
      return { ok: true, updated: false, reason: 'not_newer_than_installed' };
    }
  }

  const nowMs = Number.isFinite(Number(opts.nowMs)) ? Number(opts.nowMs) : Date.now();
  const prevFail = failureBackoffBySha.get(rel.sha256);
  if (prevFail && nowMs < prevFail.retryAfter && !opts.ignoreBackoff) {
    return { ok: false, updated: false, reason: 'backoff_active' };
  }

  const lockFile = bundleLockPath(opts.lockPath);
  if (!acquireUpdateLock(lockFile)) {
    return { ok: false, updated: false, reason: 'locked_by_another_process' };
  }
  updateInFlight = true;
  try {
    const cacheSep = rel.url.includes('?') ? '&' : '?';
    const downloadUrl = opts.allowLoopbackTest ? rel.url : `${rel.url}${cacheSep}b=${rel.builtAt}`;
    const zipBuf = opts.downloadFn
      ? await opts.downloadFn(downloadUrl, rel)
      : await downloadBundleBuffer(downloadUrl, opts);
    const actualSha = sha256Hex(zipBuf);
    if (actualSha !== rel.sha256) {
      const tries = (prevFail?.tries || 0) + 1;
      const delayMs = tries <= 5 ? 60000 : 10 * 60 * 1000;
      failureBackoffBySha.set(rel.sha256, { tries, retryAfter: Date.now() + delayMs });
      return { ok: false, updated: false, reason: 'bundle_sha256_mismatch' };
    }

    const { files } = extractAndVerifyBundleZip(zipBuf, rel.builtAt, opts);

    const updatedPaths = [];
    for (const extDir of extTargets) {
      writeVerifiedFilesAtomically(extDir, files);
      writeAppliedTargetMarker(extDir, rel);
      registerExtensionTargetInJson(extDir, rel.version, homeDir);
      updatedPaths.push(extDir);
    }

    let repoResult = 'absent';
    const repoDir =
      opts.repoDir !== undefined ? opts.repoDir : path.join(homeDir, 'bhfirms', 'theo-hub');
    if (repoDir && fs.existsSync(repoDir)) {
      const gitState = isGitRepoDirtyOrAhead(repoDir);
      if (!gitState.hasGit) {
        writeVerifiedFilesAtomically(repoDir, files);
        writeAppliedTargetMarker(repoDir, rel);
        updatedPaths.push(repoDir);
        repoResult = 'updated_files';
      } else if (gitState.blocked) {
        repoResult = `skipped_${gitState.reason}`;
      } else {
        repoResult = tryFastForwardCleanGitRepo(repoDir) ? 'git_ff_merged' : 'git_clean_preserved';
      }
    }

    // Pre-patch installed Antigravity & Claude Code extensions from the newly updated hub copy so headless updates
    // keep bridge files warm even before VS Code reloads.
    if (
      !opts.skipBridgePrepatch &&
      process.env.THEO_SMOKE_TEST !== '1' &&
      process.env.THEO_HEADLESS_TEST !== '1' &&
      updatedPaths.length > 0
    ) {
      try {
        const primaryTarget = updatedPaths[0];
        // Worker thread (runHeadlessBridgePrepatchAsync), so applying a hub release never blocks the host.
        runHeadlessBridgePrepatchAsync(primaryTarget, extTargets).catch(() => {});
        // Re-verify once after 22s so an already-open pre-upgrade Extension Host's 18s prepatch tick cannot leave webview/index.js stale.
        const settleTimer = setTimeout(() => {
          runHeadlessBridgePrepatchAsync(primaryTarget, extTargets).catch(() => {});
        }, 22000);
        if (typeof settleTimer?.unref === 'function') settleTimer.unref();
      } catch {}
    }

    // Recompile ~/.theo/THEO.exe when running outside headless/smoke tests so C# launcher updates land automatically.
    if (
      !opts.skipLauncherRebuild &&
      process.platform === 'win32' &&
      process.env.THEO_SMOKE_TEST !== '1' &&
      process.env.THEO_HEADLESS_TEST !== '1' &&
      updatedPaths.length > 0
    ) {
      try {
        const launcherModPath = path.join(updatedPaths[0], 'desktop-launcher.js');
        delete require.cache[require.resolve(launcherModPath)];
        const {
          ensureStableDesktopIcon,
          ensureNativeLauncherExecutable
        } = require(launcherModPath);
        const ico = ensureStableDesktopIcon({ hubRoot: updatedPaths[0], homeDir });
        ensureNativeLauncherExecutable({
          hubRoot: updatedPaths[0],
          homeDir,
          iconPath: ico.iconPath,
          force: true
        });
      } catch {}
    }

    const stamp = {
      version: rel.version,
      builtAt: rel.builtAt,
      sha256: rel.sha256,
      appliedAt: Date.now(),
      repoResult
    };
    writeInstalledBundleStamp(stamp, opts.stampPath);
    failureBackoffBySha.delete(rel.sha256);
    return { ok: true, updated: true, release: rel, updatedPaths, repoResult };
  } catch (err) {
    const tries = (prevFail?.tries || 0) + 1;
    failureBackoffBySha.set(rel.sha256, {
      tries,
      retryAfter: Date.now() + 10 * 60 * 1000
    });
    return {
      ok: false,
      updated: false,
      reason: 'apply_failed',
      error: String(err?.message || err)
    };
  } finally {
    updateInFlight = false;
    releaseUpdateLock(lockFile);
  }
}

function runHeadlessBridgePrepatch(hubDir, extTargets = []) {
  const bridgeModPath = path.join(hubDir, 'bridge.js');
  if (!fs.existsSync(bridgeModPath)) {
    return { ok: false, reason: 'missing_bridge_js', reports: [] };
  }
  const webviewPatchesPath = path.join(hubDir, 'compat', 'claude-webview-patches.cjs');
  try {
    if (fs.existsSync(webviewPatchesPath)) {
      delete require.cache[require.resolve(webviewPatchesPath)];
    }
  } catch {}
  try {
    delete require.cache[require.resolve(bridgeModPath)];
  } catch {}
  const bridgeMod = require(bridgeModPath);
  const reports = [];
  const extRoots = new Set((Array.isArray(extTargets) ? extTargets : []).map((t) => path.dirname(t)));
  for (const extParent of extRoots) {
    if (!fs.existsSync(extParent)) continue;
    for (const entry of fs.readdirSync(extParent, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const fullDir = path.join(extParent, entry.name);
      if (
        /^google\.google-antigravity-/i.test(entry.name) &&
        typeof bridgeMod.ensureBridgeInstalledForExtensionDir === 'function'
      ) {
        reports.push(bridgeMod.ensureBridgeInstalledForExtensionDir(fullDir, hubDir));
      } else if (
        /^anthropic\.claude-code-/i.test(entry.name) &&
        typeof bridgeMod.ensureClaudeBridgeInstalledForExtensionDir === 'function'
      ) {
        reports.push(bridgeMod.ensureClaudeBridgeInstalledForExtensionDir(fullDir, hubDir));
      }
    }
  }
  return {
    ok: true,
    bridgePatchDigest:
      typeof bridgeMod.getBridgePatchDigest === 'function' ? bridgeMod.getBridgePatchDigest() : '',
    reports
  };
}

// Same as runHeadlessBridgePrepatch, but the bundles are patched in bridge.js's worker thread (and queued
// behind any other patch run in this process) when the freshly applied bridge.js offers it.
async function runHeadlessBridgePrepatchAsync(hubDir, extTargets = []) {
  const bridgeModPath = path.join(hubDir, 'bridge.js');
  if (!fs.existsSync(bridgeModPath)) {
    return { ok: false, reason: 'missing_bridge_js', reports: [] };
  }
  const webviewPatchesPath = path.join(hubDir, 'compat', 'claude-webview-patches.cjs');
  try {
    if (fs.existsSync(webviewPatchesPath)) {
      delete require.cache[require.resolve(webviewPatchesPath)];
    }
  } catch {}
  try {
    delete require.cache[require.resolve(bridgeModPath)];
  } catch {}
  const bridgeMod = require(bridgeModPath);
  if (typeof bridgeMod.runBridgeJobsInWorker !== 'function') {
    return runHeadlessBridgePrepatch(hubDir, extTargets);
  }
  const jobs = [];
  const extRoots = new Set((Array.isArray(extTargets) ? extTargets : []).map((t) => path.dirname(t)));
  for (const extParent of extRoots) {
    if (!fs.existsSync(extParent)) continue;
    for (const entry of fs.readdirSync(extParent, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const fullDir = path.join(extParent, entry.name);
      if (/^google\.google-antigravity-/i.test(entry.name)) {
        jobs.push({ provider: 'antigravity', dir: fullDir });
      } else if (/^anthropic\.claude-code-/i.test(entry.name)) {
        jobs.push({ provider: 'claude', dir: fullDir });
      }
    }
  }
  const reports = await bridgeMod.runBridgeJobsInWorker(jobs, hubDir);
  return {
    ok: true,
    bridgePatchDigest:
      typeof bridgeMod.getBridgePatchDigest === 'function' ? bridgeMod.getBridgePatchDigest() : '',
    reports
  };
}

module.exports = {
  BUNDLE_MANIFEST_NAME,
  BUNDLE_CANONICAL_PREFIX,
  DEFAULT_BUNDLE_URL,
  crc32Buffer,
  readInstalledBundleStamp,
  writeInstalledBundleStamp,
  isAllowedBundleUrl,
  canonicalHubReleaseMessage,
  signHubReleaseRecord,
  verifyHubReleaseRecord,
  validateSafeZipEntryPath,
  extractAndVerifyBundleZip,
  isGitRepoDirtyOrAhead,
  runHeadlessBridgePrepatch,
  runHeadlessBridgePrepatchAsync,
  maybeApplyHubReleaseUpdate
};
