'use strict';

// Unsaved work idle for 24 h or more (owner idea 2026-11-13, "THEO multi-session hygiene").
// Once an hour this host runs `theo-worktree-guard.py --report-json` from the THEO memory folder
// and caches the result in ~/.claude/.theo-unsaved-work.json. buildFullState publishes the
// sanitised summary as `unsavedWork`, and the evening THEO Remote digest names the folders that
// have held uncommitted or unpushed work untouched for 24 h, so they are pushed or cleared on
// purpose. The report sees every git working folder of a ~/bhfirms repo, Antigravity ones
// included (the delete guard itself cannot watch Antigravity sessions).

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const { resolveTheoMemoryRoot, findPythonExecutable } = require('./pc-setup');

const REFRESH_EVERY_MS = 60 * 60 * 1000;
const RUN_TIMEOUT_MS = 150 * 1000;
const MAX_DOC_AGE_MS = 26 * 60 * 60 * 1000;
const MAX_ITEMS = 20;
const STATE_KEY = Symbol.for('theo-hub.unsaved-work');
const st = (globalThis[STATE_KEY] = globalThis[STATE_KEY] || { inFlight: null, lastStartAt: 0 });

function resolveHome(opts = {}) {
  const env = opts.env || process.env;
  return String(opts.homeDir || env.THEO_SETUP_HOME || env.THEO_GUARD_HOME || os.homedir()).trim();
}

function resolveCachePath(opts = {}) {
  if (opts.cachePath) return String(opts.cachePath);
  return path.join(resolveHome(opts), '.claude', '.theo-unsaved-work.json');
}

function clip(val, max) {
  return String(val == null ? '' : val)
    .replace(/[\r\n\t]+/g, ' ')
    .trim()
    .slice(0, max);
}

function sanitizeUnsavedWork(raw, now = Date.now()) {
  if (!raw || typeof raw !== 'object') return null;
  const checkedAt = Math.max(0, Math.floor(Number(raw.checkedAt || 0)));
  if (!checkedAt || now - checkedAt > MAX_DOC_AGE_MS) return null;
  const staleHours = Number.isFinite(Number(raw.staleHours)) ? Number(raw.staleHours) : 24;
  const items = [];
  for (const it of Array.isArray(raw.items) ? raw.items : []) {
    if (!it || typeof it !== 'object') continue;
    const idle = it.idleHours == null ? null : Number(it.idleHours);
    items.push({
      repo: clip(it.repo, 40) || '?',
      branch: clip(it.branch, 60) || '-',
      where: clip(it.where, 40),
      why: clip(it.why, 60),
      path: clip(it.path, 180).replace(/^[A-Za-z]:\\Users\\[^\\]+/, '~'),
      idleHours: Number.isFinite(idle) ? Math.max(0, Math.round(idle * 10) / 10) : null,
      stale: Boolean(it.stale)
    });
    if (items.length >= MAX_ITEMS) break;
  }
  const count = (v, fallback) => Math.max(0, Math.min(999, Math.floor(Number(v ?? fallback) || 0)));
  return {
    checkedAt,
    staleHours,
    folders: count(raw.folders, 0),
    unsavedCount: count(raw.unsavedCount, items.length),
    staleCount: count(raw.staleCount, items.filter((i) => i.stale).length),
    unchecked: count(raw.unchecked, 0),
    items
  };
}

function readUnsavedWorkSummary(opts = {}) {
  try {
    const p = resolveCachePath(opts);
    if (!fs.existsSync(p)) return null;
    return sanitizeUnsavedWork(JSON.parse(fs.readFileSync(p, 'utf8')), opts.now || Date.now());
  } catch {
    return null;
  }
}

function folderLabel(it) {
  const who = it.where ? ` (${it.where})` : '';
  return `${it.repo} ${it.branch}${who}`;
}

// One line for the evening digest; '' when nothing has been idle long enough.
function formatUnsavedDigestLine(summary, maxNames = 3) {
  if (!summary || !summary.staleCount) return '';
  const stale = (summary.items || []).filter((i) => i.stale);
  const names = stale.slice(0, maxNames).map(folderLabel);
  const more = summary.staleCount - names.length;
  const hrs = Math.round(Number(summary.staleHours || 24));
  const n = summary.staleCount;
  return (
    `${n} folder${n === 1 ? '' : 's'} with unsaved work untouched ${hrs} h+: ${names.join(', ')}` +
    (more > 0 ? ` and ${more} more` : '')
  );
}

// Re-run the report when the cached one is older than an hour (checked against the cache file,
// so several VS Code windows on one PC share one run). Never blocks the caller.
function refreshUnsavedWork(opts = {}) {
  const env = opts.env || process.env;
  if (env.THEO_SMOKE_TEST === '1' && !opts.allowInSmokeTest) return Promise.resolve(null);
  if (st.inFlight) return st.inFlight;
  const now = Date.now();
  const cachePath = resolveCachePath(opts);
  if (!opts.force) {
    if (now - st.lastStartAt < REFRESH_EVERY_MS) return Promise.resolve(null);
    try {
      const age = now - fs.statSync(cachePath).mtimeMs;
      if (age < REFRESH_EVERY_MS) return Promise.resolve(null);
    } catch {}
  }
  const memoryRoot = resolveTheoMemoryRoot(opts);
  const guardPy = memoryRoot ? path.join(memoryRoot, 'Admin', 'theo-worktree-guard.py') : '';
  const pyExe = findPythonExecutable(opts);
  if (!guardPy || !fs.existsSync(guardPy) || !pyExe) return Promise.resolve(null);
  st.lastStartAt = now;
  const childEnv = { ...env };
  if (opts.homeDir) childEnv.THEO_GUARD_HOME = String(opts.homeDir);
  st.inFlight = new Promise((resolve) => {
    execFile(
      pyExe,
      [guardPy, '--report-json', '--out', cachePath],
      { timeout: opts.timeoutMs || RUN_TIMEOUT_MS, windowsHide: true, maxBuffer: 1024 * 1024, env: childEnv },
      () => resolve(readUnsavedWorkSummary(opts))
    );
  }).finally(() => {
    st.inFlight = null;
  });
  return st.inFlight;
}

module.exports = {
  sanitizeUnsavedWork,
  readUnsavedWorkSummary,
  formatUnsavedDigestLine,
  refreshUnsavedWork,
  resolveUnsavedWorkCachePath: resolveCachePath
};
