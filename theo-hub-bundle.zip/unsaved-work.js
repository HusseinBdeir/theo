'use strict';

// Unsaved work idle for 24 h or more (owner idea 2026-11-13, "THEO multi-session hygiene").
// Once an hour this host runs `theo-worktree-guard.py --report-json` from the THEO memory folder
// and caches the result in ~/.claude/.theo-unsaved-work.json. buildFullState publishes the
// sanitised summary as `unsavedWork`, and the evening THEO Remote digest names the folders that
// have held uncommitted or unpushed work untouched for 24 h, so they are pushed or cleared on
// purpose. The report sees every git working folder of a ~/bhfirms repo, Antigravity ones
// included (the delete guard itself cannot watch Antigravity sessions).

const fs = require('fs');
const http = require('http');
const https = require('https');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const { resolveTheoMemoryRoot, findPythonExecutable } = require('./pc-setup');
const { loadTheoCredentials, deriveEdgeAuthToken, DEFAULT_EDGE_RELAY_URL } = require('./device-identity');

const REFRESH_EVERY_MS = 60 * 60 * 1000;
const RUN_TIMEOUT_MS = 150 * 1000;
const STALLED_TIMEOUT_MS = 45 * 1000;
const MAX_DOC_AGE_MS = 26 * 60 * 60 * 1000;
// A peer PC that is switched off keeps its last report in the fleet entry; the phone still lists it
// (marked "last checked N d ago") for up to a week, because its folders are still unsaved.
const PEER_MAX_DOC_AGE_MS = 7 * 24 * 60 * 60 * 1000;
// Per PC, the Workspaces tab of THEO Remote lists up to 50 folders and says "+N more" beyond that.
const MAX_ITEMS = 50;
const READ_MEMO_MS = 30 * 1000;
const MAX_FUTURE_SKEW_MS = 10 * 60 * 1000;
const STATE_KEY = Symbol.for('theo-hub.unsaved-work');
const st = (globalThis[STATE_KEY] = globalThis[STATE_KEY] || { inFlight: null, lastStartAt: 0 });

function resolveHome(opts = {}) {
  const env = opts.env || process.env;
  return String(opts.homeDir || env.THEO_SETUP_HOME || env.THEO_GUARD_HOME || os.homedir()).trim();
}

function resolveCachePath(opts = {}) {
  if (opts.cachePath) return String(opts.cachePath);
  return path.join(resolveHome(opts), '.claude', '.theo-unsaved-work.json');
}

function clip(val, max) {
  return String(val == null ? '' : val)
    .replace(/[\r\n\t]+/g, ' ')
    .trim()
    .slice(0, max);
}

function sanitizeStalledWt(raw, fallbackCheckedAt = 0) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const items = [];
  for (const it of Array.isArray(raw.items) ? raw.items : []) {
    if (!it || typeof it !== 'object') continue;
    const age = it.ageHours == null ? null : Number(it.ageHours);
    items.push({
      repo: clip(it.repo, 40) || '?',
      branch: clip(it.branch, 60) || '-',
      sha: clip(it.sha, 16),
      ageHours: Number.isFinite(age) ? Math.max(0, Math.round(age * 10) / 10) : null,
      ahead: Math.max(0, Math.min(999, Math.floor(Number(it.ahead || 0)))),
      subject: clip(it.subject, 80)
    });
    if (items.length >= MAX_ITEMS) break;
  }
  const rawCount = Math.max(0, Math.min(999, Math.floor(Number(raw.stalledCount ?? items.length) || 0)));
  const stalledCount = Math.max(items.length, rawCount);
  if (stalledCount === 0 && items.length === 0) return null;
  const cutRaw = Number(raw.cutoffHours ?? raw.hours);
  const parsedTs =
    typeof raw.checkedAt === 'number' && Number.isFinite(raw.checkedAt)
      ? Math.max(0, Math.floor(raw.checkedAt))
      : raw.checkedAt
        ? Math.max(0, Date.parse(String(raw.checkedAt)) || 0)
        : 0;
  return {
    checkedAt: parsedTs || Math.max(0, Math.floor(Number(fallbackCheckedAt || 0))),
    cutoffHours: Number.isFinite(cutRaw) && cutRaw >= 0 ? cutRaw : 24,
    stalledCount,
    items
  };
}

function sanitizeUnsavedWork(raw, now = Date.now(), opts = {}) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const maxAgeMs = Number(opts.maxAgeMs) > 0 ? Number(opts.maxAgeMs) : MAX_DOC_AGE_MS;
  const checkedAt = Math.max(0, Math.floor(Number(raw.checkedAt || 0)));
  if (!checkedAt || now - checkedAt > maxAgeMs) return null;
  // A report stamped in the future (a PC clock running ahead) would never age out: treat it as no report.
  if (checkedAt - now > MAX_FUTURE_SKEW_MS) return null;
  const staleHours = Number.isFinite(Number(raw.staleHours)) ? Number(raw.staleHours) : 24;
  const items = [];
  for (const it of Array.isArray(raw.items) ? raw.items : []) {
    if (!it || typeof it !== 'object') continue;
    const idle = it.idleHours == null ? null : Number(it.idleHours);
    items.push({
      repo: clip(it.repo, 40) || '?',
      branch: clip(it.branch, 60) || '-',
      where: clip(it.where, 40),
      why: clip(it.why, 60),
      path: clip(it.path, 180).replace(/^[A-Za-z]:\\Users\\[^\\]+/, '~'),
      idleHours: Number.isFinite(idle) ? Math.max(0, Math.round(idle * 10) / 10) : null,
      stale: Boolean(it.stale)
    });
    if (items.length >= MAX_ITEMS) break;
  }
  const count = (v, fallback) => Math.max(0, Math.min(999, Math.floor(Number(v ?? fallback) || 0)));
  const stalledWt = sanitizeStalledWt(raw.stalledWt, checkedAt);
  return {
    checkedAt,
    staleHours,
    folders: count(raw.folders, 0),
    unsavedCount: count(raw.unsavedCount, items.length),
    staleCount: count(raw.staleCount, items.filter((i) => i.stale).length),
    unchecked: count(raw.unchecked, 0),
    items,
    ...(stalledWt ? { stalledWt } : {})
  };
}

function readUnsavedWorkSummary(opts = {}) {
  try {
    const p = resolveCachePath(opts);
    const now = opts.now || Date.now();
    let stat = null;
    try {
      stat = fs.statSync(p);
    } catch {
      return null;
    }
    // buildFullState, the fleet list and the sync cycle all ask several times a second: re-read the
    // file only when it changed, and re-check its age at most every 30 s.
    const maxAgeMs = Number(opts.maxAgeMs) > 0 ? Number(opts.maxAgeMs) : MAX_DOC_AGE_MS;
    const memoKey = `${p}|${maxAgeMs}`;
    st.memos = st.memos || {};
    const m = st.memos[memoKey];
    if (!opts.now && m && m.mtimeMs === stat.mtimeMs && m.size === stat.size && now - m.at < READ_MEMO_MS) {
      return m.value;
    }
    const value = sanitizeUnsavedWork(JSON.parse(fs.readFileSync(p, 'utf8')), now, { maxAgeMs });
    if (!opts.now) st.memos[memoKey] = { mtimeMs: stat.mtimeMs, size: stat.size, at: now, value };
    return value;
  } catch {
    return null;
  }
}

// This PC's own list for the fleet entry: kept for a week like a peer's, so a PC whose hourly check keeps
// failing still shows its last list ("last checked N d ago") instead of vanishing after 26 h. The evening
// digest keeps the 26 h limit (readUnsavedWorkSummary).
function readFleetUnsavedWorkSummary(opts = {}) {
  return readUnsavedWorkSummary({ ...opts, maxAgeMs: PEER_MAX_DOC_AGE_MS });
}

// A peer's copy, as received through the store or the edge relay: re-sanitised on this host, kept
// for up to a week so a PC that is switched off still shows its last list.
function sanitizePeerUnsavedWork(raw, now = Date.now()) {
  return sanitizeUnsavedWork(raw, now, { maxAgeMs: PEER_MAX_DOC_AGE_MS });
}

// Short change marker for the sync cycle's "did my own entry change" signature.
function unsavedWorkSig(summary) {
  if (!summary) return '';
  const stCount = summary.stalledWt ? summary.stalledWt.stalledCount : 0;
  return `|uw:${summary.checkedAt}:${summary.unsavedCount}:${summary.staleCount}:st${stCount}`;
}

function folderLabel(it) {
  const who = it.where ? ` (${it.where})` : '';
  return `${it.repo} ${it.branch}${who}`;
}

// One line for the evening digest; '' when nothing has been idle long enough.
function formatUnsavedDigestLine(summary, maxNames = 3) {
  if (!summary || !summary.staleCount) return '';
  const stale = (summary.items || []).filter((i) => i.stale);
  const names = stale.slice(0, maxNames).map(folderLabel);
  const more = summary.staleCount - names.length;
  const hrs = Math.round(Number(summary.staleHours || 24));
  const n = summary.staleCount;
  return (
    `${n} folder${n === 1 ? '' : 's'} with unsaved work untouched ${hrs} h+: ${names.join(', ')}` +
    (more > 0 ? ` and ${more} more` : '')
  );
}

// One line for unshipped remote origin/wt/* branches stalled past cutoffHours (release_lock.py stalled).
function formatStalledWtDigestLine(summary, maxNames = 3) {
  const sw = summary && summary.stalledWt;
  if (!sw || !sw.stalledCount) return '';
  const items = Array.isArray(sw.items) ? sw.items : [];
  const names = items.slice(0, maxNames).map((it) => `${it.repo} ${it.branch}`);
  const more = sw.stalledCount - names.length;
  const hrs = Math.round(Number(sw.cutoffHours || 24));
  const n = sw.stalledCount;
  return (
    `${n} unshipped wt/* branch${n === 1 ? '' : 'es'} stalled ${hrs} h+: ${names.join(', ')}` +
    (more > 0 ? ` and ${more} more` : '')
  );
}

// Re-run the report when the cached one is older than an hour (checked against the cache file,
// so several VS Code windows on one PC share one run). Never blocks the caller.
function resolveIsabiRoot(opts = {}, memoryRoot = '') {
  if (opts.isabiDir) return String(opts.isabiDir);
  if (opts.homeDir) return path.join(String(opts.homeDir), 'bhfirms', 'isabi');
  if (memoryRoot) return path.join(path.dirname(memoryRoot), 'isabi');
  return path.join(resolveHome(opts), 'bhfirms', 'isabi');
}

function runStalledWtRadar(pyExe, rlPy, opts, childEnv) {
  return new Promise((resolve) => {
    if (!rlPy || !fs.existsSync(rlPy) || opts.skipStalled) {
      resolve(null);
      return;
    }
    execFile(
      pyExe,
      [rlPy, 'stalled', '--hours', '24', '--json'],
      { timeout: opts.stalledTimeoutMs || STALLED_TIMEOUT_MS, windowsHide: true, maxBuffer: 1024 * 1024, env: childEnv },
      (err, stdout) => {
        if (err || !stdout) {
          resolve(null);
          return;
        }
        try {
          resolve(JSON.parse(String(stdout).trim()));
        } catch {
          resolve(null);
        }
      }
    );
  });
}

function refreshUnsavedWork(opts = {}) {
  const env = opts.env || process.env;
  if (env.THEO_SMOKE_TEST === '1' && !opts.allowInSmokeTest) return Promise.resolve(null);
  if (st.inFlight) return st.inFlight;
  const now = Date.now();
  const cachePath = resolveCachePath(opts);
  if (!opts.force) {
    if (now - st.lastStartAt < REFRESH_EVERY_MS) return Promise.resolve(null);
    try {
      const age = now - fs.statSync(cachePath).mtimeMs;
      if (age < REFRESH_EVERY_MS) return Promise.resolve(null);
    } catch {}
  }
  const memoryRoot = resolveTheoMemoryRoot(opts);
  const guardPy = memoryRoot ? path.join(memoryRoot, 'Admin', 'theo-worktree-guard.py') : '';
  const rlPy = path.join(resolveIsabiRoot(opts, memoryRoot), 'build', 'release_lock.py');
  const hasGuard = Boolean(guardPy && fs.existsSync(guardPy));
  const hasRadar = Boolean(!opts.skipStalled && rlPy && fs.existsSync(rlPy));
  const pyExe = findPythonExecutable(opts);
  if ((!hasGuard && !hasRadar) || !pyExe) return Promise.resolve(null);
  st.lastStartAt = now;
  const childEnv = { ...env };
  if (opts.homeDir) childEnv.THEO_GUARD_HOME = String(opts.homeDir);
  let prevDoc = null;
  try {
    prevDoc = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
  } catch {}
  const prevStalled = prevDoc && typeof prevDoc === 'object' ? prevDoc.stalledWt : null;
  const prevStalledFresh =
    prevStalled &&
    typeof prevStalled === 'object' &&
    now - Math.max(0, Number(prevStalled.checkedAt || prevDoc.checkedAt || 0)) <= MAX_DOC_AGE_MS;

  st.inFlight = (async () => {
    if (hasGuard) {
      await new Promise((resolve) => {
        execFile(
          pyExe,
          [guardPy, '--report-json', '--out', cachePath],
          { timeout: opts.timeoutMs || RUN_TIMEOUT_MS, windowsHide: true, maxBuffer: 1024 * 1024, env: childEnv },
          () => resolve()
        );
      });
    }
    const stalledRaw = hasRadar ? await runStalledWtRadar(pyExe, rlPy, opts, childEnv) : null;
    if (stalledRaw && typeof stalledRaw === 'object') {
      try {
        let baseDoc = null;
        try {
          baseDoc = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
        } catch {}
        if (!baseDoc || typeof baseDoc !== 'object' || Array.isArray(baseDoc)) {
          baseDoc = { checkedAt: Date.now(), staleHours: 24, folders: 0, unsavedCount: 0, staleCount: 0, unchecked: 0, items: [] };
        }
        baseDoc.stalledWt = {
          checkedAt: Date.now(),
          cutoffHours: Number(stalledRaw.cutoffHours ?? stalledRaw.hours ?? 24),
          stalledCount: Number(stalledRaw.stalledCount ?? (Array.isArray(stalledRaw.items) ? stalledRaw.items.length : 0)),
          items: Array.isArray(stalledRaw.items) ? stalledRaw.items : []
        };
        fs.mkdirSync(path.dirname(cachePath), { recursive: true });
        fs.writeFileSync(cachePath, JSON.stringify(baseDoc), 'utf8');
      } catch {}
    } else if (hasRadar && prevStalledFresh) {
      // Transient git/network failure on `release_lock.py stalled`: preserve last recent stalledWt instead of dropping it.
      try {
        let baseDoc = null;
        try {
          baseDoc = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
        } catch {}
        if (baseDoc && typeof baseDoc === 'object' && !Array.isArray(baseDoc) && !baseDoc.stalledWt) {
          baseDoc.stalledWt = prevStalled;
          fs.writeFileSync(cachePath, JSON.stringify(baseDoc), 'utf8');
        }
      } catch {}
    }
    return readUnsavedWorkSummary(opts);
  })().finally(() => {
    st.inFlight = null;
  });
  return st.inFlight;
}

const RELEASE_STALE_MS = 180 * 60 * 1000;
const RELEASE_DEAD_KEEP_MS = 7 * 24 * 60 * 60 * 1000;
const RELEASE_DISMISSED_KEEP_MS = 14 * 24 * 60 * 60 * 1000;
const RELEASE_POLL_OK_MS = 60 * 1000;
const RELEASE_POLL_ERR_MS = 15 * 1000;
const RELEASE_HTTP_TIMEOUT_MS = 5000;
const RELEASE_MAX_HTTP_BYTES = 1024 * 1024;
const RELEASE_CACHE_NAME = '.theo-release-line-radar.json';

const releaseRadarState = {
  inFlight: null,
  lastOkAt: 0,
  lastErrAt: 0,
  pendingOnChanged: []
};

function hasOwn(obj, key) {
  return Boolean(obj && Object.prototype.hasOwnProperty.call(obj, key));
}

function cleanRelText(raw, maxLen = 120) {
  return String(raw || '')
    .replace(/\u2014|\u2192/g, '-')
    .replace(/[\x00-\x1f\x7f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLen);
}

function parseRelIsoMs(iso) {
  const s = String(iso || '').trim();
  if (!s) return 0;
  const ms = Date.parse(s);
  return Number.isFinite(ms) ? ms : 0;
}

function resolveReleaseLineCachePath(opts = {}) {
  if (opts && opts.cachePath) return String(opts.cachePath);
  return path.join(resolveHome(opts), '.claude', RELEASE_CACHE_NAME);
}

function isSafeReleaseStateUrl(urlStr) {
  const u = String(urlStr || '').trim();
  if (!u) return false;
  return /^https:\/\/[^\s]+$/i.test(u) || /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/|$)/i.test(u);
}

function normalizeReleaseStateUrl(rawRelayUrl) {
  const stripRelay = (u) => String(u || '')
    .trim()
    .replace(/^wss:/i, 'https:')
    .replace(/^ws:/i, 'http:')
    .replace(/[?#].*$/, '')
    .replace(/\/+$/, '')
    .replace(/\/(ws|store)$/i, '')
    .replace(/\/+$/, '');
  const baseUrl = stripRelay(rawRelayUrl) || stripRelay(DEFAULT_EDGE_RELAY_URL);
  if (!baseUrl) return '';
  const stateUrl = `${baseUrl}/release/state`;
  return isSafeReleaseStateUrl(stateUrl) ? stateUrl : '';
}

function readReleaseLineConfig(opts = {}) {
  try {
    const env = opts.env || process.env;
    let key = String(env.THEO_EDGE_KEY || '').trim();
    let relayUrl = String(env.THEO_EDGE_RELAY_URL || '').trim();
    if (!opts.env) {
      const creds = loadTheoCredentials();
      if (!key) key = String(creds?.edgeAccessKey || '').trim();
      if (!relayUrl) relayUrl = String(creds?.edgeRelayUrl || '').trim();
    } else if (env.THEO_CRED_PATH) {
      try {
        if (fs.existsSync(env.THEO_CRED_PATH)) {
          const parsed = JSON.parse(fs.readFileSync(env.THEO_CRED_PATH, 'utf8'));
          if (!key) key = String(parsed?.edgeAccessKey || '').trim();
          if (!relayUrl) relayUrl = String(parsed?.edgeRelayUrl || '').trim();
        }
      } catch {}
    }
    if (!key) return null;
    const stateUrl = normalizeReleaseStateUrl(relayUrl || DEFAULT_EDGE_RELAY_URL);
    if (!stateUrl) return null;
    const token = deriveEdgeAuthToken(key);
    if (!token) return null;
    return { stateUrl, token };
  } catch {
    return null;
  }
}

function fetchJsonHttp(urlStr, token, timeoutMs = RELEASE_HTTP_TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    if (!isSafeReleaseStateUrl(urlStr)) {
      reject(new Error('unsafe_release_url'));
      return;
    }
    let parsed;
    try {
      parsed = new URL(urlStr);
    } catch (err) {
      reject(err);
      return;
    }
    let settled = false;
    let ended = false;
    const fail = (err) => {
      if (settled) return;
      settled = true;
      reject(err instanceof Error ? err : new Error(String(err || 'http_error')));
    };
    const finish = (val) => {
      if (settled) return;
      settled = true;
      resolve(val);
    };
    const lib = parsed.protocol === 'http:' ? http : https;
    const req = lib.request(
      parsed,
      {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json'
        }
      },
      (res) => {
        const chunks = [];
        let totalBytes = 0;
        res.on('data', (c) => {
          if (settled) return;
          totalBytes += c.length;
          if (totalBytes > RELEASE_MAX_HTTP_BYTES) {
            fail(new Error('response_too_large'));
            try { res.destroy(); } catch {}
            try { req.destroy(); } catch {}
            return;
          }
          chunks.push(c);
        });
        res.on('error', fail);
        res.on('close', () => {
          if (!ended) fail(new Error('response_closed'));
        });
        res.on('end', () => {
          ended = true;
          const text = Buffer.concat(chunks).toString('utf8');
          if ((res.statusCode || 0) < 200 || (res.statusCode || 0) >= 300) {
            fail(new Error(`HTTP ${res.statusCode || 0}`));
            return;
          }
          try {
            finish(JSON.parse(text || '{}'));
          } catch (err) {
            fail(err);
          }
        });
      }
    );
    req.setTimeout(timeoutMs, () => {
      fail(new Error('timeout'));
      try { req.destroy(); } catch {}
    });
    req.on('error', fail);
    req.end();
  });
}

function classifyReleaseLineState(stateDoc, opts = {}) {
  const nowMs = Number(opts.nowMs || Date.now());
  const entries = Array.isArray(stateDoc?.line)
    ? stateDoc.line
    : (Array.isArray(stateDoc?.entries) ? stateDoc.entries : []);
  const lockId = String(stateDoc?.lock?.lockId || '').trim();
  const items = [];
  for (const e of entries) {
    if (!e || typeof e !== 'object' || !e.id) continue;
    const st = String(e.state || '').trim();
    const id = cleanRelText(e.id, 64);
    if (!id) continue;
    const summary = cleanRelText(e.summary || id, 100) || id;
    const holder = cleanRelText(e.holder || '', 64);
    const appB = cleanRelText(e.app?.branch || '', 64);
    const siteB = cleanRelText(e.site?.branch || '', 64);
    const branch = [appB, siteB].filter(Boolean).join(' + ');
    if (st === 'left_out') {
      const leftOutAtRaw = String(e.leftOutAt || e.seenAt || e.queuedAt || '').trim();
      const atMs = parseRelIsoMs(leftOutAtRaw);
      if (atMs > 0 && nowMs - atMs > RELEASE_DEAD_KEEP_MS) continue;
      const why = cleanRelText(e.note || 'left out of batch', 140) || 'left out of batch';
      items.push({
        id,
        kind: 'left_out',
        kindLabel: 'LEFT OUT',
        alertKey: `isabi-rel-${id}-left_out`,
        dismissKey: `${id}:left_out:${cleanRelText(leftOutAtRaw, 40)}`,
        summary,
        holder,
        branch,
        why,
        by: cleanRelText(e.leftOutBy || '', 48),
        atMs
      });
    } else if (st === 'waiting') {
      if (lockId && String(e.batch?.lockId || '').trim() === lockId) continue;
      const hbRaw = String(e.seenAt || e.heartbeatAt || e.queuedAt || '').trim();
      const hbMs = parseRelIsoMs(hbRaw);
      if (!(hbMs > 0)) continue;
      const ageMs = nowMs - hbMs;
      if (ageMs <= RELEASE_STALE_MS || ageMs > RELEASE_DEAD_KEEP_MS) continue;
      const staleHours = Math.max(3, Math.floor(ageMs / 3600000));
      items.push({
        id,
        kind: 'stale',
        kindLabel: 'STALE',
        alertKey: `isabi-rel-${id}-stale`,
        dismissKey: `${id}:stale:${cleanRelText(hbRaw, 40)}`,
        summary,
        holder,
        branch,
        why: `no heartbeat for ${staleHours}h`,
        staleHours,
        atMs: hbMs
      });
    }
  }
  items.sort((a, b) => {
    if (a.kind !== b.kind) return a.kind === 'left_out' ? -1 : 1;
    return (a.atMs || 0) - (b.atMs || 0);
  });
  return { items, updatedAt: nowMs };
}

function readReleaseRadarDoc(opts = {}) {
  try {
    const cachePath = resolveReleaseLineCachePath(opts);
    if (!fs.existsSync(cachePath)) return null;
    const raw = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
    return raw && typeof raw === 'object' ? raw : null;
  } catch {
    return null;
  }
}

function writeReleaseRadarDoc(doc, opts = {}) {
  try {
    const cachePath = resolveReleaseLineCachePath(opts);
    fs.mkdirSync(path.dirname(cachePath), { recursive: true });
    const tmp = `${cachePath}.tmp-${process.pid}`;
    fs.writeFileSync(tmp, JSON.stringify(doc), 'utf8');
    fs.renameSync(tmp, cachePath);
  } catch {}
}

function sanitizeReleaseLineAlertForRemote(raw, opts = {}) {
  if (!raw || typeof raw !== 'object') return null;
  const maxCap = Math.max(1, Number(opts.cap || 8));
  const srcItems = Array.isArray(raw.items) ? raw.items : [];
  const allValid = [];
  for (const it of srcItems) {
    if (!it || typeof it !== 'object') continue;
    const kind = it.kind === 'left_out' ? 'left_out' : (it.kind === 'stale' ? 'stale' : '');
    const id = cleanRelText(it.id, 64);
    if (!kind || !id) continue;
    allValid.push({
      id,
      kind,
      kindLabel: kind === 'left_out' ? 'LEFT OUT' : 'STALE',
      alertKey: cleanRelText(it.alertKey || `isabi-rel-${id}-${kind}`, 96),
      dismissKey: cleanRelText(it.dismissKey || `${id}:${kind}`, 128),
      summary: cleanRelText(it.summary || id, 100),
      holder: cleanRelText(it.holder || '', 64),
      branch: cleanRelText(it.branch || '', 80),
      why: cleanRelText(it.why || '', 140)
    });
  }
  if (!allValid.length) return null;
  const items = allValid.slice(0, maxCap);
  const staleCount = allValid.filter((i) => i.kind === 'stale').length;
  const leftOutCount = allValid.filter((i) => i.kind === 'left_out').length;
  const totalCount = Math.max(allValid.length, Number(raw.totalCount || raw.count || 0) || 0);
  return {
    count: allValid.length,
    totalCount,
    staleCount,
    leftOutCount,
    items,
    dismissKeys: allValid.map((i) => i.dismissKey),
    updatedAt: Number(raw.updatedAt || 0) || 0
  };
}

function isReleaseRadarSmokeBlocked(opts = {}) {
  const env = (opts && opts.env) || process.env;
  return (
    env.THEO_SMOKE_TEST === '1' &&
    !opts?.allowInSmokeTest &&
    !opts?.homeDir &&
    !opts?.cachePath &&
    !env.THEO_GUARD_HOME
  );
}

function readRawReleaseLineAlert(opts = {}) {
  if (isReleaseRadarSmokeBlocked(opts)) return null;
  const doc = readReleaseRadarDoc(opts);
  if (!doc) return null;
  return sanitizeReleaseLineAlertForRemote({ items: doc.items, updatedAt: doc.updatedAt }, { cap: 200 });
}

function readReleaseLineAlertView(opts = {}) {
  if (isReleaseRadarSmokeBlocked(opts)) return null;
  const nowMs = Number(opts.nowMs || Date.now());
  const doc = readReleaseRadarDoc(opts);
  if (!doc || !Array.isArray(doc.items)) return null;
  const dismissed = doc.dismissed && typeof doc.dismissed === 'object' ? doc.dismissed : {};
  const visible = doc.items.filter((it) => {
    const dk = String(it?.dismissKey || '').trim();
    if (!dk) return true;
    const dAt = hasOwn(dismissed, dk) ? Number(dismissed[dk] || 0) : 0;
    return !(dAt > 0 && nowMs - dAt < RELEASE_DISMISSED_KEEP_MS);
  });
  return sanitizeReleaseLineAlertForRemote({ items: visible, updatedAt: doc.updatedAt });
}

function dismissReleaseLineAlert(keys, opts = {}) {
  const nowMs = Number(opts.nowMs || Date.now());
  const doc = readReleaseRadarDoc(opts) || { items: [], dismissed: {}, updatedAt: 0 };
  const dismissed = Object.create(null);
  for (const [k, ts] of Object.entries(doc.dismissed && typeof doc.dismissed === 'object' ? doc.dismissed : {})) {
    if (Number(ts) > 0 && nowMs - Number(ts) < RELEASE_DISMISSED_KEEP_MS) {
      dismissed[k] = Number(ts);
    }
  }
  const targetKeys = Array.isArray(keys) && keys.length > 0
    ? keys.map((k) => String(k || '').trim()).filter(Boolean)
    : (Array.isArray(doc.items) ? doc.items.map((it) => String(it?.dismissKey || '').trim()).filter(Boolean) : []);
  for (const dk of targetKeys) {
    dismissed[dk] = nowMs;
  }
  writeReleaseRadarDoc({ ...doc, dismissed }, opts);
  return readReleaseLineAlertView(opts);
}

function buildReleaseLinePushPlan({ items = [], sentKeys = new Set() } = {}) {
  const seen = sentKeys instanceof Set ? sentKeys : new Set(Array.isArray(sentKeys) ? sentKeys : []);
  const unseen = (Array.isArray(items) ? items : []).filter((it) => {
    const ak = cleanRelText(it?.alertKey || '', 96);
    return ak && !seen.has(ak);
  });
  if (!unseen.length) return null;
  const leftOut = unseen.filter((i) => i.kind === 'left_out');
  const stale = unseen.filter((i) => i.kind === 'stale');
  const partsTitle = [];
  if (leftOut.length) partsTitle.push(`${leftOut.length} left out`);
  if (stale.length) partsTitle.push(`${stale.length} stale`);
  const title = cleanRelText(`ISABI Release Queue - ${partsTitle.join(', ')}`, 80);
  const bodyLines = unseen.slice(0, 3).map((it) => {
    const label = it.kind === 'left_out' ? 'LEFT OUT' : 'STALE';
    const subject = it.branch || it.summary || it.id;
    return `${label}: ${subject}${it.why ? ' (' + it.why + ')' : ''}`;
  });
  if (unseen.length > 3) bodyLines.push(`+${unseen.length - 3} more`);
  const body = cleanRelText(bodyLines.join(' | '), 220);
  return {
    keys: unseen.map((i) => cleanRelText(i.alertKey, 96)),
    push: {
      title,
      body,
      tag: cleanRelText(`isabi-release-${unseen[0].alertKey}`, 64),
      url: '/'
    }
  };
}

function refreshReleaseLineRadar(opts = {}) {
  const env = opts.env || process.env;
  if (env.THEO_SMOKE_TEST === '1' && !opts.allowInSmokeTest) return Promise.resolve(null);
  if (typeof opts.onChanged === 'function') {
    releaseRadarState.pendingOnChanged.push(opts.onChanged);
  }
  if (releaseRadarState.inFlight) return releaseRadarState.inFlight;
  const nowMs = Number(opts.nowMs || Date.now());
  if (!opts.force) {
    if (
      releaseRadarState.lastOkAt &&
      nowMs >= releaseRadarState.lastOkAt &&
      nowMs - releaseRadarState.lastOkAt < RELEASE_POLL_OK_MS
    ) {
      releaseRadarState.pendingOnChanged.length = 0;
      return Promise.resolve(readReleaseLineAlertView(opts));
    }
    if (
      releaseRadarState.lastErrAt &&
      nowMs >= releaseRadarState.lastErrAt &&
      nowMs - releaseRadarState.lastErrAt < RELEASE_POLL_ERR_MS
    ) {
      releaseRadarState.pendingOnChanged.length = 0;
      return Promise.resolve(readReleaseLineAlertView(opts));
    }
  }
  const cfg = opts.stateUrl && opts.token
    ? { stateUrl: opts.stateUrl, token: opts.token }
    : readReleaseLineConfig(opts);
  if (!cfg) {
    releaseRadarState.pendingOnChanged.length = 0;
    return Promise.resolve(null);
  }
  releaseRadarState.inFlight = (async () => {
    try {
      const prevViewSig = JSON.stringify(readReleaseLineAlertView(opts)?.dismissKeys || []);
      const fetchFn = typeof opts.fetchFn === 'function'
        ? opts.fetchFn
        : (u, t) => fetchJsonHttp(u, t, RELEASE_HTTP_TIMEOUT_MS);
      const stateDoc = await fetchFn(cfg.stateUrl, cfg.token);
      const classified = classifyReleaseLineState(stateDoc, { nowMs: Number(opts.nowMs || Date.now()) });
      const prev = readReleaseRadarDoc(opts) || {};
      const prunedDismissed = Object.create(null);
      const tNow = Number(opts.nowMs || Date.now());
      for (const [k, ts] of Object.entries(prev.dismissed && typeof prev.dismissed === 'object' ? prev.dismissed : {})) {
        if (Number(ts) > 0 && tNow - Number(ts) < RELEASE_DISMISSED_KEEP_MS) {
          prunedDismissed[k] = Number(ts);
        }
      }
      writeReleaseRadarDoc({
        updatedAt: classified.updatedAt,
        lastFetchOkAt: tNow,
        items: classified.items,
        dismissed: prunedDismissed
      }, opts);
      releaseRadarState.lastOkAt = tNow;
      const nextView = readReleaseLineAlertView(opts);
      const nextViewSig = JSON.stringify(nextView?.dismissKeys || []);
      const listeners = releaseRadarState.pendingOnChanged.splice(0);
      if (nextViewSig !== prevViewSig) {
        for (const fn of new Set(listeners)) {
          try {
            fn(nextView);
          } catch {}
        }
      }
      return nextView;
    } catch {
      releaseRadarState.lastErrAt = nowMs;
      releaseRadarState.pendingOnChanged.length = 0;
      return readReleaseLineAlertView(opts);
    }
  })().finally(() => {
    releaseRadarState.inFlight = null;
    releaseRadarState.pendingOnChanged.length = 0;
  });
  return releaseRadarState.inFlight;
}

module.exports = {
  sanitizeUnsavedWork,
  sanitizePeerUnsavedWork,
  sanitizeStalledWt,
  unsavedWorkSig,
  UNSAVED_WORK_MAX_ITEMS: MAX_ITEMS,
  readUnsavedWorkSummary,
  readFleetUnsavedWorkSummary,
  formatUnsavedDigestLine,
  formatStalledWtDigestLine,
  refreshUnsavedWork,
  resolveUnsavedWorkCachePath: resolveCachePath,
  classifyReleaseLineState,
  refreshReleaseLineRadar,
  readRawReleaseLineAlert,
  readReleaseLineAlertView,
  dismissReleaseLineAlert,
  sanitizeReleaseLineAlertForRemote,
  buildReleaseLinePushPlan,
  resolveReleaseLineCachePath,
  readReleaseLineConfig
};
