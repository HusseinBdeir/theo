"""Install bhfirms.theo-hub into ~/.vscode/extensions, migrate state from bhfirms.antigravity-hub, and pre-install both the Antigravity and Claude Code bridges."""
import json
import pathlib
import shutil
import sqlite3
import subprocess
import time

root = pathlib.Path(__file__).parent
if root.resolve().name.lower() == "antigravity-hub":
    # Retired mirror (2026-11-18): installing from it would push stale code into the extension folder.
    raise SystemExit(
        "[ERROR] ~/bhfirms/antigravity-hub is a retired mirror. Run install_local.py from ~/bhfirms/theo-hub instead."
    )
pkg = json.loads((root / "package.json").read_text(encoding="utf-8"))
ext_id = f"{pkg['publisher']}.{pkg['name']}"
legacy_ext_id = "bhfirms.antigravity-hub"
version = pkg["version"]
folder_name = f"{ext_id}-{version}"

vscode_ext_dir = pathlib.Path.home() / ".vscode" / "extensions"
target_dir = vscode_ext_dir / folder_name

files = [
    "package.json",
    "extension.js",
    "accounts.js",
    "session-tabs.js",
    "hub.js",
    "data.js",
    "store.js",
    "state.js",
    "bridge.js",
    "remote.js",
    "device-identity.js",
    "pc-setup.js",
    "unsaved-work.js",
    "auto-reload.js",
    "bundle-updater.js",
    "ws-server.js",
    "direct-runner.js",
    "edge-relay-client.js",
    "README.md",
    "activity.js",
    "desktop-notify.js",
    "desktop-launcher.js",
    "compat/antigravity-hub-bridge.cjs",
    "compat/antigravity-tab-state.cjs",
    "compat/antigravity-context-window.cjs",
    "compat/claude-hub-bridge.cjs",
    "compat/claude-webview-patches.cjs",
    "compat/excel-preview.cjs",
    "resources/icon.png",
    "resources/theo.ico",
    "resources/TheoLauncher.cs",
    "resources/logo.svg",
    "resources/antigravity-logo-color.svg",
    "resources/antigravity-logo-done.svg",
    "resources/antigravity-logo-pending.svg",
    "resources/claude-logo.svg",
    "resources/claude-logo-done.svg",
    "resources/claude-logo-pending.svg",
    "resources/hub.html",
    "resources/hub.css",
    "resources/hub.js",
    "scripts/relay_keepalive.cjs",
    "scripts/relay_keepalive_start.ps1",
    "scripts/memory_cloud_sync.cjs",
    "scripts/theo_agent.cjs",
    "scripts/theo_agent_start.ps1",
    "scripts/install_desktop_shortcut.ps1",
]


# 0. Migrate saved state from bhfirms.antigravity-hub -> ~/.claude/.theo-hub-state.json & bhfirms.theo-hub in state.vscdb
vscdb_path = (
    pathlib.Path.home()
    / "AppData"
    / "Roaming"
    / "Code"
    / "User"
    / "globalStorage"
    / "state.vscdb"
)
backup_state_path = pathlib.Path.home() / ".claude" / ".theo-hub-state.json"
if vscdb_path.exists():
    try:
        con = sqlite3.connect(str(vscdb_path), timeout=2.0)
        row_new = con.execute("SELECT value FROM ItemTable WHERE key=?", (ext_id,)).fetchone()
        row_old = con.execute("SELECT value FROM ItemTable WHERE key=?", (legacy_ext_id,)).fetchone()
        chosen_raw = (row_new[0] if row_new else None) or (row_old[0] if row_old else None)
        if chosen_raw:
            parsed_outer = json.loads(chosen_raw)
            inner_state = parsed_outer.get("antigravity-hub.state.v1")
            if isinstance(inner_state, dict) and not backup_state_path.exists():
                backup_state_path.parent.mkdir(parents=True, exist_ok=True)
                backup_state_path.write_text(json.dumps(inner_state), encoding="utf-8")
                print(f"[OK] Backed up Hub state to {backup_state_path}")
            if not row_new and row_old:
                try:
                    con.execute(
                        "INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)",
                        (ext_id, row_old[0]),
                    )
                    con.commit()
                    print(f"[OK] Migrated state.vscdb key {legacy_ext_id} -> {ext_id}")
                except Exception:
                    pass
        con.close()
    except Exception as e:
        print(f"[WARN] state.vscdb check skipped: {e}")

# 0b. The ~/bhfirms/antigravity-hub mirror is retired (2026-11-18): it is no longer refreshed here, and the per-PC
# setup step `retire-antigravity-hub` (memory/Admin/theo-retire-antigravity-hub.py) moves it to ~/.theo/retired/.

# 1. Copy extension files into ~/.vscode/extensions/bhfirms.theo-hub-0.1.0 and ~/.antigravity/extensions/bhfirms.theo-hub-0.1.0
for old_dir in vscode_ext_dir.glob(f"{legacy_ext_id}-*"):
    if old_dir.is_dir() and old_dir.resolve() != target_dir.resolve():
        shutil.rmtree(old_dir, ignore_errors=True)
        print(f"[OK] Removed legacy extension folder {old_dir}")

ext_targets = [target_dir]
agy_ext_root = pathlib.Path.home() / ".antigravity" / "extensions"
if agy_ext_root.exists():
    ext_targets.append(agy_ext_root / folder_name)

for dst_root in ext_targets:
    legacy_dst_secret = dst_root / "remote-relay.json"
    if legacy_dst_secret.exists():
        legacy_dst_secret.unlink(missing_ok=True)
    for rel in files:
        src = root / rel
        if src.exists():
            dst = dst_root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
    print(f"[OK] Installed extension files to {dst_root}")

# 2. Register in ~/.vscode/extensions/extensions.json
ext_json_path = vscode_ext_dir / "extensions.json"
if ext_json_path.exists():
    entries = json.loads(ext_json_path.read_text(encoding="utf-8"))
else:
    entries = []

entries = [
    e
    for e in entries
    if (e.get("identifier") or {}).get("id", "").lower()
    not in {ext_id.lower(), legacy_ext_id.lower()}
]

posix_path = "/" + str(target_dir.resolve()).replace("\\", "/")
if posix_path[1].isalpha() and posix_path[2] == ":":
    posix_path = "/" + posix_path[1].lower() + posix_path[2:]

entries.append(
    {
        "identifier": {"id": ext_id},
        "version": version,
        "location": {
            "$mid": 1,
            "path": posix_path,
            "scheme": "file",
        },
        "relativeLocation": folder_name,
        "metadata": {
            "isApplicationScoped": False,
            "isMachineScoped": False,
            "isBuiltin": False,
            "installedTimestamp": int(time.time() * 1000),
            "pinned": True,
            "source": "vsix",
        },
    }
)

# 2b. Sync anthropic.claude-code auto-update state in extensions.json & state.vscdb with ~/.claude/.theo-accounts-vault.json
vault_path = pathlib.Path.home() / ".claude" / ".theo-accounts-vault.json"
claude_signed_out = False
if vault_path.exists():
    try:
        vault_data = json.loads(vault_path.read_text(encoding="utf-8"))
        claude_accts = [
            a
            for a in (vault_data.get("accounts") or {}).get("claude") or []
            if isinstance(a, dict) and "@" in str(a.get("email") or "")
        ]
        if not claude_accts and (vault_data.get("signedOut") or {}).get("claude"):
            claude_signed_out = True
    except Exception:
        pass

for entry in entries:
    if (entry.get("identifier") or {}).get("id", "").lower() == "anthropic.claude-code":
        entry.setdefault("metadata", {})["pinned"] = bool(claude_signed_out)

ext_json_path.write_text(json.dumps(entries, separators=(",", ":")), encoding="utf-8")
print(f"[OK] Registered {ext_id} in {ext_json_path}")

if vscdb_path.exists():
    try:
        con = sqlite3.connect(str(vscdb_path), timeout=2.0)
        row = con.execute(
            "SELECT value FROM ItemTable WHERE key=?", ("extensions.donotAutoUpdate",)
        ).fetchone()
        arr = json.loads(row[0]) if row and row[0] else []
        if not isinstance(arr, list):
            arr = []
        norm = [str(x).lower() for x in arr]
        changed = False
        if claude_signed_out and "anthropic.claude-code" not in norm:
            arr.append("anthropic.claude-code")
            changed = True
        elif not claude_signed_out and "anthropic.claude-code" in norm:
            arr = [x for x in arr if str(x).lower() != "anthropic.claude-code"]
            changed = True
        if changed:
            con.execute(
                "INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)",
                ("extensions.donotAutoUpdate", json.dumps(arr)),
            )
            con.commit()
            print(
                f"[OK] Synced extensions.donotAutoUpdate in state.vscdb (claude_signed_out={claude_signed_out})"
            )
        con.close()
    except Exception as e:
        print(f"[WARN] extensions.donotAutoUpdate sync skipped: {e}")

# 3. Pre-install the bridge into google.google-antigravity-* and anthropic.claude-code-*
# using bridge.js directly so bundles are only written when modified and .theo-bridge-stamp.json v3 stays warm.
bridge_install_script = """
const fs = require('fs');
const path = require('path');
const bridge = require(process.argv[1]);
const hubRoot = process.argv[2];
const vscodeExtDir = process.argv[3];

if (fs.existsSync(vscodeExtDir)) {
  for (const entry of fs.readdirSync(vscodeExtDir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const fullDir = path.join(vscodeExtDir, entry.name);
    if (/^google\\.google-antigravity-/i.test(entry.name)) {
      const res = bridge.ensureBridgeInstalledForExtensionDir(fullDir, hubRoot);
      if (res.installed) {
        console.log(`[OK] Bridge ready in ${fullDir} (bundleUpdated=${Boolean(res.bundleUpdated)}, filesUpdated=${Boolean(res.filesUpdated)})`);
      }
    } else if (/^anthropic\\.claude-code-/i.test(entry.name)) {
      const res = bridge.ensureClaudeBridgeInstalledForExtensionDir(fullDir, hubRoot);
      if (res.installed) {
        console.log(`[OK] Claude bridge ready in ${fullDir} (bundleUpdated=${Boolean(res.bundleUpdated)}, webviewUpdated=${Boolean(res.webviewUpdated)}, filesUpdated=${Boolean(res.filesUpdated)})`);
      }
    }
  }
}
try {
  const os = require('os');
  const launcher = require(path.join(hubRoot, 'desktop-launcher.js'));
  if (typeof launcher.ensureNativeLauncherExecutable === 'function') {
    const homeDir = os.homedir();
    const ico = launcher.ensureStableDesktopIcon({ hubRoot, homeDir });
    let savedHash = '';
    const statePath = path.join(homeDir, '.theo', 'desktop-shortcut.json');
    if (fs.existsSync(statePath)) {
      try {
        savedHash = String(JSON.parse(fs.readFileSync(statePath, 'utf8'))?.launcherSourceHash || '');
      } catch {}
    }
    const lRes = launcher.ensureNativeLauncherExecutable({
      hubRoot,
      homeDir,
      iconPath: ico.iconPath,
      savedHash,
      force: false
    });
    if (lRes && lRes.launcherExePath) {
      console.log(`[OK] Desktop launcher ready at ${lRes.launcherExePath} (rebuilt=${Boolean(lRes.updated || lRes.compiled || lRes.rebuilt)})`);
    }
  }
} catch (err) {
  console.warn('[WARN] Desktop launcher compile skipped:', err && err.message ? err.message : err);
}
"""
import os

portable_node = pathlib.Path.home() / ".local" / "node" / "node.exe"
node_exe = str(portable_node) if portable_node.exists() else shutil.which("node")
node_env = os.environ.copy()
if not node_exe:
    for vs_cand in (
        pathlib.Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Microsoft VS Code" / "Code.exe",
        pathlib.Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "Microsoft VS Code" / "Code.exe",
        pathlib.Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Antigravity IDE" / "Antigravity.exe",
    ):
        if vs_cand.exists():
            node_exe = str(vs_cand)
            node_env["ELECTRON_RUN_AS_NODE"] = "1"
            break

if not node_exe:
    raise RuntimeError("Could not find node or VS Code executable to install THEO bridges.")

subprocess.run(
    [
        node_exe,
        "-e",
        bridge_install_script,
        str(root / "bridge.js"),
        str(root),
        str(vscode_ext_dir),
    ],
    env=node_env,
    check=True,
)

# 4. Stamp local bundle version/builtAt so older store hub_release records never overwrite a fresh local install
stamp_path = pathlib.Path.home() / ".claude" / ".theo-hub-bundle-stamp.json"
try:
    stamp_path.parent.mkdir(parents=True, exist_ok=True)
    now_ms = int(time.time() * 1000)
    stamp_obj = {
        "version": version,
        "builtAt": now_ms,
        "sha256": "local-install",
        "appliedAt": now_ms,
    }
    stamp_path.write_text(
        json.dumps(stamp_obj, indent=2),
        encoding="utf-8",
    )
    for dst_root in ext_targets:
        if dst_root.exists():
            (dst_root / ".theo-bundle-applied.json").write_text(
                json.dumps(stamp_obj, indent=2),
                encoding="utf-8",
            )
    print(f"[OK] Updated bundle anti-rollback stamp at {stamp_path} (builtAt={now_ms})")
except Exception as e:
    print(f"[WARN] Bundle stamp update skipped: {e}")

# 5. Ensure permanent THEO Relay Keepalive daemon + Scheduled Task / Startup launcher are running with latest code
keepalive_ps1 = root / "scripts" / "relay_keepalive_start.ps1"
if keepalive_ps1.exists():
    try:
        res = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-WindowStyle",
                "Hidden",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(keepalive_ps1),
                "-Restart",
            ],
            capture_output=True,
            text=True,
            timeout=20,
        )
        if res.stdout.strip():
            print(f"[OK] {res.stdout.strip()}")
    except Exception as e:
        print(f"[WARN] Keepalive launcher check skipped: {e}")

