const vscode = require('vscode');
const { execFile } = require('child_process');

// Dedupe memory lives on globalThis, not in this module: a hot swap evicts and re-requires desktop-notify
// (and hub.js binds notifySessionTransition at load), and a module-level Map would come back empty, so a
// finished-agent toast could repeat right after the swap.
const RECENT_NOTIFS_KEY = Symbol.for('bhfirms.theoHub.desktopNotify.recentTransitionNotifs');
if (!(globalThis[RECENT_NOTIFS_KEY] instanceof Map)) {
  globalThis[RECENT_NOTIFS_KEY] = new Map();
}
const recentTransitionNotifs = globalThis[RECENT_NOTIFS_KEY];

function playNotificationTone() {
  if (process.platform === 'win32') {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', '[System.Media.SystemSounds]::Asterisk.Play()'],
      { windowsHide: true, timeout: 2500 },
      () => {}
    );
  }
}

// Name the agent that actually ran the session (same labels as the phone push in remote.js).
// A session with no recognisable provider is announced as THEO, never as a guessed agent.
function sessionAgentLabel(thread) {
  const provider = String(thread?.provider || '').trim().toLowerCase();
  if (provider === 'claude') {
    return 'Claude Code';
  }
  if (provider === 'antigravity') {
    return 'Antigravity';
  }
  if (provider === 'codex') {
    return 'Codex';
  }
  return 'THEO';
}

function buildTransitionMessage(thread, state, preferences) {
  const agent = sessionAgentLabel(thread);
  const title = thread?.title || 'Untitled session';
  if (state === 'waiting' && preferences?.notifyOnWaiting !== false) {
    return `${agent} needs input in "${title}"`;
  }
  if (state === 'completed' && preferences?.notifyOnComplete !== false) {
    return `${agent} finished in "${title}"`;
  }
  if (state === 'errored' && preferences?.notifyOnComplete !== false) {
    return `${agent} stopped with an error in "${title}"`;
  }
  return '';
}

async function notifySessionTransition({ thread, state, preferences, isActiveTab, onOpenThread }) {
  if (!thread || !preferences) {
    return;
  }
  if (preferences.onlyNotifyBackground && isActiveTab && vscode.window.state.focused) {
    return;
  }

  const now = Date.now();
  for (const [k, ts] of recentTransitionNotifs.entries()) {
    if (now - ts > 600000) {
      recentTransitionNotifs.delete(k);
    }
  }
  const dedupeKey = `${thread.id || thread.title}::${state}`;
  const prevTs = recentTransitionNotifs.get(dedupeKey) || 0;
  if (prevTs > 0 && now - prevTs < 90000) {
    return;
  }
  recentTransitionNotifs.set(dedupeKey, now);

  const message = buildTransitionMessage(thread, state, preferences);

  if (!message) {
    return;
  }

  if (preferences.notifySound !== false) {
    playNotificationTone();
  }

  const action = await vscode.window.showInformationMessage(message, 'Open Session');
  if (action === 'Open Session' && typeof onOpenThread === 'function') {
    await onOpenThread(thread.id);
  }
}

module.exports = {
  notifySessionTransition,
  sessionAgentLabel,
  buildTransitionMessage
};

