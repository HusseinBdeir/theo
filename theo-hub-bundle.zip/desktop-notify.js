const vscode = require('vscode');
const { execFile } = require('child_process');

const recentTransitionNotifs = new Map();

function playNotificationTone() {
  if (process.platform === 'win32') {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', '[System.Media.SystemSounds]::Asterisk.Play()'],
      { windowsHide: true, timeout: 2500 },
      () => {}
    );
  }
}

async function notifySessionTransition({ thread, state, preferences, isActiveTab, onOpenThread }) {
  if (!thread || !preferences) {
    return;
  }
  if (preferences.onlyNotifyBackground && isActiveTab && vscode.window.state.focused) {
    return;
  }

  const now = Date.now();
  for (const [k, ts] of recentTransitionNotifs.entries()) {
    if (now - ts > 600000) {
      recentTransitionNotifs.delete(k);
    }
  }
  const dedupeKey = `${thread.id || thread.title}::${state}`;
  const prevTs = recentTransitionNotifs.get(dedupeKey) || 0;
  if (prevTs > 0 && now - prevTs < 90000) {
    return;
  }
  recentTransitionNotifs.set(dedupeKey, now);

  let message = '';
  if (state === 'waiting' && preferences.notifyOnWaiting !== false) {
    message = `Antigravity needs input in "${thread.title}"`;
  } else if (state === 'completed' && preferences.notifyOnComplete !== false) {
    message = `Antigravity finished in "${thread.title}"`;
  } else if (state === 'errored' && preferences.notifyOnComplete !== false) {
    message = `Antigravity stopped with an error in "${thread.title}"`;
  }

  if (!message) {
    return;
  }

  if (preferences.notifySound !== false) {
    playNotificationTone();
  }

  const action = await vscode.window.showInformationMessage(message, 'Open Session');
  if (action === 'Open Session' && typeof onOpenThread === 'function') {
    await onOpenThread(thread.id);
  }
}

module.exports = {
  notifySessionTransition
};

