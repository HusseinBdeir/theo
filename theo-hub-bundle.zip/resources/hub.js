(() => {
  'use strict';
  const vscode = acquireVsCodeApi();
  const saved = vscode.getState() || {};
  const $ = id => document.getElementById(id);
  const send = message => vscode.postMessage(message);
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon = (paths, cls = 'icon') => `<svg class="${cls}" viewBox="0 0 16 16" aria-hidden="true">${paths}</svg>`;
  const icons = {
    chevron: icon('<path d="M6 4l4 4-4 4"/>', 'chevron'),
    check: icon('<path d="M3.5 8.5l3 3 6-7"/>'),
    rename: icon('<path d="M3 13l.6-2.6 7-7a1.2 1.2 0 0 1 1.7 0l.3.3a1.2 1.2 0 0 1 0 1.7l-7 7z"/>'),
    archive: icon('<rect x="2.5" y="3" width="11" height="3" rx=".8"/><path d="M3.5 6v6a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V6M6.5 9h3"/>'),
    unarchive: icon('<rect x="2.5" y="3" width="11" height="3" rx=".8"/><path d="M3.5 6v6a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V6M8 11.5v-3M6.5 9.8L8 8.3l1.5 1.5"/>'),
    stop: icon('<rect x="4" y="4" width="8" height="8" rx="1.6" fill="currentColor" stroke="none"/>'),
    close: icon('<path d="M4 4l8 8M12 4l-8 8"/>'),
    plus: icon('<path d="M8 3.5v9M3.5 8h9"/>'),
    more: icon('<circle cx="3.5" cy="8" r="1.1" fill="currentColor" stroke="none"/><circle cx="8" cy="8" r="1.1" fill="currentColor" stroke="none"/><circle cx="12.5" cy="8" r="1.1" fill="currentColor" stroke="none"/>'),
    terminal: icon('<rect x="2" y="2.8" width="12" height="10.4" rx="1.6"/><path d="M4.8 6.3L7 8l-2.2 1.7M8.3 10h2.8"/>'),
    subagent: icon('<circle cx="8" cy="4.2" r="1.8"/><circle cx="4.2" cy="11.8" r="1.7"/><circle cx="11.8" cy="11.8" r="1.7"/><path d="M7 5.8L5 10.2M9 5.8l2 4.4"/>'),
    timer: icon('<circle cx="8" cy="8.5" r="5.2"/><path d="M8 5.8v2.9l2 1.3M6.3 2h3.4"/>'),
    question: icon('<circle cx="8" cy="8" r="6"/><path d="M6.4 6.3a1.7 1.7 0 1 1 2.4 1.5c-.6.3-.8.6-.8 1.2M8 11.4h.01"/>'),
    arrowUp: icon('<path d="M8 12.5v-9M4.5 7L8 3.5 11.5 7"/>'),
    arrowDown: icon('<path d="M8 3.5v9M4.5 9L8 12.5 11.5 9"/>'),
  };

  const providerIcons = {
    antigravity: `<svg viewBox="6 8 100 100" aria-hidden="true"><path d="M89.7 93.7C94.4 97.2 101.4 94.9 94.9 88.4C75.7 69.8 79.8 18.4 55.9 18.4C31.9 18.4 36 69.8 16.8 88.4C9.8 95.4 17.4 97.2 22 93.7C40.1 81.4 38.9 59.9 55.9 59.9C72.8 59.9 71.6 81.4 89.7 93.7Z" fill="#3186FF"/></svg>`,
    claude: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.709 15.955l4.72-2.647.08-.23-.08-.128H9.2l-.79-.048-2.698-.073-2.339-.097-2.266-.122-.571-.121L0 11.784l.055-.352.48-.321.686.06 1.52.103 2.278.158 1.652.097 2.449.255h.389l.055-.157-.134-.098-.103-.097-2.358-1.596-2.552-1.688-1.336-.972-.724-.491-.364-.462-.158-1.008.656-.722.881.06.225.061.893.686 1.908 1.476 2.491 1.833.365.304.145-.103.019-.073-.164-.274-1.355-2.446-1.446-2.49-.644-1.032-.17-.619a2.97 2.97 0 01-.104-.729L6.283.134 6.696 0l.996.134.42.364.62 1.414 1.002 2.229 1.555 3.03.456.898.243.832.091.255h.158V9.01l.128-1.706.237-2.095.23-2.695.08-.76.376-.91.747-.492.584.28.48.685-.067.444-.286 1.851-.559 2.903-.364 1.942h.212l.243-.242.985-1.306 1.652-2.064.73-.82.85-.904.547-.431h1.033l.76 1.129-.34 1.166-1.064 1.347-.881 1.142-1.264 1.7-.79 1.36.073.11.188-.02 2.856-.606 1.543-.28 1.841-.315.833.388.091.395-.328.807-1.969.486-2.309.462-3.439.813-.042.03.049.061 1.549.146.662.036h1.622l3.02.225.79.522.474.638-.079.485-1.215.62-1.64-.389-3.829-.91-1.312-.329h-.182v.11l1.093 1.068 2.006 1.81 2.509 2.33.127.578-.322.455-.34-.049-2.205-1.657-.851-.747-1.926-1.62h-.128v.17l.444.649 2.345 3.521.122 1.08-.17.353-.608.213-.668-.122-1.374-1.925-1.415-2.167-1.143-1.943-.14.08-.674 7.254-.316.37-.729.28-.607-.461-.322-.747.322-1.476.389-1.924.315-1.53.286-1.9.17-.632-.012-.042-.14.018-1.434 1.967-2.18 2.945-1.726 1.845-.414.164-.717-.37.067-.662.401-.589 2.388-3.036 1.44-1.882.93-1.086-.006-.158h-.055L4.132 18.56l-1.13.146-.487-.456.061-.746.231-.243 1.908-1.312-.006.006z" fill="#D97757" fill-rule="nonzero"/></svg>`
  };

  if ($('hdr-agy-icon')) $('hdr-agy-icon').innerHTML = providerIcons.antigravity;
  if ($('hdr-claude-icon')) $('hdr-claude-icon').innerHTML = providerIcons.claude;

  const statusLabels = {needs_input: 'Needs input', working: 'Running now', completed: 'Completed'};
  const tabLabels = {open: 'Open', closed: 'Closed'};

  let state = null;
  let search = saved.search || '';
  let period = saved.period === 'week' ? 'week' : 'today';
  let activityProvider = ['all', 'antigravity', 'claude'].includes(saved.activityProvider) ? saved.activityProvider : 'all';
  let collapsed = {
    usage: Boolean(saved.collapsed?.usage),
    antigravityUsage: Boolean(saved.collapsed?.antigravityUsage),
    claudeUsage: Boolean(saved.collapsed?.claudeUsage),
    accounts: saved.collapsed?.accounts && typeof saved.collapsed.accounts === 'object' ? {...saved.collapsed.accounts} : {},
    questions: Boolean(saved.collapsed?.questions),
    bgTasks: Boolean(saved.collapsed?.bgTasks),
    sessions: Boolean(saved.collapsed?.sessions),
    ungrouped: Boolean(saved.collapsed?.ungrouped),
    archived: saved.collapsed?.archived !== undefined ? Boolean(saved.collapsed.archived) : true
  };
  let filter = {statuses: [], tabStates: [], activeOnly: false};
  let providerFilter = 'all';
  let details = false, renaming = null, menu = null;
  let pinnedBgSessionId = '', bgInspector = null;
  const questionDrafts = new Map();
  let addTrayOpen = false, addTrayProvider = 'antigravity', addTrayLabel = '', addTrayEmail = '', addTraySwitch = true;
  let switchingAccountId = '', editingAccountId = '';

  const rendered = new WeakMap();
  const setHTML = (element, html) => {
    if (!element || rendered.get(element) === html) return false;
    element.innerHTML = html;
    rendered.set(element, html);
    return true;
  };
  const persist = () => vscode.setState({search, period, activityProvider, collapsed});
  const compact = n => new Intl.NumberFormat(undefined, {notation: 'compact', maximumFractionDigits: 1}).format(n || 0);
  const exact = n => new Intl.NumberFormat().format(n || 0);
  const ago = at => {
    const minutes = Math.floor(Math.max(0, Date.now() - at) / 60000), hours = Math.floor(minutes / 60), days = Math.floor(hours / 24);
    return days >= 365 ? `${Math.floor(days / 365)}y` : days >= 30 ? `${Math.floor(days / 30)}mo` : days ? `${days}d` : hours ? `${hours}h` : minutes ? `${minutes}m` : 'now';
  };
  const until = at => {
    const minutes = Math.floor((at - Date.now()) / 60000), hours = Math.floor(minutes / 60);
    return minutes <= 0 ? 'soon' : minutes < 60 ? `in ${minutes}m` : hours < 24 ? `in ${hours}h` : `in ${Math.floor(hours / 24)}d`;
  };
  const windowLabel = minutes => minutes === 300 ? 'Session (5hr)' : minutes === 10080 ? 'Weekly (7 day)'
    : !minutes ? 'Usage window' : minutes % 1440 === 0 ? `${minutes / 1440} day window` : minutes % 60 === 0 ? `${minutes / 60}hr window` : `${minutes}min window`;
  const rowByKey = key => state?.rows.find(r => r.key === key);
  const filtering = () => filter.activeOnly || filter.statuses.length > 0 || filter.tabStates.length > 0;
  const isActive = r => r.unread || r.category !== 'completed';
  const getProviderIcon = prov => providerIcons[prov === 'claude' ? 'claude' : 'antigravity'];
  const getProviderLabel = prov => prov === 'claude' ? 'Claude Code' : 'Antigravity';

  // ---- Account & usage -------------------------------------------------
  let lastTriggeredResetAt = 0;
  function renderUsageBarsHTML(u, msg, providerKey, withAllLimits) {
    const list = withAllLimits && Array.isArray(u?.allLimits) && u.allLimits.length ? u.allLimits : u?.limits || [];
    if (!u || !list.length) {
      return `<p class="unavailable">${escape(msg || 'Allowance unavailable.')}</p>`;
    }
    const nowMs = Date.now();
    return `<div class="usage-bars">${list.map(l => {
      const label = l.label || windowLabel(l.minutes);
      const passed = Boolean(l.expired || (l.reset && l.reset <= nowMs));
      if (l.reset && l.reset <= nowMs && l.reset > lastTriggeredResetAt) {
        lastTriggeredResetAt = l.reset;
        setTimeout(() => send({action: 'refresh'}), 250);
      }
      const known = passed || l.pct != null;
      const pct = passed ? 0 : known ? Math.min(100, Math.max(0, l.pct)) : 0;
      const resetLine = passed ? 'Window idle' : l.resetText ? escape(l.resetText) : l.reset ? 'Resets ' + until(l.reset) : '';
      const fillCls = pct >= 90 ? ' critical' : pct >= 78 ? ' high' : providerKey === 'claude' ? ' claude' : '';
      return `<div class="usage-bar"><div class="usage-bar-header"><span class="usage-bar-label">${escape(label)}</span><span class="usage-bar-meta">${resetLine ? `<span class="reset-text">${resetLine}</span>` : ''}<span class="usage-percent">${known ? Math.floor(pct) + '%' : '—'}</span></span></div>`
        + `<div class="usage-track"${known ? ` role="meter" aria-label="${escape(label)} used" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.floor(pct)}"` : ''}><div class="usage-fill${fillCls}" style="width:${pct}%"></div></div></div>`;
    }).join('')}</div>`;
  }

  function getProviderAccountsList(provInfo, key) {
    if (Array.isArray(provInfo?.accounts) && provInfo.accounts.length) {
      return provInfo.accounts;
    }
    if (!provInfo) return [];
    const sectionKey = key === 'claude' ? 'claudeUsage' : 'antigravityUsage';
    const email = provInfo.account?.email || '';
    return [{
      id: email ? `${key}:${email.toLowerCase()}` : `${key}:default`,
      provider: key,
      label: provInfo.label || getProviderLabel(key),
      nickname: provInfo.account?.nickname || '',
      active: true,
      collapsed: Boolean(collapsed[sectionKey]),
      account: provInfo.account || {},
      usage: provInfo.usage,
      usageMessage: provInfo.usageMessage
    }];
  }

  function findAccountModel(accountId, provHint) {
    const provs = state?.providers || {};
    const all = [
      ...getProviderAccountsList(provs.antigravity, 'antigravity'),
      ...getProviderAccountsList(provs.claude, 'claude')
    ];
    return all.find(a => a.id === accountId && (!provHint || a.provider === provHint)) || all.find(a => a.id === accountId) || null;
  }

  function renderAddAccountTray(forceFocus = false) {
    const tray = $('add-account-tray');
    const addBtn = $('add-account-btn');
    if (addBtn) addBtn.setAttribute('aria-expanded', String(addTrayOpen));
    if (!tray) return;
    tray.hidden = !addTrayOpen;
    tray.classList.toggle('claude-mode', addTrayProvider === 'claude');
    if (!addTrayOpen) {
      setHTML(tray, '');
      return;
    }
    const isClaude = addTrayProvider === 'claude';
    const provTitle = isClaude ? 'Claude Code' : 'Antigravity';
    const provHasAcct = hasSignedInProvider(addTrayProvider);
    const trayHeading = provHasAcct ? 'Add another account' : `Sign in to ${provTitle}`;
    const traySub = provHasAcct
      ? 'Sign in a second or friend&#39;s account — your existing accounts stay logged in.'
      : `Complete ${provTitle} sign-in in your browser — your existing accounts stay untouched.`;
    setHTML(tray,
      `<div class="add-tray-top"><span class="add-tray-title">${escape(trayHeading)}</span><button type="button" class="account-menu-btn" data-action="closeAddAccount" title="Close" aria-label="Close add account">${icons.close}</button></div>`
      + `<p class="add-tray-sub">${traySub}</p>`
      + `<div class="add-prov-seg" role="group" aria-label="Select provider">`
      + `<button type="button" class="add-prov-opt agy" data-action="selectAddProvider" data-provider="antigravity" aria-pressed="${!isClaude}"><span class="provider-icon">${providerIcons.antigravity}</span><span>Antigravity</span></button>`
      + `<button type="button" class="add-prov-opt claude" data-action="selectAddProvider" data-provider="claude" aria-pressed="${isClaude}"><span class="provider-icon">${providerIcons.claude}</span><span>Claude Code</span></button>`
      + `</div>`
      + `<div class="add-tray-fields">`
      + `<input id="add-account-label" class="add-tray-input" type="text" maxlength="36" placeholder="Nickname / label (optional — e.g. Friend, Work)" value="${escape(addTrayLabel)}" autocomplete="off">`
      + (isClaude ? `<input id="add-account-email" class="add-tray-input" type="email" maxlength="80" placeholder="Email hint (optional — e.g. friend@gmail.com)" value="${escape(addTrayEmail)}" autocomplete="off">` : '')
      + (provHasAcct ? `<label class="add-tray-check"><input id="add-account-switch" type="checkbox" ${addTraySwitch ? 'checked' : ''}><span>Switch to this account once signed in</span></label>` : '')
      + `</div>`
      + `<div class="add-tray-actions">`
      + `<button type="button" class="ghost sm" data-action="closeAddAccount">Cancel</button>`
      + `<button type="button" class="btn-primary-add${isClaude ? ' claude' : ''}" data-action="submitAddAccount">Sign in ${escape(provTitle)} →</button>`
      + `</div>`
    );
    const lblInput = $('add-account-label');
    const emlInput = $('add-account-email');
    const swInput = $('add-account-switch');
    if (lblInput) {
      lblInput.oninput = e => { addTrayLabel = e.target.value; };
      lblInput.onkeydown = e => {
        if (e.key === 'Enter') { e.preventDefault(); submitAddAccountForm(); }
        else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeAddAccountTray(); }
      };
      if (forceFocus) setTimeout(() => lblInput.focus(), 15);
    }
    if (emlInput) {
      emlInput.oninput = e => { addTrayEmail = e.target.value; };
      emlInput.onkeydown = e => {
        if (e.key === 'Enter') { e.preventDefault(); submitAddAccountForm(); }
        else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeAddAccountTray(); }
      };
    }
    if (swInput) {
      swInput.onchange = e => { addTraySwitch = Boolean(e.target.checked); };
    }
  }

  function openAddAccountTray(defaultProv) {
    if (defaultProv === 'claude' || defaultProv === 'antigravity') {
      addTrayProvider = defaultProv;
    }
    if (collapsed.usage) {
      collapsed.usage = false;
      persist();
      send({action: 'collapse', section: 'usage', value: false});
      renderSections();
    }
    addTrayOpen = true;
    $('usage-body').hidden = false;
    renderAddAccountTray(true);
  }

  function closeAddAccountTray() {
    addTrayOpen = false;
    renderAddAccountTray(false);
  }

  function submitAddAccountForm() {
    const label = ($('add-account-label')?.value ?? addTrayLabel).trim();
    const emailHint = ($('add-account-email')?.value ?? addTrayEmail).trim();
    const switchOnComplete = $('add-account-switch') ? Boolean($('add-account-switch').checked) : addTraySwitch;
    const provider = addTrayProvider === 'claude' ? 'claude' : 'antigravity';
    addTrayLabel = '';
    addTrayEmail = '';
    addTrayOpen = false;
    renderAddAccountTray(false);
    send({action: 'accountAdd', provider, label, emailHint, switchOnComplete});
  }

  function triggerAccountSwitch(accountId, provider) {
    if (!accountId) return;
    switchingAccountId = accountId;
    renderUsage();
    renderDetails();
    send({action: 'accountSwitch', accountId, provider});
  }

  function openInlineAccountLabel(accountId) {
    closeMenu();
    if (collapsed.accounts?.[accountId]) {
      collapsed.accounts[accountId] = false;
      persist();
      send({action: 'accountCollapse', accountId, value: false});
    }
    editingAccountId = accountId;
    renderUsage();
    setTimeout(() => {
      const inp = document.querySelector('.account-inline-input');
      if (inp) {
        inp.focus();
        inp.select();
      }
    }, 20);
  }

  function commitInlineAccountLabel(save) {
    if (!editingAccountId) return;
    const wrap = document.querySelector('.account-inline-edit');
    const inp = wrap?.querySelector('.account-inline-input');
    const accountId = editingAccountId;
    const provider = wrap?.dataset.provider || (accountId.startsWith('claude:') ? 'claude' : 'antigravity');
    const nextVal = inp ? inp.value.trim() : '';
    editingAccountId = '';
    if (save) {
      const m = findAccountModel(accountId, provider);
      if (m) {
        m.nickname = nextVal;
        if (m.account) m.account.nickname = nextVal;
      }
      send({action: 'accountLabel', accountId, provider, label: nextVal, prompt: false});
    }
    renderUsage();
    renderDetails();
  }

  function renderPendingLoginBanner() {
    const slot = $('pending-login-slot');
    if (!slot) return;
    const p = state?.pendingAccountLogin;
    if (!p || !p.active) {
      setHTML(slot, '');
      return;
    }
    const isClaude = p.provider === 'claude';
    const provLabel = getProviderLabel(p.provider);
    const titleText = p.awaitingVerification
      ? `Verify Google Account${p.label ? ` (${escape(p.label)})` : ''}…`
      : `Signing in ${escape(provLabel)}${p.label ? ` (${escape(p.label)})` : ''}…`;
    const actionButtons = p.awaitingVerification
      ? `<button type="button" class="button sm" data-action="accountContinueVerification">✓ Verified — Continue</button>`
        + `<button type="button" class="button sm" data-action="accountOpenAuthUrl">Open Verify Link</button>`
        + `<button type="button" class="ghost sm" data-action="accountCancelAdd">Cancel</button>`
      : (p.authUrl ? `<button type="button" class="button sm" data-action="accountOpenAuthUrl">Open Link</button>` : '')
        + `<button type="button" class="button sm" data-action="accountFocusTerminal">Show Terminal</button>`
        + `<button type="button" class="ghost sm" data-action="accountCancelAdd">Cancel</button>`;
    setHTML(slot,
      `<div class="pending-login-banner${isClaude ? ' claude' : ''}">`
      + `<div class="pending-login-top"><span class="pulse-dot"></span><span>${titleText}</span></div>`
      + `<div class="reset-text" style="opacity:.85">${escape(p.message || 'Complete sign-in in your browser. Existing accounts stay logged in.')}</div>`
      + `<div class="button-row" style="margin-top:2px;flex-wrap:wrap">`
      + actionButtons
      + `</div></div>`
    );
  }

  function isSignedInAccountCard(acct) {
    const a = acct?.account;
    if (!a || a.signedOut) return false;
    return Boolean(a.available || a.email);
  }

  function hasSignedInProvider(provKey) {
    if (!state) return true;
    const prov = provKey === 'claude' ? 'claude' : 'antigravity';
    return getProviderAccountsList(state?.providers?.[prov], prov).some(isSignedInAccountCard);
  }

  function syncNewSessionControls() {
    const hasAgy = hasSignedInProvider('antigravity');
    const hasClaude = hasSignedInProvider('claude');
    const row = $('new-session-row');
    const agyBtn = $('new-session-agy-btn') || row?.querySelector('[data-provider="antigravity"]');
    const claudeBtn = $('new-session-claude-btn') || row?.querySelector('[data-provider="claude"]');
    const divider = $('new-session-divider') || row?.querySelector('.header-divider');
    if (agyBtn) agyBtn.hidden = !hasAgy;
    if (claudeBtn) claudeBtn.hidden = !hasClaude;
    if (divider) divider.hidden = !(hasAgy && hasClaude);
    if (row) row.hidden = !(hasAgy || hasClaude);
  }

  function getOrderedAccountCards(forDetails = false) {
    const provs = state?.providers || {};
    const agyList = getProviderAccountsList(provs.antigravity, 'antigravity');
    const claudeList = getProviderAccountsList(provs.claude, 'claude');
    const agySignedIn = agyList.filter(isSignedInAccountCard);
    const claudeSignedIn = claudeList.filter(isSignedInAccountCard);
    const totalSignedIn = agySignedIn.length + claudeSignedIn.length;
    const listAgy = forDetails ? agyList : (totalSignedIn > 0 ? agySignedIn : agyList);
    const listClaude = forDetails ? claudeList : (totalSignedIn > 0 ? claudeSignedIn : claudeList);
    const combined = [...listAgy, ...listClaude];
    const orderArr = Array.isArray(state?.accountOrder) ? state.accountOrder : [];
    const orderIndex = new Map();
    orderArr.forEach((id, idx) => {
      if (id && !orderIndex.has(id)) orderIndex.set(id, idx);
    });
    const ordered = combined
      .map((acct, fallbackIdx) => ({acct, fallbackIdx}))
      .sort((a, b) => {
        const ia = orderIndex.has(a.acct?.id)
          ? orderIndex.get(a.acct.id)
          : Number.isFinite(Number(a.acct?.sortOrder))
            ? 1000 + Number(a.acct.sortOrder)
            : 2000 + a.fallbackIdx;
        const ib = orderIndex.has(b.acct?.id)
          ? orderIndex.get(b.acct.id)
          : Number.isFinite(Number(b.acct?.sortOrder))
            ? 1000 + Number(b.acct.sortOrder)
            : 2000 + b.fallbackIdx;
        return ia - ib;
      })
      .map(x => x.acct);
    return {
      ordered,
      totalSignedIn,
      sameProvCounts: {
        antigravity: listAgy.length,
        claude: listClaude.length
      }
    };
  }

  function moveAccountCard(accountId, opts = {}) {
    if (!state || !accountId) return;
    const {ordered} = getOrderedAccountCards(false);
    const ids = ordered.map(a => a.id).filter(Boolean);
    const fromIdx = ids.indexOf(accountId);
    if (fromIdx === -1) return;
    let nextIds = [...ids];
    if (opts.targetAccountId && opts.targetAccountId !== accountId) {
      nextIds.splice(fromIdx, 1);
      const targetIdx = nextIds.indexOf(opts.targetAccountId);
      if (targetIdx === -1) return;
      const insertAt = opts.position === 'after' ? targetIdx + 1 : targetIdx;
      nextIds.splice(insertAt, 0, accountId);
    } else {
      const delta = opts.direction === 'up' ? -1 : opts.direction === 'down' ? 1 : 0;
      const toIdx = fromIdx + delta;
      if (!delta || toIdx < 0 || toIdx >= nextIds.length) return;
      const [moved] = nextIds.splice(fromIdx, 1);
      nextIds.splice(toIdx, 0, moved);
    }
    const existingExtra = (Array.isArray(state.accountOrder) ? state.accountOrder : []).filter(
      id => id && !nextIds.includes(id)
    );
    const fullOrder = [...nextIds, ...existingExtra];
    state.accountOrder = fullOrder;
    for (const provKey of ['antigravity', 'claude']) {
      const provAccounts = state.providers?.[provKey]?.accounts;
      if (Array.isArray(provAccounts)) {
        provAccounts.sort((a, b) => {
          const ia = fullOrder.indexOf(a?.id);
          const ib = fullOrder.indexOf(b?.id);
          return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
        });
        provAccounts.forEach((item, idx) => {
          if (item) item.sortOrder = idx;
        });
      }
    }
    renderUsage();
    if (details) renderDetails();
    send({
      action: 'accountReorder',
      accountId,
      provider: opts.provider || (accountId.startsWith('claude:') ? 'claude' : 'antigravity'),
      direction: opts.direction || '',
      targetAccountId: opts.targetAccountId || '',
      position: opts.position || '',
      orderedIds: fullOrder
    });
  }

  function renderAccountUsageCard(acct, sameProvCount, detailed, orderCtx = null) {
    if (!acct) return '';
    const key = acct.provider === 'claude' ? 'claude' : 'antigravity';
    const acctId = acct.id || `${key}:default`;
    const provLabel = acct.label || getProviderLabel(key);
    if (!isSignedInAccountCard(acct)) {
      const signedOutHeader = `<div class="provider-card-header"><div class="provider-title-wrap"><span class="provider-icon">${getProviderIcon(key)}</span><span class="provider-title-text">${escape(provLabel)}</span></div><div class="provider-card-actions"><span class="provider-plan-pill">Signed out</span></div></div>`;
      const signInBtn = `<div class="button-row" style="margin-top:6px"><button type="button" class="button sm" data-action="openAddFromDetails" data-provider="${key}">+ Sign in ${escape(provLabel)}</button></div>`;
      return `<div class="provider-card is-secondary" data-account-card="${escape(acctId)}">${signedOutHeader}${signInBtn}</div>`;
    }
    const isCardCollapsed = detailed
      ? false
      : typeof collapsed.accounts?.[acctId] === 'boolean'
        ? Boolean(collapsed.accounts[acctId])
        : Boolean(acct.collapsed);
    const a = acct.account || {};
    const u = acct.usage;
    const isActiveAcct = acct.active !== false;
    const isSwitching = switchingAccountId === acctId;
    const isEditingNick = !detailed && editingAccountId === acctId;
    const nick = String(acct.nickname || a.nickname || '').trim();
    const emailText = a.available ? (a.email || a.name || '') : (a.signedOut ? 'Not signed in' : a.name || '');
    const emailShort = emailText.includes('@') ? emailText.split('@')[0] : emailText;
    const planText = a.plan || (key === 'claude' ? 'Claude Code' : 'Google AI');
    const multi = sameProvCount > 1;
    const cardIndex = typeof orderCtx?.index === 'number' ? orderCtx.index : 0;
    const totalCards = typeof orderCtx?.totalCards === 'number' ? orderCtx.totalCards : sameProvCount;
    const canReorder = totalCards > 1;
    const canMoveUp = canReorder && cardIndex > 0;
    const canMoveDown = canReorder && cardIndex < totalCards - 1;

    const headerNickBadge = !detailed
      ? (nick
          ? `<span class="account-nick-pill${key === 'claude' ? ' claude' : ''}" title="${escape(emailText ? `${nick} · ${emailText}` : nick)}">${escape(nick)}</span>`
          : multi && emailShort
            ? `<span class="account-nick-pill${key === 'claude' ? ' claude' : ''}" title="${escape(emailText)}">${escape(emailShort)}</span>`
            : '')
      : '';

    let rightControls = '';
    if (!isActiveAcct) {
      rightControls += `<button type="button" class="account-switch-btn" data-action="accountSwitch" data-account-id="${escape(acctId)}" data-provider="${key}" ${isSwitching ? 'disabled' : ''} title="Switch active ${escape(provLabel)} account to ${escape(emailText || provLabel)} (keeps all other accounts signed in)">${isSwitching ? 'Switching…' : '⇄ Use'}</button>`;
    } else if (multi || detailed) {
      const pillLabel = 'Active';
      const pillTitle = `Currently active for ${provLabel} sessions`;
      rightControls += `<span class="account-active-pill" title="${escape(pillTitle)}"><span class="account-active-dot"></span>${pillLabel}</span>`;
    } else {
      rightControls += `<span class="provider-plan-pill" title="${escape(emailText ? `${emailText} · ${planText}` : planText)}">${escape(planText)}</span>`;
    }
    if (canReorder && (canMoveUp || canMoveDown)) {
      const dualCls = canMoveUp && canMoveDown ? ' dual' : '';
      rightControls += `<span class="account-move-group${dualCls}" role="group" aria-label="Reorder account">`
        + (canMoveUp ? `<button type="button" class="account-move-btn" data-action="accountMove" data-dir="up" data-account-id="${escape(acctId)}" data-provider="${key}" title="Move account up (or drag card)" aria-label="Move account up">${icons.arrowUp}</button>` : '')
        + (canMoveDown ? `<button type="button" class="account-move-btn" data-action="accountMove" data-dir="down" data-account-id="${escape(acctId)}" data-provider="${key}" title="Move account down (or drag card)" aria-label="Move account down">${icons.arrowDown}</button>` : '')
        + `</span>`;
    }
    if (!detailed) {
      rightControls += `<button type="button" class="account-menu-btn" data-account-menu="${escape(acctId)}" data-provider="${key}" title="Account options" aria-label="Account options" aria-haspopup="menu" aria-expanded="false">${icons.more}</button>`;
    }

    const headerInner = `<div class="provider-title-wrap">${detailed ? '' : icons.chevron}<span class="provider-icon">${getProviderIcon(key)}</span><span class="provider-title-text">${escape(provLabel)}</span>${headerNickBadge}</div>`;
    const headerRow = detailed
      ? `<div class="provider-card-header">${headerInner}<div class="provider-card-actions">${rightControls}</div></div>`
      : `<div class="provider-card-header"><button type="button" class="provider-card-toggle" data-action="accountCollapse" data-account-id="${escape(acctId)}" data-provider="${key}" aria-expanded="${!isCardCollapsed}" title="${isCardCollapsed ? 'Show' : 'Hide'} ${escape(emailText || provLabel)} usage">${headerInner}</button><div class="provider-card-actions">${rightControls}</div></div>`;

    const dragAttrs = !detailed && canReorder && !isEditingNick
      ? ` draggable="true" data-provider="${key}"`
      : ` data-provider="${key}"`;

    if (isCardCollapsed) {
      return `<div class="provider-card collapsed${isActiveAcct ? ' is-active' : ' is-secondary'}${multi ? ' multi' : ''}" data-account-card="${escape(acctId)}"${dragAttrs}>${headerRow}</div>`;
    }

    if (detailed) {
      const detailActions =
        `<div class="button-row" style="margin-top:4px">`
        + (!isActiveAcct ? `<button type="button" class="button sm" data-action="accountSwitch" data-account-id="${escape(acctId)}" data-provider="${key}">${isSwitching ? 'Switching…' : '⇄ Switch to this Account'}</button>` : '')
        + `<button type="button" class="button sm" data-action="accountNewSession" data-account-id="${escape(acctId)}" data-provider="${key}">+ New Session</button>`
        + `<button type="button" class="button sm" data-action="accountPromptLabel" data-account-id="${escape(acctId)}" data-provider="${key}">${nick ? 'Edit Label' : 'Set Label'}</button>`
        + `<button type="button" class="button sm" data-action="accountRemove" data-account-id="${escape(acctId)}" data-provider="${key}">${multi ? 'Disconnect' : 'Sign out'}</button>`
        + `<button type="button" class="link-button" style="align-self:center;margin-left:auto" data-action="${key === 'claude' ? 'claudeSettings' : 'settings'}">${key === 'claude' ? 'Claude Settings' : 'Antigravity Settings'}</button>`
        + `</div>`;
      return `<div class="provider-card${isActiveAcct ? ' is-active' : ' is-secondary'}${multi ? ' multi' : ''}" data-account-card="${escape(acctId)}">`
        + headerRow
        + `<div class="account-rows">`
        + `<div class="account-row"><span>Account</span><span>${escape(emailText || 'Not signed in')}</span></div>`
        + (nick ? `<div class="account-row"><span>Label</span><span>${escape(nick)}</span></div>` : '')
        + `<div class="account-row"><span>Plan</span><span>${escape(planText)}</span></div>`
        + `<div class="account-row"><span>Session routing</span><span>${isActiveAcct ? 'Active (drives new sessions)' : 'Signed in · Standby'}</span></div>`
        + `</div>`
        + renderUsageBarsHTML(u, acct.usageMessage, key, true)
        + detailActions
        + `</div>`;
    }

    const showSubPlan = multi || !isActiveAcct;
    const shortPlanText = /^Google AI\s+/i.test(planText)
      ? planText.replace(/^Google AI\s+/i, '')
      : planText;
    const subPlanPill = showSubPlan
      ? `<span class="provider-plan-pill" title="${escape(planText)}">${escape(shortPlanText)}</span>`
      : '';
    const subBadges = subPlanPill
      ? `<div class="provider-sub-badges">${subPlanPill}</div>`
      : '';
    const subRow = `<div class="provider-sub">`
      + `<div class="provider-sub-email" title="${escape(emailText)}"><span>${escape(emailText || 'Signed in')}</span><button type="button" class="account-edit-nick-btn" data-action="startEditAccountLabel" data-account-id="${escape(acctId)}" title="${nick ? 'Edit account label' : 'Set friendly label (e.g. Friend, Work)'}">${icons.rename}</button></div>`
      + subBadges
      + `</div>`;

    const inlineEditHtml = isEditingNick
      ? `<div class="account-inline-edit" data-account-id="${escape(acctId)}" data-provider="${key}"><input type="text" class="account-inline-input" maxlength="36" value="${escape(nick)}" placeholder="Label (e.g. Friend, Personal, Work)"><button type="button" class="button sm" data-action="saveAccountLabel">Save</button><button type="button" class="ghost sm" data-action="cancelAccountLabel">✕</button></div>`
      : '';

    return `<div class="provider-card${isActiveAcct ? ' is-active' : ' is-secondary'}${multi ? ' multi' : ''}" data-account-card="${escape(acctId)}"${dragAttrs}>`
      + headerRow
      + subRow
      + inlineEditHtml
      + renderUsageBarsHTML(u, acct.usageMessage, key, false)
      + `</div>`;
  }

  function renderUsage() {
    const body = $('usage-body');
    const cardsEl = $('account-cards-list');
    const countPill = $('accounts-count-pill');
    const {ordered, totalSignedIn, sameProvCounts} = getOrderedAccountCards(false);

    if (countPill) {
      countPill.hidden = totalSignedIn <= 2;
      if (totalSignedIn > 2) countPill.textContent = String(totalSignedIn);
    }
    syncNewSessionControls();

    body.hidden = collapsed.usage;
    if (collapsed.usage || !state) return;

    renderPendingLoginBanner();

    if (editingAccountId && document.activeElement?.classList?.contains('account-inline-input')) {
      return;
    }

    const html = ordered
      .map((a, index) => {
        const provKey = a.provider === 'claude' ? 'claude' : 'antigravity';
        return renderAccountUsageCard(a, sameProvCounts[provKey] || 1, false, {
          index,
          totalCards: ordered.length
        });
      })
      .join('');
    setHTML(cardsEl, html);

    if (editingAccountId) {
      const inp = cardsEl?.querySelector('.account-inline-input');
      if (inp) {
        inp.onkeydown = ev => {
          if (ev.key === 'Enter') { ev.preventDefault(); commitInlineAccountLabel(true); }
          else if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); commitInlineAccountLabel(false); }
        };
      }
    }
  }

  function renderSections() {
    for (const toggle of document.querySelectorAll('.section-toggle')) {
      const section = toggle.dataset.section;
      const name = section === 'usage' ? 'account & usage' : section === 'questions' ? 'pending questions' : section === 'bgTasks' ? 'background tasks' : 'session manager';
      toggle.setAttribute('aria-expanded', String(!collapsed[section]));
      toggle.title = `${collapsed[section] ? 'Expand' : 'Collapse'} ${name}`;
    }
    $('sessions-body').hidden = collapsed.sessions;
    syncNewSessionControls();
    const b = state.bridge;
    setHTML($('notice'), b.reload && b.message ? `<div class="notice"><span>${escape(b.message)}</span><button class="button" data-action="reload">Reload</button></div>`
      : !b.active && b.message ? `<div class="notice"><span>${escape(b.message)}</span></div>` : '');
  }

  // ---- Pending Questions (Needs Input) ---------------------------------
  function getNormalizedRowQuestions(r) {
    if (!r) return [];
    const pq = r.pendingQuestion;
    if (pq && Array.isArray(pq.questions) && pq.questions.length) {
      return pq.questions
        .map(q => ({
          question: String(q?.question || q?.prompt || q?.title || '').trim(),
          options: Array.isArray(q?.options)
            ? q.options.map(o => typeof o === 'string' ? o : String(o?.label || o?.value || o?.text || o?.title || '').trim()).filter(Boolean)
            : [],
          isMultiSelect: Boolean(q?.isMultiSelect || q?.is_multi_select || q?.multiSelect)
        }))
        .filter(q => q.question);
    }
    if (pq && typeof pq.question === 'string' && pq.question.trim()) {
      return [{
        question: pq.question.trim(),
        options: Array.isArray(pq.options)
          ? pq.options.map(o => typeof o === 'string' ? o : String(o?.label || o?.value || o?.text || o?.title || '').trim()).filter(Boolean)
          : [],
        isMultiSelect: Boolean(pq.isMultiSelect || pq.is_multi_select)
      }];
    }
    if (r.status === 'waiting') {
      return [{
        question: r.reason ? `Waiting for user input (${r.reason})` : 'Waiting for user input…',
        options: [],
        isMultiSelect: false
      }];
    }
    return [];
  }

  function getQuestionDraft(sessionId, qCount) {
    let draft = questionDrafts.get(sessionId);
    if (!draft || !Array.isArray(draft.selected) || draft.selected.length !== qCount) {
      draft = {
        selected: Array.from({length: qCount}, (_, idx) => draft?.selected?.[idx] || []),
        other: Array.from({length: qCount}, (_, idx) => draft?.other?.[idx] || '')
      };
      questionDrafts.set(sessionId, draft);
    }
    return draft;
  }

  function showQuestionHoverCard(anchorEl) {
    const card = $('bg-hover-card');
    if (!card || !anchorEl || !state) return;
    const sid = anchorEl.dataset.sessionId;
    const row = state.rows?.find(r => r.id === sid);
    if (!row) return;
    const qList = getNormalizedRowQuestions(row);
    if (!qList.length) return;
    const prov = row.provider === 'claude' ? 'claude' : 'antigravity';
    const q0 = qList[0];
    const ageVal = row.pendingQuestion?.at || row.at;
    const ageTxt = ageVal ? ` · ${ago(ageVal)}` : '';
    const optsPreview = (q0.options || []).slice(0, 5)
      .map((o, idx) => `${idx + 1}. ${o}`)
      .join('\n');
    setHTML(
      card,
      `<div class="bg-hover-top">`
      + `<span class="bg-hover-top-left"><span class="provider-glyph">${getProviderIcon(prov)}</span><span>Question${qList.length > 1 ? ` (${qList.length})` : ''}</span></span>`
      + `<span class="status-pill ok">${escape('Needs input' + ageTxt)}</span>`
      + `</div>`
      + `<div class="bg-hover-expl">${escape(q0.question)}</div>`
      + `<div class="bg-hover-sess">Session: ${escape(row.title)}</div>`
      + (optsPreview ? `<div class="bg-hover-cmd">${escape(optsPreview)}</div>` : '')
    );
    card.hidden = false;
    const rect = anchorEl.getBoundingClientRect();
    const cardH = card.offsetHeight || 110;
    const below = rect.bottom + 6;
    const top = below + cardH <= window.innerHeight - 6 ? below : Math.max(6, rect.top - cardH - 6);
    card.style.top = `${Math.round(top)}px`;
  }

  function collectSidebarQuestionItems() {
    if (!state || !Array.isArray(state.rows)) return [];
    const items = [];
    for (const r of state.rows) {
      if (r.archived || !matchesProvider(r)) continue;
      if (!r.pendingQuestion && r.status !== 'waiting') continue;
      const questions = getNormalizedRowQuestions(r);
      if (!questions.length) continue;
      items.push({row: r, questions, at: r.pendingQuestion?.at || r.at || 0});
    }
    items.sort((a, b) => Number(Boolean(b.row.active)) - Number(Boolean(a.row.active)) || Number(b.at || 0) - Number(a.at || 0));
    return items;
  }

  function renderPcSetupCard() {
    const card = $('pc-setup-card');
    if (!card) return;
    const ps = state?.pcSetup;
    if (!ps || !ps.available || (ps.ready && !ps.applying) || (!ps.pendingCount && !ps.applying)) {
      card.hidden = true;
      card.dataset.sig = '';
      setHTML(card, '');
      return;
    }
    const pendingList = Array.isArray(ps.pending) ? ps.pending : [];
    const sig = `${ps.applying ? '1' : '0'}:${ps.pendingCount}:${pendingList.map(p => p.id).join(',')}`;
    card.hidden = false;
    if (card.dataset.sig === sig) return;
    card.dataset.sig = sig;

    const pillText = ps.applying
      ? 'Applying setup…'
      : `${ps.pendingCount} setup update${ps.pendingCount === 1 ? '' : 's'}`;
    const shown = pendingList.slice(0, 4);
    const extraCount = Math.max(0, pendingList.length - shown.length);
    const itemsHtml = shown.map(p =>
      `<div class="pc-setup-item"><span class="pc-setup-item-bullet">•</span><span>${escape(p.title || p.id)}</span></div>`
    ).join('') + (extraCount > 0 ? `<div class="pc-setup-item"><span class="pc-setup-item-bullet">+</span><span>${extraCount} more in checklist</span></div>` : '');

    setHTML(
      card,
      `<div class="pc-setup-top">`
      + `<span class="pc-setup-title"><span class="pc-setup-dot"></span><span>This PC</span></span>`
      + `<span class="pc-setup-pill tabular">${escape(pillText)}</span>`
      + `</div>`
      + (itemsHtml ? `<div class="pc-setup-items">${itemsHtml}</div>` : '')
      + `<div class="pc-setup-actions">`
      + `<button type="button" class="ghost sm" data-action="openPcSetupDetails">Checklist</button>`
      + `<button type="button" class="pc-setup-apply-btn" data-action="applyPcSetup"${ps.applying ? ' disabled' : ''}>${ps.applying ? 'Applying…' : 'Apply Setup'}</button>`
      + `</div>`
    );
  }

  function renderQuestions(force = false) {
    const hdr = $('questions-header');
    const body = $('questions-body');
    const countPill = $('questions-count-pill');
    if (!hdr || !body) return;
    if (!state) {
      hdr.hidden = true;
      body.hidden = true;
      return;
    }
    const items = collectSidebarQuestionItems();
    const totalQuestions = items.reduce((sum, it) => sum + it.questions.length, 0);
    if (!items.length) {
      hdr.hidden = true;
      body.hidden = true;
      body.dataset.sig = '';
      setHTML(body, '');
      return;
    }

    hdr.hidden = false;
    if (countPill) {
      countPill.textContent = `${totalQuestions} waiting`;
    }
    body.hidden = Boolean(collapsed.questions);
    if (collapsed.questions) return;

    const sig = items.map(it => `${it.row.id}:${it.questions.map(q => q.question + '|' + q.options.join(',')).join(';')}`).join('||');
    const activeEl = document.activeElement;
    if (!force && body.dataset.sig === sig && activeEl && body.contains(activeEl) && activeEl.classList?.contains('sb-q-other-input')) {
      return;
    }
    body.dataset.sig = sig;

    const html = items.map(({row, questions, at}) => {
      const prov = row.provider === 'claude' ? 'claude' : 'antigravity';
      const draft = getQuestionDraft(row.id, questions.length);
      const qBlocks = questions.map((q, qi) => {
        const selectedArr = draft.selected[qi] || [];
        const otherVal = draft.other[qi] || '';
        const optsHtml = (q.options || []).map((opt, oi) => {
          const isSel = selectedArr.includes(opt);
          return `<button type="button" class="sb-q-opt${isSel ? ' selected' : ''}" data-action="selectSidebarQuestionOpt" data-session-id="${escape(row.id)}" data-q-index="${qi}" data-opt-index="${oi}" data-multi="${q.isMultiSelect ? '1' : '0'}">`
            + `<span class="sb-q-num">${oi + 1}</span>`
            + `<span class="sb-q-opt-label">${escape(opt)}</span>`
            + `</button>`;
        }).join('');
        const otherNum = (q.options?.length || 0) + 1;
        return `<div class="sb-q-block" data-q-index="${qi}">`
          + `<div class="sb-q-text">${escape(q.question)}</div>`
          + (optsHtml ? `<div class="sb-q-opts">${optsHtml}</div>` : '')
          + `<div class="sb-q-other-row">`
          + `<span class="sb-q-num">${otherNum}</span>`
          + `<input type="text" class="sb-q-other-input" data-session-id="${escape(row.id)}" data-q-index="${qi}" placeholder="Other (write your answer)…" value="${escape(otherVal)}" />`
          + `</div>`
          + `</div>`;
      }).join('');

      return `<div class="sb-q-card" data-session-id="${escape(row.id)}" data-provider="${prov}">`
        + `<button type="button" class="sb-q-head" data-action="openQuestionSession" data-session-id="${escape(row.id)}" data-provider="${prov}" title="Switch to ${escape(row.title)}">`
        + `<span class="provider-glyph">${getProviderIcon(prov)}</span>`
        + `<span class="sb-q-session">${escape(row.title)}</span>`
        + `<span class="sb-q-age">${at ? ago(at) : 'now'}</span>`
        + `</button>`
        + qBlocks
        + `<div class="sb-q-footer">`
        + `<button type="button" class="ghost sm" data-action="skipSidebarQuestion" data-session-id="${escape(row.id)}" data-provider="${prov}">Skip</button>`
        + `<button type="button" class="sb-q-submit" data-action="submitSidebarQuestion" data-session-id="${escape(row.id)}" data-provider="${prov}">Submit ↵</button>`
        + `</div>`
        + `</div>`;
    }).join('');

    setHTML(body, html);
  }

  function submitSidebarQuestion(sessionId, provider, skip = false) {
    if (!sessionId || !state) return;
    const row = state.rows?.find(r => r.id === sessionId);
    const questions = row ? getNormalizedRowQuestions(row) : [];
    const draft = getQuestionDraft(sessionId, Math.max(1, questions.length));
    const answers = {};
    if (!skip) {
      questions.forEach((q, qi) => {
        const picked = [...(draft.selected[qi] || [])];
        const other = String(draft.other[qi] || '').trim();
        if (other) picked.push(other);
        if (!picked.length && q.options?.length) {
          picked.push(q.options[0]);
        }
        answers[q.question] = picked;
      });
    }
    const firstKey = Object.keys(answers)[0];
    const primaryAnswer = skip ? '' : (firstKey ? answers[firstKey].join(', ') : (draft.other[0] || ''));
    questionDrafts.delete(sessionId);
    if (row) {
      row.pendingQuestion = null;
      row.status = 'working';
      row.category = 'working';
      row.dot = 'running';
      row.reason = null;
    }
    renderQuestions(true);
    renderList();
    send({
      action: 'answerQuestion',
      sessionId,
      provider: provider || row?.provider || 'antigravity',
      skip: Boolean(skip),
      answer: primaryAnswer,
      selectedOptions: firstKey ? answers[firstKey] : [],
      answers,
      questions
    });
  }

  // ---- Background tasks & subagents ------------------------------------
  let bgHoverTimer = null;
  function hideBgHoverCard() {
    if (bgHoverTimer) { clearTimeout(bgHoverTimer); bgHoverTimer = null; }
    const card = $('bg-hover-card');
    if (card) card.hidden = true;
  }

  function showBgHoverCard(anchorEl) {
    const card = $('bg-hover-card');
    if (!card || !anchorEl || !state) return;
    const sid = anchorEl.dataset.sessionId;
    const tid = anchorEl.dataset.taskId;
    const row = state.rows?.find(r => r.id === sid);
    if (!row) return;
    const task = tid
      ? (row.bgTasks || []).find(t => String(t.id) === String(tid))
      : (row.bgTasks || []).find(t => t.state === 'running') || (row.bgTasks || [])[0];
    if (!task) return;
    const prov = row.provider === 'claude' ? 'claude' : 'antigravity';
    const kindLabel = task.kind === 'subagent'
      ? (task.subagentType ? `Subagent (${task.subagentType})` : 'Subagent')
      : task.kind === 'timer'
        ? 'Scheduled timer'
        : 'Background command';
    const stateTag = task.state === 'running' ? 'Running'
      : task.state === 'stalled' ? 'Stalled'
      : task.state === 'interrupted' ? 'Interrupted'
      : task.state === 'failed' ? 'Failed'
      : task.state === 'cancelled' ? 'Stopped' : 'Completed';
    const pillCls = task.state === 'running' ? 'ok' : (task.state === 'failed' || task.state === 'stalled' || task.state === 'interrupted') ? 'err' : 'muted';
    const ageTxt = task.startedAt ? ` · ${ago(task.startedAt)}` : '';
    setHTML(
      card,
      `<div class="bg-hover-top">`
      + `<span class="bg-hover-top-left"><span class="provider-glyph">${getProviderIcon(prov)}</span><span>${escape(kindLabel)}</span></span>`
      + `<span class="status-pill ${pillCls}">${escape(stateTag + ageTxt)}</span>`
      + `</div>`
      + `<div class="bg-hover-expl">${escape(task.summary || task.id)}</div>`
      + `<div class="bg-hover-sess">Session: ${escape(row.title)}</div>`
      + (task.command ? `<div class="bg-hover-cmd">${escape(task.command)}</div>` : '')
    );
    card.hidden = false;
    const rect = anchorEl.getBoundingClientRect();
    const cardH = card.offsetHeight || 96;
    const below = rect.bottom + 6;
    const top = below + cardH <= window.innerHeight - 6 ? below : Math.max(6, rect.top - cardH - 6);
    card.style.top = `${Math.round(top)}px`;
  }

  function getBgKindIcon(kind) {
    return kind === 'subagent' ? icons.subagent : kind === 'timer' ? icons.timer : icons.terminal;
  }

  function collectSidebarBgItems() {
    if (!state || !Array.isArray(state.rows)) return {items: [], runningCount: 0, targetRow: null};
    const seen = new Set();
    const items = [];
    let runningCount = 0;
    const pinnedRow = pinnedBgSessionId ? state.rows.find(r => r.id === pinnedBgSessionId) : null;
    if (pinnedBgSessionId && !pinnedRow) pinnedBgSessionId = '';

    for (const r of state.rows) {
      if (r.archived || !matchesProvider(r) || !Array.isArray(r.bgTasks) || !r.bgTasks.length) continue;
      for (const t of r.bgTasks) {
        if (t.state === 'running') runningCount++;
        const include = pinnedRow
          ? r.id === pinnedRow.id
          : (t.state === 'running' || t.state === 'stalled' || t.state === 'interrupted');
        if (!include) continue;
        const key = `${r.id}:${t.id}`;
        if (seen.has(key)) continue;
        seen.add(key);
        items.push({row: r, task: t});
      }
    }

    items.sort((a, b) => {
      const aLive = a.task.state === 'running' ? 2 : a.task.state === 'stalled' ? 1 : 0;
      const bLive = b.task.state === 'running' ? 2 : b.task.state === 'stalled' ? 1 : 0;
      if (bLive !== aLive) return bLive - aLive;
      return Number(b.task.startedAt || 0) - Number(a.task.startedAt || 0);
    });

    return {items: items.slice(0, 12), totalMatched: items.length, runningCount, targetRow: pinnedRow, isPinned: Boolean(pinnedRow)};
  }

  function renderBgTasks() {
    const hdr = $('bg-tasks-header');
    const body = $('bg-tasks-body');
    const countPill = $('bg-tasks-count-pill');
    const stopAllBtn = $('bg-tasks-stop-all');
    const clearPinBtn = $('bg-tasks-clear-pin');
    if (!hdr || !body) return;
    if (!state) {
      hdr.hidden = true;
      body.hidden = true;
      hideBgHoverCard();
      return;
    }

    const {items, totalMatched, runningCount, targetRow, isPinned} = collectSidebarBgItems();
    if (!items.length) {
      hdr.hidden = true;
      body.hidden = true;
      setHTML(body, '');
      hideBgHoverCard();
      return;
    }

    hdr.hidden = false;
    if (countPill) {
      countPill.textContent = runningCount > 0 ? `${runningCount} live` : String(totalMatched);
      countPill.classList.toggle('live', runningCount > 0);
    }
    if (stopAllBtn) {
      stopAllBtn.hidden = runningCount === 0;
    }
    if (clearPinBtn) {
      clearPinBtn.hidden = !isPinned;
    }

    body.hidden = Boolean(collapsed.bgTasks);
    if (collapsed.bgTasks) {
      hideBgHoverCard();
      return;
    }

    const captionHtml = isPinned && targetRow
      ? `<div class="bg-tasks-caption"><span>${escape(targetRow.title)}</span><span>${totalMatched} task${totalMatched === 1 ? '' : 's'}</span></div>`
      : '';

    const rowsHtml = items.map(({row, task}) => {
      const isRun = task.state === 'running';
      const isFail = task.state === 'failed' || task.state === 'interrupted' || task.state === 'stalled';
      const prov = row.provider === 'claude' ? 'claude' : 'antigravity';
      const glyphInner = `${getBgKindIcon(task.kind)}${isRun ? '<span class="bg-task-live-dot"></span>' : ''}`;
      const stopHtml = isRun
        ? `<span role="button" tabindex="0" class="bg-task-stop" data-action="cancelBgTask" data-session-id="${escape(row.id)}" data-task-id="${escape(task.id)}" data-provider="${prov}" aria-label="Stop background task">${icons.stop}</span>`
        : '';
      return `<button type="button" class="bg-task-row${isRun ? ' is-running' : ''}${isFail ? ' is-failed' : ''}" data-action="inspectBgTask" data-bg-hover="1" data-session-id="${escape(row.id)}" data-task-id="${escape(task.id)}" data-provider="${prov}">`
        + `<span class="bg-task-icon">${glyphInner}</span>`
        + `<span class="bg-task-summary">${escape(task.summary || task.id)}</span>`
        + `<span class="bg-task-prov-mini">${getProviderIcon(prov)}</span>`
        + `<span class="bg-task-right"><span class="bg-task-age">${task.startedAt ? ago(task.startedAt) : ''}</span>${stopHtml}</span>`
        + `</button>`;
    }).join('');

    setHTML(body, captionHtml + rowsHtml);
  }

  // ---- Session list ----------------------------------------------------
  function matchesProvider(r) {
    if (providerFilter === 'all') return true;
    return (r.provider || 'antigravity') === providerFilter;
  }

  function visibleRows() {
    const query = search.trim().toLowerCase(), on = filtering();
    return state.rows.filter(r => {
      if (!matchesProvider(r)) return false;
      if (query && ![r.title, r.folder, r.model, r.branch, getProviderLabel(r.provider)].some(v => String(v || '').toLowerCase().includes(query))) return false;
      if (!on || (renaming && renaming.kind === 'session' && renaming.id === r.key)) return true;
      if (r.archived) return false;
      if (r.active || r.category === 'needs_input' || r.pendingQuestion) return true;
      if (filter.activeOnly && (r.active || isActive(r))) return true;
      if (!filter.statuses.length && !filter.tabStates.length) return !filter.activeOnly;
      if (filter.statuses.length && !filter.statuses.includes(r.category)) return false;
      return !filter.tabStates.length || filter.tabStates.includes(r.open ? 'open' : 'closed');
    });
  }

  function counts() {
    const c = {active: 0, needs_input: 0, working: 0, completed: 0, open: 0, closed: 0, allProviders: 0, antigravity: 0, claude: 0};
    for (const r of state.rows) {
      if (r.archived) continue;
      const prov = r.provider === 'claude' ? 'claude' : 'antigravity';
      c.allProviders++;
      c[prov]++;
    }
    if ((providerFilter === 'claude' && c.claude === 0) || (providerFilter === 'antigravity' && c.antigravity === 0)) {
      providerFilter = 'all';
      send({action: 'providerFilter', value: 'all'});
    }
    for (const r of state.rows) {
      if (r.archived || !matchesProvider(r)) continue;
      c[r.category]++;
      c[r.open ? 'open' : 'closed']++;
      if (isActive(r)) c.active++;
    }
    return c;
  }

  function renderProviderBar(c) {
    const bar = $('provider-bar');
    if (!bar) return;
    const showAgy = c.antigravity > 0;
    const showClaude = c.claude > 0;
    if (providerFilter === 'claude' && !showClaude) providerFilter = 'all';
    if (providerFilter === 'antigravity' && !showAgy) providerFilter = 'all';
    if (!showAgy || !showClaude) {
      bar.hidden = true;
      setHTML(bar, '');
      return;
    }
    bar.hidden = false;
    const tab = (val, label, count, glyph) =>
      `<button type="button" class="provider-tab" data-action="providerFilter" data-value="${val}" aria-pressed="${providerFilter === val}">`
      + `${glyph ? `<span class="provider-glyph">${glyph}</span>` : ''}<span>${label}</span><span class="provider-tab-count">${count}</span></button>`;
    setHTML(
      bar,
      tab('all', 'All', c.allProviders, '') +
      tab('antigravity', 'Antigravity', c.antigravity, providerIcons.antigravity) +
      tab('claude', 'Claude', c.claude, providerIcons.claude)
    );
  }

  function highlight(title) {
    const query = search.trim();
    const at = query ? title.toLowerCase().indexOf(query.toLowerCase()) : -1;
    return at < 0 ? escape(title) : `${escape(title.slice(0, at))}<mark>${escape(title.slice(at, at + query.length))}</mark>${escape(title.slice(at + query.length))}`;
  }

  function dotTitle(r) {
    const where = r.open ? 'Open in a tab' : r.elsewhere ? 'Running in another window / CLI' : 'Closed';
    return r.dot === 'waiting' ? `${where} — awaiting input${r.reason ? ` (${r.reason})` : ''}`
      : r.dot === 'running' ? `${where} — running${r.reason ? ` (${r.reason})` : ''}`
      : r.dot === 'failed' ? `${where} — ${r.reason || 'failed'}`
      : r.dot === 'unread' ? 'Unread' : where;
  }

  function computeRowActionsHTML(r) {
    const action = (name, title, glyph) => `<span role="button" tabindex="0" class="action-button" data-row-action="${name}" title="${title}">${glyph}</span>`;
    const isRunning = r.dot === 'running' || r.status === 'working';
    const stopBtn = isRunning && r.id ? action('stop', 'Stop running session', icons.stop) : '';
    const unassignBtn = r.group && !r.archived && !r.draft ? action('unassign', 'Remove from group', icons.close) : '';
    return r.draft ? action('close', 'Close tab', icons.close)
      : r.archived ? action('unarchive', 'Unarchive session', icons.unarchive)
      : stopBtn + action('rename', 'Rename session', icons.rename) + unassignBtn + action('archive', 'Archive session', icons.archive);
  }

  function patchSessionRowElement(existingEl, r, listKey) {
    const editing = Boolean(renaming && renaming.kind === 'session' && renaming.id === r.key);
    const prov = r.provider === 'claude' ? 'claude' : 'antigravity';
    const metaLine = [getProviderLabel(prov), r.folder, r.branch, r.model, r.reason].filter(Boolean).join(' · ');
    const tip = [r.title, metaLine].filter(Boolean).join('\n');
    const dotCls = r.dot
      ? `status-dot ${r.dot}${r.elsewhere && r.dot === 'running' && !r.open ? ' elsewhere' : ''}`
      : '';
    const dotTip = r.dot ? dotTitle(r) : '';

    if (editing) {
      if (existingEl && existingEl.tagName === 'DIV' && existingEl._isEditingRow && renaming.started) {
        existingEl.dataset.listKey = listKey;
        return existingEl;
      }
      const el = document.createElement('div');
      el._isEditingRow = true;
      el.className = `session-item${r.active ? ' active' : ''}`;
      el.dataset.listKey = listKey;
      el.dataset.key = r.key;
      el.dataset.provider = prov;
      el.title = tip;
      const dotHTML = r.dot ? `<span class="${dotCls}" title="${escape(dotTip)}"></span>` : '';
      const provBadge = `<span class="provider-glyph" title="${escape(getProviderLabel(prov))}">${getProviderIcon(prov)}</span>`;
      const nameHTML = `<span class="session-name editing" contenteditable="plaintext-only" spellcheck="false">${escape(r.title)}</span>`;
      const timeHTML = `<span class="session-meta"><span class="session-time">${r.at ? ago(r.at) : ''}</span></span>`;
      el.innerHTML = `${dotHTML}${provBadge}${nameHTML}${timeHTML}`;
      return el;
    }

    let el = existingEl;
    if (!el || el.tagName !== 'BUTTON' || !el._els || el._isEditingRow) {
      el = document.createElement('button');
      el.type = 'button';
      const dotEl = document.createElement('span');
      dotEl.hidden = true;
      const provEl = document.createElement('span');
      provEl.className = 'provider-glyph';
      const nameEl = document.createElement('span');
      nameEl.className = 'session-name';
      const qPillEl = document.createElement('span');
      qPillEl.hidden = true;
      const bgPillEl = document.createElement('span');
      bgPillEl.hidden = true;
      const metaEl = document.createElement('span');
      metaEl.className = 'session-meta';
      const timeEl = document.createElement('span');
      timeEl.className = 'session-time';
      const actionsEl = document.createElement('span');
      actionsEl.className = 'session-actions';
      metaEl.append(timeEl, actionsEl);
      el.append(dotEl, provEl, nameEl, qPillEl, bgPillEl, metaEl);
      el._els = { dotEl, provEl, nameEl, qPillEl, bgPillEl, metaEl, timeEl, actionsEl };
      el._patch = {};
    }

    const { dotEl, provEl, nameEl, qPillEl, bgPillEl, timeEl, actionsEl } = el._els;
    const patch = el._patch;
    el.dataset.listKey = listKey;
    if (patch.key !== r.key) {
      el.dataset.key = r.key;
      patch.key = r.key;
    }
    if (patch.prov !== prov) {
      el.dataset.provider = prov;
      provEl.title = getProviderLabel(prov);
      provEl.innerHTML = getProviderIcon(prov);
      patch.prov = prov;
    }
    const hasMenuOpen = Boolean(menu && menu.source === el && !$('menu')?.hidden);
    const wantCls = `session-item${r.active ? ' active' : ''}${hasMenuOpen ? ' menu-open' : ''}`;
    if (el.className !== wantCls) {
      el.className = wantCls;
    }
    if (patch.tip !== tip) {
      el.title = tip;
      patch.tip = tip;
    }

    if (!r.dot) {
      if (!dotEl.hidden) dotEl.hidden = true;
      patch.dotCls = '';
      patch.dotTip = '';
    } else {
      if (dotEl.hidden) dotEl.hidden = false;
      if (patch.dotCls !== dotCls) {
        dotEl.className = dotCls;
        patch.dotCls = dotCls;
      }
      if (patch.dotTip !== dotTip) {
        dotEl.title = dotTip;
        patch.dotTip = dotTip;
      }
    }

    const nameHTML = highlight(r.title);
    if (patch.nameHTML !== nameHTML) {
      nameEl.innerHTML = nameHTML;
      patch.nameHTML = nameHTML;
    }

    const qCount = (r.pendingQuestion || r.status === 'waiting') && r.id ? getNormalizedRowQuestions(r).length : 0;
    const qSig = qCount > 0 ? `${r.id}:${qCount}` : '';
    if (!qSig) {
      if (!qPillEl.hidden) qPillEl.hidden = true;
      patch.qSig = '';
    } else if (patch.qSig !== qSig) {
      qPillEl.hidden = false;
      qPillEl.className = 'bg-row-pill waiting tabular';
      qPillEl.setAttribute('role', 'button');
      qPillEl.tabIndex = 0;
      qPillEl.dataset.rowAction = 'question';
      qPillEl.dataset.qHover = '1';
      qPillEl.dataset.sessionId = r.id;
      qPillEl.innerHTML = `${icons.question}<span>${qCount}</span>`;
      patch.qSig = qSig;
    }

    const bgRun = Number(r.bgRunningCount || 0);
    const bgSig = bgRun > 0 && r.id ? `${r.id}:${bgRun}` : '';
    if (!bgSig) {
      if (!bgPillEl.hidden) bgPillEl.hidden = true;
      patch.bgSig = '';
    } else if (patch.bgSig !== bgSig) {
      bgPillEl.hidden = false;
      bgPillEl.className = 'bg-row-pill running tabular';
      bgPillEl.setAttribute('role', 'button');
      bgPillEl.tabIndex = 0;
      bgPillEl.dataset.rowAction = 'bgTasks';
      bgPillEl.dataset.bgHover = '1';
      bgPillEl.dataset.sessionId = r.id;
      bgPillEl.innerHTML = `${icons.terminal}<span>${bgRun}</span>`;
      patch.bgSig = bgSig;
    }

    const timeTxt = r.at ? ago(r.at) : '';
    if (patch.timeTxt !== timeTxt) {
      timeEl.textContent = timeTxt;
      patch.timeTxt = timeTxt;
    }

    const actionsHTML = computeRowActionsHTML(r);
    if (patch.actionsHTML !== actionsHTML) {
      actionsEl.innerHTML = actionsHTML;
      patch.actionsHTML = actionsHTML;
    }

    return el;
  }

  function patchHeaderElement(existingEl, desc) {
    const { name, count, isCollapsed, group, section, action = '', fixed = false, listKey } = desc;
    const editing = Boolean(group && renaming && renaming.kind === 'group' && renaming.id === group);
    const tip = fixed ? name : `${isCollapsed ? 'Expand' : 'Collapse'} ${name}`;

    if (editing) {
      if (existingEl && existingEl.tagName === 'DIV' && existingEl._isEditingHeader && renaming.started) {
        existingEl.dataset.listKey = listKey;
        return existingEl;
      }
      const el = document.createElement('div');
      el._isEditingHeader = true;
      el.className = 'group-header';
      el.dataset.listKey = listKey;
      el.dataset.group = group;
      if (fixed) el.dataset.fixed = '1';
      el.setAttribute('aria-expanded', String(!isCollapsed));
      el.title = tip;
      el.innerHTML = `${icons.chevron}<span class="group-name editing" contenteditable="plaintext-only" spellcheck="false">${escape(name)}</span><span class="group-count">${count}</span>`;
      return el;
    }

    let el = existingEl;
    if (!el || el.tagName !== 'BUTTON' || !el._els || el._isEditingHeader) {
      el = document.createElement('button');
      el.type = 'button';
      const tpl = document.createElement('template');
      tpl.innerHTML = icons.chevron;
      const chevEl = tpl.content.firstElementChild;
      const nameEl = document.createElement('span');
      nameEl.className = 'group-name';
      const countEl = document.createElement('span');
      countEl.className = 'group-count';
      el.append(chevEl, nameEl, countEl);
      el._els = { nameEl, countEl, actionNode: null };
      el._patch = {};
    }

    const { nameEl, countEl } = el._els;
    const patch = el._patch;
    el.dataset.listKey = listKey;
    if (group) {
      if (el.dataset.group !== group) el.dataset.group = group;
      if (el.dataset.section) delete el.dataset.section;
    } else {
      if (el.dataset.section !== section) el.dataset.section = section;
      if (el.dataset.group) delete el.dataset.group;
    }
    if (fixed) {
      if (el.dataset.fixed !== '1') el.dataset.fixed = '1';
    } else if (el.dataset.fixed) {
      delete el.dataset.fixed;
    }
    const hasMenuOpen = Boolean(menu && menu.source === el && !$('menu')?.hidden);
    const wantCls = `group-header${hasMenuOpen ? ' menu-open' : ''}`;
    if (el.className !== wantCls) el.className = wantCls;
    const wantExpanded = String(!isCollapsed);
    if (patch.expanded !== wantExpanded) {
      el.setAttribute('aria-expanded', wantExpanded);
      patch.expanded = wantExpanded;
    }
    if (patch.tip !== tip) {
      el.title = tip;
      patch.tip = tip;
    }
    if (patch.name !== name) {
      nameEl.textContent = name;
      patch.name = name;
    }
    const countTxt = String(count);
    if (patch.countTxt !== countTxt) {
      countEl.textContent = countTxt;
      patch.countTxt = countTxt;
    }
    if (patch.actionHTML !== action) {
      if (el._els.actionNode && el._els.actionNode.parentNode === el) {
        el._els.actionNode.remove();
      }
      el._els.actionNode = null;
      if (action) {
        const tpl = document.createElement('template');
        tpl.innerHTML = action;
        const actionNode = tpl.content.firstElementChild;
        if (actionNode) {
          el.insertBefore(actionNode, countEl);
          el._els.actionNode = actionNode;
        }
      }
      patch.actionHTML = action;
    }
    return el;
  }

  function patchStateBannerElement(existingEl, desc) {
    const cls = desc.kind === 'null' ? 'null-state' : 'empty-state';
    let el = existingEl;
    if (!el || el.tagName !== 'DIV' || el.className !== cls) {
      el = document.createElement('div');
      el.className = cls;
    }
    el.dataset.listKey = desc.listKey;
    if (el.textContent !== desc.text) {
      el.textContent = desc.text;
    }
    return el;
  }

  function reconcileListDOM(listEl, descriptors) {
    if (!listEl) return;
    const existingByKey = new Map();
    for (const child of Array.from(listEl.children)) {
      const k = child.dataset?.listKey;
      if (k && !existingByKey.has(k)) {
        existingByKey.set(k, child);
      }
    }
    const usedNodes = new Set();
    const desiredNodes = [];
    for (const desc of descriptors) {
      let existing = existingByKey.get(desc.listKey) || null;
      if (!existing && desc.kind === 'row' && desc.row?.uri) {
        const draftAlias = existingByKey.get(`row:${desc.row.uri}`);
        if (draftAlias && !usedNodes.has(draftAlias)) {
          existing = draftAlias;
        }
      }
      if (existing && usedNodes.has(existing)) {
        existing = null;
      }
      let nextNode;
      if (desc.kind === 'row') {
        nextNode = patchSessionRowElement(existing, desc.row, desc.listKey);
      } else if (desc.kind === 'header') {
        nextNode = patchHeaderElement(existing, desc);
      } else {
        nextNode = patchStateBannerElement(existing, desc);
      }
      if (menu && existing && existing !== nextNode && menu.source === existing) {
        menu.source = nextNode;
        if (!$('menu')?.hidden) nextNode.classList.add('menu-open');
      }
      usedNodes.add(nextNode);
      desiredNodes.push(nextNode);
    }
    for (const child of Array.from(listEl.children)) {
      if (!usedNodes.has(child)) {
        if (menu && menu.source === child) {
          closeMenu();
        }
        child.remove();
      }
    }
    let cursor = listEl.firstElementChild;
    for (const node of desiredNodes) {
      if (cursor === node) {
        cursor = cursor.nextElementSibling;
      } else {
        listEl.insertBefore(node, cursor);
      }
    }
  }

  function renderList() {
    if (!state || (renaming && renaming.started)) return;
    const c = counts(), selected = filter.statuses.length + filter.tabStates.length;
    renderProviderBar(c);
    $('active-count').textContent = `Running / Unread · ${c.active}`;
    $('active-toggle').classList.toggle('on', filter.activeOnly);
    $('active-toggle').setAttribute('aria-pressed', String(filter.activeOnly));
    $('filter-button').classList.toggle('on', selected > 0);
    $('filter-button').setAttribute('aria-label', selected ? `Filter by status, ${selected} selected` : 'Filter by status');
    $('search-clear').hidden = !search;

    const rows = visibleRows(), query = search.trim(), on = filtering();
    const live = rows.filter(r => !r.archived), archived = rows.filter(r => r.archived);
    const groupIds = new Set(state.groups.map(g => g.id));
    const descriptors = [];
    if (!state.rows.length && !state.groups.length) {
      descriptors.push({
        kind: 'null',
        listKey: 'state:null',
        text: state.loading ? 'Loading sessions…' : 'No sessions yet'
      });
    } else if (!rows.length && (query || on || providerFilter !== 'all')) {
      descriptors.push({
        kind: 'empty',
        listKey: 'state:empty',
        text: 'No matching sessions'
      });
    } else if (query || !state.groups.length) {
      for (const r of live) {
        descriptors.push({ kind: 'row', listKey: `row:${r.key}`, row: r });
      }
    } else {
      const newInGroup = `<span role="button" tabindex="0" class="action-button group-action" data-group-action="new" title="Start new session in this group">${icons.plus}</span>`;
      for (const g of state.groups) {
        const items = live.filter(r => r.group === g.id);
        if (on && !items.length && !(renaming && renaming.id === g.id)) continue;
        descriptors.push({
          kind: 'header',
          listKey: `grp:${g.id}`,
          name: g.name,
          count: items.length,
          isCollapsed: g.collapsed,
          group: g.id,
          action: newInGroup
        });
        if (!g.collapsed) {
          for (const r of items) {
            descriptors.push({ kind: 'row', listKey: `row:${r.key}`, row: r });
          }
        }
      }
      const ungrouped = live.filter(r => !r.group || !groupIds.has(r.group));
      if (ungrouped.length) {
        const archivableUngrouped = ungrouped.filter(r => r.id && !r.open && r.status !== 'working' && r.status !== 'waiting' && !r.unread);
        const archiveBtn = archivableUngrouped.length
          ? `<span role="button" tabindex="0" class="action-button group-action" data-group-action="archiveUngroupedClosed" title="Archive ${archivableUngrouped.length} closed session${archivableUngrouped.length === 1 ? '' : 's'}">${icons.archive}</span>`
          : '';
        descriptors.push({
          kind: 'header',
          listKey: 'sec:ungrouped',
          name: 'Ungrouped',
          count: ungrouped.length,
          isCollapsed: collapsed.ungrouped,
          section: 'ungrouped',
          action: archiveBtn
        });
        if (!collapsed.ungrouped) {
          for (const r of ungrouped) {
            descriptors.push({ kind: 'row', listKey: `row:${r.key}`, row: r });
          }
        }
      }
    }
    if (archived.length) {
      const hidden = !query && collapsed.archived;
      const all = `<span role="button" tabindex="0" class="action-button group-action" data-group-action="unarchiveAll" title="${archived.length === 1 ? 'Unarchive session' : `Unarchive all ${archived.length} sessions`}">${icons.unarchive}</span>`;
      descriptors.push({
        kind: 'header',
        listKey: 'sec:archived',
        name: 'Archived sessions',
        count: archived.length,
        isCollapsed: hidden,
        section: 'archived',
        action: query ? '' : all,
        fixed: !!query
      });
      if (!hidden) {
        for (const r of archived) {
          descriptors.push({ kind: 'row', listKey: `row:${r.key}`, row: r });
        }
      }
    }
    reconcileListDOM($('list'), descriptors);
    if (renaming && !renaming.started) beginEdit();
  }

  // ---- Inline rename ---------------------------------------------------
  function startRename(kind, id) {
    closeMenu();
    renaming = {kind, id, started: false};
    renderList();
  }
  function beginEdit() {
    const el = $('list').querySelector('[contenteditable]');
    if (!el) { renaming = null; return; }
    renaming.started = true;
    renaming.original = el.textContent;
    el.focus();
    const range = document.createRange();
    range.selectNodeContents(el);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    el.addEventListener('keydown', event => {
      if (event.isComposing) return;
      event.stopPropagation();
      if (event.key === 'Enter') { event.preventDefault(); finishRename(true); }
      else if (event.key === 'Escape') { event.preventDefault(); finishRename(false); }
    });
    el.addEventListener('blur', () => finishRename(true));
  }
  function finishRename(commit) {
    if (!renaming || !renaming.started) return;
    const {kind, id, original} = renaming;
    const el = $('list').querySelector('[contenteditable]');
    const name = (el ? el.textContent : '').replace(/\s+/g, ' ').trim();
    renaming = null;
    if (commit && name && name !== original) {
      if (kind === 'group') {
        const g = state.groups.find(g => g.id === id);
        if (g) g.name = name;
        send({action: 'groupRename', group: id, name});
      } else {
        const r = rowByKey(id);
        if (r) r.title = name;
        send({action: 'rename', id: r?.id || id, name, provider: r?.provider});
      }
    }
    renderList();
    if (typeof scheduleRowOrderFreezeRelease === 'function') {
      scheduleRowOrderFreezeRelease(220);
    }
  }

  // ---- Menus -----------------------------------------------------------
  function closeMenu() {
    if (!menu) return;
    menu.source?.classList.remove('menu-open');
    menu.button?.setAttribute('aria-expanded', 'false');
    $('menu').hidden = true;
    menu = null;
    if (typeof scheduleRowOrderFreezeRelease === 'function') {
      scheduleRowOrderFreezeRelease(220);
    }
  }
  function openMenu(build, x, y, options = {}) {
    closeMenu();
    const el = $('menu'), items = build();
    if (!items.length) return;
    el.innerHTML = items.map((item, index) => {
      const separator = item.separator ? '<div class="menu-separator"></div>' : '';
      if (item.heading) return `${separator}<div class="menu-heading">${escape(item.heading)}</div>`;
      const check = item.checked === undefined ? '' : `<span class="menu-check">${item.checked ? icons.check : ''}</span>`;
      const glyph = item.glyph ? `<span class="provider-glyph">${item.glyph}</span>` : '';
      return `${separator}<button class="menu-item" role="${item.checked === undefined ? 'menuitem' : 'menuitemcheckbox'}"${item.checked === undefined ? '' : ` aria-checked="${item.checked}"`} data-index="${index}">${check}${glyph}${escape(item.label)}</button>`;
    }).join('');
    el.hidden = false;
    const box = el.getBoundingClientRect();
    el.style.left = `${Math.max(4, Math.min(x, window.innerWidth - box.width - 4))}px`;
    el.style.top = `${Math.max(4, Math.min(y, window.innerHeight - box.height - 4))}px`;
    menu = {items, build, x, y, source: options.source, button: options.button, width: window.innerWidth, height: window.innerHeight};
    options.source?.classList.add('menu-open');
    options.button?.setAttribute('aria-expanded', 'true');
    el.querySelector('.menu-item')?.focus();
  }
  function sessionMenu(r) {
    const prov = r.provider || 'antigravity';
    const open = () => {
      activateSessionOptimistically(r);
      return r.id ? send({action: 'open', id: r.id, provider: prov}) : send({action: 'focus', key: r.key, provider: prov});
    };
    const close = {label: 'Close tab', run: () => send({action: 'closeTab', key: r.key, id: r.id, provider: prov})};
    const first = {label: r.open ? 'Switch to session' : 'Resume session', glyph: getProviderIcon(prov), run: open};
    if (r.draft) return [first, {...close, separator: true}];
    if (r.archived) return [first, {label: 'Unarchive session', separator: true, run: () => {
      r.archived = false;
      renderList();
      send({action: 'archive', ids: [r.id], value: false});
    }}];
    const items = [first];
    if (r.logged) items.push({label: 'Open to the side', run: () => send({action: 'beside', id: r.id, provider: prov})});
    if (r.open) items.push(close);
    const qList = (r.pendingQuestion || r.status === 'waiting') ? getNormalizedRowQuestions(r) : [];
    if (qList.length && r.id) {
      items.push({label: `Pending question (${qList.length} waiting)`, separator: true, run: () => rowAction('question', r)});
    }
    if (Number(r.bgTotalCount || 0) > 0 && r.id) {
      items.push({label: `Background tasks (${r.bgRunningCount > 0 ? `${r.bgRunningCount} live / ${r.bgTotalCount}` : r.bgTotalCount})`, separator: true, run: () => focusSessionBgTasks(r)});
    }
    if ((r.dot === 'running' || r.status === 'working') && r.id) {
      items.push({label: 'Stop session', separator: true, run: () => {
        r.dot = r.open ? 'idle' : null;
        r.status = 'completed';
        r.category = 'completed';
        r.unread = false;
        r.elsewhere = false;
        r.reason = null;
        renderList();
        send({action: 'stop', id: r.id, key: r.key, provider: prov});
      }});
    }
    items.push({label: 'Rename session', separator: true, run: () => startRename('session', r.key)});
    items.push({label: 'New group from session', separator: true, run: () => send({action: 'groupCreate', ids: [r.id]})});
    const others = state.groups.filter(g => g.id !== r.group);
    if (others.length) {
      items.push({heading: 'Add to group'});
      for (const g of others) items.push({label: g.name, run: () => {
        r.group = g.id;
        renderList();
        send({action: 'groupAdd', ids: [r.id], group: g.id});
      }});
    }
    if (r.group) items.push({label: 'Remove from group', separator: true, run: () => {
      const prevGrp = r.group;
      r.group = null;
      renderList();
      send({action: 'groupRemove', ids: [r.id], group: prevGrp});
    }});
    items.push({label: r.unread ? 'Mark as read' : 'Mark as unread', separator: true, run: () => {
      r.unread = !r.unread;
      renderList();
      send({action: 'unread', ids: [r.id], value: r.unread});
    }});
    items.push({label: 'Archive session', separator: true, run: () => {
      r.archived = true;
      r.group = null;
      renderList();
      send({action: 'archive', ids: [r.id], value: true});
    }});
    if (r.logged) items.push(
      {label: 'Copy session ID', separator: true, run: () => send({action: 'copy', id: r.id})},
      {label: 'Show transcript log', run: () => send({action: 'reveal', id: r.id, provider: prov})}
    );
    return items;
  }
  const groupMenu = g => {
    const hasAgy = hasSignedInProvider('antigravity');
    const hasClaude = hasSignedInProvider('claude');
    const items = [];
    if (hasAgy) items.push({label: 'New Antigravity session in group', glyph: providerIcons.antigravity, run: () => send({action: 'newInGroup', group: g.id, provider: 'antigravity'})});
    if (hasClaude) items.push({label: 'New Claude Code session in group', glyph: providerIcons.claude, run: () => send({action: 'newInGroup', group: g.id, provider: 'claude'})});
    items.push({label: 'Rename group', separator: items.length > 0, run: () => startRename('group', g.id)});
    items.push({label: 'Delete group', run: () => send({action: 'groupDelete', group: g.id})});
    return items;
  };
  function accountMenu(accountId, provKey) {
    const prov = provKey === 'claude' ? 'claude' : 'antigravity';
    const provs = state?.providers || {};
    const list = getProviderAccountsList(provs[prov], prov);
    const signedInList = list.filter(isSignedInAccountCard);
    const acct = findAccountModel(accountId, prov);
    const isActive = acct ? acct.active !== false : true;
    const provLabel = getProviderLabel(prov);
    const email = acct?.account?.email || provLabel;
    const nick = String(acct?.nickname || acct?.account?.nickname || '').trim();
    const {ordered} = getOrderedAccountCards(false);
    const orderedIds = ordered.map(a => a.id);
    const posIdx = orderedIds.indexOf(accountId);
    const items = [
      {heading: email},
      isActive
        ? {label: 'Active for new sessions', checked: true, run: () => {}}
        : {label: 'Switch to this account', glyph: providerIcons[prov], run: () => triggerAccountSwitch(accountId, prov)},
      {label: `New ${provLabel} session with this account`, run: () => send({action: 'accountNewSession', accountId, provider: prov, beside: false})},
      {label: nick ? `Edit label (${nick})…` : 'Set label / nickname…', separator: true, run: () => openInlineAccountLabel(accountId)}
    ];
    if (orderedIds.length > 1 && posIdx !== -1) {
      if (posIdx > 0) {
        items.push({
          label: 'Move account up',
          separator: true,
          run: () => moveAccountCard(accountId, {provider: prov, direction: 'up'})
        });
      }
      if (posIdx < orderedIds.length - 1) {
        items.push({
          label: 'Move account down',
          separator: posIdx === 0,
          run: () => moveAccountCard(accountId, {provider: prov, direction: 'down'})
        });
      }
    }
    items.push(
      {label: 'Refresh usage windows', separator: true, run: () => send({action: 'refresh'})},
      {label: `Add another ${provLabel} account…`, separator: true, run: () => openAddAccountTray(prov)}
    );
    if (signedInList.length >= 1 && (!acct || isSignedInAccountCard(acct))) {
      items.push({
        label: signedInList.length > 1 ? 'Disconnect account…' : 'Sign out / Disconnect account…',
        separator: true,
        run: () => send({action: 'accountRemove', accountId, provider: prov, confirm: true})
      });
    }
    return items;
  }
  function filterMenu() {
    const c = counts();
    const toggle = (list, value) => () => {
      let nextList = filter[list].includes(value) ? filter[list].filter(v => v !== value) : [...filter[list], value];
      if (list === 'statuses' && nextList.length >= Object.keys(statusLabels).length) nextList = [];
      if (list === 'tabStates' && nextList.length >= Object.keys(tabLabels).length) nextList = [];
      filter = {...filter, [list]: nextList};
      send({action: 'filter', filter});
      renderList();
    };
    const clearFilters = () => {
      filter = {statuses: [], tabStates: [], activeOnly: false};
      send({action: 'filter', filter});
      renderList();
    };
    const autoDays = typeof state?.autoArchiveDays === 'number' ? state.autoArchiveDays : 14;
    const setAutoDays = days => () => send({action: 'autoArchiveDays', value: days});
    return [
      ...(filter.statuses.length || filter.tabStates.length || filter.activeOnly ? [{label: 'Clear all filters', run: clearFilters}] : []),
      {heading: 'Status', separator: Boolean(filter.statuses.length || filter.tabStates.length || filter.activeOnly)},
      ...Object.keys(statusLabels).map(k => ({label: `${statusLabels[k]} · ${c[k]}`, checked: filter.statuses.includes(k), keepOpen: true, run: toggle('statuses', k)})),
      {heading: 'Tabs', separator: true},
      ...Object.keys(tabLabels).map(k => ({label: `${tabLabels[k]} · ${c[k]}`, checked: filter.tabStates.includes(k), keepOpen: true, run: toggle('tabStates', k)})),
      {heading: 'Auto-archive inactive', separator: true},
      {label: 'After 1 day', checked: autoDays === 1, run: setAutoDays(1)},
      {label: 'After 2 days', checked: autoDays === 2, run: setAutoDays(2)},
      {label: 'After 7 days', checked: autoDays === 7, run: setAutoDays(7)},
      {label: 'After 14 days', checked: autoDays === 14, run: setAutoDays(14)},
      {label: 'Never', checked: autoDays === 0, run: setAutoDays(0)},
      {label: 'Archive all closed & read now', separator: true, run: () => {
        const groupIds = new Set((state?.groups || []).map(g => g.id));
        const ids = (state?.rows || [])
          .filter(r => r.id && !r.archived && !r.open && r.status !== 'working' && r.status !== 'waiting' && !r.unread && (!r.group || !groupIds.has(r.group)) && matchesProvider(r))
          .map(r => r.id);
        if (ids.length) send({action: 'archive', ids, value: true});
      }}
    ];
  }
  $('menu').addEventListener('click', event => {
    const button = event.target.closest('.menu-item');
    if (!button || !menu) return;
    const current = menu, index = button.dataset.index, item = current.items[Number(index)];
    if (!item.keepOpen) closeMenu();
    item.run();
    if (item.keepOpen) {
      openMenu(current.build, current.x, current.y, {source: current.source, button: current.button});
      $('menu').querySelector(`[data-index="${index}"]`)?.focus();
    }
  });
  $('menu').addEventListener('keydown', event => {
    if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
    event.preventDefault();
    const items = [...$('menu').querySelectorAll('.menu-item')], at = items.indexOf(document.activeElement);
    items[(at + (event.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length]?.focus();
  });
  document.addEventListener('pointerdown', event => { if (menu && !$('menu').contains(event.target) && !menu.button?.contains(event.target)) closeMenu(); }, true);
  window.addEventListener('blur', closeMenu);
  window.addEventListener('resize', () => { if (menu && (menu.width !== window.innerWidth || menu.height !== window.innerHeight)) closeMenu(); });
  document.addEventListener('wheel', event => { if (menu && !$('menu').contains(event.target)) closeMenu(); }, {capture: true, passive: true});

  function focusSessionBgTasks(r) {
    if (!r || !r.id) return;
    if (pinnedBgSessionId === r.id && Array.isArray(r.bgTasks) && r.bgTasks.length === 1) {
      const only = r.bgTasks[0];
      openBgTaskInspector(r.id, only.id, r.provider, only);
      return;
    }
    pinnedBgSessionId = r.id;
    if (collapsed.bgTasks) {
      collapsed.bgTasks = false;
      persist();
      send({action: 'collapse', section: 'bgTasks', value: false});
    }
    renderSections();
    renderBgTasks();
    $('bg-tasks-header')?.scrollIntoView?.({behavior: 'smooth', block: 'nearest'});
  }

  function openBgTaskInspector(sessionId, taskId, provider, fallbackTask) {
    const row = state?.rows?.find(r => r.id === sessionId);
    const localTask = row?.bgTasks?.find(t => t.id === taskId || t.fullId === taskId) || fallbackTask || {id: taskId, summary: taskId, state: 'completed'};
    details = false;
    bgInspector = {
      sessionId,
      sessionTitle: row?.title || 'Session',
      provider: provider || row?.provider || 'antigravity',
      task: {...localTask},
      output: null,
      loading: true
    };
    renderDetails();
    send({action: 'inspectBgTask', sessionId, taskId, provider: bgInspector.provider});
  }

  // ---- Account & Usage details / Background Task Inspector -------------
  function renderDetails() {
    const showModal = Boolean(details || bgInspector);
    $('dialog').hidden = !showModal;
    if (!showModal) return;

    if (bgInspector) {
      const t = bgInspector.task || {};
      const prov = bgInspector.provider === 'claude' ? 'claude' : 'antigravity';
      const isRun = t.state === 'running';
      const statusCls = isRun ? 'ok' : (t.state === 'failed' || t.state === 'stalled' || t.state === 'interrupted') ? 'err' : t.state === 'cancelled' ? 'warn' : 'muted';
      const statusText = isRun
        ? 'Running'
        : t.state === 'stalled'
          ? 'Stalled'
          : t.state === 'interrupted'
            ? 'Interrupted'
            : t.state === 'failed'
              ? 'Failed'
              : t.state === 'cancelled'
                ? 'Stopped'
                : 'Completed';
      const kindTitle = t.kind === 'subagent'
        ? (t.subagentType ? `Subagent (${t.subagentType})` : 'Subagent Task')
        : t.kind === 'timer'
          ? 'Scheduled Timer'
          : 'Background Task';
      if ($('dialog-title')) $('dialog-title').textContent = kindTitle;
      const durationSec = t.startedAt
        ? Math.max(0, Math.round(((t.completedAt || Date.now()) - t.startedAt) / 1000))
        : 0;
      const durText = durationSec >= 3600
        ? `${Math.floor(durationSec / 3600)}h ${Math.floor((durationSec % 3600) / 60)}m`
        : durationSec >= 60
          ? `${Math.floor(durationSec / 60)}m ${durationSec % 60}s`
          : `${durationSec}s`;
      const logContent = bgInspector.loading && bgInspector.output === null
        ? 'Loading task log output…'
        : (bgInspector.output || 'No log output captured yet.');
      setHTML($('dialog-body'),
        `<div class="block">`
        + `<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">`
        + `<div style="font-weight:600;font-size:13px;line-height:1.35">${escape(t.summary || t.id)}</div>`
        + `<span class="status-pill ${statusCls}">${escape(statusText)}</span>`
        + `</div>`
        + `<div class="account-rows">`
        + `<div class="account-row"><span>Session</span><span style="display:inline-flex;align-items:center;gap:5px"><span class="provider-glyph">${getProviderIcon(prov)}</span>${escape(bgInspector.sessionTitle)}</span></div>`
        + `<div class="account-row"><span>Task ID</span><span class="tabular">${escape(t.id || '—')}</span></div>`
        + (t.startedAt ? `<div class="account-row"><span>Timing</span><span class="tabular">Started ${ago(t.startedAt) === 'now' ? 'just now' : `${ago(t.startedAt)} ago`} · ${durText}</span></div>` : '')
        + `</div></div>`
        + (t.command
          ? `<div class="block"><h4 class="block-title">${t.kind === 'subagent' ? 'Delegated prompt' : 'Command'}</h4><pre class="bg-detail-cmd">${escape(t.command)}</pre></div>`
          : '')
        + `<div class="block"><div class="block-title-row"><h4 class="block-title">${t.kind === 'subagent' ? 'Subagent trace / report' : 'Live terminal output'}</h4>`
        + `<button type="button" class="ghost sm" data-action="refreshBgTaskLog">↻ Refresh</button></div>`
        + `<pre class="bg-detail-log">${escape(logContent)}</pre></div>`
        + `<div class="button-row">`
        + `<button type="button" class="button" data-action="openBgTaskSession">Open session</button>`
        + (isRun ? `<button type="button" class="button danger" data-action="cancelBgTask" data-session-id="${escape(bgInspector.sessionId)}" data-task-id="${escape(t.id)}" data-provider="${prov}">■ Stop task</button>` : '')
        + `<button type="button" class="ghost" style="margin-left:auto" data-action="closeDetails">Close</button>`
        + `</div>`
      );
      return;
    }

    if ($('dialog-title')) $('dialog-title').textContent = 'Account & Usage';
    if (!details || !state) return;
    const provs = state.providers || {};
    const summaries = state.summaryByProvider || {all: state.summary};
    const activeSummary = summaries[activityProvider] || state.summary;
    const m = activeSummary[period] || {sessions: 0, turns: 0, tokens: 0, input: 0, cached: 0, output: 0};
    const days = Array.isArray(activeSummary.days) ? activeSummary.days : [];
    const max = Math.max(1, ...days.map(d => d.tokens));
    const cache = m.input ? Math.round(Math.min(100, m.cached / m.input * 100)) : null;
    const pressed = (on, action, value, label) => `<button data-action="${action}" data-value="${value}" aria-pressed="${on}">${label}</button>`;
    const b = state.bridge || {};
    const agyPill = `<span class="status-pill ${b.antigravityActive ? 'ok' : 'warn'}">${b.antigravityActive ? 'Connected' : 'Reload needed'}</span>`;
    const claudePill = `<span class="status-pill ${b.claudeActive ? 'ok' : 'warn'}">${b.claudeActive ? 'Connected' : 'Reload needed'}</span>`;
    const autoDays = typeof state.autoArchiveDays === 'number' ? state.autoArchiveDays : 14;

    const {ordered: detailsOrdered, sameProvCounts: detailsCounts} = getOrderedAccountCards(true);
    const ps = state.pcSetup || null;
    const psReady = Boolean(ps && ps.available && ps.ready && !ps.applying);
    const psBadgeHtml = !ps || !ps.available
      ? `<span class="pc-setup-pill tabular">Checking…</span>`
      : ps.applying
        ? `<span class="pc-setup-pill tabular">Applying…</span>`
        : psReady
          ? `<span class="pc-setup-pill ok tabular">${ps.okCount}/${ps.totalCount} Ready</span>`
          : `<span class="pc-setup-pill tabular">${ps.pendingCount} Pending (${ps.okCount}/${ps.totalCount})</span>`;
    const psSteps = Array.isArray(ps?.steps) && ps.steps.length
      ? ps.steps
      : Array.isArray(ps?.pending)
        ? ps.pending.map(p => ({id: p.id, title: p.title, ok: false, summary: ''}))
        : [];
    const psChecklistHtml = psSteps.length
      ? `<div class="pc-setup-checklist">`
        + psSteps.map(st =>
          `<div class="pc-setup-step-row">`
          + `<div class="pc-setup-step-main">`
          + `<span class="pc-setup-step-mark${st.ok ? '' : ' pending'}">${st.ok ? '✓' : '●'}</span>`
          + `<div class="pc-setup-step-copy">`
          + `<span class="pc-setup-step-name">${escape(st.title || st.id)}</span>`
          + (st.summary ? `<span class="pc-setup-step-sub">${escape(st.summary)}</span>` : '')
          + `</div></div></div>`
        ).join('')
        + `</div>`
      : `<p class="note">Click Check now to verify all per-PC tools, hooks, and rules on this workstation.</p>`;

    setHTML($('dialog-body'),
      `<div class="block"><div class="block-title-row"><h4 class="block-title">Accounts &amp; Quotas</h4><button type="button" class="section-add-btn" data-action="openAddFromDetails">+ Add Account</button></div>`
      + detailsOrdered.map((a, index) => {
          const provKey = a.provider === 'claude' ? 'claude' : 'antigravity';
          return renderAccountUsageCard(a, detailsCounts[provKey] || 1, true, {
            index,
            totalCards: detailsOrdered.length
          });
        }).join('')
      + `</div>`
      + `<div class="block" id="pc-setup-details-block"><div class="block-title-row"><h4 class="block-title">This PC Setup</h4>${psBadgeHtml}</div>`
      + psChecklistHtml
      + `<div class="button-row">`
      + `<button type="button" class="button" data-action="checkPcSetup"${ps?.applying ? ' disabled' : ''}>Check now</button>`
      + `<button type="button" class="button" data-action="applyPcSetup"${ps?.applying ? ' disabled' : ''}>${ps?.applying ? 'Applying…' : (ps && ps.pendingCount > 0 ? `Apply Setup (${ps.pendingCount})` : 'Verify / Repair')}</button>`
      + `</div></div>`
      + `<div class="block"><h4 class="block-title">Local token activity</h4>`
      + `<div class="segmented" role="group" aria-label="Activity provider">${pressed(activityProvider === 'all', 'activityProvider', 'all', 'Combined')}${pressed(activityProvider === 'antigravity', 'activityProvider', 'antigravity', 'Antigravity')}${pressed(activityProvider === 'claude', 'activityProvider', 'claude', 'Claude Code')}</div>`
      + `<div class="segmented" role="group" aria-label="Activity period">${pressed(period === 'today', 'period', 'today', 'Today')}${pressed(period === 'week', 'period', 'week', 'Last 7 days')}</div>`
      + `<div class="metrics"><div class="metric"><strong>${compact(m.sessions)}</strong><span>Sessions</span></div><div class="metric"><strong>${compact(m.turns)}</strong><span>User turns</span></div><div class="metric" title="${exact(m.tokens)} tokens"><strong>${compact(m.tokens)}</strong><span>Tokens</span></div></div>`
      + `<div class="chart" role="img" aria-label="Tokens by day: ${escape(days.map(d => d.label + ' ' + exact(d.tokens)).join(', '))}">${days.map(d => `<div class="chart-day" title="${escape(d.key)}: ${exact(d.tokens)} tokens, ${exact(d.turns)} user turns"><div class="chart-bar" style="height:${d.tokens / max * 42}px"></div><span>${escape(d.label)}</span></div>`).join('')}</div>`
      + `<div class="account-rows"><div class="account-row"><span>Input tokens</span><span class="tabular">${exact(m.input)}</span></div><div class="account-row"><span>Cached input (included above)</span><span class="tabular">${exact(m.cached)}</span></div><div class="account-row"><span>Output tokens</span><span class="tabular">${exact(m.output)}</span></div><div class="account-row"><span>Input cache reuse</span><span class="tabular">${cache == null ? '—' : cache + '%'}</span></div></div>`
      + '<p class="note">Token counts are local activity from Antigravity and Claude Code session logs, not billing percentages.</p></div>'
      + `<div class="block"><h4 class="block-title">Sessions shown</h4><div class="segmented" role="group" aria-label="Session scope">${pressed(state.scope === 'workspace', 'scope', 'workspace', 'This workspace')}${pressed(state.scope === 'all', 'scope', 'all', 'All workspaces')}</div></div>`
      + `<div class="block"><h4 class="block-title">Auto-archive inactive chats</h4><div class="segmented" role="group" aria-label="Auto-archive inactive sessions">${pressed(autoDays === 1, 'autoArchiveDays', '1', '1d')}${pressed(autoDays === 2, 'autoArchiveDays', '2', '2d')}${pressed(autoDays === 7, 'autoArchiveDays', '7', '7d')}${pressed(autoDays === 14, 'autoArchiveDays', '14', '14d')}${pressed(autoDays === 0, 'autoArchiveDays', '0', 'Never')}</div><p class="note">Sessions that are open, running, waiting for input, unread, or in a group are never archived automatically.</p></div>`
      + `<div class="block"><h4 class="block-title">Activity Bar</h4><div class="segmented" role="group" aria-label="Activity Bar icon mode">${pressed(!!b.hideDuplicateIcon, 'toggleDuplicateIcon', 'hide', 'Single unified icon')}${pressed(!b.hideDuplicateIcon, 'toggleDuplicateIcon', 'show', 'Show both icons')}</div></div>`
      + `<div class="block"><h4 class="block-title">Hub &amp; Bridges</h4>`
      + `<div class="bridge-grid"><div class="account-row"><span>Antigravity Multi-Tab &amp; Context Pill</span>${agyPill}</div><div class="account-row"><span>Claude Code Bridge &amp; Webview Tweaks</span>${claudePill}</div></div>`
      + `<div class="button-row">${b.reload ? '<button class="button" data-action="reload">Reload window</button>' : ''}<button class="button" data-action="refresh">Refresh</button><button class="button" data-action="testNotification">Test alert</button><button class="button" data-action="config">Settings</button><button class="button" data-action="repair">Repair bridges</button></div></div>`
    );
  }

  function render() {
    renderSections();
    renderUsage();
    renderPcSetupCard();
    renderQuestions();
    renderBgTasks();
    renderList();
    renderDetails();
  }

  // ---- Events ----------------------------------------------------------
  let listPointerDown = false, listPointerDownAt = 0, listPointerInside = false, pendingRender = false, pointerHoldTimer = null;
  let optimisticActive = null, optimisticActiveTimer = null;
  let rowOrderFreeze = null, freezeReleaseTimer = null, lastRowActivate = null;
  let prevServerOpenKeys = new Set();

  function isPointerPressActive(now = Date.now()) {
    if (!listPointerDown) return false;
    if (now - listPointerDownAt >= 1200) {
      listPointerDown = false;
      return false;
    }
    return true;
  }

  function clearOptimisticActiveTimer() {
    if (optimisticActiveTimer) {
      clearTimeout(optimisticActiveTimer);
      optimisticActiveTimer = null;
    }
  }

  function clearRowOrderFreeze() {
    rowOrderFreeze = null;
    if (freezeReleaseTimer) {
      clearTimeout(freezeReleaseTimer);
      freezeReleaseTimer = null;
    }
  }

  function isRowOrderFreezeHeldByUI(now = Date.now()) {
    if (!rowOrderFreeze || search.trim()) return false;
    if (listPointerInside || isPointerPressActive(now) || renaming) return true;
    const listEl = $('list');
    if (menu && !$('menu')?.hidden && menu.source && listEl?.contains?.(menu.source)) {
      return true;
    }
    return now < rowOrderFreeze.until;
  }

  function scheduleRowOrderFreezeRelease(delayMs = 260, forceShorten = false) {
    if (!rowOrderFreeze) return;
    const now = Date.now();
    const minWait = Math.max(60, Number(delayMs) || 260);
    if (forceShorten && rowOrderFreeze.until > now + minWait) {
      rowOrderFreeze.until = now + minWait;
    }
    const targetAt = Math.max(now + minWait, rowOrderFreeze.until || 0);
    if (freezeReleaseTimer) clearTimeout(freezeReleaseTimer);
    freezeReleaseTimer = setTimeout(() => {
      freezeReleaseTimer = null;
      if (!rowOrderFreeze) return;
      const curNow = Date.now();
      if (isRowOrderFreezeHeldByUI(curNow)) {
        // Pointer is still inside #list, menu is open, or rename is active — keep order pinned!
        return;
      }
      rowOrderFreeze = null;
      if (state && Array.isArray(state.rows) && !isPointerPressActive(curNow)) {
        sortSessionRows(state.rows);
        renderList();
      }
    }, Math.max(60, targetAt - now + 15));
  }

  function freezeCurrentRowOrder(durationMs = 900, reason = 'hover') {
    if (!state || !Array.isArray(state.rows) || !state.rows.length) return;
    const now = Date.now();
    const nextUntil = now + Math.max(150, Number(durationMs) || 900);
    if (rowOrderFreeze && isRowOrderFreezeHeldByUI(now)) {
      if (nextUntil > rowOrderFreeze.until) rowOrderFreeze.until = nextUntil;
      if (reason === 'click') rowOrderFreeze.reason = 'click';
    } else {
      const orderMap = new Map();
      state.rows.forEach((row, idx) => {
        if (!row) return;
        if (row.key) orderMap.set(row.key, idx);
        if (row.uri && !orderMap.has(row.uri)) orderMap.set(row.uri, idx);
      });
      rowOrderFreeze = { orderMap, until: nextUntil, reason };
    }
    if (!listPointerInside) {
      scheduleRowOrderFreezeRelease(nextUntil - now);
    } else if (freezeReleaseTimer) {
      clearTimeout(freezeReleaseTimer);
      freezeReleaseTimer = null;
    }
  }

  function sortSessionRows(rows) {
    if (!Array.isArray(rows)) return;
    const now = Date.now();
    if (rowOrderFreeze && isRowOrderFreezeHeldByUI(now)) {
      const { orderMap } = rowOrderFreeze;
      const getFreezeIndex = row => {
        if (!row) return Number.MAX_SAFE_INTEGER;
        if (row.key && orderMap.has(row.key)) return orderMap.get(row.key);
        if (row.uri && orderMap.has(row.uri)) {
          const inherited = orderMap.get(row.uri);
          if (row.key) orderMap.set(row.key, inherited);
          return inherited;
        }
        const appended = orderMap.size;
        if (row.key) orderMap.set(row.key, appended);
        if (row.uri && !orderMap.has(row.uri)) orderMap.set(row.uri, appended);
        return appended;
      };
      rows.sort((a, b) => {
        const ai = getFreezeIndex(a);
        const bi = getFreezeIndex(b);
        if (ai !== bi) return ai - bi;
        return Number(Boolean(b.open)) - Number(Boolean(a.open)) || Number(Boolean(b.draft)) - Number(Boolean(a.draft)) || (b.at || 0) - (a.at || 0);
      });
      return;
    }
    if (rowOrderFreeze && !isRowOrderFreezeHeldByUI(now)) {
      rowOrderFreeze = null;
    }
    rows.sort((a, b) => Number(Boolean(b.open)) - Number(Boolean(a.open)) || Number(Boolean(b.draft)) - Number(Boolean(a.draft)) || (b.at || 0) - (a.at || 0));
  }

  function stampServerRowBaselines(rows) {
    if (!Array.isArray(rows)) return;
    for (const row of rows) {
      if (!row || typeof row !== 'object') continue;
      row._serverActive = Boolean(row.active);
      row._serverOpen = Boolean(row.open);
      row._serverElsewhere = Boolean(row.elsewhere);
      row._serverUnread = Boolean(row.unread);
      row._serverDot = row.dot ?? null;
    }
  }

  function restoreRowsToServerBaseline(rows) {
    if (!Array.isArray(rows)) return;
    for (const row of rows) {
      if (!row || typeof row !== 'object') continue;
      if ('_serverActive' in row) row.active = Boolean(row._serverActive);
      if ('_serverOpen' in row) row.open = Boolean(row._serverOpen);
      if ('_serverElsewhere' in row) row.elsewhere = Boolean(row._serverElsewhere);
      if ('_serverUnread' in row) row.unread = Boolean(row._serverUnread);
      if ('_serverDot' in row) row.dot = row._serverDot;
    }
  }

  function matchesOptimisticTarget(row, opt) {
    if (!row || !opt) return false;
    if (opt.id && row.id === opt.id) return true;
    if (opt.key && (row.key === opt.key || (row.uri && row.uri === opt.key))) return true;
    return false;
  }

  function applyOptimisticActiveToRows(rows, opt) {
    if (!Array.isArray(rows) || !opt) return;
    restoreRowsToServerBaseline(rows);
    const target = rows.find(row => matchesOptimisticTarget(row, opt));
    if (!target) {
      sortSessionRows(rows);
      return;
    }
    if (target.id && !opt.id) {
      opt.id = target.id;
    }
    if (target.key && opt.key && target.uri === opt.key && target.key !== opt.key) {
      opt.key = target.key;
    }
    for (const row of rows) {
      row.active = row === target;
    }
    target.open = true;
    target.elsewhere = false;
    if (target.unread) {
      target.unread = false;
    }
    if (!target.dot || target.dot === 'unread') {
      target.dot = 'idle';
    }
    sortSessionRows(rows);
  }

  function reconcileOptimisticActive(rows, pendingActiveKey = null) {
    if (!optimisticActive) return;
    const now = Date.now();
    if (now >= optimisticActive.until) {
      optimisticActive = null;
      clearOptimisticActiveTimer();
      restoreRowsToServerBaseline(rows);
      sortSessionRows(rows);
      return;
    }
    if (!Array.isArray(rows)) return;
    const matchedTarget = rows.find(r => matchesOptimisticTarget(r, optimisticActive));
    if (matchedTarget) {
      if (matchedTarget.id && !optimisticActive.id) {
        optimisticActive.id = matchedTarget.id;
      }
      if (matchedTarget.key && optimisticActive.key && matchedTarget.uri === optimisticActive.key && matchedTarget.key !== optimisticActive.key) {
        optimisticActive.key = matchedTarget.key;
      }
    }
    const rawTargetOpen = Boolean(
      matchedTarget && ('_serverOpen' in matchedTarget ? matchedTarget._serverOpen : matchedTarget.open)
    );
    const rawTargetActive = rows.some(r => ('_serverActive' in r ? r._serverActive : r.active) && matchesOptimisticTarget(r, optimisticActive));
    const rawOtherActive = rows.some(r => ('_serverActive' in r ? r._serverActive : r.active) && !matchesOptimisticTarget(r, optimisticActive));
    const isSyntheticServerEcho = Boolean(
      pendingActiveKey &&
      (pendingActiveKey === optimisticActive.id || pendingActiveKey === optimisticActive.key)
    );
    if (rawTargetOpen && !isSyntheticServerEcho) {
      optimisticActive.seenOpen = true;
    } else if (!rawTargetOpen && optimisticActive.seenOpen) {
      optimisticActive = null;
      clearOptimisticActiveTimer();
      restoreRowsToServerBaseline(rows);
      sortSessionRows(rows);
      return;
    }
    if (rawTargetActive && !rawOtherActive) {
      if (!isSyntheticServerEcho) {
        optimisticActive.confirmed = true;
        if (!optimisticActive.confirmedAt) {
          optimisticActive.confirmedAt = now;
        }
      }
      restoreRowsToServerBaseline(rows);
      sortSessionRows(rows);
      return;
    }
    const otherIsOutgoing = rows.some(r => {
      const isSrvActive = '_serverActive' in r ? r._serverActive : r.active;
      if (!isSrvActive || matchesOptimisticTarget(r, optimisticActive)) return false;
      const out = optimisticActive.outgoingKeys;
      if (!(out instanceof Set)) return false;
      return Boolean((r.key && out.has(r.key)) || (r.id && out.has(r.id)) || (r.uri && out.has(r.uri)));
    });
    const canReleaseToOther =
      optimisticActive.confirmed &&
      !rawTargetActive &&
      rawOtherActive &&
      (otherIsOutgoing
        ? optimisticActive.confirmedAt > 0 && now - optimisticActive.confirmedAt > 900
        : now - optimisticActive.setAt > 280);
    if (canReleaseToOther) {
      optimisticActive = null;
      clearOptimisticActiveTimer();
      restoreRowsToServerBaseline(rows);
      sortSessionRows(rows);
      return;
    }
    applyOptimisticActiveToRows(rows, optimisticActive);
  }

  function clearOptimisticActiveIfMatches(idOrKey) {
    if (!optimisticActive || !idOrKey) return;
    if (optimisticActive.id === idOrKey || optimisticActive.key === idOrKey) {
      optimisticActive = null;
      clearOptimisticActiveTimer();
      if (state && Array.isArray(state.rows)) {
        restoreRowsToServerBaseline(state.rows);
      }
    }
  }

  function activateSessionOptimistically(r) {
    if (!r) return;
    if (pointerHoldTimer) {
      clearTimeout(pointerHoldTimer);
      pointerHoldTimer = null;
    }
    listPointerDown = false;
    pendingRender = false;
    const now = Date.now();
    const outgoingKeys = new Set(
      optimisticActive && now < optimisticActive.until && optimisticActive.outgoingKeys instanceof Set
        ? optimisticActive.outgoingKeys
        : []
    );
    if (optimisticActive && now < optimisticActive.until) {
      const samePrev =
        (r.id && optimisticActive.id === r.id) || (r.key && optimisticActive.key === r.key);
      if (!samePrev) {
        if (optimisticActive.id) outgoingKeys.add(optimisticActive.id);
        if (optimisticActive.key) outgoingKeys.add(optimisticActive.key);
      }
    }
    if (state && Array.isArray(state.rows)) {
      for (const row of state.rows) {
        if (!row || row === r) continue;
        if (row.active || row._serverActive) {
          if (row.key) outgoingKeys.add(row.key);
          if (row.id) outgoingKeys.add(row.id);
          if (row.uri) outgoingKeys.add(row.uri);
        }
      }
    }
    if (r.key) outgoingKeys.delete(r.key);
    if (r.id) outgoingKeys.delete(r.id);
    if (r.uri) outgoingKeys.delete(r.uri);

    const wasClosed = !('_serverOpen' in r ? r._serverOpen : r.open);
    if (wasClosed) {
      // Keep the clicked closed row right under the pointer while highlighting it immediately
      // so it never teleports upward mid-click or causes a double-click neighbor misfire.
      freezeCurrentRowOrder(1100, 'click');
    }
    const optObj = {
      key: r.key || '',
      id: r.id || '',
      outgoingKeys,
      setAt: now,
      until: now + 2250,
      seenOpen: !wasClosed,
      confirmed: false,
      confirmedAt: 0
    };
    optimisticActive = optObj;
    clearOptimisticActiveTimer();
    optimisticActiveTimer = setTimeout(() => {
      optimisticActiveTimer = null;
      if (optimisticActive === optObj && Date.now() >= optObj.until) {
        optimisticActive = null;
        if (state && Array.isArray(state.rows) && !isPointerPressActive()) {
          restoreRowsToServerBaseline(state.rows);
          sortSessionRows(state.rows);
          renderList();
        }
      }
    }, 2300);
    if (state && Array.isArray(state.rows)) {
      applyOptimisticActiveToRows(state.rows, optimisticActive);
      renderList();
    }
  }

  window.addEventListener('message', event => {
    if (event.data?.type === 'openDetails') {
      bgInspector = null;
      details = true;
      renderDetails();
      if (event.data.scrollToPcSetup) {
        document.getElementById('pc-setup-details-block')?.scrollIntoView?.({behavior: 'smooth', block: 'nearest'});
      }
      return;
    }
    if (event.data?.type === 'bgTaskDetail') {
      if (bgInspector && bgInspector.sessionId === event.data.sessionId && (bgInspector.task?.id === event.data.task?.id || bgInspector.task?.fullId === event.data.task?.id)) {
        bgInspector.sessionTitle = event.data.sessionTitle || bgInspector.sessionTitle;
        bgInspector.provider = event.data.provider || bgInspector.provider;
        bgInspector.task = {...bgInspector.task, ...(event.data.task || {})};
        bgInspector.output = event.data.output || '';
        bgInspector.loading = false;
        renderDetails();
      }
      return;
    }
    if (event.data?.type !== 'state') return;
    state = event.data;
    stampServerRowBaselines(state.rows);
    const curServerOpenKeys = new Set();
    if (Array.isArray(state.rows)) {
      for (const r of state.rows) {
        if (r && r._serverOpen && r.key) curServerOpenKeys.add(r.key);
      }
    }
    let anyTabClosedOnServer = false;
    if (prevServerOpenKeys.size > 0) {
      for (const k of prevServerOpenKeys) {
        if (!curServerOpenKeys.has(k)) {
          anyTabClosedOnServer = true;
          break;
        }
      }
    }
    prevServerOpenKeys = curServerOpenKeys;
    if (anyTabClosedOnServer && !listPointerInside) {
      clearRowOrderFreeze();
    }
    reconcileOptimisticActive(state.rows, state.pendingActiveKey || null);
    if (!optimisticActive && Array.isArray(state.rows)) {
      sortSessionRows(state.rows);
    }
    providerFilter = state.providerFilter || 'all';
    collapsed = {
      ...collapsed,
      ...state.collapsed,
      accounts: {...(collapsed.accounts || {}), ...(state.collapsed?.accounts || {})}
    };
    if (bgInspector && Array.isArray(state.rows)) {
      const sRow = state.rows.find(r => r.id === bgInspector.sessionId);
      const sTask = sRow?.bgTasks?.find(t => t.id === bgInspector.task?.id || t.fullId === bgInspector.task?.id);
      if (sTask) {
        bgInspector.task = {...bgInspector.task, ...sTask};
      }
    }
    if (switchingAccountId) {
      const swProv = switchingAccountId.startsWith('claude:') ? 'claude' : 'antigravity';
      const swModel = findAccountModel(switchingAccountId, swProv);
      if (!swModel || swModel.active !== false) {
        switchingAccountId = '';
      }
    }
    filter = {statuses: [...state.filter.statuses], tabStates: [...state.filter.tabStates], activeOnly: !!state.filter.activeOnly};
    if (state.editGroup && !renaming) renaming = {kind: 'group', id: state.editGroup, started: false};
    if (isPointerPressActive()) {
      pendingRender = true;
      renderDetails();
      return;
    }
    pendingRender = false;
    render();
  });
  const clearPointerHold = () => {
    if (!listPointerDown) return;
    listPointerDown = false;
    if (pendingRender) {
      pendingRender = false;
      if (pointerHoldTimer) clearTimeout(pointerHoldTimer);
      pointerHoldTimer = setTimeout(() => {
        pointerHoldTimer = null;
        if (!isPointerPressActive()) {
          render();
        }
      }, 35);
    }
  };
  document.addEventListener('pointerdown', event => {
    if (event.button !== undefined && event.button !== 0) return;
    const interactive = event.target?.closest?.('.session-item, .group-header, button, [role="button"]');
    if (interactive && !event.target?.closest?.('.modal')) {
      listPointerDown = true;
      listPointerDownAt = Date.now();
    }
  }, true);
  window.addEventListener('pointerup', clearPointerHold, true);
  window.addEventListener('pointercancel', clearPointerHold, true);
  window.addEventListener('dragstart', clearPointerHold, true);
  window.addEventListener('blur', () => {
    clearPointerHold();
    if (!listPointerInside) {
      scheduleRowOrderFreezeRelease(80, true);
    }
  });
  document.addEventListener('input', event => {
    const inp = event.target?.closest?.('.sb-q-other-input');
    if (!inp) return;
    const sid = inp.dataset.sessionId;
    const qi = Number(inp.dataset.qIndex || 0);
    if (!sid) return;
    const row = state?.rows?.find(r => r.id === sid);
    const qList = row ? getNormalizedRowQuestions(row) : [];
    const draft = getQuestionDraft(sid, Math.max(1, qList.length));
    draft.other[qi] = inp.value;
  });
  document.addEventListener('keydown', event => {
    const inp = event.target?.closest?.('.sb-q-other-input');
    if (inp && event.key === 'Enter') {
      event.preventDefault();
      event.stopPropagation();
      const sid = inp.dataset.sessionId;
      const row = state?.rows?.find(r => r.id === sid);
      if (sid) submitSidebarQuestion(sid, row?.provider || 'antigravity', false);
    }
  });
  document.addEventListener('click', event => {
    const acctMenuBtn = event.target.closest('[data-account-menu]');
    if (acctMenuBtn) {
      const acctId = acctMenuBtn.dataset.accountMenu;
      const prov = acctMenuBtn.dataset.provider || (acctId.startsWith('claude:') ? 'claude' : 'antigravity');
      if (menu && menu.button === acctMenuBtn) return closeMenu();
      const box = acctMenuBtn.getBoundingClientRect();
      return openMenu(() => accountMenu(acctId, prov), Math.max(8, box.right - 210), box.bottom + 4, {button: acctMenuBtn});
    }
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const {action, section, value, provider, accountId, sessionId, taskId} = button.dataset;
    if (action === 'openQuestionSession') {
      if (sessionId) {
        const targetRow = state?.rows?.find(r => r.id === sessionId);
        if (targetRow) activateSessionOptimistically(targetRow);
        send({action: 'open', id: sessionId, provider: provider || targetRow?.provider || 'antigravity'});
      }
      return;
    }
    if (action === 'selectSidebarQuestionOpt') {
      event.stopPropagation();
      if (!sessionId) return;
      const qi = Number(button.dataset.qIndex || 0);
      const oi = Number(button.dataset.optIndex || 0);
      const isMulti = button.dataset.multi === '1';
      const row = state?.rows?.find(r => r.id === sessionId);
      const qList = row ? getNormalizedRowQuestions(row) : [];
      const q = qList[qi];
      if (!q || !q.options?.[oi]) return;
      const optLabel = q.options[oi];
      const draft = getQuestionDraft(sessionId, Math.max(1, qList.length));
      const cur = draft.selected[qi] || [];
      if (isMulti) {
        draft.selected[qi] = cur.includes(optLabel) ? cur.filter(x => x !== optLabel) : [...cur, optLabel];
      } else {
        draft.selected[qi] = cur.includes(optLabel) && cur.length === 1 ? [] : [optLabel];
      }
      renderQuestions(true);
      return;
    }
    if (action === 'skipSidebarQuestion') {
      event.stopPropagation();
      if (sessionId) submitSidebarQuestion(sessionId, provider, true);
      return;
    }
    if (action === 'submitSidebarQuestion') {
      event.stopPropagation();
      if (sessionId) submitSidebarQuestion(sessionId, provider, false);
      return;
    }
    if (action === 'cancelBgTask') {
      event.stopPropagation();
      if (sessionId && taskId) {
        const sRow = state?.rows?.find(r => r.id === sessionId);
        const sTask = sRow?.bgTasks?.find(t => t.id === taskId || t.fullId === taskId);
        if (sTask) {
          sTask.state = 'cancelled';
          if (sRow.bgRunningCount > 0) sRow.bgRunningCount--;
        }
        if (bgInspector && bgInspector.sessionId === sessionId && bgInspector.task?.id === taskId) {
          bgInspector.task.state = 'cancelled';
        }
        renderBgTasks();
        renderList();
        renderDetails();
        send({action: 'cancelBgTask', sessionId, taskId, provider});
      }
      return;
    }
    if (action === 'cancelAllBgTasks') {
      event.stopPropagation();
      send({action: 'cancelAllBgTasks', sessionId: pinnedBgSessionId || ''});
      return;
    }
    if (action === 'clearPinnedBgSession') {
      pinnedBgSessionId = '';
      renderBgTasks();
      return;
    }
    if (action === 'inspectBgTask') {
      if (sessionId && taskId) {
        openBgTaskInspector(sessionId, taskId, provider);
      }
      return;
    }
    if (action === 'refreshBgTaskLog') {
      if (bgInspector) {
        bgInspector.loading = true;
        send({action: 'inspectBgTask', sessionId: bgInspector.sessionId, taskId: bgInspector.task.id, provider: bgInspector.provider});
      }
      return;
    }
    if (action === 'openBgTaskSession') {
      if (bgInspector?.sessionId) {
        const sid = bgInspector.sessionId, prov = bgInspector.provider;
        const targetRow = state?.rows?.find(r => r.id === sid);
        bgInspector = null;
        renderDetails();
        if (targetRow) activateSessionOptimistically(targetRow);
        send({action: 'open', id: sid, provider: prov});
      }
      return;
    }
    if (action === 'toggleAddAccount') {
      return addTrayOpen ? closeAddAccountTray() : openAddAccountTray();
    }
    if (action === 'closeAddAccount') {
      return closeAddAccountTray();
    }
    if (action === 'openAddFromDetails') {
      details = false;
      renderDetails();
      return openAddAccountTray(provider);
    }
    if (action === 'selectAddProvider') {
      addTrayProvider = provider === 'claude' ? 'claude' : 'antigravity';
      return renderAddAccountTray(true);
    }
    if (action === 'submitAddAccount') {
      return submitAddAccountForm();
    }
    if (
      action === 'accountCancelAdd' ||
      action === 'accountFocusTerminal' ||
      action === 'accountContinueVerification' ||
      action === 'accountOpenAuthUrl'
    ) {
      return send({action});
    }
    if (action === 'accountCollapse') {
      if (!collapsed.accounts) collapsed.accounts = {};
      const curAcct = findAccountModel(accountId, provider);
      const curVal = typeof collapsed.accounts[accountId] === 'boolean'
        ? collapsed.accounts[accountId]
        : Boolean(curAcct?.collapsed);
      collapsed.accounts[accountId] = !curVal;
      persist();
      send({action: 'accountCollapse', accountId, value: collapsed.accounts[accountId]});
      return renderUsage();
    }
    if (action === 'accountSwitch') {
      return triggerAccountSwitch(accountId, provider);
    }
    if (action === 'accountMove') {
      event.stopPropagation();
      const dir = button.dataset.dir;
      if (accountId && (dir === 'up' || dir === 'down')) {
        moveAccountCard(accountId, {provider, direction: dir});
      }
      return;
    }
    if (action === 'accountNewSession') {
      return send({action: 'accountNewSession', accountId, provider, beside: Boolean(event.altKey || event.shiftKey)});
    }
    if (action === 'accountPromptLabel') {
      return send({action: 'accountLabel', accountId, provider, prompt: true});
    }
    if (action === 'accountRemove') {
      return send({action: 'accountRemove', accountId, provider, confirm: true});
    }
    if (action === 'startEditAccountLabel') {
      return openInlineAccountLabel(accountId);
    }
    if (action === 'saveAccountLabel') {
      return commitInlineAccountLabel(true);
    }
    if (action === 'cancelAccountLabel') {
      return commitInlineAccountLabel(false);
    }
    if (action === 'collapse') {
      collapsed[section] = !collapsed[section];
      persist();
      send({action, section, value: collapsed[section]});
      return render();
    }
    if (action === 'new') {
      clearRowOrderFreeze();
      if (!event.altKey && !event.shiftKey) optimisticActive = null;
      return send({action: 'new', provider: provider || 'antigravity', beside: Boolean(event.altKey || event.shiftKey)});
    }
    if (action === 'providerFilter') {
      clearRowOrderFreeze();
      providerFilter = value || 'all';
      send({action: 'providerFilter', value: providerFilter});
      renderQuestions();
      renderBgTasks();
      return renderList();
    }
    if (action === 'details') { bgInspector = null; details = true; send({action}); return renderDetails(); }
    if (action === 'openPcSetupDetails') {
      bgInspector = null;
      details = true;
      renderDetails();
      document.getElementById('pc-setup-details-block')?.scrollIntoView?.({behavior: 'smooth', block: 'nearest'});
      send({action: 'checkPcSetup'});
      return;
    }
    if (action === 'closeDetails') { details = false; bgInspector = null; return renderDetails(); }
    if (action === 'period') { period = value; persist(); return renderDetails(); }
    if (action === 'activityProvider') { activityProvider = value; persist(); return renderDetails(); }
    if (action === 'autoArchiveDays') {
      return send({action: 'autoArchiveDays', value: Number(value)});
    }
    if (action === 'toggleDuplicateIcon') {
      return send({action: 'toggleDuplicateIcon', visible: value === 'show'});
    }
    if (action === 'scope') return send({action, value});
    send({action});
  });
  $('dialog').addEventListener('click', event => { if (event.target === $('dialog')) { details = false; bgInspector = null; renderDetails(); } });
  $('filter-button').addEventListener('click', () => {
    if (menu && menu.button === $('filter-button')) return closeMenu();
    const box = $('filter-button').getBoundingClientRect();
    openMenu(filterMenu, box.left, box.bottom + 2, {button: $('filter-button')});
  });
  $('active-toggle').addEventListener('click', () => {
    clearRowOrderFreeze();
    filter = {...filter, activeOnly: !filter.activeOnly};
    send({action: 'filter', filter});
    renderList();
  });
  $('search').value = search;
  $('search').addEventListener('input', event => { clearRowOrderFreeze(); search = event.target.value; persist(); renderList(); });
  $('search').addEventListener('keydown', event => {
    if (event.key === 'Escape' && search) { event.stopPropagation(); clearRowOrderFreeze(); search = $('search').value = ''; persist(); renderList(); }
    else if (event.key === 'ArrowDown') { event.preventDefault(); $('list').querySelector('.session-item, .group-header')?.focus(); }
  });
  $('search-clear').addEventListener('click', () => { clearRowOrderFreeze(); search = $('search').value = ''; persist(); renderList(); $('search').focus(); });

  const list = $('list');
  list.addEventListener('pointerenter', () => {
    listPointerInside = true;
    if (state && Array.isArray(state.rows) && state.rows.length > 1) {
      freezeCurrentRowOrder(900, 'hover');
    }
  });
  list.addEventListener('pointerdown', event => {
    if (event.button !== undefined && event.button !== 0) return;
    listPointerDown = true;
    listPointerDownAt = Date.now();
    listPointerInside = true;
    freezeCurrentRowOrder(950, 'hover');
  }, true);
  list.addEventListener('pointermove', () => {
    listPointerInside = true;
    if (state && Array.isArray(state.rows) && state.rows.length > 1) {
      freezeCurrentRowOrder(900, 'hover');
    }
  }, { passive: true });
  list.addEventListener('pointerleave', () => {
    listPointerInside = false;
    scheduleRowOrderFreezeRelease(140, true);
  });
  function rowAction(name, r) {
    if (name === 'question') {
      if (collapsed.questions) {
        collapsed.questions = false;
        persist();
        send({action: 'collapse', section: 'questions', value: false});
      }
      renderSections();
      renderQuestions(true);
      const qCard = $('questions-body')?.querySelector?.(`.sb-q-card[data-session-id="${r.id}"]`);
      (qCard || $('questions-header'))?.scrollIntoView?.({behavior: 'smooth', block: 'nearest'});
      return;
    }
    if (name === 'bgTasks') {
      focusSessionBgTasks(r);
      return;
    }
    if (name === 'stop') {
      r.dot = r.open ? 'idle' : null;
      r.status = 'completed';
      r.category = 'completed';
      r.unread = false;
      r.elsewhere = false;
      r.reason = null;
      renderList();
      send({action: 'stop', id: r.id, key: r.key, provider: r.provider});
    } else if (name === 'rename') startRename('session', r.key);
    else if (name === 'close') {
      clearRowOrderFreeze();
      clearOptimisticActiveIfMatches(r.id || r.key);
      send({action: 'closeTab', key: r.key, id: r.id, provider: r.provider});
    } else if (name === 'unassign') {
      clearRowOrderFreeze();
      const prevGrp = r.group;
      r.group = null;
      renderList();
      send({action: 'groupRemove', ids: [r.id], group: prevGrp});
    } else {
      clearRowOrderFreeze();
      const archiving = name === 'archive';
      if (archiving) clearOptimisticActiveIfMatches(r.id || r.key);
      r.archived = archiving;
      if (archiving) r.group = null;
      renderList();
      send({action: 'archive', ids: [r.id], value: archiving});
    }
  }
  function groupAction(name, header, event) {
    clearRowOrderFreeze();
    if (name === 'new') {
      optimisticActive = null;
      const groupId = header.dataset.group;
      const hasAgy = hasSignedInProvider('antigravity');
      const hasClaude = hasSignedInProvider('claude');
      if ((providerFilter === 'antigravity' && hasAgy) || (hasAgy && !hasClaude)) {
        send({action: 'newInGroup', group: groupId, provider: 'antigravity'});
      } else if ((providerFilter === 'claude' && hasClaude) || (hasClaude && !hasAgy)) {
        send({action: 'newInGroup', group: groupId, provider: 'claude'});
      } else if (hasAgy && hasClaude) {
        const box = (event?.target?.closest('[data-group-action]') || header).getBoundingClientRect();
        openMenu(() => [
          {label: 'New Antigravity session', glyph: providerIcons.antigravity, run: () => send({action: 'newInGroup', group: groupId, provider: 'antigravity'})},
          {label: 'New Claude Code session', glyph: providerIcons.claude, run: () => send({action: 'newInGroup', group: groupId, provider: 'claude'})}
        ], box.left, box.bottom + 2, {source: header});
      }
    } else if (name === 'archiveUngroupedClosed') {
      const groupIds = new Set((state?.groups || []).map(g => g.id));
      const ids = (state?.rows || [])
        .filter(r => r.id && !r.archived && !r.open && r.status !== 'working' && r.status !== 'waiting' && !r.unread && (!r.group || !groupIds.has(r.group)) && matchesProvider(r))
        .map(r => r.id);
      if (ids.length) send({action: 'archive', ids, value: true});
    } else if (name === 'unarchiveAll') {
      send({action: 'archive', ids: state.rows.filter(r => r.archived && matchesProvider(r)).map(r => r.id), value: false});
    }
  }
  function toggleHeader(header) {
    if (header.dataset.fixed) return;
    clearRowOrderFreeze();
    const expanded = header.getAttribute('aria-expanded') === 'true';
    if (header.dataset.group) {
      const g = state.groups.find(g => g.id === header.dataset.group);
      if (g) g.collapsed = expanded;
      send({action: 'groupToggle', group: header.dataset.group, value: expanded});
    } else {
      collapsed[header.dataset.section] = expanded;
      send({action: 'collapse', section: header.dataset.section, value: expanded});
    }
    renderList();
  }
  function activate(event) {
    if (pointerHoldTimer) {
      clearTimeout(pointerHoldTimer);
      pointerHoldTimer = null;
    }
    listPointerDown = false;
    pendingRender = false;
    if (renaming) return;
    const item = event.target.closest('.session-item'), header = event.target.closest('.group-header');
    const rowButton = event.target.closest('[data-row-action]'), groupButton = event.target.closest('[data-group-action]');
    if (rowButton && item) { const r = rowByKey(item.dataset.key); if (r) rowAction(rowButton.dataset.rowAction, r); }
    else if (groupButton && header) groupAction(groupButton.dataset.groupAction, header, event);
    else if (header) toggleHeader(header);
    else if (item) {
      const r = rowByKey(item.dataset.key);
      if (r) {
        const beside = Boolean(event.altKey || event.shiftKey);
        const now = Date.now();
        if (
          !beside &&
          lastRowActivate &&
          lastRowActivate.key === r.key &&
          now - lastRowActivate.at < 450 &&
          Number(event.detail || 1) >= 2
        ) {
          return;
        }
        lastRowActivate = { key: r.key, id: r.id || '', at: now };
        if (!beside) {
          activateSessionOptimistically(r);
        }
        if (r.id) {
          send({action: beside ? 'beside' : 'open', id: r.id, provider: r.provider});
        } else {
          send({action: 'focus', key: r.key, provider: r.provider, beside});
        }
      }
    }
  }
  list.addEventListener('click', activate);
  function contextFor(target, x, y) {
    const item = target.closest('.session-item'), header = target.closest('.group-header');
    if (item && rowByKey(item.dataset.key)) {
      const key = item.dataset.key;
      openMenu(() => { const r = rowByKey(key); return r ? sessionMenu(r) : []; }, x, y, {source: item});
    } else if (header && header.dataset.group) {
      const g = state.groups.find(g => g.id === header.dataset.group);
      if (g) openMenu(() => groupMenu(g), x, y, {source: header});
    } else return false;
    return true;
  }
  list.addEventListener('contextmenu', event => {
    if (!renaming && contextFor(event.target, event.clientX, event.clientY)) event.preventDefault();
  });
  list.addEventListener('keydown', event => {
    if (renaming) return;
    const focusable = [...list.querySelectorAll('.session-item, .group-header')], current = event.target.closest('.session-item, .group-header');
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      const next = focusable[focusable.indexOf(current) + (event.key === 'ArrowDown' ? 1 : -1)];
      if (next) next.focus(); else if (event.key === 'ArrowUp') $('search').focus();
    } else if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('[role=button]')) {
      event.preventDefault();
      activate(event);
    } else if (event.key === 'F2' && current) {
      event.preventDefault();
      const r = current.dataset.key ? rowByKey(current.dataset.key) : null;
      if (current.dataset.group) startRename('group', current.dataset.group);
      else if (r && r.id && !r.archived) startRename('session', r.key);
    } else if (event.key === 'Delete' && current && current.dataset.key) {
      const r = rowByKey(current.dataset.key);
      if (r && r.id && !r.archived) {
        event.preventDefault();
        rowAction(r.group ? 'unassign' : 'archive', r);
      }
    } else if ((event.key === 'ContextMenu' || (event.key === 'F10' && event.shiftKey)) && current) {
      event.preventDefault();
      const box = current.getBoundingClientRect();
      contextFor(current, box.left + 24, box.bottom);
    }
  });
  document.addEventListener('mouseover', event => {
    const qHover = event.target?.closest?.('[data-q-hover]');
    if (qHover) {
      if (bgHoverTimer) clearTimeout(bgHoverTimer);
      bgHoverTimer = setTimeout(() => showQuestionHoverCard(qHover), 120);
      return;
    }
    const hoverTarget = event.target?.closest?.('[data-bg-hover]');
    if (!hoverTarget) {
      hideBgHoverCard();
      return;
    }
    if (bgHoverTimer) clearTimeout(bgHoverTimer);
    bgHoverTimer = setTimeout(() => showBgHoverCard(hoverTarget), 120);
  });
  document.addEventListener('mouseleave', hideBgHoverCard);
  document.addEventListener('scroll', hideBgHoverCard, true);
  document.addEventListener('mousedown', hideBgHoverCard);
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    if (menu) { const source = menu.button || menu.source; closeMenu(); source?.focus?.(); }
    else if (editingAccountId) { commitInlineAccountLabel(false); }
    else if (addTrayOpen) { closeAddAccountTray(); }
    else if (details || bgInspector) { details = false; bgInspector = null; renderDetails(); }
  });

  let draggedAccountId = '';
  const clearAccountDragIndicators = () => {
    for (const el of document.querySelectorAll('.provider-card.dragging, .provider-card.drag-over-top, .provider-card.drag-over-bottom')) {
      el.classList.remove('dragging', 'drag-over-top', 'drag-over-bottom');
    }
  };
  document.addEventListener('dragstart', event => {
    const card = event.target?.closest?.('.provider-card[data-account-card][draggable="true"]');
    if (!card) return;
    if (event.target?.closest?.('input, textarea')) {
      event.preventDefault();
      return;
    }
    draggedAccountId = card.dataset.accountCard || '';
    if (!draggedAccountId) return;
    card.classList.add('dragging');
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
      try {
        event.dataTransfer.setData('text/plain', draggedAccountId);
      } catch {}
    }
  });
  document.addEventListener('dragover', event => {
    if (!draggedAccountId) return;
    const card = event.target?.closest?.('.provider-card[data-account-card]');
    if (!card) return;
    event.preventDefault();
    const targetId = card.dataset.accountCard || '';
    if (!targetId || targetId === draggedAccountId) return;
    for (const el of document.querySelectorAll('.provider-card.drag-over-top, .provider-card.drag-over-bottom')) {
      if (el !== card) el.classList.remove('drag-over-top', 'drag-over-bottom');
    }
    const rect = card.getBoundingClientRect();
    const isBottom = event.clientY >= rect.top + rect.height / 2;
    card.classList.toggle('drag-over-top', !isBottom);
    card.classList.toggle('drag-over-bottom', isBottom);
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  });
  document.addEventListener('dragleave', event => {
    const card = event.target?.closest?.('.provider-card[data-account-card]');
    if (card && !card.contains(event.relatedTarget)) {
      card.classList.remove('drag-over-top', 'drag-over-bottom');
    }
  });
  document.addEventListener('drop', event => {
    if (!draggedAccountId) return;
    const card = event.target?.closest?.('.provider-card[data-account-card]');
    const sourceId = draggedAccountId;
    draggedAccountId = '';
    if (!card) {
      clearAccountDragIndicators();
      return;
    }
    event.preventDefault();
    const targetId = card.dataset.accountCard || '';
    const rect = card.getBoundingClientRect();
    const position = event.clientY >= rect.top + rect.height / 2 ? 'after' : 'before';
    clearAccountDragIndicators();
    if (targetId && targetId !== sourceId) {
      moveAccountCard(sourceId, {
        provider: sourceId.startsWith('claude:') ? 'claude' : 'antigravity',
        targetAccountId: targetId,
        position
      });
    }
  });
  document.addEventListener('dragend', () => {
    draggedAccountId = '';
    clearAccountDragIndicators();
  });

  setInterval(() => {
    if (!state || document.hidden) return;
    if (bgInspector && bgInspector.task?.state === 'running') {
      send({action: 'inspectBgTask', sessionId: bgInspector.sessionId, taskId: bgInspector.task.id, provider: bgInspector.provider});
    }
    renderDetails();
    if (isPointerPressActive()) {
      pendingRender = true;
      return;
    }
    renderUsage();
    renderPcSetupCard();
    if (Array.isArray(state.rows)) {
      reconcileOptimisticActive(state.rows, state.pendingActiveKey || null);
      if (!optimisticActive && rowOrderFreeze) {
        sortSessionRows(state.rows);
      }
    }
    renderQuestions();
    renderBgTasks();
    renderList();
  }, 5000);
  send({action: 'ready'});
})();
