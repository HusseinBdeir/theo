using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using Microsoft.Win32;

[assembly: AssemblyTitle("THEO")]
[assembly: AssemblyDescription("THEO - AI Session Workbench")]
[assembly: AssemblyCompany("BHFIRMS")]
[assembly: AssemblyProduct("THEO")]
[assembly: AssemblyCopyright("Copyright (c) BHFIRMS")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace TheoDesktopLauncher
{
    internal static class Program
    {
        private const string DEFAULT_AUMID = "BHFIRMS.THEO.Desktop";
        private const string DEFAULT_FALLBACK_URL = "https://husseinbdeir.github.io/theo/";
        private const int SW_RESTORE = 9;
        private const int SW_SHOW = 5;
        private const uint WM_SETICON = 0x0080;
        private const uint IMAGE_ICON = 1;
        private const uint LR_LOADFROMFILE = 0x00000010;

        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool IsIconic(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool BringWindowToTop(IntPtr hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr LoadImage(IntPtr hinst, string lpszName, uint uType, int cxDesired, int cyDesired, uint fuLoad);

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        private struct LASTINPUTINFO
        {
            public uint cbSize;
            public uint dwTime;
        }

        [DllImport("user32.dll")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        private static extern int SetCurrentProcessExplicitAppUserModelID(string AppID);

        [DllImport("shell32.dll")]
        private static extern int SHGetPropertyStoreForWindow(
            IntPtr hwnd,
            ref Guid iid,
            [Out, MarshalAs(UnmanagedType.Interface)] out IPropertyStore propStore);

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")]
        private interface IPropertyStore
        {
            int GetCount(out uint cProps);
            int GetAt(uint iProp, out PROPERTYKEY pkey);
            int GetValue(ref PROPERTYKEY key, out PropVariant pv);
            int SetValue(ref PROPERTYKEY key, ref PropVariant pv);
            int Commit();
        }

        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        private struct PROPERTYKEY
        {
            public Guid fmtid;
            public uint pid;
            public PROPERTYKEY(string guid, uint id)
            {
                fmtid = new Guid(guid);
                pid = id;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct PropVariant
        {
            public ushort vt;
            public ushort wReserved1;
            public ushort wReserved2;
            public ushort wReserved3;
            public IntPtr ptr;
            public int dummy;

            public static PropVariant FromString(string val)
            {
                PropVariant pv = new PropVariant();
                pv.vt = 31; // VT_LPWSTR
                pv.ptr = Marshal.StringToCoTaskMemUni(val ?? string.Empty);
                return pv;
            }

            public void Free()
            {
                if (vt == 31 && ptr != IntPtr.Zero)
                {
                    Marshal.FreeCoTaskMem(ptr);
                    ptr = IntPtr.Zero;
                    vt = 0;
                }
            }
        }

        private sealed class LaunchConfig
        {
            public string Url;
            public string BrowserPath;
            public string ProfileDir;
            public string IconPath;
            public string LauncherExePath;
            public string KeepaliveScriptPath;
            public string AppUserModelId;
            public string WindowStatePath;
        }

        [STAThread]
        public static int Main(string[] args)
        {
            if (args != null && args.Length == 1 && string.Equals(args[0], "--idle-ms", StringComparison.OrdinalIgnoreCase))
            {
                LASTINPUTINFO lii = new LASTINPUTINFO();
                lii.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
                if (!GetLastInputInfo(ref lii))
                {
                    Console.WriteLine("-1");
                    return 1;
                }
                uint nowTick = unchecked((uint)Environment.TickCount);
                uint elapsed = unchecked(nowTick - lii.dwTime);
                Console.WriteLine(elapsed.ToString());
                return 0;
            }

            bool verifyOnly = false;
            string customStateFile = "";
            if (args != null)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    string a = args[i] ?? "";
                    if (string.Equals(a, "--verify-config", StringComparison.OrdinalIgnoreCase))
                    {
                        verifyOnly = true;
                    }
                    else if (string.Equals(a, "--state-file", StringComparison.OrdinalIgnoreCase) && i + 1 < args.Length)
                    {
                        customStateFile = args[++i] ?? "";
                    }
                }
            }

            string smokeEnv = Environment.GetEnvironmentVariable("THEO_SMOKE_TEST") ?? "";
            string headlessEnv = Environment.GetEnvironmentVariable("THEO_HEADLESS_TEST") ?? "";
            if ((smokeEnv == "1" || headlessEnv == "1") && !verifyOnly)
            {
                Console.Error.WriteLine("Quarantine active: refusing live GUI launch under THEO_SMOKE_TEST=1 without --verify-config");
                return 2;
            }

            try
            {
                LaunchConfig cfg = ResolveConfig(customStateFile);
                try
                {
                    SetCurrentProcessExplicitAppUserModelID(cfg.AppUserModelId);
                }
                catch { }

                if (verifyOnly)
                {
                    JavaScriptSerializer ser = new JavaScriptSerializer();
                    Dictionary<string, object> result = new Dictionary<string, object>();
                    result["ok"] = true;
                    result["url"] = cfg.Url;
                    result["browserPath"] = cfg.BrowserPath;
                    result["profileDir"] = cfg.ProfileDir;
                    result["iconPath"] = cfg.IconPath;
                    result["launcherExePath"] = cfg.LauncherExePath;
                    result["appUserModelId"] = cfg.AppUserModelId;
                    result["supportsIdleMs"] = true;
                    Console.WriteLine(ser.Serialize(result));
                    return 0;
                }

                bool createdNew = false;
                using (Mutex mtx = new Mutex(true, @"Local\BHFIRMS_THEO_Desktop_Launcher_v2", out createdNew))
                {
                    if (!createdNew)
                    {
                        try
                        {
                            mtx.WaitOne(2500);
                        }
                        catch (AbandonedMutexException) { }
                    }

                    IntPtr existingHwnd = FindExistingTheoWindow(cfg, 0);
                    if (existingHwnd != IntPtr.Zero)
                    {
                        StampWindowIdentityAndIcon(existingHwnd, cfg);
                        FocusWindow(existingHwnd);
                        return 0;
                    }

                    EnsureLocalBridgeListening(cfg);
                    PrepareIsolatedProfile(cfg.ProfileDir);

                    string browserArgs = BuildBrowserArguments(cfg);
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = cfg.BrowserPath;
                    psi.Arguments = browserArgs;
                    psi.WorkingDirectory = Path.GetDirectoryName(cfg.BrowserPath) ?? Environment.CurrentDirectory;
                    psi.UseShellExecute = false;

                    Process proc = Process.Start(psi);
                    uint spawnedPid = (proc != null) ? (uint)proc.Id : 0;

                    IntPtr newHwnd = IntPtr.Zero;
                    Stopwatch sw = Stopwatch.StartNew();
                    while (sw.ElapsedMilliseconds < 8000)
                    {
                        newHwnd = FindExistingTheoWindow(cfg, spawnedPid);
                        if (newHwnd != IntPtr.Zero)
                        {
                            break;
                        }
                        Thread.Sleep(80);
                    }

                    if (newHwnd != IntPtr.Zero)
                    {
                        uint winPid = 0;
                        GetWindowThreadProcessId(newHwnd, out winPid);
                        SaveWindowState(cfg.WindowStatePath, winPid, newHwnd);
                        StampWindowIdentityAndIcon(newHwnd, cfg);
                        FocusWindow(newHwnd);

                        int[] delays = new int[] { 400, 900 };
                        for (int i = 0; i < delays.Length; i++)
                        {
                            Thread.Sleep(delays[i]);
                            if (IsWindowVisible(newHwnd))
                            {
                                StampWindowIdentityAndIcon(newHwnd, cfg);
                            }
                        }
                    }
                }
                return 0;
            }
            catch (Exception ex)
            {
                if (verifyOnly)
                {
                    Console.Error.WriteLine(ex.Message);
                }
                return 1;
            }
        }

        private static LaunchConfig ResolveConfig(string customStateFile)
        {
            string homeDir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (string.IsNullOrEmpty(homeDir))
            {
                homeDir = Environment.ExpandEnvironmentVariables("%USERPROFILE%");
            }
            string theoDir = Path.Combine(homeDir, ".theo");
            string stateFile = !string.IsNullOrEmpty(customStateFile)
                ? customStateFile
                : Path.Combine(theoDir, "desktop-shortcut.json");

            JavaScriptSerializer ser = new JavaScriptSerializer();
            Dictionary<string, object> saved = null;
            if (File.Exists(stateFile))
            {
                try
                {
                    saved = ser.Deserialize<Dictionary<string, object>>(File.ReadAllText(stateFile, Encoding.UTF8));
                }
                catch { }
            }

            string rawUrl = GetDictString(saved, "url");
            string validUrl = ValidateDesktopAppUrl(rawUrl);
            if (string.IsNullOrEmpty(validUrl))
            {
                int port = 4318;
                string credFile = Path.Combine(theoDir, "credentials.json");
                if (File.Exists(credFile))
                {
                    try
                    {
                        Dictionary<string, object> creds = ser.Deserialize<Dictionary<string, object>>(File.ReadAllText(credFile, Encoding.UTF8));
                        int parsedPort = GetDictInt(creds, "port", 4318);
                        if (parsedPort >= 1 && parsedPort <= 65535) port = parsedPort;
                    }
                    catch { }
                }
                string localIndex = Path.Combine(homeDir, "bhfirms", "theo", "index.html");
                if (File.Exists(localIndex))
                {
                    validUrl = string.Format("http://127.0.0.1:{0}/", port);
                }
                else
                {
                    validUrl = DEFAULT_FALLBACK_URL;
                }
            }

            string rawBrowser = GetDictString(saved, "browserPath");
            string browserPath = FindBrowserExecutable(rawBrowser);
            if (string.IsNullOrEmpty(browserPath))
            {
                throw new InvalidOperationException("Could not locate Google Chrome or Microsoft Edge executable.");
            }

            string profileDir = GetDictString(saved, "profileDir");
            if (string.IsNullOrEmpty(profileDir))
            {
                profileDir = Path.Combine(theoDir, "app-profile");
            }

            string iconPath = GetDictString(saved, "iconPath");
            if (string.IsNullOrEmpty(iconPath) || !File.Exists(iconPath))
            {
                iconPath = Path.Combine(theoDir, "theo.ico");
            }

            string launcherExePath = GetDictString(saved, "launcherExePath");
            if (string.IsNullOrEmpty(launcherExePath))
            {
                try
                {
                    launcherExePath = Assembly.GetExecutingAssembly().Location;
                }
                catch { }
                if (string.IsNullOrEmpty(launcherExePath))
                {
                    launcherExePath = Path.Combine(theoDir, "THEO.exe");
                }
            }

            string keepaliveScript = GetDictString(saved, "keepaliveScriptPath");
            if (string.IsNullOrEmpty(keepaliveScript) || !File.Exists(keepaliveScript))
            {
                string bestExtPs1 = null;
                DateTime bestWriteUtc = DateTime.MinValue;
                string vscodeExtRoot = Path.Combine(homeDir, ".vscode", "extensions");
                if (Directory.Exists(vscodeExtRoot))
                {
                    try
                    {
                        foreach (string dir in Directory.GetDirectories(vscodeExtRoot, "bhfirms.theo-hub-*"))
                        {
                            string candPs1 = Path.Combine(dir, "scripts", "relay_keepalive_start.ps1");
                            if (File.Exists(candPs1))
                            {
                                DateTime wt = File.GetLastWriteTimeUtc(candPs1);
                                if (bestExtPs1 == null || wt >= bestWriteUtc)
                                {
                                    bestExtPs1 = candPs1;
                                    bestWriteUtc = wt;
                                }
                            }
                        }
                    }
                    catch { }
                }
                string candRepo = Path.Combine(homeDir, "bhfirms", "theo-hub", "scripts", "relay_keepalive_start.ps1");
                if (!string.IsNullOrEmpty(bestExtPs1)) keepaliveScript = bestExtPs1;
                else if (File.Exists(candRepo)) keepaliveScript = candRepo;
            }

            string configuredAumid = GetDictString(saved, "appUserModelId");
            if (string.IsNullOrEmpty(configuredAumid))
            {
                configuredAumid = DEFAULT_AUMID;
            }

            LaunchConfig cfg = new LaunchConfig();
            cfg.Url = validUrl;
            cfg.BrowserPath = browserPath;
            cfg.ProfileDir = profileDir;
            cfg.IconPath = iconPath;
            cfg.LauncherExePath = launcherExePath;
            cfg.KeepaliveScriptPath = keepaliveScript;
            cfg.AppUserModelId = configuredAumid;
            cfg.WindowStatePath = Path.Combine(theoDir, "app-window.json");
            return cfg;
        }

        private static string ValidateDesktopAppUrl(string rawUrl)
        {
            if (string.IsNullOrEmpty(rawUrl)) return null;
            string trimmed = rawUrl.Trim();
            if (trimmed.Length == 0 || trimmed.Length > 512) return null;
            if (Regex.IsMatch(trimmed, @"[\x00-\x20\x7f""'`$\\]")) return null;

            Uri parsed;
            if (!Uri.TryCreate(trimmed, UriKind.Absolute, out parsed)) return null;
            if (!string.IsNullOrEmpty(parsed.UserInfo)) return null;

            string queryAndFrag = (parsed.Query ?? "") + (parsed.Fragment ?? "");
            if (Regex.IsMatch(queryAndFrag, @"pair=|cloudKey|edgeAccessKey|token=", RegexOptions.IgnoreCase))
            {
                return null;
            }

            if (string.Equals(parsed.Scheme, "https", StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrEmpty(parsed.Host) || parsed.Host.Contains("..")) return null;
                return parsed.AbsoluteUri;
            }

            if (string.Equals(parsed.Scheme, "http", StringComparison.OrdinalIgnoreCase))
            {
                string host = (parsed.Host ?? "").ToLowerInvariant();
                if (host != "127.0.0.1" && host != "localhost") return null;
                int port = parsed.IsDefaultPort ? 80 : parsed.Port;
                if (port < 1 || port > 65535) return null;
                return parsed.AbsoluteUri;
            }

            return null;
        }

        private static bool IsSafeExePath(string candidate)
        {
            if (string.IsNullOrEmpty(candidate)) return false;
            string trimmed = candidate.Trim();
            if (trimmed.Length == 0 || Regex.IsMatch(trimmed, @"[\x00-\x1f\x7f""'`$;|&<>]")) return false;
            if (!trimmed.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) return false;
            try
            {
                return File.Exists(trimmed);
            }
            catch
            {
                return false;
            }
        }

        private static string FindBrowserExecutable(string preferredPath)
        {
            if (IsSafeExePath(preferredPath)) return preferredPath.Trim();

            string progFiles = Environment.GetEnvironmentVariable("ProgramFiles") ?? @"C:\Program Files";
            string progFilesX86 = Environment.GetEnvironmentVariable("ProgramFiles(x86)") ?? @"C:\Program Files (x86)";
            string localAppData = Environment.GetEnvironmentVariable("LOCALAPPDATA")
                ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "AppData", "Local");

            // Prefer Google Chrome over Microsoft Edge to avoid Edge Startup Boost / Sync dialogs
            string[] candidates = new string[]
            {
                Path.Combine(progFiles, "Google", "Chrome", "Application", "chrome.exe"),
                Path.Combine(progFilesX86, "Google", "Chrome", "Application", "chrome.exe"),
                Path.Combine(localAppData, "Google", "Chrome", "Application", "chrome.exe"),
                Path.Combine(progFilesX86, "Microsoft", "Edge", "Application", "msedge.exe"),
                Path.Combine(progFiles, "Microsoft", "Edge", "Application", "msedge.exe"),
                Path.Combine(localAppData, "Microsoft", "Edge", "Application", "msedge.exe")
            };

            for (int i = 0; i < candidates.Length; i++)
            {
                if (IsSafeExePath(candidates[i])) return candidates[i];
            }
            return null;
        }

        private static string BuildBrowserArguments(LaunchConfig cfg)
        {
            return string.Format(
                "--user-data-dir=\"{0}\" --app=\"{1}\" --no-first-run --no-default-browser-check --disable-background-mode --disable-sync --disable-features=Translate,msEdgeSidebarV2,msHubApps,EdgeCollections,msImplicitSignin",
                cfg.ProfileDir,
                cfg.Url);
        }

        private static void PrepareIsolatedProfile(string profileDir)
        {
            try
            {
                string defaultSubdir = Path.Combine(profileDir, "Default");
                Directory.CreateDirectory(defaultSubdir);

                string firstRunSentinel = Path.Combine(profileDir, "First Run");
                if (!File.Exists(firstRunSentinel))
                {
                    File.WriteAllText(firstRunSentinel, "", Encoding.ASCII);
                }

                string prefsPath = Path.Combine(defaultSubdir, "Preferences");
                if (!File.Exists(prefsPath))
                {
                    string minimalPrefs = "{\"browser\":{\"has_seen_welcome_page\":true},\"background_mode\":{\"enabled\":false},\"sync\":{\"suppress_start\":true}}";
                    File.WriteAllText(prefsPath, minimalPrefs, Encoding.UTF8);
                }
            }
            catch { }
        }

        private static void EnsureLocalBridgeListening(LaunchConfig cfg)
        {
            try
            {
                Uri u = new Uri(cfg.Url);
                if (!string.Equals(u.Scheme, "http", StringComparison.OrdinalIgnoreCase)) return;
                string host = (u.Host ?? "").ToLowerInvariant();
                if (host != "127.0.0.1" && host != "localhost") return;
                int port = u.IsDefaultPort ? 80 : u.Port;

                if (IsTcpPortOpen("127.0.0.1", port, 250)) return;
                if (string.IsNullOrEmpty(cfg.KeepaliveScriptPath) || !File.Exists(cfg.KeepaliveScriptPath)) return;

                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = "powershell.exe";
                psi.Arguments = string.Format("-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File \"{0}\" -SkipTaskCheck", cfg.KeepaliveScriptPath);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                Process.Start(psi);

                Stopwatch sw = Stopwatch.StartNew();
                while (sw.ElapsedMilliseconds < 3000)
                {
                    Thread.Sleep(150);
                    if (IsTcpPortOpen("127.0.0.1", port, 200)) break;
                }
            }
            catch { }
        }

        private static bool IsTcpPortOpen(string host, int port, int timeoutMs)
        {
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    IAsyncResult ar = client.BeginConnect(host, port, null, null);
                    bool ok = ar.AsyncWaitHandle.WaitOne(timeoutMs);
                    if (!ok) return false;
                    client.EndConnect(ar);
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        private static IntPtr FindExistingTheoWindow(LaunchConfig cfg, uint spawnedPid)
        {
            uint savedPid = 0;
            IntPtr savedHwnd = IntPtr.Zero;
            ReadSavedWindowState(cfg.WindowStatePath, out savedPid, out savedHwnd);

            IntPtr found = IntPtr.Zero;
            Guid iid = new Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99");
            PROPERTYKEY pkAumid = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 5);

            EnumWindows(delegate(IntPtr hWnd, IntPtr lParam)
            {
                if (!IsWindowVisible(hWnd)) return true;

                StringBuilder cb = new StringBuilder(128);
                GetClassName(hWnd, cb, 128);
                if (cb.ToString() != "Chrome_WidgetWin_1") return true;

                StringBuilder sb = new StringBuilder(512);
                GetWindowText(hWnd, sb, 512);
                string title = sb.ToString();
                if (string.IsNullOrEmpty(title)) return true;

                // Never match normal tabbed browser windows
                if (title.EndsWith("- Google Chrome", StringComparison.OrdinalIgnoreCase) ||
                    title.EndsWith("- Microsoft Edge", StringComparison.OrdinalIgnoreCase) ||
                    title.EndsWith("- Microsoft\u200b Edge", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                uint pid = 0;
                GetWindowThreadProcessId(hWnd, out pid);

                if (spawnedPid != 0 && pid == spawnedPid)
                {
                    found = hWnd;
                    return false;
                }
                if (savedPid != 0 && savedHwnd != IntPtr.Zero && pid == savedPid && hWnd == savedHwnd)
                {
                    found = hWnd;
                    return false;
                }

                string hwndAumid = "";
                try
                {
                    IPropertyStore store;
                    if (SHGetPropertyStoreForWindow(hWnd, ref iid, out store) == 0 && store != null)
                    {
                        PropVariant pv = new PropVariant();
                        try
                        {
                            if (store.GetValue(ref pkAumid, out pv) == 0 && pv.vt == 31 && pv.ptr != IntPtr.Zero)
                            {
                                hwndAumid = Marshal.PtrToStringUni(pv.ptr) ?? "";
                            }
                        }
                        finally
                        {
                            pv.Free();
                        }
                    }
                }
                catch { }

                if (!string.IsNullOrEmpty(hwndAumid))
                {
                    if (string.Equals(hwndAumid, cfg.AppUserModelId, StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(hwndAumid, DEFAULT_AUMID, StringComparison.OrdinalIgnoreCase) ||
                        hwndAumid.IndexOf(".appprofile.", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        found = hWnd;
                        return false;
                    }
                }

                // Match chromeless THEO window by title
                if (title.IndexOf("THEO — AI Session Workbench", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    title.IndexOf("THEO - AI Session Workbench", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    found = hWnd;
                    return false;
                }

                return true;
            }, IntPtr.Zero);

            return found;
        }

        private static void StampWindowIdentityAndIcon(IntPtr hWnd, LaunchConfig cfg)
        {
            if (hWnd == IntPtr.Zero) return;
            try
            {
                Guid iid = new Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99");
                IPropertyStore store;
                if (SHGetPropertyStoreForWindow(hWnd, ref iid, out store) == 0 && store != null)
                {
                    PROPERTYKEY pkAumid = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 5);
                    PROPERTYKEY pkRelaunchCmd = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 2);
                    PROPERTYKEY pkRelaunchIcon = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 3);
                    PROPERTYKEY pkRelaunchName = new PROPERTYKEY("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3", 4);

                    PropVariant vId = PropVariant.FromString(cfg.AppUserModelId);
                    PropVariant vCmd = PropVariant.FromString("\"" + cfg.LauncherExePath + "\"");
                    PropVariant vIco = PropVariant.FromString(cfg.IconPath + ",0");
                    PropVariant vNam = PropVariant.FromString("THEO");
                    try
                    {
                        store.SetValue(ref pkAumid, ref vId);
                        store.SetValue(ref pkRelaunchCmd, ref vCmd);
                        store.SetValue(ref pkRelaunchIcon, ref vIco);
                        store.SetValue(ref pkRelaunchName, ref vNam);
                        store.Commit();
                    }
                    finally
                    {
                        vId.Free();
                        vCmd.Free();
                        vIco.Free();
                        vNam.Free();
                    }
                }
            }
            catch { }

            try
            {
                if (!string.IsNullOrEmpty(cfg.IconPath) && File.Exists(cfg.IconPath))
                {
                    IntPtr hIconBig = LoadImage(IntPtr.Zero, cfg.IconPath, IMAGE_ICON, 256, 256, LR_LOADFROMFILE);
                    IntPtr hIconSmall = LoadImage(IntPtr.Zero, cfg.IconPath, IMAGE_ICON, 32, 32, LR_LOADFROMFILE);
                    if (hIconBig != IntPtr.Zero)
                    {
                        SendMessage(hWnd, WM_SETICON, new IntPtr(1), hIconBig);
                    }
                    if (hIconSmall != IntPtr.Zero)
                    {
                        SendMessage(hWnd, WM_SETICON, new IntPtr(0), hIconSmall);
                    }
                }
            }
            catch { }
        }

        private static void FocusWindow(IntPtr hWnd)
        {
            if (hWnd == IntPtr.Zero) return;
            try
            {
                if (IsIconic(hWnd))
                {
                    ShowWindow(hWnd, SW_RESTORE);
                }
                else
                {
                    ShowWindow(hWnd, SW_SHOW);
                }
                BringWindowToTop(hWnd);
                SetForegroundWindow(hWnd);
            }
            catch { }
        }

        private static void ReadSavedWindowState(string windowStatePath, out uint pidOut, out IntPtr hwndOut)
        {
            pidOut = 0;
            hwndOut = IntPtr.Zero;
            if (string.IsNullOrEmpty(windowStatePath) || !File.Exists(windowStatePath)) return;
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                Dictionary<string, object> d = ser.Deserialize<Dictionary<string, object>>(File.ReadAllText(windowStatePath, Encoding.UTF8));
                int pid = GetDictInt(d, "pid", 0);
                long hwndVal = 0;
                if (d != null && d.ContainsKey("hwnd") && d["hwnd"] != null)
                {
                    hwndVal = Convert.ToInt64(d["hwnd"]);
                }
                if (pid > 0 && hwndVal != 0)
                {
                    pidOut = (uint)pid;
                    hwndOut = new IntPtr(hwndVal);
                }
            }
            catch { }
        }

        private static void SaveWindowState(string windowStatePath, uint pid, IntPtr hwnd)
        {
            if (string.IsNullOrEmpty(windowStatePath) || pid == 0) return;
            try
            {
                JavaScriptSerializer ser = new JavaScriptSerializer();
                Dictionary<string, object> d = new Dictionary<string, object>();
                d["pid"] = pid;
                d["hwnd"] = hwnd.ToInt64();
                d["updatedAt"] = DateTime.UtcNow.ToString("o");
                File.WriteAllText(windowStatePath, ser.Serialize(d), Encoding.UTF8);
            }
            catch { }
        }

        private static string GetDictString(Dictionary<string, object> d, string key)
        {
            if (d == null || !d.ContainsKey(key) || d[key] == null) return "";
            return Convert.ToString(d[key]) ?? "";
        }

        private static int GetDictInt(Dictionary<string, object> d, string key, int fallback)
        {
            if (d == null || !d.ContainsKey(key) || d[key] == null) return fallback;
            try
            {
                return Convert.ToInt32(d[key]);
            }
            catch
            {
                return fallback;
            }
        }
    }
}
