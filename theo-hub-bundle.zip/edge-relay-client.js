'use strict';

const { getDeviceIdentity, deriveEdgeAuthToken } = require('./device-identity');

class TheoEdgeRelayClient {
  constructor(options = {}) {
    this.getRelayKey = typeof options.getRelayKey === 'function' ? options.getRelayKey : () => options.relayKey || '';
    this.getEdgeUrl = typeof options.getEdgeUrl === 'function' ? options.getEdgeUrl : () => options.edgeUrl || '';
    this.authTokenOverride = String(options.authToken || '').trim();
    this.deviceOverride = options.device || options.deviceInfo || null;
    this.buildHostState =
      typeof options.buildHostState === 'function' ? options.buildHostState : async () => ({});
    this.onRpcCommand =
      typeof options.onRpcCommand === 'function' ? options.onRpcCommand : async () => ({ ok: false });
    this.onFleetDevicesUpdated =
      typeof options.onFleetDevicesUpdated === 'function' ? options.onFleetDevicesUpdated : null;
    this.onPeerHostState =
      typeof options.onPeerHostState === 'function' ? options.onPeerHostState : null;
    this.onPeerStreamDelta =
      typeof options.onPeerStreamDelta === 'function' ? options.onPeerStreamDelta : null;

    this.ws = null;
    this.connected = false;
    this.authenticated = false;
    this.disposed = false;
    this.currentUrl = '';
    this.lastConnectedAt = 0;
    this.lastError = '';
    this.latencyMs = 0;
    this.reconnectAttempt = 0;
    this.reconnectTimer = null;
    this.pingTimer = null;
    this.lastPingSentAt = 0;
    this.fleetDevices = [];
    this.pendingPeerRpcs = new Map();
    this.peerSnapshots = new Map();
  }

  start() {
    this.disposed = false;
    this._connect();
  }

  stop() {
    this.disposed = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    if (this.ws) {
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    this.connected = false;
    this.authenticated = false;
  }

  updateUrlAndReconnect() {
    const nextUrl = this._normalizeWsUrl(this.getEdgeUrl());
    if (nextUrl === this.currentUrl && this.connected) {
      return;
    }
    if (this.ws) {
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    this.connected = false;
    this.authenticated = false;
    this.reconnectAttempt = 0;
    this._connect();
  }

  getStatus() {
    return {
      configured: Boolean(this._normalizeWsUrl(this.getEdgeUrl())),
      url: this._normalizeWsUrl(this.getEdgeUrl()),
      connected: this.connected && this.authenticated,
      lastConnectedAt: this.lastConnectedAt,
      latencyMs: this.latencyMs,
      lastError: this.lastError,
      fleetDeviceCount: this.fleetDevices.length
    };
  }

  getFleetDevices() {
    return this.fleetDevices.slice();
  }

  getPeerSnapshots() {
    return Object.fromEntries(this.peerSnapshots.entries());
  }

  forwardRpcToDevice(targetDeviceId, cmd, timeoutMs = 15000) {
    return new Promise((resolve) => {
      if (!this.connected || !this.authenticated) {
        resolve(null);
        return;
      }
      const reqId = `peer-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
      const timer = setTimeout(() => {
        this.pendingPeerRpcs.delete(reqId);
        resolve({ ok: false, error: 'Peer device RPC timed out' });
      }, timeoutMs);
      if (typeof timer.unref === 'function') timer.unref();
      this.pendingPeerRpcs.set(reqId, { resolve, timer });
      const sent = this.sendJson({
        type: 'rpc_cmd',
        reqId,
        targetDeviceId,
        cmd
      });
      if (!sent) {
        clearTimeout(timer);
        this.pendingPeerRpcs.delete(reqId);
        resolve(null);
      }
    });
  }

  sendJson(obj) {
    if (!this.ws || !this.connected) return false;
    try {
      this.ws.send(typeof obj === 'string' ? obj : JSON.stringify(obj));
      return true;
    } catch {
      return false;
    }
  }

  _getDevice() {
    return this.deviceOverride || getDeviceIdentity();
  }

  async pushHostState(stateSnapshot = null) {
    if (!this.connected || !this.authenticated) return false;
    try {
      const dev = this._getDevice();
      const snap = stateSnapshot || (await this.buildHostState());
      return this.sendJson({
        type: 'host_state',
        deviceId: dev.id,
        deviceName: dev.name,
        device: {
          id: dev.id,
          name: dev.name,
          role: dev.role,
          hostname: dev.hostname,
          platform: dev.platform,
          capabilities: dev.capabilities,
          lanIps: dev.lanIps,
          online: true,
          lastSeen: Date.now()
        },
        snapshot: snap,
        ts: Date.now()
      });
    } catch {
      return false;
    }
  }

  pushStreamDelta(deltaPayload) {
    if (!this.connected || !this.authenticated) return false;
    return this.sendJson(deltaPayload);
  }

  _normalizeWsUrl(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';
    let u = s;
    if (u.startsWith('https://')) u = 'wss://' + u.slice(8);
    else if (u.startsWith('http://')) u = 'ws://' + u.slice(7);
    if (!u.startsWith('ws://') && !u.startsWith('wss://')) return '';
    try {
      const parsed = new URL(u);
      if (!parsed.pathname || parsed.pathname === '/') {
        parsed.pathname = '/ws';
      }
      return parsed.toString();
    } catch {
      return '';
    }
  }

  _scheduleReconnect() {
    if (this.disposed || this.reconnectTimer) return;
    const baseDelay = Math.min(15000, 1000 * Math.pow(1.8, Math.min(6, this.reconnectAttempt)));
    const jitter = Math.floor(Math.random() * 400);
    this.reconnectAttempt += 1;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this._connect();
    }, baseDelay + jitter);
    if (typeof this.reconnectTimer.unref === 'function') {
      this.reconnectTimer.unref();
    }
  }

  _connect() {
    if (this.disposed) return;
    const wsUrl = this._normalizeWsUrl(this.getEdgeUrl());
    this.currentUrl = wsUrl;
    if (!wsUrl || typeof WebSocket !== 'function') {
      return;
    }
    const authToken = this.authTokenOverride || deriveEdgeAuthToken(this.getRelayKey());
    if (!authToken) {
      this.lastError = 'Missing relay auth key';
      return;
    }

    const dev = this._getDevice();
    let fullUrl = wsUrl;
    try {
      const u = new URL(wsUrl);
      u.searchParams.set('role', 'host');
      u.searchParams.set('deviceId', dev.id);
      fullUrl = u.toString();
    } catch {}

    let sock;
    try {
      sock = new WebSocket(fullUrl);
    } catch (err) {
      this.lastError = String(err?.message || err);
      this._scheduleReconnect();
      return;
    }
    this.ws = sock;

    sock.addEventListener('open', () => {
      if (this.ws !== sock) return;
      this.connected = true;
      this.reconnectAttempt = 0;
      this.lastError = '';
      this.sendJson({
        type: 'auth_host',
        token: authToken,
        device: {
          id: dev.id,
          name: dev.name,
          role: dev.role,
          hostname: dev.hostname,
          username: dev.username,
          platform: dev.platform,
          capabilities: dev.capabilities,
          lanIps: dev.lanIps,
          online: true,
          lastSeen: Date.now()
        }
      });

      if (this.pingTimer) clearInterval(this.pingTimer);
      this.pingTimer = setInterval(() => {
        if (!this.connected || this.ws !== sock) return;
        this.lastPingSentAt = Date.now();
        this.sendJson({ type: 'ping', ts: this.lastPingSentAt });
      }, 25000);
      if (typeof this.pingTimer.unref === 'function') {
        this.pingTimer.unref();
      }
    });

    sock.addEventListener('message', async (ev) => {
      if (this.ws !== sock) return;
      let msg;
      try {
        msg = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data || ''));
      } catch {
        return;
      }
      if (!msg || typeof msg !== 'object') return;

      if (msg.type === 'auth_ok') {
        this.authenticated = true;
        this.lastConnectedAt = Date.now();
        if (Array.isArray(msg.devices)) {
          this.fleetDevices = msg.devices;
          if (this.onFleetDevicesUpdated) this.onFleetDevicesUpdated(this.fleetDevices);
        }
        this.pushHostState().catch(() => {});
        return;
      }

      if (msg.type === 'pong') {
        if (msg.echoTs) {
          this.latencyMs = Math.max(1, Date.now() - Number(msg.echoTs));
        }
        return;
      }

      if (msg.type === 'devices_presence' && Array.isArray(msg.devices)) {
        this.fleetDevices = msg.devices;
        if (this.onFleetDevicesUpdated) this.onFleetDevicesUpdated(this.fleetDevices);
        return;
      }

      if (msg.type === 'host_state' && msg.deviceId) {
        const curDev = this._getDevice();
        if (msg.deviceId !== curDev.id && msg.snapshot) {
          this.peerSnapshots.set(msg.deviceId, {
            deviceId: msg.deviceId,
            deviceName: msg.deviceName || msg.device?.name || msg.deviceId,
            device: msg.device || null,
            snapshot: msg.snapshot,
            updatedAt: Date.now()
          });
          if (this.onPeerHostState) this.onPeerHostState(msg);
        }
        return;
      }

      if (msg.type === 'stream_delta' && msg.deviceId) {
        const curDev = this._getDevice();
        if (msg.deviceId !== curDev.id && this.onPeerStreamDelta) {
          this.onPeerStreamDelta(msg);
        }
        return;
      }

      if (msg.type === 'rpc_res' && msg.reqId && this.pendingPeerRpcs.has(msg.reqId)) {
        const pending = this.pendingPeerRpcs.get(msg.reqId);
        this.pendingPeerRpcs.delete(msg.reqId);
        clearTimeout(pending.timer);
        pending.resolve(msg.ok === false ? { ok: false, error: msg.error || 'Peer error' } : msg.result || { ok: true });
        return;
      }

      if (msg.type === 'request_sync') {
        this.pushHostState().catch(() => {});
        return;
      }

      if (msg.type === 'rpc_cmd') {
        const curDev = this._getDevice();
        if (
          msg.targetDeviceId &&
          msg.targetDeviceId !== 'auto' &&
          msg.targetDeviceId !== curDev.id
        ) {
          return;
        }
        try {
          const res = await this.onRpcCommand(msg.cmd || msg);
          if (msg.reqId) {
            this.sendJson({
              type: 'rpc_res',
              reqId: msg.reqId,
              clientConnId: msg.clientConnId || '',
              deviceId: curDev.id,
              deviceName: curDev.name,
              ok: res?.ok !== false,
              result: res
            });
          }
        } catch (err) {
          if (msg.reqId) {
            this.sendJson({
              type: 'rpc_res',
              reqId: msg.reqId,
              clientConnId: msg.clientConnId || '',
              deviceId: curDev.id,
              deviceName: curDev.name,
              ok: false,
              error: String(err?.message || err)
            });
          }
        }
      }
    });

    const handleCloseOrErr = (errEvt) => {
      if (this.ws !== sock) return;
      if (errEvt && errEvt.message) {
        this.lastError = String(errEvt.message);
      }
      this.connected = false;
      this.authenticated = false;
      this.ws = null;
      if (this.pingTimer) {
        clearInterval(this.pingTimer);
        this.pingTimer = null;
      }
      this._scheduleReconnect();
    };

    sock.addEventListener('close', handleCloseOrErr);
    sock.addEventListener('error', handleCloseOrErr);
  }
}

module.exports = {
  TheoEdgeRelayClient
};
