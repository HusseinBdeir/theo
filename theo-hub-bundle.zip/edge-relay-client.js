'use strict';

const {
  getDeviceIdentity,
  deriveEdgeAuthToken,
  loadTheoCredentials,
  getHostIdleMs
} = require('./device-identity');

function neutralizeRemoteProviderForSig(prov) {
  if (!prov || typeof prov !== 'object') return prov ?? null;
  const out = { ...prov };
  if ('quotaUpdatedAt' in out) out.quotaUpdatedAt = 0;
  if ('at' in out) out.at = 0;
  if (out.usage && typeof out.usage === 'object') {
    out.usage = { ...out.usage, at: 0 };
  }
  return out;
}

function buildRemoteStatePostParts(stateObj) {
  const rows = Array.isArray(stateObj?.rows) ? stateObj.rows : [];
  const rowJsons = new Map();
  const rowMetaByKey = new Map();
  let canPatch = true;
  for (let i = 0; i < rows.length; i += 1) {
    const r = rows[i];
    const rk = String(r?.key || r?.id || '').trim();
    if (!rk || rowJsons.has(rk)) {
      canPatch = false;
      break;
    }
    rowJsons.set(rk, JSON.stringify(r));
    rowMetaByKey.set(rk, { id: String(r?.id || rk), key: rk });
  }
  const rawConn =
    stateObj?.connection && typeof stateObj.connection === 'object' ? stateObj.connection : null;
  const rawEdge =
    rawConn?.edgeRelay && typeof rawConn.edgeRelay === 'object' ? rawConn.edgeRelay : null;
  const neutralizedConnection = rawConn
    ? {
        ...rawConn,
        lastCloudSyncAt: 0,
        lastCloudAttemptAt: 0,
        cloudSyncInFlight: false,
        edgeRelay: rawEdge
          ? {
              ...rawEdge,
              latencyMs: 0,
              lastPingAt: 0,
              lastPongAt: 0,
              lastConnectAttemptAt: 0
            }
          : rawConn.edgeRelay ?? null
      }
    : null;
  const headerSig = JSON.stringify({
    total: stateObj?.total ?? rows.length,
    pendingActiveKey: stateObj?.pendingActiveKey ?? null,
    summary: stateObj?.summary || null,
    summaryByProvider: stateObj?.summaryByProvider || null,
    topSessions: Array.isArray(stateObj?.topSessions) ? stateObj.topSessions : [],
    connection: neutralizedConnection
  });
  const rawProviders =
    stateObj?.providers && typeof stateObj.providers === 'object' ? stateObj.providers : null;
  const neutralizedProviders = rawProviders
    ? {
        ...rawProviders,
        ...(rawProviders.antigravity
          ? { antigravity: neutralizeRemoteProviderForSig(rawProviders.antigravity) }
          : {}),
        ...(rawProviders.claude
          ? { claude: neutralizeRemoteProviderForSig(rawProviders.claude) }
          : {})
      }
    : stateObj?.providers ?? null;
  const neutralizedDevices = Array.isArray(stateObj?.devices)
    ? stateObj.devices.map((d) =>
        d && typeof d === 'object'
          ? {
              ...d,
              lastSeen: 0,
              unsavedWork:
                d.unsavedWork && typeof d.unsavedWork === 'object'
                  ? { ...d.unsavedWork, checkedAt: 0 }
                  : d.unsavedWork,
              pcSetup:
                d.pcSetup && typeof d.pcSetup === 'object'
                  ? { ...d.pcSetup, checkedAt: 0 }
                  : d.pcSetup
            }
          : d
      )
    : stateObj?.devices ?? null;
  const neutralizedDevice =
    stateObj?.device && typeof stateObj.device === 'object'
      ? {
          ...stateObj.device,
          lastSeen: 0,
          unsavedWork:
            stateObj.device.unsavedWork && typeof stateObj.device.unsavedWork === 'object'
              ? { ...stateObj.device.unsavedWork, checkedAt: 0 }
              : stateObj.device.unsavedWork,
          pcSetup:
            stateObj.device.pcSetup && typeof stateObj.device.pcSetup === 'object'
              ? { ...stateObj.device.pcSetup, checkedAt: 0 }
              : stateObj.device.pcSetup
        }
      : stateObj?.device ?? null;
  const neutralizedUsage =
    stateObj?.usage && typeof stateObj.usage === 'object'
      ? { ...stateObj.usage, at: 0 }
      : stateObj?.usage ?? null;
  const neutralizedUnsaved =
    stateObj?.unsavedWork && typeof stateObj.unsavedWork === 'object'
      ? { ...stateObj.unsavedWork, checkedAt: 0 }
      : stateObj?.unsavedWork ?? null;
  const neutralizedPcSetup =
    stateObj?.pcSetup && typeof stateObj.pcSetup === 'object'
      ? { ...stateObj.pcSetup, checkedAt: 0 }
      : stateObj?.pcSetup ?? null;
  const metaSig = JSON.stringify({
    ...(stateObj && typeof stateObj === 'object' ? stateObj : {}),
    generatedAt: 0,
    rows: null,
    total: 0,
    pendingActiveKey: null,
    summary: null,
    summaryByProvider: null,
    topSessions: null,
    connection: null,
    prewarmTelemetry: null,
    providers: neutralizedProviders,
    usage: neutralizedUsage,
    devices: neutralizedDevices,
    device: neutralizedDevice,
    unsavedWork: neutralizedUnsaved,
    pcSetup: neutralizedPcSetup
  });
  return { rows, rowJsons, rowMetaByKey, canPatch, metaSig, headerSig };
}

function applyRowPatchToSnapshot(baseSnap, msg) {
  if (!baseSnap || typeof baseSnap !== 'object' || !msg || typeof msg !== 'object') {
    return null;
  }
  const remIds = new Set(Array.isArray(msg.removedIds) ? msg.removedIds.map(String) : []);
  const remKeys = new Set(Array.isArray(msg.removedKeys) ? msg.removedKeys.map(String) : []);
  const hasExplicitRemKeys = remKeys.size > 0;
  const prevRows = Array.isArray(baseSnap.rows) ? baseSnap.rows : [];
  const nextRows = [];
  const idxByKey = new Map();
  const idxById = new Map();
  for (let i = 0; i < prevRows.length; i += 1) {
    const r = prevRows[i];
    if (!r || typeof r !== 'object') continue;
    const rawKey = String(r.key || '').trim();
    const rid = String(r.id || '').trim();
    const rk = rawKey || rid;
    const shouldDrop = hasExplicitRemKeys
      ? Boolean((rk && remKeys.has(rk)) || (!rawKey && rid && remIds.has(rid)))
      : Boolean((rid && remIds.has(rid)) || (rk && remKeys.has(rk)));
    if (shouldDrop) continue;
    const cloned = { ...r };
    const idx = nextRows.length;
    nextRows.push(cloned);
    if (rawKey) idxByKey.set(rawKey, idx);
    if (rid) {
      const list = idxById.get(rid) || [];
      list.push({ idx, rawKey });
      idxById.set(rid, list);
    }
  }

  const rawUpserts = Array.isArray(msg.upserts) ? msg.upserts : [];
  for (let i = 0; i < rawUpserts.length; i += 1) {
    const u = rawUpserts[i];
    if (!u || typeof u !== 'object') continue;
    const rawUKey = String(u.key || '').trim();
    const rid = String(u.id || u.key || '').trim();
    const rk = rawUKey || rid;
    if (!rid && !rk) continue;
    let hitIdx = rawUKey && idxByKey.has(rawUKey) ? idxByKey.get(rawUKey) : undefined;
    if (hitIdx === undefined && rid && idxById.has(rid)) {
      const idEntries = idxById.get(rid);
      if (!rawUKey) {
        if (idEntries.length === 1) {
          hitIdx = idEntries[0].idx;
        } else {
          const keylessMatch = idEntries.find((e) => !e.rawKey);
          if (keylessMatch) hitIdx = keylessMatch.idx;
        }
      } else {
        const keylessMatch = idEntries.find((e) => !e.rawKey);
        if (keylessMatch) hitIdx = keylessMatch.idx;
      }
    }
    if (hitIdx !== undefined) {
      const prevKey = String(nextRows[hitIdx]?.key || '').trim();
      const mergedKey = rawUKey || prevKey;
      const cloned = mergedKey ? { ...u, id: rid || mergedKey, key: mergedKey } : { ...u, id: rid };
      nextRows[hitIdx] = cloned;
      if (mergedKey) idxByKey.set(mergedKey, hitIdx);
      if (rid && idxById.has(rid)) {
        for (const entry of idxById.get(rid)) {
          if (entry.idx === hitIdx) entry.rawKey = mergedKey;
        }
      }
    } else {
      const cloned = rawUKey ? { ...u, id: rid || rawUKey, key: rawUKey } : { ...u, id: rid };
      const newIdx = nextRows.length;
      nextRows.push(cloned);
      if (rawUKey) idxByKey.set(rawUKey, newIdx);
      if (rid) {
        const list = idxById.get(rid) || [];
        list.push({ idx: newIdx, rawKey: rawUKey });
        idxById.set(rid, list);
      }
    }
  }

  nextRows.sort(
    (a, b) =>
      Number(Boolean(b.pinned && !b.archived)) - Number(Boolean(a.pinned && !a.archived)) ||
      Number(b.at || 0) - Number(a.at || 0) ||
      Number(b.pinnedAt || 0) - Number(a.pinnedAt || 0) ||
      String(a.id || '').localeCompare(String(b.id || ''))
  );

  return {
    ...baseSnap,
    generatedAt: Number(msg.generatedAt || Date.now()),
    total: typeof msg.total === 'number' ? msg.total : nextRows.length,
    rows: nextRows,
    ...(msg.pendingActiveKey !== undefined ? { pendingActiveKey: msg.pendingActiveKey } : {}),
    ...(msg.summary !== undefined ? { summary: msg.summary } : {}),
    ...(msg.summaryByProvider !== undefined ? { summaryByProvider: msg.summaryByProvider } : {}),
    ...(Array.isArray(msg.topSessions) ? { topSessions: msg.topSessions } : {}),
    ...(msg.connection !== undefined && msg.connection !== null ? { connection: msg.connection } : {})
  };
}

class TheoEdgeRelayClient {
  constructor(options = {}) {
    this.getRelayKey =
      typeof options.getRelayKey === 'function'
        ? options.getRelayKey
        : () => options.relayKey || loadTheoCredentials().effectiveEdgeSecret || '';
    this.getEdgeUrl =
      typeof options.getEdgeUrl === 'function'
        ? options.getEdgeUrl
        : () => options.edgeUrl || loadTheoCredentials().edgeRelayUrl || '';
    this.authTokenOverride = String(options.authToken || '').trim();
    this.deviceOverride = options.device || options.deviceInfo || null;
    this.buildHostState =
      typeof options.buildHostState === 'function' ? options.buildHostState : async () => ({});
    this.onRpcCommand =
      typeof options.onRpcCommand === 'function' ? options.onRpcCommand : async () => ({ ok: false });
    this.onFleetDevicesUpdated =
      typeof options.onFleetDevicesUpdated === 'function' ? options.onFleetDevicesUpdated : null;
    this.onPeerHostState =
      typeof options.onPeerHostState === 'function' ? options.onPeerHostState : null;
    this.onPeerStreamDelta =
      typeof options.onPeerStreamDelta === 'function' ? options.onPeerStreamDelta : null;
    this.onClaudePermissionMode =
      typeof options.onClaudePermissionMode === 'function' ? options.onClaudePermissionMode : null;
    this.onPrewarmHint =
      typeof options.onPrewarmHint === 'function' ? options.onPrewarmHint : null;

    this.ws = null;
    this.connected = false;
    this.authenticated = false;
    this.disposed = false;
    this.authRejected = false;
    this.currentUrl = '';
    this.lastConnectedAt = 0;
    this.lastError = '';
    this.latencyMs = 0;
    this.reconnectAttempt = 0;
    this.reconnectTimer = null;
    this.pingTimer = null;
    this.lastPingSentAt = 0;
    this.fleetDevices = [];
    this.pendingPeerRpcs = new Map();
    this.peerSnapshots = new Map();
    this._edgePostState = null;
    this._edgeNextSeq = 0;
    this._peerResyncAt = new Map();
    this.relaySupportsRowPatch = false;
  }

  start() {
    this.disposed = false;
    this.authRejected = false;
    this._connect();
  }

  _flushPendingPeerRpcs(reason = 'Edge relay disconnected') {
    for (const [reqId, pending] of this.pendingPeerRpcs.entries()) {
      clearTimeout(pending.timer);
      try {
        pending.resolve({ ok: false, error: reason });
      } catch {}
      this.pendingPeerRpcs.delete(reqId);
    }
  }

  _resetEdgePostState() {
    this._edgePostState = null;
  }

  stop() {
    this.disposed = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    this._flushPendingPeerRpcs('Edge relay stopped');
    if (this.ws) {
      const sock = this.ws;
      this.ws = null;
      try {
        sock.close();
      } catch {}
    }
    this.connected = false;
    this.authenticated = false;
    this._resetEdgePostState();
  }

  updateUrlAndReconnect(force = false) {
    const nextUrl = this._normalizeWsUrl(this.getEdgeUrl());
    if (!force && nextUrl === this.currentUrl && this.connected && this.authenticated) {
      return;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    this._flushPendingPeerRpcs('Edge relay reconnecting');
    if (this.ws) {
      const sock = this.ws;
      this.ws = null;
      try {
        sock.close();
      } catch {}
    }
    this.connected = false;
    this.authenticated = false;
    this.authRejected = false;
    this.reconnectAttempt = 0;
    this._resetEdgePostState();
    this._connect();
  }

  getStatus() {
    return {
      configured: Boolean(this._normalizeWsUrl(this.getEdgeUrl())),
      url: this._normalizeWsUrl(this.getEdgeUrl()),
      connected: this.connected && this.authenticated,
      lastConnectedAt: this.lastConnectedAt,
      latencyMs: this.latencyMs,
      lastError: this.lastError,
      fleetDeviceCount: this.fleetDevices.length
    };
  }

  getFleetDevices() {
    return this.fleetDevices.slice();
  }

  getPeerSnapshots() {
    return Object.fromEntries(this.peerSnapshots.entries());
  }

  forwardRpcToDevice(targetDeviceId, cmd, timeoutMs = 15000) {
    return new Promise((resolve) => {
      if (!this.connected || !this.authenticated) {
        resolve(null);
        return;
      }
      const reqId = `peer-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
      const timer = setTimeout(() => {
        this.pendingPeerRpcs.delete(reqId);
        resolve({ ok: false, error: 'Peer device RPC timed out' });
      }, timeoutMs);
      if (typeof timer.unref === 'function') timer.unref();
      this.pendingPeerRpcs.set(reqId, { resolve, timer });
      const sent = this.sendJson({
        type: 'rpc_cmd',
        reqId,
        targetDeviceId,
        cmd
      });
      if (!sent) {
        clearTimeout(timer);
        this.pendingPeerRpcs.delete(reqId);
        resolve(null);
      }
    });
  }

  sendJson(obj) {
    if (!this.ws || !this.connected) return false;
    try {
      const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
      if (text.length > 940 * 1024) {
        return false;
      }
      this.ws.send(text);
      return true;
    } catch {
      return false;
    }
  }

  _getDevice() {
    return this.deviceOverride || getDeviceIdentity();
  }

  async pushHostState(stateSnapshot = null, opts = {}) {
    if (!this.connected || !this.authenticated) return false;
    try {
      const sockAtStart = this.ws;
      const dev = this._getDevice();
      const snap = stateSnapshot || (await this.buildHostState());
      if (this.ws !== sockAtStart || !this.connected || !this.authenticated) {
        return false;
      }
      if (!snap || typeof snap !== 'object') return false;
      const parts = buildRemoteStatePostParts(snap);
      const prev = this._edgePostState || null;
      const now = Number(opts.now || Date.now());
      const idleMs = getHostIdleMs();
      const needFull = Boolean(
        opts.forceFull ||
          this.relaySupportsRowPatch !== true ||
          !prev ||
          !prev.canPatch ||
          !parts.canPatch ||
          prev.metaSig !== parts.metaSig
      );

      if (!needFull) {
        const upserts = [];
        for (const r of parts.rows) {
          const rk = String(r?.key || r?.id || '').trim();
          if (prev.rowJsons.get(rk) !== parts.rowJsons.get(rk)) {
            upserts.push(r);
          }
        }
        const removedIds = [];
        const removedKeys = [];
        for (const oldKey of prev.rowJsons.keys()) {
          if (!parts.rowJsons.has(oldKey)) {
            const meta = prev.rowMetaByKey.get(oldKey);
            removedIds.push(meta?.id || oldKey);
            removedKeys.push(oldKey);
          }
        }
        const maxRows = Math.max(parts.rows.length, prev.rowJsons.size);
        const churnCount = upserts.length + removedKeys.length;
        const tooMuchChurn = maxRows >= 4 && churnCount >= Math.ceil(maxRows * 0.5);

        if (
          !tooMuchChurn &&
          !opts.forceHeartbeat &&
          upserts.length === 0 &&
          removedKeys.length === 0 &&
          prev.headerSig === parts.headerSig &&
          now - Number(prev.lastPostAt || 0) < 60000
        ) {
          prev.lastSnapshot = snap;
          return false;
        }

        if (!tooMuchChurn) {
          const nextSeq = Number(this._edgeNextSeq || prev.seq || 0) + 1;
          const sent = this.sendJson({
            type: 'host_row_patch',
            seq: nextSeq,
            deviceId: dev.id,
            deviceName: dev.name,
            ...(idleMs !== null ? { idleMs } : {}),
            generatedAt: snap.generatedAt,
            total: snap.total ?? parts.rows.length,
            ...(snap.pendingActiveKey !== undefined
              ? { pendingActiveKey: snap.pendingActiveKey }
              : {}),
            upserts,
            removedIds,
            removedKeys,
            summary: snap.summary || null,
            summaryByProvider: snap.summaryByProvider || null,
            topSessions: Array.isArray(snap.topSessions) ? snap.topSessions : [],
            connection: snap.connection || null,
            ts: now
          });
          if (!sent) {
            this._edgePostState = null;
            return false;
          }
          this._edgeNextSeq = nextSeq;
          this._edgePostState = {
            seq: nextSeq,
            metaSig: parts.metaSig,
            headerSig: parts.headerSig,
            rowJsons: parts.rowJsons,
            rowMetaByKey: parts.rowMetaByKey,
            canPatch: parts.canPatch,
            lastPostAt: now,
            lastSnapshot: snap
          };
          return 'host_row_patch';
        }
      }

      const nextSeq = Number(this._edgeNextSeq || prev?.seq || 0) + 1;
      const sent = this.sendJson({
        type: 'host_state',
        seq: nextSeq,
        deviceId: dev.id,
        deviceName: dev.name,
        ...(idleMs !== null ? { idleMs } : {}),
        device: {
          id: dev.id,
          name: dev.name,
          role: dev.role,
          hostname: dev.hostname,
          platform: dev.platform,
          capabilities: dev.capabilities,
          lanIps: dev.lanIps,
          online: true,
          lastSeen: now
        },
        snapshot: snap,
        ts: now
      });
      if (!sent) {
        this._edgePostState = null;
        return false;
      }
      this._edgeNextSeq = nextSeq;
      this._edgePostState = {
        seq: nextSeq,
        metaSig: parts.metaSig,
        headerSig: parts.headerSig,
        rowJsons: parts.rowJsons,
        rowMetaByKey: parts.rowMetaByKey,
        canPatch: parts.canPatch,
        lastPostAt: now,
        lastSnapshot: snap
      };
      return 'host_state';
    } catch {
      return false;
    }
  }

  pushStreamDelta(deltaPayload) {
    if (!this.connected || !this.authenticated) return false;
    return this.sendJson(deltaPayload);
  }

  pushPrewarmHint(hintPayload = {}) {
    if (!this.connected || !this.authenticated || !hintPayload || typeof hintPayload !== 'object') {
      return false;
    }
    const cleanTid = String(hintPayload.threadId || hintPayload.id || '')
      .trim()
      .replace(/^(?:antigravity|claude):/, '');
    if (
      !cleanTid ||
      cleanTid === '__new__' ||
      cleanTid === '__new_claude__' ||
      cleanTid.startsWith('cmd-') ||
      cleanTid.startsWith('draft-') ||
      !/^[A-Za-z0-9._:-]{1,160}$/.test(cleanTid)
    ) {
      return false;
    }
    return this.sendJson({
      type: 'prewarm_hint',
      threadId: cleanTid,
      provider:
        hintPayload.provider === 'claude'
          ? 'claude'
          : hintPayload.provider === 'antigravity'
            ? 'antigravity'
            : '',
      targetDeviceId: String(hintPayload.targetDeviceId || 'auto').trim() || 'auto',
      source: String(hintPayload.source || 'remote').trim().slice(0, 32),
      forwarded: true,
      ts: Number(hintPayload.ts || Date.now())
    });
  }

  pushClaudePermissionMode(modeDoc = {}) {
    if (!this.connected || !this.authenticated || !modeDoc || typeof modeDoc !== 'object') {
      return false;
    }
    const dev = this._getDevice();
    return this.sendJson({
      type: 'claude_permission_mode',
      defaultMode: modeDoc.defaultMode || modeDoc.mode || '',
      rev: Number(modeDoc.rev || 0) || 0,
      alreadyStored: Boolean(modeDoc.alreadyStored),
      updatedAt: Number(modeDoc.updatedAt || Date.now()),
      updatedBy: modeDoc.updatedBy || dev.name || dev.id || 'Workstation',
      source: modeDoc.source || 'theo-hub'
    });
  }

  _normalizeWsUrl(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';
    let u = s;
    if (u.startsWith('https://')) u = 'wss://' + u.slice(8);
    else if (u.startsWith('http://')) u = 'ws://' + u.slice(7);
    if (!u.startsWith('ws://') && !u.startsWith('wss://')) return '';
    try {
      const parsed = new URL(u);
      if (!parsed.pathname || parsed.pathname === '/') {
        parsed.pathname = '/ws';
      }
      return parsed.toString();
    } catch {
      return '';
    }
  }

  _scheduleReconnect(isAuthError = false) {
    if (this.disposed || this.reconnectTimer) return;
    const baseDelay = isAuthError
      ? Math.min(60000, 6000 * Math.pow(2, Math.min(4, this.reconnectAttempt)))
      : Math.min(20000, 1000 * Math.pow(1.8, Math.min(6, this.reconnectAttempt)));
    const jitter = Math.floor(Math.random() * 500);
    this.reconnectAttempt += 1;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this._connect();
    }, baseDelay + jitter);
    if (typeof this.reconnectTimer.unref === 'function') {
      this.reconnectTimer.unref();
    }
  }

  async _decodeFrameData(rawData) {
    if (typeof rawData === 'string') return rawData;
    if (Buffer.isBuffer(rawData)) return rawData.toString('utf8');
    if (rawData instanceof ArrayBuffer) return Buffer.from(rawData).toString('utf8');
    if (ArrayBuffer.isView(rawData)) {
      return Buffer.from(rawData.buffer, rawData.byteOffset, rawData.byteLength).toString('utf8');
    }
    if (rawData && typeof rawData.text === 'function') {
      return await rawData.text();
    }
    return String(rawData || '');
  }

  _connect() {
    if (this.disposed) return;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    const wsUrl = this._normalizeWsUrl(this.getEdgeUrl());
    this.currentUrl = wsUrl;
    if (!wsUrl) {
      return;
    }
    if (typeof WebSocket !== 'function') {
      this.lastError = 'Global WebSocket API unavailable in this Node runtime';
      return;
    }
    const authToken = this.authTokenOverride || deriveEdgeAuthToken(this.getRelayKey());
    if (!authToken) {
      this.lastError = 'Missing relay auth key (~/.theo/credentials.json)';
      return;
    }

    const dev = this._getDevice();
    let fullUrl = wsUrl;
    try {
      const u = new URL(wsUrl);
      u.searchParams.set('role', 'host');
      u.searchParams.set('deviceId', dev.id);
      fullUrl = u.toString();
    } catch {}

    let sock;
    try {
      sock = new WebSocket(fullUrl);
    } catch (err) {
      this.lastError = String(err?.message || err);
      this._scheduleReconnect();
      return;
    }
    this.ws = sock;
    this.authRejected = false;
    this.relaySupportsRowPatch = false;

    sock.addEventListener('open', () => {
      if (this.ws !== sock) return;
      this.connected = true;
      const openIdleMs = getHostIdleMs();
      // Do NOT reset reconnectAttempt until auth_ok arrives (prevents 1s reconnect storm on 4001)
      this.sendJson({
        type: 'auth_host',
        token: authToken,
        protocol: 2,
        supportsRowPatch: true,
        ...(openIdleMs !== null ? { idleMs: openIdleMs } : {}),
        device: {
          id: dev.id,
          name: dev.name,
          role: dev.role,
          hostname: dev.hostname,
          username: dev.username,
          platform: dev.platform,
          capabilities: dev.capabilities,
          lanIps: dev.lanIps,
          online: true,
          lastSeen: Date.now()
        }
      });

      if (this.pingTimer) clearInterval(this.pingTimer);
      this.pingTimer = setInterval(() => {
        if (!this.connected || !this.authenticated || this.ws !== sock) return;
        this.lastPingSentAt = Date.now();
        const pingIdleMs = getHostIdleMs();
        this.sendJson({
          type: 'ping',
          ts: this.lastPingSentAt,
          ...(pingIdleMs !== null ? { idleMs: pingIdleMs } : {})
        });
      }, 25000);
      if (typeof this.pingTimer.unref === 'function') {
        this.pingTimer.unref();
      }
    });

    sock.addEventListener('message', async (ev) => {
      if (this.ws !== sock) return;
      let msg;
      try {
        const text = await this._decodeFrameData(ev.data);
        msg = JSON.parse(text);
      } catch {
        return;
      }
      if (!msg || typeof msg !== 'object') return;

      if (msg.type === 'auth_err') {
        this.authenticated = false;
        this.authRejected = true;
        this.lastError = String(msg.error || 'Edge relay authentication rejected');
        return;
      }

      if (msg.type === 'auth_ok') {
        this.authenticated = true;
        this.authRejected = false;
        this.reconnectAttempt = 0;
        this.lastError = '';
        this.lastConnectedAt = Date.now();
        this.relaySupportsRowPatch = Boolean(
          msg.supportsRowPatch || Number(msg.protocol || 0) >= 2
        );
        this._resetEdgePostState();
        if (Array.isArray(msg.devices)) {
          this.fleetDevices = msg.devices;
          if (this.onFleetDevicesUpdated) this.onFleetDevicesUpdated(this.fleetDevices);
        }
        this.pushHostState(null, { forceFull: true }).catch(() => {});
        return;
      }

      if (msg.type === 'pong') {
        if (msg.echoTs) {
          this.latencyMs = Math.max(1, Date.now() - Number(msg.echoTs));
        }
        return;
      }

      if (msg.type === 'devices_presence' && Array.isArray(msg.devices)) {
        this.fleetDevices = msg.devices;
        if (this.onFleetDevicesUpdated) this.onFleetDevicesUpdated(this.fleetDevices);
        return;
      }

      if (msg.type === 'host_state' && msg.deviceId) {
        const curDev = this._getDevice();
        if (msg.deviceId !== curDev.id && msg.snapshot) {
          if (!(this.peerSnapshots instanceof Map)) this.peerSnapshots = new Map();
          this.peerSnapshots.set(msg.deviceId, {
            deviceId: msg.deviceId,
            deviceName: msg.deviceName || msg.device?.name || msg.deviceId,
            device: msg.device || null,
            seq: typeof msg.seq === 'number' && Number.isFinite(msg.seq) ? msg.seq : null,
            snapshot: msg.snapshot,
            updatedAt: Date.now()
          });
          if (this.onPeerHostState) this.onPeerHostState(msg);
        }
        return;
      }

      if (msg.type === 'host_row_patch' && msg.deviceId) {
        const curDev = this._getDevice();
        if (msg.deviceId !== curDev.id) {
          if (!(this.peerSnapshots instanceof Map)) this.peerSnapshots = new Map();
          if (!(this._peerResyncAt instanceof Map)) this._peerResyncAt = new Map();
          const peerEntry = this.peerSnapshots.get(msg.deviceId) || null;
          const hasSeq = typeof msg.seq === 'number' && Number.isFinite(msg.seq);
          const seqValid =
            !hasSeq ||
            (peerEntry &&
              typeof peerEntry.seq === 'number' &&
              Number.isFinite(peerEntry.seq) &&
              msg.seq === peerEntry.seq + 1);
          const merged =
            peerEntry?.snapshot && seqValid ? applyRowPatchToSnapshot(peerEntry.snapshot, msg) : null;
          if (merged) {
            this.peerSnapshots.set(msg.deviceId, {
              deviceId: msg.deviceId,
              deviceName: msg.deviceName || peerEntry.deviceName || msg.deviceId,
              device: peerEntry.device || null,
              seq: hasSeq ? msg.seq : peerEntry.seq ?? null,
              snapshot: merged,
              updatedAt: Date.now()
            });
            if (this.onPeerHostState) {
              this.onPeerHostState({
                ...msg,
                type: 'host_state',
                snapshot: merged
              });
            }
          } else {
            const nowMs = Date.now();
            const lastReq = Number(this._peerResyncAt.get(msg.deviceId) || 0);
            if (nowMs - lastReq >= 1500) {
              this._peerResyncAt.set(msg.deviceId, nowMs);
              this.forwardRpcToDevice(msg.deviceId, { action: 'getState' }, 8000)
                .then((res) => {
                  const st = res?.state || res?.result?.state || null;
                  const resSeq =
                    typeof res?.seq === 'number'
                      ? res.seq
                      : typeof res?.result?.seq === 'number'
                        ? res.result.seq
                        : null;
                  if (st && typeof st === 'object') {
                    this.peerSnapshots.set(msg.deviceId, {
                      deviceId: msg.deviceId,
                      deviceName: peerEntry?.deviceName || st?.device?.name || msg.deviceId,
                      device: st.device || peerEntry?.device || null,
                      seq: resSeq,
                      snapshot: st,
                      updatedAt: Date.now()
                    });
                    if (this.onPeerHostState) {
                      this.onPeerHostState({
                        type: 'host_state',
                        deviceId: msg.deviceId,
                        deviceName: peerEntry?.deviceName || st?.device?.name || msg.deviceId,
                        ...(resSeq !== null ? { seq: resSeq } : {}),
                        snapshot: st
                      });
                    }
                  }
                })
                .catch(() => {});
            }
          }
        }
        return;
      }

      if (msg.type === 'prewarm_hint' || msg.type === 'prewarmHint') {
        if (this.onPrewarmHint) {
          Promise.resolve(this.onPrewarmHint(msg)).catch(() => {});
        }
        return;
      }

      if (msg.type === 'stream_delta' && msg.deviceId) {
        const curDev = this._getDevice();
        if (msg.deviceId !== curDev.id && this.onPeerStreamDelta) {
          this.onPeerStreamDelta(msg);
        }
        return;
      }

      if (msg.type === 'claude_permission_mode' && (msg.defaultMode || msg.mode)) {
        if (this.onClaudePermissionMode) {
          Promise.resolve(this.onClaudePermissionMode(msg)).catch(() => {});
        }
        return;
      }

      if (msg.type === 'rpc_res' && msg.reqId && this.pendingPeerRpcs.has(msg.reqId)) {
        const pending = this.pendingPeerRpcs.get(msg.reqId);
        this.pendingPeerRpcs.delete(msg.reqId);
        clearTimeout(pending.timer);
        pending.resolve(
          msg.ok === false
            ? { ok: false, error: msg.error || 'Peer error' }
            : msg.result || { ok: true }
        );
        return;
      }

      if (msg.type === 'request_sync') {
        const wantFull = Boolean(msg.forceFull || msg.reason === 'seq_gap' || msg.reason === 'oversize');
        this.pushHostState(null, { forceFull: wantFull, forceHeartbeat: true }).catch(() => {});
        return;
      }

      if (msg.type === 'rpc_cmd') {
        const curDev = this._getDevice();
        if (
          msg.targetDeviceId &&
          msg.targetDeviceId !== 'auto' &&
          msg.targetDeviceId !== curDev.id
        ) {
          return;
        }
        const cmdObj = msg.cmd || msg;
        const cmdAction = String(cmdObj?.action || cmdObj?.type || '').trim();
        try {
          let res;
          if (cmdAction === 'getState') {
            if (!this._edgePostState?.lastSnapshot) {
              await this.pushHostState(null, { forceFull: true }).catch(() => {});
            } else {
              await this.pushHostState().catch(() => {});
            }
            const stateSnap = this._edgePostState?.lastSnapshot || (await this.buildHostState());
            const seqNum =
              typeof this._edgePostState?.seq === 'number' && Number.isFinite(this._edgePostState.seq)
                ? this._edgePostState.seq
                : undefined;
            res = {
              ok: true,
              ...(seqNum !== undefined ? { seq: seqNum } : {}),
              state: stateSnap
            };
          } else {
            res = await this.onRpcCommand(cmdObj);
          }
          if (msg.reqId) {
            this.sendJson({
              type: 'rpc_res',
              reqId: msg.reqId,
              clientConnId: msg.clientConnId || '',
              deviceId: curDev.id,
              deviceName: curDev.name,
              ok: res?.ok !== false,
              result: res
            });
          }
        } catch (err) {
          if (msg.reqId) {
            this.sendJson({
              type: 'rpc_res',
              reqId: msg.reqId,
              clientConnId: msg.clientConnId || '',
              deviceId: curDev.id,
              deviceName: curDev.name,
              ok: false,
              error: String(err?.message || err)
            });
          }
        }
      }
    });

    const handleCloseOrErr = (evt) => {
      if (this.ws !== sock) return;
      const closeCode = Number(evt?.code || 0);
      if (evt && evt.message) {
        this.lastError = String(evt.message);
      } else if (closeCode === 4001) {
        this.authRejected = true;
        this.lastError = 'Edge relay authentication failed (4001)';
      } else if (closeCode === 4002) {
        // Superseded by another active TheoRemoteBridge on this host — back off quietly
        this.lastError = 'Superseded by active host socket';
      }
      this.connected = false;
      this.authenticated = false;
      this.relaySupportsRowPatch = false;
      this.ws = null;
      this._resetEdgePostState();
      if (this.pingTimer) {
        clearInterval(this.pingTimer);
        this.pingTimer = null;
      }
      this._flushPendingPeerRpcs('Edge relay socket closed');
      if (closeCode === 4002) {
        return;
      }
      this._scheduleReconnect(this.authRejected || closeCode === 4001);
    };

    sock.addEventListener('close', handleCloseOrErr);
    sock.addEventListener('error', handleCloseOrErr);
  }
}

module.exports = {
  TheoEdgeRelayClient,
  buildRemoteStatePostParts,
  applyRowPatchToSnapshot
};
