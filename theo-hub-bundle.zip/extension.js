const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');
const vm = require('vm');
const { spawn } = require('child_process');
const vscode = require('vscode');
const { AntigravityDataStore } = require('./store');
const { HubStateStore } = require('./state');
const { isClaudeDesktopScratchPath } = require('./data');
const { SessionActivityTracker } = require('./activity');
const { SessionTabManager } = require('./session-tabs');
const { HubProvider } = require('./hub');
let activeHubInstance = null;
let {
  ensureAntigravityBridgeInstalled,
  prepatchInstalledExtensions,
  prepatchInstalledExtensionsAsync
} = require('./bridge');

// Patches installed extensions in a worker thread when the loaded bridge.js offers it (2026-11-12), so a
// slow bundle patch never blocks the Extension Host; an older bridge.js falls back to the in-thread call.
function prepatchInstalledExtensionsOffThread(extRoot, options = {}) {
  try {
    const run =
      typeof prepatchInstalledExtensionsAsync === 'function'
        ? prepatchInstalledExtensionsAsync
        : prepatchInstalledExtensions;
    return Promise.resolve(run(extRoot, options)).catch(() => {});
  } catch {}
  return Promise.resolve();
}
const { TheoRemoteBridge, TheoServiceBridgeClient } = require('./remote');
const { AccountVaultManager } = require('./accounts');
const {
  loadTheoCredentials,
  deriveEdgeAuthToken,
  resolveNodeBinaryInfo,
  isLegacyVsCodePhoneBridgeEnabled,
  recordServiceCutoverEvent
} = require('./device-identity');
// Resolved at call time: after a bridge restart the bridge and its relay client read idle time from the
// freshly loaded device-identity, so editor activity must be recorded on that same module copy.
function noteLocalUserActivity() {
  try {
    require('./device-identity').noteLocalUserActivity();
  } catch {}
}
const PREWARM_GUARD_SYMBOL = Symbol.for('bhfirms.theoHub.prewarmGuard');
function isPrewarmGuardActive() {
  return Number(globalThis[PREWARM_GUARD_SYMBOL]?.depth || 0) > 0;
}
let pcSetupMod = require('./pc-setup');
const { ensureExcelPreviewRegistered } = require('./compat/excel-preview.cjs');
const { parseSessionUri } = require('./compat/antigravity-tab-state.cjs');

function isPidAlive(pid) {
  const n = Number(pid || 0);
  if (!n || n <= 0) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch (err) {
    return err && err.code === 'EPERM';
  }
}

function getFileMtimeMs(filePath) {
  try {
    return Math.floor(fs.statSync(filePath).mtimeMs);
  } catch {
    return 0;
  }
}

// Hot swap without needless phone-link restarts (2026-11-12). Sessions editing ~/bhfirms/theo-hub save files
// minutes apart, and every swap used to dispose and restart the remote bridge (phone link + relay):
// - swap only once the changed files have been quiet for HOT_SWAP_QUIET_MS (a change that keeps moving is
//   still picked up after HOT_SWAP_MAX_DEFER_MS), so a burst of saves is one swap and no half-written file
//   is copied;
// - a save that leaves the bytes identical never swaps;
// - only a change to HOT_SWAP_RESTART_FILES (the modules the bridge is built from) restarts the bridge;
//   every other module is swapped in place, the way a signed bundle update already is.
const HOT_SWAP_QUIET_MS = 20 * 1000;
const HOT_SWAP_MAX_DEFER_MS = 10 * 60 * 1000;
const HOT_SWAP_COPY_RETRY_MS = 60 * 1000;
// remote.js plus every module it binds functions from at load time (its top-level require()s); classes
// from store/state/hub/accounts/activity/session-tabs are swapped by prototype instead.
const HOT_SWAP_RESTART_FILES = new Set([
  'remote.js',
  'ws-server.js',
  'device-identity.js',
  'edge-relay-client.js',
  'direct-runner.js',
  'bundle-updater.js',
  'pc-setup.js',
  'unsaved-work.js'
]);

// Pure decision for one 6 s poll tick: reads files, writes nothing. `memo` (rel -> { key, same, retryAt })
// caches byte comparisons per src:dst mtime pair and holds back a failed copy until retryAt.
// Returns { action: 'idle' } or { action: 'wait' | 'swap', toCopy, installedChanged, newestChange, maxMtime,
// needsRestart }.
function planHotSwap({
  repoRoot,
  extRoot,
  watchedFiles,
  loadedMtime = 0,
  nowMs = Date.now(),
  deferSince = 0,
  memo = new Map(),
  quietMs = HOT_SWAP_QUIET_MS,
  maxDeferMs = HOT_SWAP_MAX_DEFER_MS,
  forceCompare = null // rels saved again while a swap checked them: compare bytes even if dst looks newer
}) {
  const toCopy = [];
  const installedChanged = [];
  let newestChange = 0;
  let maxMtime = 0;
  // An installed folder that is a git checkout is never written: its own edits still load (installedChanged),
  // but nothing from the repo is copied over it.
  const extIsGitCheckout = isGitCheckoutFolder(extRoot);
  for (const rel of watchedFiles) {
    const src = path.join(repoRoot, rel);
    const dst = path.join(extRoot, rel);
    const srcM = getFileMtimeMs(src);
    const dstM = getFileMtimeMs(dst);
    if (dstM > maxMtime) maxMtime = dstM;
    // The installed copy itself changed after the loaded code (install_local.py, another window's copy).
    if (dstM > loadedMtime + 500) {
      installedChanged.push(rel);
      if (dstM > newestChange) newestChange = dstM;
    }
    if (extIsGitCheckout || srcM <= 0 || path.resolve(src) === path.resolve(dst)) continue;
    if (srcM <= dstM + 500 && !(forceCompare && forceCompare.has(rel))) continue;
    const key = `${srcM}:${dstM}`;
    const seen = memo.get(rel);
    const fresh = Boolean(seen && seen.key === key);
    if (fresh && seen.same) continue; // touched but unchanged (git checkout, an empty save)
    if (fresh && nowMs < Number(seen.retryAt || 0)) continue; // copy failed; retry later
    let differs = true;
    if (!fresh || seen.same !== false) {
      try {
        differs = !fs.readFileSync(src).equals(fs.readFileSync(dst));
      } catch {}
      memo.set(rel, { key, same: !differs });
    }
    if (!differs) continue;
    toCopy.push(rel);
    if (srcM > newestChange) newestChange = srcM;
  }
  const pending = toCopy.length > 0 || installedChanged.length > 0 || (loadedMtime === 0 && maxMtime > 0);
  if (!pending) return { action: 'idle' };
  const changed = [...new Set([...toCopy, ...installedChanged])];
  const needsRestart = loadedMtime === 0 || changed.some((rel) => HOT_SWAP_RESTART_FILES.has(rel));
  const waitedMs = deferSince > 0 ? nowMs - deferSince : 0;
  const action =
    newestChange > 0 && nowMs - newestChange < quietMs && waitedMs < maxDeferMs ? 'wait' : 'swap';
  return {
    action,
    toCopy,
    installedChanged,
    newestChange,
    maxMtime: Math.max(maxMtime, newestChange),
    needsRestart
  };
}

// Copies one repo file over the installed copy through a temp file + rename, so another window polling the
// same folder never require()s a half-written module. Returns true on success.
function copyFileAtomicSync(srcFile, dstFile) {
  const tmp = `${dstFile}.theo-tmp-${process.pid}-${Date.now()}`;
  try {
    fs.mkdirSync(path.dirname(dstFile), { recursive: true });
    fs.writeFileSync(tmp, fs.readFileSync(srcFile));
    fs.renameSync(tmp, dstFile);
    return true;
  } catch {
    try {
      fs.unlinkSync(tmp);
    } catch {}
    return false;
  }
}

// Validated hot swap (2026-11-18 rework of the 2026-11-16 branch after the red-team gate BLOCK):
// - the repo bytes are read once (stat first, then read); the bytes that pass the syntax check are the bytes
//   copied, so a save landing mid-check is never copied unchecked;
// - the syntax check runs in a worker thread, never on the Extension Host thread;
// - the batch is all or nothing: one file that fails the syntax check, the copy or the load check holds back
//   the whole batch, so a coupled edit never lands half way; a held batch is not retried until one of its
//   files changes on disk (buildHotSwapHold / isHotSwapHoldActive);
// - copy, load check and rollback run under the bundle updater's lock file, so another window's hot swap and
//   the signed bundle updater never interleave with ours;
// - while the load check runs, remote.js skips its companion copy (HOT_SWAP_STAGING_KEY), so nothing outside
//   the batch is written; a failed load check puts require.cache back exactly as it was;
// - rollback restores a file only while it still holds the bytes this swap wrote, and never deletes a file
//   whose backup could not be read (the swap stops before writing instead).
const HOT_SWAP_STAGING_KEY = Symbol.for('bhfirms.theoHub.hotSwapStaging');
const HOT_SWAP_SYNTAX_TIMEOUT_MS = 20 * 1000;

function writeBufferAtomicSync(buf, dstFile, { statMeta = null, allowDirectFallback = false } = {}) {
  const tmp = `${dstFile}.theo-tmp-${process.pid}-${Date.now()}`;
  let wrote = false;
  try {
    fs.mkdirSync(path.dirname(dstFile), { recursive: true });
    fs.writeFileSync(tmp, buf);
    fs.renameSync(tmp, dstFile);
    wrote = true;
  } catch {
    try {
      fs.unlinkSync(tmp);
    } catch {}
    // Restoring a backup may fall back to a direct write; a forward copy never does (no half-written module).
    if (allowDirectFallback) {
      try {
        fs.writeFileSync(dstFile, buf);
        wrote = true;
      } catch {}
    }
  }
  if (wrote && statMeta && Number.isFinite(statMeta.mtimeMs)) {
    try {
      fs.utimesSync(dstFile, Number(statMeta.atimeMs || statMeta.mtimeMs) / 1000, statMeta.mtimeMs / 1000);
    } catch {}
  }
  return wrote;
}

function isHostNodeHotSwapModule(relFile, restartRemote = false) {
  const cleanRel = String(relFile || '')
    .replace(/\\/g, '/')
    .replace(/^\.\//, '');
  if (!/\.c?js$/i.test(cleanRel)) return false;
  if (
    cleanRel === 'extension.js' ||
    cleanRel.startsWith('resources/') ||
    cleanRel.startsWith('scripts/') ||
    cleanRel.startsWith('test/')
  ) {
    return false;
  }
  if (!restartRemote && HOT_SWAP_RESTART_FILES.has(cleanRel)) {
    return false;
  }
  return true;
}

function isSyntaxCheckedHotSwapFile(relFile) {
  return /\.c?js$/i.test(String(relFile || ''));
}

// Pure: compiles each entry as a CommonJS module body (Module.wrap), the way require() will. Also runs inside
// the syntax worker through its source text, so it must not close over anything.
function compileHotSwapEntries(entries, vmMod, moduleMod) {
  for (const entry of entries || []) {
    const rel = String((entry && entry.rel) || '');
    const code = String((entry && entry.code) || '')
      .replace(/^﻿/, '')
      .replace(/^#!.*/, '');
    try {
      new vmMod.Script(moduleMod.wrap(code), { filename: rel });
    } catch (e) {
      return {
        ok: false,
        failedFile: rel,
        error: { name: String((e && e.name) || 'Error'), message: String((e && e.message) || e) }
      };
    }
  }
  return { ok: true };
}

const HOT_SWAP_SYNTAX_WORKER_SOURCE = `
const { parentPort, workerData } = require('worker_threads');
const compileHotSwapEntries = ${compileHotSwapEntries.toString()};
parentPort.postMessage(compileHotSwapEntries(workerData.entries, require('vm'), require('module')));
`;

// Resolves { ok: true } | { ok: false, failedFile, error } | { ok: false, transient: true, error } (worker could
// not start, crashed or timed out: retried later, never compiled on this thread instead).
function checkHotSwapSyntaxOffThread(entries, { timeoutMs = HOT_SWAP_SYNTAX_TIMEOUT_MS } = {}) {
  const list = (entries || []).filter((e) => e && isSyntaxCheckedHotSwapFile(e.rel));
  if (list.length === 0) return Promise.resolve({ ok: true });
  let WorkerCtor = null;
  try {
    WorkerCtor = require('worker_threads').Worker;
  } catch {}
  if (typeof WorkerCtor !== 'function') {
    return Promise.resolve({ ok: false, transient: true, error: { message: 'worker_threads unavailable' } });
  }
  return new Promise((resolve) => {
    let settled = false;
    let worker = null;
    let timer = null;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      try {
        worker?.terminate?.();
      } catch {}
      resolve(result);
    };
    const transient = (message) => finish({ ok: false, transient: true, error: { message: String(message) } });
    try {
      worker = new WorkerCtor(HOT_SWAP_SYNTAX_WORKER_SOURCE, {
        eval: true,
        workerData: { entries: list.map((e) => ({ rel: String(e.rel), code: String(e.code) })) }
      });
    } catch (error) {
      transient(error?.message || error);
      return;
    }
    timer = setTimeout(() => transient('syntax check timed out'), timeoutMs);
    if (typeof timer?.unref === 'function') timer.unref();
    worker.once('message', (msg) =>
      msg && typeof msg === 'object' ? finish(msg) : transient('unexpected syntax worker reply')
    );
    worker.once('error', (error) => transient(error?.message || error));
    worker.once('exit', (code) => transient(`syntax worker exited with code ${code}`));
  });
}

// Reads the batch from the repo (stat before read, so a save that lands in between leaves the recorded mtime
// older than the bytes and the next tick looks again) and syntax-checks it off-thread.
// Resolves { ok, stage?, failedFile?, error?, transient?, sources: Map(rel -> { buf, srcMtimeMs }) }.
async function prepareHotSwapBatch({ repoRoot, toCopy = [], checkSyntax = checkHotSwapSyntaxOffThread } = {}) {
  const sources = new Map();
  for (const rel of toCopy) {
    const srcFile = path.join(repoRoot, rel);
    try {
      const srcMtimeMs = Math.floor(fs.statSync(srcFile).mtimeMs);
      sources.set(rel, { buf: fs.readFileSync(srcFile), srcMtimeMs });
    } catch (error) {
      return { ok: false, stage: 'read', transient: true, failedFile: rel, error, sources };
    }
  }
  const entries = [];
  for (const [rel, src] of sources) {
    if (isSyntaxCheckedHotSwapFile(rel)) entries.push({ rel, code: src.buf.toString('utf8') });
  }
  const syntax = await checkSyntax(entries);
  if (!syntax || !syntax.ok) {
    return {
      ok: false,
      stage: syntax?.transient ? 'syntax-worker' : 'syntax',
      transient: Boolean(syntax?.transient),
      failedFile: syntax?.failedFile || '',
      error: syntax?.error || null,
      sources
    };
  }
  return { ok: true, sources };
}

// Same lock file and rules as bundle-updater.js (wx create, stale after 120 s), used when the loaded
// bundle-updater.js predates its lock exports (a branch switch in the shared repo, an older bundle).
const FALLBACK_BUNDLE_LOCK_API = {
  bundleLockPath: (customPath = '') =>
    customPath ||
    process.env.THEO_BUNDLE_LOCK_PATH ||
    path.join(os.homedir(), '.claude', '.theo-hub-bundle-update.lock'),
  acquireUpdateLock: (lockFile) => {
    try {
      fs.mkdirSync(path.dirname(lockFile), { recursive: true });
      if (fs.existsSync(lockFile)) {
        if (Date.now() - fs.statSync(lockFile).mtimeMs < 120000) return false;
        try {
          fs.unlinkSync(lockFile);
        } catch {}
      }
      fs.writeFileSync(lockFile, JSON.stringify({ pid: process.pid, at: Date.now() }), {
        encoding: 'utf8',
        flag: 'wx'
      });
      return true;
    } catch {
      return false;
    }
  },
  releaseUpdateLock: (lockFile) => {
    try {
      if (fs.existsSync(lockFile)) fs.unlinkSync(lockFile);
    } catch {}
  }
};

function loadBundleLockApi() {
  try {
    const updater = require('./bundle-updater');
    if (
      typeof updater?.acquireUpdateLock === 'function' &&
      typeof updater?.releaseUpdateLock === 'function' &&
      typeof updater?.bundleLockPath === 'function'
    ) {
      return updater;
    }
  } catch {}
  return FALLBACK_BUNDLE_LOCK_API;
}

// The held-swap status helpers in bundle-updater.js (sidebar card + evening digest), or null when the loaded
// bundle-updater.js predates them. Never throws.
function loadHotSwapHoldApi() {
  try {
    const updater = require('./bundle-updater');
    if (
      typeof updater?.writeHotSwapHoldStatus === 'function' &&
      typeof updater?.clearHotSwapHoldStatus === 'function' &&
      typeof updater?.hotSwapHoldRecordAction === 'function'
    ) {
      return updater;
    }
  } catch {}
  return null;
}

// True when the folder is itself a git checkout (`.git` is a folder in a clone and a file in a worktree).
// The hot swap never copies the repo over such a folder: on a developer setup it would overwrite work that
// may not be committed.
function isGitCheckoutFolder(dir) {
  if (!dir) return false;
  try {
    fs.statSync(path.join(dir, '.git'));
    return true;
  } catch {
    return false;
  }
}

// Restores each file this swap wrote, but only while it still holds exactly the bytes we wrote: a newer write
// by another window, install_local.py or the bundle updater is left alone.
// `failed` holds the files that still carry our bytes because the restore write itself failed (antivirus,
// EBUSY): the caller keeps them on the hold and retries (retryHotSwapPendingRestore).
function rollbackHotSwapWrites(extRoot, written, backups) {
  const restored = [];
  const leftAlone = [];
  const failed = new Map();
  for (const [rel, wroteBuf] of written) {
    const dstFile = path.join(extRoot, rel);
    const backup = backups.get(rel);
    let current = null;
    try {
      current = fs.readFileSync(dstFile);
    } catch {}
    if (!backup || !current || !current.equals(wroteBuf)) {
      leftAlone.push(rel);
      continue;
    }
    if (backup.existed) {
      if (writeBufferAtomicSync(backup.data, dstFile, { statMeta: backup, allowDirectFallback: true })) {
        restored.push(rel);
      } else {
        failed.set(rel, wroteBuf);
      }
    } else {
      try {
        fs.unlinkSync(dstFile);
        restored.push(rel);
      } catch {
        failed.set(rel, wroteBuf);
      }
    }
  }
  return { restored, leftAlone, failed };
}

function pendingRestoreFrom(rb, backups) {
  return rb.failed && rb.failed.size > 0 ? { written: rb.failed, backups } : null;
}

function restoreModuleCacheSnapshot(moduleCache, snapshot) {
  for (const key of Object.keys(moduleCache)) {
    if (!snapshot.has(key)) delete moduleCache[key];
  }
  for (const [key, mod] of snapshot) {
    moduleCache[key] = mod;
  }
}

// Synchronous: under the bundle lock, back up, write the checked bytes, load-check the host modules, and roll
// back on failure. `sources` comes from prepareHotSwapBatch. Returns
// { ok, stage?, failedFile?, error?, copiedFiles, rolledBack, leftAlone? }; stage is one of
// 'locked' | 'backup' | 'copy' | 'require'.
function stageHotSwapFilesWithValidation({
  extRoot,
  toCopy = [],
  sources = new Map(),
  installedChanged = [],
  restartRemote = false,
  loadModule = require,
  moduleCache = require.cache,
  lockApi = loadBundleLockApi(),
  lockFile = ''
} = {}) {
  const fail = (extra) => ({ ok: false, copiedFiles: [], rolledBack: false, ...extra });
  // Second line of the git-checkout guard (planHotSwap never plans such a copy): refuse before any write.
  if (toCopy.length > 0 && isGitCheckoutFolder(extRoot)) {
    return fail({ stage: 'copy', failedFile: toCopy[0], error: new Error('installed folder is a git checkout') });
  }
  for (const rel of toCopy) {
    if (!sources.has(rel)) return fail({ stage: 'copy', failedFile: rel, error: new Error('unchecked source') });
  }
  const lockPath = lockApi ? lockApi.bundleLockPath(lockFile) : '';
  if (lockApi && !lockApi.acquireUpdateLock(lockPath)) {
    return fail({ stage: 'locked' });
  }
  try {
    // 1. Back up every target. A target that exists but cannot be read stops the swap before anything is
    //    written: without a backup a rollback could only delete it.
    const backups = new Map();
    for (const rel of toCopy) {
      const dstFile = path.join(extRoot, rel);
      try {
        const st = fs.statSync(dstFile);
        backups.set(rel, {
          existed: true,
          data: fs.readFileSync(dstFile),
          atimeMs: st.atimeMs,
          mtimeMs: st.mtimeMs
        });
      } catch (error) {
        if (error && error.code === 'ENOENT') {
          backups.set(rel, { existed: false, data: null });
        } else {
          return fail({ stage: 'backup', failedFile: rel, error });
        }
      }
    }

    // 2. Write the checked bytes. One failed copy undoes the others (all or nothing).
    const written = new Map();
    for (const rel of toCopy) {
      const buf = sources.get(rel).buf;
      if (!writeBufferAtomicSync(buf, path.join(extRoot, rel))) {
        const rb = rollbackHotSwapWrites(extRoot, written, backups);
        return fail({
          stage: 'copy',
          failedFile: rel,
          rolledBack: rb.restored.length > 0,
          leftAlone: rb.leftAlone,
          pendingRestore: pendingRestoreFrom(rb, backups)
        });
      }
      written.set(rel, buf);
    }
    const copiedFiles = [...written.keys()];

    // 3. Load-check the host modules of the batch with remote.js's companion copy switched off.
    const effectiveRestartRemote =
      Boolean(restartRemote) ||
      copiedFiles.some((rel) => HOT_SWAP_RESTART_FILES.has(String(rel || '').replace(/\\/g, '/')));
    const candidateModules = [...new Set([...copiedFiles, ...installedChanged])].filter((rel) =>
      isHostNodeHotSwapModule(rel, effectiveRestartRemote)
    );
    const cacheSnapshot = new Map(Object.keys(moduleCache).map((key) => [key, moduleCache[key]]));
    let currentRelFile = '';
    const prevStaging = globalThis[HOT_SWAP_STAGING_KEY];
    globalThis[HOT_SWAP_STAGING_KEY] = true;
    try {
      for (const relFile of candidateModules) {
        const absPath = path.resolve(extRoot, relFile);
        let resolvedId = absPath;
        try {
          resolvedId = require.resolve(absPath);
        } catch {}
        delete moduleCache[resolvedId];
      }
      for (const relFile of candidateModules) {
        currentRelFile = relFile;
        loadModule(path.resolve(extRoot, relFile));
      }
    } catch (error) {
      restoreModuleCacheSnapshot(moduleCache, cacheSnapshot);
      const rb = rollbackHotSwapWrites(extRoot, written, backups);
      return fail({
        stage: 'require',
        failedFile: currentRelFile,
        error,
        copiedFiles,
        rolledBack: rb.restored.length > 0,
        leftAlone: rb.leftAlone,
        pendingRestore: pendingRestoreFrom(rb, backups)
      });
    } finally {
      if (prevStaging === undefined) delete globalThis[HOT_SWAP_STAGING_KEY];
      else globalThis[HOT_SWAP_STAGING_KEY] = prevStaging;
    }
    return { ok: true, copiedFiles, validatedModules: candidateModules, rolledBack: false };
  } finally {
    if (lockApi) lockApi.releaseUpdateLock(lockPath);
  }
}

// A held batch: { stage, retryAt, keys: Map(rel -> mtime) }. It stays held, with no file read and no compile,
// until one of its files changes on disk (repo copy for a file to copy, installed copy for a file another
// writer installed) or retryAt passes (Infinity for a syntax or load failure: only a new save can fix those).
// Installed-copy keys cover every watched file, not just the batch: a signed release or another window writing
// the installed folder releases the hold, so this window does not keep running old code (gate round 2).
// `pendingRestore` ({ written, backups }) carries files whose rollback write failed, retried while held.
function buildHotSwapHold({
  repoRoot,
  extRoot,
  stage,
  toCopy = [],
  installedChanged = [],
  watchedFiles = [],
  sources = new Map(),
  retryAt = Infinity,
  pendingRestore = null
}) {
  const keys = new Map();
  for (const rel of toCopy) {
    const seen = sources.get(rel);
    keys.set(`src:${rel}`, seen ? seen.srcMtimeMs : getFileMtimeMs(path.join(repoRoot, rel)));
  }
  for (const rel of new Set([...watchedFiles, ...toCopy, ...installedChanged])) {
    keys.set(`dst:${rel}`, getFileMtimeMs(path.join(extRoot, rel)));
  }
  return { stage, retryAt, keys, pendingRestore };
}

// Combines two pending restores. The newer write wins for "bytes we wrote" (that is what the file holds now),
// the older backup wins for "bytes to restore" (the newer batch backed up the failed batch's bytes).
function mergePendingRestore(older, newer) {
  if (!older || !older.written || older.written.size === 0) return newer || null;
  if (!newer || !newer.written || newer.written.size === 0) return older;
  return {
    written: new Map([...older.written, ...newer.written]),
    backups: new Map([...newer.backups, ...older.backups])
  };
}

// Retries the rollback of files whose restore write failed, under the bundle lock, while they still hold our
// bytes. The hold's installed-copy keys are refreshed for the files it restores, so our own restore does not
// release the hold. Returns the number of files still pending.
function retryHotSwapPendingRestore(hold, { extRoot, lockApi = loadBundleLockApi(), lockFile = '' } = {}) {
  const pending = hold && hold.pendingRestore;
  if (!pending || !pending.written || pending.written.size === 0) return 0;
  const lockPath = lockApi ? lockApi.bundleLockPath(lockFile) : '';
  if (lockApi && !lockApi.acquireUpdateLock(lockPath)) return pending.written.size;
  try {
    const rb = rollbackHotSwapWrites(extRoot, pending.written, pending.backups);
    for (const rel of rb.restored) {
      pending.written.delete(rel);
      hold.keys.set(`dst:${rel}`, getFileMtimeMs(path.join(extRoot, rel)));
    }
    // Rewritten by someone else since: not ours to restore, and its new mtime releases the hold.
    for (const rel of rb.leftAlone) pending.written.delete(rel);
    if (pending.written.size === 0) hold.pendingRestore = null;
    return pending.written.size;
  } finally {
    if (lockApi) lockApi.releaseUpdateLock(lockPath);
  }
}

function isHotSwapHoldActive(hold, { repoRoot, extRoot, nowMs = Date.now() } = {}) {
  if (!hold) return false;
  if (nowMs >= Number(hold.retryAt)) return false;
  for (const [key, mtime] of hold.keys) {
    const rel = key.slice(4);
    const root = key.startsWith('src:') ? repoRoot : extRoot;
    if (getFileMtimeMs(path.join(root, rel)) !== mtime) return false;
  }
  return true;
}

// Appends "<iso> +<ms since activate()> <phase>" lines to ~/.claude/.theo-hub-activation.log so a slow
// THEO start can be attributed to a phase (sidebar attach, first refresh, Claude Code activation, ...).
function createActivationPhaseLogger(context) {
  const startedAt = Date.now();
  let logPath = '';
  try {
    const claudeDir = path.join(os.homedir(), '.claude');
    fs.mkdirSync(claudeDir, { recursive: true });
    logPath = path.join(claudeDir, '.theo-hub-activation.log');
    if (fs.existsSync(logPath) && fs.statSync(logPath).size > 256 * 1024) {
      fs.unlinkSync(logPath);
    }
    fs.appendFileSync(
      logPath,
      `\n[${new Date(startedAt).toISOString()}] activate() start (ext ${context?.extension?.packageJSON?.version || '?'}, host pid ${process.pid})\n`,
      'utf8'
    );
  } catch {
    logPath = '';
  }
  return (phase) => {
    const elapsed = Date.now() - startedAt;
    const line = `[${new Date().toISOString()}] +${elapsed} ms ${phase}`;
    try {
      console.log(`[theo-hub] ${line}`);
    } catch {}
    if (logPath) {
      try {
        fs.appendFileSync(logPath, `${line}\n`, 'utf8');
      } catch {}
    }
  };
}

function resolveLegacyPhoneBridgeSetting({ env = process.env, cfg = null } = {}) {
  const envRaw = env?.THEO_LEGACY_VSCODE_BRIDGE;
  if (envRaw !== undefined && String(envRaw).trim() !== '') {
    const norm = String(envRaw).trim().toLowerCase();
    if (norm === '1' || norm === 'true' || norm === 'yes' || norm === 'on') return true;
    if (norm === '0' || norm === 'false' || norm === 'no' || norm === 'off') return false;
  }
  try {
    if (cfg && typeof cfg.inspect === 'function') {
      const inspected = cfg.inspect('legacyVsCodePhoneBridge');
      if (typeof inspected?.globalValue === 'boolean') {
        return inspected.globalValue;
      }
    }
    if (cfg && typeof cfg.get === 'function') {
      return Boolean(cfg.get('legacyVsCodePhoneBridge', false));
    }
  } catch {}
  return false;
}

async function syncLegacyPhoneBridgePreference({
  enabled,
  stateStore,
  recordEvent = null
} = {}) {
  try {
    const curPrefs = stateStore?.readRawLocalState?.()?.preferences || {};
    if (Boolean(curPrefs.legacyVsCodePhoneBridge) !== Boolean(enabled)) {
      if (enabled) {
        try {
          (
            recordEvent ||
            require('./device-identity').recordServiceCutoverEvent ||
            recordServiceCutoverEvent
          )?.('legacyBridgeFlips', 'legacyVsCodePhoneBridge', {
            ...(stateStore?.diskBackupPath ? { hubStateFile: stateStore.diskBackupPath } : {})
          });
        } catch {}
      }
      await stateStore?.updatePreferences?.({
        legacyVsCodePhoneBridge: Boolean(enabled),
        legacyVsCodePhoneBridgeUpdatedAt: Date.now()
      });
    }
    stateStore?.flushDiskBackupSync?.();
  } catch {}
  return Boolean(enabled);
}

function ensureRelayKeepaliveDaemon(context, opts = {}) {
  try {
    const homeDir = String(opts.homeDir || os.homedir());
    const checkPidAlive = typeof opts.isPidAliveFn === 'function' ? opts.isPidAliveFn : isPidAlive;
    const killPid = typeof opts.killFn === 'function' ? opts.killFn : (p) => process.kill(p);
    const spawnProc = typeof opts.spawnFn === 'function' ? opts.spawnFn : spawn;
    const repoRoot = String(opts.repoRoot || path.join(homeDir, 'bhfirms', 'theo-hub'));
    const extRoot = context?.extensionPath || __dirname;
    const candidateRoots = Array.isArray(opts.candidateRoots) ? opts.candidateRoots : [repoRoot, extRoot];
    const mtimeOfRoot = (r, scriptPath) =>
      Math.max(
        getFileMtimeMs(scriptPath),
        getFileMtimeMs(path.join(r, 'remote.js')),
        getFileMtimeMs(path.join(r, 'state.js')),
        getFileMtimeMs(path.join(r, 'store.js')),
        getFileMtimeMs(path.join(r, 'accounts.js')),
        getFileMtimeMs(path.join(r, 'data.js')),
        getFileMtimeMs(path.join(r, 'device-identity.js')),
        getFileMtimeMs(path.join(r, 'pc-setup.js')),
        getFileMtimeMs(path.join(r, 'unsaved-work.js')),
        getFileMtimeMs(path.join(r, 'bundle-updater.js')),
        getFileMtimeMs(path.join(r, 'direct-runner.js')),
        getFileMtimeMs(path.join(r, 'edge-relay-client.js'))
      );
    let keepaliveScript = '';
    let workingRoot = extRoot;
    let diskMaxMtime = 0;
    for (const r of candidateRoots) {
      const p = path.join(r, 'scripts', 'relay_keepalive.cjs');
      if (fs.existsSync(p)) {
        const candidateMtime = mtimeOfRoot(r, p);
        if (!keepaliveScript || candidateMtime > diskMaxMtime) {
          keepaliveScript = p;
          workingRoot = r;
          diskMaxMtime = candidateMtime;
        }
      }
    }
    if (!keepaliveScript) return { action: 'no_script' };

    const claudeDir = path.join(homeDir, '.claude');
    if (!fs.existsSync(claudeDir)) {
      fs.mkdirSync(claudeDir, { recursive: true });
    }
    const pidFile = path.join(claudeDir, '.theo-relay-keepalive.pid');
    const metaFile = path.join(claudeDir, '.theo-relay-keepalive.json');
    const logFile = path.join(claudeDir, '.theo-relay-keepalive.log');
    const directActiveFile = path.join(claudeDir, '.theo-direct-active.json');

    let existingPid = 0;
    if (fs.existsSync(pidFile)) {
      existingPid = Number(String(fs.readFileSync(pidFile, 'utf8')).trim() || 0);
    }
    let existingBootMtime = 0;
    if (fs.existsSync(metaFile)) {
      try {
        const meta = JSON.parse(fs.readFileSync(metaFile, 'utf8'));
        existingBootMtime = Number(meta?.bootMtime || 0);
        if (!existingPid && meta?.pid) existingPid = Number(meta.pid);
      } catch {}
    }

    if (checkPidAlive(existingPid)) {
      if (existingBootMtime >= diskMaxMtime - 1500) {
        return { action: 'current', pid: existingPid };
      }
      let hasActiveDirectRuns = false;
      try {
        if (fs.existsSync(directActiveFile)) {
          const activeInfo = JSON.parse(fs.readFileSync(directActiveFile, 'utf8'));
          if (
            Number(activeInfo?.pid || 0) === existingPid &&
            Number(activeInfo?.count || 0) > 0 &&
            Date.now() - Number(activeInfo?.updatedAt || 0) < 30 * 60 * 1000
          ) {
            hasActiveDirectRuns = true;
          }
        }
      } catch {}
      if (hasActiveDirectRuns) {
        return { action: 'deferred_active_runs', pid: existingPid };
      }
      try {
        killPid(existingPid);
      } catch {}
    }

    try {
      if (fs.existsSync(logFile) && fs.statSync(logFile).size > 2 * 1024 * 1024) {
        fs.unlinkSync(logFile);
      }
    } catch {}

    const nodeInfo = resolveNodeBinaryInfo();
    const usePlainNode = Boolean(nodeInfo?.executable && !nodeInfo.electronRunAsNode);
    const spawnExe = usePlainNode ? nodeInfo.executable : process.execPath;
    const spawnEnv = usePlainNode
      ? { ...process.env }
      : { ...process.env, ELECTRON_RUN_AS_NODE: '1' };
    const child = spawnProc(spawnExe, [keepaliveScript], {
      cwd: workingRoot,
      detached: false,
      windowsHide: true,
      stdio: 'ignore',
      env: spawnEnv
    });
    child?.unref?.();
    if (child?.pid) {
      fs.writeFileSync(pidFile, String(child.pid), 'utf8');
      fs.writeFileSync(
        metaFile,
        JSON.stringify({
          pid: child.pid,
          startedAt: Date.now(),
          bootMtime: diskMaxMtime,
          script: keepaliveScript
        }),
        'utf8'
      );
    }
    return { action: 'spawned', pid: child?.pid || 0 };
  } catch {
    return { action: 'error' };
  }
}

async function syncHideClaudeDesktopOnStartup({ vscodeApi = vscode, stateStore, hub, remote } = {}) {
  try {
    const cfg = vscodeApi?.workspace?.getConfiguration?.('antigravityHub');
    if (!cfg || !stateStore) {
      return;
    }
    const inspected =
      typeof cfg.inspect === 'function' ? cfg.inspect('hideClaudeDesktopSessions') : null;
    const cfgVal = cfg.get('hideClaudeDesktopSessions', false);
    const hasExplicitSetting = inspected
      ? inspected.globalValue !== undefined ||
        inspected.workspaceValue !== undefined ||
        inspected.workspaceFolderValue !== undefined
      : cfgVal !== undefined;
    const curPrefs = stateStore.read().preferences || {};
    const prefVal = Boolean(curPrefs.hideClaudeDesktopSessions);

    if (stateStore.adoptedHideClaudeDesktopOnBoot) {
      stateStore.adoptedHideClaudeDesktopOnBoot = false;
      const globalDiffers = !inspected || Boolean(inspected.globalValue) !== prefVal;
      const wsDiffers =
        inspected?.workspaceValue !== undefined && Boolean(inspected.workspaceValue) !== prefVal;
      const wsFolderDiffers =
        inspected?.workspaceFolderValue !== undefined &&
        Boolean(inspected.workspaceFolderValue) !== prefVal;
      if (globalDiffers || wsDiffers || wsFolderDiffers) {
        if (hub) {
          hub._writingHideClaudeDesktopConfigCount =
            Number(hub._writingHideClaudeDesktopConfigCount || 0) + 1;
          hub._writingHideClaudeDesktopConfig = true;
        }
        try {
          if (globalDiffers) {
            await cfg.update(
              'hideClaudeDesktopSessions',
              prefVal,
              vscodeApi?.ConfigurationTarget?.Global ?? 1
            );
          }
          if (wsDiffers) {
            await cfg.update(
              'hideClaudeDesktopSessions',
              undefined,
              vscodeApi?.ConfigurationTarget?.Workspace ?? 2
            );
          }
          if (wsFolderDiffers) {
            await cfg.update(
              'hideClaudeDesktopSessions',
              undefined,
              vscodeApi?.ConfigurationTarget?.WorkspaceFolder ?? 3
            );
          }
        } catch {} finally {
          if (hub) {
            hub._writingHideClaudeDesktopConfigCount = Math.max(
              0,
              Number(hub._writingHideClaudeDesktopConfigCount || 1) - 1
            );
            hub._writingHideClaudeDesktopConfig = hub._writingHideClaudeDesktopConfigCount > 0;
          }
        }
      }
      return;
    }

    if (hasExplicitSetting && Boolean(cfgVal) !== prefVal) {
      await stateStore.updatePreferences({
        hideClaudeDesktopSessions: Boolean(cfgVal),
        hideClaudeDesktopSessionsUpdatedAt: Date.now()
      });
      if (hub) {
        hub.lastPosted = null;
        if (typeof hub.requestRender === 'function') hub.requestRender();
        else hub.render?.();
      }
      try {
        remote?.notifyStateUpdated?.();
      } catch {}
    }
  } catch {}
}

async function runAutoOpenLastSession({ hub, tabs, store } = {}) {
  try {
    const pendingTabsPath = path.join(os.homedir(), '.claude', '.theo-pending-workspace-tabs.json');
    if (fs.existsSync(pendingTabsPath)) {
      try {
        fs.unlinkSync(pendingTabsPath);
      } catch {}
    }
    const openTabs = await tabs.getOpenTabs();
    if (openTabs.length !== 0) {
      return false;
    }
    const allThreads = hub?.snapshot?.threads || [];
    const rawLastId = await tabs.getLastConversationId();
    const lastThread = rawLastId ? allThreads.find((t) => t.id === rawLastId) : null;
    const isScratchId = (sid, thread) =>
      Boolean(
        thread?.claudeDesktopScratch ||
          hub?.isScratchDesktopSession?.(sid, thread) ||
          isClaudeDesktopScratchPath(store?.claudeFileById?.get?.(sid) || '') ||
          isClaudeDesktopScratchPath(thread?.filePath || '')
      );
    const validLastId = rawLastId && isScratchId(rawLastId, lastThread) ? '' : rawLastId;
    const fallbackThread = allThreads.find(
      (t) => t && !t.claudeDesktop && !t.claudeDesktopScratch && !isScratchId(t.id, t)
    );
    const targetId = validLastId || fallbackThread?.id || '';
    if (!targetId) {
      return false;
    }
    const matched = allThreads.find((t) => t.id === targetId);
    if (isScratchId(targetId, matched)) {
      return false;
    }
    await tabs.openThread(targetId, {
      provider: matched?.provider || 'antigravity',
      title: matched?.title || '',
      automatic: true,
      preserveFocus: false
    });
    await hub?.refresh?.();
    return true;
  } catch {
    return false;
  }
}

// Hands-free reload (auto-reload.js): off in the smoke and headless test hosts, which share no real windows.
function autoReloadAllowed() {
  return process.env.THEO_SMOKE_TEST !== '1' && process.env.THEO_HEADLESS_TEST !== '1';
}

async function activate(context) {
  const bootPhase = createActivationPhaseLogger(context);
  // First, before anything can rewrite the installed folder: which extension.js / package.json this window runs.
  if (autoReloadAllowed()) {
    try {
      require('./auto-reload').initAutoReload({
        extRoot: context?.extensionPath || __dirname,
        workspaceId:
          context?.storageUri?.fsPath ||
          vscode.workspace.workspaceFile?.toString() ||
          vscode.workspace.workspaceFolders?.[0]?.uri?.toString() ||
          ''
      });
    } catch {}
  }
  ensureExcelPreviewRegistered(vscode, context);
  const store = new AntigravityDataStore();
  const stateStore = new HubStateStore(context.globalState, { diskBackup: true });
  const activity = new SessionActivityTracker();
  const tabs = new SessionTabManager();

  let hub = null;
  const accountVault = new AccountVaultManager({
    onStateChange: () => {
      if (hub) {
        hub.refresh({ forceQuota: false });
      }
    }
  });

  let pcSetupToastInFlight = false;
  async function runTrustedUiPcSetupApply(opts = {}) {
    try {
      await remote?.refreshStatus?.().catch(() => null);
    } catch {}
    const activeRuns = Number(remote?.getStatus?.()?.activeDirectRuns || 0);
    if (activeRuns > 0) {
      vscode.window.showWarningMessage(
        `THEO PC Setup: ${activeRuns} active phone/headless session(s) running. Wait for them to finish before applying updates.`
      );
      return { ok: false, busy: true, reason: 'sessions_running', activeRuns };
    }
    const res = await pcSetupMod.applyPcSetupFromTrustedUi({
      ...opts,
      vscode,
      onStateChange: () => {
        if (hub) {
          hub.lastPosted = null;
          hub.requestRender?.();
        }
      }
    });
    if (hub) {
      hub.lastPosted = null;
      hub.render();
    }
    if (res?.busy) return res;
    if (res?.error || res?.ok === false) {
      const action = await vscode.window.showWarningMessage(
        `THEO PC Setup: ${res?.error || 'Some setup steps could not be completed.'}`,
        'View Checklist'
      );
      if (action === 'View Checklist') {
        hub?.openDetailsModal?.(true);
      }
      return res;
    }
    const v = res?.view;
    if (v?.ready) {
      vscode.window.setStatusBarMessage(
        `THEO: This PC is up to date (${v.okCount}/${v.totalCount} ready)`,
        4500
      );
      remote?.syncCloudRelay?.({ pushState: true, urgent: true })?.catch?.(() => {});
    } else if (v && v.pendingCount > 0) {
      const action = await vscode.window.showWarningMessage(
        `THEO: ${v.pendingCount} setup item(s) still need attention on this PC.`,
        'View Checklist'
      );
      if (action === 'View Checklist') {
        hub?.openDetailsModal?.(true);
      }
    }
    return res;
  }

  async function runBackgroundPcSetupCheck(opts = {}) {
    const view = await pcSetupMod.checkPcSetupStatus(opts);
    if (hub) {
      hub.lastPosted = null;
      hub.requestRender?.();
    }
    if (
      opts.promptToast !== false &&
      !pcSetupToastInFlight &&
      process.env.THEO_SMOKE_TEST !== '1' &&
      process.env.THEO_HEADLESS_TEST !== '1' &&
      pcSetupMod.shouldPromptPcSetupToast(view)
    ) {
      pcSetupToastInFlight = true;
      pcSetupMod.recordPcSetupToastShown(view);
      const titles = (view.pending || [])
        .slice(0, 2)
        .map((p) => p.title)
        .join(', ');
      const suffix =
        (view.pending || []).length > 2 ? `, +${view.pending.length - 2} more` : '';
      vscode.window
        .showInformationMessage(
          `THEO: ${view.pendingCount} setup update${view.pendingCount === 1 ? '' : 's'} ready on this PC (${titles}${suffix}).`,
          'Apply Setup',
          'View Checklist'
        )
        .then((choice) => {
          if (choice === 'Apply Setup') {
            return runTrustedUiPcSetupApply();
          }
          if (choice === 'View Checklist') {
            hub?.openDetailsModal?.(true);
          }
          return null;
        })
        .catch(() => {})
        .finally(() => {
          pcSetupToastInFlight = false;
        });
    }
    return view;
  }

  hub = new HubProvider(context, {
    store,
    stateStore,
    activity,
    tabs,
    accountVault,
    getPcSetupView: () => pcSetupMod.getLocalPcSetupView(),
    checkPcSetup: (opts) => runBackgroundPcSetupCheck({ ...opts, promptToast: false }),
    applyPcSetup: (opts) => runTrustedUiPcSetupApply(opts),
    ensureBridge: async (opts) => {
      const res = await ensureAntigravityBridgeInstalled(context, {
        forcePromptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude'),
        ...opts
      });
      hub?.setBridgeInstallReport?.(res);
      return res;
    }
  });
  activeHubInstance = hub;
  accountVault.hubRef = hub;

  const readLegacyPhoneBridgeSetting = () => {
    try {
      const cfg = vscode.workspace.getConfiguration('antigravityHub');
      return resolveLegacyPhoneBridgeSetting({ env: process.env, cfg });
    } catch {}
    return resolveLegacyPhoneBridgeSetting({ env: process.env, cfg: null });
  };

  let adapterSwapChain = Promise.resolve();
  const serializeAdapterSwap = (fn) => {
    const next = adapterSwapChain.then(fn, fn);
    adapterSwapChain = next.catch(() => {});
    return next;
  };

  const syncLegacyPhoneBridgeSetting = () =>
    syncLegacyPhoneBridgePreference({
      enabled: readLegacyPhoneBridgeSetting(),
      stateStore
    });

  const createRemoteAdapter = ({
    legacy = readLegacyPhoneBridgeSetting(),
    TheoRemoteBridgeCtor = TheoRemoteBridge,
    TheoServiceBridgeClientCtor = TheoServiceBridgeClient,
    hotSwapChangedFiles = undefined
  } = {}) => {
    const Ctor = legacy ? TheoRemoteBridgeCtor : TheoServiceBridgeClientCtor;
    return new Ctor(context, {
      vscode,
      hub,
      store,
      stateStore,
      tabs,
      accountVault,
      ...(hotSwapChangedFiles !== undefined ? { hotSwapChangedFiles } : {})
    });
  };

  const requestLegacyYieldPort = (targetRemote) =>
    new Promise((resolve) => {
      const creds = loadTheoCredentials();
      const bearer = creds.effectiveEdgeSecret
        ? deriveEdgeAuthToken(creds.effectiveEdgeSecret)
        : '';
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: targetRemote?.port || 4318,
          path: '/api/yield-port',
          method: 'POST',
          headers: bearer ? { Authorization: `Bearer ${bearer}` } : {},
          timeout: 800
        },
        (res) => {
          res.resume();
          res.on('end', () => setTimeout(resolve, 80));
        }
      );
      req.on('error', () => resolve());
      req.on('timeout', () => {
        try {
          req.destroy();
        } catch {}
        resolve();
      });
      req.end();
    });

  const startRemoteAdapter = async (targetRemote) => {
    if (!targetRemote || targetRemote.disposed) return;
    if (targetRemote.isServiceClient) {
      ensureRelayKeepaliveDaemon(context);
      if (targetRemote.disposed) return;
      await targetRemote.start().catch(() => {});
    } else {
      await requestLegacyYieldPort(targetRemote);
      if (targetRemote.disposed) return;
      await targetRemote.start().catch(() => {});
      if (targetRemote.disposed) return;
      ensureRelayKeepaliveDaemon(context);
    }
  };

  const initialLegacyPhoneBridge = await syncLegacyPhoneBridgeSetting();
  let remote = createRemoteAdapter({ legacy: initialLegacyPhoneBridge });
  hub.remote = remote;
  await syncHideClaudeDesktopOnStartup({ vscodeApi: vscode, stateStore, hub, remote });

  context.subscriptions.push(
    vscode.commands.registerCommand('antigravityHub.openRemote', async () => {
      const st = remote.getStatus();
      const items = [
        {
          label: '$(globe) Open THEO Remote PWA (GitHub Pages + Cloud Relay)',
          description: st.pwaUrl,
          target: st.pwaUrl
        },
        {
          label: '$(broadcast) Open Local Direct Bridge (Instant SSE)',
          description: st.localUrl,
          target: st.localUrl
        },
        {
          label: '$(device-mobile) Copy LAN Mobile URL (Wi-Fi)',
          description: st.lanUrl,
          copy: st.lanUrl
        },
        {
          label: '$(cloud-upload) Force Sync Snapshot to Cloud Relay Now',
          syncNow: true
        }
      ];
      const picked = await vscode.window.showQuickPick(items, {
        placeHolder: `THEO Remote Bridge (${st.listening ? `Listening on :${st.port}` : 'Cloud Relay Ready'})`
      });
      if (!picked) {
        return;
      }
      if (picked.syncNow) {
        await remote.syncCloudRelay({ pushState: true });
        vscode.window.setStatusBarMessage('THEO Remote: Snapshot synced to Cloud Relay', 3000);
      } else if (picked.copy) {
        await vscode.env.clipboard.writeText(picked.copy);
        vscode.window.setStatusBarMessage(`Copied THEO LAN URL: ${picked.copy}`, 3000);
      } else if (picked.target) {
        await vscode.env.openExternal(vscode.Uri.parse(picked.target));
      }
    }),
    vscode.commands.registerCommand('antigravityHub.syncRemoteCloud', async () => {
      const res = await remote.syncCloudRelay({ pushState: true });
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.addAccount', async (opts = {}) => {
      let provider = opts?.provider;
      if (provider !== 'antigravity' && provider !== 'claude') {
        const picked = await vscode.window.showQuickPick(
          [
            {
              label: '$(sparkle) Google Antigravity',
              description: 'Sign in an additional Google AI account (keeps existing accounts logged in)',
              provider: 'antigravity'
            },
            {
              label: '$(hubot) Anthropic Claude Code',
              description: 'Sign in an additional Claude account (keeps existing accounts logged in)',
              provider: 'claude'
            }
          ],
          { placeHolder: 'Choose which provider account to add to THEO' }
        );
        if (!picked) return null;
        provider = picked.provider;
      }
      const label = await vscode.window.showInputBox({
        title: `Add ${provider === 'claude' ? 'Claude Code' : 'Antigravity'} Account`,
        prompt: 'Optional nickname / label (e.g., Friend, Personal, Work)',
        placeHolder: 'Optional label — press Enter to skip'
      });
      if (label === undefined) return null;
      return hub.handleMessage({
        action: 'accountAdd',
        provider,
        label,
        switchOnComplete: true
      });
    }),
    vscode.commands.registerCommand('antigravityHub.switchAccount', async () => {
      const agyList = (hub.accountsView?.antigravity || []).filter(
        (a) => a && a.available !== false && !a.signedOut
      );
      const claudeList = (hub.accountsView?.claude || []).filter(
        (a) => a && a.available !== false && !a.signedOut
      );
      const items = [
        ...agyList.map((a) => ({
          label: `${a.active ? '$(check) ' : ''}Antigravity · ${a.email || a.name}`,
          description: `${a.label ? `[${a.label}] · ` : ''}${a.plan || ''}${a.active ? ' (Active)' : ''}`,
          provider: 'antigravity',
          accountId: a.id,
          active: a.active
        })),
        ...claudeList.map((a) => ({
          label: `${a.active ? '$(check) ' : ''}Claude Code · ${a.email || a.name}`,
          description: `${a.label ? `[${a.label}] · ` : ''}${a.plan || ''}${a.active ? ' (Active)' : ''}`,
          provider: 'claude',
          accountId: a.id,
          active: a.active
        })),
        {
          label: '$(add) Add another account…',
          description: 'Keep all current accounts logged in',
          addNew: true
        }
      ];
      const picked = await vscode.window.showQuickPick(items, {
        placeHolder: 'Switch active account or add a new account'
      });
      if (!picked) return null;
      if (picked.addNew) {
        return vscode.commands.executeCommand('antigravityHub.addAccount');
      }
      if (!picked.active) {
        await hub.handleMessage({
          action: 'accountSwitch',
          provider: picked.provider,
          accountId: picked.accountId
        });
      }
      return picked;
    }),
    vscode.commands.registerCommand('antigravityHub.checkPcSetup', async () => {
      await runBackgroundPcSetupCheck({ force: true, promptToast: false });
      hub?.openDetailsModal?.(true);
    }),
    vscode.commands.registerCommand('antigravityHub.applyPcSetup', async () => {
      const view = await runBackgroundPcSetupCheck({ force: true, promptToast: false });
      const msg =
        view && view.pendingCount > 0
          ? `Apply ${view.pendingCount} pending THEO setup update${view.pendingCount === 1 ? '' : 's'} on this PC?`
          : 'Re-verify and repair THEO setup on this PC?';
      const confirm = await vscode.window.showInformationMessage(
        msg,
        { modal: true },
        'Apply Setup'
      );
      if (confirm !== 'Apply Setup') return null;
      return runTrustedUiPcSetupApply();
    }),
    vscode.commands.registerCommand('antigravityHub.newSession', async (opts = {}) => {
      const res = await tabs.openNewSession({
        provider: opts?.provider === 'claude' ? 'claude' : 'antigravity'
      });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newClaudeSession', async () => {
      const res = await tabs.openNewSession({ provider: 'claude' });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newSessionBeside', async (opts = {}) => {
      const res = await tabs.openNewSession({
        provider: opts?.provider === 'claude' ? 'claude' : 'antigravity',
        beside: true
      });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newClaudeSessionBeside', async () => {
      const res = await tabs.openNewSession({ provider: 'claude', beside: true });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.refresh', async () => {
      await hub.refresh({ forceQuota: true });
    }),
    vscode.commands.registerCommand('antigravityHub.repairBridge', async () => {
      const res = await ensureAntigravityBridgeInstalled(context, {
        promptReload: true,
        forcePromptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude')
      });
      hub.setBridgeInstallReport?.(res);
      await hub.refresh();
    }),
    vscode.commands.registerCommand('antigravityHub.markThreadSeen', async (payload) => {
      const threadId = typeof payload === 'string' ? payload : payload?.id || payload?.threadId;
      const seenAt = typeof payload === 'object' ? payload?.seenAt : 0;
      if (threadId) {
        await hub.markThreadSeen(threadId, seenAt);
      }
    }),
    vscode.commands.registerCommand('antigravityHub.activityChanged', async (payload) => {
      if (payload && typeof payload === 'object') {
        activity.ingestBridgeEvent(payload);
        if (Array.isArray(payload.conversations) && payload.conversations.length > 0) {
          hub.syncOpenTabBadges();
          hub.requestRender();
        }
        const evType = String(payload.type || '');
        const isBackgroundOrBeside = Boolean(
          payload.preserveFocus || payload.beside || evType.endsWith('-bg')
        );
        const isExplicitOpenCommand =
          !isBackgroundOrBeside &&
          (evType === 'reveal' ||
            evType === 'reveal-draft' ||
            evType === 'open-thread' ||
            evType === 'open-new');
        const isTabEvent =
          isExplicitOpenCommand ||
          evType === 'tab-closed' ||
          evType === 'reveal-bg' ||
          evType === 'reveal-draft-bg' ||
          evType === 'open-thread-bg' ||
          evType === 'open-new-bg' ||
          evType === 'focus' ||
          evType === 'tab-state' ||
          evType === 'tab-resolved' ||
          evType === 'url' ||
          evType === 'claude-setup-panel' ||
          evType === 'claude-register-session' ||
          evType === 'claude-create-panel';
        if (isTabEvent && isPrewarmGuardActive()) {
          return;
        }
        if (evType === 'claude-permission' || evType === 'claude-permission-cleared' || evType === 'claude-permission-responded') {
          try {
            remote?.notifyStateUpdated?.({ force: true });
          } catch {}
        } else if (isTabEvent) {
          try {
            remote?.pushUiStateIfConnected?.();
          } catch {}
        }
        if (evType === 'tab-closed') {
          hub.clearPendingActiveTargetIfMatches?.({
            id: payload.threadId || '',
            key: payload.uri || ''
          });
        }
        const pendingTarget =
          typeof hub.getPendingActiveTarget === 'function' ? hub.getPendingActiveTarget() : null;
        const payloadDiffersFromPending = Boolean(
          pendingTarget &&
            ((pendingTarget.id && payload.threadId && payload.threadId !== pendingTarget.id) ||
              (pendingTarget.key && payload.uri && payload.uri !== pendingTarget.key))
        );
        const payloadMatchesOutgoing = Boolean(
          pendingTarget &&
            ((payload.threadId && pendingTarget.outgoingIds?.has?.(payload.threadId)) ||
              (payload.uri && pendingTarget.outgoingKeys?.has?.(payload.uri)))
        );
        const isPendingBounceFromOtherTab = Boolean(
          payloadDiffersFromPending &&
            (!pendingTarget.confirmedInTabs ||
              payloadMatchesOutgoing ||
              Date.now() - Number(pendingTarget.setAt || 0) < 600)
        );
        if (
          !isPrewarmGuardActive() &&
          !isPendingBounceFromOtherTab &&
          !isBackgroundOrBeside &&
          payload.threadId &&
          (evType === 'focus' ||
            evType === 'reveal' ||
            evType === 'open-thread' ||
            (evType === 'tab-state' && payload.active))
        ) {
          await hub.markThreadSeen(payload.threadId);
        }
        if (isTabEvent) {
          const nextOptimisticId = isPendingBounceFromOtherTab
            ? pendingTarget.id || ''
            : isExplicitOpenCommand
              ? payload.threadId || ''
              : '';
          const nextOptimisticKey = isPendingBounceFromOtherTab
            ? pendingTarget.key || ''
            : isExplicitOpenCommand && (evType === 'reveal-draft' || evType === 'open-new')
              ? payload.uri || ''
              : '';
          await hub.refreshTabStateFast({
            optimisticActiveId: nextOptimisticId,
            optimisticActiveKey: nextOptimisticKey,
            forceOptimistic: Boolean(isPendingBounceFromOtherTab || isExplicitOpenCommand),
            scheduleFullRefreshMs: 320,
            onlyIfStaleOrUnknown: true
          });
          return;
        }
      }
      await hub.refresh({ force: true });
    })
  );

  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration(async (e) => {
      if (e.affectsConfiguration('antigravityHub.hideThirdPartyQuota') && !hub._writingHideThirdPartyConfig) {
        const next = Boolean(
          vscode.workspace.getConfiguration('antigravityHub').get('hideThirdPartyQuota', false)
        );
        const curPrefs = stateStore.read().preferences || {};
        if (curPrefs.hideThirdPartyQuota !== next) {
          await stateStore.updatePreferences({
            hideThirdPartyQuota: next,
            hideThirdPartyQuotaUpdatedAt: Date.now()
          });
          hub.lastPosted = null;
          hub.render();
          try {
            remote?.notifyStateUpdated?.();
          } catch {}
        }
      }
      if (
        e.affectsConfiguration('antigravityHub.hideClaudeDesktopSessions') &&
        !hub._writingHideClaudeDesktopConfig &&
        !(hub._writingHideClaudeDesktopConfigCount > 0)
      ) {
        const nextDesktop = Boolean(
          vscode.workspace
            .getConfiguration('antigravityHub')
            .get('hideClaudeDesktopSessions', false)
        );
        const curPrefs = stateStore.read().preferences || {};
        if (curPrefs.hideClaudeDesktopSessions !== nextDesktop) {
          await stateStore.updatePreferences({
            hideClaudeDesktopSessions: nextDesktop,
            hideClaudeDesktopSessionsUpdatedAt: Date.now()
          });
          hub.lastPosted = null;
          hub.render();
          try {
            remote?.notifyStateUpdated?.();
          } catch {}
        }
      }
      if (e.affectsConfiguration('antigravityHub.legacyVsCodePhoneBridge')) {
        await serializeAdapterSwap(async () => {
          const nextLegacy = await syncLegacyPhoneBridgeSetting();
          if (Boolean(remote?.isServiceClient) === nextLegacy) {
            try {
              remote?.dispose?.();
            } catch {}
            await new Promise((r) => setTimeout(r, 120));
            const {
              TheoRemoteBridge: FreshRemoteBridge,
              TheoServiceBridgeClient: FreshServiceBridgeClient
            } = require('./remote');
            remote = createRemoteAdapter({
              legacy: nextLegacy,
              TheoRemoteBridgeCtor: FreshRemoteBridge,
              TheoServiceBridgeClientCtor: FreshServiceBridgeClient
            });
            hub.remote = remote;
            await startRemoteAdapter(remote);
            hub.lastPosted = null;
            hub.render();
          }
        });
      }
    })
  );

  // Boot order (2026-10-20): nothing below blocks activate() from resolving, and nothing that the
  // sidebar needs waits for Claude Code. After a cold boot Claude Code's own activation took 102 s
  // and THEO used to `await claudeExt.activate()` before attaching the sidebar or loading any data.
  bootPhase('commands-registered');

  const autoOpenLastSession = () => {
    const autoOpen = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('autoOpenLastSessionOnStartup', true);
    if (!autoOpen) {
      return;
    }
    setTimeout(() => {
      void runAutoOpenLastSession({ hub, tabs, store });
    }, 600);
  };

  let fallbackEditorDisposable = null;
  const ensureFallbackConversationEditorIfNeeded = () => {
    if (fallbackEditorDisposable) {
      return;
    }
    const disposables = [];
    try {
      disposables.push(
        vscode.workspace.registerTextDocumentContentProvider('antigravity-session', {
          provideTextDocumentContent: () => ''
        })
      );
    } catch {}
    try {
      const iconUri = vscode.Uri.joinPath(
        context.extensionUri,
        'resources',
        'antigravity-logo-color.svg'
      );
      disposables.push(
        vscode.window.registerCustomEditorProvider(
          'antigravity.conversationEditor',
          {
            async openCustomDocument(uri) {
              return { uri, dispose() {} };
            },
            async resolveCustomEditor(document, webviewPanel) {
              const parsed = parseSessionUri(document.uri);
              const persisted = stateStore.read();
              let title = '';
              if (parsed.kind === 'thread' && parsed.threadId) {
                title =
                  persisted?.customTitles?.[parsed.threadId] ||
                  (hub?.snapshot?.threads || []).find((t) => t.id === parsed.threadId)?.title ||
                  '';
              }
              webviewPanel.title = title || 'Antigravity';
              try {
                webviewPanel.iconPath = { light: iconUri, dark: iconUri };
              } catch {}
              webviewPanel.webview.options = { enableScripts: true };
              webviewPanel.webview.onDidReceiveMessage(async (msg) => {
                if (msg && msg.type === 'reload') {
                  await vscode.commands.executeCommand('workbench.action.reloadWindow');
                }
              });
              webviewPanel.webview.html = [
                '<!doctype html><html><head><meta charset="utf-8">',
                '<style>body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:var(--vscode-editor-background,#18181b);color:var(--vscode-editor-foreground,#e4e4e7);font:13px/1.5 var(--vscode-font-family,system-ui,sans-serif)}.card{max-width:420px;padding:24px 28px;border:1px solid var(--vscode-panel-border,rgba(255,255,255,.1));border-radius:10px;text-align:center}h3{margin:0 0 8px;font-size:15px;font-weight:600}p{margin:0 0 16px;opacity:.8}button{background:var(--vscode-button-background,#2563eb);color:var(--vscode-button-foreground,#fff);border:0;border-radius:6px;padding:8px 16px;font:inherit;font-weight:500;cursor:pointer}</style>',
                '</head><body><div class="card"><h3>THEO Session Tab Preserved</h3>',
                '<p>Antigravity was updated and THEO preserved this session tab. Reload VS Code once to reconnect the live session view.</p>',
                '<button id="btn">Reload Window</button></div>',
                '<script>const v=acquireVsCodeApi();document.getElementById("btn").onclick=()=>v.postMessage({type:"reload"});</script>',
                '</body></html>'
              ].join('');
            }
          },
          {
            webviewOptions: { retainContextWhenHidden: true },
            supportsMultipleEditorsPerDocument: false
          }
        )
      );
    } catch {}
    if (disposables.length > 0) {
      fallbackEditorDisposable = vscode.Disposable.from(...disposables);
      context.subscriptions.push(fallbackEditorDisposable);
    }
  };

  const bootAntigravitySide = async () => {
    // google.google-antigravity is a declared extensionDependency, so it is already active here.
    try {
      const agyExt = vscode.extensions.getExtension('google.google-antigravity');
      if (agyExt && !agyExt.isActive) {
        await agyExt.activate();
      }
    } catch {}
    await vscode.commands.executeCommand('antigravityHub.attachSidebar', hub).then(
      () => {},
      () => {}
    );
    bootPhase('antigravity-sidebar-attached');

    await hub.refresh({ forceQuota: true });
    bootPhase('first-refresh');

    await startRemoteAdapter(remote);
    bootPhase('remote-bridge-started');

    let agyBridgeStatus = null;
    try {
      agyBridgeStatus = await vscode.commands.executeCommand('antigravityHub.bridgeStatus');
    } catch {}
    if (agyBridgeStatus?.active) {
      autoOpenLastSession();
    } else {
      ensureFallbackConversationEditorIfNeeded();
    }
  };

  const bootClaudeSide = async () => {
    const claudeSignedIn = accountVault.hasSignedInProvider('claude');
    let claudeExt = null;
    try {
      claudeExt = vscode.extensions.getExtension('anthropic.claude-code');
      if (claudeSignedIn && claudeExt && !claudeExt.isActive) {
        await claudeExt.activate();
      }
    } catch {}
    bootPhase(claudeSignedIn ? 'claude-code-active' : 'claude-code-skipped-signed-out');
    if (claudeExt?.isActive) {
      await vscode.commands.executeCommand('antigravityHub.claudeAttachSidebar', hub).then(
        () => {},
        () => {}
      );
      bootPhase('claude-sidebar-attached');
      let claudeStatus = null;
      try {
        claudeStatus = await vscode.commands.executeCommand('antigravityHub.claudeBridgeStatus');
      } catch {}
      if (!claudeStatus?.active && claudeSignedIn) {
        const autoMaintain = vscode.workspace
          .getConfiguration('antigravityHub')
          .get('autoMaintainBridge', true);
        if (autoMaintain) {
          try {
            const res = await ensureAntigravityBridgeInstalled(context, {
              promptReload: true,
              claudeSignedIn
            });
            hub.setBridgeInstallReport?.(res);
          } catch {}
        }
      }
    }
    hub.refresh({ forceQuota: false });
  };

  const bootBridgeMaintenance = async (claudeBoot) => {
    const autoMaintain = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('autoMaintainBridge', true);
    if (!autoMaintain) {
      return;
    }
    // Give Claude Code up to 2.5s to finish fast activation; if it takes longer, bridge.js inspects
    // claudeExt.isActive so a still-activating extension never causes a false reload toast, and
    // bootClaudeSide re-verifies once claudeExt.activate() resolves.
    await Promise.race([claudeBoot, new Promise((r) => setTimeout(r, 2500))]);
    try {
      const res = await ensureAntigravityBridgeInstalled(context, {
        promptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude')
      });
      hub.setBridgeInstallReport?.(res);
    } catch {}
    bootPhase('bridge-maintained');
  };

  const claudeBoot = bootClaudeSide().catch(() => {});
  bootAntigravitySide()
    .catch(() => {})
    .then(() => bootBridgeMaintenance(claudeBoot))
    .catch(() => {})
    .then(() => bootPhase('boot-complete'));

  // Keep open/active tab state synced when editor tabs change without triggering a full snapshot storm
  if (vscode.window.tabGroups) {
    context.subscriptions.push(
      vscode.window.tabGroups.onDidChangeTabs(() => {
        if (isPrewarmGuardActive()) {
          return;
        }
        hub.notePrewarmActivity?.('tab');
        hub.scheduleFastTabSync(16, {
          scheduleFullRefreshMs: 320,
          onlyIfStaleOrUnknown: true
        });
      }),
      vscode.window.tabGroups.onDidChangeTabGroups(() => {
        if (isPrewarmGuardActive()) {
          return;
        }
        hub.notePrewarmActivity?.('tab');
        hub.scheduleFastTabSync(16, {
          scheduleFullRefreshMs: 320,
          onlyIfStaleOrUnknown: true
        });
      })
    );
  }

  context.subscriptions.push(
    vscode.window.onDidChangeWindowState((winState) => {
      if (winState?.focused) {
        noteLocalUserActivity();
        hub.notePrewarmActivity?.('focus');
      } else {
        hub.notePrewarmActivity?.('blur');
      }
      hub.scheduleFastTabSync(16, {
        scheduleFullRefreshMs: 320,
        onlyIfStaleOrUnknown: true
      });
    }),
    vscode.window.onDidChangeTextEditorSelection(() => {
      noteLocalUserActivity();
      hub.notePrewarmActivity?.('input');
    }),
    vscode.workspace.onDidChangeTextDocument((ev) => {
      if (ev?.contentChanges?.length > 0) {
        noteLocalUserActivity();
        hub.notePrewarmActivity?.('input');
      }
    }),
    vscode.window.onDidChangeActiveTerminal(() => {
      noteLocalUserActivity();
      hub.notePrewarmActivity?.('input');
    })
  );

  if (vscode.window.activeTextEditor) {
    hub.noteActiveEditorContext?.(vscode.window.activeTextEditor);
  }
  if (typeof vscode.window.onDidChangeActiveTextEditor === 'function') {
    context.subscriptions.push(
      vscode.window.onDidChangeActiveTextEditor((editor) => {
        if (editor?.document?.uri?.scheme === 'file') {
          noteLocalUserActivity();
          hub.noteActiveEditorContext?.(editor);
        }
      })
    );
  }

  let hotSwapInFlight = false;
  let hotSwapDeferSince = 0;
  let hotSwapAttemptedMtime = 0; // a swap that threw is not retried every tick, only on the next change
  const hotSwapMemo = new Map();
  let hotSwapHold = null; // a held batch (buildHotSwapHold): nothing is read or compiled until it changes
  let hotSwapCarryRestore = null; // a failed restore that outlived its hold (mergePendingRestore)
  const hotSwapForceCompare = new Set(); // saved again while being checked: compare bytes despite mtimes
  // This installed folder's held-swap record (bundle-updater.js; one per installed folder, so a window only
  // ever clears its own folder's record) is cleared once per window start (it may be left over from a session
  // that ended while held, or written by another window on the same folder) and after any hold this window
  // recorded; not on every idle 6 s tick. A clear that failed is retried on the next tick. A folder that is a
  // git checkout never records or clears (the hot swap never copies into it).
  let hotSwapHoldSignalled = true;
  function clearHotSwapHoldSignal(extRoot) {
    if (!hotSwapHoldSignalled) return;
    if (isGitCheckoutFolder(extRoot)) {
      hotSwapHoldSignalled = false;
      return;
    }
    let outcome = 'failed';
    try {
      const holdApi = loadHotSwapHoldApi();
      outcome = holdApi ? holdApi.clearHotSwapHoldStatus(extRoot) : 'absent';
    } catch {}
    if (outcome !== 'failed') hotSwapHoldSignalled = false;
  }
  async function maybeHotSwapRemoteBridge() {
    if (hotSwapInFlight) return;
    // Set before the first await: the syntax check is asynchronous and the next 6 s tick must not overlap it.
    hotSwapInFlight = true;
    try {
      const extRoot = context?.extensionPath || __dirname;
      const repoRoot = path.join(os.homedir(), 'bhfirms', 'theo-hub');
      const watchedFiles = [
        'remote.js',
        'bridge.js',
        'data.js',
        'state.js',
        'store.js',
        'accounts.js',
        'hub.js',
        'activity.js',
        'session-tabs.js',
        'desktop-notify.js',
        'desktop-launcher.js',
        'device-identity.js',
        'pc-setup.js',
        'unsaved-work.js',
        'auto-reload.js',
        'bundle-updater.js',
        'ws-server.js',
        'direct-runner.js',
        'edge-relay-client.js',
        path.join('compat', 'antigravity-hub-bridge.cjs'),
        path.join('compat', 'antigravity-context-window.cjs'),
        path.join('compat', 'antigravity-tab-state.cjs'),
        path.join('compat', 'claude-hub-bridge.cjs'),
        path.join('compat', 'claude-webview-patches.cjs'),
        path.join('compat', 'excel-preview.cjs'),
        path.join('resources', 'theo.ico'),
        path.join('resources', 'TheoLauncher.cs'),
        path.join('resources', 'hub.js'),
        path.join('resources', 'hub.css'),
        path.join('resources', 'hub.html'),
        path.join('scripts', 'relay_keepalive.cjs'),
        path.join('scripts', 'relay_keepalive_start.ps1'),
        path.join('scripts', 'memory_cloud_sync.cjs')
      ];

      // A held batch (bad syntax, failed load check, locked copy) waits for one of its files to change. A file
      // whose rollback write failed is restored on a later tick first.
      if (hotSwapHold?.pendingRestore) {
        try {
          retryHotSwapPendingRestore(hotSwapHold, { extRoot });
        } catch {}
      }
      if (hotSwapCarryRestore) {
        // Outlived its hold: retried every tick until it lands or another writer replaces the file.
        const carrier = { keys: new Map(), pendingRestore: hotSwapCarryRestore };
        try {
          retryHotSwapPendingRestore(carrier, { extRoot });
        } catch {}
        hotSwapCarryRestore = carrier.pendingRestore;
      }
      if (isHotSwapHoldActive(hotSwapHold, { repoRoot, extRoot })) return;
      if (hotSwapHold?.pendingRestore) {
        hotSwapCarryRestore = mergePendingRestore(hotSwapCarryRestore, hotSwapHold.pendingRestore);
      }
      hotSwapHold = null;

      // If ~/bhfirms/theo-hub/* was edited on disk and differs from the installed copy, sync it automatically,
      // once the edits have been quiet (planHotSwap).
      const plan = planHotSwap({
        repoRoot,
        extRoot,
        watchedFiles,
        loadedMtime: Math.max(Number(remote?.codeMtime || 0), hotSwapAttemptedMtime),
        nowMs: Date.now(),
        deferSince: hotSwapDeferSince,
        memo: hotSwapMemo,
        forceCompare: hotSwapForceCompare
      });
      for (const rel of [...hotSwapForceCompare]) {
        if (!plan.toCopy || !plan.toCopy.includes(rel)) hotSwapForceCompare.delete(rel);
      }
      if (plan.action === 'idle') {
        hotSwapDeferSince = 0;
        // The repo matches the installed copy: nothing is held in this folder any more.
        clearHotSwapHoldSignal(extRoot);
        return;
      }
      if (plan.action === 'wait') {
        if (!hotSwapDeferSince) hotSwapDeferSince = Date.now();
        return;
      }
      hotSwapDeferSince = 0;
      const restartRemote =
        plan.needsRestart ||
        plan.toCopy.some((rel) => HOT_SWAP_RESTART_FILES.has(rel)) ||
        Boolean(remote?.isServiceClient) === Boolean(readLegacyPhoneBridgeSetting()) ||
        !remote ||
        remote.disposed === true ||
        typeof remote.syncHotReloadedModules !== 'function';
      const holdBatch = (result, sources, retryAt, { quiet = false } = {}) => {
        hotSwapHold = buildHotSwapHold({
          repoRoot,
          extRoot,
          stage: result.stage,
          toCopy: plan.toCopy,
          installedChanged: plan.installedChanged,
          watchedFiles,
          sources,
          retryAt,
          pendingRestore: mergePendingRestore(hotSwapCarryRestore, result.pendingRestore || null)
        });
        hotSwapCarryRestore = null;
        // Syntax and load-check holds wait for a new save, possibly for days: show them in the sidebar and the
        // evening digest, not only in the log line below. Any other loud hold clears the record, whose error
        // would no longer describe this batch (hotSwapHoldRecordAction).
        try {
          const holdApi = loadHotSwapHoldApi();
          const recordAction = holdApi
            ? holdApi.hotSwapHoldRecordAction({
                stage: result.stage,
                quiet,
                transient: Boolean(result.transient),
                gitCheckout: isGitCheckoutFolder(extRoot),
                recordedStage:
                  typeof holdApi.readHotSwapHoldRecord === 'function'
                    ? holdApi.readHotSwapHoldRecord(extRoot)?.stage || ''
                    : ''
              })
            : 'none';
          if (recordAction === 'record') {
            const written = holdApi.writeHotSwapHoldStatus({
              extRoot,
              stage: result.stage,
              failedFile: result.failedFile || '',
              error: result.error,
              batch: [...plan.toCopy, ...plan.installedChanged]
            });
            if (written) hotSwapHoldSignalled = true;
          } else if (recordAction === 'clear') {
            clearHotSwapHoldSignal(extRoot);
          }
        } catch {}
        if (quiet) return;
        try {
          const pendingRestore = result.pendingRestore ? [...result.pendingRestore.written.keys()] : [];
          console.error(
            `[theo-hub] Hot swap held (${result.stage}) on ${result.failedFile || 'batch'}: ` +
              `${result.error?.message || result.error || 'see stage'}; ` +
              `batch ${[...new Set([...plan.toCopy, ...plan.installedChanged])].join(', ')}` +
              (result.leftAlone?.length ? `; left alone (rewritten by another writer) ${result.leftAlone.join(', ')}` : '') +
              (pendingRestore.length ? `; restore pending ${pendingRestore.join(', ')}` : '')
          );
        } catch {}
      };
      const batch = await prepareHotSwapBatch({ repoRoot, toCopy: plan.toCopy });
      if (!batch.ok) {
        // Bad syntax: held until a file in the batch is saved again. A worker or read hiccup: retried later.
        holdBatch(batch, batch.sources, batch.transient ? Date.now() + HOT_SWAP_COPY_RETRY_MS : Infinity);
        return;
      }
      const stageResult = stageHotSwapFilesWithValidation({
        extRoot,
        toCopy: plan.toCopy,
        sources: batch.sources,
        installedChanged: plan.installedChanged,
        restartRemote
      });
      if (!stageResult.ok) {
        if (stageResult.stage === 'locked') {
          // The bundle updater or another window is writing: look again in 15 s, not every 6 s tick with a
          // fresh syntax worker (and sooner if any watched file changes).
          holdBatch(stageResult, batch.sources, Date.now() + 15000, { quiet: true });
          return;
        }
        holdBatch(
          stageResult,
          batch.sources,
          stageResult.stage === 'require' ? Infinity : Date.now() + HOT_SWAP_COPY_RETRY_MS
        );
        return;
      }
      // The batch passed its checks and is installed: updates are flowing again into this folder.
      clearHotSwapHoldSignal(extRoot);
      // These files now hold bytes that were just checked and are about to load: a carried restore must not
      // put an older failed batch's backup back over them.
      if (hotSwapCarryRestore) {
        for (const rel of [...stageResult.copiedFiles, ...plan.installedChanged]) {
          hotSwapCarryRestore.written.delete(rel);
        }
        if (hotSwapCarryRestore.written.size === 0) hotSwapCarryRestore = null;
      }
      // A file saved again while it was being checked has an older mtime than the copy just written: make the
      // next ticks compare its bytes so the newer save is not missed.
      for (const [rel, src] of batch.sources) {
        if (getFileMtimeMs(path.join(repoRoot, rel)) !== src.srcMtimeMs) hotSwapForceCompare.add(rel);
      }
      const copied = stageResult.copiedFiles.length;
      // Nothing copied and nothing else changed: the loaded code is still current, so do not swap.
      if (copied === 0 && plan.installedChanged.length === 0 && Number(remote?.codeMtime || 0) > 0) {
        return;
      }
      const maxMtime = Math.max(plan.maxMtime, Date.now());
      hotSwapAttemptedMtime = maxMtime;
      // Already copied above, so syncHotReloadedModules would find no difference on its own: hand it the list
      // so a bridge.js / claude-webview-patches.cjs change forces the re-patch and an
      // antigravity-context-window.cjs change resets the cached /main.js.
      const hotSwapChangedFiles = [...new Set([...plan.toCopy, ...plan.installedChanged])];

      const runSwapPass = async () => {
        if (restartRemote) {
          try {
            remote.dispose();
          } catch {}
          await new Promise((r) => setTimeout(r, 150));
        }
        for (const modName of [
          './data',
          './remote',
          './state',
          './store',
          './accounts',
          './activity',
          './session-tabs',
          './desktop-notify',
          './desktop-launcher',
          './device-identity',
          './pc-setup',
          './unsaved-work',
          './auto-reload',
          './bundle-updater',
          './ws-server',
          './direct-runner',
          './edge-relay-client',
          './hub',
          './compat/antigravity-hub-bridge.cjs',
          './compat/antigravity-context-window.cjs',
          './compat/antigravity-tab-state.cjs',
          './compat/claude-hub-bridge.cjs',
          './compat/claude-webview-patches.cjs',
          './compat/excel-preview.cjs',
          './bridge'
        ]) {
          // In place, the live bridge keeps its modules: a second copy of device-identity or pc-setup would
          // split their in-module state (idle tracking, apply-in-flight) between the bridge and the rest.
          if (!restartRemote && HOT_SWAP_RESTART_FILES.has(`${modName.replace(/^\.\//, '')}.js`)) continue;
          try {
            const resolvedMod = require.resolve(modName);
            delete require.cache[resolvedMod];
          } catch {}
        }
        try {
          const { HubStateStore: FreshStateStore } = require('./state');
          const { AntigravityDataStore: FreshStore } = require('./store');
          const {
            AccountVaultManager: FreshVault,
            defaultHttpsJsonRequest: freshHttpsJsonRequest
          } = require('./accounts');
          const { SessionActivityTracker: FreshActivity } = require('./activity');
          const { SessionTabManager: FreshTabs } = require('./session-tabs');
          const { HubProvider: FreshHub } = require('./hub');
          pcSetupMod = require('./pc-setup');
          if (stateStore && FreshStateStore?.prototype) {
            Object.setPrototypeOf(stateStore, FreshStateStore.prototype);
          }
          Object.setPrototypeOf(store, FreshStore.prototype);
          store.cachedSqliteMtimeMs = 0;
          store.sqliteCacheByPath?.clear?.();
          store.cachedClaudeVscMtimeMs = 0;
          if (
            FreshStore?.PARSE_CACHE_VERSION &&
            Number(store.parseCacheVersion || 0) !== Number(FreshStore.PARSE_CACHE_VERSION)
          ) {
            store.transcriptCache?.clear?.();
            store.claudeSessionCache?.clear?.();
            store.parseCacheVersion = Number(FreshStore.PARSE_CACHE_VERSION);
            store.readPersistedParseCache?.();
          }
          if (accountVault) {
            Object.setPrototypeOf(accountVault, FreshVault.prototype);
            if (!accountVault.hasCustomHttpsJsonRequest && freshHttpsJsonRequest) {
              accountVault.httpsJsonRequest = freshHttpsJsonRequest;
            }
            accountVault.agyQuotaInFlightById?.clear?.();
            accountVault.claudeQuotaInFlightById?.clear?.();
          }
          if (tabs) {
            Object.setPrototypeOf(tabs, FreshTabs.prototype);
          }
          if (hub?.activity) {
            Object.setPrototypeOf(hub.activity, FreshActivity.prototype);
          }
          if (hub) {
            Object.setPrototypeOf(hub, FreshHub.prototype);
            hub.accountVault = accountVault;
            hub.getPcSetupView = () => pcSetupMod.getLocalPcSetupView();
            hub.checkPcSetup = (opts) => runBackgroundPcSetupCheck({ ...opts, promptToast: false });
            hub.applyPcSetup = (opts) => runTrustedUiPcSetupApply(opts);
            if (
              hub.refreshInFlight &&
              (!hub.refreshStartedAt || Date.now() - Number(hub.refreshStartedAt || 0) > 10000)
            ) {
              hub.refreshInFlight = null;
            }
            hub.reloadAllWebviews?.();
          }
          try {
            const freshBridgeInstaller = require('./bridge');
            if (typeof freshBridgeInstaller?.ensureAntigravityBridgeInstalled === 'function') {
              ensureAntigravityBridgeInstalled = freshBridgeInstaller.ensureAntigravityBridgeInstalled;
            }
            if (typeof freshBridgeInstaller?.prepatchInstalledExtensions === 'function') {
              prepatchInstalledExtensions = freshBridgeInstaller.prepatchInstalledExtensions;
            }
            prepatchInstalledExtensionsAsync =
              typeof freshBridgeInstaller?.prepatchInstalledExtensionsAsync === 'function'
                ? freshBridgeInstaller.prepatchInstalledExtensionsAsync
                : null;
            const prepatchDone = prepatchInstalledExtensionsOffThread(extRoot);
            // A stored patch failure or reload notice was produced by the old patcher. Once the new one
            // has run, re-check so a fixed patch turns "THEO needs an update" into "Reload" instead of
            // keeping the stale notice until the next window reload (red-team, 2026-11-18).
            const storedReport = hub?.bridgeInstallReport;
            if (
              hub &&
              storedReport &&
              ((Array.isArray(storedReport.patchFailures) && storedReport.patchFailures.length > 0) ||
                storedReport.needsReload)
            ) {
              // The sidebar is updated first: with promptReload the call waits for the reload toast to be
              // answered, and an unanswered toast would keep the stale notice up. The second, prompting
              // pass only runs when a reload is due and is cheap (the stamp skips the patch work).
              const claudeSignedIn = accountVault.hasSignedInProvider('claude');
              Promise.resolve(prepatchDone)
                .then(() => ensureAntigravityBridgeInstalled(context, { promptReload: false, claudeSignedIn }))
                .then((res) => {
                  hub.setBridgeInstallReport?.(res);
                  if (res?.needsReload) {
                    return ensureAntigravityBridgeInstalled(context, { promptReload: true, claudeSignedIn }).then(
                      (prompted) => hub.setBridgeInstallReport?.(prompted)
                    );
                  }
                  return null;
                })
                .catch(() => {});
            }
          } catch {}
          try {
            const freshClaudeBridge = require('./compat/claude-hub-bridge.cjs');
            freshClaudeBridge?.hotUpgradeLiveState?.();
          } catch {}
          try {
            const freshAgyBridge = require('./compat/antigravity-hub-bridge.cjs');
            freshAgyBridge?.hotUpgradeLiveState?.(freshAgyBridge.getBridgeState(), vscode, hub);
          } catch {}
          if (
            process.platform === 'win32' &&
            process.env.THEO_SMOKE_TEST !== '1' &&
            process.env.THEO_HEADLESS_TEST !== '1'
          ) {
            try {
              const launcherMod = require('./desktop-launcher');
              launcherMod.syncInstalledDesktopLauncher({ hubRoot: extRoot, homeDir: os.homedir() });
            } catch {}
          }
        } catch {}
        if (!restartRemote) {
          // Bridge modules unchanged: keep the phone link and relay up and swap the rest in place, as the
          // signed bundle updater does (remote.syncHotReloadedModules also re-points the live bridge state).
          try {
            remote.syncHotReloadedModules({ changedFiles: hotSwapChangedFiles });
          } catch {}
          remote.codeMtime = Math.max(maxMtime, Number(remote.codeMtime || 0), Date.now());
          return;
        }
        const {
          TheoRemoteBridge: FreshRemoteBridge,
          TheoServiceBridgeClient: FreshServiceBridgeClient
        } = require('./remote');
        const hotSwapLegacyMode = await syncLegacyPhoneBridgeSetting();
        const FreshAdapterCtor = hotSwapLegacyMode ? FreshRemoteBridge : FreshServiceBridgeClient;
        remote = new FreshAdapterCtor(context, {
          vscode,
          hub,
          store,
          stateStore,
          tabs,
          accountVault,
          hotSwapChangedFiles
        });
        remote.codeMtime = Math.max(maxMtime, Number(remote.codeMtime || 0), Date.now());
        hub.remote = remote;
        await startRemoteAdapter(remote);
      };
      if (restartRemote) {
        await serializeAdapterSwap(runSwapPass);
      } else {
        await runSwapPass();
      }
    } catch {} finally {
      hotSwapInFlight = false;
    }
  }

  const pcSetupBootTimer = setTimeout(() => {
    runBackgroundPcSetupCheck().catch(() => {});
  }, 2500);
  if (typeof pcSetupBootTimer?.unref === 'function') {
    pcSetupBootTimer.unref();
  }

  // The 18 s maintenance pass patches silently. When the set of failures it reports changes (a folder that
  // stayed write-blocked long enough to count as a real failure, or one that became writable again), the
  // install report behind the sidebar notice is refreshed, with the warning or reload prompt it calls for.
  // Without this a read-only extension folder stayed silent until the next window start (2026-11-20).
  // The logic and its tests live in bridge.js (createBridgeRecheck).
  let recheckBridgeAfterPrepatch = null;
  try {
    recheckBridgeAfterPrepatch = require('./bridge').createBridgeRecheck?.({
      ensure: (opts) =>
        ensureAntigravityBridgeInstalled(context, {
          ...opts,
          claudeSignedIn: accountVault.hasSignedInProvider('claude')
        }),
      setReport: (report) => hub.setBridgeInstallReport?.(report),
      refresh: () => hub.refresh({ forceQuota: false }),
      getStoredReport: () => hub?.bridgeInstallReport || null,
      isEnabled: () => vscode.workspace.getConfiguration('antigravityHub').get('autoMaintainBridge', true)
    });
  } catch {}
  // The extensions this window has loaded. Outside plain VS Code (the Antigravity IDE, VS Code Insiders, a
  // portable install) they are not in ~/.vscode/extensions, so the pass is told about them.
  const loadedExtensionDirs = () => {
    const dirs = [];
    for (const [provider, id] of [
      ['antigravity', 'google.google-antigravity'],
      ['claude', 'anthropic.claude-code']
    ]) {
      try {
        const dir = vscode.extensions.getExtension(id)?.extensionPath;
        if (dir) dirs.push({ provider, dir });
      } catch {}
    }
    return dirs;
  };

  let tickCount = 0;
  const pollTimer = setInterval(() => {
    tickCount += 1;
    maybeHotSwapRemoteBridge().catch(() => {});
    if (tickCount % 3 === 0) {
      prepatchInstalledExtensionsOffThread(context?.extensionPath || __dirname, { extraDirs: loadedExtensionDirs() })
        .then((res) => (typeof recheckBridgeAfterPrepatch === 'function' ? recheckBridgeAfterPrepatch(res) : null))
        .catch(() => {});
    }
    if (tickCount % 10 === 0) {
      ensureRelayKeepaliveDaemon(context);
      runBackgroundPcSetupCheck().catch(() => {});
    }
    if (tickCount % 3 === 1 && autoReloadAllowed()) {
      // Hands-free reload: reloads this window once an update needs it and nothing can be lost.
      try {
        const autoReload = require('./auto-reload');
        const before = JSON.stringify(autoReload.getAutoReloadView());
        autoReload
          .tickAutoReload({ vscode, hub })
          .then((view) => {
            if (JSON.stringify(view) !== before) hub.requestRender?.();
          })
          .catch(() => {});
      } catch {}
    }
    if (
      hub.visible ||
      vscode.window.state.focused ||
      remote.sseClients.size > 0 ||
      tickCount % 3 === 0
    ) {
      hub.refresh({ forceQuota: false });
    }
    hub.scheduleIdlePrewarmCheck?.();
  }, 6000);

  // THEO started in this window: activate() got this far and the poll timer runs, so the update it runs is good
  // (auto-reload.js canary rule). Checked 20 s later so a host that falls over right after activation does not
  // count. Not tied to boot-complete, which can wait on a reload toast nobody answers on an unattended PC.
  let autoReloadVerifyTimer = null;
  if (autoReloadAllowed()) {
    autoReloadVerifyTimer = setTimeout(() => {
      try {
        require('./auto-reload').verifyAfterActivation();
      } catch {}
    }, 20 * 1000);
    if (typeof autoReloadVerifyTimer?.unref === 'function') autoReloadVerifyTimer.unref();
  }

  context.subscriptions.push({
    dispose() {
      clearTimeout(pcSetupBootTimer);
      clearTimeout(autoReloadVerifyTimer);
      clearInterval(pollTimer);
      stateStore?.flushDiskBackupSync?.();
      remote.dispose();
      if (activeHubInstance === hub) {
        try {
          Promise.resolve(hub.evictAllPrewarmedTabs?.('dispose')).catch(() => {});
        } catch {}
        activeHubInstance = null;
      }
      hub.dispose();
    }
  });
}

async function deactivate() {
  const hub = activeHubInstance;
  activeHubInstance = null;
  if (hub && typeof hub.evictAllPrewarmedTabs === 'function') {
    try {
      await Promise.race([
        hub.evictAllPrewarmedTabs('deactivate'),
        new Promise((resolve) => setTimeout(resolve, 1500))
      ]);
    } catch {}
  }
}

module.exports = {
  activate,
  deactivate,
  resolveLegacyPhoneBridgeSetting,
  syncLegacyPhoneBridgePreference,
  ensureRelayKeepaliveDaemon,
  planHotSwap,
  copyFileAtomicSync,
  compileHotSwapEntries,
  checkHotSwapSyntaxOffThread,
  prepareHotSwapBatch,
  stageHotSwapFilesWithValidation,
  buildHotSwapHold,
  isHotSwapHoldActive,
  isGitCheckoutFolder,
  loadHotSwapHoldApi,
  retryHotSwapPendingRestore,
  mergePendingRestore,
  HOT_SWAP_STAGING_KEY,
  syncHideClaudeDesktopOnStartup,
  runAutoOpenLastSession,
  HOT_SWAP_QUIET_MS,
  HOT_SWAP_MAX_DEFER_MS,
  HOT_SWAP_RESTART_FILES
};
