const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const vscode = require('vscode');
const { AntigravityDataStore } = require('./store');
const { HubStateStore } = require('./state');
const { isClaudeDesktopScratchPath } = require('./data');
const { SessionActivityTracker } = require('./activity');
const { SessionTabManager } = require('./session-tabs');
const { HubProvider } = require('./hub');
let {
  ensureAntigravityBridgeInstalled,
  prepatchInstalledExtensions,
  prepatchInstalledExtensionsAsync
} = require('./bridge');

// Patches installed extensions in a worker thread when the loaded bridge.js offers it (2026-11-12), so a
// slow bundle patch never blocks the Extension Host; an older bridge.js falls back to the in-thread call.
function prepatchInstalledExtensionsOffThread(extRoot) {
  try {
    const run =
      typeof prepatchInstalledExtensionsAsync === 'function'
        ? prepatchInstalledExtensionsAsync
        : prepatchInstalledExtensions;
    Promise.resolve(run(extRoot)).catch(() => {});
  } catch {}
}
const { TheoRemoteBridge } = require('./remote');
const { AccountVaultManager } = require('./accounts');
const {
  loadTheoCredentials,
  deriveEdgeAuthToken,
  resolveNodeBinaryInfo
} = require('./device-identity');
// Resolved at call time: after a bridge restart the bridge and its relay client read idle time from the
// freshly loaded device-identity, so editor activity must be recorded on that same module copy.
function noteLocalUserActivity() {
  try {
    require('./device-identity').noteLocalUserActivity();
  } catch {}
}
let pcSetupMod = require('./pc-setup');
const { ensureExcelPreviewRegistered } = require('./compat/excel-preview.cjs');
const { parseSessionUri } = require('./compat/antigravity-tab-state.cjs');

function isPidAlive(pid) {
  const n = Number(pid || 0);
  if (!n || n <= 0) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch (err) {
    return err && err.code === 'EPERM';
  }
}

function getFileMtimeMs(filePath) {
  try {
    return Math.floor(fs.statSync(filePath).mtimeMs);
  } catch {
    return 0;
  }
}

// Hot swap without needless phone-link restarts (2026-11-12). Sessions editing ~/bhfirms/theo-hub save files
// minutes apart, and every swap used to dispose and restart the remote bridge (phone link + relay):
// - swap only once the changed files have been quiet for HOT_SWAP_QUIET_MS (a change that keeps moving is
//   still picked up after HOT_SWAP_MAX_DEFER_MS), so a burst of saves is one swap and no half-written file
//   is copied;
// - a save that leaves the bytes identical never swaps;
// - only a change to HOT_SWAP_RESTART_FILES (the modules the bridge is built from) restarts the bridge;
//   every other module is swapped in place, the way a signed bundle update already is.
const HOT_SWAP_QUIET_MS = 20 * 1000;
const HOT_SWAP_MAX_DEFER_MS = 10 * 60 * 1000;
const HOT_SWAP_COPY_RETRY_MS = 60 * 1000;
// remote.js plus every module it binds functions from at load time (its top-level require()s); classes
// from store/state/hub/accounts/activity/session-tabs are swapped by prototype instead.
const HOT_SWAP_RESTART_FILES = new Set([
  'remote.js',
  'ws-server.js',
  'device-identity.js',
  'edge-relay-client.js',
  'direct-runner.js',
  'bundle-updater.js',
  'pc-setup.js',
  'unsaved-work.js'
]);

// Pure decision for one 6 s poll tick: reads files, writes nothing. `memo` (rel -> { key, same, retryAt })
// caches byte comparisons per src:dst mtime pair and holds back a failed copy until retryAt.
// Returns { action: 'idle' } or { action: 'wait' | 'swap', toCopy, installedChanged, newestChange, maxMtime,
// needsRestart }.
function planHotSwap({
  repoRoot,
  extRoot,
  watchedFiles,
  loadedMtime = 0,
  nowMs = Date.now(),
  deferSince = 0,
  memo = new Map(),
  quietMs = HOT_SWAP_QUIET_MS,
  maxDeferMs = HOT_SWAP_MAX_DEFER_MS
}) {
  const toCopy = [];
  const installedChanged = [];
  let newestChange = 0;
  let maxMtime = 0;
  for (const rel of watchedFiles) {
    const src = path.join(repoRoot, rel);
    const dst = path.join(extRoot, rel);
    const srcM = getFileMtimeMs(src);
    const dstM = getFileMtimeMs(dst);
    if (dstM > maxMtime) maxMtime = dstM;
    // The installed copy itself changed after the loaded code (install_local.py, another window's copy).
    if (dstM > loadedMtime + 500) {
      installedChanged.push(rel);
      if (dstM > newestChange) newestChange = dstM;
    }
    if (srcM <= 0 || path.resolve(src) === path.resolve(dst) || srcM <= dstM + 500) continue;
    const key = `${srcM}:${dstM}`;
    const seen = memo.get(rel);
    const fresh = Boolean(seen && seen.key === key);
    if (fresh && seen.same) continue; // touched but unchanged (git checkout, an empty save)
    if (fresh && nowMs < Number(seen.retryAt || 0)) continue; // copy failed; retry later
    let differs = true;
    if (!fresh || seen.same !== false) {
      try {
        differs = !fs.readFileSync(src).equals(fs.readFileSync(dst));
      } catch {}
      memo.set(rel, { key, same: !differs });
    }
    if (!differs) continue;
    toCopy.push(rel);
    if (srcM > newestChange) newestChange = srcM;
  }
  const pending = toCopy.length > 0 || installedChanged.length > 0 || (loadedMtime === 0 && maxMtime > 0);
  if (!pending) return { action: 'idle' };
  const changed = [...new Set([...toCopy, ...installedChanged])];
  const needsRestart = loadedMtime === 0 || changed.some((rel) => HOT_SWAP_RESTART_FILES.has(rel));
  const waitedMs = deferSince > 0 ? nowMs - deferSince : 0;
  const action =
    newestChange > 0 && nowMs - newestChange < quietMs && waitedMs < maxDeferMs ? 'wait' : 'swap';
  return {
    action,
    toCopy,
    installedChanged,
    newestChange,
    maxMtime: Math.max(maxMtime, newestChange),
    needsRestart
  };
}

// Copies one repo file over the installed copy through a temp file + rename, so another window polling the
// same folder never require()s a half-written module. Returns true on success.
function copyFileAtomicSync(srcFile, dstFile) {
  const tmp = `${dstFile}.theo-tmp-${process.pid}-${Date.now()}`;
  try {
    fs.mkdirSync(path.dirname(dstFile), { recursive: true });
    fs.writeFileSync(tmp, fs.readFileSync(srcFile));
    fs.renameSync(tmp, dstFile);
    return true;
  } catch {
    try {
      fs.unlinkSync(tmp);
    } catch {}
    return false;
  }
}

// Appends "<iso> +<ms since activate()> <phase>" lines to ~/.claude/.theo-hub-activation.log so a slow
// THEO start can be attributed to a phase (sidebar attach, first refresh, Claude Code activation, ...).
function createActivationPhaseLogger(context) {
  const startedAt = Date.now();
  let logPath = '';
  try {
    const claudeDir = path.join(os.homedir(), '.claude');
    fs.mkdirSync(claudeDir, { recursive: true });
    logPath = path.join(claudeDir, '.theo-hub-activation.log');
    if (fs.existsSync(logPath) && fs.statSync(logPath).size > 256 * 1024) {
      fs.unlinkSync(logPath);
    }
    fs.appendFileSync(
      logPath,
      `\n[${new Date(startedAt).toISOString()}] activate() start (ext ${context?.extension?.packageJSON?.version || '?'}, host pid ${process.pid})\n`,
      'utf8'
    );
  } catch {
    logPath = '';
  }
  return (phase) => {
    const elapsed = Date.now() - startedAt;
    const line = `[${new Date().toISOString()}] +${elapsed} ms ${phase}`;
    try {
      console.log(`[theo-hub] ${line}`);
    } catch {}
    if (logPath) {
      try {
        fs.appendFileSync(logPath, `${line}\n`, 'utf8');
      } catch {}
    }
  };
}

function ensureRelayKeepaliveDaemon(context) {
  try {
    const repoRoot = path.join(os.homedir(), 'bhfirms', 'theo-hub');
    const extRoot = context?.extensionPath || __dirname;
    const candidateRoots = [repoRoot, extRoot];
    const mtimeOfRoot = (r, scriptPath) =>
      Math.max(
        getFileMtimeMs(scriptPath),
        getFileMtimeMs(path.join(r, 'remote.js')),
        getFileMtimeMs(path.join(r, 'store.js')),
        getFileMtimeMs(path.join(r, 'accounts.js')),
        getFileMtimeMs(path.join(r, 'data.js')),
        getFileMtimeMs(path.join(r, 'device-identity.js')),
        getFileMtimeMs(path.join(r, 'pc-setup.js')),
        getFileMtimeMs(path.join(r, 'unsaved-work.js')),
        getFileMtimeMs(path.join(r, 'bundle-updater.js')),
        getFileMtimeMs(path.join(r, 'direct-runner.js')),
        getFileMtimeMs(path.join(r, 'edge-relay-client.js'))
      );
    let keepaliveScript = '';
    let workingRoot = extRoot;
    let diskMaxMtime = 0;
    for (const r of candidateRoots) {
      const p = path.join(r, 'scripts', 'relay_keepalive.cjs');
      if (fs.existsSync(p)) {
        const candidateMtime = mtimeOfRoot(r, p);
        if (!keepaliveScript || candidateMtime > diskMaxMtime) {
          keepaliveScript = p;
          workingRoot = r;
          diskMaxMtime = candidateMtime;
        }
      }
    }
    if (!keepaliveScript) return;

    const claudeDir = path.join(os.homedir(), '.claude');
    if (!fs.existsSync(claudeDir)) {
      fs.mkdirSync(claudeDir, { recursive: true });
    }
    const pidFile = path.join(claudeDir, '.theo-relay-keepalive.pid');
    const metaFile = path.join(claudeDir, '.theo-relay-keepalive.json');
    const logFile = path.join(claudeDir, '.theo-relay-keepalive.log');

    let existingPid = 0;
    if (fs.existsSync(pidFile)) {
      existingPid = Number(String(fs.readFileSync(pidFile, 'utf8')).trim() || 0);
    }
    let existingBootMtime = 0;
    if (fs.existsSync(metaFile)) {
      try {
        const meta = JSON.parse(fs.readFileSync(metaFile, 'utf8'));
        existingBootMtime = Number(meta?.bootMtime || 0);
        if (!existingPid && meta?.pid) existingPid = Number(meta.pid);
      } catch {}
    }

    if (isPidAlive(existingPid)) {
      if (existingBootMtime >= diskMaxMtime - 1500) {
        return;
      }
      try {
        process.kill(existingPid);
      } catch {}
    }

    try {
      if (fs.existsSync(logFile) && fs.statSync(logFile).size > 2 * 1024 * 1024) {
        fs.unlinkSync(logFile);
      }
    } catch {}

    const nodeInfo = resolveNodeBinaryInfo();
    const usePlainNode = Boolean(nodeInfo?.executable && !nodeInfo.electronRunAsNode);
    const spawnExe = usePlainNode ? nodeInfo.executable : process.execPath;
    const spawnEnv = usePlainNode
      ? { ...process.env }
      : { ...process.env, ELECTRON_RUN_AS_NODE: '1' };
    const child = spawn(spawnExe, [keepaliveScript], {
      cwd: workingRoot,
      detached: false,
      windowsHide: true,
      stdio: 'ignore',
      env: spawnEnv
    });
    child.unref();
    if (child.pid) {
      fs.writeFileSync(pidFile, String(child.pid), 'utf8');
      fs.writeFileSync(
        metaFile,
        JSON.stringify({
          pid: child.pid,
          startedAt: Date.now(),
          bootMtime: diskMaxMtime,
          script: keepaliveScript
        }),
        'utf8'
      );
    }
  } catch {}
}

async function syncHideClaudeDesktopOnStartup({ vscodeApi = vscode, stateStore, hub, remote } = {}) {
  try {
    const cfg = vscodeApi?.workspace?.getConfiguration?.('antigravityHub');
    if (!cfg || !stateStore) {
      return;
    }
    const inspected =
      typeof cfg.inspect === 'function' ? cfg.inspect('hideClaudeDesktopSessions') : null;
    const cfgVal = cfg.get('hideClaudeDesktopSessions', false);
    const hasExplicitSetting = inspected
      ? inspected.globalValue !== undefined ||
        inspected.workspaceValue !== undefined ||
        inspected.workspaceFolderValue !== undefined
      : cfgVal !== undefined;
    const curPrefs = stateStore.read().preferences || {};
    const prefVal = Boolean(curPrefs.hideClaudeDesktopSessions);

    if (stateStore.adoptedHideClaudeDesktopOnBoot) {
      stateStore.adoptedHideClaudeDesktopOnBoot = false;
      const globalDiffers = !inspected || Boolean(inspected.globalValue) !== prefVal;
      const wsDiffers =
        inspected?.workspaceValue !== undefined && Boolean(inspected.workspaceValue) !== prefVal;
      const wsFolderDiffers =
        inspected?.workspaceFolderValue !== undefined &&
        Boolean(inspected.workspaceFolderValue) !== prefVal;
      if (globalDiffers || wsDiffers || wsFolderDiffers) {
        if (hub) {
          hub._writingHideClaudeDesktopConfigCount =
            Number(hub._writingHideClaudeDesktopConfigCount || 0) + 1;
          hub._writingHideClaudeDesktopConfig = true;
        }
        try {
          if (globalDiffers) {
            await cfg.update(
              'hideClaudeDesktopSessions',
              prefVal,
              vscodeApi?.ConfigurationTarget?.Global ?? 1
            );
          }
          if (wsDiffers) {
            await cfg.update(
              'hideClaudeDesktopSessions',
              undefined,
              vscodeApi?.ConfigurationTarget?.Workspace ?? 2
            );
          }
          if (wsFolderDiffers) {
            await cfg.update(
              'hideClaudeDesktopSessions',
              undefined,
              vscodeApi?.ConfigurationTarget?.WorkspaceFolder ?? 3
            );
          }
        } catch {} finally {
          if (hub) {
            hub._writingHideClaudeDesktopConfigCount = Math.max(
              0,
              Number(hub._writingHideClaudeDesktopConfigCount || 1) - 1
            );
            hub._writingHideClaudeDesktopConfig = hub._writingHideClaudeDesktopConfigCount > 0;
          }
        }
      }
      return;
    }

    if (hasExplicitSetting && Boolean(cfgVal) !== prefVal) {
      await stateStore.updatePreferences({
        hideClaudeDesktopSessions: Boolean(cfgVal),
        hideClaudeDesktopSessionsUpdatedAt: Date.now()
      });
      if (hub) {
        hub.lastPosted = null;
        if (typeof hub.requestRender === 'function') hub.requestRender();
        else hub.render?.();
      }
      try {
        remote?.notifyStateUpdated?.();
      } catch {}
    }
  } catch {}
}

async function runAutoOpenLastSession({ hub, tabs, store } = {}) {
  try {
    const pendingTabsPath = path.join(os.homedir(), '.claude', '.theo-pending-workspace-tabs.json');
    if (fs.existsSync(pendingTabsPath)) {
      try {
        fs.unlinkSync(pendingTabsPath);
      } catch {}
    }
    const openTabs = await tabs.getOpenTabs();
    if (openTabs.length !== 0) {
      return false;
    }
    const allThreads = hub?.snapshot?.threads || [];
    const rawLastId = await tabs.getLastConversationId();
    const lastThread = rawLastId ? allThreads.find((t) => t.id === rawLastId) : null;
    const isScratchId = (sid, thread) =>
      Boolean(
        thread?.claudeDesktopScratch ||
          hub?.isScratchDesktopSession?.(sid, thread) ||
          isClaudeDesktopScratchPath(store?.claudeFileById?.get?.(sid) || '') ||
          isClaudeDesktopScratchPath(thread?.filePath || '')
      );
    const validLastId = rawLastId && isScratchId(rawLastId, lastThread) ? '' : rawLastId;
    const fallbackThread = allThreads.find(
      (t) => t && !t.claudeDesktop && !t.claudeDesktopScratch && !isScratchId(t.id, t)
    );
    const targetId = validLastId || fallbackThread?.id || '';
    if (!targetId) {
      return false;
    }
    const matched = allThreads.find((t) => t.id === targetId);
    if (isScratchId(targetId, matched)) {
      return false;
    }
    await tabs.openThread(targetId, {
      provider: matched?.provider || 'antigravity',
      title: matched?.title || '',
      preserveFocus: false
    });
    await hub?.refresh?.();
    return true;
  } catch {
    return false;
  }
}

async function activate(context) {
  const bootPhase = createActivationPhaseLogger(context);
  ensureExcelPreviewRegistered(vscode, context);
  const store = new AntigravityDataStore();
  const stateStore = new HubStateStore(context.globalState, { diskBackup: true });
  const activity = new SessionActivityTracker();
  const tabs = new SessionTabManager();

  let hub = null;
  const accountVault = new AccountVaultManager({
    onStateChange: () => {
      if (hub) {
        hub.refresh({ forceQuota: false });
      }
    }
  });

  let pcSetupToastInFlight = false;
  async function runTrustedUiPcSetupApply(opts = {}) {
    const res = await pcSetupMod.applyPcSetupFromTrustedUi({
      ...opts,
      vscode,
      onStateChange: () => {
        if (hub) {
          hub.lastPosted = null;
          hub.requestRender?.();
        }
      }
    });
    if (hub) {
      hub.lastPosted = null;
      hub.render();
    }
    if (res?.busy) return res;
    if (res?.error || res?.ok === false) {
      const action = await vscode.window.showWarningMessage(
        `THEO PC Setup: ${res?.error || 'Some setup steps could not be completed.'}`,
        'View Checklist'
      );
      if (action === 'View Checklist') {
        hub?.openDetailsModal?.(true);
      }
      return res;
    }
    const v = res?.view;
    if (v?.ready) {
      vscode.window.setStatusBarMessage(
        `THEO: This PC is up to date (${v.okCount}/${v.totalCount} ready)`,
        4500
      );
      remote?.syncCloudRelay?.({ pushState: true, urgent: true })?.catch?.(() => {});
    } else if (v && v.pendingCount > 0) {
      const action = await vscode.window.showWarningMessage(
        `THEO: ${v.pendingCount} setup item(s) still need attention on this PC.`,
        'View Checklist'
      );
      if (action === 'View Checklist') {
        hub?.openDetailsModal?.(true);
      }
    }
    return res;
  }

  async function runBackgroundPcSetupCheck(opts = {}) {
    const view = await pcSetupMod.checkPcSetupStatus(opts);
    if (hub) {
      hub.lastPosted = null;
      hub.requestRender?.();
    }
    if (
      opts.promptToast !== false &&
      !pcSetupToastInFlight &&
      process.env.THEO_SMOKE_TEST !== '1' &&
      process.env.THEO_HEADLESS_TEST !== '1' &&
      pcSetupMod.shouldPromptPcSetupToast(view)
    ) {
      pcSetupToastInFlight = true;
      pcSetupMod.recordPcSetupToastShown(view);
      const titles = (view.pending || [])
        .slice(0, 2)
        .map((p) => p.title)
        .join(', ');
      const suffix =
        (view.pending || []).length > 2 ? `, +${view.pending.length - 2} more` : '';
      vscode.window
        .showInformationMessage(
          `THEO: ${view.pendingCount} setup update${view.pendingCount === 1 ? '' : 's'} ready on this PC (${titles}${suffix}).`,
          'Apply Setup',
          'View Checklist'
        )
        .then((choice) => {
          if (choice === 'Apply Setup') {
            return runTrustedUiPcSetupApply();
          }
          if (choice === 'View Checklist') {
            hub?.openDetailsModal?.(true);
          }
          return null;
        })
        .catch(() => {})
        .finally(() => {
          pcSetupToastInFlight = false;
        });
    }
    return view;
  }

  hub = new HubProvider(context, {
    store,
    stateStore,
    activity,
    tabs,
    accountVault,
    getPcSetupView: () => pcSetupMod.getLocalPcSetupView(),
    checkPcSetup: (opts) => runBackgroundPcSetupCheck({ ...opts, promptToast: false }),
    applyPcSetup: (opts) => runTrustedUiPcSetupApply(opts),
    ensureBridge: async (opts) => {
      const res = await ensureAntigravityBridgeInstalled(context, {
        forcePromptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude'),
        ...opts
      });
      hub?.setBridgeInstallReport?.(res);
      return res;
    }
  });
  accountVault.hubRef = hub;

  let remote = new TheoRemoteBridge(context, {
    vscode,
    hub,
    store,
    stateStore,
    tabs,
    accountVault
  });
  hub.remote = remote;
  await syncHideClaudeDesktopOnStartup({ vscodeApi: vscode, stateStore, hub, remote });

  context.subscriptions.push(
    vscode.commands.registerCommand('antigravityHub.openRemote', async () => {
      const st = remote.getStatus();
      const items = [
        {
          label: '$(globe) Open THEO Remote PWA (GitHub Pages + Cloud Relay)',
          description: st.pwaUrl,
          target: st.pwaUrl
        },
        {
          label: '$(broadcast) Open Local Direct Bridge (Instant SSE)',
          description: st.localUrl,
          target: st.localUrl
        },
        {
          label: '$(device-mobile) Copy LAN Mobile URL (Wi-Fi)',
          description: st.lanUrl,
          copy: st.lanUrl
        },
        {
          label: '$(cloud-upload) Force Sync Snapshot to Cloud Relay Now',
          syncNow: true
        }
      ];
      const picked = await vscode.window.showQuickPick(items, {
        placeHolder: `THEO Remote Bridge (${st.listening ? `Listening on :${st.port}` : 'Cloud Relay Ready'})`
      });
      if (!picked) {
        return;
      }
      if (picked.syncNow) {
        await remote.syncCloudRelay({ pushState: true });
        vscode.window.setStatusBarMessage('THEO Remote: Snapshot synced to Cloud Relay', 3000);
      } else if (picked.copy) {
        await vscode.env.clipboard.writeText(picked.copy);
        vscode.window.setStatusBarMessage(`Copied THEO LAN URL: ${picked.copy}`, 3000);
      } else if (picked.target) {
        await vscode.env.openExternal(vscode.Uri.parse(picked.target));
      }
    }),
    vscode.commands.registerCommand('antigravityHub.syncRemoteCloud', async () => {
      const res = await remote.syncCloudRelay({ pushState: true });
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.addAccount', async (opts = {}) => {
      let provider = opts?.provider;
      if (provider !== 'antigravity' && provider !== 'claude') {
        const picked = await vscode.window.showQuickPick(
          [
            {
              label: '$(sparkle) Google Antigravity',
              description: 'Sign in an additional Google AI account (keeps existing accounts logged in)',
              provider: 'antigravity'
            },
            {
              label: '$(hubot) Anthropic Claude Code',
              description: 'Sign in an additional Claude account (keeps existing accounts logged in)',
              provider: 'claude'
            }
          ],
          { placeHolder: 'Choose which provider account to add to THEO' }
        );
        if (!picked) return null;
        provider = picked.provider;
      }
      const label = await vscode.window.showInputBox({
        title: `Add ${provider === 'claude' ? 'Claude Code' : 'Antigravity'} Account`,
        prompt: 'Optional nickname / label (e.g., Friend, Personal, Work)',
        placeHolder: 'Optional label — press Enter to skip'
      });
      if (label === undefined) return null;
      return hub.handleMessage({
        action: 'accountAdd',
        provider,
        label,
        switchOnComplete: true
      });
    }),
    vscode.commands.registerCommand('antigravityHub.switchAccount', async () => {
      const agyList = (hub.accountsView?.antigravity || []).filter(
        (a) => a && a.available !== false && !a.signedOut
      );
      const claudeList = (hub.accountsView?.claude || []).filter(
        (a) => a && a.available !== false && !a.signedOut
      );
      const items = [
        ...agyList.map((a) => ({
          label: `${a.active ? '$(check) ' : ''}Antigravity · ${a.email || a.name}`,
          description: `${a.label ? `[${a.label}] · ` : ''}${a.plan || ''}${a.active ? ' (Active)' : ''}`,
          provider: 'antigravity',
          accountId: a.id,
          active: a.active
        })),
        ...claudeList.map((a) => ({
          label: `${a.active ? '$(check) ' : ''}Claude Code · ${a.email || a.name}`,
          description: `${a.label ? `[${a.label}] · ` : ''}${a.plan || ''}${a.active ? ' (Active)' : ''}`,
          provider: 'claude',
          accountId: a.id,
          active: a.active
        })),
        {
          label: '$(add) Add another account…',
          description: 'Keep all current accounts logged in',
          addNew: true
        }
      ];
      const picked = await vscode.window.showQuickPick(items, {
        placeHolder: 'Switch active account or add a new account'
      });
      if (!picked) return null;
      if (picked.addNew) {
        return vscode.commands.executeCommand('antigravityHub.addAccount');
      }
      if (!picked.active) {
        await hub.handleMessage({
          action: 'accountSwitch',
          provider: picked.provider,
          accountId: picked.accountId
        });
      }
      return picked;
    }),
    vscode.commands.registerCommand('antigravityHub.checkPcSetup', async () => {
      await runBackgroundPcSetupCheck({ force: true, promptToast: false });
      hub?.openDetailsModal?.(true);
    }),
    vscode.commands.registerCommand('antigravityHub.applyPcSetup', async () => {
      const view = await runBackgroundPcSetupCheck({ force: true, promptToast: false });
      const msg =
        view && view.pendingCount > 0
          ? `Apply ${view.pendingCount} pending THEO setup update${view.pendingCount === 1 ? '' : 's'} on this PC?`
          : 'Re-verify and repair THEO setup on this PC?';
      const confirm = await vscode.window.showInformationMessage(
        msg,
        { modal: true },
        'Apply Setup'
      );
      if (confirm !== 'Apply Setup') return null;
      return runTrustedUiPcSetupApply();
    }),
    vscode.commands.registerCommand('antigravityHub.newSession', async (opts = {}) => {
      const res = await tabs.openNewSession({
        provider: opts?.provider === 'claude' ? 'claude' : 'antigravity'
      });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newClaudeSession', async () => {
      const res = await tabs.openNewSession({ provider: 'claude' });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newSessionBeside', async (opts = {}) => {
      const res = await tabs.openNewSession({
        provider: opts?.provider === 'claude' ? 'claude' : 'antigravity',
        beside: true
      });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newClaudeSessionBeside', async () => {
      const res = await tabs.openNewSession({ provider: 'claude', beside: true });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.refresh', async () => {
      await hub.refresh({ forceQuota: true });
    }),
    vscode.commands.registerCommand('antigravityHub.repairBridge', async () => {
      const res = await ensureAntigravityBridgeInstalled(context, {
        promptReload: true,
        forcePromptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude')
      });
      hub.setBridgeInstallReport?.(res);
      await hub.refresh();
    }),
    vscode.commands.registerCommand('antigravityHub.markThreadSeen', async (payload) => {
      const threadId = typeof payload === 'string' ? payload : payload?.id || payload?.threadId;
      const seenAt = typeof payload === 'object' ? payload?.seenAt : 0;
      if (threadId) {
        await hub.markThreadSeen(threadId, seenAt);
      }
    }),
    vscode.commands.registerCommand('antigravityHub.activityChanged', async (payload) => {
      if (payload && typeof payload === 'object') {
        activity.ingestBridgeEvent(payload);
        if (Array.isArray(payload.conversations) && payload.conversations.length > 0) {
          hub.syncOpenTabBadges();
          hub.requestRender();
        }
        const evType = String(payload.type || '');
        const isBackgroundOrBeside = Boolean(
          payload.preserveFocus || payload.beside || evType.endsWith('-bg')
        );
        const isExplicitOpenCommand =
          !isBackgroundOrBeside &&
          (evType === 'reveal' ||
            evType === 'reveal-draft' ||
            evType === 'open-thread' ||
            evType === 'open-new');
        const isTabEvent =
          isExplicitOpenCommand ||
          evType === 'tab-closed' ||
          evType === 'reveal-bg' ||
          evType === 'reveal-draft-bg' ||
          evType === 'open-thread-bg' ||
          evType === 'open-new-bg' ||
          evType === 'focus' ||
          evType === 'tab-state' ||
          evType === 'tab-resolved' ||
          evType === 'url' ||
          evType === 'claude-setup-panel' ||
          evType === 'claude-register-session';
        if (evType === 'tab-closed') {
          hub.clearPendingActiveTargetIfMatches?.({
            id: payload.threadId || '',
            key: payload.uri || ''
          });
        }
        const pendingTarget =
          typeof hub.getPendingActiveTarget === 'function' ? hub.getPendingActiveTarget() : null;
        const payloadDiffersFromPending = Boolean(
          pendingTarget &&
            ((pendingTarget.id && payload.threadId && payload.threadId !== pendingTarget.id) ||
              (pendingTarget.key && payload.uri && payload.uri !== pendingTarget.key))
        );
        const payloadMatchesOutgoing = Boolean(
          pendingTarget &&
            ((payload.threadId && pendingTarget.outgoingIds?.has?.(payload.threadId)) ||
              (payload.uri && pendingTarget.outgoingKeys?.has?.(payload.uri)))
        );
        const isPendingBounceFromOtherTab = Boolean(
          payloadDiffersFromPending &&
            (!pendingTarget.confirmedInTabs ||
              payloadMatchesOutgoing ||
              Date.now() - Number(pendingTarget.setAt || 0) < 600)
        );
        if (
          !isPendingBounceFromOtherTab &&
          !isBackgroundOrBeside &&
          payload.threadId &&
          (evType === 'focus' ||
            evType === 'reveal' ||
            evType === 'open-thread' ||
            (evType === 'tab-state' && payload.active))
        ) {
          await hub.markThreadSeen(payload.threadId);
        }
        if (isTabEvent) {
          const nextOptimisticId = isPendingBounceFromOtherTab
            ? pendingTarget.id || ''
            : isExplicitOpenCommand
              ? payload.threadId || ''
              : '';
          const nextOptimisticKey = isPendingBounceFromOtherTab
            ? pendingTarget.key || ''
            : isExplicitOpenCommand && (evType === 'reveal-draft' || evType === 'open-new')
              ? payload.uri || ''
              : '';
          await hub.refreshTabStateFast({
            optimisticActiveId: nextOptimisticId,
            optimisticActiveKey: nextOptimisticKey,
            forceOptimistic: Boolean(isPendingBounceFromOtherTab || isExplicitOpenCommand),
            scheduleFullRefreshMs: 320
          });
          return;
        }
      }
      await hub.refresh({ force: true });
    })
  );

  context.subscriptions.push(
    vscode.workspace.onDidChangeConfiguration(async (e) => {
      if (e.affectsConfiguration('antigravityHub.hideThirdPartyQuota') && !hub._writingHideThirdPartyConfig) {
        const next = Boolean(
          vscode.workspace.getConfiguration('antigravityHub').get('hideThirdPartyQuota', false)
        );
        const curPrefs = stateStore.read().preferences || {};
        if (curPrefs.hideThirdPartyQuota !== next) {
          await stateStore.updatePreferences({
            hideThirdPartyQuota: next,
            hideThirdPartyQuotaUpdatedAt: Date.now()
          });
          hub.lastPosted = null;
          hub.render();
          try {
            remote?.notifyStateUpdated?.();
          } catch {}
        }
      }
      if (
        e.affectsConfiguration('antigravityHub.hideClaudeDesktopSessions') &&
        !hub._writingHideClaudeDesktopConfig &&
        !(hub._writingHideClaudeDesktopConfigCount > 0)
      ) {
        const nextDesktop = Boolean(
          vscode.workspace
            .getConfiguration('antigravityHub')
            .get('hideClaudeDesktopSessions', false)
        );
        const curPrefs = stateStore.read().preferences || {};
        if (curPrefs.hideClaudeDesktopSessions !== nextDesktop) {
          await stateStore.updatePreferences({
            hideClaudeDesktopSessions: nextDesktop,
            hideClaudeDesktopSessionsUpdatedAt: Date.now()
          });
          hub.lastPosted = null;
          hub.render();
          try {
            remote?.notifyStateUpdated?.();
          } catch {}
        }
      }
    })
  );

  // Boot order (2026-10-20): nothing below blocks activate() from resolving, and nothing that the
  // sidebar needs waits for Claude Code. After a cold boot Claude Code's own activation took 102 s
  // and THEO used to `await claudeExt.activate()` before attaching the sidebar or loading any data.
  bootPhase('commands-registered');

  const autoOpenLastSession = () => {
    const autoOpen = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('autoOpenLastSessionOnStartup', true);
    if (!autoOpen) {
      return;
    }
    setTimeout(() => {
      void runAutoOpenLastSession({ hub, tabs, store });
    }, 600);
  };

  let fallbackEditorDisposable = null;
  const ensureFallbackConversationEditorIfNeeded = () => {
    if (fallbackEditorDisposable) {
      return;
    }
    const disposables = [];
    try {
      disposables.push(
        vscode.workspace.registerTextDocumentContentProvider('antigravity-session', {
          provideTextDocumentContent: () => ''
        })
      );
    } catch {}
    try {
      const iconUri = vscode.Uri.joinPath(
        context.extensionUri,
        'resources',
        'antigravity-logo-color.svg'
      );
      disposables.push(
        vscode.window.registerCustomEditorProvider(
          'antigravity.conversationEditor',
          {
            async openCustomDocument(uri) {
              return { uri, dispose() {} };
            },
            async resolveCustomEditor(document, webviewPanel) {
              const parsed = parseSessionUri(document.uri);
              const persisted = stateStore.read();
              let title = '';
              if (parsed.kind === 'thread' && parsed.threadId) {
                title =
                  persisted?.customTitles?.[parsed.threadId] ||
                  (hub?.snapshot?.threads || []).find((t) => t.id === parsed.threadId)?.title ||
                  '';
              }
              webviewPanel.title = title || 'Antigravity';
              try {
                webviewPanel.iconPath = { light: iconUri, dark: iconUri };
              } catch {}
              webviewPanel.webview.options = { enableScripts: true };
              webviewPanel.webview.onDidReceiveMessage(async (msg) => {
                if (msg && msg.type === 'reload') {
                  await vscode.commands.executeCommand('workbench.action.reloadWindow');
                }
              });
              webviewPanel.webview.html = [
                '<!doctype html><html><head><meta charset="utf-8">',
                '<style>body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:var(--vscode-editor-background,#18181b);color:var(--vscode-editor-foreground,#e4e4e7);font:13px/1.5 var(--vscode-font-family,system-ui,sans-serif)}.card{max-width:420px;padding:24px 28px;border:1px solid var(--vscode-panel-border,rgba(255,255,255,.1));border-radius:10px;text-align:center}h3{margin:0 0 8px;font-size:15px;font-weight:600}p{margin:0 0 16px;opacity:.8}button{background:var(--vscode-button-background,#2563eb);color:var(--vscode-button-foreground,#fff);border:0;border-radius:6px;padding:8px 16px;font:inherit;font-weight:500;cursor:pointer}</style>',
                '</head><body><div class="card"><h3>THEO Session Tab Preserved</h3>',
                '<p>Antigravity was updated and THEO preserved this session tab. Reload VS Code once to reconnect the live session view.</p>',
                '<button id="btn">Reload Window</button></div>',
                '<script>const v=acquireVsCodeApi();document.getElementById("btn").onclick=()=>v.postMessage({type:"reload"});</script>',
                '</body></html>'
              ].join('');
            }
          },
          {
            webviewOptions: { retainContextWhenHidden: true },
            supportsMultipleEditorsPerDocument: false
          }
        )
      );
    } catch {}
    if (disposables.length > 0) {
      fallbackEditorDisposable = vscode.Disposable.from(...disposables);
      context.subscriptions.push(fallbackEditorDisposable);
    }
  };

  const bootAntigravitySide = async () => {
    // google.google-antigravity is a declared extensionDependency, so it is already active here.
    try {
      const agyExt = vscode.extensions.getExtension('google.google-antigravity');
      if (agyExt && !agyExt.isActive) {
        await agyExt.activate();
      }
    } catch {}
    await vscode.commands.executeCommand('antigravityHub.attachSidebar', hub).then(
      () => {},
      () => {}
    );
    bootPhase('antigravity-sidebar-attached');

    await hub.refresh({ forceQuota: true });
    bootPhase('first-refresh');

    await new Promise((resolve) => {
      const creds = loadTheoCredentials();
      const bearer = creds.effectiveEdgeSecret
        ? deriveEdgeAuthToken(creds.effectiveEdgeSecret)
        : '';
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: remote.port || 4318,
          path: '/api/yield-port',
          method: 'POST',
          headers: bearer ? { Authorization: `Bearer ${bearer}` } : {},
          timeout: 800
        },
        (res) => {
          res.resume();
          res.on('end', () => setTimeout(resolve, 80));
        }
      );
      req.on('error', () => resolve());
      req.on('timeout', () => {
        try {
          req.destroy();
        } catch {}
        resolve();
      });
      req.end();
    });
    await remote.start().catch(() => {});
    ensureRelayKeepaliveDaemon(context);
    bootPhase('remote-bridge-started');

    let agyBridgeStatus = null;
    try {
      agyBridgeStatus = await vscode.commands.executeCommand('antigravityHub.bridgeStatus');
    } catch {}
    if (agyBridgeStatus?.active) {
      autoOpenLastSession();
    } else {
      ensureFallbackConversationEditorIfNeeded();
    }
  };

  const bootClaudeSide = async () => {
    const claudeSignedIn = accountVault.hasSignedInProvider('claude');
    let claudeExt = null;
    try {
      claudeExt = vscode.extensions.getExtension('anthropic.claude-code');
      if (claudeSignedIn && claudeExt && !claudeExt.isActive) {
        await claudeExt.activate();
      }
    } catch {}
    bootPhase(claudeSignedIn ? 'claude-code-active' : 'claude-code-skipped-signed-out');
    if (claudeExt?.isActive) {
      await vscode.commands.executeCommand('antigravityHub.claudeAttachSidebar', hub).then(
        () => {},
        () => {}
      );
      bootPhase('claude-sidebar-attached');
      let claudeStatus = null;
      try {
        claudeStatus = await vscode.commands.executeCommand('antigravityHub.claudeBridgeStatus');
      } catch {}
      if (!claudeStatus?.active && claudeSignedIn) {
        const autoMaintain = vscode.workspace
          .getConfiguration('antigravityHub')
          .get('autoMaintainBridge', true);
        if (autoMaintain) {
          try {
            const res = await ensureAntigravityBridgeInstalled(context, {
              promptReload: true,
              claudeSignedIn
            });
            hub.setBridgeInstallReport?.(res);
          } catch {}
        }
      }
    }
    hub.refresh({ forceQuota: false });
  };

  const bootBridgeMaintenance = async (claudeBoot) => {
    const autoMaintain = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('autoMaintainBridge', true);
    if (!autoMaintain) {
      return;
    }
    // Give Claude Code up to 2.5s to finish fast activation; if it takes longer, bridge.js inspects
    // claudeExt.isActive so a still-activating extension never causes a false reload toast, and
    // bootClaudeSide re-verifies once claudeExt.activate() resolves.
    await Promise.race([claudeBoot, new Promise((r) => setTimeout(r, 2500))]);
    try {
      const res = await ensureAntigravityBridgeInstalled(context, {
        promptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude')
      });
      hub.setBridgeInstallReport?.(res);
    } catch {}
    bootPhase('bridge-maintained');
  };

  const claudeBoot = bootClaudeSide().catch(() => {});
  bootAntigravitySide()
    .catch(() => {})
    .then(() => bootBridgeMaintenance(claudeBoot))
    .catch(() => {})
    .then(() => bootPhase('boot-complete'));

  // Keep open/active tab state synced when editor tabs change without triggering a full snapshot storm
  if (vscode.window.tabGroups) {
    context.subscriptions.push(
      vscode.window.tabGroups.onDidChangeTabs(async () => {
        await hub.refreshTabStateFast({ scheduleFullRefreshMs: 320 });
      }),
      vscode.window.tabGroups.onDidChangeTabGroups(async () => {
        await hub.refreshTabStateFast({ scheduleFullRefreshMs: 320 });
      })
    );
  }

  context.subscriptions.push(
    vscode.window.onDidChangeWindowState(async (winState) => {
      if (winState?.focused) noteLocalUserActivity();
      await hub.refreshTabStateFast({ scheduleFullRefreshMs: 320 });
    }),
    vscode.window.onDidChangeTextEditorSelection(() => {
      noteLocalUserActivity();
    }),
    vscode.workspace.onDidChangeTextDocument((ev) => {
      if (ev?.contentChanges?.length > 0) noteLocalUserActivity();
    }),
    vscode.window.onDidChangeActiveTerminal(() => {
      noteLocalUserActivity();
    })
  );

  let hotSwapInFlight = false;
  let hotSwapDeferSince = 0;
  let hotSwapAttemptedMtime = 0; // a swap that threw is not retried every tick, only on the next change
  const hotSwapMemo = new Map();
  async function maybeHotSwapRemoteBridge() {
    if (hotSwapInFlight) return;
    try {
      const extRoot = context?.extensionPath || __dirname;
      const repoRoot = path.join(os.homedir(), 'bhfirms', 'theo-hub');
      const watchedFiles = [
        'remote.js',
        'bridge.js',
        'data.js',
        'state.js',
        'store.js',
        'accounts.js',
        'hub.js',
        'activity.js',
        'session-tabs.js',
        'desktop-notify.js',
        'desktop-launcher.js',
        'device-identity.js',
        'pc-setup.js',
        'unsaved-work.js',
        'bundle-updater.js',
        'ws-server.js',
        'direct-runner.js',
        'edge-relay-client.js',
        path.join('compat', 'antigravity-hub-bridge.cjs'),
        path.join('compat', 'antigravity-context-window.cjs'),
        path.join('compat', 'antigravity-tab-state.cjs'),
        path.join('compat', 'claude-hub-bridge.cjs'),
        path.join('compat', 'claude-webview-patches.cjs'),
        path.join('compat', 'excel-preview.cjs'),
        path.join('resources', 'theo.ico'),
        path.join('resources', 'TheoLauncher.cs'),
        path.join('resources', 'hub.js'),
        path.join('resources', 'hub.css'),
        path.join('resources', 'hub.html')
      ];

      // If ~/bhfirms/theo-hub/* was edited on disk and differs from the installed copy, sync it automatically,
      // once the edits have been quiet (planHotSwap).
      const plan = planHotSwap({
        repoRoot,
        extRoot,
        watchedFiles,
        loadedMtime: Math.max(Number(remote?.codeMtime || 0), hotSwapAttemptedMtime),
        nowMs: Date.now(),
        deferSince: hotSwapDeferSince,
        memo: hotSwapMemo
      });
      if (plan.action === 'idle') {
        hotSwapDeferSince = 0;
        return;
      }
      if (plan.action === 'wait') {
        if (!hotSwapDeferSince) hotSwapDeferSince = Date.now();
        return;
      }
      hotSwapDeferSince = 0;
      let copied = 0;
      for (const relFile of plan.toCopy) {
        const srcFile = path.join(repoRoot, relFile);
        const dstFile = path.join(extRoot, relFile);
        if (copyFileAtomicSync(srcFile, dstFile)) {
          copied += 1;
        } else {
          // Locked (antivirus, another window): hold it back and retry later instead of every tick.
          hotSwapMemo.set(relFile, {
            key: `${getFileMtimeMs(srcFile)}:${getFileMtimeMs(dstFile)}`,
            same: false,
            retryAt: Date.now() + HOT_SWAP_COPY_RETRY_MS
          });
        }
      }
      // Every copy failed and nothing else changed: the loaded code is still current, so do not swap.
      if (copied === 0 && plan.installedChanged.length === 0 && Number(remote?.codeMtime || 0) > 0) {
        return;
      }
      // A bridge module whose copy is held back would be copied later by syncHotReloadedModules without ever
      // being loaded: wait for its retry (up to the max-defer cap), then restart the bridge.
      const heldBackRestartFile = [...hotSwapMemo].some(
        ([rel, m]) => HOT_SWAP_RESTART_FILES.has(rel) && m && m.same === false && Number(m.retryAt || 0) > Date.now()
      );
      if (heldBackRestartFile) {
        if (!hotSwapDeferSince) hotSwapDeferSince = Date.now();
        if (Date.now() - hotSwapDeferSince < HOT_SWAP_MAX_DEFER_MS) return;
      }
      const restartRemote =
        plan.needsRestart ||
        heldBackRestartFile ||
        plan.toCopy.some((rel) => HOT_SWAP_RESTART_FILES.has(rel)) ||
        !remote ||
        remote.disposed === true ||
        typeof remote.syncHotReloadedModules !== 'function';
      const maxMtime = Math.max(plan.maxMtime, Date.now());
      hotSwapAttemptedMtime = maxMtime;
      // Already copied above, so syncHotReloadedModules would find no difference on its own: hand it the list
      // so a bridge.js / claude-webview-patches.cjs change forces the re-patch and an
      // antigravity-context-window.cjs change resets the cached /main.js.
      const hotSwapChangedFiles = [...new Set([...plan.toCopy, ...plan.installedChanged])];

      {
        hotSwapInFlight = true;
        if (restartRemote) {
          try {
            remote.dispose();
          } catch {}
          await new Promise((r) => setTimeout(r, 150));
        }
        for (const modName of [
          './data',
          './remote',
          './state',
          './store',
          './accounts',
          './activity',
          './session-tabs',
          './desktop-notify',
          './desktop-launcher',
          './device-identity',
          './pc-setup',
          './bundle-updater',
          './ws-server',
          './direct-runner',
          './edge-relay-client',
          './hub',
          './compat/antigravity-hub-bridge.cjs',
          './compat/antigravity-context-window.cjs',
          './compat/antigravity-tab-state.cjs',
          './compat/claude-hub-bridge.cjs',
          './compat/claude-webview-patches.cjs',
          './compat/excel-preview.cjs',
          './bridge'
        ]) {
          // In place, the live bridge keeps its modules: a second copy of device-identity or pc-setup would
          // split their in-module state (idle tracking, apply-in-flight) between the bridge and the rest.
          if (!restartRemote && HOT_SWAP_RESTART_FILES.has(`${modName.replace(/^\.\//, '')}.js`)) continue;
          try {
            const resolvedMod = require.resolve(modName);
            delete require.cache[resolvedMod];
          } catch {}
        }
        try {
          const { HubStateStore: FreshStateStore } = require('./state');
          const { AntigravityDataStore: FreshStore } = require('./store');
          const {
            AccountVaultManager: FreshVault,
            defaultHttpsJsonRequest: freshHttpsJsonRequest
          } = require('./accounts');
          const { SessionActivityTracker: FreshActivity } = require('./activity');
          const { SessionTabManager: FreshTabs } = require('./session-tabs');
          const { HubProvider: FreshHub } = require('./hub');
          pcSetupMod = require('./pc-setup');
          if (stateStore && FreshStateStore?.prototype) {
            Object.setPrototypeOf(stateStore, FreshStateStore.prototype);
          }
          Object.setPrototypeOf(store, FreshStore.prototype);
          store.cachedSqliteMtimeMs = 0;
          store.cachedClaudeVscMtimeMs = 0;
          if (
            FreshStore?.PARSE_CACHE_VERSION &&
            Number(store.parseCacheVersion || 0) !== Number(FreshStore.PARSE_CACHE_VERSION)
          ) {
            store.transcriptCache?.clear?.();
            store.claudeSessionCache?.clear?.();
            store.parseCacheVersion = Number(FreshStore.PARSE_CACHE_VERSION);
            store.readPersistedParseCache?.();
          }
          if (accountVault) {
            Object.setPrototypeOf(accountVault, FreshVault.prototype);
            if (!accountVault.hasCustomHttpsJsonRequest && freshHttpsJsonRequest) {
              accountVault.httpsJsonRequest = freshHttpsJsonRequest;
            }
            accountVault.agyQuotaInFlightById?.clear?.();
            accountVault.claudeQuotaInFlightById?.clear?.();
          }
          if (tabs) {
            Object.setPrototypeOf(tabs, FreshTabs.prototype);
          }
          if (hub?.activity) {
            Object.setPrototypeOf(hub.activity, FreshActivity.prototype);
          }
          if (hub) {
            Object.setPrototypeOf(hub, FreshHub.prototype);
            hub.accountVault = accountVault;
            hub.getPcSetupView = () => pcSetupMod.getLocalPcSetupView();
            hub.checkPcSetup = (opts) => runBackgroundPcSetupCheck({ ...opts, promptToast: false });
            hub.applyPcSetup = (opts) => runTrustedUiPcSetupApply(opts);
            if (
              hub.refreshInFlight &&
              (!hub.refreshStartedAt || Date.now() - Number(hub.refreshStartedAt || 0) > 10000)
            ) {
              hub.refreshInFlight = null;
            }
            hub.reloadAllWebviews?.();
          }
          try {
            const freshBridgeInstaller = require('./bridge');
            if (typeof freshBridgeInstaller?.ensureAntigravityBridgeInstalled === 'function') {
              ensureAntigravityBridgeInstalled = freshBridgeInstaller.ensureAntigravityBridgeInstalled;
            }
            if (typeof freshBridgeInstaller?.prepatchInstalledExtensions === 'function') {
              prepatchInstalledExtensions = freshBridgeInstaller.prepatchInstalledExtensions;
            }
            prepatchInstalledExtensionsAsync =
              typeof freshBridgeInstaller?.prepatchInstalledExtensionsAsync === 'function'
                ? freshBridgeInstaller.prepatchInstalledExtensionsAsync
                : null;
            prepatchInstalledExtensionsOffThread(extRoot);
          } catch {}
          try {
            const freshClaudeBridge = require('./compat/claude-hub-bridge.cjs');
            freshClaudeBridge?.hotUpgradeLiveState?.();
          } catch {}
          try {
            const freshAgyBridge = require('./compat/antigravity-hub-bridge.cjs');
            freshAgyBridge?.hotUpgradeLiveState?.(freshAgyBridge.getBridgeState(), vscode, hub);
          } catch {}
          if (
            process.platform === 'win32' &&
            process.env.THEO_SMOKE_TEST !== '1' &&
            process.env.THEO_HEADLESS_TEST !== '1'
          ) {
            try {
              const csMtime = getFileMtimeMs(path.join(extRoot, 'resources', 'TheoLauncher.cs'));
              const exeMtime = getFileMtimeMs(path.join(os.homedir(), '.theo', 'THEO.exe'));
              if (csMtime > 0 && csMtime > exeMtime) {
                const launcherMod = require('./desktop-launcher');
                const ico = launcherMod.ensureStableDesktopIcon({ hubRoot: extRoot, homeDir: os.homedir() });
                launcherMod.ensureNativeLauncherExecutable({
                  hubRoot: extRoot,
                  homeDir: os.homedir(),
                  iconPath: ico.iconPath,
                  force: true
                });
              }
            } catch {}
          }
        } catch {}
        if (!restartRemote) {
          // Bridge modules unchanged: keep the phone link and relay up and swap the rest in place, as the
          // signed bundle updater does (remote.syncHotReloadedModules also re-points the live bridge state).
          try {
            remote.syncHotReloadedModules({ changedFiles: hotSwapChangedFiles });
          } catch {}
          remote.codeMtime = Math.max(maxMtime, Number(remote.codeMtime || 0), Date.now());
          return;
        }
        const { TheoRemoteBridge: FreshRemoteBridge } = require('./remote');
        remote = new FreshRemoteBridge(context, {
          vscode,
          hub,
          store,
          stateStore,
          tabs,
          accountVault,
          hotSwapChangedFiles
        });
        remote.codeMtime = Math.max(maxMtime, Number(remote.codeMtime || 0), Date.now());
        hub.remote = remote;
        await new Promise((resolve) => {
      const creds = loadTheoCredentials();
      const bearer = creds.effectiveEdgeSecret
        ? deriveEdgeAuthToken(creds.effectiveEdgeSecret)
        : '';
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: remote.port || 4318,
          path: '/api/yield-port',
          method: 'POST',
          headers: bearer ? { Authorization: `Bearer ${bearer}` } : {},
          timeout: 800
        },
        (res) => {
          res.resume();
          res.on('end', () => setTimeout(resolve, 80));
        }
      );
      req.on('error', () => resolve());
      req.on('timeout', () => {
        try {
          req.destroy();
        } catch {}
        resolve();
      });
      req.end();
    });
    await remote.start().catch(() => {});
        ensureRelayKeepaliveDaemon(context);
      }
    } catch {} finally {
      hotSwapInFlight = false;
    }
  }

  const pcSetupBootTimer = setTimeout(() => {
    runBackgroundPcSetupCheck().catch(() => {});
  }, 2500);
  if (typeof pcSetupBootTimer?.unref === 'function') {
    pcSetupBootTimer.unref();
  }

  let tickCount = 0;
  const pollTimer = setInterval(() => {
    tickCount += 1;
    maybeHotSwapRemoteBridge().catch(() => {});
    if (tickCount % 3 === 0) {
      prepatchInstalledExtensionsOffThread(context?.extensionPath || __dirname);
    }
    if (tickCount % 10 === 0) {
      ensureRelayKeepaliveDaemon(context);
      runBackgroundPcSetupCheck().catch(() => {});
    }
    if (
      hub.visible ||
      vscode.window.state.focused ||
      remote.sseClients.size > 0 ||
      tickCount % 3 === 0
    ) {
      hub.refresh({ forceQuota: false });
    }
  }, 6000);

  context.subscriptions.push({
    dispose() {
      clearTimeout(pcSetupBootTimer);
      clearInterval(pollTimer);
      stateStore?.flushDiskBackupSync?.();
      remote.dispose();
      hub.dispose();
    }
  });
}

function deactivate() {}

module.exports = {
  activate,
  deactivate,
  planHotSwap,
  copyFileAtomicSync,
  syncHideClaudeDesktopOnStartup,
  runAutoOpenLastSession,
  HOT_SWAP_QUIET_MS,
  HOT_SWAP_MAX_DEFER_MS,
  HOT_SWAP_RESTART_FILES
};
