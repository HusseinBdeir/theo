const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const vscode = require('vscode');
const { AntigravityDataStore } = require('./store');
const { HubStateStore } = require('./state');
const { SessionActivityTracker } = require('./activity');
const { SessionTabManager } = require('./session-tabs');
const { HubProvider } = require('./hub');
let {
  ensureAntigravityBridgeInstalled,
  prepatchInstalledExtensions
} = require('./bridge');
const { TheoRemoteBridge } = require('./remote');
const { AccountVaultManager } = require('./accounts');
const {
  loadTheoCredentials,
  deriveEdgeAuthToken,
  resolveNodeBinaryInfo,
  noteLocalUserActivity
} = require('./device-identity');
const { ensureExcelPreviewRegistered } = require('./compat/excel-preview.cjs');
const { parseSessionUri } = require('./compat/antigravity-tab-state.cjs');

function isPidAlive(pid) {
  const n = Number(pid || 0);
  if (!n || n <= 0) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch (err) {
    return err && err.code === 'EPERM';
  }
}

function getFileMtimeMs(filePath) {
  try {
    return Math.floor(fs.statSync(filePath).mtimeMs);
  } catch {
    return 0;
  }
}

// Appends "<iso> +<ms since activate()> <phase>" lines to ~/.claude/.theo-hub-activation.log so a slow
// THEO start can be attributed to a phase (sidebar attach, first refresh, Claude Code activation, ...).
function createActivationPhaseLogger(context) {
  const startedAt = Date.now();
  let logPath = '';
  try {
    const claudeDir = path.join(os.homedir(), '.claude');
    fs.mkdirSync(claudeDir, { recursive: true });
    logPath = path.join(claudeDir, '.theo-hub-activation.log');
    if (fs.existsSync(logPath) && fs.statSync(logPath).size > 256 * 1024) {
      fs.unlinkSync(logPath);
    }
    fs.appendFileSync(
      logPath,
      `\n[${new Date(startedAt).toISOString()}] activate() start (ext ${context?.extension?.packageJSON?.version || '?'}, host pid ${process.pid})\n`,
      'utf8'
    );
  } catch {
    logPath = '';
  }
  return (phase) => {
    const elapsed = Date.now() - startedAt;
    const line = `[${new Date().toISOString()}] +${elapsed} ms ${phase}`;
    try {
      console.log(`[theo-hub] ${line}`);
    } catch {}
    if (logPath) {
      try {
        fs.appendFileSync(logPath, `${line}\n`, 'utf8');
      } catch {}
    }
  };
}

function ensureRelayKeepaliveDaemon(context) {
  try {
    const repoRoot = path.join(os.homedir(), 'bhfirms', 'theo-hub');
    const extRoot = context?.extensionPath || __dirname;
    const candidateRoots = [repoRoot, extRoot];
    const mtimeOfRoot = (r, scriptPath) =>
      Math.max(
        getFileMtimeMs(scriptPath),
        getFileMtimeMs(path.join(r, 'remote.js')),
        getFileMtimeMs(path.join(r, 'store.js')),
        getFileMtimeMs(path.join(r, 'accounts.js')),
        getFileMtimeMs(path.join(r, 'data.js')),
        getFileMtimeMs(path.join(r, 'device-identity.js')),
        getFileMtimeMs(path.join(r, 'bundle-updater.js')),
        getFileMtimeMs(path.join(r, 'direct-runner.js')),
        getFileMtimeMs(path.join(r, 'edge-relay-client.js'))
      );
    let keepaliveScript = '';
    let workingRoot = extRoot;
    let diskMaxMtime = 0;
    for (const r of candidateRoots) {
      const p = path.join(r, 'scripts', 'relay_keepalive.cjs');
      if (fs.existsSync(p)) {
        const candidateMtime = mtimeOfRoot(r, p);
        if (!keepaliveScript || candidateMtime > diskMaxMtime) {
          keepaliveScript = p;
          workingRoot = r;
          diskMaxMtime = candidateMtime;
        }
      }
    }
    if (!keepaliveScript) return;

    const claudeDir = path.join(os.homedir(), '.claude');
    if (!fs.existsSync(claudeDir)) {
      fs.mkdirSync(claudeDir, { recursive: true });
    }
    const pidFile = path.join(claudeDir, '.theo-relay-keepalive.pid');
    const metaFile = path.join(claudeDir, '.theo-relay-keepalive.json');
    const logFile = path.join(claudeDir, '.theo-relay-keepalive.log');

    let existingPid = 0;
    if (fs.existsSync(pidFile)) {
      existingPid = Number(String(fs.readFileSync(pidFile, 'utf8')).trim() || 0);
    }
    let existingBootMtime = 0;
    if (fs.existsSync(metaFile)) {
      try {
        const meta = JSON.parse(fs.readFileSync(metaFile, 'utf8'));
        existingBootMtime = Number(meta?.bootMtime || 0);
        if (!existingPid && meta?.pid) existingPid = Number(meta.pid);
      } catch {}
    }

    if (isPidAlive(existingPid)) {
      if (existingBootMtime >= diskMaxMtime - 1500) {
        return;
      }
      try {
        process.kill(existingPid);
      } catch {}
    }

    try {
      if (fs.existsSync(logFile) && fs.statSync(logFile).size > 2 * 1024 * 1024) {
        fs.unlinkSync(logFile);
      }
    } catch {}

    const nodeInfo = resolveNodeBinaryInfo();
    const usePlainNode = Boolean(nodeInfo?.executable && !nodeInfo.electronRunAsNode);
    const spawnExe = usePlainNode ? nodeInfo.executable : process.execPath;
    const spawnEnv = usePlainNode
      ? { ...process.env }
      : { ...process.env, ELECTRON_RUN_AS_NODE: '1' };
    const child = spawn(spawnExe, [keepaliveScript], {
      cwd: workingRoot,
      detached: false,
      windowsHide: true,
      stdio: 'ignore',
      env: spawnEnv
    });
    child.unref();
    if (child.pid) {
      fs.writeFileSync(pidFile, String(child.pid), 'utf8');
      fs.writeFileSync(
        metaFile,
        JSON.stringify({
          pid: child.pid,
          startedAt: Date.now(),
          bootMtime: diskMaxMtime,
          script: keepaliveScript
        }),
        'utf8'
      );
    }
  } catch {}
}

async function activate(context) {
  const bootPhase = createActivationPhaseLogger(context);
  ensureExcelPreviewRegistered(vscode, context);
  const store = new AntigravityDataStore();
  const stateStore = new HubStateStore(context.globalState, { diskBackup: true });
  const activity = new SessionActivityTracker();
  const tabs = new SessionTabManager();

  let hub = null;
  const accountVault = new AccountVaultManager({
    onStateChange: () => {
      if (hub) {
        hub.refresh({ forceQuota: false });
      }
    }
  });

  hub = new HubProvider(context, {
    store,
    stateStore,
    activity,
    tabs,
    accountVault,
    ensureBridge: async (opts) => {
      const res = await ensureAntigravityBridgeInstalled(context, {
        forcePromptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude'),
        ...opts
      });
      hub?.setBridgeInstallReport?.(res);
      return res;
    }
  });
  accountVault.hubRef = hub;

  let remote = new TheoRemoteBridge(context, {
    vscode,
    hub,
    store,
    stateStore,
    tabs,
    accountVault
  });
  hub.remote = remote;

  context.subscriptions.push(
    vscode.commands.registerCommand('antigravityHub.openRemote', async () => {
      const st = remote.getStatus();
      const items = [
        {
          label: '$(globe) Open THEO Remote PWA (GitHub Pages + Cloud Relay)',
          description: st.pwaUrl,
          target: st.pwaUrl
        },
        {
          label: '$(broadcast) Open Local Direct Bridge (Instant SSE)',
          description: st.localUrl,
          target: st.localUrl
        },
        {
          label: '$(device-mobile) Copy LAN Mobile URL (Wi-Fi)',
          description: st.lanUrl,
          copy: st.lanUrl
        },
        {
          label: '$(cloud-upload) Force Sync Snapshot to Cloud Relay Now',
          syncNow: true
        }
      ];
      const picked = await vscode.window.showQuickPick(items, {
        placeHolder: `THEO Remote Bridge (${st.listening ? `Listening on :${st.port}` : 'Cloud Relay Ready'})`
      });
      if (!picked) {
        return;
      }
      if (picked.syncNow) {
        await remote.syncCloudRelay({ pushState: true });
        vscode.window.setStatusBarMessage('THEO Remote: Snapshot synced to Cloud Relay', 3000);
      } else if (picked.copy) {
        await vscode.env.clipboard.writeText(picked.copy);
        vscode.window.setStatusBarMessage(`Copied THEO LAN URL: ${picked.copy}`, 3000);
      } else if (picked.target) {
        await vscode.env.openExternal(vscode.Uri.parse(picked.target));
      }
    }),
    vscode.commands.registerCommand('antigravityHub.syncRemoteCloud', async () => {
      const res = await remote.syncCloudRelay({ pushState: true });
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.addAccount', async (opts = {}) => {
      let provider = opts?.provider;
      if (provider !== 'antigravity' && provider !== 'claude') {
        const picked = await vscode.window.showQuickPick(
          [
            {
              label: '$(sparkle) Google Antigravity',
              description: 'Sign in an additional Google AI account (keeps existing accounts logged in)',
              provider: 'antigravity'
            },
            {
              label: '$(hubot) Anthropic Claude Code',
              description: 'Sign in an additional Claude account (keeps existing accounts logged in)',
              provider: 'claude'
            }
          ],
          { placeHolder: 'Choose which provider account to add to THEO' }
        );
        if (!picked) return null;
        provider = picked.provider;
      }
      const label = await vscode.window.showInputBox({
        title: `Add ${provider === 'claude' ? 'Claude Code' : 'Antigravity'} Account`,
        prompt: 'Optional nickname / label (e.g., Friend, Personal, Work)',
        placeHolder: 'Optional label — press Enter to skip'
      });
      if (label === undefined) return null;
      return hub.handleMessage({
        action: 'accountAdd',
        provider,
        label,
        switchOnComplete: true
      });
    }),
    vscode.commands.registerCommand('antigravityHub.switchAccount', async () => {
      const agyList = (hub.accountsView?.antigravity || []).filter(
        (a) => a && a.available !== false && !a.signedOut
      );
      const claudeList = (hub.accountsView?.claude || []).filter(
        (a) => a && a.available !== false && !a.signedOut
      );
      const items = [
        ...agyList.map((a) => ({
          label: `${a.active ? '$(check) ' : ''}Antigravity · ${a.email || a.name}`,
          description: `${a.label ? `[${a.label}] · ` : ''}${a.plan || ''}${a.active ? ' (Active)' : ''}`,
          provider: 'antigravity',
          accountId: a.id,
          active: a.active
        })),
        ...claudeList.map((a) => ({
          label: `${a.active ? '$(check) ' : ''}Claude Code · ${a.email || a.name}`,
          description: `${a.label ? `[${a.label}] · ` : ''}${a.plan || ''}${a.active ? ' (Active)' : ''}`,
          provider: 'claude',
          accountId: a.id,
          active: a.active
        })),
        {
          label: '$(add) Add another account…',
          description: 'Keep all current accounts logged in',
          addNew: true
        }
      ];
      const picked = await vscode.window.showQuickPick(items, {
        placeHolder: 'Switch active account or add a new account'
      });
      if (!picked) return null;
      if (picked.addNew) {
        return vscode.commands.executeCommand('antigravityHub.addAccount');
      }
      if (!picked.active) {
        await hub.handleMessage({
          action: 'accountSwitch',
          provider: picked.provider,
          accountId: picked.accountId
        });
      }
      return picked;
    }),
    vscode.commands.registerCommand('antigravityHub.newSession', async (opts = {}) => {
      const res = await tabs.openNewSession({
        provider: opts?.provider === 'claude' ? 'claude' : 'antigravity'
      });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newClaudeSession', async () => {
      const res = await tabs.openNewSession({ provider: 'claude' });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newSessionBeside', async (opts = {}) => {
      const res = await tabs.openNewSession({
        provider: opts?.provider === 'claude' ? 'claude' : 'antigravity',
        beside: true
      });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.newClaudeSessionBeside', async () => {
      const res = await tabs.openNewSession({ provider: 'claude', beside: true });
      await hub.refresh();
      return res;
    }),
    vscode.commands.registerCommand('antigravityHub.refresh', async () => {
      await hub.refresh({ forceQuota: true });
    }),
    vscode.commands.registerCommand('antigravityHub.repairBridge', async () => {
      const res = await ensureAntigravityBridgeInstalled(context, {
        promptReload: true,
        forcePromptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude')
      });
      hub.setBridgeInstallReport?.(res);
      await hub.refresh();
    }),
    vscode.commands.registerCommand('antigravityHub.markThreadSeen', async (payload) => {
      const threadId = typeof payload === 'string' ? payload : payload?.id || payload?.threadId;
      const seenAt = typeof payload === 'object' ? payload?.seenAt : 0;
      if (threadId) {
        await hub.markThreadSeen(threadId, seenAt);
      }
    }),
    vscode.commands.registerCommand('antigravityHub.activityChanged', async (payload) => {
      if (payload && typeof payload === 'object') {
        activity.ingestBridgeEvent(payload);
        if (Array.isArray(payload.conversations) && payload.conversations.length > 0) {
          hub.syncOpenTabBadges();
          hub.requestRender();
        }
        const evType = String(payload.type || '');
        const isBackgroundOrBeside = Boolean(
          payload.preserveFocus || payload.beside || evType.endsWith('-bg')
        );
        const isExplicitOpenCommand =
          !isBackgroundOrBeside &&
          (evType === 'reveal' ||
            evType === 'reveal-draft' ||
            evType === 'open-thread' ||
            evType === 'open-new');
        const isTabEvent =
          isExplicitOpenCommand ||
          evType === 'tab-closed' ||
          evType === 'reveal-bg' ||
          evType === 'reveal-draft-bg' ||
          evType === 'open-thread-bg' ||
          evType === 'open-new-bg' ||
          evType === 'focus' ||
          evType === 'tab-state' ||
          evType === 'tab-resolved' ||
          evType === 'url' ||
          evType === 'claude-setup-panel' ||
          evType === 'claude-register-session';
        if (evType === 'tab-closed') {
          hub.clearPendingActiveTargetIfMatches?.({
            id: payload.threadId || '',
            key: payload.uri || ''
          });
        }
        const pendingTarget =
          typeof hub.getPendingActiveTarget === 'function' ? hub.getPendingActiveTarget() : null;
        const payloadDiffersFromPending = Boolean(
          pendingTarget &&
            ((pendingTarget.id && payload.threadId && payload.threadId !== pendingTarget.id) ||
              (pendingTarget.key && payload.uri && payload.uri !== pendingTarget.key))
        );
        const payloadMatchesOutgoing = Boolean(
          pendingTarget &&
            ((payload.threadId && pendingTarget.outgoingIds?.has?.(payload.threadId)) ||
              (payload.uri && pendingTarget.outgoingKeys?.has?.(payload.uri)))
        );
        const isPendingBounceFromOtherTab = Boolean(
          payloadDiffersFromPending &&
            (!pendingTarget.confirmedInTabs ||
              payloadMatchesOutgoing ||
              Date.now() - Number(pendingTarget.setAt || 0) < 600)
        );
        if (
          !isPendingBounceFromOtherTab &&
          !isBackgroundOrBeside &&
          payload.threadId &&
          (evType === 'focus' ||
            evType === 'reveal' ||
            evType === 'open-thread' ||
            (evType === 'tab-state' && payload.active))
        ) {
          await hub.markThreadSeen(payload.threadId);
        }
        if (isTabEvent) {
          const nextOptimisticId = isPendingBounceFromOtherTab
            ? pendingTarget.id || ''
            : isExplicitOpenCommand
              ? payload.threadId || ''
              : '';
          const nextOptimisticKey = isPendingBounceFromOtherTab
            ? pendingTarget.key || ''
            : isExplicitOpenCommand && (evType === 'reveal-draft' || evType === 'open-new')
              ? payload.uri || ''
              : '';
          await hub.refreshTabStateFast({
            optimisticActiveId: nextOptimisticId,
            optimisticActiveKey: nextOptimisticKey,
            forceOptimistic: Boolean(isPendingBounceFromOtherTab || isExplicitOpenCommand),
            scheduleFullRefreshMs: 320
          });
          return;
        }
      }
      await hub.refresh({ force: true });
    })
  );

  // Boot order (2026-10-20): nothing below blocks activate() from resolving, and nothing that the
  // sidebar needs waits for Claude Code. After a cold boot Claude Code's own activation took 102 s
  // and THEO used to `await claudeExt.activate()` before attaching the sidebar or loading any data.
  bootPhase('commands-registered');

  const autoOpenLastSession = () => {
    const autoOpen = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('autoOpenLastSessionOnStartup', true);
    if (!autoOpen) {
      return;
    }
    setTimeout(async () => {
      try {
        const pendingTabsPath = path.join(
          os.homedir(),
          '.claude',
          '.theo-pending-workspace-tabs.json'
        );
        if (fs.existsSync(pendingTabsPath)) {
          try {
            fs.unlinkSync(pendingTabsPath);
          } catch {}
        }
        const openTabs = await tabs.getOpenTabs();
        if (openTabs.length === 0) {
          const lastId = await tabs.getLastConversationId();
          const fallbackThread = hub.snapshot?.threads?.[0];
          const targetId = lastId || fallbackThread?.id || '';
          if (targetId) {
            const matched = (hub.snapshot?.threads || []).find((t) => t.id === targetId);
            await tabs.openThread(targetId, {
              provider: matched?.provider || 'antigravity',
              title: matched?.title || '',
              preserveFocus: false
            });
            await hub.refresh();
          }
        }
      } catch {}
    }, 600);
  };

  let fallbackEditorDisposable = null;
  const ensureFallbackConversationEditorIfNeeded = () => {
    if (fallbackEditorDisposable) {
      return;
    }
    const disposables = [];
    try {
      disposables.push(
        vscode.workspace.registerTextDocumentContentProvider('antigravity-session', {
          provideTextDocumentContent: () => ''
        })
      );
    } catch {}
    try {
      const iconUri = vscode.Uri.joinPath(
        context.extensionUri,
        'resources',
        'antigravity-logo-color.svg'
      );
      disposables.push(
        vscode.window.registerCustomEditorProvider(
          'antigravity.conversationEditor',
          {
            async openCustomDocument(uri) {
              return { uri, dispose() {} };
            },
            async resolveCustomEditor(document, webviewPanel) {
              const parsed = parseSessionUri(document.uri);
              const persisted = stateStore.read();
              let title = '';
              if (parsed.kind === 'thread' && parsed.threadId) {
                title =
                  persisted?.customTitles?.[parsed.threadId] ||
                  (hub?.snapshot?.threads || []).find((t) => t.id === parsed.threadId)?.title ||
                  '';
              }
              webviewPanel.title = title || 'Antigravity';
              try {
                webviewPanel.iconPath = { light: iconUri, dark: iconUri };
              } catch {}
              webviewPanel.webview.options = { enableScripts: true };
              webviewPanel.webview.onDidReceiveMessage(async (msg) => {
                if (msg && msg.type === 'reload') {
                  await vscode.commands.executeCommand('workbench.action.reloadWindow');
                }
              });
              webviewPanel.webview.html = [
                '<!doctype html><html><head><meta charset="utf-8">',
                '<style>body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:var(--vscode-editor-background,#18181b);color:var(--vscode-editor-foreground,#e4e4e7);font:13px/1.5 var(--vscode-font-family,system-ui,sans-serif)}.card{max-width:420px;padding:24px 28px;border:1px solid var(--vscode-panel-border,rgba(255,255,255,.1));border-radius:10px;text-align:center}h3{margin:0 0 8px;font-size:15px;font-weight:600}p{margin:0 0 16px;opacity:.8}button{background:var(--vscode-button-background,#2563eb);color:var(--vscode-button-foreground,#fff);border:0;border-radius:6px;padding:8px 16px;font:inherit;font-weight:500;cursor:pointer}</style>',
                '</head><body><div class="card"><h3>THEO Session Tab Preserved</h3>',
                '<p>Antigravity was updated and THEO preserved this session tab. Reload VS Code once to reconnect the live session view.</p>',
                '<button id="btn">Reload Window</button></div>',
                '<script>const v=acquireVsCodeApi();document.getElementById("btn").onclick=()=>v.postMessage({type:"reload"});</script>',
                '</body></html>'
              ].join('');
            }
          },
          {
            webviewOptions: { retainContextWhenHidden: true },
            supportsMultipleEditorsPerDocument: false
          }
        )
      );
    } catch {}
    if (disposables.length > 0) {
      fallbackEditorDisposable = vscode.Disposable.from(...disposables);
      context.subscriptions.push(fallbackEditorDisposable);
    }
  };

  const bootAntigravitySide = async () => {
    // google.google-antigravity is a declared extensionDependency, so it is already active here.
    try {
      const agyExt = vscode.extensions.getExtension('google.google-antigravity');
      if (agyExt && !agyExt.isActive) {
        await agyExt.activate();
      }
    } catch {}
    await vscode.commands.executeCommand('antigravityHub.attachSidebar', hub).then(
      () => {},
      () => {}
    );
    bootPhase('antigravity-sidebar-attached');

    await hub.refresh({ forceQuota: true });
    bootPhase('first-refresh');

    await new Promise((resolve) => {
      const creds = loadTheoCredentials();
      const bearer = creds.effectiveEdgeSecret
        ? deriveEdgeAuthToken(creds.effectiveEdgeSecret)
        : '';
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: remote.port || 4318,
          path: '/api/yield-port',
          method: 'POST',
          headers: bearer ? { Authorization: `Bearer ${bearer}` } : {},
          timeout: 800
        },
        (res) => {
          res.resume();
          res.on('end', () => setTimeout(resolve, 80));
        }
      );
      req.on('error', () => resolve());
      req.on('timeout', () => {
        try {
          req.destroy();
        } catch {}
        resolve();
      });
      req.end();
    });
    await remote.start().catch(() => {});
    ensureRelayKeepaliveDaemon(context);
    bootPhase('remote-bridge-started');

    let agyBridgeStatus = null;
    try {
      agyBridgeStatus = await vscode.commands.executeCommand('antigravityHub.bridgeStatus');
    } catch {}
    if (agyBridgeStatus?.active) {
      autoOpenLastSession();
    } else {
      ensureFallbackConversationEditorIfNeeded();
    }
  };

  const bootClaudeSide = async () => {
    const claudeSignedIn = accountVault.hasSignedInProvider('claude');
    let claudeExt = null;
    try {
      claudeExt = vscode.extensions.getExtension('anthropic.claude-code');
      if (claudeSignedIn && claudeExt && !claudeExt.isActive) {
        await claudeExt.activate();
      }
    } catch {}
    bootPhase(claudeSignedIn ? 'claude-code-active' : 'claude-code-skipped-signed-out');
    if (claudeExt?.isActive) {
      await vscode.commands.executeCommand('antigravityHub.claudeAttachSidebar', hub).then(
        () => {},
        () => {}
      );
      bootPhase('claude-sidebar-attached');
      let claudeStatus = null;
      try {
        claudeStatus = await vscode.commands.executeCommand('antigravityHub.claudeBridgeStatus');
      } catch {}
      if (!claudeStatus?.active && claudeSignedIn) {
        const autoMaintain = vscode.workspace
          .getConfiguration('antigravityHub')
          .get('autoMaintainBridge', true);
        if (autoMaintain) {
          try {
            const res = await ensureAntigravityBridgeInstalled(context, {
              promptReload: true,
              claudeSignedIn
            });
            hub.setBridgeInstallReport?.(res);
          } catch {}
        }
      }
    }
    hub.refresh({ forceQuota: false });
  };

  const bootBridgeMaintenance = async (claudeBoot) => {
    const autoMaintain = vscode.workspace
      .getConfiguration('antigravityHub')
      .get('autoMaintainBridge', true);
    if (!autoMaintain) {
      return;
    }
    // Give Claude Code up to 2.5s to finish fast activation; if it takes longer, bridge.js inspects
    // claudeExt.isActive so a still-activating extension never causes a false reload toast, and
    // bootClaudeSide re-verifies once claudeExt.activate() resolves.
    await Promise.race([claudeBoot, new Promise((r) => setTimeout(r, 2500))]);
    try {
      const res = await ensureAntigravityBridgeInstalled(context, {
        promptReload: true,
        claudeSignedIn: accountVault.hasSignedInProvider('claude')
      });
      hub.setBridgeInstallReport?.(res);
    } catch {}
    bootPhase('bridge-maintained');
  };

  const claudeBoot = bootClaudeSide().catch(() => {});
  bootAntigravitySide()
    .catch(() => {})
    .then(() => bootBridgeMaintenance(claudeBoot))
    .catch(() => {})
    .then(() => bootPhase('boot-complete'));

  // Keep open/active tab state synced when editor tabs change without triggering a full snapshot storm
  if (vscode.window.tabGroups) {
    context.subscriptions.push(
      vscode.window.tabGroups.onDidChangeTabs(async () => {
        await hub.refreshTabStateFast({ scheduleFullRefreshMs: 320 });
      }),
      vscode.window.tabGroups.onDidChangeTabGroups(async () => {
        await hub.refreshTabStateFast({ scheduleFullRefreshMs: 320 });
      })
    );
  }

  context.subscriptions.push(
    vscode.window.onDidChangeWindowState(async (winState) => {
      if (winState?.focused) noteLocalUserActivity();
      await hub.refreshTabStateFast({ scheduleFullRefreshMs: 320 });
    }),
    vscode.window.onDidChangeTextEditorSelection(() => {
      noteLocalUserActivity();
    }),
    vscode.workspace.onDidChangeTextDocument((ev) => {
      if (ev?.contentChanges?.length > 0) noteLocalUserActivity();
    }),
    vscode.window.onDidChangeActiveTerminal(() => {
      noteLocalUserActivity();
    })
  );

  let hotSwapInFlight = false;
  async function maybeHotSwapRemoteBridge() {
    if (hotSwapInFlight) return;
    try {
      const extRoot = context?.extensionPath || __dirname;
      const repoRoot = path.join(os.homedir(), 'bhfirms', 'theo-hub');
      const watchedFiles = [
        'remote.js',
        'bridge.js',
        'data.js',
        'state.js',
        'store.js',
        'accounts.js',
        'hub.js',
        'activity.js',
        'session-tabs.js',
        'desktop-notify.js',
        'desktop-launcher.js',
        'device-identity.js',
        'bundle-updater.js',
        'ws-server.js',
        'direct-runner.js',
        'edge-relay-client.js',
        path.join('compat', 'antigravity-hub-bridge.cjs'),
        path.join('compat', 'antigravity-context-window.cjs'),
        path.join('compat', 'antigravity-tab-state.cjs'),
        path.join('compat', 'claude-hub-bridge.cjs'),
        path.join('compat', 'claude-webview-patches.cjs'),
        path.join('compat', 'excel-preview.cjs'),
        path.join('resources', 'theo.ico'),
        path.join('resources', 'TheoLauncher.cs'),
        path.join('resources', 'hub.js'),
        path.join('resources', 'hub.css'),
        path.join('resources', 'hub.html')
      ];

      // If ~/bhfirms/theo-hub/* was edited on disk and differs from the installed copy, sync it automatically
      let maxMtime = 0;
      for (const relFile of watchedFiles) {
        const srcFile = path.join(repoRoot, relFile);
        const dstFile = path.join(extRoot, relFile);
        if (
          fs.existsSync(srcFile) &&
          path.resolve(srcFile) !== path.resolve(dstFile) &&
          getFileMtimeMs(srcFile) > getFileMtimeMs(dstFile) + 500
        ) {
          try {
            const srcBuf = fs.readFileSync(srcFile);
            const dstBuf = fs.existsSync(dstFile) ? fs.readFileSync(dstFile) : null;
            if (!dstBuf || !srcBuf.equals(dstBuf)) {
              fs.mkdirSync(path.dirname(dstFile), { recursive: true });
              fs.writeFileSync(dstFile, srcBuf);
            }
          } catch {}
        }
        const m = Math.max(getFileMtimeMs(dstFile), getFileMtimeMs(srcFile));
        if (m > maxMtime) maxMtime = m;
      }

      const loadedMtime = Number(remote?.codeMtime || 0);
      if (maxMtime > 0 && (loadedMtime === 0 || maxMtime > loadedMtime + 500)) {
        hotSwapInFlight = true;
        try {
          remote.dispose();
        } catch {}
        await new Promise((r) => setTimeout(r, 150));
        for (const modName of [
          './data',
          './remote',
          './state',
          './store',
          './accounts',
          './activity',
          './session-tabs',
          './desktop-notify',
          './desktop-launcher',
          './device-identity',
          './bundle-updater',
          './ws-server',
          './direct-runner',
          './edge-relay-client',
          './hub',
          './compat/antigravity-hub-bridge.cjs',
          './compat/antigravity-context-window.cjs',
          './compat/antigravity-tab-state.cjs',
          './compat/claude-hub-bridge.cjs',
          './compat/claude-webview-patches.cjs',
          './compat/excel-preview.cjs',
          './bridge'
        ]) {
          try {
            const resolvedMod = require.resolve(modName);
            delete require.cache[resolvedMod];
          } catch {}
        }
        try {
          const { HubStateStore: FreshStateStore } = require('./state');
          const { AntigravityDataStore: FreshStore } = require('./store');
          const {
            AccountVaultManager: FreshVault,
            defaultHttpsJsonRequest: freshHttpsJsonRequest
          } = require('./accounts');
          const { SessionActivityTracker: FreshActivity } = require('./activity');
          const { SessionTabManager: FreshTabs } = require('./session-tabs');
          const { HubProvider: FreshHub } = require('./hub');
          if (stateStore && FreshStateStore?.prototype) {
            Object.setPrototypeOf(stateStore, FreshStateStore.prototype);
          }
          Object.setPrototypeOf(store, FreshStore.prototype);
          store.cachedSqliteMtimeMs = 0;
          store.cachedClaudeVscMtimeMs = 0;
          if (
            FreshStore?.PARSE_CACHE_VERSION &&
            Number(store.parseCacheVersion || 0) !== Number(FreshStore.PARSE_CACHE_VERSION)
          ) {
            store.transcriptCache?.clear?.();
            store.claudeSessionCache?.clear?.();
            store.parseCacheVersion = Number(FreshStore.PARSE_CACHE_VERSION);
            store.readPersistedParseCache?.();
          }
          if (accountVault) {
            Object.setPrototypeOf(accountVault, FreshVault.prototype);
            if (!accountVault.hasCustomHttpsJsonRequest && freshHttpsJsonRequest) {
              accountVault.httpsJsonRequest = freshHttpsJsonRequest;
            }
            accountVault.agyQuotaInFlightById?.clear?.();
            accountVault.claudeQuotaInFlightById?.clear?.();
          }
          if (tabs) {
            Object.setPrototypeOf(tabs, FreshTabs.prototype);
          }
          if (hub?.activity) {
            Object.setPrototypeOf(hub.activity, FreshActivity.prototype);
          }
          if (hub) {
            Object.setPrototypeOf(hub, FreshHub.prototype);
            hub.accountVault = accountVault;
            if (
              hub.refreshInFlight &&
              (!hub.refreshStartedAt || Date.now() - Number(hub.refreshStartedAt || 0) > 10000)
            ) {
              hub.refreshInFlight = null;
            }
            hub.reloadAllWebviews?.();
          }
          try {
            const freshBridgeInstaller = require('./bridge');
            if (typeof freshBridgeInstaller?.ensureAntigravityBridgeInstalled === 'function') {
              ensureAntigravityBridgeInstalled = freshBridgeInstaller.ensureAntigravityBridgeInstalled;
            }
            if (typeof freshBridgeInstaller?.prepatchInstalledExtensions === 'function') {
              prepatchInstalledExtensions = freshBridgeInstaller.prepatchInstalledExtensions;
            }
            freshBridgeInstaller?.prepatchInstalledExtensions?.(extRoot);
          } catch {}
          try {
            const freshClaudeBridge = require('./compat/claude-hub-bridge.cjs');
            freshClaudeBridge?.hotUpgradeLiveState?.();
          } catch {}
          try {
            const freshAgyBridge = require('./compat/antigravity-hub-bridge.cjs');
            freshAgyBridge?.hotUpgradeLiveState?.(freshAgyBridge.getBridgeState(), vscode, hub);
          } catch {}
          if (
            process.platform === 'win32' &&
            process.env.THEO_SMOKE_TEST !== '1' &&
            process.env.THEO_HEADLESS_TEST !== '1'
          ) {
            try {
              const csMtime = getFileMtimeMs(path.join(extRoot, 'resources', 'TheoLauncher.cs'));
              const exeMtime = getFileMtimeMs(path.join(os.homedir(), '.theo', 'THEO.exe'));
              if (csMtime > 0 && csMtime > exeMtime) {
                const launcherMod = require('./desktop-launcher');
                const ico = launcherMod.ensureStableDesktopIcon({ hubRoot: extRoot, homeDir: os.homedir() });
                launcherMod.ensureNativeLauncherExecutable({
                  hubRoot: extRoot,
                  homeDir: os.homedir(),
                  iconPath: ico.iconPath,
                  force: true
                });
              }
            } catch {}
          }
        } catch {}
        const { TheoRemoteBridge: FreshRemoteBridge } = require('./remote');
        remote = new FreshRemoteBridge(context, {
          vscode,
          hub,
          store,
          stateStore,
          tabs,
          accountVault
        });
        remote.codeMtime = Math.max(maxMtime, Number(remote.codeMtime || 0), Date.now());
        hub.remote = remote;
        await new Promise((resolve) => {
      const creds = loadTheoCredentials();
      const bearer = creds.effectiveEdgeSecret
        ? deriveEdgeAuthToken(creds.effectiveEdgeSecret)
        : '';
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port: remote.port || 4318,
          path: '/api/yield-port',
          method: 'POST',
          headers: bearer ? { Authorization: `Bearer ${bearer}` } : {},
          timeout: 800
        },
        (res) => {
          res.resume();
          res.on('end', () => setTimeout(resolve, 80));
        }
      );
      req.on('error', () => resolve());
      req.on('timeout', () => {
        try {
          req.destroy();
        } catch {}
        resolve();
      });
      req.end();
    });
    await remote.start().catch(() => {});
        ensureRelayKeepaliveDaemon(context);
      }
    } catch {} finally {
      hotSwapInFlight = false;
    }
  }

  let tickCount = 0;
  const pollTimer = setInterval(() => {
    tickCount += 1;
    maybeHotSwapRemoteBridge().catch(() => {});
    if (tickCount % 3 === 0) {
      try {
        prepatchInstalledExtensions(context?.extensionPath || __dirname);
      } catch {}
    }
    if (tickCount % 10 === 0) {
      ensureRelayKeepaliveDaemon(context);
    }
    if (
      hub.visible ||
      vscode.window.state.focused ||
      remote.sseClients.size > 0 ||
      tickCount % 3 === 0
    ) {
      hub.refresh({ forceQuota: false });
    }
  }, 6000);

  context.subscriptions.push({
    dispose() {
      clearInterval(pollTimer);
      stateStore?.flushDiskBackupSync?.();
      remote.dispose();
      hub.dispose();
    }
  });
}

function deactivate() {}

module.exports = {
  activate,
  deactivate
};
