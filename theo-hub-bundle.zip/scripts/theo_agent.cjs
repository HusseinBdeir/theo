'use strict';
// THEO Agent Standalone Host Daemon entrypoint (VS Code-free multi-device host + Edge WebSocket Relay + Direct CLI Streamer)
require('./relay_keepalive.cjs');
