# Starts scripts/relay_keepalive.cjs hidden in the background (idempotent + auto-restarts on code update)
# outside any terminal/VS Code Job Object via WMI Win32_Process.Create (ShowWindow=0), and registers
# the permanent Windows Logon/5m Scheduled Task (THEO-Relay-Keepalive) + Startup VBS launcher.
# Log: ~/.claude/.theo-relay-keepalive.log   Pid: ~/.claude/.theo-relay-keepalive.pid
param(
  [switch]$Restart,
  [switch]$SkipTaskCheck
)

$repo = Split-Path -Parent $PSScriptRoot
$script = Join-Path $repo 'scripts\relay_keepalive.cjs'
$logDir = Join-Path $env:USERPROFILE '.claude'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$log = Join-Path $logDir '.theo-relay-keepalive.log'
$pidFile = Join-Path $logDir '.theo-relay-keepalive.pid'
$metaFile = Join-Path $logDir '.theo-relay-keepalive.json'
$vbsPath = Join-Path $logDir 'theo-relay-keepalive.vbs'

# 1. Ensure silent VBS wrapper + Windows Startup link + Scheduled Task exist
if (-not $SkipTaskCheck) {
  $ps1Path = Join-Path $repo 'scripts\relay_keepalive_start.ps1'
  $vbsLines = @(
    'Set WshShell = CreateObject("WScript.Shell")',
    "WshShell.Run ""powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File """"$ps1Path"""" -SkipTaskCheck"", 0, False"
  )
  $vbsContent = $vbsLines -join "`r`n"
  Set-Content -Path $vbsPath -Value $vbsContent -Encoding ASCII -Force

  $startupDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'
  if (Test-Path $startupDir) {
    $startupVbs = Join-Path $startupDir 'THEO-Relay-Keepalive.vbs'
    Set-Content -Path $startupVbs -Value $vbsContent -Encoding ASCII -Force
  }

  $taskName = 'THEO-Relay-Keepalive'
  $existingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if (-not $existingTask) {
    try {
      $action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument "`"$vbsPath`"" -WorkingDirectory $repo
      $trigLogon = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
      $trigRepeat = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval (New-TimeSpan -Minutes 5)
      $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
      Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($trigLogon, $trigRepeat) -Settings $settings -Description 'Permanent background watchdog for THEO Remote Cloud Relay sync' -Force | Out-Null
    } catch {}
  }

  $desktopShortcutPs1 = Join-Path $repo 'scripts\install_desktop_shortcut.ps1'
  if (Test-Path $desktopShortcutPs1) {
    try {
      & $desktopShortcutPs1 -Quiet | Out-Null
    } catch {}
  }

  $blindspotPs1 = Join-Path $env:USERPROFILE 'bhfirms\memory\Admin\Register-THEO-Blindspot-Review.ps1'
  if (Test-Path $blindspotPs1) {
    $bsTask = Get-ScheduledTask -TaskName 'THEO-Blindspot-Review' -ErrorAction SilentlyContinue
    $has24h = $false
    if ($bsTask) {
      foreach ($trig in @($bsTask.Triggers)) {
        if ($trig.Repetition -and $trig.Repetition.Interval -eq 'PT2H' -and ($trig.Repetition.Duration -eq 'P1D' -or $trig.Repetition.Duration -eq 'PT24H')) {
          $has24h = $true
        }
      }
    }
    if (-not $bsTask -or @($bsTask.Triggers).Count -lt 2 -or -not $has24h) {
      try {
        $null = & $blindspotPs1 2>$null
      } catch {}
    }
  }
}

# 2. Compute latest disk mtime across relay_keepalive.cjs, remote.js, store.js, data.js, and v3 modules
$watchFiles = @(
  $script,
  (Join-Path $repo 'remote.js'),
  (Join-Path $repo 'store.js'),
  (Join-Path $repo 'data.js'),
  (Join-Path $repo 'desktop-launcher.js'),
  (Join-Path $repo 'device-identity.js'),
  (Join-Path $repo 'bundle-updater.js'),
  (Join-Path $repo 'ws-server.js'),
  (Join-Path $repo 'direct-runner.js'),
  (Join-Path $repo 'edge-relay-client.js'),
  (Join-Path $repo 'pc-setup.js'),
  (Join-Path $repo 'scripts\memory_cloud_sync.cjs')
)
$diskMaxMs = [int64]0
foreach ($wf in $watchFiles) {
  if (Test-Path $wf) {
    $ms = [int64]([DateTimeOffset](Get-Item $wf).LastWriteTimeUtc).ToUnixTimeMilliseconds()
    if ($ms -gt $diskMaxMs) { $diskMaxMs = $ms }
  }
}

$bootMtime = [int64]0
if (Test-Path $metaFile) {
  try {
    $metaObj = Get-Content $metaFile -Raw | ConvertFrom-Json
    if ($metaObj.bootMtime) { $bootMtime = [int64]$metaObj.bootMtime }
  } catch {}
}

$running = @(Get-CimInstance Win32_Process -Filter "Name='node.exe' OR Name='Code.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'relay_keepalive\.cjs' })
$needsRestart = $Restart -or ($bootMtime -lt ($diskMaxMs - 1500)) -or ($running.Count -gt 1)

if ($running.Count -gt 0) {
  if (-not $needsRestart) {
    $keepPid = $running[0].ProcessId
    $keepPid | Set-Content $pidFile
    Write-Host "relay_keepalive already running and up-to-date (pid $keepPid)"
    exit 0
  }
  foreach ($proc in $running) {
    Stop-Process -Id $proc.ProcessId -Force -ErrorAction SilentlyContinue
  }
  Start-Sleep -Milliseconds 150
}

# 3. Spawn via WMI Win32_Process.Create (ShowWindow=0) so the daemon lives under WmiPrvSE.exe,
# completely outside any terminal / VS Code / agent Job Object (never killed when terminal closes).
$nodeCandidates = @(
  (Join-Path $env:USERPROFILE '.local\node\node.exe'),
  ((Get-Command node -ErrorAction SilentlyContinue).Source),
  'C:\Program Files\nodejs\node.exe',
  (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
)
$nodeExe = ''
foreach ($cand in $nodeCandidates) {
  if ($cand -and (Test-Path $cand)) {
    $nodeExe = $cand
    break
  }
}

$cmdLine = ''
if ($nodeExe) {
  $cmdLine = "`"$nodeExe`" `"$script`" --restart"
} else {
  $codeExe = Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\Code.exe'
  if (-not (Test-Path $codeExe)) { $codeExe = 'C:\Program Files\Microsoft VS Code\Code.exe' }
  $cmdLine = "cmd.exe /c `"set ELECTRON_RUN_AS_NODE=1&& `"$codeExe`" `"$script`" --restart`""
}

$si = New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{ ShowWindow = [uint16]0 }
$wmiRes = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
  CommandLine = $cmdLine
  CurrentDirectory = $repo
  ProcessStartupInformation = $si
}

if ($wmiRes -and $wmiRes.ReturnValue -eq 0 -and $wmiRes.ProcessId) {
  $newPid = $wmiRes.ProcessId
  $newPid | Set-Content $pidFile
  Write-Host "theo-agent / relay_keepalive started (pid $newPid), log: $log"
  exit 0
}

# Fallback if WMI unavailable
$wsh = New-Object -ComObject WScript.Shell
$null = $wsh.Run($cmdLine, 0, $false)
Write-Host "theo-agent / relay_keepalive fallback launch triggered, log: $log"
