const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const https = require('https');
const net = require('net');
const os = require('os');
const path = require('path');
const { spawn, execFile } = require('child_process');
const {
  TheoRemoteBridge,
  formatModelDisplayName,
  formatSessionRowModelDisplayName,
  inferMaxContextTokens,
  inferSoftAndHardContextLimits,
  buildCompactModelCatalogForClient,
  buildClaudeModelCatalogForClient,
  sanitizeHotSwapHoldForRemote,
  sanitizeAutoReloadForRemote,
  sanitizeBridgeHealthForRemote,
  sanitizePendingLoginForRemote,
  buildPublicHostHealthSummary
} = require('../remote');
const { AntigravityDataStore } = require('../store');
const { HubStateStore } = require('../state');
const { SessionActivityTracker } = require('../activity');
const { AccountVaultManager } = require('../accounts');
const {
  prepatchInstalledExtensions,
  prepatchInstalledExtensionsAsync,
  isBridgePatchWorkerBusy,
  describePatchSkip,
  describePatchSkipNotice,
  readAgyUiPatchHealth,
  buildAgyUiSkipReport
} = require('../bridge');
const { readCanaryFailure } = require('../auto-reload');
const {
  checkAndResumeInterruptedCascades,
  findActiveCascadesFromDiskTranscripts,
  readPersistentHubState,
  writePersistentHubState,
  ensureExpectedAntigravityKeyringSync,
  ensureAntigravityTelemetryDisabled,
  ensureAntigravityDefaultModelGuard
} = require('../compat/antigravity-hub-bridge.cjs');
const {
  loadTheoCredentials,
  deriveEdgeAuthToken,
  inferRowOwnerDevice,
  resolveRowPinState,
  resolveAgyBinaryPath
} = require('../device-identity');
const { checkPcSetupStatus, readCachedPcSetupSummary } = require('../pc-setup');
const {
  readUnsavedWorkSummary,
  readFleetUnsavedWorkSummary,
  refreshUnsavedWork,
  refreshReleaseLineRadar,
  readRawReleaseLineAlert,
  readReleaseLineAlertView,
  sanitizeReleaseLineAlertForRemote
} = require('../unsaved-work');
const { readHotSwapHoldStatus } = require('../bundle-updater');
const {
  isClaudeDesktopScratchPath,
  isNeonModelLabel,
  projectSessionRows,
  collectAutoArchiveCandidates
} = require('../data');

const REPO_ROOT = path.resolve(__dirname, '..');
const CLAUDE_DIR = path.join(os.homedir(), '.claude');
const PID_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.pid');
const META_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.json');
const LOG_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.log');
const LAST_STATE_CACHE_FILE = path.join(CLAUDE_DIR, '.theo-last-state.json');
const HUB_STATE_FILE = path.join(CLAUDE_DIR, '.theo-hub-state.json');

const STEP_ID_RE = /^[a-z0-9][a-z0-9_-]{0,63}$/;
const DEFAULT_SESSION_APPLY_STEP_IDS = Object.freeze([
  'antigravity-config',
  'claude-guard',
  'claude-project-memory',
  'git-identity',
  'memory-cloud',
  'blindspot-review',
  'pc-setup-shortcut',
  'artifacts-git',
  'cashflow-morning-check',
  'claude-engine',
  'git-faststart',
  'retire-antigravity-hub'
]);

function resolveSessionApplyStepIds(memoryRoot) {
  if (!memoryRoot) return [...DEFAULT_SESSION_APPLY_STEP_IDS];
  const adminDir = path.join(memoryRoot, 'Admin');
  const manifestPath = path.join(adminDir, 'pc-setup-manifest.json');
  if (!fs.existsSync(manifestPath)) return [...DEFAULT_SESSION_APPLY_STEP_IDS];
  const ids = [];
  const seen = new Set();
  const collect = (rawStep) => {
    if (!rawStep || typeof rawStep !== 'object') return;
    const id = String(rawStep.id || '').trim();
    if (!STEP_ID_RE.test(id) || seen.has(id)) return;
    if (rawStep.sessionApply === true && !rawStep.requiresUserTerminal) {
      seen.add(id);
      ids.push(id);
    }
  };
  try {
    const man = JSON.parse(fs.readFileSync(manifestPath, 'utf8').replace(/^\uFEFF/, ''));
    for (const s of Array.isArray(man?.steps) ? man.steps : []) collect(s);
  } catch {}
  try {
    const dropDir = path.join(adminDir, 'pc-setup.d');
    if (fs.existsSync(dropDir)) {
      const files = fs
        .readdirSync(dropDir)
        .filter((f) => f.toLowerCase().endsWith('.json'))
        .sort();
      for (const f of files) {
        try {
          const dj = JSON.parse(fs.readFileSync(path.join(dropDir, f), 'utf8').replace(/^\uFEFF/, ''));
          const items = Array.isArray(dj?.steps) ? dj.steps : dj?.id ? [dj] : [];
          for (const s of items) collect(s);
        } catch {}
      }
    }
  } catch {}
  return ids.length > 0 ? ids : [...DEFAULT_SESSION_APPLY_STEP_IDS];
}

function resolveTheoMemoryPaths(opts = {}) {
  const env = opts.env || process.env;
  const sandboxHome = String(env.THEO_GUARD_HOME || env.THEO_SETUP_HOME || '').trim();
  const sandboxed = Boolean(opts.sandboxed || sandboxHome);
  const homeDir = opts.homeDir || sandboxHome || os.homedir();
  const overrideRoot = String(opts.memoryRoot || env.THEO_MEMORY_ROOT || '').trim();
  let memoryRoot = '';
  if (overrideRoot) {
    if (fs.existsSync(path.join(overrideRoot, 'THEO.md'))) {
      memoryRoot = overrideRoot;
    }
  } else {
    // THEO memory lives only at ~/bhfirms/memory (moved off OneDrive 2026-11-11).
    const bhfMem = path.join(homeDir, 'bhfirms', 'memory');
    if (fs.existsSync(path.join(bhfMem, 'THEO.md'))) {
      memoryRoot = bhfMem;
    }
  }
  return { homeDir, memoryRoot, sandboxed };
}

function collectPythonCandidateDirs(homeDir) {
  const dirsOut = [path.join(homeDir, '.local', 'python312')];
  if (process.platform === 'win32') {
    dirsOut.push('C:\\Python314', 'C:\\Python313', 'C:\\Python312');
    const programRoots = [];
    if (process.env.LOCALAPPDATA) {
      programRoots.push(path.join(process.env.LOCALAPPDATA, 'Programs', 'Python'));
    }
    if (process.env.ProgramFiles) programRoots.push(process.env.ProgramFiles);
    if (process.env['ProgramFiles(x86)']) programRoots.push(process.env['ProgramFiles(x86)']);
    for (const rootDir of programRoots) {
      try {
        if (fs.existsSync(rootDir)) {
          const subs = fs
            .readdirSync(rootDir, { withFileTypes: true })
            .filter((e) => e.isDirectory() && /^Python3/i.test(e.name))
            .map((e) => e.name)
            .sort()
            .reverse();
          for (const sub of subs) {
            dirsOut.push(path.join(rootDir, sub));
          }
        }
      } catch {}
    }
  }
  for (const pathEntry of String(process.env.PATH || '').split(path.delimiter)) {
    const cleanDir = pathEntry.trim();
    if (!cleanDir || /windowsapps/i.test(cleanDir)) continue;
    dirsOut.push(cleanDir);
  }
  return dirsOut;
}

function findLocalPythonExe(homeDir = os.homedir()) {
  const names =
    process.platform === 'win32' ? ['pythonw.exe', 'python.exe'] : ['python3', 'python'];
  for (const dir of collectPythonCandidateDirs(homeDir)) {
    for (const name of names) {
      const exe = path.join(dir, name);
      try {
        if (!/windowsapps/i.test(exe) && fs.existsSync(exe)) return exe;
      } catch {}
    }
  }
  return '';
}

function findLocalConsolePythonExe(homeDir = os.homedir()) {
  const names =
    process.platform === 'win32' ? ['python.exe', 'pythonw.exe'] : ['python3', 'python'];
  for (const dir of collectPythonCandidateDirs(homeDir)) {
    for (const name of names) {
      const exe = path.join(dir, name);
      try {
        if (!/windowsapps/i.test(exe) && fs.existsSync(exe)) return exe;
      } catch {}
    }
  }
  return '';
}

function getFileMtimeMs(filePath) {
  try {
    return Math.floor(fs.statSync(filePath).mtimeMs);
  } catch {
    return 0;
  }
}

function computeDiskMaxMtime() {
  return Math.max(
    getFileMtimeMs(__filename),
    getFileMtimeMs(path.join(__dirname, 'memory_cloud_sync.cjs')),
    getFileMtimeMs(path.join(REPO_ROOT, 'compat', 'antigravity-hub-bridge.cjs')),
    getFileMtimeMs(path.join(REPO_ROOT, 'compat', 'antigravity-context-window.cjs')),
    getFileMtimeMs(path.join(REPO_ROOT, 'remote.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'state.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'store.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'accounts.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'data.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'bridge.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'desktop-launcher.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'device-identity.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'pc-setup.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'unsaved-work.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'bundle-updater.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'ws-server.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'direct-runner.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'edge-relay-client.js'))
  );
}

function isPidAlive(pid) {
  const n = Number(pid || 0);
  if (!n || n <= 0 || n === process.pid) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch (err) {
    return err && err.code === 'EPERM';
  }
}

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try {
    if (!fs.existsSync(CLAUDE_DIR)) {
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    }
    if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 2 * 1024 * 1024) {
      fs.unlinkSync(LOG_FILE);
    }
    fs.appendFileSync(LOG_FILE, line, 'utf8');
  } catch {}
  if (process.argv.includes('--once')) {
    process.stderr.write(line);
  }
}

function httpJson(url, options = {}) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const isLocal =
      parsed.hostname === 'localhost' ||
      parsed.hostname === '127.0.0.1' ||
      parsed.hostname === '::1';
    const targetHost = parsed.hostname === 'localhost' ? '127.0.0.1' : parsed.hostname;
    let bearer = '';
    if (isLocal) {
      const creds = loadTheoCredentials();
      if (creds.effectiveEdgeSecret) {
        bearer = deriveEdgeAuthToken(creds.effectiveEdgeSecret);
      }
    }
    const bodyText = options.body ? String(options.body) : '';
    const req = http.request(
      {
        protocol: parsed.protocol,
        hostname: targetHost,
        port: parsed.port || 4318,
        path: `${parsed.pathname}${parsed.search}`,
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}),
          ...(bodyText ? { 'Content-Length': Buffer.byteLength(bodyText) } : {})
        },
        timeout: options.timeoutMs || 5000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          try {
            resolve(raw ? JSON.parse(raw) : {});
          } catch {
            resolve({ raw });
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error('Local bridge timeout')));
    req.on('error', reject);
    if (bodyText) req.write(bodyText);
    req.end();
  });
}

function fetchCloudMetaAgeMs(relayConfig) {
  return new Promise((resolve) => {
    let parsed;
    try {
      parsed = new URL(relayConfig.url);
    } catch {
      resolve(Infinity);
      return;
    }
    const body = JSON.stringify({ key: relayConfig.key, op: 'get_control' });
    const req = https.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: parsed.pathname + parsed.search,
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=UTF-8',
          'Content-Length': Buffer.byteLength(body)
        },
        timeout: 15000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          try {
            const j = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            const docs = j?.docs && typeof j.docs === 'object' ? j.docs : j || {};
            const stamp = Date.parse(docs?.meta?.updatedAt || '') || 0;
            resolve(stamp ? Date.now() - stamp : Infinity);
          } catch {
            resolve(Infinity);
          }
        });
      }
    );
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(Infinity));
    req.write(body);
    req.end();
  });
}

function readJsonSafe(filePath, fallback = {}) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
  } catch {}
  return fallback;
}

// ---- Antigravity engine without VS Code ----
// Live Antigravity sessions run inside one long-lived `agy --hub` process. Until now only the Antigravity
// extension inside VS Code started it, so after a restart of the PC nothing ran until VS Code was opened and
// sessions fell back to the command-line tool. The service starts it itself when it is the one serving the
// phone, no VS Code is running, and no engine exists. It never stops or replaces an engine: one that is busy
// answers slowly, and killing it would cut running sessions. A VS Code opened later finds the saved address
// in bhf-persistent-hub.json and reuses this engine. Launch line and environment follow the extension's own.
const AGY_ENGINE_RETRY_MS = 5 * 60 * 1000;
const AGY_ENGINE_BACKOFF_MS = 60 * 60 * 1000;
const AGY_ENGINE_READY_MS = 25000;
const agyEngineState = { inFlight: false, lastAttemptAt: 0, lastAliveAt: 0, failures: 0 };

function getFreeLoopbackPort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const addr = srv.address();
      const port = addr && typeof addr === 'object' ? addr.port : 0;
      srv.close(() => (port ? resolve(port) : reject(new Error('no free loopback port'))));
    });
  });
}

// True only when nothing listens on the port (connection refused). A timeout or any other outcome is false.
function isLoopbackPortRefused(port) {
  const n = Number(port || 0);
  if (!Number.isInteger(n) || n <= 0 || n > 65535) return Promise.resolve(true);
  return new Promise((resolve) => {
    let done = false;
    const finish = (val) => {
      if (done) return;
      done = true;
      try {
        sock.destroy();
      } catch {}
      resolve(val);
    };
    const sock = net.connect({ host: '127.0.0.1', port: n });
    sock.setTimeout(2000, () => finish(false));
    sock.once('connect', () => finish(false));
    sock.once('error', (err) => finish(Boolean(err && err.code === 'ECONNREFUSED')));
  });
}

// { hubPids: number[], vscodeRunning: boolean }, or null when the process list could not be read.
function inspectEngineProcesses() {
  if (process.platform !== 'win32') {
    return Promise.resolve({ hubPids: [], vscodeRunning: false });
  }
  const script =
    "$h = @(Get-CimInstance Win32_Process -Filter \"Name='agy.exe'\" | Where-Object { $_.CommandLine -like '*--hub*' -and $_.CommandLine -notlike '*antigravity-auth-staging*' } | ForEach-Object { $_.ProcessId }); " +
    "$c = @(Get-Process -Name 'Code','Code - Insiders','VSCodium' -ErrorAction SilentlyContinue).Count; " +
    'Write-Output ("THEO_ENGINE|" + ($h -join ",") + "|" + $c)';
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', script],
      { timeout: 15000, windowsHide: true },
      (err, stdout) => {
        const m = /THEO_ENGINE\|([\d,]*)\|(\d+)/.exec(String(stdout || ''));
        if (err || !m) {
          resolve(null);
          return;
        }
        resolve({
          hubPids: m[1]
            .split(',')
            .map((x) => Number(x))
            .filter((x) => Number.isInteger(x) && x > 0),
          vscodeRunning: Number(m[2]) > 0
        });
      }
    );
  });
}

// On Windows, Node puts every child it starts (unless detached) into one job object that ends its members
// when Node exits. The engine must outlive this service (it restarts on every update), and it cannot be
// started detached (it would lose its hidden console, theo-extension.md § 3.2). So the engine alone is
// started one step removed: a short-lived Python helper, itself a member of the job, creates the engine
// process, and a process created by a job member is not in that job. The job keeps ending everything
// else this service starts (headless runs, sign-in helpers), exactly as before.
// Resolves { ok, pid } or { ok: false, reason }.
function launchEngineOutsideJob(spec, deps = {}) {
  const pyExe = (deps.findPython || findLocalConsolePythonExe)();
  if (!pyExe) return Promise.resolve({ ok: false, reason: 'no_python' });
  const pyCode = [
    'import json, subprocess, sys',
    // Node writes UTF-8; read the bytes and decode them as that, whatever the PC's own code page is.
    'cfg = json.loads(sys.stdin.buffer.read().decode("utf-8"))',
    'log = open(cfg["log"], "ab") if cfg.get("log") else subprocess.DEVNULL',
    // 0x08000000 = CREATE_NO_WINDOW: the engine gets a console with no window, as under VS Code.
    'flags = 0x08000000 if sys.platform == "win32" else 0',
    'p = subprocess.Popen([cfg["bin"]] + cfg["args"], cwd=cfg["cwd"], env=cfg["env"], stdin=subprocess.DEVNULL, stdout=log, stderr=log, creationflags=flags, close_fds=True)',
    'print("THEO_ENGINE_PID=%d" % p.pid)'
  ].join('\n');
  return new Promise((resolve) => {
    let out = '';
    let done = false;
    const finish = (res) => {
      if (done) return;
      done = true;
      resolve(res);
    };
    let helper = null;
    try {
      helper = (deps.spawn || spawn)(pyExe, ['-c', pyCode], {
        detached: false,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'ignore']
      });
    } catch (err) {
      finish({ ok: false, reason: 'launcher_failed', error: err?.message || String(err) });
      return;
    }
    const timer = setTimeout(() => {
      try {
        helper.kill();
      } catch {}
      finish({ ok: false, reason: 'launcher_timeout' });
    }, 20000);
    helper.stdout?.on('data', (d) => {
      out += String(d);
    });
    helper.on('error', (err) => {
      clearTimeout(timer);
      finish({ ok: false, reason: 'launcher_failed', error: err?.message || String(err) });
    });
    helper.on('close', () => {
      clearTimeout(timer);
      const m = /THEO_ENGINE_PID=(\d+)/.exec(out);
      const pid = m ? Number(m[1]) : 0;
      finish(pid > 0 ? { ok: true, pid } : { ok: false, reason: 'launcher_no_answer' });
    });
    try {
      helper.stdin?.on('error', () => {});
      // The launch details travel on stdin, never on a command line: the environment holds the engine token.
      helper.stdin?.end(
        JSON.stringify({ bin: spec.bin, args: spec.args, cwd: spec.cwd, env: spec.env, log: spec.logPath || '' })
      );
    } catch {}
  });
}

// The PowerShell test for "this command line names exactly that port": the argument ends there, or a space
// follows it, so 5123 never matches an engine on 51234. `port` is a whole number, checked by the caller.
function enginePortFilterScript(port) {
  const n = Number(port);
  // Anything that is not a port number matches nothing, and never reaches the script as text.
  if (!Number.isInteger(n) || n <= 0 || n > 65535) return '$false';
  return `$_.CommandLine -like '*--hub-port=${n} *' -or $_.CommandLine -like '*--hub-port=${n}'`;
}

// Process ids of engines started for one port (`--hub-port=<port>`). [] when none, or when it cannot be read.
function findEnginePidsByPort(port) {
  const n = Number(port || 0);
  if (process.platform !== 'win32' || !Number.isInteger(n) || n <= 0 || n > 65535) {
    return Promise.resolve([]);
  }
  const script =
    `$h = @(Get-CimInstance Win32_Process -Filter "Name='agy.exe'" | Where-Object { ${enginePortFilterScript(n)} } | ForEach-Object { $_.ProcessId }); ` +
    'Write-Output ("THEO_PORT|" + ($h -join ","))';
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', script],
      { timeout: 15000, windowsHide: true },
      (err, stdout) => {
        const m = /THEO_PORT\|([\d,]*)/.exec(String(stdout || ''));
        if (err || !m) {
          resolve([]);
          return;
        }
        resolve(
          m[1]
            .split(',')
            .map((x) => Number(x))
            .filter((x) => Number.isInteger(x) && x > 0)
        );
      }
    );
  });
}

function isVersionOlderThan(version, floor) {
  const a = String(version || '').split('.').map((x) => Number(x) || 0);
  const b = String(floor || '').split('.').map((x) => Number(x) || 0);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) < (b[i] || 0);
  }
  return false;
}

function buildAgyEngineLaunch(agyBin, port, csrfToken, opts = {}) {
  const env = { ...(opts.baseEnv || process.env) };
  delete env.AGY_CLI_CDE_AUTH_ACTION;
  delete env.ANTIGRAVITY_CDE;
  delete env.AGY_CDE_SEAMLESS_AUTH;
  delete env.THEO_EPHEMERAL_LOGIN_HUB;
  env.HOME = os.homedir();
  env.USERPROFILE = os.homedir();
  env.AGY_ENABLE_HUB = '1';
  env.AGY_REQUIRE_AUTHENTICATED_UI_BOOTSTRAP = '1';
  env.ANTIGRAVITY_VSCODE_HOST = '1';
  env.ANTIGRAVITY_AUTH_SUCCESS_APP = 'vscode';
  env.ANTIGRAVITY_SERVER_CSRF_TOKEN = csrfToken;
  if (!env.NODE_USE_SYSTEM_CA && (process.platform === 'win32' || process.platform === 'darwin')) {
    env.NODE_USE_SYSTEM_CA = '1';
  }
  const args = ['--hub', `--hub-port=${port}`, '--app_data_dir=antigravity'];
  // Engines before 1.5.2 read the token from the command line only.
  let cliVersion = opts.cliVersion;
  if (cliVersion === undefined) {
    cliVersion = readJsonSafe(path.join(path.dirname(agyBin), 'agy.version.json'), {})?.version || '';
  }
  if (cliVersion && isVersionOlderThan(cliVersion, '1.5.2')) {
    args.push(`--csrf_token=${csrfToken}`);
  }
  return { args, env };
}

// Starts the engine when every condition holds; resolves { started, reason }. `deps` lets tests stand in for
// the process list, the launcher and the engine's answers.
async function ensureStandaloneAgyEngine(deps = {}) {
  const nowMs = typeof deps.now === 'function' ? deps.now() : Date.now();
  const st = deps.state || agyEngineState;
  const logFn = typeof deps.log === 'function' ? deps.log : log;
  if (st.inFlight) return { started: false, reason: 'in_flight' };
  const waitMs = st.failures >= 3 ? AGY_ENGINE_BACKOFF_MS : AGY_ENGINE_RETRY_MS;
  if (st.lastAttemptAt && nowMs - st.lastAttemptAt < waitMs) {
    return { started: false, reason: 'backoff' };
  }
  if (st.lastAliveAt && nowMs - st.lastAliveAt < 30000) {
    return { started: false, reason: 'engine_alive' };
  }
  const readState = deps.readState || readPersistentHubState;
  const pidAlive = deps.isPidAlive || isPidAlive;
  const saved = readState();
  if (saved && saved.pid && pidAlive(saved.pid)) {
    // After a restart of the PC the saved process id may belong to some other program. Only a port that
    // refuses the connection proves the saved engine is gone; a slow or silent one is treated as alive.
    const refused = await (deps.portRefused || isLoopbackPortRefused)(saved.port);
    if (!refused) {
      st.lastAliveAt = nowMs;
      return { started: false, reason: 'engine_alive' };
    }
  }
  st.lastAliveAt = 0;
  const agyBin = (deps.resolveBin || resolveAgyBinaryPath)();
  if (!agyBin) return { started: false, reason: 'no_engine_binary' };

  st.inFlight = true;
  st.lastAttemptAt = nowMs;
  let enginePid = 0;
  // The engine just started here holds no session yet: stopping it is safe. Never used on any other engine.
  const stopEngine =
    deps.stopEngine ||
    ((pid) => {
      try {
        if (pid > 0) process.kill(pid);
      } catch {}
    });
  try {
    const procs = await (deps.inspectProcesses || inspectEngineProcesses)();
    if (!procs) return { started: false, reason: 'process_list_failed' };
    if (procs.vscodeRunning) return { started: false, reason: 'vscode_running' };
    if (procs.hubPids.length > 0) return { started: false, reason: 'engine_process_present' };

    const sync = await Promise.resolve((deps.keyringSync || ensureExpectedAntigravityKeyringSync)(null)).catch(
      () => null
    );
    if (!sync || sync.stagingActive) return { started: false, reason: 'sign_in_in_progress' };
    if (!sync.expectedEmail) return { started: false, reason: 'no_account' };

    const port = await (deps.getPort || getFreeLoopbackPort)();
    const csrfToken = crypto.randomUUID();
    const launch = buildAgyEngineLaunch(agyBin, port, csrfToken, { cliVersion: deps.cliVersion });
    const logPath = path.join(os.homedir(), '.gemini', 'antigravity', 'bhf-persistent-hub.log');
    if (!deps.launch) {
      try {
        fs.mkdirSync(path.dirname(logPath), { recursive: true });
      } catch {}
    }
    // Started one step removed, so it outlives this service; never `detached` (see launchEngineOutsideJob).
    const launched = await (deps.launch || launchEngineOutsideJob)({
      bin: agyBin,
      args: launch.args,
      env: launch.env,
      cwd: os.homedir(),
      logPath
    });
    if (!launched || !launched.ok || !launched.pid) {
      st.failures += 1;
      // The helper may have created the engine and then failed to say so (a timeout). An engine nobody has the
      // address of would block every later start: find it by the port chosen for it, and stop it.
      const strays = await Promise.resolve((deps.findByPort || findEnginePidsByPort)(port)).catch(() => []);
      for (const strayPid of Array.isArray(strays) ? strays : []) stopEngine(strayPid);
      logFn(`[WARN] Antigravity engine not started (${launched?.reason || 'launcher failed'}); will retry later`);
      return { started: false, reason: launched?.reason || 'launcher_failed' };
    }
    enginePid = launched.pid;
    // Its address is saved at once, before it has answered: if this service is restarted during the wait
    // below, the next one finds the engine (and uses it once its port answers) instead of an engine it has
    // no address for.
    const engineState = {
      pid: enginePid,
      port,
      csrfToken,
      serverUrl: `http://127.0.0.1:${port}`,
      startedAt: Math.floor(Date.now() / 1000),
      consoleHidden: true
      // `retiringHubs` is left to writePersistentHubState: older engines still finishing sessions stay listed.
    };
    const writeState = deps.writeState || writePersistentHubState;
    writeState(engineState);

    const heartbeat =
      deps.heartbeat ||
      ((p, t) => new AntigravityDataStore().callRpc(p, t, 'Heartbeat', {}, 1500));
    const readyBy = Date.now() + (deps.readyMs || AGY_ENGINE_READY_MS);
    let ready = false;
    let exited = false;
    while (Date.now() < readyBy) {
      try {
        await heartbeat(port, csrfToken);
        ready = true;
        break;
      } catch {
        if (!pidAlive(enginePid)) {
          exited = true;
          break;
        }
        await new Promise((r) => setTimeout(r, deps.pollMs || 300));
      }
    }
    if (!ready) {
      st.failures += 1;
      // One that already ended is left alone: its process id may belong to something else by now.
      if (!exited) stopEngine(enginePid);
      logFn(`[WARN] Antigravity engine did not answer after start (attempt ${st.failures}); will retry later`);
      return { started: false, reason: exited ? 'engine_exited' : 'engine_not_ready' };
    }
    // A VS Code window may have come up meanwhile and started its own: that one wins, ours holds no session.
    // Only an address saved since this attempt began counts; the stale one found at the start does not.
    const savedNow = readState();
    if (
      savedNow &&
      savedNow.port !== port &&
      savedNow.port !== Number(saved?.port || 0) &&
      savedNow.pid &&
      pidAlive(savedNow.pid)
    ) {
      stopEngine(enginePid);
      return { started: false, reason: 'superseded' };
    }
    writeState(engineState);
    Promise.resolve((deps.disableTelemetry || ensureAntigravityTelemetryDisabled)(port, csrfToken)).catch(
      () => {}
    );
    if (typeof deps.guardDefaultModel === 'function') {
      Promise.resolve(deps.guardDefaultModel({ port, csrfToken })).catch(() => {});
    } else if (!deps.disableTelemetry && process.env.THEO_SMOKE_TEST !== '1') {
      Promise.resolve(ensureAntigravityDefaultModelGuard({ port, csrfToken })).catch(() => {});
    }
    st.failures = 0;
    logFn(`[INFO] Started the Antigravity engine without VS Code (pid ${enginePid}, port ${port})`);
    return { started: true, reason: 'started', pid: enginePid, port };
  } catch (err) {
    st.failures += 1;
    if (enginePid && pidAlive(enginePid)) stopEngine(enginePid);
    logFn(`[WARN] Antigravity engine start failed: ${err?.message || err}`);
    return { started: false, reason: 'error' };
  } finally {
    st.inFlight = false;
  }
}

// The background service has no sidebar hub. Code shared with the VS Code host reads `bridge.hub.snapshot`
// and, in places, calls `bridge.hub.refresh()`: the stand-in answers both, so a call that assumes a sidebar
// can never throw here (one in a timer used to end this whole process).
function makeStandaloneHub(threads) {
  return {
    standalone: true,
    snapshot: { threads: Array.isArray(threads) ? threads : [] },
    refresh: async () => {}
  };
}

function buildStandaloneSummaryForWindows(windowsObj) {
  const win5h = windowsObj?.['5h'] || {};
  const win7d = windowsObj?.['7d'] || {};
  const days = Array.isArray(win7d.daily)
    ? win7d.daily.map((d) => ({
        key: d.date,
        label: d.label,
        tokens: Number(d.totalTokens || 0),
        turns: Number(d.turns || 0)
      }))
    : [];
  const todayBar = days[days.length - 1] || { tokens: 0, turns: 0 };
  return {
    today: {
      sessions: Number(win5h.sessions || 0),
      turns: Math.max(Number(win5h.turns || 0), Number(todayBar.turns || 0)),
      tokens: Math.max(Number(win5h.totalTokens || 0), Number(todayBar.tokens || 0)),
      input: Number(win5h.inputTokens || 0),
      cached: Number(win5h.cachedInputTokens || 0),
      output: Number(win5h.outputTokens || 0)
    },
    week: {
      sessions: Number(win7d.sessions || 0),
      turns: Number(win7d.turns || 0),
      tokens: Number(win7d.totalTokens || 0),
      input: Number(win7d.inputTokens || 0),
      cached: Number(win7d.cachedInputTokens || 0),
      output: Number(win7d.outputTokens || 0)
    },
    days: days.length ? days : [{ key: 'Today', label: 'Today', tokens: 0, turns: 0 }]
  };
}

let latestStandalonePrepatchRes = null;

function buildStandaloneHealthFields(bridge, hasAttachedUi, attachedUiTabState, claudeSignedIn, selfDevId, selfDevName) {
  let rawHotSwapHold = null;
  try {
    rawHotSwapHold = readHotSwapHoldStatus();
  } catch {}
  const hotSwapHold = sanitizeHotSwapHoldForRemote(rawHotSwapHold);
  let rawAr = attachedUiTabState?.autoReload || null;
  if (!rawAr) {
    try {
      const canary = readCanaryFailure();
      if (canary && Number(canary.firstAt) > 0) {
        rawAr = { pending: false, state: 'failed', reasons: [], blockers: [], failure: { firstAt: Number(canary.firstAt) } };
      }
    } catch {}
  }
  const autoReload = sanitizeAutoReloadForRemote(rawAr);
  let bridgeHealth = attachedUiTabState?.bridgeHealth
    ? sanitizeBridgeHealthForRemote(attachedUiTabState.bridgeHealth)
    : null;
  if (!bridgeHealth) {
    try {
      const baseReports = Array.isArray(latestStandalonePrepatchRes?.reports)
        ? latestStandalonePrepatchRes.reports
        : [];
      const uiSkip = buildAgyUiSkipReport(
        baseReports.length > 0 ? baseReports : [{ provider: 'antigravity', reason: '' }],
        readAgyUiPatchHealth(REPO_ROOT)
      );
      const rawSkips = [
        ...(Array.isArray(latestStandalonePrepatchRes?.patchSkips)
          ? latestStandalonePrepatchRes.patchSkips
          : []),
        ...(uiSkip ? [{ ...describePatchSkip(uiSkip), active: true }] : [])
      ];
      const notice = describePatchSkipNotice({ patchSkips: rawSkips }, Boolean(claudeSignedIn));
      if (notice.skipMessage || notice.patchSkips.length > 0 || latestStandalonePrepatchRes?.needsReload) {
        bridgeHealth = sanitizeBridgeHealthForRemote({
          active: true,
          antigravityActive: true,
          claudeActive: true,
          reload: Boolean(latestStandalonePrepatchRes?.needsReload),
          attachFailed: false,
          message: '',
          skipMessage: notice.skipMessage,
          patchSkips: notice.patchSkips
        });
      }
    } catch {}
  }
  const pendingAccountLogin = sanitizePendingLoginForRemote(
    bridge.accountVault?.getPendingLoginState?.() || attachedUiTabState?.pendingAccountLogin || null,
    selfDevId,
    selfDevName
  );
  const pcSetup = readCachedPcSetupSummary() || null;
  const releaseLineAlert = sanitizeReleaseLineAlertForRemote(
    attachedUiTabState?.releaseLineAlert || readReleaseLineAlertView()
  );
  const hostHealth = buildPublicHostHealthSummary({
    hotSwapHold,
    autoReload,
    releaseLineAlert,
    releaseLineRawCount: attachedUiTabState?.releaseLineRawCount ?? readRawReleaseLineAlert()?.count ?? 0,
    bridge: bridgeHealth,
    hasVsCodeUi: Boolean(hasAttachedUi)
  });
  return { hotSwapHold, autoReload, releaseLineAlert, bridgeHealth, pendingAccountLogin, pcSetup, hostHealth };
}

async function buildStandaloneState(store, bridge, opts = {}) {
  refreshUnsavedWork().catch(() => {});
  refreshReleaseLineRadar().catch(() => {});
  const cachedState =
    opts.cachedState || readJsonSafe(opts.lastStateCacheFile || LAST_STATE_CACHE_FILE, {});
  const hubStatePath = opts.hubStateFile || HUB_STATE_FILE;
  let persistedHub = opts.persistedHub || null;
  if (!persistedHub) {
    try {
      const roStateStore = new HubStateStore(null, {
        diskBackup: true,
        diskBackupPath: hubStatePath,
        ...(opts.peerCacheFile ? { peerCachePath: opts.peerCacheFile } : {}),
        readOnly: true
      });
      persistedHub = roStateStore.read();
    } catch {
      persistedHub = readJsonSafe(hubStatePath, {});
    }
  }
  persistedHub = persistedHub || {};
  let archivedSet = new Set([
    ...(Array.isArray(persistedHub?.archivedIds) ? persistedHub.archivedIds : []),
    ...(Array.isArray(persistedHub?.archived) ? persistedHub.archived : [])
  ]);
  let unarchivedAtMap =
    persistedHub?.unarchivedAt && typeof persistedHub.unarchivedAt === 'object'
      ? persistedHub.unarchivedAt
      : {};
  let pinnedMap =
    persistedHub?.pinnedThreads && typeof persistedHub.pinnedThreads === 'object'
      ? persistedHub.pinnedThreads
      : {};
  let unpinnedMap =
    persistedHub?.unpinnedThreads && typeof persistedHub.unpinnedThreads === 'object'
      ? persistedHub.unpinnedThreads
      : {};
  const groups = Array.isArray(persistedHub?.groups)
    ? persistedHub.groups.map((g) => ({
        id: g.id,
        name: g.name,
        ...(g.color ? { color: g.color } : {}),
        collapsed: Boolean(g.collapsed)
      }))
    : cachedState.groups || [];
  let groupIds = new Set(groups.map((g) => g.id));

  let snap = null;
  try {
    snap = await store.loadSnapshot({
      customTitles: persistedHub?.customTitles || {},
      archivedIds: Array.from(archivedSet),
      unarchivedAt: unarchivedAtMap,
      threadGroups: persistedHub?.threadGroups || {},
      groupIds,
      forceQuota: false,
      forceRefreshQuota: false
    });
  } catch {}

  const workspaces = await bridge.refreshWorkspacesCache().catch(() => cachedState.workspaces || []);

  const resolveEffectiveRowModelOverride = (rowId, rowModelUpdatedAt = 0) => {
    const cleanId = String(rowId || '').trim();
    if (!cleanId) return null;
    if (typeof bridge.getEffectiveSessionModelOverride === 'function') {
      return bridge.getEffectiveSessionModelOverride(cleanId, rowModelUpdatedAt);
    }
    const memOvr = bridge.sessionModelOverrides?.get(cleanId) || null;
    const diskOvr = persistedHub?.sessionModels?.[cleanId] || null;
    const memAt = Number(memOvr?.at || memOvr?.updatedAt || 0);
    const diskAt = Number(diskOvr?.at || diskOvr?.updatedAt || 0);
    const chosen = diskAt > memAt ? diskOvr : memOvr || diskOvr;
    if (!chosen || !(chosen.displayModel || chosen.model)) return null;
    const ovrAt = Number(chosen.at || chosen.updatedAt || 0);
    const baseAt = Number(rowModelUpdatedAt || 0);
    if (baseAt > 0 && ovrAt > 0 && baseAt > ovrAt) return null;
    return chosen;
  };

  if (!snap || !Array.isArray(snap.threads)) {
    const rawFallbackRows = Array.isArray(cachedState.rows) ? cachedState.rows : [];
    const fallbackRows = rawFallbackRows
      .map((r) => {
        if (!r || !r.id) return r;
        const inGroup = Boolean(r.group && groupIds.has(r.group));
        const isArch = inGroup
          ? false
          : archivedSet.has(r.id) || Boolean(r.archived && !unarchivedAtMap[r.id]);
        const pinState = resolveRowPinState({ ...r, archived: isArch }, pinnedMap, unpinnedMap);
        const fbModelAt = Number(r.modelUpdatedAt || r.transcriptModelAtMs || 0);
        const fbOvr = resolveEffectiveRowModelOverride(r.id, fbModelAt);
        const fbHasOvr = Boolean(fbOvr?.displayModel || fbOvr?.model);
        const fbEffectiveModel = fbHasOvr
          ? formatModelDisplayName(fbOvr.displayModel || fbOvr.model, r.provider, fbOvr.effort)
          : r.model;
        const fbModelUpdatedAt = Math.max(fbModelAt, Number(fbOvr?.at || fbOvr?.updatedAt || 0));
        return {
          ...r,
          model: fbEffectiveModel,
          effort: fbOvr?.effort || r.effort || undefined,
          ...(fbModelUpdatedAt > 0 ? { modelUpdatedAt: fbModelUpdatedAt } : {}),
          archived: isArch,
          neonWarning: Boolean(!isArch && r.provider !== 'claude' && isNeonModelLabel(fbEffectiveModel)),
          pinned: pinState.pinned,
          pinnedAt: pinState.pinnedAt,
          pinUpdatedAt: pinState.pinUpdatedAt
        };
      })
      .sort(
        (a, b) =>
          Number(Boolean(b?.pinned && !b?.archived)) - Number(Boolean(a?.pinned && !a?.archived)) ||
          Number(b?.at || 0) - Number(a?.at || 0) ||
          Number(b?.pinnedAt || 0) - Number(a?.pinnedAt || 0)
      );
    const fallbackHideClaudeDesktop =
      typeof persistedHub?.preferences?.hideClaudeDesktopSessions === 'boolean'
        ? persistedHub.preferences.hideClaudeDesktopSessions
        : Boolean(cachedState?.hideClaudeDesktop);
    bridge.hub = makeStandaloneHub(
      fallbackRows.map((r) => ({
        id: r.id,
        provider: r.provider,
        claudeDesktop: Boolean(r.claudeDesktop),
        claudeDesktopScratch: Boolean(r.claudeDesktopScratch),
        title: r.title,
        cwd: r.cwd,
        workspaceLabel: r.folder,
        branch: r.branch,
        model: r.model,
        updatedAt: Math.floor((r.at || Date.now()) / 1000)
      }))
    );
    const fallbackRowsById = new Map(fallbackRows.filter((r) => r && r.id).map((r) => [r.id, r]));
    const fallbackThreadsById = new Map(
      (Array.isArray(cachedState.threads) ? cachedState.threads : [])
        .filter((t) => t && t.id)
        .map((t) => [t.id, t])
    );
    const fallbackApprovals = (Array.isArray(cachedState.approvals) ? cachedState.approvals : []).filter((a) => {
      if (!a) return false;
      const row = a.sessionId ? fallbackRowsById.get(a.sessionId) : null;
      const cachedThread = a.sessionId ? fallbackThreadsById.get(a.sessionId) : null;
      const meta = row || cachedThread;
      const isScratch = Boolean(
        a.claudeDesktopScratch ||
          meta?.claudeDesktopScratch ||
          isClaudeDesktopScratchPath(
            meta?.cwd || meta?.filePath || a.cwd || a.filePath || store?.claudeFileById?.get?.(a.sessionId) || ''
          )
      );
      if (isScratch) return false;
      if (meta) {
        return !(fallbackHideClaudeDesktop && meta.claudeDesktop);
      }
      if (fallbackHideClaudeDesktop && a.claudeDesktop) return false;
      if (a.provider === 'claude' && a.claudeDesktop === undefined && a.claudeDesktopScratch !== false) {
        return false;
      }
      return true;
    });
    const fbDevId = bridge.deviceInfo?.id || 'workstation';
    const fbDevName = bridge.deviceInfo?.name || os.hostname();
    const fbHasUi = typeof bridge?.hasAttachedVsCodeUi === 'function' ? Boolean(bridge.hasAttachedVsCodeUi()) : false;
    const fbUiState = typeof bridge.getAttachedVsCodeTabState === 'function' ? bridge.getAttachedVsCodeTabState() : null;
    const fbHealth = buildStandaloneHealthFields(bridge, fbHasUi, fbUiState, Boolean(cachedState?.providers?.claude?.account?.available), fbDevId, fbDevName);
    return {
      ...cachedState,
      rows: fallbackRows,
      approvals: fallbackApprovals,
      hotSwapHold: fbHealth.hotSwapHold,
      autoReload: fbHealth.autoReload,
      releaseLineAlert: fbHealth.releaseLineAlert,
      ...(fbHealth.bridgeHealth ? { bridge: fbHealth.bridgeHealth } : {}),
      pendingAccountLogin: fbHealth.pendingAccountLogin,
      pcSetup: fbHealth.pcSetup,
      hideThirdPartyQuota:
        typeof persistedHub?.preferences?.hideThirdPartyQuota === 'boolean'
          ? persistedHub.preferences.hideThirdPartyQuota
          : Boolean(cachedState?.hideThirdPartyQuota),
      hideThirdPartyQuotaUpdatedAt: Number(
        persistedHub?.preferences?.hideThirdPartyQuotaUpdatedAt ||
          cachedState?.hideThirdPartyQuotaUpdatedAt ||
          0
      ),
      hideClaudeDesktop: fallbackHideClaudeDesktop,
      hideClaudeDesktopUpdatedAt: Number(
        persistedHub?.preferences?.hideClaudeDesktopSessionsUpdatedAt ||
          cachedState?.hideClaudeDesktopUpdatedAt ||
          0
      ),
      generatedAt: Date.now(),
      connection: bridge.getStatus(),
      workspaces,
      personalLedger: bridge.personalLedger,
      antigravityModelCatalog: buildCompactModelCatalogForClient(),
      claudeModelCatalog: buildClaudeModelCatalogForClient()
    };
  }

  const hideClaudeDesktop =
    typeof persistedHub?.preferences?.hideClaudeDesktopSessions === 'boolean'
      ? persistedHub.preferences.hideClaudeDesktopSessions
      : Boolean(cachedState?.hideClaudeDesktop);
  const hasAttachedUi =
    typeof bridge?.hasAttachedVsCodeUi === 'function' ? Boolean(bridge.hasAttachedVsCodeUi()) : false;
  const attachedUiTabState =
    typeof bridge.getAttachedVsCodeTabState === 'function'
      ? bridge.getAttachedVsCodeTabState()
      : { openIds: new Set(), activeId: '', openTabs: [], pendingPermissions: [] };
  const activity =
    !opts.freshActivityTracker && bridge && typeof bridge === 'object'
      ? (bridge._standaloneActivityTracker =
          bridge._standaloneActivityTracker || new SessionActivityTracker())
      : new SessionActivityTracker();
  activity.reconcileSnapshot?.(snap.threads || [], snap.loadedAt || Date.now());
  if (!hasAttachedUi && !opts.localOnly && !opts.persistedHub && !opts.readOnly) {
    let rawDiskHub = readJsonSafe(hubStatePath, {});
    try {
      const freshRoStore = new HubStateStore(null, {
        diskBackup: true,
        diskBackupPath: hubStatePath,
        ...(opts.peerCacheFile ? { peerCachePath: opts.peerCacheFile } : {}),
        readOnly: true
      });
      persistedHub = freshRoStore.read() || persistedHub;
      archivedSet = new Set([
        ...(Array.isArray(persistedHub?.archivedIds) ? persistedHub.archivedIds : []),
        ...(Array.isArray(persistedHub?.archived) ? persistedHub.archived : [])
      ]);
      unarchivedAtMap =
        persistedHub?.unarchivedAt && typeof persistedHub.unarchivedAt === 'object'
          ? persistedHub.unarchivedAt
          : {};
      pinnedMap =
        persistedHub?.pinnedThreads && typeof persistedHub.pinnedThreads === 'object'
          ? persistedHub.pinnedThreads
          : {};
      unpinnedMap =
        persistedHub?.unpinnedThreads && typeof persistedHub.unpinnedThreads === 'object'
          ? persistedHub.unpinnedThreads
          : {};
      if (Array.isArray(persistedHub?.groups)) {
        groups.splice(
          0,
          groups.length,
          ...persistedHub.groups.map((g) => ({
            id: g.id,
            name: g.name,
            ...(g.color ? { color: g.color } : {}),
            collapsed: Boolean(g.collapsed)
          }))
        );
        groupIds = new Set(groups.map((g) => g.id));
      }
    } catch {}
    const validDays = [0, 1, 2, 7, 14];
    const rawDays = persistedHub?.preferences?.autoArchiveInactiveDays;
    const autoDays = typeof rawDays === 'number' && validDays.includes(rawDays) ? rawDays : 1;
    const { toArchive, groupedToRestore } = collectAutoArchiveCandidates({
      threads: snap.threads,
      state: persistedHub,
      rawArchivedIds: Array.isArray(rawDiskHub?.archivedIds) ? rawDiskHub.archivedIds : persistedHub?.archivedIds,
      claudeNativeArchivedIds: snap?.claudeLive?.archivedIds || [],
      openTabIds: attachedUiTabState.openIds,
      activity,
      resolvePinState: resolveRowPinState,
      days: autoDays,
      nowSec: Math.floor(Date.now() / 1000)
    });
    if (groupedToRestore.length > 0 || toArchive.length > 0) {
      try {
        const rwStateStore = new HubStateStore(null, {
          diskBackup: true,
          diskBackupPath: hubStatePath,
          ...(opts.peerCacheFile ? { peerCachePath: opts.peerCacheFile } : {})
        });
        if (groupedToRestore.length > 0) {
          await rwStateStore.setArchivedMany(groupedToRestore, false, { manualUnarchive: true });
        }
        if (toArchive.length > 0) {
          await rwStateStore.setArchivedMany(toArchive, true, { autoArchive: true });
        }
        rwStateStore.flushDiskBackupSync?.();
        persistedHub = rwStateStore.read();
        archivedSet = new Set([
          ...(Array.isArray(persistedHub?.archivedIds) ? persistedHub.archivedIds : []),
          ...(Array.isArray(persistedHub?.archived) ? persistedHub.archived : [])
        ]);
        unarchivedAtMap =
          persistedHub?.unarchivedAt && typeof persistedHub.unarchivedAt === 'object'
            ? persistedHub.unarchivedAt
            : {};
        pinnedMap =
          persistedHub?.pinnedThreads && typeof persistedHub.pinnedThreads === 'object'
            ? persistedHub.pinnedThreads
            : {};
        unpinnedMap =
          persistedHub?.unpinnedThreads && typeof persistedHub.unpinnedThreads === 'object'
            ? persistedHub.unpinnedThreads
            : {};
      } catch {}
    }
  }
  const { rows, rowFallbackApprovals } = projectSessionRows({
    threads: snap.threads,
    openTabs: attachedUiTabState.openTabs,
    openIds: attachedUiTabState.openIds,
    activeId: attachedUiTabState.activeId,
    persisted: persistedHub,
    groupIds,
    activity,
    hasAttachedUi,
    hideClaudeDesktop,
    resolvePinState: resolveRowPinState,
    resolveSoftLimitTokens: (prov, model) =>
      inferSoftAndHardContextLimits(prov, model || '').softCompactionTargetTokens,
    isScratchSession: (tabId, prov) =>
      prov === 'claude' &&
      isClaudeDesktopScratchPath(
        store?.claudeFileById?.get?.(tabId) || store?.getTranscriptLogPath?.(tabId, prov) || ''
      ),
    formatModel: formatSessionRowModelDisplayName,
    includeEffort: true,
    includeTabUri: false,
    includeDraftTabs: false,
    sortOpenFirst: false,
    collectFallbackApprovals: true
  });

  const formatBucket = (b) => ({
    label: b.label,
    pct: b.usedPercent,
    reset: b.resetAt ? b.resetAt * 1000 : 0,
    resetText: b.resetText || '',
    expired: Boolean(b.expired ?? b.windowExpired),
    ...(b.pool ? { pool: b.pool } : {}),
    ...(b.key || b.bucketId ? { key: b.key || b.bucketId } : {})
  });

  const agyFallbackMsg = snap?.serverConnected
    ? 'Loading quota windows…'
    : 'Waiting for Antigravity language server…';
  const claudeFallbackMsg = snap?.claudeAccount?.available
    ? 'Loading Claude quota windows…'
    : 'Sign in to Claude Code to view quota.';

  const prefCollapsed =
    persistedHub?.preferences?.collapsedAccounts &&
    typeof persistedHub.preferences.collapsedAccounts === 'object'
      ? persistedHub.preferences.collapsedAccounts
      : {};
  let accountsView = null;
  if (bridge.accountVault) {
    try {
      bridge.accountVault.syncActiveClaudeFromDisk(
        snap?.claudeConfigObj,
        snap?.claudeCredsObj,
        snap?.rawClaudeQuota,
        snap?.rawClaudeQuotaAt || 0
      );
      accountsView = await bridge.accountVault.resolveAccountsSnapshot({
        nowMs: Date.now(),
        forceQuota: false,
        antigravityAccount: snap?.account,
        antigravityLimits: snap?.rateLimits,
        rawAntigravityQuota: snap?.rawAntigravityQuota,
        rawActiveQuotaAt: snap?.rawAntigravityQuotaAt || 0,
        claudeAccount: snap?.claudeAccount,
        claudeLimits: snap?.claudeRateLimits,
        rawClaudeQuota: snap?.rawClaudeQuota,
        claudeRelayMerged: snap?.claudeLive?.rateLimitWindows,
        collapsedProviders: {
          antigravity: Boolean(persistedHub?.preferences?.antigravityUsageCollapsed),
          claude: Boolean(persistedHub?.preferences?.claudeUsageCollapsed),
          ...prefCollapsed
        }
      });
    } catch {}
  }

  const mapStandaloneCard = (item, fallbackMsg) => {
    const provKey = item.provider === 'claude' ? 'claude' : 'antigravity';
    const isSignedOutItem = !item.available || Boolean(item.signedOut || item.account?.signedOut);
    const pLimits = isSignedOutItem ? [] : (item.rateLimits?.primaryBars || []).map(formatBucket);
    const aLimits = isSignedOutItem ? [] : (item.rateLimits?.allBuckets || []).map(formatBucket);
    const isCardCollapsed =
      typeof prefCollapsed[item.id] === 'boolean'
        ? Boolean(prefCollapsed[item.id])
        : Boolean(item.collapsed);
    return {
      id: item.id,
      provider: provKey,
      label: provKey === 'claude' ? 'Claude Code' : 'Antigravity',
      nickname: item.label || '',
      active: !isSignedOutItem && Boolean(item.active),
      hubLive: Boolean(item.hubLive),
      hubPendingCutover: Boolean(item.hubPendingCutover),
      collapsed: isCardCollapsed,
      addedAt: Number(item.addedAt || 0),
      sortOrder: Number.isFinite(Number(item.sortOrder)) ? Number(item.sortOrder) : 0,
      lastActiveAt: Number(item.lastActiveAt || 0),
      quotaUpdatedAt: Number(item.quotaUpdatedAt || snap?.loadedAt || 0),
      account: {
        name: item.name || item.account?.name || (provKey === 'claude' ? 'Claude Account' : 'Antigravity Account'),
        email: isSignedOutItem ? '' : item.email || item.account?.email || '',
        plan: isSignedOutItem ? '' : item.plan || item.account?.plan || (provKey === 'claude' ? 'Claude Code' : 'Google AI Pro'),
        nickname: item.label || '',
        available: !isSignedOutItem && Boolean(item.available),
        signedOut: isSignedOutItem
      },
      usage: !isSignedOutItem && pLimits.length
        ? {
            at: item.quotaUpdatedAt || snap?.loadedAt || Date.now(),
            limits: pLimits,
            allLimits: aLimits
          }
        : null,
      usageMessage: isSignedOutItem ? 'Not signed in.' : item.rateLimits?.error || fallbackMsg || ''
    };
  };

  const agyAccountsModels =
    Array.isArray(accountsView?.antigravity) && accountsView.antigravity.length
      ? accountsView.antigravity.map((item) => mapStandaloneCard(item, agyFallbackMsg))
      : null;
  const claudeAccountsModels =
    Array.isArray(accountsView?.claude) && accountsView.claude.length
      ? accountsView.claude.map((item) => mapStandaloneCard(item, claudeFallbackMsg))
      : null;
  const agyActiveCard = agyAccountsModels?.find((a) => a.active) || agyAccountsModels?.[0] || null;
  const claudeActiveCard = claudeAccountsModels?.find((a) => a.active) || claudeAccountsModels?.[0] || null;

  const agyPrimaryLimits = (snap?.rateLimits?.primaryBars || []).map(formatBucket);
  const agyAllLimits = (snap?.rateLimits?.allBuckets || []).map(formatBucket);
  const claudePrimaryLimits = (snap?.claudeRateLimits?.primaryBars || []).map(formatBucket);
  const claudeAllLimits = (snap?.claudeRateLimits?.allBuckets || []).map(formatBucket);

  const agyProviderInfo = {
    id: 'antigravity',
    label: 'Antigravity',
    account: agyActiveCard?.account || {
      name: snap?.account?.name || cachedState?.account?.name || 'Antigravity Account',
      email: snap?.account?.email || cachedState?.account?.email || '',
      plan: snap?.account?.plan || cachedState?.account?.plan || 'Google AI Pro',
      available: Boolean(snap?.account?.email || snap?.account?.name || cachedState?.account?.available),
      signedOut: false
    },
    usage: agyActiveCard
      ? agyActiveCard.usage
      : agyPrimaryLimits.length
        ? {
            at: snap?.loadedAt || Date.now(),
            limits: agyPrimaryLimits,
            allLimits: agyAllLimits
          }
        : cachedState?.providers?.antigravity?.usage || cachedState?.usage || null,
    usageMessage: agyActiveCard?.usageMessage || agyFallbackMsg,
    accounts: agyAccountsModels || cachedState?.providers?.antigravity?.accounts || undefined
  };

  const claudeSignedOut = Boolean(snap?.claudeAccount?.signedOut);
  const claudeProviderInfo = {
    id: 'claude',
    label: 'Claude Code',
    account:
      claudeActiveCard?.account ||
      (claudeSignedOut
        ? {
            name: 'Claude Code',
            email: '',
            plan: '',
            available: false,
            signedOut: true
          }
        : {
            name: snap?.claudeAccount?.name || cachedState?.providers?.claude?.account?.name || 'Claude Account',
            email: snap?.claudeAccount?.email || cachedState?.providers?.claude?.account?.email || '',
            plan: snap?.claudeAccount?.plan || cachedState?.providers?.claude?.account?.plan || 'Claude Code',
            available: Boolean(snap?.claudeAccount?.available || cachedState?.providers?.claude?.account?.available),
            signedOut: false
          }),
    usage: claudeActiveCard
      ? claudeActiveCard.usage
      : claudeSignedOut
        ? null
        : claudePrimaryLimits.length
          ? {
              at: snap?.loadedAt || Date.now(),
              limits: claudePrimaryLimits,
              allLimits: claudeAllLimits
            }
          : cachedState?.providers?.claude?.usage || null,
    usageMessage:
      claudeActiveCard?.usageMessage || (claudeSignedOut ? 'Not signed in.' : claudeFallbackMsg),
    accounts:
      claudeAccountsModels ||
      (claudeSignedOut ? [] : cachedState?.providers?.claude?.accounts || undefined)
  };

  bridge.hub = makeStandaloneHub(snap.threads);

  // Requests held for the phone that only this process can see: a headless Claude run waiting on a tool
  // approval or a question, and approvals the Antigravity engine reports. Each replaces the generic
  // "session is waiting" card of its session. Without this the phone never saw them with VS Code closed.
  const standaloneApprovals = [];
  const heldSessionIds = new Set();
  try {
    const held =
      typeof bridge.collectPendingApprovals === 'function' ? await bridge.collectPendingApprovals() : [];
    for (const card of Array.isArray(held) ? held : []) {
      if (!card || !card.id || !card.sessionId || card.kind === 'waiting_session') continue;
      if (card.claudeDesktopScratch || (hideClaudeDesktop && card.claudeDesktop)) continue;
      heldSessionIds.add(card.sessionId);
      standaloneApprovals.push(card);
    }
  } catch {}
  for (const fb of rowFallbackApprovals) {
    if (!fb || !fb.sessionId || heldSessionIds.has(fb.sessionId)) continue;
    standaloneApprovals.push(fb);
  }

  const selfDevId = bridge.deviceInfo?.id || 'workstation';
  const selfDevName = bridge.deviceInfo?.name || os.hostname();
  const peerOwnedRowIds = new Map();
  const addPeerRows = (devId, list) => {
    if (!devId || devId === selfDevId || !Array.isArray(list)) return;
    let set = peerOwnedRowIds.get(devId);
    if (!set) {
      set = new Set();
      peerOwnedRowIds.set(devId, set);
    }
    for (const pr of list) {
      if (pr && pr.id) set.add(String(pr.id));
    }
  };
  if (bridge.edgeClient) {
    for (const [pDevId, pEntry] of Object.entries(bridge.edgeClient.getPeerSnapshots())) {
      addPeerRows(pDevId, pEntry?.snapshot?.rows);
    }
  }
  for (const [rDevId, rEntry] of Object.entries(bridge.remoteDeviceStates || {})) {
    addPeerRows(rDevId, rEntry?.snapshot?.rows || rEntry?.rows);
  }
  const rowById = new Map();
  for (const r of rows) {
    if (!r || !r.id) continue;
    const ownerInfo = inferRowOwnerDevice(r, bridge.deviceInfo, { peerOwnedRowIds });
    const ownerDevId = ownerInfo.id || ownerInfo.deviceId;
    const ownerDevName = ownerInfo.name || ownerInfo.deviceName;
    const isForeignRow =
      ownerDevId !== selfDevId || r.source === 'cloud-relay' || Boolean(r.remotePeer);
    if (opts.localOnly && isForeignRow) continue;
    rowById.set(r.id, {
      ...r,
      deviceId: ownerDevId || selfDevId,
      deviceName: ownerDevName || selfDevName,
      remotePeer: isForeignRow
    });
  }
  if (bridge.directRunner) {
    for (const run of bridge.directRunner.getActiveRuns()) {
      const rid = run.threadId || run.id;
      if (!rid) continue;
      const existing = rowById.get(rid);
      const existingModelAt = Number(existing?.modelUpdatedAt || existing?.transcriptModelAtMs || 0);
      const runOverride = resolveEffectiveRowModelOverride(rid, existingModelAt);
      const runModelLabel = runOverride?.displayModel || runOverride?.model
        ? formatModelDisplayName(runOverride.displayModel || runOverride.model, run.provider, runOverride.effort)
        : formatSessionRowModelDisplayName(run.model || existing?.model, run.provider, runOverride?.effort || run.effort || '');
      const runModelUpdatedAt = Math.max(existingModelAt, Number(runOverride?.at || runOverride?.updatedAt || 0));
      // Held for an answer from the phone: the row reads as waiting, not as running.
      const runHeld = Number(run.pendingPermissionCount || 0) > 0;
      rowById.set(rid, {
        ...(existing || {}),
        id: rid,
        key: existing?.key || rid,
        draftId: run.draftId || existing?.draftId || '',
        provider: run.provider,
        deviceId: selfDevId,
        deviceName: selfDevName,
        remotePeer: false,
        title: existing?.title || run.title || 'New Direct Session',
        cwd: existing?.cwd || run.cwd || '',
        folder: existing?.folder || run.folder || 'Workspace',
        model: runModelLabel,
        ...(runModelUpdatedAt > 0 ? { modelUpdatedAt: runModelUpdatedAt } : {}),
        neonWarning: Boolean(!existing?.archived && run.provider !== 'claude' && isNeonModelLabel(runModelLabel)),
        effort: runOverride?.effort || run.effort || existing?.effort || undefined,
        ...(runHeld
          ? { status: 'waiting', statusLabel: 'Needs your answer', dot: 'waiting', category: 'needs_input' }
          : {
              status: 'working',
              statusLabel: run.activeTool ? `Running ${run.activeTool}` : 'Streaming ⚡',
              dot: 'running',
              category: 'working'
            }),
        directStreaming: true,
        at: Math.max(Number(existing?.at || 0), Number(run.updatedAt || Date.now())),
        lastAssistantText: run.fullText ? run.fullText.slice(-220) : existing?.lastAssistantText || ''
      });
    }
  }
  if (!opts.localOnly) {
    const peerSources = [];
    if (bridge.edgeClient && typeof bridge.edgeClient.getPeerSnapshots === 'function') {
      for (const [pDevId, pEntry] of Object.entries(bridge.edgeClient.getPeerSnapshots())) {
        if (pDevId && pDevId !== selfDevId && Array.isArray(pEntry?.snapshot?.rows)) {
          peerSources.push({
            deviceId: pDevId,
            deviceName: pEntry.deviceName || pDevId,
            rows: pEntry.snapshot.rows
          });
        }
      }
    }
    for (const [rDevId, rEntry] of Object.entries(bridge.remoteDeviceStates || {})) {
      const rRows = Array.isArray(rEntry?.snapshot?.rows)
        ? rEntry.snapshot.rows
        : Array.isArray(rEntry?.rows)
          ? rEntry.rows
          : null;
      if (!rDevId || rDevId === selfDevId || !rRows) continue;
      if (peerSources.some((p) => p.deviceId === rDevId)) continue;
      peerSources.push({
        deviceId: rDevId,
        deviceName: rEntry.device?.name || rDevId,
        rows: rRows
      });
    }
    for (const src of peerSources) {
      for (const pr of src.rows) {
        if (!pr || !pr.id || rowById.has(pr.id)) continue;
        // The peer listed this session as its own, so it is the owner whatever folder the session ran in.
        const prOwner = inferRowOwnerDevice(
          { ...pr, deviceId: src.deviceId, deviceName: src.deviceName },
          { id: src.deviceId, name: src.deviceName },
          { trustStamp: true }
        );
        const peerModelLabel = formatSessionRowModelDisplayName(pr.model, pr.provider, pr.effort || '');
        rowById.set(pr.id, {
          ...pr,
          deviceId: prOwner.id || prOwner.deviceId || src.deviceId,
          deviceName: prOwner.name || prOwner.deviceName || src.deviceName,
          remotePeer: true,
          model: peerModelLabel,
          neonWarning: Boolean(!pr.archived && pr.provider !== 'claude' && isNeonModelLabel(peerModelLabel))
        });
      }
    }
  }
  const nowMs = Date.now();
  const mergedRows = Array.from(rowById.values())
    .map((r) => {
      if (!r || !r.id) return r;
      const inGroup = Boolean(r.group && groupIds.has(r.group));
      const isArch = inGroup
        ? false
        : archivedSet.has(r.id) || Boolean(r.archived && !unarchivedAtMap[r.id]);
      const pinState = resolveRowPinState({ ...r, archived: isArch }, pinnedMap, unpinnedMap);
      const stopped = bridge.userStoppedSessionsById?.get(r.id);
      const recentlyStopped = Boolean(stopped && nowMs - Number(stopped.at || 0) < 60000);
      const rowModelAt = Number(r.modelUpdatedAt || r.transcriptModelAtMs || 0);
      const modelOverride = resolveEffectiveRowModelOverride(r.id, rowModelAt);
      const hasModelOverride = Boolean(modelOverride?.displayModel || modelOverride?.model);
      const effectiveModelLabel = hasModelOverride
        ? formatModelDisplayName(modelOverride.displayModel || modelOverride.model, r.provider, modelOverride.effort)
        : formatSessionRowModelDisplayName(r.model, r.provider, modelOverride?.effort || r.effort || '');
      const effectiveModelUpdatedAt = Math.max(rowModelAt, Number(modelOverride?.at || modelOverride?.updatedAt || 0));
      const overrideLimit = hasModelOverride
        ? inferMaxContextTokens(r.provider, effectiveModelLabel)
        : Number(r.limitTokens || 0);
      const rowCtxLimits = inferSoftAndHardContextLimits(r.provider, effectiveModelLabel, overrideLimit);
      const upgradeLegacyRow =
        !hasModelOverride &&
        r.provider !== 'claude' &&
        Number(r.limitTokens || 0) === 256000 &&
        rowCtxLimits.softCompactionTargetTokens > 256000;
      const rowUsed = Number(r.usedTokens || 0);
      return {
        ...r,
        ...(!r.key && r.id ? { key: String(r.id) } : {}),
        model: effectiveModelLabel,
        ...(effectiveModelUpdatedAt > 0 ? { modelUpdatedAt: effectiveModelUpdatedAt } : {}),
        neonWarning: Boolean(!isArch && r.provider !== 'claude' && isNeonModelLabel(effectiveModelLabel)),
        effort: modelOverride?.effort || r.effort || undefined,
        ...(hasModelOverride || !r.limitTokens || upgradeLegacyRow
          ? { limitTokens: rowCtxLimits.softCompactionTargetTokens }
          : {}),
        ...(upgradeLegacyRow && rowUsed > 0
          ? {
              contextPct: Math.min(
                100,
                Math.max(1, Math.round((rowUsed / rowCtxLimits.softCompactionTargetTokens) * 100))
              )
            }
          : {}),
        softCompactionTargetTokens:
          hasModelOverride || upgradeLegacyRow
            ? rowCtxLimits.softCompactionTargetTokens
            : Number(r.softCompactionTargetTokens || rowCtxLimits.softCompactionTargetTokens),
        hardMaxTokens: hasModelOverride
          ? rowCtxLimits.hardMaxTokens
          : Number(r.hardMaxTokens || rowCtxLimits.hardMaxTokens),
        archived: isArch,
        pinned: pinState.pinned,
        pinnedAt: pinState.pinnedAt,
        pinUpdatedAt: pinState.pinUpdatedAt,
        ...(recentlyStopped
          ? {
              status: 'completed',
              statusLabel: 'Stopped',
              turnComplete: false,
              dot: r.open ? 'idle' : null,
              category: 'completed',
              unread: false,
              elsewhere: false,
              reason: null,
              bgTask: null,
              bgRunningCount: 0,
              bgTasks: Array.isArray(r.bgTasks)
                ? r.bgTasks.map((t) => (t.state === 'running' ? { ...t, state: 'cancelled' } : t))
                : []
            }
          : {})
      };
    })
    .sort(
      (a, b) =>
        Number(Boolean(b?.pinned && !b?.archived)) - Number(Boolean(a?.pinned && !a?.archived)) ||
        Number(b?.at || 0) - Number(a?.at || 0) ||
        Number(b?.pinnedAt || 0) - Number(a?.pinnedAt || 0)
    );
  const stampedWorkspaces = (workspaces || []).map((w) => ({
    ...w,
    deviceId: selfDevId,
    deviceName: selfDevName
  }));
  const byProviderUsage = snap?.usage?.byProvider || {};
  const summaryByProvider = snap?.usage
    ? {
        all: buildStandaloneSummaryForWindows(snap.usage.windows || {}),
        antigravity: buildStandaloneSummaryForWindows(byProviderUsage.antigravity || {}),
        claude: buildStandaloneSummaryForWindows(byProviderUsage.claude || {})
      }
    : cachedState?.summaryByProvider || null;
  const standaloneHealth = buildStandaloneHealthFields(
    bridge,
    hasAttachedUi,
    attachedUiTabState,
    Boolean(claudeProviderInfo?.account?.available),
    selfDevId,
    selfDevName
  );
  bridge._lastSelfHostHealth = standaloneHealth.hostHealth;

  const resultState = {
    ...cachedState,
    type: 'state',
    loading: false,
    hotSwapHold: standaloneHealth.hotSwapHold,
    autoReload: standaloneHealth.autoReload,
    releaseLineAlert: standaloneHealth.releaseLineAlert,
    ...(standaloneHealth.bridgeHealth ? { bridge: standaloneHealth.bridgeHealth } : {}),
    pendingAccountLogin: standaloneHealth.pendingAccountLogin,
    pcSetup: standaloneHealth.pcSetup,
    hideThirdPartyQuota:
      typeof persistedHub?.preferences?.hideThirdPartyQuota === 'boolean'
        ? persistedHub.preferences.hideThirdPartyQuota
        : Boolean(cachedState?.hideThirdPartyQuota),
    hideThirdPartyQuotaUpdatedAt: Number(
      persistedHub?.preferences?.hideThirdPartyQuotaUpdatedAt ||
        cachedState?.hideThirdPartyQuotaUpdatedAt ||
        0
    ),
    hideClaudeDesktop,
    hideClaudeDesktopUpdatedAt: Number(
      persistedHub?.preferences?.hideClaudeDesktopSessionsUpdatedAt ||
        cachedState?.hideClaudeDesktopUpdatedAt ||
        0
    ),
    device: {
      id: selfDevId,
      name: selfDevName,
      role: bridge.deviceInfo?.role || 'host',
      hostname: os.hostname(),
      homedir: os.homedir(),
      capabilities: bridge.deviceInfo?.capabilities || [],
      pcSetup: standaloneHealth.pcSetup,
      pwaReady: bridge.getSelfPwaReadySummary?.() || null,
      ...(standaloneHealth.hostHealth ? { hostHealth: standaloneHealth.hostHealth } : {}),
      unsavedWork: readFleetUnsavedWorkSummary()
    },
    account: agyProviderInfo.account,
    usage: agyProviderInfo.usage,
    providers: {
      antigravity: agyProviderInfo,
      claude: claudeProviderInfo
    },
    accountOrder: Array.isArray(accountsView?.accountOrder)
      ? accountsView.accountOrder
      : cachedState?.accountOrder || [],
    groups,
    rows: mergedRows,
    devices: bridge.getUnifiedFleetDevices ? bridge.getUnifiedFleetDevices() : [],
    activeDirectRuns: bridge.directRunner ? bridge.directRunner.getActiveRuns() : [],
    total: mergedRows.length,
    summary: summaryByProvider?.all || cachedState?.summary || null,
    summaryByProvider,
    generatedAt: Date.now(),
    connection: bridge.getStatus(),
    approvals: standaloneApprovals,
    workspaces: stampedWorkspaces,
    unsavedWork: readUnsavedWorkSummary(),
    topSessions: (snap?.usage?.topThreads || cachedState.topSessions || []).slice(0, 12),
    personalLedger: bridge.personalLedger,
    lastNotification: bridge.lastNotification || null,
    recentNotifications: (bridge.recentNotifications || []).slice(0, 15),
    claudePermissionMode:
      typeof bridge.getClaudePermissionModeSnapshot === 'function'
        ? bridge.getClaudePermissionModeSnapshot()
        : undefined,
    antigravityModelCatalog: buildCompactModelCatalogForClient(),
    claudeModelCatalog: buildClaudeModelCatalogForClient()
  };
  if (mergedRows.length > 0 && !opts.localOnly && typeof bridge._scheduleLastStateCacheWrite === 'function') {
    bridge._scheduleLastStateCacheWrite(resultState);
  }
  return resultState;
}

function attachKeepaliveStateBuilder(store, bridge, defaultOpts = {}) {
  bridge.buildFullState = async (opts = {}) =>
    buildStandaloneState(store, bridge, { ...defaultOpts, ...opts });
}

function acquireSingleInstanceLock(bootMtime, forceRestart) {
  try {
    if (!fs.existsSync(CLAUDE_DIR)) {
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    }
    let existingPid = 0;
    if (fs.existsSync(PID_FILE)) {
      existingPid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim() || 0);
    }
    const existingMeta = readJsonSafe(META_FILE, {});
    if (!existingPid && existingMeta.pid) {
      existingPid = Number(existingMeta.pid);
    }
    if (isPidAlive(existingPid)) {
      const existingBoot = Number(existingMeta.bootMtime || 0);
      if (!forceRestart && existingBoot >= bootMtime - 1000) {
        return false;
      }
      try {
        process.kill(existingPid);
        log(`[INFO] Replaced older keepalive instance (pid ${existingPid})`);
      } catch {}
    }
    fs.writeFileSync(PID_FILE, String(process.pid), 'utf8');
    fs.writeFileSync(
      META_FILE,
      JSON.stringify({
        pid: process.pid,
        startedAt: Date.now(),
        bootMtime,
        script: __filename
      }),
      'utf8'
    );
  } catch {}
  return true;
}

let respawnTriggered = false;
function respawnSelfAndExit(updateInfo = null) {
  if (respawnTriggered) return;
  respawnTriggered = true;
  try {
    const origPs1 = path.join(__dirname, 'relay_keepalive_start.ps1');
    let startPs1 = origPs1;
    const candidateTargets = updateInfo?.updatedPaths || updateInfo?.updatedTargets;
    if (Array.isArray(candidateTargets)) {
      for (const tgt of candidateTargets) {
        const candPs1 = path.join(tgt, 'scripts', 'relay_keepalive_start.ps1');
        if (getFileMtimeMs(candPs1) > getFileMtimeMs(startPs1)) {
          startPs1 = candPs1;
        }
      }
    }
    const psArgs = [
      '-NoProfile',
      '-NonInteractive',
      '-WindowStyle',
      'Hidden',
      '-ExecutionPolicy',
      'Bypass',
      '-File',
      startPs1,
      '-Restart'
    ];
    // When respawning onto a newly self-updated target folder (e.g. ~/.vscode/extensions/bhfirms.theo-hub-* when
    // ~/bhfirms/theo-hub was skipped due to git state), re-register the Scheduled Task & Startup VBS to that folder.
    const movedTarget = path.resolve(startPs1) !== path.resolve(origPs1) || Boolean(updateInfo?.updated);
    if (!movedTarget) {
      psArgs.push('-SkipTaskCheck');
    }
    const child = spawn('powershell.exe', psArgs, {
      cwd: path.dirname(path.dirname(startPs1)),
      detached: true,
      windowsHide: true,
      stdio: 'ignore'
    });
    child.unref();
    log('[INFO] Code updated on disk -> triggered WMI respawn via relay_keepalive_start.ps1');
  } catch (err) {
    log(`[WARN] Self-respawn failed: ${err.message}`);
  }
  setTimeout(() => process.exit(0), 400);
}

function attachKeepaliveCommandProxy(_store, bridge) {
  const origExecuteRemoteCommand = bridge.executeRemoteCommand.bind(bridge);
  bridge.executeRemoteCommand = async (cmd = {}) => {
    const type = String(cmd.type || cmd.action || '').trim();
    if (
      type === 'cancelBgTask' ||
      type === 'cancelAllBgTasks' ||
      type === 'setHideThirdPartyQuota' ||
      type === 'setHideClaudeDesktop' ||
      type === 'dismissAutoReloadFailure' ||
      type === 'reload' ||
      type === 'reloadWindow' ||
      type === 'checkPcSetup' ||
      type === 'accountRefresh' ||
      type === 'accountCancelLogin' ||
      type === 'accountNewSession'
    ) {
      return origExecuteRemoteCommand({
        ...cmd,
        type: 'sessionAction',
        subAction: type
      });
    }
    return origExecuteRemoteCommand(cmd);
  };
}

async function main() {
  const once = process.argv.includes('--once');
  const forceRestart = process.argv.includes('--restart') || process.argv.includes('--force');
  const bootMtime = computeDiskMaxMtime();

  if (!once) {
    const acquired = acquireSingleInstanceLock(bootMtime, forceRestart);
    if (!acquired) {
      process.exit(0);
    }
  }

  if (!once) {
    // This process is what keeps the phone linked when no VS Code window is open. A stray error in a timer or
    // an unawaited promise is written to the log and survived; a burst of them restarts the service cleanly.
    const strayErrorTimes = [];
    const noteStrayError = (kind, err) => {
      const nowMs = Date.now();
      while (strayErrorTimes.length && nowMs - strayErrorTimes[0] > 60000) strayErrorTimes.shift();
      strayErrorTimes.push(nowMs);
      if (strayErrorTimes.length <= 6) {
        log(`[ERR] ${kind}: ${String(err?.stack || err?.message || err).slice(0, 900)}`);
      }
      if (strayErrorTimes.length >= 25) {
        strayErrorTimes.length = 0;
        log('[ERR] 25 stray errors within a minute -> restarting the service');
        respawnSelfAndExit();
      }
    };
    process.on('uncaughtException', (err) => noteStrayError('uncaught exception', err));
    process.on('unhandledRejection', (err) => noteStrayError('unhandled rejection', err));
  }

  const store = new AntigravityDataStore();
  const accountVault = new AccountVaultManager();
  const bridge = new TheoRemoteBridge(
    { extensionPath: REPO_ROOT },
    { store, accountVault }
  );
  // Until this process serves the phone itself (its server's 'listening' handler lifts this), a headless run
  // started here cannot show a tool request to anyone: it is refused at once instead of held.
  try {
    bridge.directRunner?.setPhoneLinkDown?.();
  } catch {}

  let pendingSelfUpdateInfo = null;
  let isBackgroundChildBusy = () => false;

  bridge.onSelfUpdateApplied = (info) => {
    if (!once) {
      const rel = info?.release || info;
      const hasActiveDirectRuns = (bridge.directRunner?.getActiveRuns?.().length || 0) > 0;
      if (isBackgroundChildBusy() || hasActiveDirectRuns) {
        pendingSelfUpdateInfo = info;
        log(
          `[INFO] Self-updated theo-hub bundle (${rel?.version || ''} @ ${rel?.builtAt || 0}) -> deferring daemon respawn until background/session runs finish`
        );
        return;
      }
      log(`[INFO] Self-updated theo-hub bundle (${rel?.version || ''} @ ${rel?.builtAt || 0}) -> respawning daemon`);
      respawnSelfAndExit(info);
    }
  };

  attachKeepaliveStateBuilder(store, bridge);
  attachKeepaliveCommandProxy(store, bridge);

  // Single-service phone-link loop: always own :4318 + Edge Relay + Cloud Relay when bound,
  // falling back to allowStandby only if another instance temporarily holds :4318 during handoff.
  let lastReason = '';
  let lastErr = '';
  let tickInFlight = false;

  const headlessBridgeState = { resumeCheckInFlight: false, lastBootCheckedHubStartedAt: 0 };
  async function runHeadlessCascadeContinuity() {
    try {
      const savedHub = readPersistentHubState();
      if (!savedHub || !savedHub.port || !savedHub.csrfToken) return;
      const hubStartedAtSec = Number(savedHub.startedAt || savedHub.updatedAt || 0);
      const firstForHubBoot =
        hubStartedAtSec > 0 && headlessBridgeState.lastBootCheckedHubStartedAt !== hubStartedAtSec;
      const candidateIds = findActiveCascadesFromDiskTranscripts(Date.now(), {
        maxInterruptedAgeMs: 86400 * 1000,
        hubStartedAtSec
      });
      const res = await checkAndResumeInterruptedCascades(headlessBridgeState, {
        candidateIds: Array.isArray(candidateIds) ? candidateIds : [],
        includeIdleSummaries: true,
        hubStartedAtSec,
        logFn: (line) => log(line.includes('Send failed') ? `[WARN] ${line}` : `[INFO] ${line}`),
        ...(firstForHubBoot ? { bypassMinAge: true } : {})
      });
      if (firstForHubBoot && !res?.skippedInFlight) {
        headlessBridgeState.lastBootCheckedHubStartedAt = hubStartedAtSec;
      }
      if (res && res.resumed > 0) {
        log(
          `[INFO] Headless 24/7 daemon auto-resumed ${res.resumed} cascade(s) while VS Code is closed`
        );
      }
      if (Array.isArray(res?.circuitBroken) && res.circuitBroken.length > 0) {
        log(
          `[WARN] Auto-resume circuit breaker halted ${res.circuitBroken.length} cascade(s): ${res.circuitBroken.join(', ')}`
        );
      }
    } catch {}
  }

  function syncDirectActiveStamp(count) {
    if (once || process.env.THEO_SMOKE_TEST === '1') return;
    try {
      const stampPath = path.join(CLAUDE_DIR, '.theo-direct-active.json');
      const n = Number(count || 0);
      if (n <= 0) {
        if (fs.existsSync(stampPath)) fs.unlinkSync(stampPath);
        return;
      }
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
      const raw = JSON.stringify({ pid: process.pid, count: n, updatedAt: Date.now() });
      const tmpPath = `${stampPath}.${process.pid}.tmp`;
      try {
        fs.writeFileSync(tmpPath, raw, 'utf8');
        fs.renameSync(tmpPath, stampPath);
      } catch {
        try { fs.unlinkSync(tmpPath); } catch {}
        fs.writeFileSync(stampPath, raw, 'utf8');
      }
    } catch {}
  }

  async function runSync(reason, syncOpts = {}) {
    if (reason === 'service-host' && !bridge.hasAttachedVsCodeUi?.()) {
      await runHeadlessCascadeContinuity();
    }
    bridge.lastCloudError = '';
    const syncRes = await bridge.syncCloudRelay({ pushState: true, ...syncOpts });
    if (once) {
      console.log('[OK] Cloud Relay synced:', JSON.stringify(syncRes));
    } else if (!syncRes) {
      if (bridge.lastCloudError && bridge.lastCloudError !== lastErr) {
        lastErr = bridge.lastCloudError;
        log(`[WARN] keepalive sync (${reason}) failed: ${lastErr}`);
      }
    } else if (reason !== lastReason) {
      lastErr = '';
      log(`[INFO] keepalive syncing (${reason})`);
      lastReason = reason;
    }
  }

  let prepatchTickCount = 0;
  // Patching runs in a worker thread when bridge.js offers it, so this daemon keeps relaying the phone while a
  // bundle is rewritten.
  function maybePrepatchExtensions() {
    const runner =
      typeof prepatchInstalledExtensionsAsync === 'function'
        ? prepatchInstalledExtensionsAsync
        : prepatchInstalledExtensions;
    let pending;
    try {
      pending = Promise.resolve(runner(REPO_ROOT));
    } catch {
      return;
    }
    pending.then(logPrepatchResult).catch(() => {});
  }

  function logPrepatchResult(res) {
    try {
      if (res && res.checked !== false) {
        latestStandalonePrepatchRes = res;
      }
      if (Array.isArray(res?.updatedDirs) && res.updatedDirs.length > 0) {
        log(
          `[INFO] pre-patched updated extension(s): ${res.updatedDirs.map((d) => path.basename(d)).join(', ')}`
        );
      }
      if (Array.isArray(res?.errors) && res.errors.length > 0) {
        for (const err of res.errors) {
          log(`[WARN] pre-patch failed for ${path.basename(err.extensionDir)}: ${err.error}`);
        }
      }
    } catch {}
  }

  let lastBlindspotCheckAt = 0;
  let lastBlindspotSpawnAt = 0;
  let blindspotChildInFlight = false;
  let blindspotChildStartedAt = 0;
  let cloudMemSyncInFlight = false;
  let cloudMemSyncStartedAt = 0;
  let cutoverSetupChildInFlight = false;
  let cutoverSetupStartedAt = 0;
  let lastCutoverSetupAttemptAt = 0;
  const cloudDeletionSeenMap = new Map();
  isBackgroundChildBusy = () =>
    (blindspotChildInFlight && Date.now() - blindspotChildStartedAt < 40 * 60 * 1000) ||
    (cloudMemSyncInFlight && Date.now() - cloudMemSyncStartedAt < 90 * 1000) ||
    (cutoverSetupChildInFlight && Date.now() - cutoverSetupStartedAt < 5 * 60 * 1000) ||
    // A bundle patch in the worker thread must finish before a respawn exits this process.
    (typeof isBridgePatchWorkerBusy === 'function' && isBridgePatchWorkerBusy());

  function maybeMigratePostBootstrapSetup(syncRes) {
    if (once || process.env.THEO_SMOKE_TEST === '1') return;
    const nowMs = Date.now();
    if (cutoverSetupChildInFlight && nowMs - cutoverSetupStartedAt < 5 * 60 * 1000) return;
    if (nowMs - lastCutoverSetupAttemptAt < 10 * 60 * 1000 && syncRes?.mode !== 'bootstrap') return;

    const homeDir = os.homedir();
    const bhfMem = path.join(homeDir, 'bhfirms', 'memory');
    const setupPy = path.join(bhfMem, 'Admin', 'theo-pc-setup.py');
    if (!fs.existsSync(path.join(bhfMem, 'THEO.md')) || !fs.existsSync(setupPy)) return;

    let needsMigrate = Boolean(syncRes && syncRes.mode === 'bootstrap');
    if (!needsMigrate) {
      try {
        const claudePtr = path.join(homeDir, '.claude', 'CLAUDE.md');
        const guardHook = path.join(homeDir, '.claude', 'hooks', 'bhfirms-memory-guard.py');
        const shortcutStamp = path.join(homeDir, '.theo', 'pc-setup-shortcut.json');
        if (!fs.existsSync(claudePtr) || /onedrive/i.test(fs.readFileSync(claudePtr, 'utf8'))) {
          needsMigrate = true;
        } else if (!fs.existsSync(guardHook) || !fs.readFileSync(guardHook, 'utf8').includes('bhfirms')) {
          needsMigrate = true;
        } else if (
          process.platform === 'win32' &&
          (!fs.existsSync(shortcutStamp) || /onedrive/i.test(fs.readFileSync(shortcutStamp, 'utf8')))
        ) {
          needsMigrate = true;
        }
      } catch {
        needsMigrate = true;
      }
    }
    if (!needsMigrate) return;

    const pyExe = findLocalPythonExe();
    if (!pyExe) return;
    try {
      lastCutoverSetupAttemptAt = nowMs;
      cutoverSetupChildInFlight = true;
      cutoverSetupStartedAt = nowMs;
      const sessionApplyIds = resolveSessionApplyStepIds(bhfMem);
      const child = spawn(
        pyExe,
        [
          setupPy,
          '--apply',
          '--only',
          sessionApplyIds.join(',')
        ],
        {
          detached: /pythonw\.exe$/i.test(pyExe),
          windowsHide: true,
          stdio: 'ignore'
        }
      );
      const clearSetup = () => {
        cutoverSetupChildInFlight = false;
      };
      child.on('exit', clearSetup);
      child.on('error', clearSetup);
      child.unref();
      log('[INFO] triggered post-cutover PC setup migration');
    } catch {
      cutoverSetupChildInFlight = false;
    }
  }

  function maybeSyncMemoryCloudVault() {
    if (
      once ||
      process.env.THEO_SMOKE_TEST === '1' ||
      process.env.THEO_DISABLE_MEMORY_CLOUD_SYNC === '1'
    ) {
      return;
    }
    const nowMs = Date.now();
    if (cloudMemSyncInFlight && nowMs - cloudMemSyncStartedAt < 90 * 1000) return;
    let cloudSyncMod = null;
    try {
      cloudSyncMod = require('./memory_cloud_sync.cjs');
    } catch {
      return;
    }
    if (!cloudSyncMod || typeof cloudSyncMod.runCloudSync !== 'function') return;
    let syncMode = 'pull-if-changed';
    try {
      if (typeof cloudSyncMod.detectLocalVaultDrift === 'function') {
        const drift = cloudSyncMod.detectLocalVaultDrift({
          quietMs: 15 * 1000,
          nowMs,
          deletionSeenMap: cloudDeletionSeenMap
        });
        if (drift && drift.settled) {
          syncMode = 'sync';
        }
      }
    } catch {}
    cloudMemSyncInFlight = true;
    cloudMemSyncStartedAt = nowMs;
    Promise.resolve()
      .then(() => cloudSyncMod.runCloudSync({ mode: syncMode }))
      .then((res) => {
        if (res && res.ok) {
          if (
            !res.unchanged &&
            (res.pulledCount > 0 || res.pushedCount > 0 || res.deletedLocalCount > 0 || res.deletedCloudCount > 0 || res.mergedCount > 0)
          ) {
            log(
              `[INFO] memory cloud vault synced (rev ${res.rev}, mode=${res.mode || syncMode}): pulled=${res.pulledCount}, pushed=${res.pushedCount}` +
                (res.mergedCount > 0 ? `, line-merged=${res.mergedCount}` : '')
            );
          }
          maybeMigratePostBootstrapSetup(res);
        }
      })
      .catch(() => {})
      .finally(() => {
        cloudMemSyncInFlight = false;
      });
  }

  function currentIsoWeekLocal(nowDate = new Date()) {
    const d = new Date(Date.UTC(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate()));
    const isoDay = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - isoDay);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
    return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
  }

  function maybeTriggerWeeklyBlindspotReview() {
    if (once || process.platform !== 'win32') return;
    // Wait until initial keepalive ticks have synced `bridge.cloudControlDocs` from THEO Store.
    if (prepatchTickCount < 6) return;
    const nowMs = Date.now();
    if (blindspotChildInFlight && nowMs - blindspotChildStartedAt < 40 * 60 * 1000) return;
    blindspotChildInFlight = false;
    if (nowMs - lastBlindspotCheckAt < 30 * 60 * 1000) return;
    lastBlindspotCheckAt = nowMs;
    if (nowMs - lastBlindspotSpawnAt < 2 * 60 * 60 * 1000) return;

    const nowDate = new Date(nowMs);
    if (nowDate.getDay() === 1 && nowDate.getHours() < 8) return;

    const curWeek = currentIsoWeekLocal(nowDate);
    const homeDir = os.homedir();
    const stateFile = path.join(homeDir, '.theo', 'blindspot-review-state.json');
    let localState = {};
    try {
      if (fs.existsSync(stateFile)) {
        localState = JSON.parse(fs.readFileSync(stateFile, 'utf8')) || {};
      }
    } catch {}

    const hasPendingWork = Boolean(localState.pending || localState.gitPending);
    if (!hasPendingWork && localState.lastWeek === curWeek) return;
    const cloudLastWeek = String(bridge.cloudControlDocs?.blindspot_review?.lastWeek || '');
    if (!hasPendingWork && cloudLastWeek && cloudLastWeek >= curWeek) return;

    const memPaths = resolveTheoMemoryPaths({ homeDir });
    const reviewRoot =
      memPaths.memoryRoot ||
      path.join(homeDir, 'bhfirms', 'memory');
    const reviewScript = path.join(reviewRoot, 'Admin', 'theo-blindspot-review.py');
    if (!fs.existsSync(reviewScript)) return;
    const pyExe = findLocalPythonExe();
    if (!pyExe) return;

    try {
      lastBlindspotSpawnAt = nowMs;
      blindspotChildInFlight = true;
      blindspotChildStartedAt = nowMs;
      const child = spawn(pyExe, [reviewScript], {
        detached: /pythonw\.exe$/i.test(pyExe),
        windowsHide: true,
        stdio: 'ignore'
      });
      const clearInFlight = () => {
        blindspotChildInFlight = false;
      };
      child.on('exit', clearInFlight);
      child.on('error', clearInFlight);
      child.unref();
      log(`[INFO] triggered weekly blind-spot review check (${curWeek})`);
    } catch {
      blindspotChildInFlight = false;
    }
  }

  async function tick() {
    if (tickInFlight || respawnTriggered) return;
    tickInFlight = true;
    try {
      prepatchTickCount += 1;
      if (prepatchTickCount === 1 || prepatchTickCount % 3 === 0) {
        maybePrepatchExtensions();
      }
      if (!once && (prepatchTickCount === 2 || prepatchTickCount % 12 === 0)) {
        checkPcSetupStatus().catch(() => {});
      }
      if (!once && (prepatchTickCount === 3 || prepatchTickCount % 12 === 3)) {
        maybeSyncMemoryCloudVault();
      }
      maybeTriggerWeeklyBlindspotReview();
      if (!once) {
        try {
          if (fs.existsSync(PID_FILE)) {
            const ownerPid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim() || 0);
            if (ownerPid && ownerPid !== process.pid && isPidAlive(ownerPid)) {
              process.exit(0);
              return;
            }
          }
        } catch {}
        const childStillRunning =
          isBackgroundChildBusy() || (bridge.directRunner?.getActiveRuns?.().length || 0) > 0;
        if (
          !childStillRunning &&
          (pendingSelfUpdateInfo || computeDiskMaxMtime() > bootMtime + 2000)
        ) {
          const deferredInfo = pendingSelfUpdateInfo;
          pendingSelfUpdateInfo = null;
          respawnSelfAndExit(deferredInfo);
          return;
        }
      }

      if (once) {
        await runSync('once');
        return;
      }

      syncDirectActiveStamp(bridge.directRunner?.getActiveRuns?.().length || 0);

      if (bridge.listening) {
        // Start standalone Antigravity engine when no VS Code window UI is attached on this PC.
        if (
          !bridge.hasAttachedVsCodeUi?.() &&
          process.env.THEO_SMOKE_TEST !== '1' &&
          process.env.THEO_DISABLE_AGY_ENGINE_START !== '1'
        ) {
          ensureStandaloneAgyEngine().catch(() => {});
        }
        await runSync('service-host');
        return;
      }

      if (!bridge.server) {
        bridge.disposed = false;
        bridge.startHttpServer();
        if (bridge.server) {
          bridge.server.once('listening', () => {
            log('[INFO] Service bound :4318 + Edge Relay (single-service owner)');
          });
          await new Promise((resolve) => {
            if (bridge.listening || !bridge.server) {
              resolve();
              return;
            }
            let doneFired = false;
            const done = () => {
              if (doneFired) return;
              doneFired = true;
              clearTimeout(waitTimer);
              resolve();
            };
            const waitTimer = setTimeout(done, 450);
            if (typeof waitTimer.unref === 'function') waitTimer.unref();
            bridge.server.once('listening', done);
            bridge.server.once('error', done);
          });
        }
      }
      let allowStandby = false;
      if (!bridge.listening) {
        const ping = await httpJson('http://localhost:4318/api/ping', { timeoutMs: 1500 }).catch(
          () => ({})
        );
        const syncAge = Date.now() - Number(ping?.lastCloudSyncAt || 0);
        if (!ping?.ok || ping.standaloneMode !== true || syncAge > 25000) {
          allowStandby = true;
        }
      }
      await runSync('service-host', allowStandby ? { allowStandby: true } : {});
    } catch (err) {
      if (once) {
        console.error('[ERR]', err.message);
      } else {
        log(`[ERR] ${err.message}`);
      }
    } finally {
      tickInFlight = false;
    }
  }

  log(`[INFO] keepalive daemon started (pid ${process.pid}, bootMtime ${bootMtime})`);
  await tick();
  if (!once) {
    setInterval(tick, 5000);
  }
}

const isDirectEntry =
  require.main === module ||
  Boolean(require.main && path.basename(require.main.filename || '') === 'theo_agent.cjs');
if (isDirectEntry && process.env.THEO_SMOKE_TEST !== '1') {
  main();
}

module.exports = {
  DEFAULT_SESSION_APPLY_STEP_IDS,
  resolveSessionApplyStepIds,
  resolveTheoMemoryPaths,
  findLocalPythonExe,
  findLocalConsolePythonExe,
  buildStandaloneState,
  attachKeepaliveStateBuilder,
  attachKeepaliveCommandProxy,
  makeStandaloneHub,
  launchEngineOutsideJob,
  enginePortFilterScript,
  ensureStandaloneAgyEngine,
  buildAgyEngineLaunch,
  isLoopbackPortRefused
};
