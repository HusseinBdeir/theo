const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const https = require('https');
const net = require('net');
const os = require('os');
const path = require('path');
const { spawn, execFile } = require('child_process');
const {
  TheoRemoteBridge,
  formatModelDisplayName,
  inferMaxContextTokens,
  inferSoftAndHardContextLimits,
  buildCompactModelCatalogForClient
} = require('../remote');
const { AntigravityDataStore } = require('../store');
const { HubStateStore } = require('../state');
const { SessionActivityTracker } = require('../activity');
const { AccountVaultManager } = require('../accounts');
const {
  prepatchInstalledExtensions,
  prepatchInstalledExtensionsAsync,
  isBridgePatchWorkerBusy
} = require('../bridge');
const {
  checkAndResumeInterruptedCascades,
  findActiveCascadesFromDiskTranscripts,
  readPersistentHubState,
  writePersistentHubState,
  ensureExpectedAntigravityKeyringSync,
  ensureAntigravityTelemetryDisabled
} = require('../compat/antigravity-hub-bridge.cjs');
const {
  loadTheoCredentials,
  deriveEdgeAuthToken,
  inferRowOwnerDevice,
  resolveRowPinState,
  resolveAgyBinaryPath,
  isLegacyVsCodePhoneBridgeEnabled,
  ensureServiceCutoverStatsInitialized
} = require('../device-identity');
const { checkPcSetupStatus, readCachedPcSetupSummary } = require('../pc-setup');
const {
  readUnsavedWorkSummary,
  readFleetUnsavedWorkSummary,
  refreshUnsavedWork
} = require('../unsaved-work');
const { readHotSwapHoldStatus } = require('../bundle-updater');
const { isClaudeDesktopScratchPath } = require('../data');

const REPO_ROOT = path.resolve(__dirname, '..');
const CLAUDE_DIR = path.join(os.homedir(), '.claude');
const PID_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.pid');
const META_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.json');
const LOG_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.log');
const LAST_STATE_CACHE_FILE = path.join(CLAUDE_DIR, '.theo-last-state.json');
const HUB_STATE_FILE = path.join(CLAUDE_DIR, '.theo-hub-state.json');

const MEMORY_GIT_IDLE_QUIET_MS = 10 * 60 * 1000;
const MEMORY_GIT_POLL_MS = 60 * 1000;
const MEMORY_GIT_BOOT_DELAY_MS = 30 * 1000;
const MEMORY_GIT_MIN_SPAWN_GAP_MS = 30 * 1000;
const MEMORY_GIT_CHILD_TIMEOUT_MS = 10 * 60 * 1000;
const MEMORY_GIT_LOCK_STALE_MS = 1500 * 1000;
const MEMORY_GIT_RETRY_BACKOFF_MS = [
  2 * 60 * 1000,
  5 * 60 * 1000,
  15 * 60 * 1000,
  30 * 60 * 1000
];
const MEMORY_GIT_IGNORED_DIRS = new Set([
  '.git',
  '.claude',
  '.vscode',
  '.wrangler',
  'node_modules',
  '_archive',
  'tmp',
  'scratchpad',
  'output',
  '__pycache__'
]);
const MEMORY_GIT_PRIVATE_STEMS = [
  'bank-kyc-ali-bdeir',
  'user-passports-antigua-lebanon'
];

let cachedGitIgnoreMeta = { filePath: '', mtimeMs: -1, size: -1, rules: [] };

function globPatternToRegExp(globPat) {
  let out = '^';
  for (let i = 0; i < globPat.length; i += 1) {
    const ch = globPat[i];
    if (ch === '*') {
      if (globPat[i + 1] === '*' && globPat[i + 2] === '/') {
        out += '(?:.*/)?';
        i += 2;
      } else if (globPat[i + 1] === '*') {
        out += '.*';
        i += 1;
      } else {
        out += '[^/]*';
      }
    } else if (ch === '?') {
      out += '[^/]';
    } else if ('\\.^$+()[]{}|'.includes(ch)) {
      out += `\\${ch}`;
    } else {
      out += ch;
    }
  }
  out += '$';
  return new RegExp(out, 'i');
}

function loadSimpleGitIgnoreRules(memoryRoot) {
  if (!memoryRoot) return [];
  const filePath = path.join(memoryRoot, '.gitignore');
  try {
    if (!fs.existsSync(filePath)) return [];
    const st = fs.lstatSync(filePath);
    if (!st.isFile() || st.size <= 0 || st.size > 16384) return [];
    const mtimeMs = Math.floor(st.mtimeMs);
    if (
      cachedGitIgnoreMeta.filePath === filePath &&
      cachedGitIgnoreMeta.mtimeMs === mtimeMs &&
      cachedGitIgnoreMeta.size === st.size
    ) {
      return cachedGitIgnoreMeta.rules;
    }
    const raw = fs.readFileSync(filePath, 'utf8');
    const rules = [];
    for (const rawLine of raw.split(/\r?\n/)) {
      const trimmed = rawLine.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const negated = trimmed.startsWith('!');
      const rawPat = negated ? trimmed.slice(1).trim() : trimmed;
      if (!rawPat) continue;
      const anchored = rawPat.startsWith('/');
      const dirOnly = rawPat.endsWith('/');
      const body = (dirOnly ? rawPat.slice(0, -1) : rawPat).replace(/^\//, '');
      if (!body) continue;
      const hasSlash = anchored || body.includes('/');
      rules.push({
        negated,
        dirOnly,
        hasSlash,
        re: globPatternToRegExp(body)
      });
    }
    cachedGitIgnoreMeta = { filePath, mtimeMs, size: st.size, rules };
    return rules;
  } catch {
    return [];
  }
}

function isIgnoredMemoryGitEntry(relPosix, baseName, isDir, extraRules = null) {
  const baseLower = String(baseName || '').toLowerCase();
  const relLower = String(relPosix || '').replace(/\\/g, '/').replace(/^\/+/, '').toLowerCase();
  if (!baseLower || baseLower === '.git') return true;
  if (relLower === 'private' || relLower.startsWith('private/')) return true;
  for (const stem of MEMORY_GIT_PRIVATE_STEMS) {
    if (relLower.includes(stem)) return true;
  }
  if (baseLower.includes('.bak')) return true;
  if (isDir) {
    if (MEMORY_GIT_IGNORED_DIRS.has(baseLower)) return true;
  } else {
    if (/\.(zip|pdf|docx?|xls[xmb]?|pptx?)$/i.test(baseLower)) {
      return true;
    }
    if (/^admin\/[^/]+\.(csv|log)$/i.test(relPosix)) return true;
  }
  let ignored = false;
  if (Array.isArray(extraRules)) {
    for (const rule of extraRules) {
      if (rule.dirOnly && !isDir) continue;
      const target = rule.hasSlash ? relLower : baseLower;
      if (rule.re.test(target)) {
        ignored = !rule.negated;
      }
    }
  }
  return ignored;
}

function resolveTheoMemoryPaths(opts = {}) {
  const env = opts.env || process.env;
  const sandboxHome = String(env.THEO_GUARD_HOME || env.THEO_SETUP_HOME || '').trim();
  const sandboxed = Boolean(opts.sandboxed || sandboxHome);
  const homeDir = opts.homeDir || sandboxHome || os.homedir();
  const overrideRoot = String(opts.memoryRoot || env.THEO_MEMORY_ROOT || '').trim();
  let memoryRoot = '';
  if (overrideRoot) {
    if (fs.existsSync(path.join(overrideRoot, 'THEO.md'))) {
      memoryRoot = overrideRoot;
    }
  } else {
    // THEO memory lives only at ~/bhfirms/memory (moved off OneDrive 2026-11-11).
    const bhfMem = path.join(homeDir, 'bhfirms', 'memory');
    if (fs.existsSync(path.join(bhfMem, 'THEO.md'))) {
      memoryRoot = bhfMem;
    }
  }
  const gitDir =
    String(opts.gitDir || env.THEO_MEMORY_GITDIR || '').trim() ||
    path.join(homeDir, '.gitdirs', 'claude-memory');
  const stateFile =
    String(opts.stateFile || '').trim() ||
    path.join(homeDir, '.claude', '.theo-memory-git-idle.json');
  return { homeDir, memoryRoot, gitDir, stateFile, sandboxed };
}

function scanTrackedMemoryTree(memoryRoot) {
  const empty = {
    ok: false,
    fileCount: 0,
    latestFileMtimeMs: 0,
    latestDirMtimeMs: 0,
    treeSig: '',
    pathsSig: '',
    fileSigMap: new Map()
  };
  if (!memoryRoot || !fs.existsSync(path.join(memoryRoot, 'THEO.md'))) {
    return empty;
  }
  const extraRules = loadSimpleGitIgnoreRules(memoryRoot);
  const entries = [];
  let latestFileMtimeMs = 0;
  let latestDirMtimeMs = 0;
  try {
    try {
      latestDirMtimeMs = Math.floor(fs.lstatSync(memoryRoot).mtimeMs);
    } catch {}
    const walk = (dirPath, relPrefix, depth) => {
      if (depth > 16) return;
      let dirItems;
      try {
        dirItems = fs.readdirSync(dirPath, { withFileTypes: true });
      } catch (err) {
        if (err && err.code === 'ENOENT' && depth > 0) return;
        throw err;
      }
      for (const item of dirItems) {
        const name = item.name;
        const relPosix = relPrefix ? `${relPrefix}/${name}` : name;
        if (item.isSymbolicLink()) continue;
        const fullPath = path.join(dirPath, name);
        let st;
        try {
          st = fs.lstatSync(fullPath);
        } catch (err) {
          if (err && err.code === 'ENOENT') continue;
          throw err;
        }
        if (st.isSymbolicLink()) continue;
        if (st.isDirectory()) {
          if (isIgnoredMemoryGitEntry(relPosix, name, true, extraRules)) continue;
          const dirMtime = Math.floor(st.mtimeMs);
          if (dirMtime > latestDirMtimeMs) latestDirMtimeMs = dirMtime;
          walk(fullPath, relPosix, depth + 1);
        } else if (st.isFile()) {
          if (isIgnoredMemoryGitEntry(relPosix, name, false, extraRules)) continue;
          const mtimeMs = Math.floor(st.mtimeMs);
          if (mtimeMs > latestFileMtimeMs) latestFileMtimeMs = mtimeMs;
          entries.push({ relPosix, size: st.size, mtimeMs });
        }
      }
    };
    walk(memoryRoot, '', 0);
  } catch {
    return empty;
  }
  if (entries.length === 0) {
    return empty;
  }
  entries.sort((a, b) => (a.relPosix < b.relPosix ? -1 : a.relPosix > b.relPosix ? 1 : 0));
  const hash = crypto.createHash('sha256');
  const pathsHash = crypto.createHash('sha256');
  const fileSigMap = new Map();
  for (const e of entries) {
    hash.update(`${e.relPosix}\0${e.size}\0${e.mtimeMs}\n`, 'utf8');
    pathsHash.update(`${e.relPosix}\n`, 'utf8');
    fileSigMap.set(e.relPosix, { size: e.size, mtimeMs: e.mtimeMs });
  }
  return {
    ok: true,
    fileCount: entries.length,
    latestFileMtimeMs,
    latestDirMtimeMs,
    treeSig: hash.digest('hex'),
    pathsSig: pathsHash.digest('hex'),
    fileSigMap
  };
}

function readMemoryGitRefs(gitDir, nowMs = Date.now()) {
  const empty = {
    initialized: false,
    headSha: '',
    mainSha: '',
    originMainSha: '',
    hasPreOriginRef: false,
    mainRefMtimeMs: 0,
    lockActive: false,
    lastAutoLogMtimeMs: 0,
    lastAutoExitCode: null
  };
  if (!gitDir || !fs.existsSync(path.join(gitDir, 'HEAD'))) {
    return empty;
  }
  let packedMap = null;
  const loadPacked = () => {
    if (packedMap !== null) return packedMap;
    packedMap = new Map();
    const packedPath = path.join(gitDir, 'packed-refs');
    try {
      if (fs.existsSync(packedPath)) {
        const lines = fs.readFileSync(packedPath, 'utf8').split(/\r?\n/);
        for (const raw of lines) {
          const ln = raw.trim();
          if (!ln || ln.startsWith('#') || ln.startsWith('^')) continue;
          const sp = ln.indexOf(' ');
          if (sp === 40) {
            const sha = ln.slice(0, 40).toLowerCase();
            const ref = ln.slice(41).trim();
            if (/^[0-9a-f]{40}$/.test(sha) && ref) {
              packedMap.set(ref, sha);
            }
          }
        }
      }
    } catch {}
    return packedMap;
  };
  const resolveRef = (refName, depth = 0) => {
    if (!refName || depth > 4) return '';
    const loosePath = path.join(gitDir, ...refName.split('/'));
    try {
      if (fs.existsSync(loosePath)) {
        const val = fs.readFileSync(loosePath, 'utf8').trim();
        if (val.startsWith('ref:')) {
          return resolveRef(val.slice(4).trim(), depth + 1);
        }
        if (/^[0-9a-f]{40}$/i.test(val)) {
          return val.toLowerCase();
        }
      }
    } catch {}
    return loadPacked().get(refName) || '';
  };

  const headSha = resolveRef('HEAD');
  const mainSha = resolveRef('refs/heads/main');
  const originMainSha = resolveRef('refs/remotes/origin/main');
  const hasPreOriginRef = Boolean(resolveRef('refs/theo-backup/pre-origin'));
  const mainRefMtimeMs = Math.max(
    getFileMtimeMs(path.join(gitDir, 'refs', 'heads', 'main')),
    getFileMtimeMs(path.join(gitDir, 'logs', 'refs', 'heads', 'main')),
    getFileMtimeMs(path.join(gitDir, 'logs', 'HEAD'))
  );

  let lockActive = false;
  const lockPath = path.join(gitDir, 'theo-sync.lock');
  try {
    if (fs.existsSync(lockPath)) {
      const st = fs.statSync(lockPath);
      const ageMs = nowMs - Math.floor(st.mtimeMs);
      if (ageMs <= 1000) {
        lockActive = true;
      } else if (ageMs < MEMORY_GIT_LOCK_STALE_MS) {
        const headTok = fs.readFileSync(lockPath, 'utf8').slice(0, 64).trim().split(/\s+/)[0] || '';
        if (/^\d+$/.test(headTok)) {
          const lockPid = Number(headTok);
          lockActive = lockPid === process.pid || isPidAlive(lockPid);
        } else {
          lockActive = true;
        }
      }
    }
  } catch {}

  let lastAutoLogMtimeMs = 0;
  let lastAutoExitCode = null;
  const autoLogPath = path.join(gitDir, 'last-auto-sync.log');
  try {
    if (fs.existsSync(autoLogPath)) {
      lastAutoLogMtimeMs = Math.floor(fs.statSync(autoLogPath).mtimeMs);
      const firstLine =
        (fs.readFileSync(autoLogPath, 'utf8').split(/\r?\n/).find((l) => l.trim()) || '').trim();
      const m = /\bexit=(-?\d+)\b/.exec(firstLine);
      if (m) {
        lastAutoExitCode = Number(m[1]);
      }
    }
  } catch {}

  return {
    initialized: true,
    headSha,
    mainSha,
    originMainSha,
    hasPreOriginRef,
    mainRefMtimeMs,
    lockActive,
    lastAutoLogMtimeMs,
    lastAutoExitCode
  };
}

function collectPythonCandidateDirs(homeDir) {
  const dirsOut = [path.join(homeDir, '.local', 'python312')];
  if (process.platform === 'win32') {
    dirsOut.push('C:\\Python314', 'C:\\Python313', 'C:\\Python312');
    const programRoots = [];
    if (process.env.LOCALAPPDATA) {
      programRoots.push(path.join(process.env.LOCALAPPDATA, 'Programs', 'Python'));
    }
    if (process.env.ProgramFiles) programRoots.push(process.env.ProgramFiles);
    if (process.env['ProgramFiles(x86)']) programRoots.push(process.env['ProgramFiles(x86)']);
    for (const rootDir of programRoots) {
      try {
        if (fs.existsSync(rootDir)) {
          const subs = fs
            .readdirSync(rootDir, { withFileTypes: true })
            .filter((e) => e.isDirectory() && /^Python3/i.test(e.name))
            .map((e) => e.name)
            .sort()
            .reverse();
          for (const sub of subs) {
            dirsOut.push(path.join(rootDir, sub));
          }
        }
      } catch {}
    }
  }
  for (const pathEntry of String(process.env.PATH || '').split(path.delimiter)) {
    const cleanDir = pathEntry.trim();
    if (!cleanDir || /windowsapps/i.test(cleanDir)) continue;
    dirsOut.push(cleanDir);
  }
  return dirsOut;
}

function findLocalPythonExe(homeDir = os.homedir()) {
  const names =
    process.platform === 'win32' ? ['pythonw.exe', 'python.exe'] : ['python3', 'python'];
  for (const dir of collectPythonCandidateDirs(homeDir)) {
    for (const name of names) {
      const exe = path.join(dir, name);
      try {
        if (!/windowsapps/i.test(exe) && fs.existsSync(exe)) return exe;
      } catch {}
    }
  }
  return '';
}

function findLocalConsolePythonExe(homeDir = os.homedir()) {
  const names =
    process.platform === 'win32' ? ['python.exe', 'pythonw.exe'] : ['python3', 'python'];
  for (const dir of collectPythonCandidateDirs(homeDir)) {
    for (const name of names) {
      const exe = path.join(dir, name);
      try {
        if (!/windowsapps/i.test(exe) && fs.existsSync(exe)) return exe;
      } catch {}
    }
  }
  return '';
}

function writeJsonAtomic(filePath, obj) {
  const dir = path.dirname(filePath);
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  try {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const payload = JSON.stringify(obj, null, 2) + '\n';
    fs.writeFileSync(tmp, payload, 'utf8');
    try {
      fs.renameSync(tmp, filePath);
    } catch {
      fs.writeFileSync(filePath, payload, 'utf8');
      try {
        fs.unlinkSync(tmp);
      } catch {}
    }
  } catch {
    try {
      if (fs.existsSync(tmp)) fs.unlinkSync(tmp);
    } catch {}
  }
}

function isValidMemoryGitScript(scriptPath) {
  try {
    if (!scriptPath || !fs.existsSync(scriptPath)) return false;
    const raw = fs.readFileSync(scriptPath, 'utf8');
    return raw.includes('__main__') && raw.includes('def main(');
  } catch {
    return false;
  }
}

function createMemoryGitIdleSyncController(options = {}) {
  const nowFn = typeof options.nowFn === 'function' ? options.nowFn : () => Date.now();
  const logFn = typeof options.logFn === 'function' ? options.logFn : () => {};
  const quietThresholdMs =
    typeof options.quietThresholdMs === 'number'
      ? options.quietThresholdMs
      : MEMORY_GIT_IDLE_QUIET_MS;
  const pollMs = typeof options.pollMs === 'number' ? options.pollMs : MEMORY_GIT_POLL_MS;
  const bootDelayMs =
    typeof options.bootDelayMs === 'number' ? options.bootDelayMs : MEMORY_GIT_BOOT_DELAY_MS;
  const minSpawnGapMs =
    typeof options.minSpawnGapMs === 'number'
      ? options.minSpawnGapMs
      : MEMORY_GIT_MIN_SPAWN_GAP_MS;
  const childTimeoutMs =
    typeof options.childTimeoutMs === 'number'
      ? options.childTimeoutMs
      : MEMORY_GIT_CHILD_TIMEOUT_MS;
  const retryBackoffMs =
    Array.isArray(options.retryBackoffMs) && options.retryBackoffMs.length > 0
      ? options.retryBackoffMs
      : MEMORY_GIT_RETRY_BACKOFF_MS;

  const initialPaths = resolveTheoMemoryPaths(options);
  const persisted = readJsonSafe(initialPaths.stateFile, {});
  const state = {
    lastCleanTreeSig: String(persisted.lastCleanTreeSig || ''),
    lastCleanPathsSig: String(persisted.lastCleanPathsSig || ''),
    lastCleanHead: String(persisted.lastCleanHead || ''),
    lastCleanOriginMain: String(persisted.lastCleanOriginMain || ''),
    lastCommittedTreeSig: String(persisted.lastCommittedTreeSig || ''),
    lastCommittedPathsSig: String(persisted.lastCommittedPathsSig || ''),
    lastCommittedHead: String(persisted.lastCommittedHead || ''),
    lastAttemptAt: Number(persisted.lastAttemptAt || 0),
    lastAttemptTreeSig: String(persisted.lastAttemptTreeSig || ''),
    lastAttemptHead: String(persisted.lastAttemptHead || ''),
    lastAttemptOriginMain: String(persisted.lastAttemptOriginMain || ''),
    lastExitCode: typeof persisted.lastExitCode === 'number' ? persisted.lastExitCode : 0,
    consecutiveUnconverged: Number(persisted.consecutiveUnconverged || 0)
  };

  const bootedAt = nowFn();
  let lastPollAt = 0;
  let lastObservedTreeSig = '';
  let lastObservedAt = 0;
  let lastObservedFileMap = null;
  let lastTreeChangeDetectedAt = 0;
  let wasCloudReachable = null;
  let cloudRecoveredAt = 0;
  let childInFlight = false;
  let childStartedAt = 0;
  let activeChild = null;
  let inFlightPromise = null;

  function killHungChild(proc) {
    if (!proc) return;
    const pid = proc.pid;
    if (process.platform === 'win32' && pid) {
      execFile(
        'taskkill',
        ['/T', '/F', '/PID', String(pid)],
        { windowsHide: true, timeout: 10000 },
        () => {}
      );
    } else {
      try {
        proc.kill('SIGKILL');
      } catch {}
    }
  }

  function noteCloudConnectivity(isReachable, atMs = nowFn()) {
    const clean = Boolean(isReachable);
    const recovered = wasCloudReachable === false && clean === true;
    wasCloudReachable = clean;
    if (!clean) {
      cloudRecoveredAt = 0;
    } else if (recovered) {
      cloudRecoveredAt = atMs;
      lastPollAt = 0;
    }
    return recovered;
  }

  function isInFlight(atMs = nowFn()) {
    return childInFlight && atMs - childStartedAt < childTimeoutMs;
  }

  function maybeTick(atMs = nowFn(), tickOpts = {}) {
    const env = options.env || process.env;
    if (!options.allowInSmokeTest && env.THEO_SMOKE_TEST === '1') {
      return { action: 'disabled' };
    }
    if (env.THEO_DISABLE_MEMORY_GIT_IDLE === '1') {
      return { action: 'disabled' };
    }
    if (childInFlight) {
      if (atMs - childStartedAt < childTimeoutMs) {
        return { action: 'in-flight' };
      }
      logFn('[WARN] memory-git idle sync exceeded timeout -> terminating child');
      killHungChild(activeChild);
      activeChild = null;
      childInFlight = false;
    }

    const forcePoll = Boolean(tickOpts.forcePoll);
    if (!forcePoll && atMs - bootedAt < bootDelayMs) {
      return { action: 'boot-delay' };
    }

    const pendingRecovery = cloudRecoveredAt > state.lastAttemptAt;
    const cooldownActive =
      state.lastAttemptAt > 0 && atMs - state.lastAttemptAt < minSpawnGapMs;
    const pendingRecoveryReady = pendingRecovery && !cooldownActive;
    if (!forcePoll && !pendingRecoveryReady && lastPollAt > 0 && atMs - lastPollAt < pollMs) {
      return { action: 'throttled' };
    }
    lastPollAt = atMs;

    const paths = resolveTheoMemoryPaths({ ...options, env });
    if (!paths.memoryRoot) {
      cloudRecoveredAt = 0;
      return { action: 'no-memory-root' };
    }
    if (paths.sandboxed && !String(env.THEO_MEMORY_REMOTE || '').trim()) {
      cloudRecoveredAt = 0;
      return { action: 'sandbox-missing-remote' };
    }

    const refs = readMemoryGitRefs(paths.gitDir, atMs);
    if (refs.lockActive) {
      return { action: 'git-locked' };
    }

    const scan = scanTrackedMemoryTree(paths.memoryRoot);
    if (!scan.ok) {
      cloudRecoveredAt = 0;
      return { action: 'scan-error' };
    }

    const localCommitSha = refs.mainSha || refs.headSha;
    const refsConverged =
      Boolean(refs.mainSha) &&
      refs.headSha === refs.mainSha &&
      refs.mainSha === refs.originMainSha &&
      !refs.hasPreOriginRef;
    const refsOutOfSync = Boolean(localCommitSha) && !refsConverged;

    if (!lastObservedTreeSig) {
      const useCommittedBaseline =
        Boolean(localCommitSha) &&
        Boolean(state.lastCommittedHead) &&
        localCommitSha === state.lastCommittedHead &&
        Boolean(state.lastCommittedTreeSig);
      const baselineTreeSig = useCommittedBaseline
        ? state.lastCommittedTreeSig
        : state.lastCleanTreeSig;
      const baselinePathsSig = useCommittedBaseline
        ? state.lastCommittedPathsSig
        : state.lastCleanPathsSig;

      let detectedAt = scan.latestFileMtimeMs;
      if (!baselineTreeSig || scan.treeSig !== baselineTreeSig) {
        if (scan.latestDirMtimeMs > detectedAt && scan.latestDirMtimeMs <= atMs + 2000) {
          detectedAt = scan.latestDirMtimeMs;
        }
        if (
          baselinePathsSig &&
          scan.pathsSig !== baselinePathsSig &&
          detectedAt <= (state.lastAttemptAt || 0)
        ) {
          detectedAt = atMs;
        }
      }
      lastObservedTreeSig = scan.treeSig;
      lastObservedAt = atMs;
      lastObservedFileMap = scan.fileSigMap;
      lastTreeChangeDetectedAt = detectedAt;
    } else if (scan.treeSig !== lastObservedTreeSig) {
      let hasDeletion = false;
      if (lastObservedFileMap) {
        for (const rel of lastObservedFileMap.keys()) {
          if (!scan.fileSigMap.has(rel)) {
            hasDeletion = true;
            break;
          }
        }
      }
      let hasBackdatedChange = false;
      let maxChangedMtimeMs = 0;
      for (const [rel, cur] of scan.fileSigMap.entries()) {
        const prev = lastObservedFileMap ? lastObservedFileMap.get(rel) : null;
        if (!prev || prev.size !== cur.size || prev.mtimeMs !== cur.mtimeMs) {
          if (cur.mtimeMs < lastObservedAt) {
            hasBackdatedChange = true;
          }
          if (cur.mtimeMs > maxChangedMtimeMs) {
            maxChangedMtimeMs = cur.mtimeMs;
          }
        }
      }
      lastObservedTreeSig = scan.treeSig;
      lastObservedAt = atMs;
      lastObservedFileMap = scan.fileSigMap;
      lastTreeChangeDetectedAt =
        hasDeletion || hasBackdatedChange || maxChangedMtimeMs <= 0 ? atMs : maxChangedMtimeMs;
    } else {
      lastObservedAt = atMs;
    }

    const effectiveLastEditMs = Math.max(scan.latestFileMtimeMs, lastTreeChangeDetectedAt);
    const quietMs =
      effectiveLastEditMs > 0 ? Math.max(0, atMs - effectiveLastEditMs) : quietThresholdMs;

    if (
      refsConverged &&
      scan.treeSig === state.lastCleanTreeSig &&
      refs.mainSha === state.lastCleanHead &&
      refs.originMainSha === state.lastCleanOriginMain
    ) {
      cloudRecoveredAt = 0;
      return { action: 'clean' };
    }

    let diskMatchesLocalCommit = false;
    if (localCommitSha) {
      if (state.lastCommittedHead && localCommitSha === state.lastCommittedHead) {
        diskMatchesLocalCommit = scan.treeSig === state.lastCommittedTreeSig;
      } else if (state.lastCleanHead && localCommitSha === state.lastCleanHead) {
        diskMatchesLocalCommit = scan.treeSig === state.lastCleanTreeSig;
      } else if (refs.mainRefMtimeMs > 0) {
        const dirCleanAfterCommit =
          scan.latestDirMtimeMs <= 0 ||
          scan.latestDirMtimeMs > atMs + 2000 ||
          scan.latestDirMtimeMs <= refs.mainRefMtimeMs + 1000;
        diskMatchesLocalCommit =
          effectiveLastEditMs <= refs.mainRefMtimeMs + 1000 && dirCleanAfterCommit;
      }
    }

    const triggerAheadRefs = refsOutOfSync && diskMatchesLocalCommit;
    const diskDirtyOrUnverified =
      !triggerAheadRefs &&
      (!refsConverged ||
        scan.treeSig !== state.lastCleanTreeSig ||
        refs.mainSha !== state.lastCleanHead ||
        refs.originMainSha !== state.lastCleanOriginMain);
    const triggerIdleEdits = diskDirtyOrUnverified && quietMs >= quietThresholdMs;

    if (!triggerIdleEdits && !triggerAheadRefs) {
      cloudRecoveredAt = 0;
      return { action: 'waiting-quiet', quietMs };
    }

    if (cooldownActive) {
      return { action: 'cooldown' };
    }

    if (
      !pendingRecovery &&
      refs.lastAutoExitCode !== null &&
      refs.lastAutoExitCode !== 0 &&
      refs.lastAutoLogMtimeMs > state.lastAttemptAt &&
      atMs - refs.lastAutoLogMtimeMs < retryBackoffMs[0]
    ) {
      cloudRecoveredAt = 0;
      return { action: 'recent-external-failure' };
    }

    const sameAsLastAttempt =
      state.lastAttemptAt > 0 &&
      scan.treeSig === state.lastAttemptTreeSig &&
      localCommitSha === state.lastAttemptHead &&
      refs.originMainSha === state.lastAttemptOriginMain;
    if (sameAsLastAttempt && !pendingRecovery) {
      const idx = Math.min(
        Math.max(0, (state.consecutiveUnconverged || 1) - 1),
        retryBackoffMs.length - 1
      );
      const waitMs = retryBackoffMs[idx];
      if (atMs - state.lastAttemptAt < waitMs) {
        cloudRecoveredAt = 0;
        return { action: 'backoff', waitMs };
      }
    }

    const adminScript = path.join(paths.memoryRoot, 'Admin', 'bhfirms-memory-git.py');
    const hookScript = path.join(paths.homeDir, '.claude', 'hooks', 'bhfirms-memory-git.py');
    const scriptPath = isValidMemoryGitScript(adminScript)
      ? adminScript
      : isValidMemoryGitScript(hookScript)
        ? hookScript
        : '';
    const pyExe = options.pythonExe || findLocalConsolePythonExe(paths.homeDir);
    if (!scriptPath || !pyExe) {
      cloudRecoveredAt = 0;
      return { action: 'missing-runtime' };
    }

    cloudRecoveredAt = 0;
    const startedTreeSig = scan.treeSig;
    const startedPathsSig = scan.pathsSig;
    const triggerKind = triggerAheadRefs && !triggerIdleEdits ? 'ahead' : 'idle';
    state.lastAttemptAt = atMs;
    state.lastAttemptTreeSig = startedTreeSig;
    state.lastAttemptHead = localCommitSha;
    state.lastAttemptOriginMain = refs.originMainSha;
    writeJsonAtomic(paths.stateFile, state);

    const childEnv = {
      ...env,
      PYTHONUTF8: '1',
      PYTHONIOENCODING: 'utf-8',
      THEO_MEMORY_ROOT: paths.memoryRoot,
      THEO_MEMORY_GITDIR: paths.gitDir,
      THEO_MEMORY_AUTO_TRIGGER: triggerKind
    };
    const spawnCwd = fs.existsSync(paths.homeDir)
      ? paths.homeDir
      : path.dirname(paths.memoryRoot);

    try {
      childInFlight = true;
      childStartedAt = atMs;
      const child = spawn(pyExe, ['-B', scriptPath, '--auto'], {
        cwd: spawnCwd,
        env: childEnv,
        detached: false,
        windowsHide: true,
        stdio: 'ignore'
      });
      activeChild = child;
      inFlightPromise = new Promise((resolveDone) => {
        let settled = false;
        const finish = (exitCode) => {
          if (settled) return;
          settled = true;
          if (activeChild === child) {
            activeChild = null;
            childInFlight = false;
          }
          const doneMs = nowFn();
          const afterRefs = readMemoryGitRefs(paths.gitDir, doneMs);
          const afterLocalSha = afterRefs.mainSha || afterRefs.headSha;
          const afterConverged =
            Boolean(afterRefs.mainSha) &&
            afterRefs.headSha === afterRefs.mainSha &&
            afterRefs.mainSha === afterRefs.originMainSha &&
            !afterRefs.hasPreOriginRef;
          const numCode = typeof exitCode === 'number' ? exitCode : 1;
          state.lastAttemptHead = afterLocalSha;
          state.lastAttemptOriginMain = afterRefs.originMainSha;
          state.lastExitCode = numCode;
          if (numCode === 0 && afterConverged) {
            const pushedOrMoved =
              afterRefs.mainSha !== localCommitSha ||
              afterRefs.originMainSha !== refs.originMainSha;
            state.lastCleanTreeSig = startedTreeSig;
            state.lastCleanPathsSig = startedPathsSig;
            state.lastCleanHead = afterRefs.mainSha;
            state.lastCleanOriginMain = afterRefs.originMainSha;
            state.lastCommittedTreeSig = startedTreeSig;
            state.lastCommittedPathsSig = startedPathsSig;
            state.lastCommittedHead = afterRefs.mainSha;
            state.consecutiveUnconverged = 0;
            if (pushedOrMoved) {
              logFn(
                `[INFO] memory-git idle sync (${triggerKind}) converged at ${afterRefs.mainSha.slice(0, 7)}`
              );
            }
          } else if (numCode === 0 && !afterConverged) {
            state.consecutiveUnconverged = 0;
          } else {
            if (afterLocalSha && afterLocalSha !== localCommitSha) {
              state.lastCommittedTreeSig = startedTreeSig;
              state.lastCommittedPathsSig = startedPathsSig;
              state.lastCommittedHead = afterLocalSha;
            }
            state.consecutiveUnconverged = (state.consecutiveUnconverged || 0) + 1;
            if (numCode !== 0) {
              logFn(`[WARN] memory-git idle sync (${triggerKind}) exited ${numCode}`);
            }
          }
          writeJsonAtomic(paths.stateFile, state);
          resolveDone({ exitCode: numCode, state: { ...state } });
        };
        child.on('close', (code) => finish(code));
        child.on('error', () => finish(1));
      });
      return { action: 'spawned', trigger: triggerKind };
    } catch {
      activeChild = null;
      childInFlight = false;
      state.consecutiveUnconverged = (state.consecutiveUnconverged || 0) + 1;
      writeJsonAtomic(paths.stateFile, state);
      return { action: 'spawn-error' };
    }
  }

  function waitForInFlight() {
    return inFlightPromise || Promise.resolve({ exitCode: state.lastExitCode, state: { ...state } });
  }

  function getState() {
    return { ...state };
  }

  return {
    maybeTick,
    noteCloudConnectivity,
    isInFlight,
    waitForInFlight,
    getState
  };
}

function getFileMtimeMs(filePath) {
  try {
    return Math.floor(fs.statSync(filePath).mtimeMs);
  } catch {
    return 0;
  }
}

function computeDiskMaxMtime() {
  return Math.max(
    getFileMtimeMs(__filename),
    getFileMtimeMs(path.join(__dirname, 'memory_cloud_sync.cjs')),
    getFileMtimeMs(path.join(REPO_ROOT, 'remote.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'state.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'store.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'accounts.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'data.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'bridge.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'desktop-launcher.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'device-identity.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'pc-setup.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'unsaved-work.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'bundle-updater.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'ws-server.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'direct-runner.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'edge-relay-client.js'))
  );
}

function isPidAlive(pid) {
  const n = Number(pid || 0);
  if (!n || n <= 0 || n === process.pid) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch (err) {
    return err && err.code === 'EPERM';
  }
}

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try {
    if (!fs.existsSync(CLAUDE_DIR)) {
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    }
    if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 2 * 1024 * 1024) {
      fs.unlinkSync(LOG_FILE);
    }
    fs.appendFileSync(LOG_FILE, line, 'utf8');
  } catch {}
  if (process.argv.includes('--once')) {
    process.stderr.write(line);
  }
}

function httpJson(url, options = {}) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const isLocal =
      parsed.hostname === 'localhost' ||
      parsed.hostname === '127.0.0.1' ||
      parsed.hostname === '::1';
    const targetHost = parsed.hostname === 'localhost' ? '127.0.0.1' : parsed.hostname;
    let bearer = '';
    if (isLocal) {
      const creds = loadTheoCredentials();
      if (creds.effectiveEdgeSecret) {
        bearer = deriveEdgeAuthToken(creds.effectiveEdgeSecret);
      }
    }
    const bodyText = options.body ? String(options.body) : '';
    const req = http.request(
      {
        protocol: parsed.protocol,
        hostname: targetHost,
        port: parsed.port || 4318,
        path: `${parsed.pathname}${parsed.search}`,
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}),
          ...(bodyText ? { 'Content-Length': Buffer.byteLength(bodyText) } : {})
        },
        timeout: options.timeoutMs || 5000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          try {
            resolve(raw ? JSON.parse(raw) : {});
          } catch {
            resolve({ raw });
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error('Local bridge timeout')));
    req.on('error', reject);
    if (bodyText) req.write(bodyText);
    req.end();
  });
}

function fetchCloudMetaAgeMs(relayConfig) {
  return new Promise((resolve) => {
    let parsed;
    try {
      parsed = new URL(relayConfig.url);
    } catch {
      resolve(Infinity);
      return;
    }
    const body = JSON.stringify({ key: relayConfig.key, op: 'get_control' });
    const req = https.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: parsed.pathname + parsed.search,
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=UTF-8',
          'Content-Length': Buffer.byteLength(body)
        },
        timeout: 15000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          try {
            const j = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            const docs = j?.docs && typeof j.docs === 'object' ? j.docs : j || {};
            const stamp = Date.parse(docs?.meta?.updatedAt || '') || 0;
            resolve(stamp ? Date.now() - stamp : Infinity);
          } catch {
            resolve(Infinity);
          }
        });
      }
    );
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(Infinity));
    req.write(body);
    req.end();
  });
}

function readJsonSafe(filePath, fallback = {}) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
  } catch {}
  return fallback;
}

// ---- Antigravity engine without VS Code ----
// Live Antigravity sessions run inside one long-lived `agy --hub` process. Until now only the Antigravity
// extension inside VS Code started it, so after a restart of the PC nothing ran until VS Code was opened and
// sessions fell back to the command-line tool. The service starts it itself when it is the one serving the
// phone, no VS Code is running, and no engine exists. It never stops or replaces an engine: one that is busy
// answers slowly, and killing it would cut running sessions. A VS Code opened later finds the saved address
// in bhf-persistent-hub.json and reuses this engine. Launch line and environment follow the extension's own.
const AGY_ENGINE_RETRY_MS = 5 * 60 * 1000;
const AGY_ENGINE_BACKOFF_MS = 60 * 60 * 1000;
const AGY_ENGINE_READY_MS = 25000;
const agyEngineState = { inFlight: false, lastAttemptAt: 0, lastAliveAt: 0, failures: 0 };

function getFreeLoopbackPort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const addr = srv.address();
      const port = addr && typeof addr === 'object' ? addr.port : 0;
      srv.close(() => (port ? resolve(port) : reject(new Error('no free loopback port'))));
    });
  });
}

// True only when nothing listens on the port (connection refused). A timeout or any other outcome is false.
function isLoopbackPortRefused(port) {
  const n = Number(port || 0);
  if (!Number.isInteger(n) || n <= 0 || n > 65535) return Promise.resolve(true);
  return new Promise((resolve) => {
    let done = false;
    const finish = (val) => {
      if (done) return;
      done = true;
      try {
        sock.destroy();
      } catch {}
      resolve(val);
    };
    const sock = net.connect({ host: '127.0.0.1', port: n });
    sock.setTimeout(2000, () => finish(false));
    sock.once('connect', () => finish(false));
    sock.once('error', (err) => finish(Boolean(err && err.code === 'ECONNREFUSED')));
  });
}

// { hubPids: number[], vscodeRunning: boolean }, or null when the process list could not be read.
function inspectEngineProcesses() {
  if (process.platform !== 'win32') {
    return Promise.resolve({ hubPids: [], vscodeRunning: false });
  }
  const script =
    "$h = @(Get-CimInstance Win32_Process -Filter \"Name='agy.exe'\" | Where-Object { $_.CommandLine -like '*--hub*' -and $_.CommandLine -notlike '*antigravity-auth-staging*' } | ForEach-Object { $_.ProcessId }); " +
    "$c = @(Get-Process -Name 'Code','Code - Insiders','VSCodium' -ErrorAction SilentlyContinue).Count; " +
    'Write-Output ("THEO_ENGINE|" + ($h -join ",") + "|" + $c)';
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', script],
      { timeout: 15000, windowsHide: true },
      (err, stdout) => {
        const m = /THEO_ENGINE\|([\d,]*)\|(\d+)/.exec(String(stdout || ''));
        if (err || !m) {
          resolve(null);
          return;
        }
        resolve({
          hubPids: m[1]
            .split(',')
            .map((x) => Number(x))
            .filter((x) => Number.isInteger(x) && x > 0),
          vscodeRunning: Number(m[2]) > 0
        });
      }
    );
  });
}

// On Windows, Node puts every child it starts (unless detached) into one job object that ends its members
// when Node exits. The engine must outlive this service (it restarts on every update), and it cannot be
// started detached (it would lose its hidden console, theo-extension.md § 3.2). So the engine alone is
// started one step removed: a short-lived Python helper, itself a member of the job, creates the engine
// process, and a process created by a job member is not in that job. The job keeps ending everything
// else this service starts (headless runs, sign-in helpers), exactly as before.
// Resolves { ok, pid } or { ok: false, reason }.
function launchEngineOutsideJob(spec, deps = {}) {
  const pyExe = (deps.findPython || findLocalConsolePythonExe)();
  if (!pyExe) return Promise.resolve({ ok: false, reason: 'no_python' });
  const pyCode = [
    'import json, subprocess, sys',
    // Node writes UTF-8; read the bytes and decode them as that, whatever the PC's own code page is.
    'cfg = json.loads(sys.stdin.buffer.read().decode("utf-8"))',
    'log = open(cfg["log"], "ab") if cfg.get("log") else subprocess.DEVNULL',
    // 0x08000000 = CREATE_NO_WINDOW: the engine gets a console with no window, as under VS Code.
    'flags = 0x08000000 if sys.platform == "win32" else 0',
    'p = subprocess.Popen([cfg["bin"]] + cfg["args"], cwd=cfg["cwd"], env=cfg["env"], stdin=subprocess.DEVNULL, stdout=log, stderr=log, creationflags=flags, close_fds=True)',
    'print("THEO_ENGINE_PID=%d" % p.pid)'
  ].join('\n');
  return new Promise((resolve) => {
    let out = '';
    let done = false;
    const finish = (res) => {
      if (done) return;
      done = true;
      resolve(res);
    };
    let helper = null;
    try {
      helper = (deps.spawn || spawn)(pyExe, ['-c', pyCode], {
        detached: false,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'ignore']
      });
    } catch (err) {
      finish({ ok: false, reason: 'launcher_failed', error: err?.message || String(err) });
      return;
    }
    const timer = setTimeout(() => {
      try {
        helper.kill();
      } catch {}
      finish({ ok: false, reason: 'launcher_timeout' });
    }, 20000);
    helper.stdout?.on('data', (d) => {
      out += String(d);
    });
    helper.on('error', (err) => {
      clearTimeout(timer);
      finish({ ok: false, reason: 'launcher_failed', error: err?.message || String(err) });
    });
    helper.on('close', () => {
      clearTimeout(timer);
      const m = /THEO_ENGINE_PID=(\d+)/.exec(out);
      const pid = m ? Number(m[1]) : 0;
      finish(pid > 0 ? { ok: true, pid } : { ok: false, reason: 'launcher_no_answer' });
    });
    try {
      helper.stdin?.on('error', () => {});
      // The launch details travel on stdin, never on a command line: the environment holds the engine token.
      helper.stdin?.end(
        JSON.stringify({ bin: spec.bin, args: spec.args, cwd: spec.cwd, env: spec.env, log: spec.logPath || '' })
      );
    } catch {}
  });
}

// The PowerShell test for "this command line names exactly that port": the argument ends there, or a space
// follows it, so 5123 never matches an engine on 51234. `port` is a whole number, checked by the caller.
function enginePortFilterScript(port) {
  const n = Number(port);
  // Anything that is not a port number matches nothing, and never reaches the script as text.
  if (!Number.isInteger(n) || n <= 0 || n > 65535) return '$false';
  return `$_.CommandLine -like '*--hub-port=${n} *' -or $_.CommandLine -like '*--hub-port=${n}'`;
}

// Process ids of engines started for one port (`--hub-port=<port>`). [] when none, or when it cannot be read.
function findEnginePidsByPort(port) {
  const n = Number(port || 0);
  if (process.platform !== 'win32' || !Number.isInteger(n) || n <= 0 || n > 65535) {
    return Promise.resolve([]);
  }
  const script =
    `$h = @(Get-CimInstance Win32_Process -Filter "Name='agy.exe'" | Where-Object { ${enginePortFilterScript(n)} } | ForEach-Object { $_.ProcessId }); ` +
    'Write-Output ("THEO_PORT|" + ($h -join ","))';
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', script],
      { timeout: 15000, windowsHide: true },
      (err, stdout) => {
        const m = /THEO_PORT\|([\d,]*)/.exec(String(stdout || ''));
        if (err || !m) {
          resolve([]);
          return;
        }
        resolve(
          m[1]
            .split(',')
            .map((x) => Number(x))
            .filter((x) => Number.isInteger(x) && x > 0)
        );
      }
    );
  });
}

function isVersionOlderThan(version, floor) {
  const a = String(version || '').split('.').map((x) => Number(x) || 0);
  const b = String(floor || '').split('.').map((x) => Number(x) || 0);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) < (b[i] || 0);
  }
  return false;
}

function buildAgyEngineLaunch(agyBin, port, csrfToken, opts = {}) {
  const env = { ...(opts.baseEnv || process.env) };
  delete env.AGY_CLI_CDE_AUTH_ACTION;
  delete env.ANTIGRAVITY_CDE;
  delete env.AGY_CDE_SEAMLESS_AUTH;
  delete env.THEO_EPHEMERAL_LOGIN_HUB;
  env.HOME = os.homedir();
  env.USERPROFILE = os.homedir();
  env.AGY_ENABLE_HUB = '1';
  env.AGY_REQUIRE_AUTHENTICATED_UI_BOOTSTRAP = '1';
  env.ANTIGRAVITY_VSCODE_HOST = '1';
  env.ANTIGRAVITY_AUTH_SUCCESS_APP = 'vscode';
  env.ANTIGRAVITY_SERVER_CSRF_TOKEN = csrfToken;
  if (!env.NODE_USE_SYSTEM_CA && (process.platform === 'win32' || process.platform === 'darwin')) {
    env.NODE_USE_SYSTEM_CA = '1';
  }
  const args = ['--hub', `--hub-port=${port}`, '--app_data_dir=antigravity'];
  // Engines before 1.5.2 read the token from the command line only.
  let cliVersion = opts.cliVersion;
  if (cliVersion === undefined) {
    cliVersion = readJsonSafe(path.join(path.dirname(agyBin), 'agy.version.json'), {})?.version || '';
  }
  if (cliVersion && isVersionOlderThan(cliVersion, '1.5.2')) {
    args.push(`--csrf_token=${csrfToken}`);
  }
  return { args, env };
}

// Starts the engine when every condition holds; resolves { started, reason }. `deps` lets tests stand in for
// the process list, the launcher and the engine's answers.
async function ensureStandaloneAgyEngine(deps = {}) {
  const nowMs = typeof deps.now === 'function' ? deps.now() : Date.now();
  const st = deps.state || agyEngineState;
  const logFn = typeof deps.log === 'function' ? deps.log : log;
  if (st.inFlight) return { started: false, reason: 'in_flight' };
  const waitMs = st.failures >= 3 ? AGY_ENGINE_BACKOFF_MS : AGY_ENGINE_RETRY_MS;
  if (st.lastAttemptAt && nowMs - st.lastAttemptAt < waitMs) {
    return { started: false, reason: 'backoff' };
  }
  if (st.lastAliveAt && nowMs - st.lastAliveAt < 30000) {
    return { started: false, reason: 'engine_alive' };
  }
  const readState = deps.readState || readPersistentHubState;
  const pidAlive = deps.isPidAlive || isPidAlive;
  const saved = readState();
  if (saved && saved.pid && pidAlive(saved.pid)) {
    // After a restart of the PC the saved process id may belong to some other program. Only a port that
    // refuses the connection proves the saved engine is gone; a slow or silent one is treated as alive.
    const refused = await (deps.portRefused || isLoopbackPortRefused)(saved.port);
    if (!refused) {
      st.lastAliveAt = nowMs;
      return { started: false, reason: 'engine_alive' };
    }
  }
  st.lastAliveAt = 0;
  const agyBin = (deps.resolveBin || resolveAgyBinaryPath)();
  if (!agyBin) return { started: false, reason: 'no_engine_binary' };

  st.inFlight = true;
  st.lastAttemptAt = nowMs;
  let enginePid = 0;
  // The engine just started here holds no session yet: stopping it is safe. Never used on any other engine.
  const stopEngine =
    deps.stopEngine ||
    ((pid) => {
      try {
        if (pid > 0) process.kill(pid);
      } catch {}
    });
  try {
    const procs = await (deps.inspectProcesses || inspectEngineProcesses)();
    if (!procs) return { started: false, reason: 'process_list_failed' };
    if (procs.vscodeRunning) return { started: false, reason: 'vscode_running' };
    if (procs.hubPids.length > 0) return { started: false, reason: 'engine_process_present' };

    const sync = await Promise.resolve((deps.keyringSync || ensureExpectedAntigravityKeyringSync)(null)).catch(
      () => null
    );
    if (!sync || sync.stagingActive) return { started: false, reason: 'sign_in_in_progress' };
    if (!sync.expectedEmail) return { started: false, reason: 'no_account' };

    const port = await (deps.getPort || getFreeLoopbackPort)();
    const csrfToken = crypto.randomUUID();
    const launch = buildAgyEngineLaunch(agyBin, port, csrfToken, { cliVersion: deps.cliVersion });
    const logPath = path.join(os.homedir(), '.gemini', 'antigravity', 'bhf-persistent-hub.log');
    if (!deps.launch) {
      try {
        fs.mkdirSync(path.dirname(logPath), { recursive: true });
      } catch {}
    }
    // Started one step removed, so it outlives this service; never `detached` (see launchEngineOutsideJob).
    const launched = await (deps.launch || launchEngineOutsideJob)({
      bin: agyBin,
      args: launch.args,
      env: launch.env,
      cwd: os.homedir(),
      logPath
    });
    if (!launched || !launched.ok || !launched.pid) {
      st.failures += 1;
      // The helper may have created the engine and then failed to say so (a timeout). An engine nobody has the
      // address of would block every later start: find it by the port chosen for it, and stop it.
      const strays = await Promise.resolve((deps.findByPort || findEnginePidsByPort)(port)).catch(() => []);
      for (const strayPid of Array.isArray(strays) ? strays : []) stopEngine(strayPid);
      logFn(`[WARN] Antigravity engine not started (${launched?.reason || 'launcher failed'}); will retry later`);
      return { started: false, reason: launched?.reason || 'launcher_failed' };
    }
    enginePid = launched.pid;
    // Its address is saved at once, before it has answered: if this service is restarted during the wait
    // below, the next one finds the engine (and uses it once its port answers) instead of an engine it has
    // no address for.
    const engineState = {
      pid: enginePid,
      port,
      csrfToken,
      serverUrl: `http://127.0.0.1:${port}`,
      startedAt: Math.floor(Date.now() / 1000),
      consoleHidden: true
      // `retiringHubs` is left to writePersistentHubState: older engines still finishing sessions stay listed.
    };
    const writeState = deps.writeState || writePersistentHubState;
    writeState(engineState);

    const heartbeat =
      deps.heartbeat ||
      ((p, t) => new AntigravityDataStore().callRpc(p, t, 'Heartbeat', {}, 1500));
    const readyBy = Date.now() + (deps.readyMs || AGY_ENGINE_READY_MS);
    let ready = false;
    let exited = false;
    while (Date.now() < readyBy) {
      try {
        await heartbeat(port, csrfToken);
        ready = true;
        break;
      } catch {
        if (!pidAlive(enginePid)) {
          exited = true;
          break;
        }
        await new Promise((r) => setTimeout(r, deps.pollMs || 300));
      }
    }
    if (!ready) {
      st.failures += 1;
      // One that already ended is left alone: its process id may belong to something else by now.
      if (!exited) stopEngine(enginePid);
      logFn(`[WARN] Antigravity engine did not answer after start (attempt ${st.failures}); will retry later`);
      return { started: false, reason: exited ? 'engine_exited' : 'engine_not_ready' };
    }
    // A VS Code window may have come up meanwhile and started its own: that one wins, ours holds no session.
    // Only an address saved since this attempt began counts; the stale one found at the start does not.
    const savedNow = readState();
    if (
      savedNow &&
      savedNow.port !== port &&
      savedNow.port !== Number(saved?.port || 0) &&
      savedNow.pid &&
      pidAlive(savedNow.pid)
    ) {
      stopEngine(enginePid);
      return { started: false, reason: 'superseded' };
    }
    writeState(engineState);
    Promise.resolve((deps.disableTelemetry || ensureAntigravityTelemetryDisabled)(port, csrfToken)).catch(
      () => {}
    );
    st.failures = 0;
    logFn(`[INFO] Started the Antigravity engine without VS Code (pid ${enginePid}, port ${port})`);
    return { started: true, reason: 'started', pid: enginePid, port };
  } catch (err) {
    st.failures += 1;
    if (enginePid && pidAlive(enginePid)) stopEngine(enginePid);
    logFn(`[WARN] Antigravity engine start failed: ${err?.message || err}`);
    return { started: false, reason: 'error' };
  } finally {
    st.inFlight = false;
  }
}

// The background service has no sidebar hub. Code shared with the VS Code host reads `bridge.hub.snapshot`
// and, in places, calls `bridge.hub.refresh()`: the stand-in answers both, so a call that assumes a sidebar
// can never throw here (one in a timer used to end this whole process).
function makeStandaloneHub(threads) {
  return {
    standalone: true,
    snapshot: { threads: Array.isArray(threads) ? threads : [] },
    refresh: async () => {}
  };
}

function buildStandaloneSummaryForWindows(windowsObj) {
  const win5h = windowsObj?.['5h'] || {};
  const win7d = windowsObj?.['7d'] || {};
  const days = Array.isArray(win7d.daily)
    ? win7d.daily.map((d) => ({
        key: d.date,
        label: d.label,
        tokens: Number(d.totalTokens || 0),
        turns: Number(d.turns || 0)
      }))
    : [];
  const todayBar = days[days.length - 1] || { tokens: 0, turns: 0 };
  return {
    today: {
      sessions: Number(win5h.sessions || 0),
      turns: Math.max(Number(win5h.turns || 0), Number(todayBar.turns || 0)),
      tokens: Math.max(Number(win5h.totalTokens || 0), Number(todayBar.tokens || 0)),
      input: Number(win5h.inputTokens || 0),
      cached: Number(win5h.cachedInputTokens || 0),
      output: Number(win5h.outputTokens || 0)
    },
    week: {
      sessions: Number(win7d.sessions || 0),
      turns: Number(win7d.turns || 0),
      tokens: Number(win7d.totalTokens || 0),
      input: Number(win7d.inputTokens || 0),
      cached: Number(win7d.cachedInputTokens || 0),
      output: Number(win7d.outputTokens || 0)
    },
    days: days.length ? days : [{ key: 'Today', label: 'Today', tokens: 0, turns: 0 }]
  };
}

async function buildStandaloneState(store, bridge, opts = {}) {
  refreshUnsavedWork().catch(() => {});
  const cachedState =
    opts.cachedState || readJsonSafe(opts.lastStateCacheFile || LAST_STATE_CACHE_FILE, {});
  const hubStatePath = opts.hubStateFile || HUB_STATE_FILE;
  let persistedHub = opts.persistedHub || null;
  if (!persistedHub) {
    try {
      const roStateStore = new HubStateStore(null, {
        diskBackup: true,
        diskBackupPath: hubStatePath,
        ...(opts.peerCacheFile ? { peerCachePath: opts.peerCacheFile } : {}),
        readOnly: true
      });
      persistedHub = roStateStore.read();
    } catch {
      persistedHub = readJsonSafe(hubStatePath, {});
    }
  }
  persistedHub = persistedHub || {};
  const customTitles = persistedHub?.customTitles || {};
  const threadGroups = persistedHub?.threadGroups || {};
  // `.theo-hub-state.json` is written by HubStateStore (state.js): keys are `archivedIds`,
  // `unreadIds`, `seenTurnTimestamps` (seconds) and `baseline` (seconds).
  const archivedSet = new Set([
    ...(Array.isArray(persistedHub?.archivedIds) ? persistedHub.archivedIds : []),
    ...(Array.isArray(persistedHub?.archived) ? persistedHub.archived : [])
  ]);
  const unarchivedAtMap =
    persistedHub?.unarchivedAt && typeof persistedHub.unarchivedAt === 'object'
      ? persistedHub.unarchivedAt
      : {};
  const unreadSet = new Set(Array.isArray(persistedHub?.unreadIds) ? persistedHub.unreadIds : []);
  const seenAtMap =
    persistedHub?.seenTurnTimestamps && typeof persistedHub.seenTurnTimestamps === 'object'
      ? persistedHub.seenTurnTimestamps
      : persistedHub?.seenAt || {};
  const baselineSec = Number(persistedHub?.baseline || 0);
  const pinnedMap =
    persistedHub?.pinnedThreads && typeof persistedHub.pinnedThreads === 'object'
      ? persistedHub.pinnedThreads
      : {};
  const unpinnedMap =
    persistedHub?.unpinnedThreads && typeof persistedHub.unpinnedThreads === 'object'
      ? persistedHub.unpinnedThreads
      : {};
  const groups = Array.isArray(persistedHub?.groups)
    ? persistedHub.groups.map((g) => ({
        id: g.id,
        name: g.name,
        ...(g.color ? { color: g.color } : {}),
        collapsed: Boolean(g.collapsed)
      }))
    : cachedState.groups || [];
  const groupIds = new Set(groups.map((g) => g.id));

  let snap = null;
  try {
    snap = await store.loadSnapshot({
      customTitles,
      archivedIds: Array.from(archivedSet),
      unarchivedAt: unarchivedAtMap,
      threadGroups,
      forceQuota: false,
      forceRefreshQuota: false
    });
  } catch {}

  const workspaces = await bridge.refreshWorkspacesCache().catch(() => cachedState.workspaces || []);

  if (!snap || !Array.isArray(snap.threads)) {
    const rawFallbackRows = Array.isArray(cachedState.rows) ? cachedState.rows : [];
    const fallbackRows = rawFallbackRows
      .map((r) => {
        if (!r || !r.id) return r;
        const isArch = archivedSet.has(r.id) || Boolean(r.archived && !unarchivedAtMap[r.id]);
        const pinState = resolveRowPinState({ ...r, archived: isArch }, pinnedMap, unpinnedMap);
        return {
          ...r,
          archived: isArch,
          pinned: pinState.pinned,
          pinnedAt: pinState.pinnedAt,
          pinUpdatedAt: pinState.pinUpdatedAt
        };
      })
      .sort(
        (a, b) =>
          Number(Boolean(b?.pinned && !b?.archived)) - Number(Boolean(a?.pinned && !a?.archived)) ||
          Number(b?.at || 0) - Number(a?.at || 0) ||
          Number(b?.pinnedAt || 0) - Number(a?.pinnedAt || 0)
      );
    const fallbackHideClaudeDesktop =
      typeof persistedHub?.preferences?.hideClaudeDesktopSessions === 'boolean'
        ? persistedHub.preferences.hideClaudeDesktopSessions
        : Boolean(cachedState?.hideClaudeDesktop);
    bridge.hub = makeStandaloneHub(
      fallbackRows.map((r) => ({
        id: r.id,
        provider: r.provider,
        claudeDesktop: Boolean(r.claudeDesktop),
        claudeDesktopScratch: Boolean(r.claudeDesktopScratch),
        title: r.title,
        cwd: r.cwd,
        workspaceLabel: r.folder,
        branch: r.branch,
        model: r.model,
        updatedAt: Math.floor((r.at || Date.now()) / 1000)
      }))
    );
    const fallbackRowsById = new Map(fallbackRows.filter((r) => r && r.id).map((r) => [r.id, r]));
    const fallbackThreadsById = new Map(
      (Array.isArray(cachedState.threads) ? cachedState.threads : [])
        .filter((t) => t && t.id)
        .map((t) => [t.id, t])
    );
    const fallbackApprovals = (Array.isArray(cachedState.approvals) ? cachedState.approvals : []).filter((a) => {
      if (!a) return false;
      const row = a.sessionId ? fallbackRowsById.get(a.sessionId) : null;
      const cachedThread = a.sessionId ? fallbackThreadsById.get(a.sessionId) : null;
      const meta = row || cachedThread;
      const isScratch = Boolean(
        a.claudeDesktopScratch ||
          meta?.claudeDesktopScratch ||
          isClaudeDesktopScratchPath(
            meta?.cwd || meta?.filePath || a.cwd || a.filePath || store?.claudeFileById?.get?.(a.sessionId) || ''
          )
      );
      if (isScratch) return false;
      if (meta) {
        return !(fallbackHideClaudeDesktop && meta.claudeDesktop);
      }
      if (fallbackHideClaudeDesktop && a.claudeDesktop) return false;
      if (a.provider === 'claude' && a.claudeDesktop === undefined && a.claudeDesktopScratch !== false) {
        return false;
      }
      return true;
    });
    return {
      ...cachedState,
      rows: fallbackRows,
      approvals: fallbackApprovals,
      hideThirdPartyQuota:
        typeof persistedHub?.preferences?.hideThirdPartyQuota === 'boolean'
          ? persistedHub.preferences.hideThirdPartyQuota
          : Boolean(cachedState?.hideThirdPartyQuota),
      hideThirdPartyQuotaUpdatedAt: Number(
        persistedHub?.preferences?.hideThirdPartyQuotaUpdatedAt ||
          cachedState?.hideThirdPartyQuotaUpdatedAt ||
          0
      ),
      hideClaudeDesktop: fallbackHideClaudeDesktop,
      hideClaudeDesktopUpdatedAt: Number(
        persistedHub?.preferences?.hideClaudeDesktopSessionsUpdatedAt ||
          cachedState?.hideClaudeDesktopUpdatedAt ||
          0
      ),
      generatedAt: Date.now(),
      connection: bridge.getStatus(),
      workspaces,
      personalLedger: bridge.personalLedger
    };
  }

  const hideClaudeDesktop =
    typeof persistedHub?.preferences?.hideClaudeDesktopSessions === 'boolean'
      ? persistedHub.preferences.hideClaudeDesktopSessions
      : Boolean(cachedState?.hideClaudeDesktop);
  const hasAttachedUi =
    typeof bridge?.hasAttachedVsCodeUi === 'function' ? Boolean(bridge.hasAttachedVsCodeUi()) : false;
  const attachedUiTabState =
    typeof bridge.getAttachedVsCodeTabState === 'function'
      ? bridge.getAttachedVsCodeTabState()
      : { openIds: new Set(), activeId: '', openTabs: [], pendingPermissions: [] };
  const activity =
    !opts.freshActivityTracker && bridge && typeof bridge === 'object'
      ? (bridge._standaloneActivityTracker =
          bridge._standaloneActivityTracker || new SessionActivityTracker())
      : new SessionActivityTracker();
  activity.reconcileSnapshot?.(snap.threads || [], snap.loadedAt || Date.now());
  const toEpochSec = (val) => {
    const num = Number(val || 0);
    if (!Number.isFinite(num) || num <= 0) return 0;
    return num > 1e11 ? Math.floor(num / 1000) : num;
  };
  const rows = [];
  const seenIds = new Set();
  const rowFallbackApprovals = [];
  for (const thread of snap.threads) {
    if (!thread || !thread.id) continue;
    seenIds.add(thread.id);
    const provider = thread.provider === 'claude' ? 'claude' : 'antigravity';
    const classified = activity.classifyThread(thread, { recordTransition: false });
    let status = 'idle';
    if (classified.state === 'waiting') {
      status = 'waiting';
    } else if (classified.state === 'thinking') {
      status = 'working';
    } else if (classified.state === 'errored') {
      status = 'failed';
    } else if (classified.state === 'completed') {
      status = 'completed';
    }
    const isOpenRow = attachedUiTabState.openIds.has(thread.id);
    const isActiveRow = Boolean(attachedUiTabState.activeId && thread.id === attachedUiTabState.activeId);
    const isArchived = archivedSet.has(thread.id) || Boolean(thread.archived && !unarchivedAtMap[thread.id]);
    const seenSec = Math.max(
      toEpochSec(seenAtMap[thread.id]),
      toEpochSec(baselineSec),
      toEpochSec(thread.lastUserViewAt)
    );
    const updatedSec = toEpochSec(thread.updatedAt);
    const updatedMs = Number(thread.updatedAt || 0) * 1000;
    const rawThreadUnread =
      !isActiveRow &&
      !isArchived &&
      (unreadSet.has(thread.id) ||
        Boolean(thread.claudeUnread && updatedSec > seenSec) ||
        ((classified.state === 'completed' || classified.state === 'errored') && updatedSec > seenSec + 2));
    const isUnread = hasAttachedUi ? isOpenRow && rawThreadUnread : rawThreadUnread;
    const dot =
      status === 'waiting'
        ? 'waiting'
        : status === 'working'
          ? 'running'
          : thread.bgTask?.state === 'interrupted'
            ? 'failed'
            : isUnread
              ? status === 'failed'
                ? 'failed'
                : 'unread'
              : isOpenRow
                ? 'idle'
                : null;
    const category =
      status === 'waiting'
        ? 'needs_input'
        : status === 'working'
          ? 'working'
          : 'completed';
    const title = customTitles[thread.id] || thread.title || 'Untitled session';
    const stepCount = Number(thread.stepCount || 0);
    const pendingQuestion = thread.pendingQuestion || null;
    const lastAssistantText = !isArchived ? String(thread.lastAssistantText || '').slice(0, 220) : '';
    const rawBg = Array.isArray(thread.backgroundTasks) ? thread.backgroundTasks : [];
    const bgRunningCount = rawBg.filter((t) => t && t.state === 'running').length;
    const bgTotalCount = rawBg.length;
    const includeBgList =
      !isArchived ||
      isOpenRow ||
      bgRunningCount > 0 ||
      thread.bgTask?.state === 'interrupted' ||
      Boolean(thread.bgTask?.stalled);
    const bgTasks = includeBgList
      ? rawBg.slice(-12).map((t) => ({
          id: t.id,
          fullId: t.fullId || t.id,
          subagentConversationId: t.subagentConversationId || '',
          kind: t.kind || 'task',
          subagentType: t.subagentType || '',
          summary: t.summary || '',
          command: String(t.command || '').slice(0, 320),
          state: t.state || 'completed',
          isDaemon: Boolean(t.isDaemon),
          startedAt: Number(t.startedAt || 0) * 1000,
          completedAt: t.completedAt ? Number(t.completedAt) * 1000 : 0,
          stepIndex: typeof t.stepIndex === 'number' ? t.stepIndex : -1
        }))
      : [];

    const pinState = resolveRowPinState(
      {
        id: thread.id,
        archived: isArchived,
        pinned: thread.pinned,
        pinnedAt: thread.pinnedAt,
        pinUpdatedAt: thread.pinUpdatedAt
      },
      pinnedMap,
      unpinnedMap
    );
    const rowUsedTokens = Number(thread.usedTokens || thread.estTokens || 0) || 0;
    const rowLimFallback =
      provider === 'antigravity'
        ? inferSoftAndHardContextLimits(provider, thread.model || '').softCompactionTargetTokens
        : 0;
    const rowLimitTokens = Number(thread.limitTokens || rowLimFallback || 0) || 0;

    rows.push({
      key: thread.id,
      id: thread.id,
      provider,
      claudeDesktop: Boolean(thread.claudeDesktop),
      claudeDesktopScratch: Boolean(thread.claudeDesktopScratch),
      draft: false,
      title,
      at: updatedMs,
      open: isOpenRow,
      active: isActiveRow,
      group:
        threadGroups[thread.id] && groupIds.has(threadGroups[thread.id])
          ? threadGroups[thread.id]
          : null,
      archived: isArchived,
      pinned: pinState.pinned,
      pinnedAt: pinState.pinnedAt,
      pinUpdatedAt: pinState.pinUpdatedAt,
      cwd: thread.cwd || '',
      folder: thread.workspaceLabel || '',
      branch: thread.branch || '',
      deviceId: thread.deviceId || '',
      deviceName: thread.deviceName || '',
      source: thread.source || '',
      usedTokens: rowUsedTokens,
      limitTokens: rowLimitTokens,
      remotePeer: Boolean(thread.remotePeer || thread.source === 'cloud-relay'),
      model: formatModelDisplayName(
        thread.model || (provider === 'claude' ? 'Claude' : 'Gemini'),
        provider,
        thread.effort || ''
      ),
      effort: thread.effort || undefined,
      logged: true,
      status,
      dot,
      category,
      unread: isUnread,
      elsewhere: Boolean((status === 'working' || thread.elsewhere) && !isOpenRow),
      reason: classified.reason || null,
      stepCount,
      turnComplete: thread.turnComplete !== false,
      lastAssistantText,
      pendingQuestion,
      bgTasks,
      bgRunningCount,
      bgTotalCount
    });

    if (
      (pendingQuestion || status === 'waiting') &&
      !thread.claudeDesktopScratch &&
      !(hideClaudeDesktop && thread.claudeDesktop)
    ) {
      const isQ = Boolean(pendingQuestion);
      const stepKey = pendingQuestion?.stepIndex || stepCount || 0;
      const normQs =
        Array.isArray(pendingQuestion?.questions) && pendingQuestion.questions.length
          ? pendingQuestion.questions
          : [];
      const itemId =
        pendingQuestion?.approvalId ||
        (isQ
          ? `question-${thread.id}-${stepKey}`
          : stepKey
            ? `waiting-${thread.id}-${stepKey}`
            : `waiting-${thread.id}`);
      rowFallbackApprovals.push({
        id: itemId,
        approvalId: itemId,
        provider,
        claudeDesktop: Boolean(thread.claudeDesktop),
        claudeDesktopScratch: Boolean(thread.claudeDesktopScratch),
        sessionId: thread.id,
        title,
        toolName:
          pendingQuestion?.toolName ||
          (isQ ? 'Question' : classified.reason || 'Waiting on user input'),
        detail:
          pendingQuestion?.questionText ||
          lastAssistantText ||
          `${thread.workspaceLabel || 'Workspace'} · ${thread.model || ''}`.trim(),
        codePreview: pendingQuestion?.codePreview || '',
        description: pendingQuestion?.description || '',
        isToolPermission: Boolean(pendingQuestion?.isToolPermission),
        writeInPlaceholder: pendingQuestion?.writeInPlaceholder || '',
        isMultiSelect: Boolean(pendingQuestion?.isMultiSelect || normQs[0]?.isMultiSelect),
        options: pendingQuestion?.options || [],
        questions: normQs,
        stepIndex: stepKey,
        kind: isQ ? 'question' : 'waiting_session',
        createdAt: (pendingQuestion?.at ? pendingQuestion.at * 1000 : updatedMs) || Date.now()
      });
    }
  }

  for (const tab of Array.isArray(attachedUiTabState.openTabs) ? attachedUiTabState.openTabs : []) {
    if (!tab || !tab.id || seenIds.has(tab.id)) continue;
    seenIds.add(tab.id);
    const provider = tab.provider === 'claude' ? 'claude' : 'antigravity';
    const defaultModel = provider === 'claude' ? 'Claude' : 'Gemini';
    const liveEntry = activity.liveByThreadId?.get?.(tab.id);
    const syntheticThread = {
      id: tab.id,
      provider,
      title: customTitles[tab.id] || tab.title || 'Untitled session',
      updatedAt: Number(liveEntry?.updatedAt || Math.floor(Date.now() / 1000)),
      stepCount: Number(liveEntry?.stepCount || 0),
      notFullyIdle: Boolean(liveEntry?.notFullyIdle),
      status: liveEntry?.notFullyIdle ? 'CASCADE_RUN_STATUS_RUNNING' : 'CASCADE_RUN_STATUS_IDLE'
    };
    const classified = activity.classifyThread(syntheticThread, { recordTransition: false });
    let fallbackStatus = 'idle';
    if (classified.state === 'waiting') fallbackStatus = 'waiting';
    else if (classified.state === 'thinking') fallbackStatus = 'working';
    else if (classified.state === 'errored') fallbackStatus = 'failed';
    else if (classified.state === 'completed') fallbackStatus = 'completed';
    const fallbackDot =
      fallbackStatus === 'waiting'
        ? 'waiting'
        : fallbackStatus === 'working'
          ? 'running'
          : 'idle';
    const fallbackCategory =
      fallbackStatus === 'waiting'
        ? 'needs_input'
        : fallbackStatus === 'working'
          ? 'working'
          : 'completed';
    const mappedPath =
      store?.claudeFileById?.get?.(tab.id) || store?.getTranscriptLogPath?.(tab.id, provider) || '';
    const synthScratch = provider === 'claude' && isClaudeDesktopScratchPath(mappedPath);
    const isSynthArchived = archivedSet.has(tab.id);
    const synthPinState = resolveRowPinState(
      { id: tab.id, archived: isSynthArchived },
      pinnedMap,
      unpinnedMap
    );
    const synthLim =
      provider === 'antigravity'
        ? inferSoftAndHardContextLimits(provider, defaultModel).softCompactionTargetTokens
        : 0;
    rows.push({
      key: tab.id,
      id: tab.id,
      provider,
      claudeDesktop: synthScratch,
      claudeDesktopScratch: synthScratch,
      draft: false,
      title: syntheticThread.title,
      at: Number(syntheticThread.updatedAt) * 1000,
      open: true,
      active: Boolean(tab.active || (attachedUiTabState.activeId && tab.id === attachedUiTabState.activeId)),
      group: threadGroups[tab.id] && groupIds.has(threadGroups[tab.id]) ? threadGroups[tab.id] : null,
      archived: isSynthArchived,
      pinned: synthPinState.pinned,
      pinnedAt: synthPinState.pinnedAt,
      pinUpdatedAt: synthPinState.pinUpdatedAt,
      cwd: '',
      folder: synthScratch ? 'Claude Desktop' : '',
      branch: '',
      deviceId: '',
      deviceName: '',
      source: '',
      usedTokens: Number(syntheticThread.usedTokens || syntheticThread.estTokens || 0) || 0,
      limitTokens: Number(syntheticThread.limitTokens || synthLim || 0) || 0,
      remotePeer: false,
      model: formatModelDisplayName(defaultModel, provider, ''),
      logged: true,
      status: fallbackStatus,
      dot: fallbackDot,
      category: fallbackCategory,
      unread: false,
      elsewhere: false,
      reason: classified.reason || null,
      stepCount: syntheticThread.stepCount,
      turnComplete: !syntheticThread.notFullyIdle,
      lastAssistantText: '',
      pendingQuestion: null,
      bgTasks: [],
      bgRunningCount: 0,
      bgTotalCount: 0
    });
  }

  rows.sort(
    (a, b) =>
      Number(Boolean(b.pinned && !b.archived)) - Number(Boolean(a.pinned && !a.archived)) ||
      Number(b.at || 0) - Number(a.at || 0) ||
      Number(b.pinnedAt || 0) - Number(a.pinnedAt || 0)
  );

  const formatBucket = (b) => ({
    label: b.label,
    pct: b.usedPercent,
    reset: b.resetAt ? b.resetAt * 1000 : 0,
    resetText: b.resetText || '',
    expired: Boolean(b.expired ?? b.windowExpired),
    ...(b.pool ? { pool: b.pool } : {}),
    ...(b.key || b.bucketId ? { key: b.key || b.bucketId } : {})
  });

  const agyFallbackMsg = snap?.serverConnected
    ? 'Loading quota windows…'
    : 'Waiting for Antigravity language server…';
  const claudeFallbackMsg = snap?.claudeAccount?.available
    ? 'Loading Claude quota windows…'
    : 'Sign in to Claude Code to view quota.';

  const prefCollapsed =
    persistedHub?.preferences?.collapsedAccounts &&
    typeof persistedHub.preferences.collapsedAccounts === 'object'
      ? persistedHub.preferences.collapsedAccounts
      : {};
  let accountsView = null;
  if (bridge.accountVault) {
    try {
      bridge.accountVault.syncActiveClaudeFromDisk(
        snap?.claudeConfigObj,
        snap?.claudeCredsObj,
        snap?.rawClaudeQuota,
        snap?.rawClaudeQuotaAt || 0
      );
      accountsView = await bridge.accountVault.resolveAccountsSnapshot({
        nowMs: Date.now(),
        forceQuota: false,
        antigravityAccount: snap?.account,
        antigravityLimits: snap?.rateLimits,
        rawAntigravityQuota: snap?.rawAntigravityQuota,
        rawActiveQuotaAt: snap?.rawAntigravityQuotaAt || 0,
        claudeAccount: snap?.claudeAccount,
        claudeLimits: snap?.claudeRateLimits,
        rawClaudeQuota: snap?.rawClaudeQuota,
        claudeRelayMerged: snap?.claudeLive?.rateLimitWindows,
        collapsedProviders: {
          antigravity: Boolean(persistedHub?.preferences?.antigravityUsageCollapsed),
          claude: Boolean(persistedHub?.preferences?.claudeUsageCollapsed),
          ...prefCollapsed
        }
      });
    } catch {}
  }

  const mapStandaloneCard = (item, fallbackMsg) => {
    const provKey = item.provider === 'claude' ? 'claude' : 'antigravity';
    const isSignedOutItem = !item.available || Boolean(item.signedOut || item.account?.signedOut);
    const pLimits = isSignedOutItem ? [] : (item.rateLimits?.primaryBars || []).map(formatBucket);
    const aLimits = isSignedOutItem ? [] : (item.rateLimits?.allBuckets || []).map(formatBucket);
    const isCardCollapsed =
      typeof prefCollapsed[item.id] === 'boolean'
        ? Boolean(prefCollapsed[item.id])
        : Boolean(item.collapsed);
    return {
      id: item.id,
      provider: provKey,
      label: provKey === 'claude' ? 'Claude Code' : 'Antigravity',
      nickname: item.label || '',
      active: !isSignedOutItem && Boolean(item.active),
      hubLive: Boolean(item.hubLive),
      hubPendingCutover: Boolean(item.hubPendingCutover),
      collapsed: isCardCollapsed,
      addedAt: Number(item.addedAt || 0),
      sortOrder: Number.isFinite(Number(item.sortOrder)) ? Number(item.sortOrder) : 0,
      lastActiveAt: Number(item.lastActiveAt || 0),
      quotaUpdatedAt: Number(item.quotaUpdatedAt || snap?.loadedAt || 0),
      account: {
        name: item.name || item.account?.name || (provKey === 'claude' ? 'Claude Account' : 'Antigravity Account'),
        email: isSignedOutItem ? '' : item.email || item.account?.email || '',
        plan: isSignedOutItem ? '' : item.plan || item.account?.plan || (provKey === 'claude' ? 'Claude Code' : 'Google AI Pro'),
        nickname: item.label || '',
        available: !isSignedOutItem && Boolean(item.available),
        signedOut: isSignedOutItem
      },
      usage: !isSignedOutItem && pLimits.length
        ? {
            at: item.quotaUpdatedAt || snap?.loadedAt || Date.now(),
            limits: pLimits,
            allLimits: aLimits
          }
        : null,
      usageMessage: isSignedOutItem ? 'Not signed in.' : item.rateLimits?.error || fallbackMsg || ''
    };
  };

  const agyAccountsModels =
    Array.isArray(accountsView?.antigravity) && accountsView.antigravity.length
      ? accountsView.antigravity.map((item) => mapStandaloneCard(item, agyFallbackMsg))
      : null;
  const claudeAccountsModels =
    Array.isArray(accountsView?.claude) && accountsView.claude.length
      ? accountsView.claude.map((item) => mapStandaloneCard(item, claudeFallbackMsg))
      : null;
  const agyActiveCard = agyAccountsModels?.find((a) => a.active) || agyAccountsModels?.[0] || null;
  const claudeActiveCard = claudeAccountsModels?.find((a) => a.active) || claudeAccountsModels?.[0] || null;

  const agyPrimaryLimits = (snap?.rateLimits?.primaryBars || []).map(formatBucket);
  const agyAllLimits = (snap?.rateLimits?.allBuckets || []).map(formatBucket);
  const claudePrimaryLimits = (snap?.claudeRateLimits?.primaryBars || []).map(formatBucket);
  const claudeAllLimits = (snap?.claudeRateLimits?.allBuckets || []).map(formatBucket);

  const agyProviderInfo = {
    id: 'antigravity',
    label: 'Antigravity',
    account: agyActiveCard?.account || {
      name: snap?.account?.name || cachedState?.account?.name || 'Antigravity Account',
      email: snap?.account?.email || cachedState?.account?.email || '',
      plan: snap?.account?.plan || cachedState?.account?.plan || 'Google AI Pro',
      available: Boolean(snap?.account?.email || snap?.account?.name || cachedState?.account?.available),
      signedOut: false
    },
    usage: agyActiveCard
      ? agyActiveCard.usage
      : agyPrimaryLimits.length
        ? {
            at: snap?.loadedAt || Date.now(),
            limits: agyPrimaryLimits,
            allLimits: agyAllLimits
          }
        : cachedState?.providers?.antigravity?.usage || cachedState?.usage || null,
    usageMessage: agyActiveCard?.usageMessage || agyFallbackMsg,
    accounts: agyAccountsModels || cachedState?.providers?.antigravity?.accounts || undefined
  };

  const claudeSignedOut = Boolean(snap?.claudeAccount?.signedOut);
  const claudeProviderInfo = {
    id: 'claude',
    label: 'Claude Code',
    account:
      claudeActiveCard?.account ||
      (claudeSignedOut
        ? {
            name: 'Claude Code',
            email: '',
            plan: '',
            available: false,
            signedOut: true
          }
        : {
            name: snap?.claudeAccount?.name || cachedState?.providers?.claude?.account?.name || 'Claude Account',
            email: snap?.claudeAccount?.email || cachedState?.providers?.claude?.account?.email || '',
            plan: snap?.claudeAccount?.plan || cachedState?.providers?.claude?.account?.plan || 'Claude Code',
            available: Boolean(snap?.claudeAccount?.available || cachedState?.providers?.claude?.account?.available),
            signedOut: false
          }),
    usage: claudeActiveCard
      ? claudeActiveCard.usage
      : claudeSignedOut
        ? null
        : claudePrimaryLimits.length
          ? {
              at: snap?.loadedAt || Date.now(),
              limits: claudePrimaryLimits,
              allLimits: claudeAllLimits
            }
          : cachedState?.providers?.claude?.usage || null,
    usageMessage:
      claudeActiveCard?.usageMessage || (claudeSignedOut ? 'Not signed in.' : claudeFallbackMsg),
    accounts:
      claudeAccountsModels ||
      (claudeSignedOut ? [] : cachedState?.providers?.claude?.accounts || undefined)
  };

  bridge.hub = makeStandaloneHub(snap.threads);

  // Requests held for the phone that only this process can see: a headless Claude run waiting on a tool
  // approval or a question, and approvals the Antigravity engine reports. Each replaces the generic
  // "session is waiting" card of its session. Without this the phone never saw them with VS Code closed.
  const standaloneApprovals = [];
  const heldSessionIds = new Set();
  try {
    const held =
      typeof bridge.collectPendingApprovals === 'function' ? await bridge.collectPendingApprovals() : [];
    for (const card of Array.isArray(held) ? held : []) {
      if (!card || !card.id || !card.sessionId || card.kind === 'waiting_session') continue;
      if (card.claudeDesktopScratch || (hideClaudeDesktop && card.claudeDesktop)) continue;
      heldSessionIds.add(card.sessionId);
      standaloneApprovals.push(card);
    }
  } catch {}
  for (const fb of rowFallbackApprovals) {
    if (!fb || !fb.sessionId || heldSessionIds.has(fb.sessionId)) continue;
    standaloneApprovals.push(fb);
  }

  const selfDevId = bridge.deviceInfo?.id || 'workstation';
  const selfDevName = bridge.deviceInfo?.name || os.hostname();
  const peerOwnedRowIds = new Map();
  const addPeerRows = (devId, list) => {
    if (!devId || devId === selfDevId || !Array.isArray(list)) return;
    let set = peerOwnedRowIds.get(devId);
    if (!set) {
      set = new Set();
      peerOwnedRowIds.set(devId, set);
    }
    for (const pr of list) {
      if (pr && pr.id) set.add(String(pr.id));
    }
  };
  if (bridge.edgeClient) {
    for (const [pDevId, pEntry] of Object.entries(bridge.edgeClient.getPeerSnapshots())) {
      addPeerRows(pDevId, pEntry?.snapshot?.rows);
    }
  }
  for (const [rDevId, rEntry] of Object.entries(bridge.remoteDeviceStates || {})) {
    addPeerRows(rDevId, rEntry?.snapshot?.rows || rEntry?.rows);
  }
  const rowById = new Map();
  for (const r of rows) {
    if (!r || !r.id) continue;
    const ownerInfo = inferRowOwnerDevice(r, bridge.deviceInfo, { peerOwnedRowIds });
    const ownerDevId = ownerInfo.id || ownerInfo.deviceId;
    const ownerDevName = ownerInfo.name || ownerInfo.deviceName;
    const isForeignRow =
      ownerDevId !== selfDevId || r.source === 'cloud-relay' || Boolean(r.remotePeer);
    if (opts.localOnly && isForeignRow) continue;
    rowById.set(r.id, {
      ...r,
      deviceId: ownerDevId || selfDevId,
      deviceName: ownerDevName || selfDevName,
      remotePeer: isForeignRow
    });
  }
  if (bridge.directRunner) {
    for (const run of bridge.directRunner.getActiveRuns()) {
      const rid = run.threadId || run.id;
      if (!rid) continue;
      const existing = rowById.get(rid);
      const runOverride = bridge.sessionModelOverrides?.get(rid) || null;
      const runModelLabel = runOverride?.displayModel
        ? formatModelDisplayName(runOverride.displayModel, run.provider, runOverride.effort)
        : formatModelDisplayName(run.model || existing?.model, run.provider, runOverride?.effort || run.effort || '');
      // Held for an answer from the phone: the row reads as waiting, not as running.
      const runHeld = Number(run.pendingPermissionCount || 0) > 0;
      rowById.set(rid, {
        ...(existing || {}),
        id: rid,
        key: existing?.key || rid,
        draftId: run.draftId || existing?.draftId || '',
        provider: run.provider,
        deviceId: selfDevId,
        deviceName: selfDevName,
        remotePeer: false,
        title: existing?.title || run.title || 'New Direct Session',
        cwd: existing?.cwd || run.cwd || '',
        folder: existing?.folder || run.folder || 'Workspace',
        model: runModelLabel,
        effort: runOverride?.effort || run.effort || existing?.effort || undefined,
        ...(runHeld
          ? { status: 'waiting', statusLabel: 'Needs your answer', dot: 'waiting', category: 'needs_input' }
          : {
              status: 'working',
              statusLabel: run.activeTool ? `Running ${run.activeTool}` : 'Streaming ⚡',
              dot: 'running',
              category: 'working'
            }),
        directStreaming: true,
        at: Math.max(Number(existing?.at || 0), Number(run.updatedAt || Date.now())),
        lastAssistantText: run.fullText ? run.fullText.slice(-220) : existing?.lastAssistantText || ''
      });
    }
  }
  if (!opts.localOnly) {
    const peerSources = [];
    if (bridge.edgeClient && typeof bridge.edgeClient.getPeerSnapshots === 'function') {
      for (const [pDevId, pEntry] of Object.entries(bridge.edgeClient.getPeerSnapshots())) {
        if (pDevId && pDevId !== selfDevId && Array.isArray(pEntry?.snapshot?.rows)) {
          peerSources.push({
            deviceId: pDevId,
            deviceName: pEntry.deviceName || pDevId,
            rows: pEntry.snapshot.rows
          });
        }
      }
    }
    for (const [rDevId, rEntry] of Object.entries(bridge.remoteDeviceStates || {})) {
      const rRows = Array.isArray(rEntry?.snapshot?.rows)
        ? rEntry.snapshot.rows
        : Array.isArray(rEntry?.rows)
          ? rEntry.rows
          : null;
      if (!rDevId || rDevId === selfDevId || !rRows) continue;
      if (peerSources.some((p) => p.deviceId === rDevId)) continue;
      peerSources.push({
        deviceId: rDevId,
        deviceName: rEntry.device?.name || rDevId,
        rows: rRows
      });
    }
    for (const src of peerSources) {
      for (const pr of src.rows) {
        if (!pr || !pr.id || rowById.has(pr.id)) continue;
        // The peer listed this session as its own, so it is the owner whatever folder the session ran in.
        const prOwner = inferRowOwnerDevice(
          { ...pr, deviceId: src.deviceId, deviceName: src.deviceName },
          { id: src.deviceId, name: src.deviceName },
          { trustStamp: true }
        );
        rowById.set(pr.id, {
          ...pr,
          deviceId: prOwner.id || prOwner.deviceId || src.deviceId,
          deviceName: prOwner.name || prOwner.deviceName || src.deviceName,
          remotePeer: true,
          model: formatModelDisplayName(pr.model, pr.provider, pr.effort || '')
        });
      }
    }
  }
  const nowMs = Date.now();
  const mergedRows = Array.from(rowById.values())
    .map((r) => {
      if (!r || !r.id) return r;
      const isArch = archivedSet.has(r.id) || Boolean(r.archived && !unarchivedAtMap[r.id]);
      const pinState = resolveRowPinState({ ...r, archived: isArch }, pinnedMap, unpinnedMap);
      const stopped = bridge.userStoppedSessionsById?.get(r.id);
      const recentlyStopped = Boolean(stopped && nowMs - Number(stopped.at || 0) < 60000);
      const modelOverride = bridge.sessionModelOverrides?.get(r.id) || null;
      const hasModelOverride = Boolean(modelOverride?.displayModel);
      const effectiveModelLabel = hasModelOverride
        ? formatModelDisplayName(modelOverride.displayModel, r.provider, modelOverride.effort)
        : formatModelDisplayName(r.model, r.provider, modelOverride?.effort || r.effort || '');
      const overrideLimit = hasModelOverride
        ? inferMaxContextTokens(r.provider, effectiveModelLabel)
        : Number(r.limitTokens || 0);
      const rowCtxLimits = inferSoftAndHardContextLimits(r.provider, effectiveModelLabel, overrideLimit);
      const upgradeLegacyRow =
        !hasModelOverride &&
        r.provider !== 'claude' &&
        Number(r.limitTokens || 0) === 256000 &&
        rowCtxLimits.softCompactionTargetTokens > 256000;
      const rowUsed = Number(r.usedTokens || 0);
      return {
        ...r,
        ...(!r.key && r.id ? { key: String(r.id) } : {}),
        model: effectiveModelLabel,
        effort: modelOverride?.effort || r.effort || undefined,
        ...(hasModelOverride || !r.limitTokens || upgradeLegacyRow
          ? { limitTokens: rowCtxLimits.softCompactionTargetTokens }
          : {}),
        ...(upgradeLegacyRow && rowUsed > 0
          ? {
              contextPct: Math.min(
                100,
                Math.max(1, Math.round((rowUsed / rowCtxLimits.softCompactionTargetTokens) * 100))
              )
            }
          : {}),
        softCompactionTargetTokens:
          hasModelOverride || upgradeLegacyRow
            ? rowCtxLimits.softCompactionTargetTokens
            : Number(r.softCompactionTargetTokens || rowCtxLimits.softCompactionTargetTokens),
        hardMaxTokens: hasModelOverride
          ? rowCtxLimits.hardMaxTokens
          : Number(r.hardMaxTokens || rowCtxLimits.hardMaxTokens),
        archived: isArch,
        pinned: pinState.pinned,
        pinnedAt: pinState.pinnedAt,
        pinUpdatedAt: pinState.pinUpdatedAt,
        ...(recentlyStopped
          ? {
              status: 'completed',
              statusLabel: 'Stopped',
              turnComplete: false,
              dot: r.open ? 'idle' : null,
              category: 'completed',
              unread: false,
              elsewhere: false,
              reason: null,
              bgTask: null,
              bgRunningCount: 0,
              bgTasks: Array.isArray(r.bgTasks)
                ? r.bgTasks.map((t) => (t.state === 'running' ? { ...t, state: 'cancelled' } : t))
                : []
            }
          : {})
      };
    })
    .sort(
      (a, b) =>
        Number(Boolean(b?.pinned && !b?.archived)) - Number(Boolean(a?.pinned && !a?.archived)) ||
        Number(b?.at || 0) - Number(a?.at || 0) ||
        Number(b?.pinnedAt || 0) - Number(a?.pinnedAt || 0)
    );
  const stampedWorkspaces = (workspaces || []).map((w) => ({
    ...w,
    deviceId: selfDevId,
    deviceName: selfDevName
  }));
  const byProviderUsage = snap?.usage?.byProvider || {};
  const summaryByProvider = snap?.usage
    ? {
        all: buildStandaloneSummaryForWindows(snap.usage.windows || {}),
        antigravity: buildStandaloneSummaryForWindows(byProviderUsage.antigravity || {}),
        claude: buildStandaloneSummaryForWindows(byProviderUsage.claude || {})
      }
    : cachedState?.summaryByProvider || null;
  let rawHotSwapHold = null;
  try {
    rawHotSwapHold = readHotSwapHoldStatus();
  } catch {}
  const redactedHotSwapHold =
    rawHotSwapHold && rawHotSwapHold.held === true
      ? {
          held: true,
          stage: rawHotSwapHold.stage,
          file: rawHotSwapHold.file,
          apps: rawHotSwapHold.apps,
          since: rawHotSwapHold.since
        }
      : null;

  const resultState = {
    ...cachedState,
    type: 'state',
    loading: false,
    hotSwapHold: redactedHotSwapHold,
    hideThirdPartyQuota:
      typeof persistedHub?.preferences?.hideThirdPartyQuota === 'boolean'
        ? persistedHub.preferences.hideThirdPartyQuota
        : Boolean(cachedState?.hideThirdPartyQuota),
    hideThirdPartyQuotaUpdatedAt: Number(
      persistedHub?.preferences?.hideThirdPartyQuotaUpdatedAt ||
        cachedState?.hideThirdPartyQuotaUpdatedAt ||
        0
    ),
    hideClaudeDesktop,
    hideClaudeDesktopUpdatedAt: Number(
      persistedHub?.preferences?.hideClaudeDesktopSessionsUpdatedAt ||
        cachedState?.hideClaudeDesktopUpdatedAt ||
        0
    ),
    device: {
      id: selfDevId,
      name: selfDevName,
      role: bridge.deviceInfo?.role || 'host',
      hostname: os.hostname(),
      homedir: os.homedir(),
      capabilities: bridge.deviceInfo?.capabilities || [],
      pcSetup: readCachedPcSetupSummary() || null,
      pwaReady: bridge.getSelfPwaReadySummary?.() || null,
      unsavedWork: readFleetUnsavedWorkSummary()
    },
    account: agyProviderInfo.account,
    usage: agyProviderInfo.usage,
    providers: {
      antigravity: agyProviderInfo,
      claude: claudeProviderInfo
    },
    accountOrder: Array.isArray(accountsView?.accountOrder)
      ? accountsView.accountOrder
      : cachedState?.accountOrder || [],
    groups,
    rows: mergedRows,
    devices: bridge.getUnifiedFleetDevices ? bridge.getUnifiedFleetDevices() : [],
    activeDirectRuns: bridge.directRunner ? bridge.directRunner.getActiveRuns() : [],
    total: mergedRows.length,
    summary: summaryByProvider?.all || cachedState?.summary || null,
    summaryByProvider,
    generatedAt: Date.now(),
    connection: bridge.getStatus(),
    approvals: standaloneApprovals,
    workspaces: stampedWorkspaces,
    unsavedWork: readUnsavedWorkSummary(),
    topSessions: (snap?.usage?.topThreads || cachedState.topSessions || []).slice(0, 12),
    personalLedger: bridge.personalLedger,
    lastNotification: bridge.lastNotification || null,
    recentNotifications: (bridge.recentNotifications || []).slice(0, 15),
    claudePermissionMode:
      typeof bridge.getClaudePermissionModeSnapshot === 'function'
        ? bridge.getClaudePermissionModeSnapshot()
        : undefined,
    antigravityModelCatalog: buildCompactModelCatalogForClient()
  };
  if (mergedRows.length > 0 && !opts.localOnly && typeof bridge._scheduleLastStateCacheWrite === 'function') {
    bridge._scheduleLastStateCacheWrite(resultState);
  }
  return resultState;
}

function attachKeepaliveStateBuilder(store, bridge, defaultOpts = {}) {
  // Service mode builds standalone directly; legacy mode reads localhost:4318 when VS Code holds :4318.
  bridge.buildFullState = async (opts = {}) => {
    const mergedOpts = { ...defaultOpts, ...opts };
    if (
      bridge.listening ||
      (!mergedOpts.fetchHostState && !isLegacyVsCodePhoneBridgeEnabled(mergedOpts))
    ) {
      return buildStandaloneState(store, bridge, mergedOpts);
    }
    const fetchHostState =
      typeof mergedOpts.fetchHostState === 'function'
        ? mergedOpts.fetchHostState
        : () => httpJson('http://localhost:4318/api/state', { timeoutMs: 8000 });
    const persistedHub =
      mergedOpts.persistedHub || readJsonSafe(mergedOpts.hubStateFile || HUB_STATE_FILE, {});
    try {
      const res = await fetchHostState();
      if (res && res.state && Array.isArray(res.state.rows)) {
        const state = res.state;
        if (state.personalLedger && typeof bridge.mergePersonalLedger === 'function') {
          bridge.mergePersonalLedger(state.personalLedger);
        }
        state.personalLedger = bridge.personalLedger;
        if (!state.claudePermissionMode && typeof bridge.getClaudePermissionModeSnapshot === 'function') {
          state.claudePermissionMode = bridge.getClaudePermissionModeSnapshot();
        }
        const hideDesktop =
          typeof state.hideClaudeDesktop === 'boolean'
            ? state.hideClaudeDesktop
            : typeof persistedHub?.preferences?.hideClaudeDesktopSessions === 'boolean'
              ? persistedHub.preferences.hideClaudeDesktopSessions
              : false;
        state.hideClaudeDesktop = hideDesktop;
        if (
          !Number(state.hideClaudeDesktopUpdatedAt) &&
          persistedHub?.preferences?.hideClaudeDesktopSessionsUpdatedAt
        ) {
          state.hideClaudeDesktopUpdatedAt = Number(
            persistedHub.preferences.hideClaudeDesktopSessionsUpdatedAt
          );
        }
        let threadsById = new Map();
        const hostRowIds = new Set(state.rows.map((r) => r && r.id).filter(Boolean));
        const hasApprovalOutsideRows =
          Array.isArray(state.approvals) &&
          state.approvals.some((a) => a && a.sessionId && !hostRowIds.has(a.sessionId));
        const needsTranscriptEnrich =
          state.scope === 'workspace' ||
          hasApprovalOutsideRows ||
          state.rows.some(
            (r) =>
              r &&
              (r.stepCount === undefined ||
                (r.provider === 'claude' &&
                  (r.claudeDesktop === undefined || r.claudeDesktopScratch === undefined)))
          );
        if (needsTranscriptEnrich) {
          try {
            const snap = await store.loadSnapshot({ forceQuota: false });
            if (snap && Array.isArray(snap.threads)) {
              threadsById = new Map(snap.threads.filter((t) => t && t.id).map((t) => [t.id, t]));
            }
          } catch {}
        }
        const rawApprovals = Array.isArray(state.approvals) ? [...state.approvals] : [];
        const rows = state.rows.map((r) => {
          const t = threadsById.get(r.id);
          const claudeDesktopScratch = Boolean(
            r.claudeDesktopScratch ||
              t?.claudeDesktopScratch ||
              isClaudeDesktopScratchPath(
                r.cwd || r.filePath || t?.cwd || t?.filePath || store?.claudeFileById?.get?.(r.id) || ''
              )
          );
          const claudeDesktop = Boolean(r.claudeDesktop || t?.claudeDesktop || claudeDesktopScratch);
          const pendingQuestion = r.pendingQuestion || t?.pendingQuestion || null;
          const stepCount = Number(r.stepCount ?? t?.stepCount ?? 0);
          const lastAssistantText = r.lastAssistantText || t?.lastAssistantText || '';
          const status = pendingQuestion ? 'waiting' : r.status;
          const category = status === 'waiting' ? 'needs_input' : r.category;
          const dot = status === 'waiting' ? 'waiting' : r.dot;
          const suppressDesktopAlert = claudeDesktopScratch || (hideDesktop && claudeDesktop);
          if (
            !suppressDesktopAlert &&
            pendingQuestion &&
            !rawApprovals.some((a) => a && a.sessionId === r.id && a.kind === 'question')
          ) {
            const stepKey = pendingQuestion.stepIndex || stepCount || 0;
            const qId = `question-${r.id}-${stepKey}`;
            const filteredIdx = rawApprovals.findIndex(
              (a) => a && a.sessionId === r.id && a.kind === 'waiting_session'
            );
            if (filteredIdx >= 0) rawApprovals.splice(filteredIdx, 1);
            rawApprovals.push({
              id: qId,
              approvalId: qId,
              provider: r.provider || 'antigravity',
              claudeDesktop,
              claudeDesktopScratch,
              sessionId: r.id,
              title: r.title || 'Session asking a question',
              toolName: 'Question',
              detail: pendingQuestion.questionText || 'Waiting for your answer',
              isMultiSelect: Boolean(pendingQuestion.isMultiSelect),
              options: pendingQuestion.options || [],
              questions: pendingQuestion.questions || [],
              stepIndex: stepKey,
              kind: 'question',
              createdAt: (pendingQuestion.at ? pendingQuestion.at * 1000 : r.at) || Date.now()
            });
          }
          return {
            ...r,
            claudeDesktop,
            claudeDesktopScratch,
            status,
            category,
            dot,
            stepCount,
            lastAssistantText,
            pendingQuestion,
            model: formatModelDisplayName(r.model, r.provider)
          };
        });
        const rowById = new Map(rows.map((r) => [r.id, r]));
        state.rows = rows;
        state.approvals = rawApprovals
          .map((a) => {
            if (!a) return null;
            const row = rowById.get(a.sessionId);
            const thread = threadsById.get(a.sessionId);
            const meta = row || thread;
            const isScratch = Boolean(
              a.claudeDesktopScratch ||
                meta?.claudeDesktopScratch ||
                isClaudeDesktopScratchPath(
                  meta?.cwd ||
                    meta?.filePath ||
                    a.cwd ||
                    a.filePath ||
                    store?.claudeFileById?.get?.(a.sessionId) ||
                    ''
                )
            );
            const isDesktop = Boolean(a.claudeDesktop || meta?.claudeDesktop || isScratch);
            if (isScratch || (hideDesktop && isDesktop)) {
              return null;
            }
            return {
              ...a,
              claudeDesktop: isDesktop,
              claudeDesktopScratch: isScratch
            };
          })
          .filter(Boolean);
        const snapThreads = rows.map((r) => ({
          id: r.id,
          provider: r.provider,
          claudeDesktop: Boolean(r.claudeDesktop),
          claudeDesktopScratch: Boolean(r.claudeDesktopScratch),
          title: r.title,
          cwd: r.cwd,
          filePath: r.filePath || threadsById.get(r.id)?.filePath || '',
          workspaceLabel: r.folder,
          branch: r.branch,
          model: r.model,
          stepCount: r.stepCount,
          lastAssistantText: r.lastAssistantText,
          pendingQuestion: r.pendingQuestion,
          updatedAt: Math.floor((r.at || Date.now()) / 1000)
        }));
        const extraSnapSource =
          threadsById.size > 0
            ? Array.from(threadsById.values())
            : Array.isArray(bridge.hub?.snapshot?.threads)
              ? bridge.hub.snapshot.threads
              : [];
        for (const t of extraSnapSource) {
          if (!t || !t.id || rowById.has(t.id)) continue;
          const tScratch = Boolean(
            t.claudeDesktopScratch || isClaudeDesktopScratchPath(t.cwd || t.filePath || '')
          );
          snapThreads.push({
            id: t.id,
            provider: t.provider || 'antigravity',
            claudeDesktop: Boolean(t.claudeDesktop || tScratch),
            claudeDesktopScratch: tScratch,
            title: t.title || 'Untitled session',
            cwd: t.cwd || '',
            filePath: t.filePath || '',
            workspaceLabel: t.workspaceLabel || '',
            branch: t.branch || '',
            model: t.model || '',
            stepCount: Number(t.stepCount || 0),
            lastAssistantText: t.lastAssistantText || '',
            pendingQuestion: t.pendingQuestion || null,
            updatedAt: Number(t.updatedAt || 0)
          });
        }
        bridge.hub = makeStandaloneHub(snapThreads);
        return state;
      }
    } catch {}
    return buildStandaloneState(store, bridge, mergedOpts);
  };
}

function acquireSingleInstanceLock(bootMtime, forceRestart) {
  try {
    if (!fs.existsSync(CLAUDE_DIR)) {
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    }
    let existingPid = 0;
    if (fs.existsSync(PID_FILE)) {
      existingPid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim() || 0);
    }
    const existingMeta = readJsonSafe(META_FILE, {});
    if (!existingPid && existingMeta.pid) {
      existingPid = Number(existingMeta.pid);
    }
    if (isPidAlive(existingPid)) {
      const existingBoot = Number(existingMeta.bootMtime || 0);
      if (!forceRestart && existingBoot >= bootMtime - 1000) {
        return false;
      }
      try {
        process.kill(existingPid);
        log(`[INFO] Replaced older keepalive instance (pid ${existingPid})`);
      } catch {}
    }
    fs.writeFileSync(PID_FILE, String(process.pid), 'utf8');
    fs.writeFileSync(
      META_FILE,
      JSON.stringify({
        pid: process.pid,
        startedAt: Date.now(),
        bootMtime,
        script: __filename
      }),
      'utf8'
    );
  } catch {}
  return true;
}

let respawnTriggered = false;
function respawnSelfAndExit(updateInfo = null) {
  if (respawnTriggered) return;
  respawnTriggered = true;
  try {
    const origPs1 = path.join(__dirname, 'relay_keepalive_start.ps1');
    let startPs1 = origPs1;
    const candidateTargets = updateInfo?.updatedPaths || updateInfo?.updatedTargets;
    if (Array.isArray(candidateTargets)) {
      for (const tgt of candidateTargets) {
        const candPs1 = path.join(tgt, 'scripts', 'relay_keepalive_start.ps1');
        if (getFileMtimeMs(candPs1) > getFileMtimeMs(startPs1)) {
          startPs1 = candPs1;
        }
      }
    }
    const psArgs = [
      '-NoProfile',
      '-NonInteractive',
      '-WindowStyle',
      'Hidden',
      '-ExecutionPolicy',
      'Bypass',
      '-File',
      startPs1,
      '-Restart'
    ];
    // When respawning onto a newly self-updated target folder (e.g. ~/.vscode/extensions/bhfirms.theo-hub-* when
    // ~/bhfirms/theo-hub was skipped due to git state), re-register the Scheduled Task & Startup VBS to that folder.
    const movedTarget = path.resolve(startPs1) !== path.resolve(origPs1) || Boolean(updateInfo?.updated);
    if (!movedTarget) {
      psArgs.push('-SkipTaskCheck');
    }
    const child = spawn('powershell.exe', psArgs, {
      cwd: path.dirname(path.dirname(startPs1)),
      detached: true,
      windowsHide: true,
      stdio: 'ignore'
    });
    child.unref();
    log('[INFO] Code updated on disk -> triggered WMI respawn via relay_keepalive_start.ps1');
  } catch (err) {
    log(`[WARN] Self-respawn failed: ${err.message}`);
  }
  setTimeout(() => process.exit(0), 400);
}

function attachKeepaliveCommandProxy(store, bridge, opts = {}) {
  const httpJsonFn = typeof opts.httpJson === 'function' ? opts.httpJson : httpJson;
  const origExecuteRemoteCommand = bridge.executeRemoteCommand.bind(bridge);
  bridge.executeRemoteCommand = async (cmd = {}) => {
    if (bridge.listening || (!opts.httpJson && !isLegacyVsCodePhoneBridgeEnabled(opts))) {
      return origExecuteRemoteCommand(cmd);
    }
    const type = String(cmd.type || cmd.action || '').trim();
    const subAction = String(cmd.subAction || cmd.action || '').trim();
    const cleanTargetCandidate = (val) => {
      const s = String(val || '').trim();
      if (!s || s === '__new__' || s.startsWith('cmd-') || s.startsWith('draft-new-') || s.startsWith('draft-direct-')) {
        return '';
      }
      return s;
    };
    const targetId = cleanTargetCandidate(cmd.threadId) || cleanTargetCandidate(cmd.id);
    if (type === 'requestThread' || (type === 'sessionAction' && subAction === 'requestThread')) {
      const id = targetId;
      const provider = cmd.provider === 'claude' ? 'claude' : 'antigravity';
      if (id) {
        if (!bridge.requestedThreads) bridge.requestedThreads = new Map();
        bridge.requestedThreads.set(id, { provider, requestedAt: Date.now() });
      }
      return { ok: true, id, provider };
    }
    if (type === 'send' || type === 'sendPrompt') {
      return httpJsonFn('http://localhost:4318/api/send', {
        method: 'POST',
        body: JSON.stringify({ ...cmd, id: targetId, threadId: targetId }),
        timeoutMs: 16000
      }).catch(() => origExecuteRemoteCommand(cmd));
    }
    if (type === 'approve' || type === 'respondApproval' || type === 'answerQuestion') {
      const localRes = await httpJsonFn('http://localhost:4318/api/approve', {
        method: 'POST',
        body: JSON.stringify(cmd),
        timeoutMs: 8000
      }).catch(() => null);
      if (localRes) return localRes;
      let fallbackRes = null;
      try {
        fallbackRes = await origExecuteRemoteCommand(cmd);
        if (fallbackRes && (fallbackRes.ok || fallbackRes.blocked)) return fallbackRes;
      } catch {}
      const sessId = String(cmd.sessionId || targetId || cmd.approvalId || '').trim();
      if (
        cmd.provider !== 'claude' &&
        !fallbackRes?.blocked &&
        !(typeof bridge?.isScratchDesktopSession === 'function' && sessId && bridge.isScratchDesktopSession(sessId)) &&
        sessId &&
        store?.answerAntigravityQuestion
      ) {
        return store.answerAntigravityQuestion(sessId, cmd).catch(() => ({ ok: false }));
      }
      return fallbackRes || { ok: false };
    }
    if (
      type === 'setClaudePermissionMode' ||
      (type === 'sessionAction' && subAction === 'setClaudePermissionMode')
    ) {
      return httpJsonFn('http://localhost:4318/api/claude-permission-mode', {
        method: 'POST',
        body: JSON.stringify(cmd),
        timeoutMs: 8000
      })
        .then((res) => (res && res.ok ? res : origExecuteRemoteCommand(cmd)))
        .catch(() => origExecuteRemoteCommand(cmd));
    }
    if (
      type === 'cancelBgTask' ||
      type === 'cancelAllBgTasks' ||
      type === 'setHideThirdPartyQuota' ||
      type === 'setHideClaudeDesktop'
    ) {
      return bridge.executeRemoteCommand({
        ...cmd,
        type: 'sessionAction',
        subAction: type
      });
    }
    if (type === 'sessionAction') {
      const localRes = await httpJsonFn('http://localhost:4318/api/session-action', {
        method: 'POST',
        body: JSON.stringify({ ...cmd, id: targetId || cmd.id, action: subAction }),
        timeoutMs: 8000
      }).catch(() => null);
      if (localRes && (localRes.ok || localRes.blocked)) return localRes;
      if (subAction === 'cancelBgTask' && store?.cancelBackgroundTaskOnServer) {
        const sid = String(cmd.sessionId || targetId || cmd.id || '').trim();
        const tid = String(cmd.taskId || '').trim();
        if (sid && tid) {
          const out = await store
            .cancelBackgroundTaskOnServer(sid, cmd.provider || '', {
              id: tid,
              fullId: tid,
              kind: cmd.kind || 'task',
              stepIndex: typeof cmd.stepIndex === 'number' ? cmd.stepIndex : -1
            })
            .catch(() => ({ ok: false }));
          return { ok: Boolean(out?.ok) };
        }
      }
      if (
        (subAction === 'interrupt' || subAction === 'stop' || subAction === 'cancel') &&
        (targetId || cmd.id) &&
        store?.cancelSessionOnServer
      ) {
        const ok = await store
          .cancelSessionOnServer(targetId || cmd.id, cmd.provider)
          .catch(() => false);
        return { ok: Boolean(ok) };
      }
      // Host down: apply unread / archive / group edits straight to ~/.claude/.theo-hub-state.json
      // via TheoRemoteBridge's standalone branch (hub-less executeRemoteCommand) instead of
      // silently dropping them.
      try {
        const standaloneRes = await origExecuteRemoteCommand({
          ...cmd,
          type: 'sessionAction',
          subAction,
          action: subAction,
          threadId: targetId
        });
        if (standaloneRes && (standaloneRes.ok || standaloneRes.blocked)) return standaloneRes;
      } catch {}
      return localRes || { ok: false };
    }
    return { ok: true };
  };
}

async function main() {
  const once = process.argv.includes('--once');
  const forceRestart = process.argv.includes('--restart') || process.argv.includes('--force');
  const bootMtime = computeDiskMaxMtime();

  if (!once) {
    const acquired = acquireSingleInstanceLock(bootMtime, forceRestart);
    if (!acquired) {
      process.exit(0);
    }
    try {
      ensureServiceCutoverStatsInitialized();
    } catch {}
  }

  if (!once) {
    // This process is what keeps the phone linked when no VS Code window is open. A stray error in a timer or
    // an unawaited promise is written to the log and survived; a burst of them restarts the service cleanly.
    const strayErrorTimes = [];
    const noteStrayError = (kind, err) => {
      const nowMs = Date.now();
      while (strayErrorTimes.length && nowMs - strayErrorTimes[0] > 60000) strayErrorTimes.shift();
      strayErrorTimes.push(nowMs);
      if (strayErrorTimes.length <= 6) {
        log(`[ERR] ${kind}: ${String(err?.stack || err?.message || err).slice(0, 900)}`);
      }
      if (strayErrorTimes.length >= 25) {
        strayErrorTimes.length = 0;
        log('[ERR] 25 stray errors within a minute -> restarting the service');
        respawnSelfAndExit();
      }
    };
    process.on('uncaughtException', (err) => noteStrayError('uncaught exception', err));
    process.on('unhandledRejection', (err) => noteStrayError('unhandled rejection', err));
  }

  const store = new AntigravityDataStore();
  const accountVault = new AccountVaultManager();
  const bridge = new TheoRemoteBridge(
    { extensionPath: REPO_ROOT },
    { store, accountVault }
  );
  // Until this process serves the phone itself (its server's 'listening' handler lifts this), a headless run
  // started here cannot show a tool request to anyone: it is refused at once instead of held.
  try {
    bridge.directRunner?.setPhoneLinkDown?.();
  } catch {}

  let yieldCooldownUntil = 0;

  async function releaseStandaloneListeners() {
    yieldCooldownUntil = Date.now() + 12000;
    try {
      if (bridge.edgeClient) {
        bridge.edgeClient.stop();
      }
    } catch {}
    try {
      if (bridge.wsHub) {
        bridge.wsHub.closeAll();
        bridge.wsHub = null;
      }
    } catch {}
    for (const client of Array.from(bridge.sseClients || [])) {
      try {
        client.end();
      } catch {}
    }
    bridge.sseClients?.clear?.();
    if (bridge.standbyBindTimer) {
      clearInterval(bridge.standbyBindTimer);
      bridge.standbyBindTimer = null;
    }
    if (bridge.server) {
      await new Promise((resolve) => {
        try {
          bridge.server.closeAllConnections?.();
        } catch {}
        try {
          bridge.server.close(() => resolve());
        } catch {
          resolve();
        }
        setTimeout(resolve, 150);
      });
      bridge.server = null;
      bridge.listening = false;
    }
    log('[INFO] Yielded standalone :4318 + Edge Relay to VS Code extension host');
  }

  let pendingSelfUpdateInfo = null;
  let isBackgroundChildBusy = () => false;

  bridge.onYieldPortRequested = releaseStandaloneListeners;
  bridge.onSelfUpdateApplied = (info) => {
    if (!once) {
      const rel = info?.release || info;
      const hasActiveDirectRuns = (bridge.directRunner?.getActiveRuns?.().length || 0) > 0;
      if (isBackgroundChildBusy() || hasActiveDirectRuns) {
        pendingSelfUpdateInfo = info;
        log(
          `[INFO] Self-updated theo-hub bundle (${rel?.version || ''} @ ${rel?.builtAt || 0}) -> deferring daemon respawn until background/session runs finish`
        );
        return;
      }
      log(`[INFO] Self-updated theo-hub bundle (${rel?.version || ''} @ ${rel?.builtAt || 0}) -> respawning daemon`);
      respawnSelfAndExit(info);
    }
  };

  attachKeepaliveStateBuilder(store, bridge);
  attachKeepaliveCommandProxy(store, bridge);

  // Non-competing watchdog state machine:
  //   healthy      -> host ping fresh & code current; probe cloud stamp every 60s, otherwise 100% idle
  //   hostLagging  -> host ping reachable & code current, but lastCloudSyncAt > 45s; nudge /api/cloud-sync first
  //   staleHost    -> host ping reachable but running older remote.js & cloud stamp stale; take over state sync
  //   hostDown     -> VS Code closed (:4318 unreachable); sync standalone via AntigravityDataStore
  const STORE_PROBE_MS = 45000;
  const STALE_STORE_MS = 45000;
  const RECHECK_MS = 120000;
  const PAUSE_MS = 25000;
  let staleHost = false;
  let lastProbeAt = 0;
  let pauseUntil = 0;
  let lastReason = '';
  let lastErr = '';
  let tickInFlight = false;

  const headlessBridgeState = { resumeCheckInFlight: false, lastBootCheckedHubStartedAt: 0 };
  async function runHeadlessCascadeContinuity() {
    try {
      const savedHub = readPersistentHubState();
      if (!savedHub || !savedHub.port || !savedHub.csrfToken) return;
      const hubStartedAtSec = Number(savedHub.startedAt || savedHub.updatedAt || 0);
      const firstForHubBoot =
        hubStartedAtSec > 0 && headlessBridgeState.lastBootCheckedHubStartedAt !== hubStartedAtSec;
      const candidateIds = findActiveCascadesFromDiskTranscripts(Date.now(), {
        maxInterruptedAgeMs: 86400 * 1000,
        hubStartedAtSec
      });
      const res = await checkAndResumeInterruptedCascades(headlessBridgeState, {
        candidateIds: Array.isArray(candidateIds) ? candidateIds : [],
        includeIdleSummaries: true,
        hubStartedAtSec,
        logFn: (line) => log(line.includes('Send failed') ? `[WARN] ${line}` : `[INFO] ${line}`),
        ...(firstForHubBoot ? { bypassMinAge: true } : {})
      });
      if (firstForHubBoot && !res?.skippedInFlight) {
        headlessBridgeState.lastBootCheckedHubStartedAt = hubStartedAtSec;
      }
      if (res && res.resumed > 0) {
        log(
          `[INFO] Headless 24/7 daemon auto-resumed ${res.resumed} cascade(s) while VS Code is closed`
        );
      }
    } catch {}
  }

  const memoryGitIdleSync = createMemoryGitIdleSyncController({ logFn: log });

  function observeStatusForMemoryGit(st, nowMs = Date.now()) {
    if (!st || (!st.cloudConfigured && !st.edgeRelayUrl)) return;
    const online =
      Boolean(st.edgeRelay?.connected) ||
      (!st.lastCloudError &&
        Number(st.lastCloudSyncAt || 0) > 0 &&
        nowMs - Number(st.lastCloudSyncAt || 0) < 90000);
    if (online) {
      if (memoryGitIdleSync.noteCloudConnectivity(true, nowMs)) {
        memoryGitIdleSync.maybeTick(nowMs);
      }
    } else if (st.lastCloudError && !st.edgeRelay?.connected) {
      memoryGitIdleSync.noteCloudConnectivity(false, nowMs);
    }
  }

  function syncDirectActiveStamp(count) {
    if (once || process.env.THEO_SMOKE_TEST === '1') return;
    try {
      const stampPath = path.join(CLAUDE_DIR, '.theo-direct-active.json');
      const n = Number(count || 0);
      if (n <= 0) {
        if (fs.existsSync(stampPath)) fs.unlinkSync(stampPath);
        return;
      }
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
      const raw = JSON.stringify({ pid: process.pid, count: n, updatedAt: Date.now() });
      const tmpPath = `${stampPath}.${process.pid}.tmp`;
      try {
        fs.writeFileSync(tmpPath, raw, 'utf8');
        fs.renameSync(tmpPath, stampPath);
      } catch {
        try { fs.unlinkSync(tmpPath); } catch {}
        fs.writeFileSync(stampPath, raw, 'utf8');
      }
    } catch {}
  }

  async function runSync(reason, syncOpts = {}) {
    if (
      (reason === 'standalone-host' || reason === 'service-host' || reason === 'host-down') &&
      !bridge.hasAttachedVsCodeUi?.()
    ) {
      await runHeadlessCascadeContinuity();
    }
    bridge.lastCloudError = '';
    const syncRes = await bridge.syncCloudRelay({ pushState: true, ...syncOpts });
    if (!once) {
      observeStatusForMemoryGit(bridge.getStatus(), Date.now());
    }
    if (!bridge.listening && isLegacyVsCodePhoneBridgeEnabled() && syncRes && bridge.pushDevices.length > 0) {
      for (const dev of bridge.pushDevices) {
        await httpJson('http://localhost:4318/api/push-register', {
          method: 'POST',
          body: JSON.stringify(dev),
          timeoutMs: 2000
        }).catch(() => {});
      }
    }
    if (!bridge.listening && isLegacyVsCodePhoneBridgeEnabled() && syncRes && bridge.personalLedger) {
      await httpJson('http://localhost:4318/api/personal-ledger', {
        method: 'POST',
        body: JSON.stringify({ personalLedger: bridge.personalLedger }),
        timeoutMs: 2500
      }).catch(() => {});
    }
    if (once) {
      console.log('[OK] Cloud Relay synced:', JSON.stringify(syncRes));
    } else if (!syncRes) {
      if (bridge.lastCloudError && bridge.lastCloudError !== lastErr) {
        lastErr = bridge.lastCloudError;
        log(`[WARN] keepalive sync (${reason}) failed: ${lastErr}`);
      }
    } else if (reason !== lastReason) {
      lastErr = '';
      log(`[INFO] keepalive syncing (${reason})`);
      lastReason = reason;
    }
  }

  let prepatchTickCount = 0;
  // Patching runs in a worker thread when bridge.js offers it, so this daemon keeps relaying the phone while a
  // bundle is rewritten.
  function maybePrepatchExtensions() {
    const runner =
      typeof prepatchInstalledExtensionsAsync === 'function'
        ? prepatchInstalledExtensionsAsync
        : prepatchInstalledExtensions;
    let pending;
    try {
      pending = Promise.resolve(runner(REPO_ROOT));
    } catch {
      return;
    }
    pending.then(logPrepatchResult).catch(() => {});
  }

  function logPrepatchResult(res) {
    try {
      if (Array.isArray(res?.updatedDirs) && res.updatedDirs.length > 0) {
        log(
          `[INFO] pre-patched updated extension(s): ${res.updatedDirs.map((d) => path.basename(d)).join(', ')}`
        );
      }
      if (Array.isArray(res?.errors) && res.errors.length > 0) {
        for (const err of res.errors) {
          log(`[WARN] pre-patch failed for ${path.basename(err.extensionDir)}: ${err.error}`);
        }
      }
    } catch {}
  }

  let lastBlindspotCheckAt = 0;
  let lastBlindspotSpawnAt = 0;
  let blindspotChildInFlight = false;
  let blindspotChildStartedAt = 0;
  let cloudMemSyncInFlight = false;
  let cloudMemSyncStartedAt = 0;
  let cutoverSetupChildInFlight = false;
  let cutoverSetupStartedAt = 0;
  let lastCutoverSetupAttemptAt = 0;
  const cloudDeletionSeenMap = new Map();
  isBackgroundChildBusy = () =>
    (blindspotChildInFlight && Date.now() - blindspotChildStartedAt < 40 * 60 * 1000) ||
    (cloudMemSyncInFlight && Date.now() - cloudMemSyncStartedAt < 90 * 1000) ||
    (cutoverSetupChildInFlight && Date.now() - cutoverSetupStartedAt < 5 * 60 * 1000) ||
    memoryGitIdleSync.isInFlight() ||
    // A bundle patch in the worker thread must finish before a respawn exits this process.
    (typeof isBridgePatchWorkerBusy === 'function' && isBridgePatchWorkerBusy());

  function maybeMigratePostBootstrapSetup(syncRes) {
    if (once || process.env.THEO_SMOKE_TEST === '1') return;
    const nowMs = Date.now();
    if (cutoverSetupChildInFlight && nowMs - cutoverSetupStartedAt < 5 * 60 * 1000) return;
    if (nowMs - lastCutoverSetupAttemptAt < 10 * 60 * 1000 && syncRes?.mode !== 'bootstrap') return;

    const homeDir = os.homedir();
    const bhfMem = path.join(homeDir, 'bhfirms', 'memory');
    const setupPy = path.join(bhfMem, 'Admin', 'theo-pc-setup.py');
    if (!fs.existsSync(path.join(bhfMem, 'THEO.md')) || !fs.existsSync(setupPy)) return;

    let needsMigrate = Boolean(syncRes && syncRes.mode === 'bootstrap');
    if (!needsMigrate) {
      try {
        const claudePtr = path.join(homeDir, '.claude', 'CLAUDE.md');
        const guardHook = path.join(homeDir, '.claude', 'hooks', 'bhfirms-memory-guard.py');
        const shortcutStamp = path.join(homeDir, '.theo', 'pc-setup-shortcut.json');
        if (!fs.existsSync(claudePtr) || /onedrive/i.test(fs.readFileSync(claudePtr, 'utf8'))) {
          needsMigrate = true;
        } else if (!fs.existsSync(guardHook) || !fs.readFileSync(guardHook, 'utf8').includes('bhfirms')) {
          needsMigrate = true;
        } else if (
          process.platform === 'win32' &&
          (!fs.existsSync(shortcutStamp) || /onedrive/i.test(fs.readFileSync(shortcutStamp, 'utf8')))
        ) {
          needsMigrate = true;
        }
      } catch {
        needsMigrate = true;
      }
    }
    if (!needsMigrate) return;

    const pyExe = findLocalPythonExe();
    if (!pyExe) return;
    try {
      lastCutoverSetupAttemptAt = nowMs;
      cutoverSetupChildInFlight = true;
      cutoverSetupStartedAt = nowMs;
      const child = spawn(
        pyExe,
        [
          setupPy,
          '--apply',
          '--only',
          'antigravity-config,claude-guard,claude-project-memory,git-identity,memory-git,blindspot-review,pc-setup-shortcut'
        ],
        {
          detached: /pythonw\.exe$/i.test(pyExe),
          windowsHide: true,
          stdio: 'ignore'
        }
      );
      const clearSetup = () => {
        cutoverSetupChildInFlight = false;
      };
      child.on('exit', clearSetup);
      child.on('error', clearSetup);
      child.unref();
      log('[INFO] triggered post-cutover PC setup migration');
    } catch {
      cutoverSetupChildInFlight = false;
    }
  }

  function maybeSyncMemoryCloudVault() {
    if (
      once ||
      process.env.THEO_SMOKE_TEST === '1' ||
      process.env.THEO_DISABLE_MEMORY_CLOUD_SYNC === '1'
    ) {
      return;
    }
    const nowMs = Date.now();
    if (cloudMemSyncInFlight && nowMs - cloudMemSyncStartedAt < 90 * 1000) return;
    let cloudSyncMod = null;
    try {
      cloudSyncMod = require('./memory_cloud_sync.cjs');
    } catch {
      return;
    }
    if (!cloudSyncMod || typeof cloudSyncMod.runCloudSync !== 'function') return;
    let syncMode = 'pull-if-changed';
    try {
      if (typeof cloudSyncMod.detectLocalVaultDrift === 'function') {
        const drift = cloudSyncMod.detectLocalVaultDrift({
          quietMs: 90 * 1000,
          nowMs,
          deletionSeenMap: cloudDeletionSeenMap
        });
        if (drift && drift.settled) {
          syncMode = 'sync';
        }
      }
    } catch {}
    cloudMemSyncInFlight = true;
    cloudMemSyncStartedAt = nowMs;
    Promise.resolve()
      .then(() => cloudSyncMod.runCloudSync({ mode: syncMode }))
      .then((res) => {
        if (res && res.ok) {
          if (
            !res.unchanged &&
            (res.pulledCount > 0 || res.pushedCount > 0 || res.deletedLocalCount > 0 || res.deletedCloudCount > 0 || res.mergedCount > 0)
          ) {
            log(
              `[INFO] memory cloud vault synced (rev ${res.rev}, mode=${res.mode || syncMode}): pulled=${res.pulledCount}, pushed=${res.pushedCount}` +
                (res.mergedCount > 0 ? `, line-merged=${res.mergedCount}` : '')
            );
          }
          maybeMigratePostBootstrapSetup(res);
        }
      })
      .catch(() => {})
      .finally(() => {
        cloudMemSyncInFlight = false;
      });
  }

  function currentIsoWeekLocal(nowDate = new Date()) {
    const d = new Date(Date.UTC(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate()));
    const isoDay = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - isoDay);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
    return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
  }

  function maybeTriggerWeeklyBlindspotReview() {
    if (once || process.platform !== 'win32') return;
    // Wait until initial keepalive ticks have synced `bridge.cloudControlDocs` from THEO Store.
    if (prepatchTickCount < 6) return;
    const nowMs = Date.now();
    if (blindspotChildInFlight && nowMs - blindspotChildStartedAt < 40 * 60 * 1000) return;
    blindspotChildInFlight = false;
    if (nowMs - lastBlindspotCheckAt < 30 * 60 * 1000) return;
    lastBlindspotCheckAt = nowMs;
    if (nowMs - lastBlindspotSpawnAt < 2 * 60 * 60 * 1000) return;

    const nowDate = new Date(nowMs);
    if (nowDate.getDay() === 1 && nowDate.getHours() < 8) return;

    const curWeek = currentIsoWeekLocal(nowDate);
    const homeDir = os.homedir();
    const stateFile = path.join(homeDir, '.theo', 'blindspot-review-state.json');
    let localState = {};
    try {
      if (fs.existsSync(stateFile)) {
        localState = JSON.parse(fs.readFileSync(stateFile, 'utf8')) || {};
      }
    } catch {}

    const hasPendingWork = Boolean(localState.pending || localState.gitPending);
    if (!hasPendingWork && localState.lastWeek === curWeek) return;
    const cloudLastWeek = String(bridge.cloudControlDocs?.blindspot_review?.lastWeek || '');
    if (!hasPendingWork && cloudLastWeek && cloudLastWeek >= curWeek) return;

    const memPaths = resolveTheoMemoryPaths({ homeDir });
    const reviewRoot =
      memPaths.memoryRoot ||
      path.join(homeDir, 'bhfirms', 'memory');
    const reviewScript = path.join(reviewRoot, 'Admin', 'theo-blindspot-review.py');
    if (!fs.existsSync(reviewScript)) return;
    const pyExe = findLocalPythonExe();
    if (!pyExe) return;

    try {
      lastBlindspotSpawnAt = nowMs;
      blindspotChildInFlight = true;
      blindspotChildStartedAt = nowMs;
      const child = spawn(pyExe, [reviewScript], {
        detached: /pythonw\.exe$/i.test(pyExe),
        windowsHide: true,
        stdio: 'ignore'
      });
      const clearInFlight = () => {
        blindspotChildInFlight = false;
      };
      child.on('exit', clearInFlight);
      child.on('error', clearInFlight);
      child.unref();
      log(`[INFO] triggered weekly blind-spot review check (${curWeek})`);
    } catch {
      blindspotChildInFlight = false;
    }
  }

  async function tick() {
    if (tickInFlight || respawnTriggered) return;
    tickInFlight = true;
    try {
      prepatchTickCount += 1;
      if (prepatchTickCount === 1 || prepatchTickCount % 3 === 0) {
        maybePrepatchExtensions();
      }
      if (!once && (prepatchTickCount === 2 || prepatchTickCount % 12 === 0)) {
        checkPcSetupStatus().catch(() => {});
      }
      if (!once && (prepatchTickCount === 3 || prepatchTickCount % 12 === 3)) {
        maybeSyncMemoryCloudVault();
      }
      maybeTriggerWeeklyBlindspotReview();
      if (!once) {
        memoryGitIdleSync.maybeTick();
        try {
          if (fs.existsSync(PID_FILE)) {
            const ownerPid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim() || 0);
            if (ownerPid && ownerPid !== process.pid && isPidAlive(ownerPid)) {
              process.exit(0);
              return;
            }
          }
        } catch {}
        const childStillRunning =
          isBackgroundChildBusy() || (bridge.directRunner?.getActiveRuns?.().length || 0) > 0;
        if (
          !childStillRunning &&
          (pendingSelfUpdateInfo || computeDiskMaxMtime() > bootMtime + 2000)
        ) {
          const deferredInfo = pendingSelfUpdateInfo;
          pendingSelfUpdateInfo = null;
          respawnSelfAndExit(deferredInfo);
          return;
        }
      }

      if (once) {
        await runSync('once');
        return;
      }

      const legacySwitchEnabled = isLegacyVsCodePhoneBridgeEnabled();
      syncDirectActiveStamp(bridge.directRunner?.getActiveRuns?.().length || 0);

      if (bridge.listening) {
        observeStatusForMemoryGit(bridge.getStatus(), Date.now());
        // Start standalone Antigravity engine when no VS Code window UI is attached on this PC.
        if (
          !bridge.hasAttachedVsCodeUi?.() &&
          process.env.THEO_SMOKE_TEST !== '1' &&
          process.env.THEO_DISABLE_AGY_ENGINE_START !== '1'
        ) {
          ensureStandaloneAgyEngine().catch(() => {});
        }
        await runSync(legacySwitchEnabled ? 'standalone-host' : 'service-host');
        return;
      }

      if (!legacySwitchEnabled) {
        if (Date.now() > yieldCooldownUntil && !bridge.server) {
          bridge.disposed = false;
          bridge.startHttpServer();
          if (bridge.server) {
            bridge.server.once('listening', () => {
              log('[INFO] Service bound :4318 + Edge Relay (single-service owner)');
            });
            await new Promise((resolve) => {
              if (bridge.listening || !bridge.server) {
                resolve();
                return;
              }
              let doneFired = false;
              const done = () => {
                if (doneFired) return;
                doneFired = true;
                clearTimeout(waitTimer);
                resolve();
              };
              const waitTimer = setTimeout(done, 450);
              if (typeof waitTimer.unref === 'function') waitTimer.unref();
              bridge.server.once('listening', done);
              bridge.server.once('error', done);
            });
          }
        }
        let allowStandby = false;
        if (!bridge.listening) {
          const ping = await httpJson('http://localhost:4318/api/ping', { timeoutMs: 1500 }).catch(
            () => ({})
          );
          const syncAge = Date.now() - Number(ping?.lastCloudSyncAt || 0);
          if (!ping?.ok || ping.standaloneMode !== true || syncAge > 25000) {
            allowStandby = true;
          }
        }
        await runSync('service-host', allowStandby ? { allowStandby: true } : {});
        return;
      }

      const ping = await httpJson('http://localhost:4318/api/ping', { timeoutMs: 2500 }).catch(
        () => ({})
      );
      const hostUp = Boolean(ping && ping.ok && ping.version >= 2 && !ping.standaloneMode);

      if (!hostUp) {
        if (staleHost) log('[INFO] host bridge closed; keepalive running standalone');
        staleHost = false;
        pauseUntil = 0;
        if (Date.now() > yieldCooldownUntil && !bridge.server) {
          bridge.disposed = false;
          bridge.startHttpServer();
          log('[INFO] Standalone theo-agent bound :4318 + Edge Relay (VS Code closed)');
        }
        await runSync('host-down');
        return;
      }

      const now = Date.now();
      observeStatusForMemoryGit(ping, now);
      const diskRemoteMtime = getFileMtimeMs(path.join(REPO_ROOT, 'remote.js'));
      const hostCodeMtime = Number(ping.codeMtime || 0);
      const hostCodeFresh = hostCodeMtime > 0 && hostCodeMtime >= diskRemoteMtime - 2000;
      const hostPushReady =
        bridge.pushDevices.length === 0 || Number(ping.pushDeviceCount || 0) > 0;
      const inProcAge = now - Number(ping.lastCloudSyncAt || 0);
      const attemptAge = now - Number(ping.lastCloudAttemptAt || 0);
      const hostSyncActive =
        inProcAge < 45000 || (Boolean(ping.cloudSyncInFlight) && attemptAge < 35000);

      // Fast path: Extension Host has current code, has push devices, and is actively syncing -> zero interference
      if (hostCodeFresh && hostPushReady && hostSyncActive) {
        if (staleHost) {
          staleHost = false;
          pauseUntil = 0;
          lastReason = '';
          log('[INFO] host is now up-to-date and syncing -> keepalive back to idle watch');
        }
        return;
      }

      // Host has current code, but its sync timer hasn't completed in >= 45s -> ask host to sync first
      if (hostCodeFresh && hostPushReady && !hostSyncActive) {
        const nudge = await httpJson('http://localhost:4318/api/cloud-sync', {
          method: 'POST',
          timeoutMs: 18000
        }).catch(() => null);
        if (nudge && nudge.ok) {
          lastReason = '';
          return;
        }
        await runSync('host-lagging');
        return;
      }

      // Host is running older code (pre-hot-swap window) or missing push devices -> keepalive handles push & state sync
      if (!staleHost) {
        staleHost = true;
        log(
          `[WARN] host codeMtime (${hostCodeMtime}) < disk (${diskRemoteMtime}) or pushDeviceCount=${ping.pushDeviceCount || 0} -> keepalive taking over state & push sync`
        );
      }
      await runSync('stale-host');
    } catch (err) {
      if (once) {
        console.error('[ERR]', err.message);
      } else {
        log(`[ERR] ${err.message}`);
      }
    } finally {
      tickInFlight = false;
    }
  }

  log(`[INFO] keepalive daemon started (pid ${process.pid}, bootMtime ${bootMtime})`);
  await tick();
  if (!once) {
    setInterval(tick, 5000);
  }
}

const isDirectEntry =
  require.main === module ||
  Boolean(require.main && path.basename(require.main.filename || '') === 'theo_agent.cjs');
if (isDirectEntry && process.env.THEO_SMOKE_TEST !== '1') {
  main();
}

module.exports = {
  MEMORY_GIT_IDLE_QUIET_MS,
  isIgnoredMemoryGitEntry,
  resolveTheoMemoryPaths,
  scanTrackedMemoryTree,
  readMemoryGitRefs,
  findLocalPythonExe,
  findLocalConsolePythonExe,
  createMemoryGitIdleSyncController,
  buildStandaloneState,
  attachKeepaliveStateBuilder,
  attachKeepaliveCommandProxy,
  makeStandaloneHub,
  launchEngineOutsideJob,
  enginePortFilterScript,
  ensureStandaloneAgyEngine,
  buildAgyEngineLaunch,
  isLoopbackPortRefused
};
