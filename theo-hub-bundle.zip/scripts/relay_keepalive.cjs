const fs = require('fs');
const http = require('http');
const https = require('https');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const { TheoRemoteBridge, formatModelDisplayName } = require('../remote');
const { AntigravityDataStore } = require('../store');
const { SessionActivityTracker } = require('../activity');
const { AccountVaultManager } = require('../accounts');
const { prepatchInstalledExtensions } = require('../bridge');
const {
  loadTheoCredentials,
  deriveEdgeAuthToken,
  inferRowOwnerDevice
} = require('../device-identity');

const REPO_ROOT = path.resolve(__dirname, '..');
const CLAUDE_DIR = path.join(os.homedir(), '.claude');
const PID_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.pid');
const META_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.json');
const LOG_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.log');
const LAST_STATE_CACHE_FILE = path.join(CLAUDE_DIR, '.theo-last-state.json');
const HUB_STATE_FILE = path.join(CLAUDE_DIR, '.theo-hub-state.json');

function getFileMtimeMs(filePath) {
  try {
    return Math.floor(fs.statSync(filePath).mtimeMs);
  } catch {
    return 0;
  }
}

function computeDiskMaxMtime() {
  return Math.max(
    getFileMtimeMs(__filename),
    getFileMtimeMs(path.join(REPO_ROOT, 'remote.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'store.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'accounts.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'data.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'bridge.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'device-identity.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'ws-server.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'direct-runner.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'edge-relay-client.js'))
  );
}

function isPidAlive(pid) {
  const n = Number(pid || 0);
  if (!n || n <= 0 || n === process.pid) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch (err) {
    return err && err.code === 'EPERM';
  }
}

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try {
    if (!fs.existsSync(CLAUDE_DIR)) {
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    }
    if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 2 * 1024 * 1024) {
      fs.unlinkSync(LOG_FILE);
    }
    fs.appendFileSync(LOG_FILE, line, 'utf8');
  } catch {}
  if (process.argv.includes('--once')) {
    process.stderr.write(line);
  }
}

function httpJson(url, options = {}) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const isLocal =
      parsed.hostname === 'localhost' ||
      parsed.hostname === '127.0.0.1' ||
      parsed.hostname === '::1';
    const targetHost = parsed.hostname === 'localhost' ? '127.0.0.1' : parsed.hostname;
    let bearer = '';
    if (isLocal) {
      const creds = loadTheoCredentials();
      if (creds.effectiveEdgeSecret) {
        bearer = deriveEdgeAuthToken(creds.effectiveEdgeSecret);
      }
    }
    const bodyText = options.body ? String(options.body) : '';
    const req = http.request(
      {
        protocol: parsed.protocol,
        hostname: targetHost,
        port: parsed.port || 4318,
        path: `${parsed.pathname}${parsed.search}`,
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}),
          ...(bodyText ? { 'Content-Length': Buffer.byteLength(bodyText) } : {})
        },
        timeout: options.timeoutMs || 5000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          try {
            resolve(raw ? JSON.parse(raw) : {});
          } catch {
            resolve({ raw });
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error('Local bridge timeout')));
    req.on('error', reject);
    if (bodyText) req.write(bodyText);
    req.end();
  });
}

function fetchCloudMetaAgeMs(relayConfig) {
  return new Promise((resolve) => {
    let parsed;
    try {
      parsed = new URL(relayConfig.url);
    } catch {
      resolve(Infinity);
      return;
    }
    const body = JSON.stringify({ key: relayConfig.key, op: 'get_control' });
    const req = https.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: parsed.pathname + parsed.search,
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=UTF-8',
          'Content-Length': Buffer.byteLength(body)
        },
        timeout: 15000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          try {
            const j = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            const docs = j?.docs && typeof j.docs === 'object' ? j.docs : j || {};
            const stamp = Date.parse(docs?.meta?.updatedAt || '') || 0;
            resolve(stamp ? Date.now() - stamp : Infinity);
          } catch {
            resolve(Infinity);
          }
        });
      }
    );
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(Infinity));
    req.write(body);
    req.end();
  });
}

function readJsonSafe(filePath, fallback = {}) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
  } catch {}
  return fallback;
}

async function buildStandaloneState(store, bridge, opts = {}) {
  const cachedState = readJsonSafe(LAST_STATE_CACHE_FILE, {});
  const persistedHub = readJsonSafe(HUB_STATE_FILE, {});
  const customTitles = persistedHub?.customTitles || {};
  const threadGroups = persistedHub?.threadGroups || {};
  // `.theo-hub-state.json` is written by HubStateStore (state.js): keys are `archivedIds`,
  // `unreadIds`, `seenTurnTimestamps` (seconds) and `baseline` (seconds).
  const archivedSet = new Set([
    ...(Array.isArray(persistedHub?.archivedIds) ? persistedHub.archivedIds : []),
    ...(Array.isArray(persistedHub?.archived) ? persistedHub.archived : [])
  ]);
  const unreadSet = new Set(Array.isArray(persistedHub?.unreadIds) ? persistedHub.unreadIds : []);
  const seenAtMap =
    persistedHub?.seenTurnTimestamps && typeof persistedHub.seenTurnTimestamps === 'object'
      ? persistedHub.seenTurnTimestamps
      : persistedHub?.seenAt || {};
  const baselineSec = Number(persistedHub?.baseline || 0);
  const groups = Array.isArray(persistedHub?.groups)
    ? persistedHub.groups.map((g) => ({
        id: g.id,
        name: g.name,
        collapsed: Boolean(g.collapsed)
      }))
    : cachedState.groups || [];
  const groupIds = new Set(groups.map((g) => g.id));

  let snap = null;
  try {
    snap = await store.loadSnapshot({ forceQuota: false });
  } catch {}

  const workspaces = await bridge.refreshWorkspacesCache().catch(() => cachedState.workspaces || []);

  if (!snap || !Array.isArray(snap.threads)) {
    const fallbackRows = Array.isArray(cachedState.rows) ? cachedState.rows : [];
    bridge.hub = {
      snapshot: {
        threads: fallbackRows.map((r) => ({
          id: r.id,
          provider: r.provider,
          title: r.title,
          cwd: r.cwd,
          workspaceLabel: r.folder,
          branch: r.branch,
          model: r.model,
          updatedAt: Math.floor((r.at || Date.now()) / 1000)
        }))
      }
    };
    return {
      ...cachedState,
      rows: fallbackRows,
      generatedAt: Date.now(),
      connection: bridge.getStatus(),
      workspaces,
      personalLedger: bridge.personalLedger
    };
  }

  const activity = new SessionActivityTracker();
  const rows = [];
  const standaloneApprovals = [];
  for (const thread of snap.threads) {
    if (!thread || !thread.id) continue;
    const provider = thread.provider === 'claude' ? 'claude' : 'antigravity';
    const classified = activity.classifyThread(thread, { recordTransition: false });
    let status = 'idle';
    if (classified.state === 'waiting') {
      status = 'waiting';
    } else if (classified.state === 'thinking') {
      status = 'working';
    } else if (classified.state === 'errored') {
      status = 'failed';
    } else if (classified.state === 'completed') {
      status = 'completed';
    }
    const rawSeen = Number(seenAtMap[thread.id] || 0);
    const seenSec = Math.max(rawSeen > 1e11 ? Math.floor(rawSeen / 1000) : rawSeen, baselineSec);
    const updatedSec = Number(thread.updatedAt || 0);
    const updatedMs = updatedSec * 1000;
    const isUnread =
      unreadSet.has(thread.id) ||
      ((status === 'completed' || status === 'failed') && updatedSec > seenSec + 2);
    const dot =
      status === 'waiting'
        ? 'waiting'
        : status === 'working'
          ? 'running'
          : isUnread
            ? 'unread'
            : null;
    const category =
      status === 'waiting'
        ? 'needs_input'
        : status === 'working'
          ? 'working'
          : 'completed';
    const title = customTitles[thread.id] || thread.title || 'Untitled session';
    const stepCount = Number(thread.stepCount || 0);
    const pendingQuestion = thread.pendingQuestion || null;
    const lastAssistantText = thread.lastAssistantText || '';
    const rawBg = Array.isArray(thread.backgroundTasks) ? thread.backgroundTasks : [];
    const bgRunningCount = rawBg.filter((t) => t && t.state === 'running').length;
    const bgTotalCount = rawBg.length;
    const bgTasks = rawBg.slice(-8).map((t) => ({
      id: t.id,
      fullId: t.fullId || t.id,
      subagentConversationId: t.subagentConversationId || '',
      kind: t.kind || 'task',
      subagentType: t.subagentType || '',
      summary: String(t.summary || '').slice(0, 140),
      command: String(t.command || '').slice(0, 220),
      state: t.state || 'completed',
      isDaemon: Boolean(t.isDaemon),
      startedAt: Number(t.startedAt || 0) * 1000,
      completedAt: t.completedAt ? Number(t.completedAt) * 1000 : 0,
      stepIndex: typeof t.stepIndex === 'number' ? t.stepIndex : -1
    }));

    rows.push({
      key: thread.id,
      id: thread.id,
      provider,
      draft: false,
      title,
      at: updatedMs,
      open: false,
      active: false,
      group:
        threadGroups[thread.id] && groupIds.has(threadGroups[thread.id])
          ? threadGroups[thread.id]
          : null,
      archived: archivedSet.has(thread.id) || Boolean(thread.archived),
      cwd: thread.cwd || '',
      folder: thread.workspaceLabel || '',
      branch: thread.branch || '',
      deviceId: thread.deviceId || '',
      deviceName: thread.deviceName || '',
      source: thread.source || '',
      remotePeer: Boolean(thread.remotePeer || thread.source === 'cloud-relay'),
      model: formatModelDisplayName(
        thread.model || (provider === 'claude' ? 'Claude' : 'Gemini'),
        provider
      ),
      logged: true,
      status,
      dot,
      category,
      unread: isUnread,
      elsewhere: Boolean(status === 'working' || thread.elsewhere),
      reason: classified.reason || thread.runReason || null,
      stepCount,
      turnComplete: thread.turnComplete !== false,
      lastAssistantText,
      pendingQuestion,
      bgTasks,
      bgRunningCount,
      bgTotalCount
    });

    if (pendingQuestion || status === 'waiting') {
      const isQ = Boolean(pendingQuestion);
      const stepKey = pendingQuestion?.stepIndex || stepCount || 0;
      const itemId =
        pendingQuestion?.approvalId ||
        (isQ
          ? `question-${thread.id}-${stepKey}`
          : stepKey
            ? `waiting-${thread.id}-${stepKey}`
            : `waiting-${thread.id}`);
      standaloneApprovals.push({
        id: itemId,
        approvalId: itemId,
        provider,
        sessionId: thread.id,
        title,
        toolName:
          pendingQuestion?.toolName ||
          (isQ ? 'Question' : classified.reason || 'Waiting on user input'),
        detail:
          pendingQuestion?.questionText ||
          lastAssistantText ||
          `${thread.workspaceLabel || 'Workspace'} · ${thread.model || ''}`.trim(),
        codePreview: pendingQuestion?.codePreview || '',
        description: pendingQuestion?.description || '',
        isToolPermission: Boolean(pendingQuestion?.isToolPermission),
        writeInPlaceholder: pendingQuestion?.writeInPlaceholder || '',
        isMultiSelect: Boolean(pendingQuestion?.isMultiSelect),
        options: pendingQuestion?.options || [],
        questions: pendingQuestion?.questions || [],
        stepIndex: stepKey,
        kind: isQ ? 'question' : 'waiting_session',
        createdAt: (pendingQuestion?.at ? pendingQuestion.at * 1000 : updatedMs) || Date.now()
      });
    }
  }

  rows.sort((a, b) => b.at - a.at);

  const formatBucket = (b) => ({
    label: b.label,
    pct: b.usedPercent,
    reset: b.resetAt ? b.resetAt * 1000 : 0,
    resetText: b.resetText || '',
    expired: Boolean(b.expired)
  });

  let accountsView = null;
  if (bridge.accountVault) {
    try {
      bridge.accountVault.syncActiveClaudeFromDisk(
        snap?.claudeConfigObj,
        snap?.claudeCredsObj,
        snap?.rawClaudeQuota,
        snap?.loadedAt
      );
      const prefCollapsed = persistedHub?.preferences?.collapsedAccounts || {};
      accountsView = await bridge.accountVault.resolveAccountsSnapshot({
        nowMs: Date.now(),
        forceQuota: false,
        antigravityAccount: snap?.account,
        antigravityLimits: snap?.rateLimits,
        rawAntigravityQuota: snap?.rawAntigravityQuota,
        claudeAccount: snap?.claudeAccount,
        claudeLimits: snap?.claudeRateLimits,
        rawClaudeQuota: snap?.rawClaudeQuota,
        claudeRelayMerged: snap?.claudeLive?.rateLimitWindows,
        collapsedProviders: {
          antigravity: Boolean(persistedHub?.preferences?.antigravityUsageCollapsed),
          claude: Boolean(persistedHub?.preferences?.claudeUsageCollapsed),
          ...prefCollapsed
        }
      });
    } catch {}
  }

  const mapStandaloneCard = (item) => {
    const provKey = item.provider === 'claude' ? 'claude' : 'antigravity';
    const isSignedOutItem = !item.available || Boolean(item.signedOut || item.account?.signedOut);
    const pLimits = isSignedOutItem ? [] : (item.rateLimits?.primaryBars || []).map(formatBucket);
    const aLimits = isSignedOutItem ? [] : (item.rateLimits?.allBuckets || []).map(formatBucket);
    return {
      id: item.id,
      provider: provKey,
      label: provKey === 'claude' ? 'Claude Code' : 'Antigravity',
      nickname: item.label || '',
      active: !isSignedOutItem && Boolean(item.active),
      collapsed: Boolean(item.collapsed),
      sortOrder: Number.isFinite(Number(item.sortOrder)) ? Number(item.sortOrder) : 0,
      account: {
        name: item.name || item.account?.name || (provKey === 'claude' ? 'Claude Account' : 'Antigravity Account'),
        email: isSignedOutItem ? '' : item.email || item.account?.email || '',
        plan: isSignedOutItem ? '' : item.plan || item.account?.plan || (provKey === 'claude' ? 'Claude Code' : 'Google AI Pro'),
        nickname: item.label || '',
        available: !isSignedOutItem && Boolean(item.available),
        signedOut: isSignedOutItem
      },
      usage: pLimits.length
        ? {
            at: item.quotaUpdatedAt || snap?.loadedAt || Date.now(),
            limits: pLimits,
            allLimits: aLimits
          }
        : null,
      usageMessage: isSignedOutItem ? 'Not signed in.' : item.rateLimits?.error || ''
    };
  };

  const agyPrimaryLimits = (snap?.rateLimits?.primaryBars || []).map(formatBucket);
  const agyAllLimits = (snap?.rateLimits?.allBuckets || []).map(formatBucket);
  const claudePrimaryLimits = (snap?.claudeRateLimits?.primaryBars || []).map(formatBucket);
  const claudeAllLimits = (snap?.claudeRateLimits?.allBuckets || []).map(formatBucket);

  const agyProviderInfo = {
    id: 'antigravity',
    label: 'Antigravity',
    account: {
      name: snap?.account?.name || cachedState?.account?.name || 'Antigravity Account',
      email: snap?.account?.email || cachedState?.account?.email || '',
      plan: snap?.account?.plan || cachedState?.account?.plan || 'Google AI Pro',
      available: Boolean(snap?.account?.email || snap?.account?.name || cachedState?.account?.available),
      signedOut: false
    },
    usage: agyPrimaryLimits.length
      ? {
          at: snap?.loadedAt || Date.now(),
          limits: agyPrimaryLimits,
          allLimits: agyAllLimits
        }
      : cachedState?.providers?.antigravity?.usage || cachedState?.usage || null,
    usageMessage: '',
    accounts:
      accountsView?.antigravity?.length
        ? accountsView.antigravity.map(mapStandaloneCard)
        : cachedState?.providers?.antigravity?.accounts || undefined
  };

  const claudeSignedOut = Boolean(snap?.claudeAccount?.signedOut);
  const claudeProviderInfo = {
    id: 'claude',
    label: 'Claude Code',
    account: claudeSignedOut
      ? {
          name: 'Claude Code',
          email: '',
          plan: '',
          available: false,
          signedOut: true
        }
      : {
          name: snap?.claudeAccount?.name || cachedState?.providers?.claude?.account?.name || 'Claude Account',
          email: snap?.claudeAccount?.email || cachedState?.providers?.claude?.account?.email || '',
          plan: snap?.claudeAccount?.plan || cachedState?.providers?.claude?.account?.plan || 'Claude Code',
          available: Boolean(snap?.claudeAccount?.available || cachedState?.providers?.claude?.account?.available),
          signedOut: false
        },
    usage: claudeSignedOut
      ? null
      : claudePrimaryLimits.length
        ? {
            at: snap?.loadedAt || Date.now(),
            limits: claudePrimaryLimits,
            allLimits: claudeAllLimits
          }
        : cachedState?.providers?.claude?.usage || null,
    usageMessage: claudeSignedOut ? 'Not signed in.' : '',
    accounts:
      accountsView?.claude?.length
        ? accountsView.claude.map(mapStandaloneCard)
        : claudeSignedOut
          ? []
          : cachedState?.providers?.claude?.accounts || undefined
  };

  bridge.hub = {
    snapshot: {
      threads: snap.threads
    }
  };

  const selfDevId = bridge.deviceInfo?.id || 'workstation';
  const selfDevName = bridge.deviceInfo?.name || os.hostname();
  const rowById = new Map();
  for (const r of rows) {
    if (!r || !r.id) continue;
    const ownerInfo = inferRowOwnerDevice(r, bridge.deviceInfo);
    const ownerDevId = ownerInfo.id || ownerInfo.deviceId;
    const ownerDevName = ownerInfo.name || ownerInfo.deviceName;
    const isForeignRow =
      ownerDevId !== selfDevId || r.source === 'cloud-relay' || Boolean(r.remotePeer);
    if (opts.localOnly && isForeignRow) continue;
    rowById.set(r.id, {
      ...r,
      deviceId: ownerDevId || selfDevId,
      deviceName: ownerDevName || selfDevName,
      remotePeer: isForeignRow
    });
  }
  if (bridge.directRunner) {
    for (const run of bridge.directRunner.getActiveRuns()) {
      const rid = run.threadId || run.id;
      if (!rid) continue;
      const existing = rowById.get(rid);
      rowById.set(rid, {
        ...(existing || {}),
        id: rid,
        draftId: run.draftId || existing?.draftId || '',
        provider: run.provider,
        deviceId: selfDevId,
        deviceName: selfDevName,
        remotePeer: false,
        title: existing?.title || run.title || 'New Direct Session',
        cwd: existing?.cwd || run.cwd || '',
        folder: existing?.folder || run.folder || 'Workspace',
        model: formatModelDisplayName(run.model || existing?.model, run.provider),
        status: 'working',
        statusLabel: run.activeTool ? `Running ${run.activeTool}` : 'Streaming ⚡',
        dot: 'running',
        category: 'working',
        directStreaming: true,
        at: Math.max(Number(existing?.at || 0), Number(run.updatedAt || Date.now())),
        lastAssistantText: run.fullText ? run.fullText.slice(-220) : existing?.lastAssistantText || ''
      });
    }
  }
  if (!opts.localOnly) {
    for (const [rDevId, rEntry] of Object.entries(bridge.remoteDeviceStates || {})) {
      const rRows = Array.isArray(rEntry?.snapshot?.rows)
        ? rEntry.snapshot.rows
        : Array.isArray(rEntry?.rows)
          ? rEntry.rows
          : null;
      if (!rDevId || rDevId === selfDevId || !rRows) continue;
      for (const pr of rRows) {
        if (!pr || !pr.id || rowById.has(pr.id)) continue;
        const prOwner = inferRowOwnerDevice(pr, {
          id: rDevId,
          name: rEntry.device?.name || rDevId
        });
        rowById.set(pr.id, {
          ...pr,
          deviceId: prOwner.id || prOwner.deviceId || rDevId,
          deviceName: prOwner.name || prOwner.deviceName || rEntry.device?.name || rDevId,
          remotePeer: true,
          model: formatModelDisplayName(pr.model, pr.provider)
        });
      }
    }
  }
  const mergedRows = Array.from(rowById.values()).sort(
    (a, b) => Number(b.at || 0) - Number(a.at || 0)
  );
  const stampedWorkspaces = (workspaces || []).map((w) => ({
    ...w,
    deviceId: selfDevId,
    deviceName: selfDevName
  }));

  return {
    ...cachedState,
    type: 'state',
    loading: false,
    device: {
      id: selfDevId,
      name: selfDevName,
      role: bridge.deviceInfo?.role || 'secondary',
      hostname: os.hostname(),
      capabilities: bridge.deviceInfo?.capabilities || []
    },
    account: agyProviderInfo.account,
    usage: agyProviderInfo.usage,
    providers: {
      antigravity: agyProviderInfo,
      claude: claudeProviderInfo
    },
    accountOrder: Array.isArray(accountsView?.accountOrder)
      ? accountsView.accountOrder
      : cachedState?.accountOrder || [],
    groups,
    rows: mergedRows,
    devices: bridge.getUnifiedFleetDevices ? bridge.getUnifiedFleetDevices() : [],
    activeDirectRuns: bridge.directRunner ? bridge.directRunner.getActiveRuns() : [],
    total: mergedRows.length,
    generatedAt: Date.now(),
    connection: bridge.getStatus(),
    approvals: standaloneApprovals,
    workspaces: stampedWorkspaces,
    topSessions: (snap?.usage?.topThreads || cachedState.topSessions || []).slice(0, 12),
    personalLedger: bridge.personalLedger
  };
}

function acquireSingleInstanceLock(bootMtime, forceRestart) {
  try {
    if (!fs.existsSync(CLAUDE_DIR)) {
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    }
    let existingPid = 0;
    if (fs.existsSync(PID_FILE)) {
      existingPid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim() || 0);
    }
    const existingMeta = readJsonSafe(META_FILE, {});
    if (!existingPid && existingMeta.pid) {
      existingPid = Number(existingMeta.pid);
    }
    if (isPidAlive(existingPid)) {
      const existingBoot = Number(existingMeta.bootMtime || 0);
      if (!forceRestart && existingBoot >= bootMtime - 1000) {
        return false;
      }
      try {
        process.kill(existingPid);
        log(`[INFO] Replaced older keepalive instance (pid ${existingPid})`);
      } catch {}
    }
    fs.writeFileSync(PID_FILE, String(process.pid), 'utf8');
    fs.writeFileSync(
      META_FILE,
      JSON.stringify({
        pid: process.pid,
        startedAt: Date.now(),
        bootMtime,
        script: __filename
      }),
      'utf8'
    );
  } catch {}
  return true;
}

let respawnTriggered = false;
function respawnSelfAndExit() {
  if (respawnTriggered) return;
  respawnTriggered = true;
  try {
    const startPs1 = path.join(__dirname, 'relay_keepalive_start.ps1');
    const child = spawn(
      'powershell.exe',
      [
        '-NoProfile',
        '-NonInteractive',
        '-WindowStyle',
        'Hidden',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        startPs1,
        '-Restart',
        '-SkipTaskCheck'
      ],
      {
        cwd: REPO_ROOT,
        detached: true,
        windowsHide: true,
        stdio: 'ignore'
      }
    );
    child.unref();
    log('[INFO] Code updated on disk -> triggered WMI respawn via relay_keepalive_start.ps1');
  } catch (err) {
    log(`[WARN] Self-respawn failed: ${err.message}`);
  }
  setTimeout(() => process.exit(0), 400);
}

async function main() {
  const once = process.argv.includes('--once');
  const forceRestart = process.argv.includes('--restart') || process.argv.includes('--force');
  const bootMtime = computeDiskMaxMtime();

  if (!once) {
    const acquired = acquireSingleInstanceLock(bootMtime, forceRestart);
    if (!acquired) {
      process.exit(0);
    }
  }

  const store = new AntigravityDataStore();
  const accountVault = new AccountVaultManager();
  const bridge = new TheoRemoteBridge(
    { extensionPath: REPO_ROOT },
    { store, accountVault }
  );

  let yieldCooldownUntil = 0;

  async function releaseStandaloneListeners() {
    yieldCooldownUntil = Date.now() + 12000;
    try {
      if (bridge.edgeClient) {
        bridge.edgeClient.stop();
      }
    } catch {}
    try {
      if (bridge.wsHub) {
        bridge.wsHub.closeAll();
        bridge.wsHub = null;
      }
    } catch {}
    for (const client of Array.from(bridge.sseClients || [])) {
      try {
        client.end();
      } catch {}
    }
    bridge.sseClients?.clear?.();
    if (bridge.standbyBindTimer) {
      clearInterval(bridge.standbyBindTimer);
      bridge.standbyBindTimer = null;
    }
    if (bridge.server) {
      await new Promise((resolve) => {
        try {
          bridge.server.closeAllConnections?.();
        } catch {}
        try {
          bridge.server.close(() => resolve());
        } catch {
          resolve();
        }
        setTimeout(resolve, 150);
      });
      bridge.server = null;
      bridge.listening = false;
    }
    log('[INFO] Yielded standalone :4318 + Edge Relay to VS Code extension host');
  }

  bridge.onYieldPortRequested = releaseStandaloneListeners;

  // Use live localhost:4318 when VS Code owns :4318; run standalone directly when we own :4318 or VS Code is closed
  bridge.buildFullState = async (opts = {}) => {
    if (bridge.listening) {
      return buildStandaloneState(store, bridge, opts);
    }
    try {
      const res = await httpJson('http://localhost:4318/api/state', { timeoutMs: 8000 });
      if (res && res.state && Array.isArray(res.state.rows)) {
        const state = res.state;
        if (state.personalLedger) {
          bridge.mergePersonalLedger(state.personalLedger);
        }
        state.personalLedger = bridge.personalLedger;
        let threadsById = new Map();
        const needsTranscriptEnrich = state.rows.some((r) => r && r.stepCount === undefined);
        if (needsTranscriptEnrich) {
          try {
            const snap = await store.loadSnapshot({ forceQuota: false });
            if (snap && Array.isArray(snap.threads)) {
              threadsById = new Map(snap.threads.map((t) => [t.id, t]));
            }
          } catch {}
        }
        const approvals = Array.isArray(state.approvals) ? [...state.approvals] : [];
        const rows = state.rows.map((r) => {
          const t = threadsById.get(r.id);
          const pendingQuestion = r.pendingQuestion || t?.pendingQuestion || null;
          const stepCount = Number(r.stepCount ?? t?.stepCount ?? 0);
          const lastAssistantText = r.lastAssistantText || t?.lastAssistantText || '';
          const status = pendingQuestion ? 'waiting' : r.status;
          const category = status === 'waiting' ? 'needs_input' : r.category;
          const dot = status === 'waiting' ? 'waiting' : r.dot;
          if (pendingQuestion && !approvals.some((a) => a && a.sessionId === r.id && a.kind === 'question')) {
            const stepKey = pendingQuestion.stepIndex || stepCount || 0;
            const qId = `question-${r.id}-${stepKey}`;
            const filteredIdx = approvals.findIndex((a) => a && a.sessionId === r.id && a.kind === 'waiting_session');
            if (filteredIdx >= 0) approvals.splice(filteredIdx, 1);
            approvals.push({
              id: qId,
              approvalId: qId,
              provider: r.provider || 'antigravity',
              sessionId: r.id,
              title: r.title || 'Session asking a question',
              toolName: 'Question',
              detail: pendingQuestion.questionText || 'Waiting for your answer',
              isMultiSelect: Boolean(pendingQuestion.isMultiSelect),
              options: pendingQuestion.options || [],
              questions: pendingQuestion.questions || [],
              stepIndex: stepKey,
              kind: 'question',
              createdAt: (pendingQuestion.at ? pendingQuestion.at * 1000 : r.at) || Date.now()
            });
          }
          return {
            ...r,
            status,
            category,
            dot,
            stepCount,
            lastAssistantText,
            pendingQuestion,
            model: formatModelDisplayName(r.model, r.provider)
          };
        });
        state.rows = rows;
        state.approvals = approvals;
        bridge.hub = {
          snapshot: {
            threads: rows.map((r) => ({
              id: r.id,
              provider: r.provider,
              title: r.title,
              cwd: r.cwd,
              workspaceLabel: r.folder,
              branch: r.branch,
              model: r.model,
              stepCount: r.stepCount,
              lastAssistantText: r.lastAssistantText,
              pendingQuestion: r.pendingQuestion,
              updatedAt: Math.floor((r.at || Date.now()) / 1000)
            }))
          }
        };
        return state;
      }
    } catch {}
    return buildStandaloneState(store, bridge, opts);
  };

  const origExecuteRemoteCommand = bridge.executeRemoteCommand.bind(bridge);
  bridge.executeRemoteCommand = async (cmd = {}) => {
    if (bridge.listening) {
      return origExecuteRemoteCommand(cmd);
    }
    const type = String(cmd.type || cmd.action || '').trim();
    const subAction = String(cmd.subAction || cmd.action || '').trim();
    const cleanTargetCandidate = (val) => {
      const s = String(val || '').trim();
      if (!s || s === '__new__' || s.startsWith('cmd-') || s.startsWith('draft-new-') || s.startsWith('draft-direct-')) {
        return '';
      }
      return s;
    };
    const targetId = cleanTargetCandidate(cmd.threadId) || cleanTargetCandidate(cmd.id);
    if (type === 'requestThread' || (type === 'sessionAction' && subAction === 'requestThread')) {
      const id = targetId;
      const provider = cmd.provider === 'claude' ? 'claude' : 'antigravity';
      if (id) {
        if (!bridge.requestedThreads) bridge.requestedThreads = new Map();
        bridge.requestedThreads.set(id, { provider, requestedAt: Date.now() });
      }
      return { ok: true, id, provider };
    }
    if (type === 'send' || type === 'sendPrompt') {
      return httpJson('http://localhost:4318/api/send', {
        method: 'POST',
        body: JSON.stringify({ ...cmd, id: targetId, threadId: targetId }),
        timeoutMs: 16000
      }).catch(() => origExecuteRemoteCommand(cmd));
    }
    if (type === 'approve' || type === 'respondApproval' || type === 'answerQuestion') {
      const localRes = await httpJson('http://localhost:4318/api/approve', {
        method: 'POST',
        body: JSON.stringify(cmd),
        timeoutMs: 8000
      });
      if (localRes && localRes.ok) return localRes;
      const sessId = String(cmd.sessionId || targetId || cmd.approvalId || '').trim();
      if (sessId && store?.answerAntigravityQuestion) {
        return store.answerAntigravityQuestion(sessId, cmd).catch(() => ({ ok: false }));
      }
      return { ok: false };
    }
    if (type === 'cancelBgTask' || type === 'cancelAllBgTasks') {
      return bridge.executeRemoteCommand({
        ...cmd,
        type: 'sessionAction',
        subAction: type
      });
    }
    if (type === 'sessionAction') {
      const localRes = await httpJson('http://localhost:4318/api/session-action', {
        method: 'POST',
        body: JSON.stringify({ ...cmd, id: targetId || cmd.id, action: subAction }),
        timeoutMs: 8000
      }).catch(() => null);
      if (localRes && localRes.ok) return localRes;
      if (subAction === 'cancelBgTask' && store?.cancelBackgroundTaskOnServer) {
        const sid = String(cmd.sessionId || targetId || cmd.id || '').trim();
        const tid = String(cmd.taskId || '').trim();
        if (sid && tid) {
          const out = await store
            .cancelBackgroundTaskOnServer(sid, cmd.provider || '', {
              id: tid,
              fullId: tid,
              kind: cmd.kind || 'task',
              stepIndex: typeof cmd.stepIndex === 'number' ? cmd.stepIndex : -1
            })
            .catch(() => ({ ok: false }));
          return { ok: Boolean(out?.ok) };
        }
      }
      if (
        (subAction === 'interrupt' || subAction === 'stop' || subAction === 'cancel') &&
        (targetId || cmd.id) &&
        store?.cancelSessionOnServer
      ) {
        const ok = await store
          .cancelSessionOnServer(targetId || cmd.id, cmd.provider)
          .catch(() => false);
        return { ok: Boolean(ok) };
      }
      // Host down: apply unread / archive / group edits straight to ~/.claude/.theo-hub-state.json
      // via TheoRemoteBridge's standalone branch (hub-less executeRemoteCommand) instead of
      // silently dropping them.
      try {
        const standaloneRes = await origExecuteRemoteCommand({
          ...cmd,
          type: 'sessionAction',
          subAction,
          action: subAction,
          threadId: targetId
        });
        if (standaloneRes && standaloneRes.ok) return standaloneRes;
      } catch {}
      return localRes || { ok: false };
    }
    return { ok: true };
  };

  // Non-competing watchdog state machine:
  //   healthy      -> host ping fresh & code current; probe cloud stamp every 60s, otherwise 100% idle
  //   hostLagging  -> host ping reachable & code current, but lastCloudSyncAt > 45s; nudge /api/cloud-sync first
  //   staleHost    -> host ping reachable but running older remote.js & cloud stamp stale; take over state sync
  //   hostDown     -> VS Code closed (:4318 unreachable); sync standalone via AntigravityDataStore
  const STORE_PROBE_MS = 45000;
  const STALE_STORE_MS = 45000;
  const RECHECK_MS = 120000;
  const PAUSE_MS = 25000;
  let staleHost = false;
  let lastProbeAt = 0;
  let pauseUntil = 0;
  let lastReason = '';
  let lastErr = '';
  let tickInFlight = false;

  async function runSync(reason) {
    bridge.lastCloudError = '';
    const syncRes = await bridge.syncCloudRelay({ pushState: true });
    if (syncRes && bridge.pushDevices.length > 0) {
      for (const dev of bridge.pushDevices) {
        await httpJson('http://localhost:4318/api/push-register', {
          method: 'POST',
          body: JSON.stringify(dev),
          timeoutMs: 2000
        }).catch(() => {});
      }
    }
    if (syncRes && bridge.personalLedger) {
      await httpJson('http://localhost:4318/api/personal-ledger', {
        method: 'POST',
        body: JSON.stringify({ personalLedger: bridge.personalLedger }),
        timeoutMs: 2500
      }).catch(() => {});
    }
    if (once) {
      console.log('[OK] Cloud Relay synced:', JSON.stringify(syncRes));
    } else if (!syncRes) {
      if (bridge.lastCloudError && bridge.lastCloudError !== lastErr) {
        lastErr = bridge.lastCloudError;
        log(`[WARN] keepalive sync (${reason}) failed: ${lastErr}`);
      }
    } else if (reason !== lastReason) {
      lastErr = '';
      log(`[INFO] keepalive syncing (${reason})`);
      lastReason = reason;
    }
  }

  let prepatchTickCount = 0;
  function maybePrepatchExtensions() {
    try {
      const res = prepatchInstalledExtensions(REPO_ROOT);
      if (Array.isArray(res?.updatedDirs) && res.updatedDirs.length > 0) {
        log(
          `[INFO] pre-patched updated extension(s): ${res.updatedDirs.map((d) => path.basename(d)).join(', ')}`
        );
      }
      if (Array.isArray(res?.errors) && res.errors.length > 0) {
        for (const err of res.errors) {
          log(`[WARN] pre-patch failed for ${path.basename(err.extensionDir)}: ${err.error}`);
        }
      }
    } catch {}
  }

  async function tick() {
    if (tickInFlight || respawnTriggered) return;
    tickInFlight = true;
    try {
      prepatchTickCount += 1;
      if (prepatchTickCount === 1 || prepatchTickCount % 3 === 0) {
        maybePrepatchExtensions();
      }
      if (!once) {
        try {
          if (fs.existsSync(PID_FILE)) {
            const ownerPid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim() || 0);
            if (ownerPid && ownerPid !== process.pid && isPidAlive(ownerPid)) {
              process.exit(0);
              return;
            }
          }
        } catch {}
        if (computeDiskMaxMtime() > bootMtime + 2000) {
          respawnSelfAndExit();
          return;
        }
      }

      if (once) {
        await runSync('once');
        return;
      }

      if (bridge.listening) {
        await runSync('standalone-host');
        return;
      }

      const ping = await httpJson('http://localhost:4318/api/ping', { timeoutMs: 2500 }).catch(
        () => ({})
      );
      const hostUp = Boolean(ping && ping.ok && ping.version >= 2 && !ping.standaloneMode);

      if (!hostUp) {
        if (staleHost) log('[INFO] host bridge closed; keepalive running standalone');
        staleHost = false;
        pauseUntil = 0;
        if (Date.now() > yieldCooldownUntil && !bridge.server) {
          bridge.disposed = false;
          bridge.startHttpServer();
          log('[INFO] Standalone theo-agent bound :4318 + Edge Relay (VS Code closed)');
        }
        await runSync('host-down');
        return;
      }

      const now = Date.now();
      const diskRemoteMtime = getFileMtimeMs(path.join(REPO_ROOT, 'remote.js'));
      const hostCodeMtime = Number(ping.codeMtime || 0);
      const hostCodeFresh = hostCodeMtime > 0 && hostCodeMtime >= diskRemoteMtime - 2000;
      const hostPushReady =
        bridge.pushDevices.length === 0 || Number(ping.pushDeviceCount || 0) > 0;
      const inProcAge = now - Number(ping.lastCloudSyncAt || 0);
      const attemptAge = now - Number(ping.lastCloudAttemptAt || 0);
      const hostSyncActive =
        inProcAge < 45000 || (Boolean(ping.cloudSyncInFlight) && attemptAge < 35000);

      // Fast path: Extension Host has current code, has push devices, and is actively syncing -> zero interference
      if (hostCodeFresh && hostPushReady && hostSyncActive) {
        if (staleHost) {
          staleHost = false;
          pauseUntil = 0;
          lastReason = '';
          log('[INFO] host is now up-to-date and syncing -> keepalive back to idle watch');
        }
        return;
      }

      // Host has current code, but its sync timer hasn't completed in >= 45s -> ask host to sync first
      if (hostCodeFresh && hostPushReady && !hostSyncActive) {
        const nudge = await httpJson('http://localhost:4318/api/cloud-sync', {
          method: 'POST',
          timeoutMs: 18000
        }).catch(() => null);
        if (nudge && nudge.ok) {
          lastReason = '';
          return;
        }
        await runSync('host-lagging');
        return;
      }

      // Host is running older code (pre-hot-swap window) or missing push devices -> keepalive handles push & state sync
      if (!staleHost) {
        staleHost = true;
        log(
          `[WARN] host codeMtime (${hostCodeMtime}) < disk (${diskRemoteMtime}) or pushDeviceCount=${ping.pushDeviceCount || 0} -> keepalive taking over state & push sync`
        );
      }
      await runSync('stale-host');
    } catch (err) {
      if (once) {
        console.error('[ERR]', err.message);
      } else {
        log(`[ERR] ${err.message}`);
      }
    } finally {
      tickInFlight = false;
    }
  }

  log(`[INFO] keepalive daemon started (pid ${process.pid}, bootMtime ${bootMtime})`);
  await tick();
  if (!once) {
    setInterval(tick, 5000);
  }
}

main();
