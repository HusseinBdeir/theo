const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const https = require('https');
const os = require('os');
const path = require('path');
const { spawn, execFile } = require('child_process');
const { TheoRemoteBridge, formatModelDisplayName } = require('../remote');
const { AntigravityDataStore } = require('../store');
const { SessionActivityTracker } = require('../activity');
const { AccountVaultManager } = require('../accounts');
const { prepatchInstalledExtensions } = require('../bridge');
const {
  checkAndResumeInterruptedCascades,
  findActiveCascadesFromDiskTranscripts,
  readPersistentHubState
} = require('../compat/antigravity-hub-bridge.cjs');
const {
  loadTheoCredentials,
  deriveEdgeAuthToken,
  inferRowOwnerDevice
} = require('../device-identity');
const { checkPcSetupStatus } = require('../pc-setup');

const REPO_ROOT = path.resolve(__dirname, '..');
const CLAUDE_DIR = path.join(os.homedir(), '.claude');
const PID_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.pid');
const META_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.json');
const LOG_FILE = path.join(CLAUDE_DIR, '.theo-relay-keepalive.log');
const LAST_STATE_CACHE_FILE = path.join(CLAUDE_DIR, '.theo-last-state.json');
const HUB_STATE_FILE = path.join(CLAUDE_DIR, '.theo-hub-state.json');

const MEMORY_GIT_IDLE_QUIET_MS = 10 * 60 * 1000;
const MEMORY_GIT_POLL_MS = 60 * 1000;
const MEMORY_GIT_BOOT_DELAY_MS = 30 * 1000;
const MEMORY_GIT_MIN_SPAWN_GAP_MS = 30 * 1000;
const MEMORY_GIT_CHILD_TIMEOUT_MS = 10 * 60 * 1000;
const MEMORY_GIT_LOCK_STALE_MS = 1500 * 1000;
const MEMORY_GIT_RETRY_BACKOFF_MS = [
  2 * 60 * 1000,
  5 * 60 * 1000,
  15 * 60 * 1000,
  30 * 60 * 1000
];
const MEMORY_GIT_IGNORED_DIRS = new Set([
  '.git',
  '.claude',
  '.vscode',
  '.wrangler',
  'node_modules',
  '_archive',
  'tmp',
  'scratchpad',
  'output',
  '__pycache__'
]);
const MEMORY_GIT_PRIVATE_STEMS = [
  'bank-kyc-ali-bdeir',
  'user-passports-antigua-lebanon'
];

let cachedGitIgnoreMeta = { filePath: '', mtimeMs: -1, size: -1, rules: [] };

function globPatternToRegExp(globPat) {
  let out = '^';
  for (let i = 0; i < globPat.length; i += 1) {
    const ch = globPat[i];
    if (ch === '*') {
      if (globPat[i + 1] === '*' && globPat[i + 2] === '/') {
        out += '(?:.*/)?';
        i += 2;
      } else if (globPat[i + 1] === '*') {
        out += '.*';
        i += 1;
      } else {
        out += '[^/]*';
      }
    } else if (ch === '?') {
      out += '[^/]';
    } else if ('\\.^$+()[]{}|'.includes(ch)) {
      out += `\\${ch}`;
    } else {
      out += ch;
    }
  }
  out += '$';
  return new RegExp(out, 'i');
}

function loadSimpleGitIgnoreRules(memoryRoot) {
  if (!memoryRoot) return [];
  const filePath = path.join(memoryRoot, '.gitignore');
  try {
    if (!fs.existsSync(filePath)) return [];
    const st = fs.lstatSync(filePath);
    if (!st.isFile() || st.size <= 0 || st.size > 16384) return [];
    const mtimeMs = Math.floor(st.mtimeMs);
    if (
      cachedGitIgnoreMeta.filePath === filePath &&
      cachedGitIgnoreMeta.mtimeMs === mtimeMs &&
      cachedGitIgnoreMeta.size === st.size
    ) {
      return cachedGitIgnoreMeta.rules;
    }
    const raw = fs.readFileSync(filePath, 'utf8');
    const rules = [];
    for (const rawLine of raw.split(/\r?\n/)) {
      const trimmed = rawLine.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const negated = trimmed.startsWith('!');
      const rawPat = negated ? trimmed.slice(1).trim() : trimmed;
      if (!rawPat) continue;
      const anchored = rawPat.startsWith('/');
      const dirOnly = rawPat.endsWith('/');
      const body = (dirOnly ? rawPat.slice(0, -1) : rawPat).replace(/^\//, '');
      if (!body) continue;
      const hasSlash = anchored || body.includes('/');
      rules.push({
        negated,
        dirOnly,
        hasSlash,
        re: globPatternToRegExp(body)
      });
    }
    cachedGitIgnoreMeta = { filePath, mtimeMs, size: st.size, rules };
    return rules;
  } catch {
    return [];
  }
}

function isIgnoredMemoryGitEntry(relPosix, baseName, isDir, extraRules = null) {
  const baseLower = String(baseName || '').toLowerCase();
  const relLower = String(relPosix || '').toLowerCase();
  if (!baseLower || baseLower === '.git') return true;
  for (const stem of MEMORY_GIT_PRIVATE_STEMS) {
    if (relLower.includes(stem)) return true;
  }
  if (baseLower.includes('.bak')) return true;
  if (isDir) {
    if (MEMORY_GIT_IGNORED_DIRS.has(baseLower)) return true;
  } else {
    if (
      baseLower.endsWith('.zip') ||
      baseLower.endsWith('.pdf') ||
      (baseLower.endsWith('.html') && !relLower.startsWith('cloudflare-memory/'))
    ) {
      return true;
    }
    if (/^admin\/[^/]+\.(csv|log)$/i.test(relPosix)) return true;
  }
  let ignored = false;
  if (Array.isArray(extraRules)) {
    for (const rule of extraRules) {
      if (rule.dirOnly && !isDir) continue;
      const target = rule.hasSlash ? relLower : baseLower;
      if (rule.re.test(target)) {
        ignored = !rule.negated;
      }
    }
  }
  return ignored;
}

function resolveTheoMemoryPaths(opts = {}) {
  const env = opts.env || process.env;
  const sandboxHome = String(env.THEO_GUARD_HOME || env.THEO_SETUP_HOME || '').trim();
  const sandboxed = Boolean(opts.sandboxed || sandboxHome);
  const homeDir = opts.homeDir || sandboxHome || os.homedir();
  const overrideRoot = String(opts.memoryRoot || env.THEO_MEMORY_ROOT || '').trim();
  let memoryRoot = '';
  if (overrideRoot) {
    if (fs.existsSync(path.join(overrideRoot, 'THEO.md'))) {
      memoryRoot = overrideRoot;
    }
  } else {
    const candidates = [
      path.join(homeDir, 'bhfirms', 'memory'),
      path.join(homeDir, 'OneDrive - BHFIRMS', 'System', 'System', 'THEO')
    ];
    const odc = String(env.OneDriveCommercial || '').trim();
    if (!sandboxed && odc) {
      candidates.push(path.join(odc, 'System', 'System', 'THEO'));
    }
    for (const cand of candidates) {
      if (fs.existsSync(path.join(cand, 'THEO.md'))) {
        memoryRoot = cand;
        break;
      }
    }
  }
  const gitDir =
    String(opts.gitDir || env.THEO_MEMORY_GITDIR || '').trim() ||
    path.join(homeDir, '.gitdirs', 'claude-memory');
  const stateFile =
    String(opts.stateFile || '').trim() ||
    path.join(homeDir, '.claude', '.theo-memory-git-idle.json');
  return { homeDir, memoryRoot, gitDir, stateFile, sandboxed };
}

function scanTrackedMemoryTree(memoryRoot) {
  const empty = {
    ok: false,
    fileCount: 0,
    latestFileMtimeMs: 0,
    latestDirMtimeMs: 0,
    treeSig: '',
    pathsSig: '',
    fileSigMap: new Map()
  };
  if (!memoryRoot || !fs.existsSync(path.join(memoryRoot, 'THEO.md'))) {
    return empty;
  }
  const extraRules = loadSimpleGitIgnoreRules(memoryRoot);
  const entries = [];
  let latestFileMtimeMs = 0;
  let latestDirMtimeMs = 0;
  try {
    try {
      latestDirMtimeMs = Math.floor(fs.lstatSync(memoryRoot).mtimeMs);
    } catch {}
    const walk = (dirPath, relPrefix, depth) => {
      if (depth > 16) return;
      let dirItems;
      try {
        dirItems = fs.readdirSync(dirPath, { withFileTypes: true });
      } catch (err) {
        if (err && err.code === 'ENOENT' && depth > 0) return;
        throw err;
      }
      for (const item of dirItems) {
        const name = item.name;
        const relPosix = relPrefix ? `${relPrefix}/${name}` : name;
        if (item.isSymbolicLink()) continue;
        const fullPath = path.join(dirPath, name);
        let st;
        try {
          st = fs.lstatSync(fullPath);
        } catch (err) {
          if (err && err.code === 'ENOENT') continue;
          throw err;
        }
        if (st.isSymbolicLink()) continue;
        if (st.isDirectory()) {
          if (isIgnoredMemoryGitEntry(relPosix, name, true, extraRules)) continue;
          const dirMtime = Math.floor(st.mtimeMs);
          if (dirMtime > latestDirMtimeMs) latestDirMtimeMs = dirMtime;
          walk(fullPath, relPosix, depth + 1);
        } else if (st.isFile()) {
          if (isIgnoredMemoryGitEntry(relPosix, name, false, extraRules)) continue;
          const mtimeMs = Math.floor(st.mtimeMs);
          if (mtimeMs > latestFileMtimeMs) latestFileMtimeMs = mtimeMs;
          entries.push({ relPosix, size: st.size, mtimeMs });
        }
      }
    };
    walk(memoryRoot, '', 0);
  } catch {
    return empty;
  }
  if (entries.length === 0) {
    return empty;
  }
  entries.sort((a, b) => (a.relPosix < b.relPosix ? -1 : a.relPosix > b.relPosix ? 1 : 0));
  const hash = crypto.createHash('sha256');
  const pathsHash = crypto.createHash('sha256');
  const fileSigMap = new Map();
  for (const e of entries) {
    hash.update(`${e.relPosix}\0${e.size}\0${e.mtimeMs}\n`, 'utf8');
    pathsHash.update(`${e.relPosix}\n`, 'utf8');
    fileSigMap.set(e.relPosix, { size: e.size, mtimeMs: e.mtimeMs });
  }
  return {
    ok: true,
    fileCount: entries.length,
    latestFileMtimeMs,
    latestDirMtimeMs,
    treeSig: hash.digest('hex'),
    pathsSig: pathsHash.digest('hex'),
    fileSigMap
  };
}

function readMemoryGitRefs(gitDir, nowMs = Date.now()) {
  const empty = {
    initialized: false,
    headSha: '',
    mainSha: '',
    originMainSha: '',
    hasPreOriginRef: false,
    mainRefMtimeMs: 0,
    lockActive: false,
    lastAutoLogMtimeMs: 0,
    lastAutoExitCode: null
  };
  if (!gitDir || !fs.existsSync(path.join(gitDir, 'HEAD'))) {
    return empty;
  }
  let packedMap = null;
  const loadPacked = () => {
    if (packedMap !== null) return packedMap;
    packedMap = new Map();
    const packedPath = path.join(gitDir, 'packed-refs');
    try {
      if (fs.existsSync(packedPath)) {
        const lines = fs.readFileSync(packedPath, 'utf8').split(/\r?\n/);
        for (const raw of lines) {
          const ln = raw.trim();
          if (!ln || ln.startsWith('#') || ln.startsWith('^')) continue;
          const sp = ln.indexOf(' ');
          if (sp === 40) {
            const sha = ln.slice(0, 40).toLowerCase();
            const ref = ln.slice(41).trim();
            if (/^[0-9a-f]{40}$/.test(sha) && ref) {
              packedMap.set(ref, sha);
            }
          }
        }
      }
    } catch {}
    return packedMap;
  };
  const resolveRef = (refName, depth = 0) => {
    if (!refName || depth > 4) return '';
    const loosePath = path.join(gitDir, ...refName.split('/'));
    try {
      if (fs.existsSync(loosePath)) {
        const val = fs.readFileSync(loosePath, 'utf8').trim();
        if (val.startsWith('ref:')) {
          return resolveRef(val.slice(4).trim(), depth + 1);
        }
        if (/^[0-9a-f]{40}$/i.test(val)) {
          return val.toLowerCase();
        }
      }
    } catch {}
    return loadPacked().get(refName) || '';
  };

  const headSha = resolveRef('HEAD');
  const mainSha = resolveRef('refs/heads/main');
  const originMainSha = resolveRef('refs/remotes/origin/main');
  const hasPreOriginRef = Boolean(resolveRef('refs/theo-backup/pre-origin'));
  const mainRefMtimeMs = Math.max(
    getFileMtimeMs(path.join(gitDir, 'refs', 'heads', 'main')),
    getFileMtimeMs(path.join(gitDir, 'logs', 'refs', 'heads', 'main')),
    getFileMtimeMs(path.join(gitDir, 'logs', 'HEAD'))
  );

  let lockActive = false;
  const lockPath = path.join(gitDir, 'theo-sync.lock');
  try {
    if (fs.existsSync(lockPath)) {
      const st = fs.statSync(lockPath);
      const ageMs = nowMs - Math.floor(st.mtimeMs);
      if (ageMs <= 1000) {
        lockActive = true;
      } else if (ageMs < MEMORY_GIT_LOCK_STALE_MS) {
        const headTok = fs.readFileSync(lockPath, 'utf8').slice(0, 64).trim().split(/\s+/)[0] || '';
        if (/^\d+$/.test(headTok)) {
          const lockPid = Number(headTok);
          lockActive = lockPid === process.pid || isPidAlive(lockPid);
        } else {
          lockActive = true;
        }
      }
    }
  } catch {}

  let lastAutoLogMtimeMs = 0;
  let lastAutoExitCode = null;
  const autoLogPath = path.join(gitDir, 'last-auto-sync.log');
  try {
    if (fs.existsSync(autoLogPath)) {
      lastAutoLogMtimeMs = Math.floor(fs.statSync(autoLogPath).mtimeMs);
      const firstLine =
        (fs.readFileSync(autoLogPath, 'utf8').split(/\r?\n/).find((l) => l.trim()) || '').trim();
      const m = /\bexit=(-?\d+)\b/.exec(firstLine);
      if (m) {
        lastAutoExitCode = Number(m[1]);
      }
    }
  } catch {}

  return {
    initialized: true,
    headSha,
    mainSha,
    originMainSha,
    hasPreOriginRef,
    mainRefMtimeMs,
    lockActive,
    lastAutoLogMtimeMs,
    lastAutoExitCode
  };
}

function collectPythonCandidateDirs(homeDir) {
  const dirsOut = [path.join(homeDir, '.local', 'python312')];
  if (process.platform === 'win32') {
    dirsOut.push('C:\\Python314', 'C:\\Python313', 'C:\\Python312');
    const programRoots = [];
    if (process.env.LOCALAPPDATA) {
      programRoots.push(path.join(process.env.LOCALAPPDATA, 'Programs', 'Python'));
    }
    if (process.env.ProgramFiles) programRoots.push(process.env.ProgramFiles);
    if (process.env['ProgramFiles(x86)']) programRoots.push(process.env['ProgramFiles(x86)']);
    for (const rootDir of programRoots) {
      try {
        if (fs.existsSync(rootDir)) {
          const subs = fs
            .readdirSync(rootDir, { withFileTypes: true })
            .filter((e) => e.isDirectory() && /^Python3/i.test(e.name))
            .map((e) => e.name)
            .sort()
            .reverse();
          for (const sub of subs) {
            dirsOut.push(path.join(rootDir, sub));
          }
        }
      } catch {}
    }
  }
  for (const pathEntry of String(process.env.PATH || '').split(path.delimiter)) {
    const cleanDir = pathEntry.trim();
    if (!cleanDir || /windowsapps/i.test(cleanDir)) continue;
    dirsOut.push(cleanDir);
  }
  return dirsOut;
}

function findLocalPythonExe(homeDir = os.homedir()) {
  const names =
    process.platform === 'win32' ? ['pythonw.exe', 'python.exe'] : ['python3', 'python'];
  for (const dir of collectPythonCandidateDirs(homeDir)) {
    for (const name of names) {
      const exe = path.join(dir, name);
      try {
        if (!/windowsapps/i.test(exe) && fs.existsSync(exe)) return exe;
      } catch {}
    }
  }
  return '';
}

function findLocalConsolePythonExe(homeDir = os.homedir()) {
  const names =
    process.platform === 'win32' ? ['python.exe', 'pythonw.exe'] : ['python3', 'python'];
  for (const dir of collectPythonCandidateDirs(homeDir)) {
    for (const name of names) {
      const exe = path.join(dir, name);
      try {
        if (!/windowsapps/i.test(exe) && fs.existsSync(exe)) return exe;
      } catch {}
    }
  }
  return '';
}

function writeJsonAtomic(filePath, obj) {
  const dir = path.dirname(filePath);
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  try {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const payload = JSON.stringify(obj, null, 2) + '\n';
    fs.writeFileSync(tmp, payload, 'utf8');
    try {
      fs.renameSync(tmp, filePath);
    } catch {
      fs.writeFileSync(filePath, payload, 'utf8');
      try {
        fs.unlinkSync(tmp);
      } catch {}
    }
  } catch {
    try {
      if (fs.existsSync(tmp)) fs.unlinkSync(tmp);
    } catch {}
  }
}

function isValidMemoryGitScript(scriptPath) {
  try {
    if (!scriptPath || !fs.existsSync(scriptPath)) return false;
    const raw = fs.readFileSync(scriptPath, 'utf8');
    return raw.includes('__main__') && raw.includes('def main(');
  } catch {
    return false;
  }
}

function createMemoryGitIdleSyncController(options = {}) {
  const nowFn = typeof options.nowFn === 'function' ? options.nowFn : () => Date.now();
  const logFn = typeof options.logFn === 'function' ? options.logFn : () => {};
  const quietThresholdMs =
    typeof options.quietThresholdMs === 'number'
      ? options.quietThresholdMs
      : MEMORY_GIT_IDLE_QUIET_MS;
  const pollMs = typeof options.pollMs === 'number' ? options.pollMs : MEMORY_GIT_POLL_MS;
  const bootDelayMs =
    typeof options.bootDelayMs === 'number' ? options.bootDelayMs : MEMORY_GIT_BOOT_DELAY_MS;
  const minSpawnGapMs =
    typeof options.minSpawnGapMs === 'number'
      ? options.minSpawnGapMs
      : MEMORY_GIT_MIN_SPAWN_GAP_MS;
  const childTimeoutMs =
    typeof options.childTimeoutMs === 'number'
      ? options.childTimeoutMs
      : MEMORY_GIT_CHILD_TIMEOUT_MS;
  const retryBackoffMs =
    Array.isArray(options.retryBackoffMs) && options.retryBackoffMs.length > 0
      ? options.retryBackoffMs
      : MEMORY_GIT_RETRY_BACKOFF_MS;

  const initialPaths = resolveTheoMemoryPaths(options);
  const persisted = readJsonSafe(initialPaths.stateFile, {});
  const state = {
    lastCleanTreeSig: String(persisted.lastCleanTreeSig || ''),
    lastCleanPathsSig: String(persisted.lastCleanPathsSig || ''),
    lastCleanHead: String(persisted.lastCleanHead || ''),
    lastCleanOriginMain: String(persisted.lastCleanOriginMain || ''),
    lastCommittedTreeSig: String(persisted.lastCommittedTreeSig || ''),
    lastCommittedPathsSig: String(persisted.lastCommittedPathsSig || ''),
    lastCommittedHead: String(persisted.lastCommittedHead || ''),
    lastStaleWaitTreeSig: String(persisted.lastStaleWaitTreeSig || ''),
    lastStaleWaitHead: String(persisted.lastStaleWaitHead || ''),
    lastStaleWaitOriginMain: String(persisted.lastStaleWaitOriginMain || ''),
    lastAttemptAt: Number(persisted.lastAttemptAt || 0),
    lastAttemptTreeSig: String(persisted.lastAttemptTreeSig || ''),
    lastAttemptHead: String(persisted.lastAttemptHead || ''),
    lastAttemptOriginMain: String(persisted.lastAttemptOriginMain || ''),
    lastExitCode: typeof persisted.lastExitCode === 'number' ? persisted.lastExitCode : 0,
    consecutiveUnconverged: Number(persisted.consecutiveUnconverged || 0)
  };

  const bootedAt = nowFn();
  let lastPollAt = 0;
  let lastObservedTreeSig = '';
  let lastObservedAt = 0;
  let lastObservedFileMap = null;
  let lastTreeChangeDetectedAt = 0;
  let wasCloudReachable = null;
  let cloudRecoveredAt = 0;
  let childInFlight = false;
  let childStartedAt = 0;
  let activeChild = null;
  let inFlightPromise = null;

  function killHungChild(proc) {
    if (!proc) return;
    const pid = proc.pid;
    if (process.platform === 'win32' && pid) {
      execFile(
        'taskkill',
        ['/T', '/F', '/PID', String(pid)],
        { windowsHide: true, timeout: 10000 },
        () => {}
      );
    } else {
      try {
        proc.kill('SIGKILL');
      } catch {}
    }
  }

  function noteCloudConnectivity(isReachable, atMs = nowFn()) {
    const clean = Boolean(isReachable);
    const recovered = wasCloudReachable === false && clean === true;
    wasCloudReachable = clean;
    if (!clean) {
      cloudRecoveredAt = 0;
    } else if (recovered) {
      cloudRecoveredAt = atMs;
      lastPollAt = 0;
    }
    return recovered;
  }

  function isInFlight(atMs = nowFn()) {
    return childInFlight && atMs - childStartedAt < childTimeoutMs;
  }

  function maybeTick(atMs = nowFn(), tickOpts = {}) {
    const env = options.env || process.env;
    if (!options.allowInSmokeTest && env.THEO_SMOKE_TEST === '1') {
      return { action: 'disabled' };
    }
    if (env.THEO_DISABLE_MEMORY_GIT_IDLE === '1') {
      return { action: 'disabled' };
    }
    if (childInFlight) {
      if (atMs - childStartedAt < childTimeoutMs) {
        return { action: 'in-flight' };
      }
      logFn('[WARN] memory-git idle sync exceeded timeout -> terminating child');
      killHungChild(activeChild);
      activeChild = null;
      childInFlight = false;
    }

    const forcePoll = Boolean(tickOpts.forcePoll);
    if (!forcePoll && atMs - bootedAt < bootDelayMs) {
      return { action: 'boot-delay' };
    }

    const pendingRecovery = cloudRecoveredAt > state.lastAttemptAt;
    const cooldownActive =
      state.lastAttemptAt > 0 && atMs - state.lastAttemptAt < minSpawnGapMs;
    const pendingRecoveryReady = pendingRecovery && !cooldownActive;
    if (!forcePoll && !pendingRecoveryReady && lastPollAt > 0 && atMs - lastPollAt < pollMs) {
      return { action: 'throttled' };
    }
    lastPollAt = atMs;

    const paths = resolveTheoMemoryPaths({ ...options, env });
    if (!paths.memoryRoot) {
      cloudRecoveredAt = 0;
      return { action: 'no-memory-root' };
    }
    if (paths.sandboxed && !String(env.THEO_MEMORY_REMOTE || '').trim()) {
      cloudRecoveredAt = 0;
      return { action: 'sandbox-missing-remote' };
    }

    const refs = readMemoryGitRefs(paths.gitDir, atMs);
    if (refs.lockActive) {
      return { action: 'git-locked' };
    }

    const scan = scanTrackedMemoryTree(paths.memoryRoot);
    if (!scan.ok) {
      cloudRecoveredAt = 0;
      return { action: 'scan-error' };
    }

    const localCommitSha = refs.mainSha || refs.headSha;
    const refsConverged =
      Boolean(refs.mainSha) &&
      refs.headSha === refs.mainSha &&
      refs.mainSha === refs.originMainSha &&
      !refs.hasPreOriginRef;
    const refsOutOfSync = Boolean(localCommitSha) && !refsConverged;

    if (!lastObservedTreeSig) {
      const useCommittedBaseline =
        Boolean(localCommitSha) &&
        Boolean(state.lastCommittedHead) &&
        localCommitSha === state.lastCommittedHead &&
        Boolean(state.lastCommittedTreeSig);
      const baselineTreeSig = useCommittedBaseline
        ? state.lastCommittedTreeSig
        : state.lastCleanTreeSig;
      const baselinePathsSig = useCommittedBaseline
        ? state.lastCommittedPathsSig
        : state.lastCleanPathsSig;

      let detectedAt = scan.latestFileMtimeMs;
      if (!baselineTreeSig || scan.treeSig !== baselineTreeSig) {
        if (scan.latestDirMtimeMs > detectedAt && scan.latestDirMtimeMs <= atMs + 2000) {
          detectedAt = scan.latestDirMtimeMs;
        }
        if (
          baselinePathsSig &&
          scan.pathsSig !== baselinePathsSig &&
          detectedAt <= (state.lastAttemptAt || 0)
        ) {
          detectedAt = atMs;
        }
      }
      lastObservedTreeSig = scan.treeSig;
      lastObservedAt = atMs;
      lastObservedFileMap = scan.fileSigMap;
      lastTreeChangeDetectedAt = detectedAt;
    } else if (scan.treeSig !== lastObservedTreeSig) {
      let hasDeletion = false;
      if (lastObservedFileMap) {
        for (const rel of lastObservedFileMap.keys()) {
          if (!scan.fileSigMap.has(rel)) {
            hasDeletion = true;
            break;
          }
        }
      }
      let hasBackdatedChange = false;
      let maxChangedMtimeMs = 0;
      for (const [rel, cur] of scan.fileSigMap.entries()) {
        const prev = lastObservedFileMap ? lastObservedFileMap.get(rel) : null;
        if (!prev || prev.size !== cur.size || prev.mtimeMs !== cur.mtimeMs) {
          if (cur.mtimeMs < lastObservedAt) {
            hasBackdatedChange = true;
          }
          if (cur.mtimeMs > maxChangedMtimeMs) {
            maxChangedMtimeMs = cur.mtimeMs;
          }
        }
      }
      lastObservedTreeSig = scan.treeSig;
      lastObservedAt = atMs;
      lastObservedFileMap = scan.fileSigMap;
      lastTreeChangeDetectedAt =
        hasDeletion || hasBackdatedChange || maxChangedMtimeMs <= 0 ? atMs : maxChangedMtimeMs;
    } else {
      lastObservedAt = atMs;
    }

    const effectiveLastEditMs = Math.max(scan.latestFileMtimeMs, lastTreeChangeDetectedAt);
    const quietMs =
      effectiveLastEditMs > 0 ? Math.max(0, atMs - effectiveLastEditMs) : quietThresholdMs;

    if (
      refsConverged &&
      scan.treeSig === state.lastCleanTreeSig &&
      refs.mainSha === state.lastCleanHead &&
      refs.originMainSha === state.lastCleanOriginMain
    ) {
      cloudRecoveredAt = 0;
      return { action: 'clean' };
    }

    const isOneDriveMemoryRoot = /onedrive/i.test(paths.memoryRoot);
    const waitingForOneDriveDelivery =
      isOneDriveMemoryRoot &&
      ((Boolean(state.lastStaleWaitTreeSig) &&
        scan.treeSig === state.lastStaleWaitTreeSig &&
        localCommitSha === state.lastStaleWaitHead &&
        refs.originMainSha === state.lastStaleWaitOriginMain) ||
        (Boolean(state.lastCleanHead) &&
          localCommitSha === state.lastCleanHead &&
          scan.treeSig === state.lastCleanTreeSig &&
          refs.headSha === refs.mainSha &&
          !refs.hasPreOriginRef &&
          Boolean(refs.originMainSha) &&
          refs.originMainSha !== refs.mainSha));
    if (waitingForOneDriveDelivery) {
      cloudRecoveredAt = 0;
      return { action: 'waiting-onedrive' };
    }

    let diskMatchesLocalCommit = false;
    if (localCommitSha) {
      if (state.lastCommittedHead && localCommitSha === state.lastCommittedHead) {
        diskMatchesLocalCommit = scan.treeSig === state.lastCommittedTreeSig;
      } else if (state.lastCleanHead && localCommitSha === state.lastCleanHead) {
        diskMatchesLocalCommit = scan.treeSig === state.lastCleanTreeSig;
      } else if (refs.mainRefMtimeMs > 0) {
        const dirCleanAfterCommit =
          scan.latestDirMtimeMs <= 0 ||
          scan.latestDirMtimeMs > atMs + 2000 ||
          scan.latestDirMtimeMs <= refs.mainRefMtimeMs + 1000;
        diskMatchesLocalCommit =
          effectiveLastEditMs <= refs.mainRefMtimeMs + 1000 && dirCleanAfterCommit;
      }
    }

    const triggerAheadRefs = refsOutOfSync && diskMatchesLocalCommit;
    const diskDirtyOrUnverified =
      !triggerAheadRefs &&
      (!refsConverged ||
        scan.treeSig !== state.lastCleanTreeSig ||
        refs.mainSha !== state.lastCleanHead ||
        refs.originMainSha !== state.lastCleanOriginMain);
    const triggerIdleEdits = diskDirtyOrUnverified && quietMs >= quietThresholdMs;

    if (!triggerIdleEdits && !triggerAheadRefs) {
      cloudRecoveredAt = 0;
      return { action: 'waiting-quiet', quietMs };
    }

    if (cooldownActive) {
      return { action: 'cooldown' };
    }

    if (
      !pendingRecovery &&
      refs.lastAutoExitCode !== null &&
      refs.lastAutoExitCode !== 0 &&
      refs.lastAutoLogMtimeMs > state.lastAttemptAt &&
      atMs - refs.lastAutoLogMtimeMs < retryBackoffMs[0]
    ) {
      cloudRecoveredAt = 0;
      return { action: 'recent-external-failure' };
    }

    const sameAsLastAttempt =
      state.lastAttemptAt > 0 &&
      scan.treeSig === state.lastAttemptTreeSig &&
      localCommitSha === state.lastAttemptHead &&
      refs.originMainSha === state.lastAttemptOriginMain;
    if (sameAsLastAttempt && !pendingRecovery) {
      const idx = Math.min(
        Math.max(0, (state.consecutiveUnconverged || 1) - 1),
        retryBackoffMs.length - 1
      );
      const waitMs = retryBackoffMs[idx];
      if (atMs - state.lastAttemptAt < waitMs) {
        cloudRecoveredAt = 0;
        return { action: 'backoff', waitMs };
      }
    }

    const adminScript = path.join(paths.memoryRoot, 'Admin', 'bhfirms-memory-git.py');
    const hookScript = path.join(paths.homeDir, '.claude', 'hooks', 'bhfirms-memory-git.py');
    const scriptPath = isValidMemoryGitScript(adminScript)
      ? adminScript
      : isValidMemoryGitScript(hookScript)
        ? hookScript
        : '';
    const pyExe = options.pythonExe || findLocalConsolePythonExe(paths.homeDir);
    if (!scriptPath || !pyExe) {
      cloudRecoveredAt = 0;
      return { action: 'missing-runtime' };
    }

    cloudRecoveredAt = 0;
    const startedTreeSig = scan.treeSig;
    const startedPathsSig = scan.pathsSig;
    const triggerKind = triggerAheadRefs && !triggerIdleEdits ? 'ahead' : 'idle';
    state.lastAttemptAt = atMs;
    state.lastAttemptTreeSig = startedTreeSig;
    state.lastAttemptHead = localCommitSha;
    state.lastAttemptOriginMain = refs.originMainSha;
    writeJsonAtomic(paths.stateFile, state);

    const childEnv = {
      ...env,
      PYTHONUTF8: '1',
      PYTHONIOENCODING: 'utf-8',
      THEO_MEMORY_ROOT: paths.memoryRoot,
      THEO_MEMORY_GITDIR: paths.gitDir,
      THEO_MEMORY_AUTO_TRIGGER: triggerKind
    };
    const spawnCwd = fs.existsSync(paths.homeDir)
      ? paths.homeDir
      : path.dirname(paths.memoryRoot);

    try {
      childInFlight = true;
      childStartedAt = atMs;
      const child = spawn(pyExe, ['-B', scriptPath, '--auto'], {
        cwd: spawnCwd,
        env: childEnv,
        detached: false,
        windowsHide: true,
        stdio: 'ignore'
      });
      activeChild = child;
      inFlightPromise = new Promise((resolveDone) => {
        let settled = false;
        const finish = (exitCode) => {
          if (settled) return;
          settled = true;
          if (activeChild === child) {
            activeChild = null;
            childInFlight = false;
          }
          const doneMs = nowFn();
          const afterRefs = readMemoryGitRefs(paths.gitDir, doneMs);
          const afterLocalSha = afterRefs.mainSha || afterRefs.headSha;
          const afterConverged =
            Boolean(afterRefs.mainSha) &&
            afterRefs.headSha === afterRefs.mainSha &&
            afterRefs.mainSha === afterRefs.originMainSha &&
            !afterRefs.hasPreOriginRef;
          const numCode = typeof exitCode === 'number' ? exitCode : 1;
          state.lastAttemptHead = afterLocalSha;
          state.lastAttemptOriginMain = afterRefs.originMainSha;
          state.lastExitCode = numCode;
          if (numCode === 0 && afterConverged) {
            const pushedOrMoved =
              afterRefs.mainSha !== localCommitSha ||
              afterRefs.originMainSha !== refs.originMainSha;
            state.lastCleanTreeSig = startedTreeSig;
            state.lastCleanPathsSig = startedPathsSig;
            state.lastCleanHead = afterRefs.mainSha;
            state.lastCleanOriginMain = afterRefs.originMainSha;
            state.lastCommittedTreeSig = startedTreeSig;
            state.lastCommittedPathsSig = startedPathsSig;
            state.lastCommittedHead = afterRefs.mainSha;
            state.lastStaleWaitTreeSig = '';
            state.lastStaleWaitHead = '';
            state.lastStaleWaitOriginMain = '';
            state.consecutiveUnconverged = 0;
            if (pushedOrMoved) {
              logFn(
                `[INFO] memory-git idle sync (${triggerKind}) converged at ${afterRefs.mainSha.slice(0, 7)}`
              );
            }
          } else if (numCode === 0 && !afterConverged) {
            state.lastStaleWaitTreeSig = startedTreeSig;
            state.lastStaleWaitHead = afterLocalSha;
            state.lastStaleWaitOriginMain = afterRefs.originMainSha;
            state.consecutiveUnconverged = 0;
          } else {
            if (afterLocalSha && afterLocalSha !== localCommitSha) {
              state.lastCommittedTreeSig = startedTreeSig;
              state.lastCommittedPathsSig = startedPathsSig;
              state.lastCommittedHead = afterLocalSha;
            }
            state.consecutiveUnconverged = (state.consecutiveUnconverged || 0) + 1;
            if (numCode !== 0) {
              logFn(`[WARN] memory-git idle sync (${triggerKind}) exited ${numCode}`);
            }
          }
          writeJsonAtomic(paths.stateFile, state);
          resolveDone({ exitCode: numCode, state: { ...state } });
        };
        child.on('close', (code) => finish(code));
        child.on('error', () => finish(1));
      });
      return { action: 'spawned', trigger: triggerKind };
    } catch {
      activeChild = null;
      childInFlight = false;
      state.consecutiveUnconverged = (state.consecutiveUnconverged || 0) + 1;
      writeJsonAtomic(paths.stateFile, state);
      return { action: 'spawn-error' };
    }
  }

  function waitForInFlight() {
    return inFlightPromise || Promise.resolve({ exitCode: state.lastExitCode, state: { ...state } });
  }

  function getState() {
    return { ...state };
  }

  return {
    maybeTick,
    noteCloudConnectivity,
    isInFlight,
    waitForInFlight,
    getState
  };
}

function getFileMtimeMs(filePath) {
  try {
    return Math.floor(fs.statSync(filePath).mtimeMs);
  } catch {
    return 0;
  }
}

function computeDiskMaxMtime() {
  return Math.max(
    getFileMtimeMs(__filename),
    getFileMtimeMs(path.join(__dirname, 'memory_cloud_sync.cjs')),
    getFileMtimeMs(path.join(REPO_ROOT, 'remote.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'store.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'accounts.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'data.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'bridge.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'desktop-launcher.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'device-identity.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'pc-setup.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'bundle-updater.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'ws-server.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'direct-runner.js')),
    getFileMtimeMs(path.join(REPO_ROOT, 'edge-relay-client.js'))
  );
}

function isPidAlive(pid) {
  const n = Number(pid || 0);
  if (!n || n <= 0 || n === process.pid) return false;
  try {
    process.kill(n, 0);
    return true;
  } catch (err) {
    return err && err.code === 'EPERM';
  }
}

function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try {
    if (!fs.existsSync(CLAUDE_DIR)) {
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    }
    if (fs.existsSync(LOG_FILE) && fs.statSync(LOG_FILE).size > 2 * 1024 * 1024) {
      fs.unlinkSync(LOG_FILE);
    }
    fs.appendFileSync(LOG_FILE, line, 'utf8');
  } catch {}
  if (process.argv.includes('--once')) {
    process.stderr.write(line);
  }
}

function httpJson(url, options = {}) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const isLocal =
      parsed.hostname === 'localhost' ||
      parsed.hostname === '127.0.0.1' ||
      parsed.hostname === '::1';
    const targetHost = parsed.hostname === 'localhost' ? '127.0.0.1' : parsed.hostname;
    let bearer = '';
    if (isLocal) {
      const creds = loadTheoCredentials();
      if (creds.effectiveEdgeSecret) {
        bearer = deriveEdgeAuthToken(creds.effectiveEdgeSecret);
      }
    }
    const bodyText = options.body ? String(options.body) : '';
    const req = http.request(
      {
        protocol: parsed.protocol,
        hostname: targetHost,
        port: parsed.port || 4318,
        path: `${parsed.pathname}${parsed.search}`,
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}),
          ...(bodyText ? { 'Content-Length': Buffer.byteLength(bodyText) } : {})
        },
        timeout: options.timeoutMs || 5000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          try {
            resolve(raw ? JSON.parse(raw) : {});
          } catch {
            resolve({ raw });
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error('Local bridge timeout')));
    req.on('error', reject);
    if (bodyText) req.write(bodyText);
    req.end();
  });
}

function fetchCloudMetaAgeMs(relayConfig) {
  return new Promise((resolve) => {
    let parsed;
    try {
      parsed = new URL(relayConfig.url);
    } catch {
      resolve(Infinity);
      return;
    }
    const body = JSON.stringify({ key: relayConfig.key, op: 'get_control' });
    const req = https.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: parsed.pathname + parsed.search,
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=UTF-8',
          'Content-Length': Buffer.byteLength(body)
        },
        timeout: 15000
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          try {
            const j = JSON.parse(Buffer.concat(chunks).toString('utf8'));
            const docs = j?.docs && typeof j.docs === 'object' ? j.docs : j || {};
            const stamp = Date.parse(docs?.meta?.updatedAt || '') || 0;
            resolve(stamp ? Date.now() - stamp : Infinity);
          } catch {
            resolve(Infinity);
          }
        });
      }
    );
    req.on('timeout', () => req.destroy());
    req.on('error', () => resolve(Infinity));
    req.write(body);
    req.end();
  });
}

function readJsonSafe(filePath, fallback = {}) {
  try {
    if (fs.existsSync(filePath)) {
      return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
  } catch {}
  return fallback;
}

async function buildStandaloneState(store, bridge, opts = {}) {
  const cachedState = readJsonSafe(LAST_STATE_CACHE_FILE, {});
  const persistedHub = readJsonSafe(HUB_STATE_FILE, {});
  const customTitles = persistedHub?.customTitles || {};
  const threadGroups = persistedHub?.threadGroups || {};
  // `.theo-hub-state.json` is written by HubStateStore (state.js): keys are `archivedIds`,
  // `unreadIds`, `seenTurnTimestamps` (seconds) and `baseline` (seconds).
  const archivedSet = new Set([
    ...(Array.isArray(persistedHub?.archivedIds) ? persistedHub.archivedIds : []),
    ...(Array.isArray(persistedHub?.archived) ? persistedHub.archived : [])
  ]);
  const unreadSet = new Set(Array.isArray(persistedHub?.unreadIds) ? persistedHub.unreadIds : []);
  const seenAtMap =
    persistedHub?.seenTurnTimestamps && typeof persistedHub.seenTurnTimestamps === 'object'
      ? persistedHub.seenTurnTimestamps
      : persistedHub?.seenAt || {};
  const baselineSec = Number(persistedHub?.baseline || 0);
  const groups = Array.isArray(persistedHub?.groups)
    ? persistedHub.groups.map((g) => ({
        id: g.id,
        name: g.name,
        collapsed: Boolean(g.collapsed)
      }))
    : cachedState.groups || [];
  const groupIds = new Set(groups.map((g) => g.id));

  let snap = null;
  try {
    snap = await store.loadSnapshot({ forceQuota: false });
  } catch {}

  const workspaces = await bridge.refreshWorkspacesCache().catch(() => cachedState.workspaces || []);

  if (!snap || !Array.isArray(snap.threads)) {
    const fallbackRows = Array.isArray(cachedState.rows) ? cachedState.rows : [];
    bridge.hub = {
      snapshot: {
        threads: fallbackRows.map((r) => ({
          id: r.id,
          provider: r.provider,
          title: r.title,
          cwd: r.cwd,
          workspaceLabel: r.folder,
          branch: r.branch,
          model: r.model,
          updatedAt: Math.floor((r.at || Date.now()) / 1000)
        }))
      }
    };
    return {
      ...cachedState,
      rows: fallbackRows,
      generatedAt: Date.now(),
      connection: bridge.getStatus(),
      workspaces,
      personalLedger: bridge.personalLedger
    };
  }

  const activity = new SessionActivityTracker();
  const rows = [];
  const standaloneApprovals = [];
  for (const thread of snap.threads) {
    if (!thread || !thread.id) continue;
    const provider = thread.provider === 'claude' ? 'claude' : 'antigravity';
    const classified = activity.classifyThread(thread, { recordTransition: false });
    let status = 'idle';
    if (classified.state === 'waiting') {
      status = 'waiting';
    } else if (classified.state === 'thinking') {
      status = 'working';
    } else if (classified.state === 'errored') {
      status = 'failed';
    } else if (classified.state === 'completed') {
      status = 'completed';
    }
    const rawSeen = Number(seenAtMap[thread.id] || 0);
    const seenSec = Math.max(rawSeen > 1e11 ? Math.floor(rawSeen / 1000) : rawSeen, baselineSec);
    const updatedSec = Number(thread.updatedAt || 0);
    const updatedMs = updatedSec * 1000;
    const isUnread =
      unreadSet.has(thread.id) ||
      ((status === 'completed' || status === 'failed') && updatedSec > seenSec + 2);
    const dot =
      status === 'waiting'
        ? 'waiting'
        : status === 'working'
          ? 'running'
          : isUnread
            ? 'unread'
            : null;
    const category =
      status === 'waiting'
        ? 'needs_input'
        : status === 'working'
          ? 'working'
          : 'completed';
    const title = customTitles[thread.id] || thread.title || 'Untitled session';
    const stepCount = Number(thread.stepCount || 0);
    const pendingQuestion = thread.pendingQuestion || null;
    const lastAssistantText = thread.lastAssistantText || '';
    const rawBg = Array.isArray(thread.backgroundTasks) ? thread.backgroundTasks : [];
    const bgRunningCount = rawBg.filter((t) => t && t.state === 'running').length;
    const bgTotalCount = rawBg.length;
    const bgTasks = rawBg.slice(-8).map((t) => ({
      id: t.id,
      fullId: t.fullId || t.id,
      subagentConversationId: t.subagentConversationId || '',
      kind: t.kind || 'task',
      subagentType: t.subagentType || '',
      summary: String(t.summary || '').slice(0, 140),
      command: String(t.command || '').slice(0, 220),
      state: t.state || 'completed',
      isDaemon: Boolean(t.isDaemon),
      startedAt: Number(t.startedAt || 0) * 1000,
      completedAt: t.completedAt ? Number(t.completedAt) * 1000 : 0,
      stepIndex: typeof t.stepIndex === 'number' ? t.stepIndex : -1
    }));

    rows.push({
      key: thread.id,
      id: thread.id,
      provider,
      draft: false,
      title,
      at: updatedMs,
      open: false,
      active: false,
      group:
        threadGroups[thread.id] && groupIds.has(threadGroups[thread.id])
          ? threadGroups[thread.id]
          : null,
      archived: archivedSet.has(thread.id) || Boolean(thread.archived),
      cwd: thread.cwd || '',
      folder: thread.workspaceLabel || '',
      branch: thread.branch || '',
      deviceId: thread.deviceId || '',
      deviceName: thread.deviceName || '',
      source: thread.source || '',
      remotePeer: Boolean(thread.remotePeer || thread.source === 'cloud-relay'),
      model: formatModelDisplayName(
        thread.model || (provider === 'claude' ? 'Claude' : 'Gemini'),
        provider
      ),
      logged: true,
      status,
      dot,
      category,
      unread: isUnread,
      elsewhere: Boolean(status === 'working' || thread.elsewhere),
      reason: classified.reason || thread.runReason || null,
      stepCount,
      turnComplete: thread.turnComplete !== false,
      lastAssistantText,
      pendingQuestion,
      bgTasks,
      bgRunningCount,
      bgTotalCount
    });

    if (pendingQuestion || status === 'waiting') {
      const isQ = Boolean(pendingQuestion);
      const stepKey = pendingQuestion?.stepIndex || stepCount || 0;
      const itemId =
        pendingQuestion?.approvalId ||
        (isQ
          ? `question-${thread.id}-${stepKey}`
          : stepKey
            ? `waiting-${thread.id}-${stepKey}`
            : `waiting-${thread.id}`);
      standaloneApprovals.push({
        id: itemId,
        approvalId: itemId,
        provider,
        sessionId: thread.id,
        title,
        toolName:
          pendingQuestion?.toolName ||
          (isQ ? 'Question' : classified.reason || 'Waiting on user input'),
        detail:
          pendingQuestion?.questionText ||
          lastAssistantText ||
          `${thread.workspaceLabel || 'Workspace'} · ${thread.model || ''}`.trim(),
        codePreview: pendingQuestion?.codePreview || '',
        description: pendingQuestion?.description || '',
        isToolPermission: Boolean(pendingQuestion?.isToolPermission),
        writeInPlaceholder: pendingQuestion?.writeInPlaceholder || '',
        isMultiSelect: Boolean(pendingQuestion?.isMultiSelect),
        options: pendingQuestion?.options || [],
        questions: pendingQuestion?.questions || [],
        stepIndex: stepKey,
        kind: isQ ? 'question' : 'waiting_session',
        createdAt: (pendingQuestion?.at ? pendingQuestion.at * 1000 : updatedMs) || Date.now()
      });
    }
  }

  rows.sort((a, b) => b.at - a.at);

  const formatBucket = (b) => ({
    label: b.label,
    pct: b.usedPercent,
    reset: b.resetAt ? b.resetAt * 1000 : 0,
    resetText: b.resetText || '',
    expired: Boolean(b.expired ?? b.windowExpired)
  });

  let accountsView = null;
  if (bridge.accountVault) {
    try {
      bridge.accountVault.syncActiveClaudeFromDisk(
        snap?.claudeConfigObj,
        snap?.claudeCredsObj,
        snap?.rawClaudeQuota,
        snap?.loadedAt
      );
      const prefCollapsed = persistedHub?.preferences?.collapsedAccounts || {};
      accountsView = await bridge.accountVault.resolveAccountsSnapshot({
        nowMs: Date.now(),
        forceQuota: false,
        antigravityAccount: snap?.account,
        antigravityLimits: snap?.rateLimits,
        rawAntigravityQuota: snap?.rawAntigravityQuota,
        claudeAccount: snap?.claudeAccount,
        claudeLimits: snap?.claudeRateLimits,
        rawClaudeQuota: snap?.rawClaudeQuota,
        claudeRelayMerged: snap?.claudeLive?.rateLimitWindows,
        collapsedProviders: {
          antigravity: Boolean(persistedHub?.preferences?.antigravityUsageCollapsed),
          claude: Boolean(persistedHub?.preferences?.claudeUsageCollapsed),
          ...prefCollapsed
        }
      });
    } catch {}
  }

  const mapStandaloneCard = (item) => {
    const provKey = item.provider === 'claude' ? 'claude' : 'antigravity';
    const isSignedOutItem = !item.available || Boolean(item.signedOut || item.account?.signedOut);
    const pLimits = isSignedOutItem ? [] : (item.rateLimits?.primaryBars || []).map(formatBucket);
    const aLimits = isSignedOutItem ? [] : (item.rateLimits?.allBuckets || []).map(formatBucket);
    return {
      id: item.id,
      provider: provKey,
      label: provKey === 'claude' ? 'Claude Code' : 'Antigravity',
      nickname: item.label || '',
      active: !isSignedOutItem && Boolean(item.active),
      collapsed: Boolean(item.collapsed),
      sortOrder: Number.isFinite(Number(item.sortOrder)) ? Number(item.sortOrder) : 0,
      account: {
        name: item.name || item.account?.name || (provKey === 'claude' ? 'Claude Account' : 'Antigravity Account'),
        email: isSignedOutItem ? '' : item.email || item.account?.email || '',
        plan: isSignedOutItem ? '' : item.plan || item.account?.plan || (provKey === 'claude' ? 'Claude Code' : 'Google AI Pro'),
        nickname: item.label || '',
        available: !isSignedOutItem && Boolean(item.available),
        signedOut: isSignedOutItem
      },
      usage: pLimits.length
        ? {
            at: item.quotaUpdatedAt || snap?.loadedAt || Date.now(),
            limits: pLimits,
            allLimits: aLimits
          }
        : null,
      usageMessage: isSignedOutItem ? 'Not signed in.' : item.rateLimits?.error || ''
    };
  };

  const agyPrimaryLimits = (snap?.rateLimits?.primaryBars || []).map(formatBucket);
  const agyAllLimits = (snap?.rateLimits?.allBuckets || []).map(formatBucket);
  const claudePrimaryLimits = (snap?.claudeRateLimits?.primaryBars || []).map(formatBucket);
  const claudeAllLimits = (snap?.claudeRateLimits?.allBuckets || []).map(formatBucket);

  const agyProviderInfo = {
    id: 'antigravity',
    label: 'Antigravity',
    account: {
      name: snap?.account?.name || cachedState?.account?.name || 'Antigravity Account',
      email: snap?.account?.email || cachedState?.account?.email || '',
      plan: snap?.account?.plan || cachedState?.account?.plan || 'Google AI Pro',
      available: Boolean(snap?.account?.email || snap?.account?.name || cachedState?.account?.available),
      signedOut: false
    },
    usage: agyPrimaryLimits.length
      ? {
          at: snap?.loadedAt || Date.now(),
          limits: agyPrimaryLimits,
          allLimits: agyAllLimits
        }
      : cachedState?.providers?.antigravity?.usage || cachedState?.usage || null,
    usageMessage: '',
    accounts:
      accountsView?.antigravity?.length
        ? accountsView.antigravity.map(mapStandaloneCard)
        : cachedState?.providers?.antigravity?.accounts || undefined
  };

  const claudeSignedOut = Boolean(snap?.claudeAccount?.signedOut);
  const claudeProviderInfo = {
    id: 'claude',
    label: 'Claude Code',
    account: claudeSignedOut
      ? {
          name: 'Claude Code',
          email: '',
          plan: '',
          available: false,
          signedOut: true
        }
      : {
          name: snap?.claudeAccount?.name || cachedState?.providers?.claude?.account?.name || 'Claude Account',
          email: snap?.claudeAccount?.email || cachedState?.providers?.claude?.account?.email || '',
          plan: snap?.claudeAccount?.plan || cachedState?.providers?.claude?.account?.plan || 'Claude Code',
          available: Boolean(snap?.claudeAccount?.available || cachedState?.providers?.claude?.account?.available),
          signedOut: false
        },
    usage: claudeSignedOut
      ? null
      : claudePrimaryLimits.length
        ? {
            at: snap?.loadedAt || Date.now(),
            limits: claudePrimaryLimits,
            allLimits: claudeAllLimits
          }
        : cachedState?.providers?.claude?.usage || null,
    usageMessage: claudeSignedOut ? 'Not signed in.' : '',
    accounts:
      accountsView?.claude?.length
        ? accountsView.claude.map(mapStandaloneCard)
        : claudeSignedOut
          ? []
          : cachedState?.providers?.claude?.accounts || undefined
  };

  bridge.hub = {
    snapshot: {
      threads: snap.threads
    }
  };

  const selfDevId = bridge.deviceInfo?.id || 'workstation';
  const selfDevName = bridge.deviceInfo?.name || os.hostname();
  const peerOwnedRowIds = new Map();
  const addPeerRows = (devId, list) => {
    if (!devId || devId === selfDevId || !Array.isArray(list)) return;
    let set = peerOwnedRowIds.get(devId);
    if (!set) {
      set = new Set();
      peerOwnedRowIds.set(devId, set);
    }
    for (const pr of list) {
      if (pr && pr.id) set.add(String(pr.id));
    }
  };
  if (bridge.edgeClient) {
    for (const [pDevId, pEntry] of Object.entries(bridge.edgeClient.getPeerSnapshots())) {
      addPeerRows(pDevId, pEntry?.snapshot?.rows);
    }
  }
  for (const [rDevId, rEntry] of Object.entries(bridge.remoteDeviceStates || {})) {
    addPeerRows(rDevId, rEntry?.snapshot?.rows || rEntry?.rows);
  }
  const rowById = new Map();
  for (const r of rows) {
    if (!r || !r.id) continue;
    const ownerInfo = inferRowOwnerDevice(r, bridge.deviceInfo, { peerOwnedRowIds });
    const ownerDevId = ownerInfo.id || ownerInfo.deviceId;
    const ownerDevName = ownerInfo.name || ownerInfo.deviceName;
    const isForeignRow =
      ownerDevId !== selfDevId || r.source === 'cloud-relay' || Boolean(r.remotePeer);
    if (opts.localOnly && isForeignRow) continue;
    rowById.set(r.id, {
      ...r,
      deviceId: ownerDevId || selfDevId,
      deviceName: ownerDevName || selfDevName,
      remotePeer: isForeignRow
    });
  }
  if (bridge.directRunner) {
    for (const run of bridge.directRunner.getActiveRuns()) {
      const rid = run.threadId || run.id;
      if (!rid) continue;
      const existing = rowById.get(rid);
      rowById.set(rid, {
        ...(existing || {}),
        id: rid,
        draftId: run.draftId || existing?.draftId || '',
        provider: run.provider,
        deviceId: selfDevId,
        deviceName: selfDevName,
        remotePeer: false,
        title: existing?.title || run.title || 'New Direct Session',
        cwd: existing?.cwd || run.cwd || '',
        folder: existing?.folder || run.folder || 'Workspace',
        model: formatModelDisplayName(run.model || existing?.model, run.provider),
        status: 'working',
        statusLabel: run.activeTool ? `Running ${run.activeTool}` : 'Streaming ⚡',
        dot: 'running',
        category: 'working',
        directStreaming: true,
        at: Math.max(Number(existing?.at || 0), Number(run.updatedAt || Date.now())),
        lastAssistantText: run.fullText ? run.fullText.slice(-220) : existing?.lastAssistantText || ''
      });
    }
  }
  if (!opts.localOnly) {
    for (const [rDevId, rEntry] of Object.entries(bridge.remoteDeviceStates || {})) {
      const rRows = Array.isArray(rEntry?.snapshot?.rows)
        ? rEntry.snapshot.rows
        : Array.isArray(rEntry?.rows)
          ? rEntry.rows
          : null;
      if (!rDevId || rDevId === selfDevId || !rRows) continue;
      for (const pr of rRows) {
        if (!pr || !pr.id || rowById.has(pr.id)) continue;
        // The peer listed this session as its own, so it is the owner whatever folder the session ran in.
        const prOwner = inferRowOwnerDevice(
          { ...pr, deviceId: rDevId, deviceName: rEntry.device?.name || rDevId },
          { id: rDevId, name: rEntry.device?.name || rDevId },
          { trustStamp: true }
        );
        rowById.set(pr.id, {
          ...pr,
          deviceId: prOwner.id || prOwner.deviceId || rDevId,
          deviceName: prOwner.name || prOwner.deviceName || rEntry.device?.name || rDevId,
          remotePeer: true,
          model: formatModelDisplayName(pr.model, pr.provider)
        });
      }
    }
  }
  const mergedRows = Array.from(rowById.values()).sort(
    (a, b) => Number(b.at || 0) - Number(a.at || 0)
  );
  const stampedWorkspaces = (workspaces || []).map((w) => ({
    ...w,
    deviceId: selfDevId,
    deviceName: selfDevName
  }));

  return {
    ...cachedState,
    type: 'state',
    loading: false,
    device: {
      id: selfDevId,
      name: selfDevName,
      role: bridge.deviceInfo?.role || 'host',
      hostname: os.hostname(),
      homedir: os.homedir(),
      capabilities: bridge.deviceInfo?.capabilities || []
    },
    account: agyProviderInfo.account,
    usage: agyProviderInfo.usage,
    providers: {
      antigravity: agyProviderInfo,
      claude: claudeProviderInfo
    },
    accountOrder: Array.isArray(accountsView?.accountOrder)
      ? accountsView.accountOrder
      : cachedState?.accountOrder || [],
    groups,
    rows: mergedRows,
    devices: bridge.getUnifiedFleetDevices ? bridge.getUnifiedFleetDevices() : [],
    activeDirectRuns: bridge.directRunner ? bridge.directRunner.getActiveRuns() : [],
    total: mergedRows.length,
    generatedAt: Date.now(),
    connection: bridge.getStatus(),
    approvals: standaloneApprovals,
    workspaces: stampedWorkspaces,
    topSessions: (snap?.usage?.topThreads || cachedState.topSessions || []).slice(0, 12),
    personalLedger: bridge.personalLedger,
    claudePermissionMode:
      typeof bridge.getClaudePermissionModeSnapshot === 'function'
        ? bridge.getClaudePermissionModeSnapshot()
        : undefined
  };
}

function acquireSingleInstanceLock(bootMtime, forceRestart) {
  try {
    if (!fs.existsSync(CLAUDE_DIR)) {
      fs.mkdirSync(CLAUDE_DIR, { recursive: true });
    }
    let existingPid = 0;
    if (fs.existsSync(PID_FILE)) {
      existingPid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim() || 0);
    }
    const existingMeta = readJsonSafe(META_FILE, {});
    if (!existingPid && existingMeta.pid) {
      existingPid = Number(existingMeta.pid);
    }
    if (isPidAlive(existingPid)) {
      const existingBoot = Number(existingMeta.bootMtime || 0);
      if (!forceRestart && existingBoot >= bootMtime - 1000) {
        return false;
      }
      try {
        process.kill(existingPid);
        log(`[INFO] Replaced older keepalive instance (pid ${existingPid})`);
      } catch {}
    }
    fs.writeFileSync(PID_FILE, String(process.pid), 'utf8');
    fs.writeFileSync(
      META_FILE,
      JSON.stringify({
        pid: process.pid,
        startedAt: Date.now(),
        bootMtime,
        script: __filename
      }),
      'utf8'
    );
  } catch {}
  return true;
}

let respawnTriggered = false;
function respawnSelfAndExit(updateInfo = null) {
  if (respawnTriggered) return;
  respawnTriggered = true;
  try {
    const origPs1 = path.join(__dirname, 'relay_keepalive_start.ps1');
    let startPs1 = origPs1;
    const candidateTargets = updateInfo?.updatedPaths || updateInfo?.updatedTargets;
    if (Array.isArray(candidateTargets)) {
      for (const tgt of candidateTargets) {
        const candPs1 = path.join(tgt, 'scripts', 'relay_keepalive_start.ps1');
        if (getFileMtimeMs(candPs1) > getFileMtimeMs(startPs1)) {
          startPs1 = candPs1;
        }
      }
    }
    const psArgs = [
      '-NoProfile',
      '-NonInteractive',
      '-WindowStyle',
      'Hidden',
      '-ExecutionPolicy',
      'Bypass',
      '-File',
      startPs1,
      '-Restart'
    ];
    // When respawning onto a newly self-updated target folder (e.g. ~/.vscode/extensions/bhfirms.theo-hub-* when
    // ~/bhfirms/theo-hub was skipped due to git state), re-register the Scheduled Task & Startup VBS to that folder.
    const movedTarget = path.resolve(startPs1) !== path.resolve(origPs1) || Boolean(updateInfo?.updated);
    if (!movedTarget) {
      psArgs.push('-SkipTaskCheck');
    }
    const child = spawn('powershell.exe', psArgs, {
      cwd: path.dirname(path.dirname(startPs1)),
      detached: true,
      windowsHide: true,
      stdio: 'ignore'
    });
    child.unref();
    log('[INFO] Code updated on disk -> triggered WMI respawn via relay_keepalive_start.ps1');
  } catch (err) {
    log(`[WARN] Self-respawn failed: ${err.message}`);
  }
  setTimeout(() => process.exit(0), 400);
}

async function main() {
  const once = process.argv.includes('--once');
  const forceRestart = process.argv.includes('--restart') || process.argv.includes('--force');
  const bootMtime = computeDiskMaxMtime();

  if (!once) {
    const acquired = acquireSingleInstanceLock(bootMtime, forceRestart);
    if (!acquired) {
      process.exit(0);
    }
  }

  const store = new AntigravityDataStore();
  const accountVault = new AccountVaultManager();
  const bridge = new TheoRemoteBridge(
    { extensionPath: REPO_ROOT },
    { store, accountVault }
  );

  let yieldCooldownUntil = 0;

  async function releaseStandaloneListeners() {
    yieldCooldownUntil = Date.now() + 12000;
    try {
      if (bridge.edgeClient) {
        bridge.edgeClient.stop();
      }
    } catch {}
    try {
      if (bridge.wsHub) {
        bridge.wsHub.closeAll();
        bridge.wsHub = null;
      }
    } catch {}
    for (const client of Array.from(bridge.sseClients || [])) {
      try {
        client.end();
      } catch {}
    }
    bridge.sseClients?.clear?.();
    if (bridge.standbyBindTimer) {
      clearInterval(bridge.standbyBindTimer);
      bridge.standbyBindTimer = null;
    }
    if (bridge.server) {
      await new Promise((resolve) => {
        try {
          bridge.server.closeAllConnections?.();
        } catch {}
        try {
          bridge.server.close(() => resolve());
        } catch {
          resolve();
        }
        setTimeout(resolve, 150);
      });
      bridge.server = null;
      bridge.listening = false;
    }
    log('[INFO] Yielded standalone :4318 + Edge Relay to VS Code extension host');
  }

  let pendingSelfUpdateInfo = null;
  let isBackgroundChildBusy = () => false;

  bridge.onYieldPortRequested = releaseStandaloneListeners;
  bridge.onSelfUpdateApplied = (info) => {
    if (!once) {
      const rel = info?.release || info;
      if (isBackgroundChildBusy()) {
        pendingSelfUpdateInfo = info;
        log(
          `[INFO] Self-updated theo-hub bundle (${rel?.version || ''} @ ${rel?.builtAt || 0}) -> deferring daemon respawn until background sync child exits`
        );
        return;
      }
      log(`[INFO] Self-updated theo-hub bundle (${rel?.version || ''} @ ${rel?.builtAt || 0}) -> respawning daemon`);
      respawnSelfAndExit(info);
    }
  };

  // Use live localhost:4318 when VS Code owns :4318; run standalone directly when we own :4318 or VS Code is closed
  bridge.buildFullState = async (opts = {}) => {
    if (bridge.listening) {
      return buildStandaloneState(store, bridge, opts);
    }
    try {
      const res = await httpJson('http://localhost:4318/api/state', { timeoutMs: 8000 });
      if (res && res.state && Array.isArray(res.state.rows)) {
        const state = res.state;
        if (state.personalLedger) {
          bridge.mergePersonalLedger(state.personalLedger);
        }
        state.personalLedger = bridge.personalLedger;
        if (!state.claudePermissionMode && typeof bridge.getClaudePermissionModeSnapshot === 'function') {
          state.claudePermissionMode = bridge.getClaudePermissionModeSnapshot();
        }
        let threadsById = new Map();
        const needsTranscriptEnrich = state.rows.some((r) => r && r.stepCount === undefined);
        if (needsTranscriptEnrich) {
          try {
            const snap = await store.loadSnapshot({ forceQuota: false });
            if (snap && Array.isArray(snap.threads)) {
              threadsById = new Map(snap.threads.map((t) => [t.id, t]));
            }
          } catch {}
        }
        const approvals = Array.isArray(state.approvals) ? [...state.approvals] : [];
        const rows = state.rows.map((r) => {
          const t = threadsById.get(r.id);
          const pendingQuestion = r.pendingQuestion || t?.pendingQuestion || null;
          const stepCount = Number(r.stepCount ?? t?.stepCount ?? 0);
          const lastAssistantText = r.lastAssistantText || t?.lastAssistantText || '';
          const status = pendingQuestion ? 'waiting' : r.status;
          const category = status === 'waiting' ? 'needs_input' : r.category;
          const dot = status === 'waiting' ? 'waiting' : r.dot;
          if (pendingQuestion && !approvals.some((a) => a && a.sessionId === r.id && a.kind === 'question')) {
            const stepKey = pendingQuestion.stepIndex || stepCount || 0;
            const qId = `question-${r.id}-${stepKey}`;
            const filteredIdx = approvals.findIndex((a) => a && a.sessionId === r.id && a.kind === 'waiting_session');
            if (filteredIdx >= 0) approvals.splice(filteredIdx, 1);
            approvals.push({
              id: qId,
              approvalId: qId,
              provider: r.provider || 'antigravity',
              sessionId: r.id,
              title: r.title || 'Session asking a question',
              toolName: 'Question',
              detail: pendingQuestion.questionText || 'Waiting for your answer',
              isMultiSelect: Boolean(pendingQuestion.isMultiSelect),
              options: pendingQuestion.options || [],
              questions: pendingQuestion.questions || [],
              stepIndex: stepKey,
              kind: 'question',
              createdAt: (pendingQuestion.at ? pendingQuestion.at * 1000 : r.at) || Date.now()
            });
          }
          return {
            ...r,
            status,
            category,
            dot,
            stepCount,
            lastAssistantText,
            pendingQuestion,
            model: formatModelDisplayName(r.model, r.provider)
          };
        });
        state.rows = rows;
        state.approvals = approvals;
        bridge.hub = {
          snapshot: {
            threads: rows.map((r) => ({
              id: r.id,
              provider: r.provider,
              title: r.title,
              cwd: r.cwd,
              workspaceLabel: r.folder,
              branch: r.branch,
              model: r.model,
              stepCount: r.stepCount,
              lastAssistantText: r.lastAssistantText,
              pendingQuestion: r.pendingQuestion,
              updatedAt: Math.floor((r.at || Date.now()) / 1000)
            }))
          }
        };
        return state;
      }
    } catch {}
    return buildStandaloneState(store, bridge, opts);
  };

  const origExecuteRemoteCommand = bridge.executeRemoteCommand.bind(bridge);
  bridge.executeRemoteCommand = async (cmd = {}) => {
    if (bridge.listening) {
      return origExecuteRemoteCommand(cmd);
    }
    const type = String(cmd.type || cmd.action || '').trim();
    const subAction = String(cmd.subAction || cmd.action || '').trim();
    const cleanTargetCandidate = (val) => {
      const s = String(val || '').trim();
      if (!s || s === '__new__' || s.startsWith('cmd-') || s.startsWith('draft-new-') || s.startsWith('draft-direct-')) {
        return '';
      }
      return s;
    };
    const targetId = cleanTargetCandidate(cmd.threadId) || cleanTargetCandidate(cmd.id);
    if (type === 'requestThread' || (type === 'sessionAction' && subAction === 'requestThread')) {
      const id = targetId;
      const provider = cmd.provider === 'claude' ? 'claude' : 'antigravity';
      if (id) {
        if (!bridge.requestedThreads) bridge.requestedThreads = new Map();
        bridge.requestedThreads.set(id, { provider, requestedAt: Date.now() });
      }
      return { ok: true, id, provider };
    }
    if (type === 'send' || type === 'sendPrompt') {
      return httpJson('http://localhost:4318/api/send', {
        method: 'POST',
        body: JSON.stringify({ ...cmd, id: targetId, threadId: targetId }),
        timeoutMs: 16000
      }).catch(() => origExecuteRemoteCommand(cmd));
    }
    if (type === 'approve' || type === 'respondApproval' || type === 'answerQuestion') {
      const localRes = await httpJson('http://localhost:4318/api/approve', {
        method: 'POST',
        body: JSON.stringify(cmd),
        timeoutMs: 8000
      });
      if (localRes && localRes.ok) return localRes;
      const sessId = String(cmd.sessionId || targetId || cmd.approvalId || '').trim();
      if (sessId && store?.answerAntigravityQuestion) {
        return store.answerAntigravityQuestion(sessId, cmd).catch(() => ({ ok: false }));
      }
      return { ok: false };
    }
    if (
      type === 'setClaudePermissionMode' ||
      (type === 'sessionAction' && subAction === 'setClaudePermissionMode')
    ) {
      return httpJson('http://localhost:4318/api/claude-permission-mode', {
        method: 'POST',
        body: JSON.stringify(cmd),
        timeoutMs: 8000
      })
        .then((res) => (res && res.ok ? res : origExecuteRemoteCommand(cmd)))
        .catch(() => origExecuteRemoteCommand(cmd));
    }
    if (type === 'cancelBgTask' || type === 'cancelAllBgTasks') {
      return bridge.executeRemoteCommand({
        ...cmd,
        type: 'sessionAction',
        subAction: type
      });
    }
    if (type === 'sessionAction') {
      const localRes = await httpJson('http://localhost:4318/api/session-action', {
        method: 'POST',
        body: JSON.stringify({ ...cmd, id: targetId || cmd.id, action: subAction }),
        timeoutMs: 8000
      }).catch(() => null);
      if (localRes && localRes.ok) return localRes;
      if (subAction === 'cancelBgTask' && store?.cancelBackgroundTaskOnServer) {
        const sid = String(cmd.sessionId || targetId || cmd.id || '').trim();
        const tid = String(cmd.taskId || '').trim();
        if (sid && tid) {
          const out = await store
            .cancelBackgroundTaskOnServer(sid, cmd.provider || '', {
              id: tid,
              fullId: tid,
              kind: cmd.kind || 'task',
              stepIndex: typeof cmd.stepIndex === 'number' ? cmd.stepIndex : -1
            })
            .catch(() => ({ ok: false }));
          return { ok: Boolean(out?.ok) };
        }
      }
      if (
        (subAction === 'interrupt' || subAction === 'stop' || subAction === 'cancel') &&
        (targetId || cmd.id) &&
        store?.cancelSessionOnServer
      ) {
        const ok = await store
          .cancelSessionOnServer(targetId || cmd.id, cmd.provider)
          .catch(() => false);
        return { ok: Boolean(ok) };
      }
      // Host down: apply unread / archive / group edits straight to ~/.claude/.theo-hub-state.json
      // via TheoRemoteBridge's standalone branch (hub-less executeRemoteCommand) instead of
      // silently dropping them.
      try {
        const standaloneRes = await origExecuteRemoteCommand({
          ...cmd,
          type: 'sessionAction',
          subAction,
          action: subAction,
          threadId: targetId
        });
        if (standaloneRes && standaloneRes.ok) return standaloneRes;
      } catch {}
      return localRes || { ok: false };
    }
    return { ok: true };
  };

  // Non-competing watchdog state machine:
  //   healthy      -> host ping fresh & code current; probe cloud stamp every 60s, otherwise 100% idle
  //   hostLagging  -> host ping reachable & code current, but lastCloudSyncAt > 45s; nudge /api/cloud-sync first
  //   staleHost    -> host ping reachable but running older remote.js & cloud stamp stale; take over state sync
  //   hostDown     -> VS Code closed (:4318 unreachable); sync standalone via AntigravityDataStore
  const STORE_PROBE_MS = 45000;
  const STALE_STORE_MS = 45000;
  const RECHECK_MS = 120000;
  const PAUSE_MS = 25000;
  let staleHost = false;
  let lastProbeAt = 0;
  let pauseUntil = 0;
  let lastReason = '';
  let lastErr = '';
  let tickInFlight = false;

  const headlessBridgeState = { resumeCheckInFlight: false };
  async function runHeadlessCascadeContinuity() {
    try {
      const savedHub = readPersistentHubState();
      if (!savedHub || !savedHub.port || !savedHub.csrfToken) return;
      const candidateIds = findActiveCascadesFromDiskTranscripts(Date.now(), {
        maxInterruptedAgeMs: 3600 * 1000
      });
      const res = await checkAndResumeInterruptedCascades(headlessBridgeState, {
        candidateIds: Array.isArray(candidateIds) ? candidateIds : [],
        includeIdleSummaries: true
      });
      if (res && res.resumed > 0) {
        log(
          `[INFO] Headless 24/7 daemon auto-resumed ${res.resumed} cascade(s) while VS Code is closed`
        );
      }
    } catch {}
  }

  const memoryGitIdleSync = createMemoryGitIdleSyncController({ logFn: log });

  function observeStatusForMemoryGit(st, nowMs = Date.now()) {
    if (!st || (!st.cloudConfigured && !st.edgeRelayUrl)) return;
    const online =
      Boolean(st.edgeRelay?.connected) ||
      (!st.lastCloudError &&
        Number(st.lastCloudSyncAt || 0) > 0 &&
        nowMs - Number(st.lastCloudSyncAt || 0) < 90000);
    if (online) {
      if (memoryGitIdleSync.noteCloudConnectivity(true, nowMs)) {
        memoryGitIdleSync.maybeTick(nowMs);
      }
    } else if (st.lastCloudError && !st.edgeRelay?.connected) {
      memoryGitIdleSync.noteCloudConnectivity(false, nowMs);
    }
  }

  async function runSync(reason) {
    if (reason === 'standalone-host' || reason === 'host-down') {
      await runHeadlessCascadeContinuity();
    }
    bridge.lastCloudError = '';
    const syncRes = await bridge.syncCloudRelay({ pushState: true });
    if (!once) {
      observeStatusForMemoryGit(bridge.getStatus(), Date.now());
    }
    if (syncRes && bridge.pushDevices.length > 0) {
      for (const dev of bridge.pushDevices) {
        await httpJson('http://localhost:4318/api/push-register', {
          method: 'POST',
          body: JSON.stringify(dev),
          timeoutMs: 2000
        }).catch(() => {});
      }
    }
    if (syncRes && bridge.personalLedger) {
      await httpJson('http://localhost:4318/api/personal-ledger', {
        method: 'POST',
        body: JSON.stringify({ personalLedger: bridge.personalLedger }),
        timeoutMs: 2500
      }).catch(() => {});
    }
    if (once) {
      console.log('[OK] Cloud Relay synced:', JSON.stringify(syncRes));
    } else if (!syncRes) {
      if (bridge.lastCloudError && bridge.lastCloudError !== lastErr) {
        lastErr = bridge.lastCloudError;
        log(`[WARN] keepalive sync (${reason}) failed: ${lastErr}`);
      }
    } else if (reason !== lastReason) {
      lastErr = '';
      log(`[INFO] keepalive syncing (${reason})`);
      lastReason = reason;
    }
  }

  let prepatchTickCount = 0;
  function maybePrepatchExtensions() {
    try {
      const res = prepatchInstalledExtensions(REPO_ROOT);
      if (Array.isArray(res?.updatedDirs) && res.updatedDirs.length > 0) {
        log(
          `[INFO] pre-patched updated extension(s): ${res.updatedDirs.map((d) => path.basename(d)).join(', ')}`
        );
      }
      if (Array.isArray(res?.errors) && res.errors.length > 0) {
        for (const err of res.errors) {
          log(`[WARN] pre-patch failed for ${path.basename(err.extensionDir)}: ${err.error}`);
        }
      }
    } catch {}
  }

  let lastBlindspotCheckAt = 0;
  let lastBlindspotSpawnAt = 0;
  let blindspotChildInFlight = false;
  let blindspotChildStartedAt = 0;
  let cloudMemSyncInFlight = false;
  let cloudMemSyncStartedAt = 0;
  let cutoverSetupChildInFlight = false;
  let cutoverSetupStartedAt = 0;
  let lastCutoverSetupAttemptAt = 0;
  const cloudDeletionSeenMap = new Map();
  isBackgroundChildBusy = () =>
    (blindspotChildInFlight && Date.now() - blindspotChildStartedAt < 40 * 60 * 1000) ||
    (cloudMemSyncInFlight && Date.now() - cloudMemSyncStartedAt < 90 * 1000) ||
    (cutoverSetupChildInFlight && Date.now() - cutoverSetupStartedAt < 5 * 60 * 1000) ||
    memoryGitIdleSync.isInFlight();

  function maybeMigratePostBootstrapSetup(syncRes) {
    if (once || process.env.THEO_SMOKE_TEST === '1') return;
    const nowMs = Date.now();
    if (cutoverSetupChildInFlight && nowMs - cutoverSetupStartedAt < 5 * 60 * 1000) return;
    if (nowMs - lastCutoverSetupAttemptAt < 10 * 60 * 1000 && syncRes?.mode !== 'bootstrap') return;

    const homeDir = os.homedir();
    const bhfMem = path.join(homeDir, 'bhfirms', 'memory');
    const setupPy = path.join(bhfMem, 'Admin', 'theo-pc-setup.py');
    if (!fs.existsSync(path.join(bhfMem, 'THEO.md')) || !fs.existsSync(setupPy)) return;

    let needsMigrate = Boolean(syncRes && syncRes.mode === 'bootstrap');
    if (!needsMigrate) {
      try {
        const claudePtr = path.join(homeDir, '.claude', 'CLAUDE.md');
        const guardHook = path.join(homeDir, '.claude', 'hooks', 'bhfirms-memory-guard.py');
        const shortcutStamp = path.join(homeDir, '.theo', 'pc-setup-shortcut.json');
        if (!fs.existsSync(claudePtr) || /onedrive/i.test(fs.readFileSync(claudePtr, 'utf8'))) {
          needsMigrate = true;
        } else if (!fs.existsSync(guardHook) || !fs.readFileSync(guardHook, 'utf8').includes('bhfirms')) {
          needsMigrate = true;
        } else if (
          process.platform === 'win32' &&
          (!fs.existsSync(shortcutStamp) || /onedrive/i.test(fs.readFileSync(shortcutStamp, 'utf8')))
        ) {
          needsMigrate = true;
        }
      } catch {
        needsMigrate = true;
      }
    }
    if (!needsMigrate) return;

    const pyExe = findLocalPythonExe();
    if (!pyExe) return;
    try {
      lastCutoverSetupAttemptAt = nowMs;
      cutoverSetupChildInFlight = true;
      cutoverSetupStartedAt = nowMs;
      const child = spawn(
        pyExe,
        [
          setupPy,
          '--apply',
          '--only',
          'antigravity-config,claude-guard,claude-project-memory,git-identity,memory-git,blindspot-review,pc-setup-shortcut'
        ],
        {
          detached: /pythonw\.exe$/i.test(pyExe),
          windowsHide: true,
          stdio: 'ignore'
        }
      );
      const clearSetup = () => {
        cutoverSetupChildInFlight = false;
      };
      child.on('exit', clearSetup);
      child.on('error', clearSetup);
      child.unref();
      log('[INFO] triggered post-cutover PC setup migration');
    } catch {
      cutoverSetupChildInFlight = false;
    }
  }

  function maybeSyncMemoryCloudVault() {
    if (
      once ||
      process.env.THEO_SMOKE_TEST === '1' ||
      process.env.THEO_DISABLE_MEMORY_CLOUD_SYNC === '1'
    ) {
      return;
    }
    const nowMs = Date.now();
    if (cloudMemSyncInFlight && nowMs - cloudMemSyncStartedAt < 90 * 1000) return;
    let cloudSyncMod = null;
    try {
      cloudSyncMod = require('./memory_cloud_sync.cjs');
    } catch {
      return;
    }
    if (!cloudSyncMod || typeof cloudSyncMod.runCloudSync !== 'function') return;
    let syncMode = 'pull-if-changed';
    try {
      if (typeof cloudSyncMod.detectLocalVaultDrift === 'function') {
        const drift = cloudSyncMod.detectLocalVaultDrift({
          quietMs: 90 * 1000,
          nowMs,
          deletionSeenMap: cloudDeletionSeenMap
        });
        if (drift && drift.settled) {
          syncMode = 'sync';
        }
      }
    } catch {}
    cloudMemSyncInFlight = true;
    cloudMemSyncStartedAt = nowMs;
    Promise.resolve()
      .then(() => cloudSyncMod.runCloudSync({ mode: syncMode }))
      .then((res) => {
        if (res && res.ok) {
          if (
            !res.unchanged &&
            (res.pulledCount > 0 || res.pushedCount > 0 || res.deletedLocalCount > 0 || res.deletedCloudCount > 0)
          ) {
            log(
              `[INFO] memory cloud vault synced (rev ${res.rev}, mode=${res.mode || syncMode}): pulled=${res.pulledCount}, pushed=${res.pushedCount}`
            );
          }
          maybeMigratePostBootstrapSetup(res);
        }
      })
      .catch(() => {})
      .finally(() => {
        cloudMemSyncInFlight = false;
      });
  }

  function currentIsoWeekLocal(nowDate = new Date()) {
    const d = new Date(Date.UTC(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate()));
    const isoDay = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - isoDay);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
    return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
  }

  function maybeTriggerWeeklyBlindspotReview() {
    if (once || process.platform !== 'win32') return;
    // Wait until initial keepalive ticks have synced `bridge.cloudControlDocs` from THEO Store.
    if (prepatchTickCount < 6) return;
    const nowMs = Date.now();
    if (blindspotChildInFlight && nowMs - blindspotChildStartedAt < 40 * 60 * 1000) return;
    blindspotChildInFlight = false;
    if (nowMs - lastBlindspotCheckAt < 30 * 60 * 1000) return;
    lastBlindspotCheckAt = nowMs;
    if (nowMs - lastBlindspotSpawnAt < 2 * 60 * 60 * 1000) return;

    const nowDate = new Date(nowMs);
    if (nowDate.getDay() === 1 && nowDate.getHours() < 8) return;

    const curWeek = currentIsoWeekLocal(nowDate);
    const homeDir = os.homedir();
    const stateFile = path.join(homeDir, '.theo', 'blindspot-review-state.json');
    let localState = {};
    try {
      if (fs.existsSync(stateFile)) {
        localState = JSON.parse(fs.readFileSync(stateFile, 'utf8')) || {};
      }
    } catch {}

    const hasPendingWork = Boolean(localState.pending || localState.gitPending);
    if (!hasPendingWork && localState.lastWeek === curWeek) return;
    const cloudLastWeek = String(bridge.cloudControlDocs?.blindspot_review?.lastWeek || '');
    if (!hasPendingWork && cloudLastWeek && cloudLastWeek >= curWeek) return;

    const memPaths = resolveTheoMemoryPaths({ homeDir });
    const reviewRoot =
      memPaths.memoryRoot ||
      path.join(homeDir, 'bhfirms', 'memory');
    const reviewScript = path.join(reviewRoot, 'Admin', 'theo-blindspot-review.py');
    if (!fs.existsSync(reviewScript)) return;
    const pyExe = findLocalPythonExe();
    if (!pyExe) return;

    try {
      lastBlindspotSpawnAt = nowMs;
      blindspotChildInFlight = true;
      blindspotChildStartedAt = nowMs;
      const child = spawn(pyExe, [reviewScript], {
        detached: /pythonw\.exe$/i.test(pyExe),
        windowsHide: true,
        stdio: 'ignore'
      });
      const clearInFlight = () => {
        blindspotChildInFlight = false;
      };
      child.on('exit', clearInFlight);
      child.on('error', clearInFlight);
      child.unref();
      log(`[INFO] triggered weekly blind-spot review check (${curWeek})`);
    } catch {
      blindspotChildInFlight = false;
    }
  }

  async function tick() {
    if (tickInFlight || respawnTriggered) return;
    tickInFlight = true;
    try {
      prepatchTickCount += 1;
      if (prepatchTickCount === 1 || prepatchTickCount % 3 === 0) {
        maybePrepatchExtensions();
      }
      if (!once && (prepatchTickCount === 2 || prepatchTickCount % 12 === 0)) {
        checkPcSetupStatus().catch(() => {});
      }
      if (!once && (prepatchTickCount === 3 || prepatchTickCount % 12 === 3)) {
        maybeSyncMemoryCloudVault();
      }
      maybeTriggerWeeklyBlindspotReview();
      if (!once) {
        memoryGitIdleSync.maybeTick();
        try {
          if (fs.existsSync(PID_FILE)) {
            const ownerPid = Number(String(fs.readFileSync(PID_FILE, 'utf8')).trim() || 0);
            if (ownerPid && ownerPid !== process.pid && isPidAlive(ownerPid)) {
              process.exit(0);
              return;
            }
          }
        } catch {}
        const childStillRunning = isBackgroundChildBusy();
        if (
          !childStillRunning &&
          (pendingSelfUpdateInfo || computeDiskMaxMtime() > bootMtime + 2000)
        ) {
          const deferredInfo = pendingSelfUpdateInfo;
          pendingSelfUpdateInfo = null;
          respawnSelfAndExit(deferredInfo);
          return;
        }
      }

      if (once) {
        await runSync('once');
        return;
      }

      if (bridge.listening) {
        observeStatusForMemoryGit(bridge.getStatus(), Date.now());
        await runSync('standalone-host');
        return;
      }

      const ping = await httpJson('http://localhost:4318/api/ping', { timeoutMs: 2500 }).catch(
        () => ({})
      );
      const hostUp = Boolean(ping && ping.ok && ping.version >= 2 && !ping.standaloneMode);

      if (!hostUp) {
        if (staleHost) log('[INFO] host bridge closed; keepalive running standalone');
        staleHost = false;
        pauseUntil = 0;
        if (Date.now() > yieldCooldownUntil && !bridge.server) {
          bridge.disposed = false;
          bridge.startHttpServer();
          log('[INFO] Standalone theo-agent bound :4318 + Edge Relay (VS Code closed)');
        }
        await runSync('host-down');
        return;
      }

      const now = Date.now();
      observeStatusForMemoryGit(ping, now);
      const diskRemoteMtime = getFileMtimeMs(path.join(REPO_ROOT, 'remote.js'));
      const hostCodeMtime = Number(ping.codeMtime || 0);
      const hostCodeFresh = hostCodeMtime > 0 && hostCodeMtime >= diskRemoteMtime - 2000;
      const hostPushReady =
        bridge.pushDevices.length === 0 || Number(ping.pushDeviceCount || 0) > 0;
      const inProcAge = now - Number(ping.lastCloudSyncAt || 0);
      const attemptAge = now - Number(ping.lastCloudAttemptAt || 0);
      const hostSyncActive =
        inProcAge < 45000 || (Boolean(ping.cloudSyncInFlight) && attemptAge < 35000);

      // Fast path: Extension Host has current code, has push devices, and is actively syncing -> zero interference
      if (hostCodeFresh && hostPushReady && hostSyncActive) {
        if (staleHost) {
          staleHost = false;
          pauseUntil = 0;
          lastReason = '';
          log('[INFO] host is now up-to-date and syncing -> keepalive back to idle watch');
        }
        return;
      }

      // Host has current code, but its sync timer hasn't completed in >= 45s -> ask host to sync first
      if (hostCodeFresh && hostPushReady && !hostSyncActive) {
        const nudge = await httpJson('http://localhost:4318/api/cloud-sync', {
          method: 'POST',
          timeoutMs: 18000
        }).catch(() => null);
        if (nudge && nudge.ok) {
          lastReason = '';
          return;
        }
        await runSync('host-lagging');
        return;
      }

      // Host is running older code (pre-hot-swap window) or missing push devices -> keepalive handles push & state sync
      if (!staleHost) {
        staleHost = true;
        log(
          `[WARN] host codeMtime (${hostCodeMtime}) < disk (${diskRemoteMtime}) or pushDeviceCount=${ping.pushDeviceCount || 0} -> keepalive taking over state & push sync`
        );
      }
      await runSync('stale-host');
    } catch (err) {
      if (once) {
        console.error('[ERR]', err.message);
      } else {
        log(`[ERR] ${err.message}`);
      }
    } finally {
      tickInFlight = false;
    }
  }

  log(`[INFO] keepalive daemon started (pid ${process.pid}, bootMtime ${bootMtime})`);
  await tick();
  if (!once) {
    setInterval(tick, 5000);
  }
}

const isDirectEntry =
  require.main === module ||
  Boolean(require.main && path.basename(require.main.filename || '') === 'theo_agent.cjs');
if (isDirectEntry && process.env.THEO_SMOKE_TEST !== '1') {
  main();
}

module.exports = {
  MEMORY_GIT_IDLE_QUIET_MS,
  isIgnoredMemoryGitEntry,
  resolveTheoMemoryPaths,
  scanTrackedMemoryTree,
  readMemoryGitRefs,
  findLocalPythonExe,
  findLocalConsolePythonExe,
  createMemoryGitIdleSyncController
};
