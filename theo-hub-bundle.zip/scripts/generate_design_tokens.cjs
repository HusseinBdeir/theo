'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const BEGIN_MARKER = '/* BEGIN GENERATED DESIGN TOKENS (source: theo-hub/tokens.json; do not edit by hand) */';
const END_MARKER = '/* END GENERATED DESIGN TOKENS */';
const HASH_PREFIX = '/* @tokens-sha256: ';
const HASH_SUFFIX = ' */';
const THEO_BODY_ANCHOR = '\n*, *::before, *::after {';
const HUB_BODY_ANCHOR = '\n* { box-sizing: border-box; }';
const HUB_ROOT_ANCHOR = ':root {\n';

const CSS_PROP_NAME_RE = /^--[a-z0-9-]+$/;
const VSCODE_VAR_NAME_RE = /^--vscode-[a-zA-Z0-9-]+$/;
const UNSAFE_CSS_VALUE_RE = /[\r\n\0;{}]|\/\*|\*\//;
const HEX6_RE = /^#([0-9a-fA-F]{6})$/;

function isPlainObject(v) {
  return Boolean(v) && typeof v === 'object' && !Array.isArray(v);
}

function assertSafeValue(val, context) {
  if (typeof val !== 'string' || !val.trim()) {
    throw new Error(`${context}: token value must be a non-empty string`);
  }
  if (UNSAFE_CSS_VALUE_RE.test(val)) {
    throw new Error(`${context}: token value contains forbidden CSS syntax or control characters`);
  }
  return val;
}

function assertSafeComment(comment, context, required = false) {
  if (!comment) {
    if (required) throw new Error(`${context}: comment must be a non-empty /* ... */ block`);
    return;
  }
  if (typeof comment !== 'string') throw new Error(`${context}: comment must be a string`);
  const trimmed = comment.trim();
  if (!trimmed.startsWith('/*') || !trimmed.endsWith('*/')) {
    throw new Error(`${context}: comment must be wrapped in /* ... */`);
  }
  const inner = trimmed.slice(2, -2);
  if (inner.includes('*/') || inner.includes('\0') || trimmed.includes(BEGIN_MARKER) || trimmed.includes(END_MARKER)) {
    throw new Error(`${context}: comment contains unsafe */ or marker text`);
  }
}

function assertSafeSelectorList(selectors, context) {
  if (!Array.isArray(selectors) || selectors.length === 0) {
    throw new Error(`${context}: selectors must be a non-empty array`);
  }
  for (const sel of selectors) {
    assertSafeValue(sel, `${context}.selector`);
  }
}

function getByPath(rootObj, refPath) {
  if (typeof refPath !== 'string' || !refPath.trim()) return undefined;
  const parts = refPath.split('.');
  let cur = rootObj;
  for (const part of parts) {
    if (!isPlainObject(cur) || !Object.prototype.hasOwnProperty.call(cur, part)) {
      return undefined;
    }
    cur = cur[part];
  }
  return cur;
}

function formatHexValue(raw, fmt, context) {
  if (!fmt || fmt === 'raw') return raw;
  if (fmt === 'lower') return raw.toLowerCase();
  if (fmt === 'shortLower') {
    const m = raw.match(HEX6_RE);
    if (!m) {
      throw new Error(`${context}: format "shortLower" requires a 6-digit hex colour, got "${raw}"`);
    }
    const h = m[1].toLowerCase();
    if (h[0] !== h[1] || h[2] !== h[3] || h[4] !== h[5]) {
      throw new Error(`${context}: "${raw}" cannot shorten losslessly to 3-digit hex`);
    }
    return `#${h[0]}${h[2]}${h[4]}`;
  }
  throw new Error(`${context}: unknown format "${fmt}"`);
}

function resolveValueExpr(expr, rootTokens, ladderSet, context, stack = new Set()) {
  if (typeof expr === 'string') {
    return assertSafeValue(expr, context);
  }
  if (!isPlainObject(expr)) {
    throw new Error(`${context}: expected string, $ref, $mix, or vscode descriptor`);
  }
  if (Object.prototype.hasOwnProperty.call(expr, '$ref')) {
    const refPath = expr.$ref;
    if (typeof refPath !== 'string' || !refPath.startsWith('shared.')) {
      throw new Error(`${context}: $ref must target shared.<key>, got "${refPath}"`);
    }
    if (stack.has(refPath)) {
      throw new Error(`${context}: circular $ref detected (${[...stack, refPath].join(' -> ')})`);
    }
    const target = getByPath(rootTokens, refPath);
    if (target === undefined) {
      throw new Error(`${context}: dangling $ref "${refPath}"`);
    }
    const nextStack = new Set(stack);
    nextStack.add(refPath);
    const resolved = resolveValueExpr(target, rootTokens, ladderSet, `${context} -> ${refPath}`, nextStack);
    return assertSafeValue(formatHexValue(resolved, expr.format, context), context);
  }
  if (Object.prototype.hasOwnProperty.call(expr, '$mix')) {
    const mix = expr.$mix;
    if (!isPlainObject(mix) || typeof mix.token !== 'string' || !CSS_PROP_NAME_RE.test(mix.token)) {
      throw new Error(`${context}: $mix requires { token: "--name", step: <number> }`);
    }
    const step = Number(mix.step);
    if (!Number.isFinite(step) || !ladderSet.has(step)) {
      throw new Error(`${context}: $mix step ${mix.step} is not in mixLadder [${[...ladderSet].join(', ')}]`);
    }
    return `color-mix(in srgb, var(${mix.token}) ${step}%, transparent)`;
  }
  if (Object.prototype.hasOwnProperty.call(expr, 'vscode')) {
    if (!Array.isArray(expr.vscode) || expr.vscode.length === 0) {
      throw new Error(`${context}: vscode must be a non-empty array of --vscode-* names`);
    }
    for (const v of expr.vscode) {
      if (typeof v !== 'string' || !VSCODE_VAR_NAME_RE.test(v)) {
        throw new Error(`${context}: invalid vscode variable name "${v}"`);
      }
    }
    const fallback = resolveValueExpr(expr.fallback, rootTokens, ladderSet, `${context}.fallback`, stack);
    return expr.vscode.reduceRight((acc, vName) => `var(${vName}, ${acc})`, fallback);
  }
  throw new Error(`${context}: unsupported token expression keys [${Object.keys(expr).join(', ')}]`);
}

function validateTokens(tokens) {
  if (!isPlainObject(tokens) || tokens.schemaVersion !== 1) {
    throw new Error('tokens.json must be an object with schemaVersion === 1');
  }
  if (!isPlainObject(tokens.shared)) {
    throw new Error('tokens.json missing shared object');
  }
  if (!isPlainObject(tokens.theo) || !Array.isArray(tokens.theo.palettes) || !isPlainObject(tokens.theo.scales)) {
    throw new Error('tokens.json missing theo.palettes or theo.scales');
  }
  if (!isPlainObject(tokens.hub) || !isPlainObject(tokens.hub.root)) {
    throw new Error('tokens.json missing hub.root');
  }
  const scales = tokens.theo.scales;
  if (!Array.isArray(scales.mixLadder) || scales.mixLadder.length === 0) {
    throw new Error('tokens.json theo.scales.mixLadder must be a non-empty array');
  }
  const ladderSet = new Set(scales.mixLadder.map((n) => {
    const num = Number(n);
    if (!Number.isFinite(num) || num <= 0 || num >= 100) {
      throw new Error(`tokens.json invalid mixLadder entry: ${n}`);
    }
    return num;
  }));

  for (const [key, val] of Object.entries(tokens.shared)) {
    resolveValueExpr(val, tokens, ladderSet, `shared.${key}`);
  }

  for (const pal of tokens.theo.palettes) {
    if (!isPlainObject(pal) || !isPlainObject(pal.tokens)) {
      throw new Error(`tokens.json invalid palette entry: ${JSON.stringify(pal && pal.id)}`);
    }
    assertSafeSelectorList(pal.selectors, `theo.palettes.${pal.id}`);
    assertSafeComment(pal.comment, `theo.palettes.${pal.id}`, false);
    for (const [prop, val] of Object.entries(pal.tokens)) {
      if (!CSS_PROP_NAME_RE.test(prop)) {
        throw new Error(`tokens.json invalid CSS custom property name "${prop}" in palette "${pal.id}"`);
      }
      resolveValueExpr(val, tokens, ladderSet, `theo.palettes.${pal.id}.${prop}`);
    }
  }

  assertSafeComment(scales.comment, 'theo.scales', true);
  for (const groupName of ['fonts', 'fontSizes', 'radii', 'rootTokens']) {
    const grp = scales[groupName];
    if (!isPlainObject(grp)) {
      throw new Error(`tokens.json theo.scales.${groupName} must be an object`);
    }
    for (const [prop, val] of Object.entries(grp)) {
      if (!CSS_PROP_NAME_RE.test(prop)) {
        throw new Error(`tokens.json invalid CSS custom property name "${prop}" in scales.${groupName}`);
      }
      resolveValueExpr(val, tokens, ladderSet, `theo.scales.${groupName}.${prop}`);
    }
  }

  if (!Array.isArray(scales.themeTokens)) {
    throw new Error('tokens.json theo.scales.themeTokens must be an array');
  }
  for (const blk of scales.themeTokens) {
    if (!isPlainObject(blk) || !isPlainObject(blk.tokens)) {
      throw new Error('tokens.json invalid theo.scales.themeTokens entry');
    }
    assertSafeSelectorList(blk.selectors, 'theo.scales.themeTokens');
    for (const [prop, val] of Object.entries(blk.tokens)) {
      if (!CSS_PROP_NAME_RE.test(prop)) {
        throw new Error(`tokens.json invalid CSS custom property name "${prop}" in scales.themeTokens`);
      }
      resolveValueExpr(val, tokens, ladderSet, `theo.scales.themeTokens.${prop}`);
    }
  }

  assertSafeValue(tokens.hub.colorScheme, 'hub.colorScheme');
  for (const [prop, val] of Object.entries(tokens.hub.root)) {
    if (!CSS_PROP_NAME_RE.test(prop)) {
      throw new Error(`tokens.json invalid CSS custom property name "${prop}" in hub.root`);
    }
    resolveValueExpr(val, tokens, ladderSet, `hub.root.${prop}`);
  }
  for (const ov of Array.isArray(tokens.hub.overrides) ? tokens.hub.overrides : []) {
    if (!isPlainObject(ov) || typeof ov.selector !== 'string' || !ov.selector.trim() || !isPlainObject(ov.tokens)) {
      throw new Error('tokens.json invalid hub.overrides entry');
    }
    if (UNSAFE_CSS_VALUE_RE.test(ov.selector)) {
      throw new Error('tokens.json hub.overrides selector contains forbidden characters');
    }
    for (const [prop, val] of Object.entries(ov.tokens)) {
      if (!CSS_PROP_NAME_RE.test(prop)) {
        throw new Error(`tokens.json invalid CSS custom property name "${prop}" in hub.overrides`);
      }
      resolveValueExpr(val, tokens, ladderSet, `hub.overrides.${prop}`);
    }
  }
  return ladderSet;
}

function loadTokens(hubRoot) {
  const tokensPath = path.join(hubRoot, 'tokens.json');
  const raw = fs.readFileSync(tokensPath, 'utf8');
  const parsed = JSON.parse(raw);
  validateTokens(parsed);
  return parsed;
}

function computeBlockSha256(innerBody) {
  const lf = String(innerBody).replace(/\r\n/g, '\n');
  return crypto.createHash('sha256').update(lf, 'utf8').digest('hex');
}

function wrapGeneratedBlock(innerBody) {
  const lfBody = String(innerBody).replace(/\r\n/g, '\n');
  const sha = computeBlockSha256(lfBody);
  return `${BEGIN_MARKER}\n${lfBody}\n${HASH_PREFIX}${sha}${HASH_SUFFIX}\n${END_MARKER}`;
}

function verifyGeneratedBlockIntegrity(cssText, fileLabel = 'CSS') {
  const lf = String(cssText).replace(/\r\n/g, '\n');
  const beginCount = lf.split(BEGIN_MARKER).length - 1;
  const endCount = lf.split(END_MARKER).length - 1;
  if (beginCount !== 1 || endCount !== 1) {
    return {
      ok: false,
      reason: `${fileLabel}: expected exactly 1 BEGIN/END GENERATED marker pair (found begin=${beginCount}, end=${endCount})`
    };
  }
  const beginAt = lf.indexOf(BEGIN_MARKER);
  const endAt = lf.indexOf(END_MARKER);
  if (endAt <= beginAt) {
    return { ok: false, reason: `${fileLabel}: END GENERATED marker appears before BEGIN GENERATED marker` };
  }
  const block = lf.slice(beginAt, endAt + END_MARKER.length);
  const afterBegin = beginAt + BEGIN_MARKER.length;
  if (lf[afterBegin] !== '\n') {
    return { ok: false, reason: `${fileLabel}: expected newline immediately after BEGIN GENERATED marker` };
  }
  const contentWithHash = lf.slice(afterBegin + 1, endAt);
  if (!contentWithHash.endsWith('\n')) {
    return { ok: false, reason: `${fileLabel}: expected newline before END GENERATED marker` };
  }
  const withoutTrailingNl = contentWithHash.slice(0, -1);
  const lastNl = withoutTrailingNl.lastIndexOf('\n');
  if (lastNl < 0) {
    return { ok: false, reason: `${fileLabel}: missing @tokens-sha256 integrity line inside generated block` };
  }
  const innerBody = withoutTrailingNl.slice(0, lastNl);
  const hashLine = withoutTrailingNl.slice(lastNl + 1);
  const m = hashLine.match(/^\/\* @tokens-sha256: ([0-9a-f]{64}) \*\/$/);
  if (!m) {
    return { ok: false, reason: `${fileLabel}: missing or malformed @tokens-sha256 stamp ("${hashLine}")` };
  }
  const actualSha = computeBlockSha256(innerBody);
  if (m[1] !== actualSha) {
    return {
      ok: false,
      reason: `${fileLabel}: generated token block was edited by hand (expected @tokens-sha256 ${actualSha}, got ${m[1]})`
    };
  }
  return { ok: true, beginAt, endAt: endAt + END_MARKER.length, block, innerBody, sha256: actualSha };
}

function renderSelectorHeader(selectors, multilineSelector) {
  return multilineSelector && selectors.length > 1 ? selectors.join(',\n') : selectors.join(', ');
}

function renderDeclBlock(selectors, multilineSelector, entries) {
  const lines = [`${renderSelectorHeader(selectors, multilineSelector)} {`];
  for (const [prop, val] of entries) {
    lines.push(`  ${prop}: ${val};`);
  }
  lines.push('}');
  return lines.join('\n');
}

function renderTheoHeaderBlock(tokens) {
  const ladderSet = validateTokens(tokens);
  const chunks = [];
  for (const pal of tokens.theo.palettes) {
    const decls = Object.entries(pal.tokens).map(([prop, expr]) => [
      prop,
      resolveValueExpr(expr, tokens, ladderSet, `theo.palettes.${pal.id}.${prop}`)
    ]);
    const block = renderDeclBlock(pal.selectors, pal.multilineSelector, decls);
    chunks.push(pal.comment ? `${pal.comment}\n${block}` : block);
  }

  const scales = tokens.theo.scales;
  const scaleEntries = [];
  for (const grpName of ['fonts', 'fontSizes', 'radii', 'rootTokens']) {
    for (const [prop, expr] of Object.entries(scales[grpName])) {
      scaleEntries.push([
        prop,
        resolveValueExpr(expr, tokens, ladderSet, `theo.scales.${grpName}.${prop}`)
      ]);
    }
  }
  const scaleChunks = [
    '/* @scales:start */',
    `${scales.comment}\n${renderDeclBlock([':root'], false, scaleEntries)}`
  ];
  for (const blk of scales.themeTokens) {
    const decls = Object.entries(blk.tokens).map(([prop, expr]) => [
      prop,
      resolveValueExpr(expr, tokens, ladderSet, `theo.scales.themeTokens.${prop}`)
    ]);
    scaleChunks.push(renderDeclBlock(blk.selectors, blk.multilineSelector, decls));
  }
  scaleChunks.push('/* @scales:end */');

  chunks.push(scaleChunks.join('\n\n').replace('/* @scales:start */\n\n', '/* @scales:start */\n').replace('\n\n/* @scales:end */', '\n/* @scales:end */'));
  return wrapGeneratedBlock(chunks.join('\n\n'));
}

function renderHubHeaderBlock(tokens) {
  const ladderSet = validateTokens(tokens);
  const rootLines = [':root {', `  color-scheme: ${tokens.hub.colorScheme};`];
  for (const [prop, expr] of Object.entries(tokens.hub.root)) {
    const val = resolveValueExpr(expr, tokens, ladderSet, `hub.root.${prop}`);
    rootLines.push(`  ${prop}: ${val};`);
  }
  rootLines.push('}');

  const blocks = [rootLines.join('\n')];
  for (const ov of Array.isArray(tokens.hub.overrides) ? tokens.hub.overrides : []) {
    const decls = Object.entries(ov.tokens).map(([prop, expr]) => {
      const val = resolveValueExpr(expr, tokens, ladderSet, `hub.overrides.${prop}`);
      return `${prop}: ${val};`;
    });
    if (ov.inline) {
      blocks.push(`${ov.selector} { ${decls.join(' ')} }`);
    } else {
      blocks.push(`${ov.selector} {\n  ${decls.join('\n  ')}\n}`);
    }
  }
  return wrapGeneratedBlock(blocks.join('\n'));
}

function replaceGeneratedBlock(existingText, newBlock, opts = {}) {
  const lf = String(existingText).replace(/\r\n/g, '\n');
  const beginCount = lf.split(BEGIN_MARKER).length - 1;
  const endCount = lf.split(END_MARKER).length - 1;
  if (beginCount > 0 || endCount > 0) {
    if (beginCount !== 1 || endCount !== 1) {
      throw new Error(`${opts.label || 'CSS'}: malformed BEGIN/END GENERATED markers (begin=${beginCount}, end=${endCount})`);
    }
    const beginAt = lf.indexOf(BEGIN_MARKER);
    const endAt = lf.indexOf(END_MARKER);
    if (endAt <= beginAt) {
      throw new Error(`${opts.label || 'CSS'}: END GENERATED marker appears before BEGIN GENERATED marker`);
    }
    return lf.slice(0, beginAt) + newBlock + lf.slice(endAt + END_MARKER.length);
  }
  if (!opts.bootstrap) {
    throw new Error(`${opts.label || 'CSS'}: missing BEGIN/END GENERATED markers (run with --bootstrap first)`);
  }
  if (opts.target === 'theo') {
    const anchorAt = lf.indexOf(THEO_BODY_ANCHOR);
    if (anchorAt < 0) {
      throw new Error(`theo.css: cannot locate body anchor "${THEO_BODY_ANCHOR.trim()}" for --bootstrap`);
    }
    return newBlock + '\n' + lf.slice(anchorAt);
  }
  if (opts.target === 'hub') {
    const startAt = lf.indexOf(HUB_ROOT_ANCHOR);
    const bodyAt = lf.indexOf(HUB_BODY_ANCHOR);
    if (startAt < 0 || bodyAt <= startAt) {
      throw new Error('hub.css: cannot locate :root or body anchor for --bootstrap');
    }
    return lf.slice(0, startAt) + newBlock + lf.slice(bodyAt);
  }
  throw new Error(`Unknown target "${opts.target}"`);
}

function writeAtomicLf(filePath, content) {
  const lf = String(content).replace(/\r\n/g, '\n');
  if (fs.existsSync(filePath)) {
    const cur = fs.readFileSync(filePath, 'utf8');
    if (cur === lf) return false;
  }
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  try {
    fs.writeFileSync(tmp, lf, 'utf8');
    fs.renameSync(tmp, filePath);
    return true;
  } catch (err) {
    try {
      fs.unlinkSync(tmp);
    } catch {}
    throw err;
  }
}

function syncDesignTokens({ hubRoot, theoRoot = '', explicitTheo = false, bootstrap = false, check = false } = {}) {
  const absHub = path.resolve(hubRoot);
  const tokens = loadTokens(absHub);
  const hubCssPath = path.join(absHub, 'resources', 'hub.css');
  if (!fs.existsSync(hubCssPath)) {
    throw new Error(`Missing hub.css at ${hubCssPath}`);
  }

  let resolvedTheoRoot = theoRoot ? path.resolve(theoRoot) : path.resolve(absHub, '..', 'theo');
  const theoCssPath = path.join(resolvedTheoRoot, 'css', 'theo.css');
  const hasTheo = fs.existsSync(theoCssPath);
  if (explicitTheo && !hasTheo) {
    throw new Error(`Explicit --theo-root missing css/theo.css: ${theoCssPath}`);
  }

  const results = [];
  const targets = [{ name: 'hub.css', target: 'hub', filePath: hubCssPath, block: renderHubHeaderBlock(tokens) }];
  if (hasTheo) {
    targets.push({ name: 'theo.css', target: 'theo', filePath: theoCssPath, block: renderTheoHeaderBlock(tokens) });
  }

  const outOfSync = [];
  const preparedWrites = [];
  for (const t of targets) {
    const curRaw = fs.readFileSync(t.filePath, 'utf8');
    if (check) {
      const integ = verifyGeneratedBlockIntegrity(curRaw, t.name);
      if (!integ.ok) {
        outOfSync.push(integ.reason);
      } else if (integ.block !== t.block) {
        outOfSync.push(`${t.name}: generated token block differs from ${path.join(absHub, 'tokens.json')}`);
      }
      results.push({ name: t.name, filePath: t.filePath, changed: false });
      continue;
    }
    // Prepare every target before writing so a marker/validation error never half-updates a file.
    const next = replaceGeneratedBlock(curRaw, t.block, { bootstrap, target: t.target, label: t.name });
    preparedWrites.push({ name: t.name, filePath: t.filePath, next });
  }

  if (check && outOfSync.length > 0) {
    const err = new Error(outOfSync.join('; '));
    err.outOfSync = outOfSync;
    throw err;
  }

  if (!check) {
    for (const pw of preparedWrites) {
      const changed = writeAtomicLf(pw.filePath, pw.next);
      results.push({ name: pw.name, filePath: pw.filePath, changed });
    }
  }

  return { hubRoot: absHub, theoRoot: hasTheo ? resolvedTheoRoot : null, results };
}

function parseCliArgs(argv) {
  const args = argv.slice(2);
  const getFlagVal = (flag) => {
    const idx = args.indexOf(flag);
    return idx >= 0 && idx + 1 < args.length ? args[idx + 1] : '';
  };
  const hubRoot = getFlagVal('--hub-root') || path.resolve(__dirname, '..');
  const explicitTheoRoot = getFlagVal('--theo-root');
  return {
    hubRoot,
    theoRoot: explicitTheoRoot,
    explicitTheo: Boolean(explicitTheoRoot),
    bootstrap: args.includes('--bootstrap'),
    check: args.includes('--check')
  };
}

if (require.main === module) {
  try {
    const opts = parseCliArgs(process.argv);
    const res = syncDesignTokens(opts);
    const summary = res.results
      .map((r) => `${r.name}(${opts.check ? 'ok' : r.changed ? `updated -> ${r.filePath}` : 'unchanged'})`)
      .join(', ');
    console.log(`[${opts.check ? 'PASS' : 'OK'}] Design tokens: ${summary}`);
  } catch (err) {
    console.error(`[FAIL] ${err && err.message ? err.message : err}`);
    process.exit(1);
  }
}

module.exports = {
  BEGIN_MARKER,
  END_MARKER,
  HASH_PREFIX,
  HASH_SUFFIX,
  THEO_BODY_ANCHOR,
  HUB_BODY_ANCHOR,
  HUB_ROOT_ANCHOR,
  loadTokens,
  validateTokens,
  computeBlockSha256,
  wrapGeneratedBlock,
  verifyGeneratedBlockIntegrity,
  renderTheoHeaderBlock,
  renderHubHeaderBlock,
  replaceGeneratedBlock,
  syncDesignTokens
};
