param(
  [switch]$Restart,
  [switch]$SkipTaskCheck
)
$target = Join-Path $PSScriptRoot 'relay_keepalive_start.ps1'
& $target @PSBoundParameters
