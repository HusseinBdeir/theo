# Installs or updates the frameless THEO Desktop App & Start Menu shortcuts (THEO.lnk)
# with the multi-resolution THEO Ledger .ico (~/.theo/theo.ico) and global hotkey (Ctrl+Alt+T).
param(
  [string]$Hotkey = '',
  [switch]$NoHotkey,
  [string]$Url = '',
  [switch]$Force,
  [switch]$Launch,
  [switch]$Uninstall,
  [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$repo = Split-Path -Parent $PSScriptRoot
$launcherModule = Join-Path $repo 'desktop-launcher.js'

if (-not (Test-Path $launcherModule)) {
  throw "Missing desktop-launcher.js at $launcherModule"
}

$nodeCandidates = @(
  (Join-Path $env:USERPROFILE '.local\node\node.exe'),
  ((Get-Command node -ErrorAction SilentlyContinue).Source),
  'C:\Program Files\nodejs\node.exe',
  (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
)
$nodeExe = ''
$useElectronNode = $false
foreach ($cand in $nodeCandidates) {
  if ($cand -and (Test-Path $cand)) {
    $nodeExe = $cand
    break
  }
}

if (-not $nodeExe) {
  $vsCandidates = @(
    (Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\Code.exe'),
    'C:\Program Files\Microsoft VS Code\Code.exe'
  )
  foreach ($vc in $vsCandidates) {
    if (Test-Path $vc) {
      $nodeExe = $vc
      $useElectronNode = $true
      break
    }
  }
}

if (-not $nodeExe) {
  throw 'Could not locate Node.js or VS Code runtime to configure THEO Desktop shortcut.'
}

$hotkeyExplicitlySet = $PSBoundParameters.ContainsKey('Hotkey') -or $NoHotkey.IsPresent
$effectiveHotkey = if ($NoHotkey) { '' } else { $Hotkey }

$inlineNode = @'
const launcher = require(process.env.THEO_LAUNCHER_MOD);
const action = process.env.THEO_SHORTCUT_ACTION || 'install';
if (action === 'uninstall') {
  const out = launcher.uninstallDesktopShortcuts({});
  console.log(JSON.stringify(out));
  process.exit(0);
}
const opts = {
  customUrl: process.env.THEO_SHORTCUT_URL || '',
  force: process.env.THEO_SHORTCUT_FORCE === '1'
};
if (process.env.THEO_SHORTCUT_HOTKEY_SET === '1') {
  opts.hotkey = process.env.THEO_SHORTCUT_HOTKEY || '';
}
const out = launcher.installDesktopShortcuts(opts);
console.log(JSON.stringify(out));
'@

$env:THEO_LAUNCHER_MOD = $launcherModule
$env:THEO_SHORTCUT_ACTION = if ($Uninstall) { 'uninstall' } else { 'install' }
$env:THEO_SHORTCUT_URL = $Url
$env:THEO_SHORTCUT_HOTKEY_SET = if ($hotkeyExplicitlySet) { '1' } else { '0' }
$env:THEO_SHORTCUT_HOTKEY = $effectiveHotkey
$env:THEO_SHORTCUT_FORCE = if ($Force) { '1' } else { '0' }
if ($useElectronNode) { $env:ELECTRON_RUN_AS_NODE = '1' }

try {
  $rawOut = & $nodeExe -e $inlineNode
  if ($LASTEXITCODE -ne 0) {
    throw "desktop-launcher exited with code $LASTEXITCODE"
  }
} finally {
  Remove-Item Env:\THEO_LAUNCHER_MOD -ErrorAction SilentlyContinue
  Remove-Item Env:\THEO_SHORTCUT_ACTION -ErrorAction SilentlyContinue
  Remove-Item Env:\THEO_SHORTCUT_URL -ErrorAction SilentlyContinue
  Remove-Item Env:\THEO_SHORTCUT_HOTKEY_SET -ErrorAction SilentlyContinue
  Remove-Item Env:\THEO_SHORTCUT_HOTKEY -ErrorAction SilentlyContinue
  Remove-Item Env:\THEO_SHORTCUT_FORCE -ErrorAction SilentlyContinue
  if ($useElectronNode) {
    Remove-Item Env:\ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
  }
}

$res = ($rawOut | Select-Object -Last 1) | ConvertFrom-Json
if ($Uninstall) {
  if (-not $Quiet) {
    Write-Host "[OK] Removed THEO Desktop & Start Menu shortcuts ($($res.removedShortcuts.Count) removed)" -ForegroundColor Green
  }
  exit 0
}

if (-not $Quiet) {
  $statusTag = if ($res.skipped) { 'up-to-date' } else { 'installed' }
  $hkLabel = if ($res.hotkey) { " | Hotkey: $($res.hotkey)" } else { '' }
  Write-Host "[OK] THEO Desktop & Start Menu app shortcuts $statusTag -> $($res.url)$hkLabel" -ForegroundColor Green
}

if ($Launch) {
  $keepaliveStart = Join-Path $PSScriptRoot 'relay_keepalive_start.ps1'
  if (Test-Path $keepaliveStart) {
    & powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File $keepaliveStart -SkipTaskCheck | Out-Null
  }
  if ($res.arguments) {
    Start-Process -FilePath $res.targetPath -ArgumentList $res.arguments -WorkingDirectory $res.workingDirectory | Out-Null
  } else {
    Start-Process -FilePath $res.targetPath -WorkingDirectory $res.workingDirectory | Out-Null
  }
}
