#!/usr/bin/env node
"use strict";

/**
 * THEO Cloudflare Memory Vault — Zero-Dependency Two-Way Sync & AES-256-GCM E2EE Client.
 *
 * Syncs `<HOME>/bhfirms/memory` <-> `https://memory.husseinbdeir.workers.dev`
 *   - Derives `authToken` = SHA-256("theo-edge-v1:" + edgeAccessKey) (hex)
 *   - Derives `privKey`   = SHA-256("theo-memory-priv-v1:" + edgeAccessKey) (32-byte AES-256-GCM key, never sent to cloud)
 *   - Encrypts/decrypts `PRIVATE_STEMS` (`bank-kyc-ali-bdeir`, `user-passports-antigua-lebanon`) client-side
 *     using WebCrypto-compatible `ciphertext || authTag(16)` + `AAD = "theo-memory-e2ee-v1:<relPosix>"`
 *   - Performs 3-way reconciliation (`~/.theo/memory-cloud-sync-state.json`) with conflict archiving in `_archive/conflicts/`
 *   - Line-merges `isLineMergePath` files (idea backlog + grep-only logs) when both sides changed, against a per-PC
 *     base copy in `~/.theo/memory-cloud-base/`, instead of newest-wins
 *   - Supports `sync`, `pull`, `push`, `bootstrap`, `status`, and `--pull-if-changed` (fast `/api/head` check).
 */

const crypto = require("node:crypto");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const DEFAULT_CLOUD_URL = "https://memory.husseinbdeir.workers.dev";
const PRIVATE_STEMS = Object.freeze([
  "bank-kyc-ali-bdeir",
  "user-passports-antigua-lebanon",
]);
const PRIVATE_DIR_PREFIX = "private/";
const MIRROR_TARGETS = Object.freeze(["CLAUDE.md", "AGENTS.md"]);
const PROTECTED_DELETE_PATHS = new Set([
  "THEO.md",
  "CLAUDE.md",
  "AGENTS.md",
  "memory/MEMORY.md",
]);
const FORBIDDEN_DIRS = new Set([
  ".git",
  ".claude",
  ".vscode",
  ".wrangler",
  "node_modules",
  "_archive",
  "tmp",
  "scratchpad",
  "output",
  "__pycache__",
  "exports",
  "runs",
]);
const ALLOWED_DOTFILES = new Set([".gitignore", ".gitattributes"]);
const MAX_LINE_BYTES = 2500;
const MAX_GREP_LINE_BYTES = 4000;
const MAX_FILE_BYTES = 25 * 1024 * 1024;
const DUP_BLOCK_MIN_LINES = 3;
const SINGLE_FILE_THRESHOLD_BYTES = 512 * 1024;
const MAX_BATCH_BYTES = 3.5 * 1024 * 1024;
const MAX_BATCH_COUNT = 60;
const LOCK_STALE_MS = 10 * 60 * 1000;

function resolveHomeDir(explicitHome) {
  const h =
    explicitHome ||
    process.env.THEO_GUARD_HOME ||
    process.env.THEO_SETUP_HOME ||
    os.homedir();
  return path.resolve(h);
}

function loadCredentials(homeDir) {
  const credPath = path.join(homeDir, ".theo", "credentials.json");
  try {
    if (fs.existsSync(credPath)) {
      const parsed = JSON.parse(fs.readFileSync(credPath, "utf8"));
      if (parsed && typeof parsed === "object") return parsed;
    }
  } catch (_) {}
  return {};
}

function sha256Hex(bufOrStr) {
  return crypto.createHash("sha256").update(bufOrStr).digest("hex");
}

function sha256Buf(bufOrStr) {
  return crypto.createHash("sha256").update(bufOrStr).digest();
}

function deriveVaultKeys(edgeAccessKey) {
  const clean = String(edgeAccessKey || "").trim();
  if (!clean) {
    return { authToken: "", privKey: null };
  }
  return {
    authToken: sha256Hex("theo-edge-v1:" + clean),
    privKey: sha256Buf("theo-memory-priv-v1:" + clean),
  };
}

function resolveSyncConfig(overrides = {}) {
  const homeDir = resolveHomeDir(overrides.homeDir);
  const creds = loadCredentials(homeDir);
  const memoryRoot = path.resolve(
    overrides.memoryRoot ||
      process.env.THEO_MEMORY_ROOT ||
      path.join(homeDir, "bhfirms", "memory")
  );
  const explicitCloudUrl = String(
    overrides.cloudUrl ||
      process.env.THEO_MEMORY_CLOUD_URL ||
      creds.memoryCloudUrl ||
      ""
  ).trim();
  const isSandboxed = Boolean(
    process.env.THEO_GUARD_HOME ||
      process.env.THEO_SETUP_HOME ||
      (overrides.homeDir && path.resolve(overrides.homeDir) !== path.resolve(os.homedir()))
  );
  const cloudUrl = (explicitCloudUrl || DEFAULT_CLOUD_URL).replace(/\/+$/, "");

  const edgeAccessKey = String(
    overrides.edgeAccessKey ||
      process.env.THEO_EDGE_KEY ||
      creds.edgeAccessKey ||
      ""
  ).trim();

  const { authToken, privKey } = deriveVaultKeys(edgeAccessKey);
  const theoStateDir = path.join(homeDir, ".theo");
  const statePath = overrides.statePath || path.join(theoStateDir, "memory-cloud-sync-state.json");
  const lockPath = overrides.lockPath || path.join(theoStateDir, "memory-cloud-sync.lock");
  const hostLabel = String(overrides.hostLabel || os.hostname() || "pc").slice(0, 60);

  return {
    homeDir,
    memoryRoot,
    cloudUrl,
    edgeAccessKey,
    authToken: overrides.authToken || authToken,
    privKey: overrides.privKey || privKey,
    theoStateDir,
    statePath,
    lockPath,
    hostLabel,
    sandboxMissingCloudUrl: isSandboxed && !explicitCloudUrl,
  };
}

function isPrivateRelPath(relPosix) {
  const lower = String(relPosix || "").replace(/\\/g, "/").replace(/^\/+/, "").toLowerCase();
  return lower === "private" || lower.startsWith(PRIVATE_DIR_PREFIX) || PRIVATE_STEMS.some((stem) => lower.includes(stem));
}

function isEligibleRelPath(relPosix) {
  if (typeof relPosix !== "string" || !relPosix || relPosix.length > 260) return false;
  if (/[\x00-\x1f\x7f]/.test(relPosix)) return false;
  if (relPosix.startsWith("/") || relPosix.endsWith("/") || relPosix.includes("//") || relPosix.includes(":")) {
    return false;
  }
  const parts = relPosix.split("/");
  for (let i = 0; i < parts.length; i++) {
    const seg = parts[i];
    if (!seg || seg === "." || seg === "..") return false;
    if (seg.endsWith(" ") || seg.endsWith(".")) return false;
    if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i.test(seg)) return false;
    const lowerSeg = seg.toLowerCase();
    if (FORBIDDEN_DIRS.has(lowerSeg)) return false;
    if (seg.startsWith(".") && !(i === 0 && parts.length === 1 && ALLOWED_DOTFILES.has(seg))) {
      return false;
    }
    if (/\.bak/i.test(seg)) return false;
    if (seg === "console.log('status") return false;
  }
  const lower = relPosix.toLowerCase();
  if (lower === "moved.txt") return false;
  if (lower === "private") return false;
  if (
    lower.startsWith("admin/") &&
    (lower.endsWith(".csv") ||
      lower.endsWith(".log") ||
      /^admin\/claude-permission-mode-.*\.json$/i.test(lower))
  ) {
    return false;
  }
  if (
    /(^|\/)\.env(\.|$)/i.test(relPosix) ||
    /credentials.*\.json$/i.test(relPosix) ||
    /\.(pem|key|pfx|p12|zip)$/i.test(relPosix)
  ) {
    return false;
  }
  return true;
}

function maxLineCapBytes(relPosix) {
  const name = String(relPosix || "").split("/").pop();
  const lower = name.toLowerCase();
  if (name === "PropagationLedger.md" || lower.endsWith("reference.md") || lower.endsWith("doneledger.md")) {
    return MAX_GREP_LINE_BYTES;
  }
  return MAX_LINE_BYTES;
}

function hasSizeLineCaps(relPosix) {
  if (!relPosix.endsWith(".md")) return false;
  const parts = relPosix.split("/");
  const isRoot = parts.length === 1;
  const isMemoryNote = parts.length === 2 && parts[0] === "memory";
  if (!isRoot && !isMemoryNote) return false;
  const name = parts[parts.length - 1];
  return !MIRROR_TARGETS.includes(name) && name !== "HISTORY.md" && !name.includes("Archive");
}

function checkLocalMarkdownGuard(relPosix, buf) {
  if (!relPosix.endsWith(".md")) return { ok: true };
  const parts = relPosix.split("/");
  const name = parts[parts.length - 1];
  if (parts.length === 1 && MIRROR_TARGETS.includes(name)) return { ok: true };
  const capped = hasSizeLineCaps(relPosix);
  const merged = isLineMergePath(relPosix);
  if (!capped && !merged) return { ok: true };

  if (capped) {
    const lower = name.toLowerCase();
    let capKb = 80;
    if (relPosix === "THEO.md" || relPosix === "memory/MEMORY.md") capKb = 20;
    else if (name === "PropagationLedger.md") capKb = 150;
    else if (lower.endsWith("reference.md") || lower.endsWith("doneledger.md")) capKb = 500;

    if (buf.length > capKb * 1024) {
      return { ok: false, kind: "size", error: `${relPosix} exceeds ${capKb} KB cap (${buf.length} B)` };
    }
    const lineCap = maxLineCapBytes(relPosix);
    const lines = buf.toString("utf8").split("\n");
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].endsWith("\r") ? lines[i].slice(0, -1) : lines[i];
      const lb = Buffer.byteLength(line, "utf8");
      if (lb > lineCap) {
        return { ok: false, kind: "line", error: `${relPosix} line ${i + 1} exceeds ${lineCap} B (${lb} B)` };
      }
    }
  }

  if (merged) {
    const dups = findDuplicateBlocks(buf);
    if (dups.length > 0) {
      const spans = dups
        .slice(0, 5)
        .map((d) => `L${d.firstStart}-L${d.firstEnd} == L${d.dupStart}-L${d.dupEnd} (${d.count} lines)`)
        .join(", ");
      const extra = dups.length > 5 ? ` (+${dups.length - 5} more)` : "";
      return {
        ok: false,
        kind: "dup",
        dups,
        error: `${relPosix} has duplicate block(s) of ${DUP_BLOCK_MIN_LINES}+ consecutive non-blank lines (${spans}${extra})`,
      };
    }
  }
  return { ok: true };
}

function isBinaryDocPath(relPosix) {
  return /\.(pdf|docx?|xls[xmb]?|pptx?)$/i.test(String(relPosix || "").trim());
}

function checkLocalPushCandidate(relPosix, local) {
  if (local && local.oversized) {
    return {
      ok: false,
      kind: "size",
      error: `${relPosix} exceeds ${MAX_FILE_BYTES} B limit (${local.size} B)`,
    };
  }
  return checkLocalMarkdownGuard(relPosix, local ? local.buf : Buffer.alloc(0));
}

function encryptPrivateRaw(relPosix, plainBuf, privKey) {
  if (!Buffer.isBuffer(privKey) || privKey.length !== 32) {
    throw new Error("Missing 32-byte private E2EE key");
  }
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", privKey, iv);
  cipher.setAAD(Buffer.from("theo-memory-e2ee-v1:" + relPosix, "utf8"));
  const body = Buffer.concat([cipher.update(plainBuf), cipher.final()]);
  const tag = cipher.getAuthTag();
  const combined = Buffer.concat([body, tag]);
  return {
    encrypted: true,
    encAlg: "AES-256-GCM",
    encIv: iv.toString("hex"),
    plainSha256: sha256Hex(plainBuf),
    plainSize: plainBuf.length,
    ciphertextBuf: combined,
  };
}

function encryptPrivateBuffer(relPosix, plainBuf, privKey) {
  const res = encryptPrivateRaw(relPosix, plainBuf, privKey);
  return {
    encrypted: res.encrypted,
    encAlg: res.encAlg,
    encIv: res.encIv,
    plainSha256: res.plainSha256,
    plainSize: res.plainSize,
    ciphertextBase64: res.ciphertextBuf.toString("base64"),
  };
}

function decryptPrivateBuffer(relPosix, encIvHex, cipherInput, privKey) {
  if (!Buffer.isBuffer(privKey) || privKey.length !== 32) {
    throw new Error("Missing 32-byte private E2EE key");
  }
  const iv = Buffer.from(String(encIvHex || ""), "hex");
  if (iv.length !== 12) throw new Error(`Invalid IV length for ${relPosix}`);
  let combined;
  if (Buffer.isBuffer(cipherInput)) {
    combined = cipherInput;
  } else if (cipherInput instanceof Uint8Array) {
    combined = Buffer.from(cipherInput.buffer, cipherInput.byteOffset, cipherInput.byteLength);
  } else {
    combined = Buffer.from(String(cipherInput || ""), "base64");
  }
  if (combined.length < 16) throw new Error(`Ciphertext too short for ${relPosix}`);
  const body = combined.subarray(0, combined.length - 16);
  const tag = combined.subarray(combined.length - 16);
  const decipher = crypto.createDecipheriv("aes-256-gcm", privKey, iv);
  decipher.setAAD(Buffer.from("theo-memory-e2ee-v1:" + relPosix, "utf8"));
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(body), decipher.final()]);
}

function scanLocalTree(memoryRoot) {
  const map = new Map();
  if (!fs.existsSync(memoryRoot)) return map;

  function walk(curDir, relPrefix) {
    let entries;
    try {
      entries = fs.readdirSync(curDir, { withFileTypes: true });
    } catch (_) {
      return;
    }
    for (const ent of entries) {
      const relPosix = relPrefix ? `${relPrefix}/${ent.name}` : ent.name;
      if (ent.isDirectory()) {
        if (FORBIDDEN_DIRS.has(ent.name.toLowerCase()) || ent.name.startsWith(".")) continue;
        walk(path.join(curDir, ent.name), relPosix);
      } else if (ent.isFile()) {
        if (!isEligibleRelPath(relPosix)) continue;
        const fullPath = path.join(curDir, ent.name);
        try {
          const st = fs.statSync(fullPath);
          if (st.size > MAX_FILE_BYTES) {
            map.set(relPosix, {
              path: relPosix,
              fullPath,
              size: st.size,
              mtimeMs: Math.round(st.mtimeMs),
              sha256: null,
              buf: null,
              oversized: true,
            });
            continue;
          }
          const buf = fs.readFileSync(fullPath);
          map.set(relPosix, {
            path: relPosix,
            fullPath,
            size: buf.length,
            mtimeMs: Math.round(st.mtimeMs),
            sha256: sha256Hex(buf),
            buf,
          });
        } catch (_) {}
      }
    }
  }

  walk(memoryRoot, "");
  return map;
}

function atomicWriteFile(destPath, buf) {
  const dir = path.dirname(destPath);
  fs.mkdirSync(dir, { recursive: true });
  const tmpPath = `${destPath}.tmp_${process.pid}_${Date.now()}`;
  fs.writeFileSync(tmpPath, buf);
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      fs.renameSync(tmpPath, destPath);
      return;
    } catch (err) {
      if (attempt === 4) {
        try { fs.unlinkSync(tmpPath); } catch (_) {}
        throw err;
      }
      const end = Date.now() + 40 * (attempt + 1);
      while (Date.now() < end) { /* brief spin retry for Windows file locks */ }
    }
  }
}

function archiveConflictFile(memoryRoot, relPosix, label, buf) {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const safeRel = relPosix.replace(/\//g, "__");
  const dest = path.join(memoryRoot, "_archive", "conflicts", `${stamp}__${label}__${safeRel}`);
  atomicWriteFile(dest, buf);
  return dest;
}

// ---------------------------------------------------------------------------
// Line-by-line 3-way merge for the idea backlog and the grep-only logs (backlog 2026-11-13,
// widened the same day to every grep-only log: root *Reference.md / *Archive.md /
// *DoneLedger.md, PropagationLedger.md, HISTORY.md and memory/*-reference.md / *-Archive.md).
// These files mostly grow by new lines, so two PCs each appending a line used to lose one of
// them to newest-wins. When two PCs (or a PC and the browser) both change one of these files
// between syncs, the sync merges them against the last version both sides had (the "base")
// instead of keeping only the newest copy, so a line one PC moved and a line another PC added
// both survive. The vault keeps only hashes of old versions, so each PC keeps its own copy of
// the last-synced bytes of these files in ~/.theo/memory-cloud-base/. With no matching base copy
// the old rule applies (newest wins, the loser archived in _archive/conflicts/).
// ---------------------------------------------------------------------------
const LINE_MERGE_EXACT = new Set(["memory/idea-backlog.md", "PropagationLedger.md", "HISTORY.md"]);

function isLineMergePath(relPosix) {
  if (typeof relPosix !== "string" || isPrivateRelPath(relPosix)) return false; // never cache plaintext
  return (
    LINE_MERGE_EXACT.has(relPosix) ||
    /^[^/]+(?:Reference|Archive|DoneLedger)\.md$/.test(relPosix) ||
    /^memory\/[^/]+-(?:reference|Archive)\.md$/.test(relPosix) ||
    /^Legacy\/Dataverse\/(?:PropagationLedger\.md|[^/]+(?:Reference|Archive|DoneLedger)\.md)$/.test(relPosix)
  );
}

/**
 * Find non-overlapping duplicate runs of >= minNonBlank non-blank lines.
 * Matches find_duplicate_blocks in Admin/bhfirms-memory-guard.py so local guard, cloud sync,
 * and git sync flag and hold back the exact same duplicate sections (without echoing line text).
 */
function findDuplicateBlocks(buf, minNonBlank = DUP_BLOCK_MIN_LINES) {
  const rawBuf = Buffer.isBuffer(buf) ? buf : Buffer.from(String(buf || ""), "utf8");
  const nb = [];
  let lineNo = 1;
  let start = 0;
  for (let i = 0; i <= rawBuf.length; i++) {
    if (i === rawBuf.length || rawBuf[i] === 0x0a) {
      let end = i;
      if (end > start && rawBuf[end - 1] === 0x0d) end--;
      const lineBuf = rawBuf.subarray(start, end);
      const s = decodeUtf8Strict(lineBuf);
      if (s !== null) {
        if (/\S/.test(s)) nb.push({ lineNo, text: `u:${s}` });
      } else {
        let hasNonSpace = false;
        for (let k = 0; k < lineBuf.length; k++) {
          const b = lineBuf[k];
          if (b !== 0x20 && b !== 0x09 && b !== 0x0b && b !== 0x0c && b !== 0x0d && (b < 0x1c || b > 0x1f)) {
            hasNonSpace = true;
            break;
          }
        }
        if (hasNonSpace) nb.push({ lineNo, text: `r:${lineBuf.toString("latin1")}` });
      }
      lineNo++;
      start = i + 1;
    }
  }
  const n = nb.length;
  if (n < minNonBlank * 2) return [];
  const texts = nb.map((x) => x.text);
  const seen = new Map();
  const dups = [];
  let skipUntil = 0;
  for (let j = 0; j <= n - minNonBlank; j++) {
    const gram = texts.slice(j, j + minNonBlank).join("\n");
    let earlier = seen.get(gram);
    if (!earlier) {
      earlier = [];
      seen.set(gram, earlier);
    }
    if (j >= skipUntil && earlier.length > 0 && earlier[0] <= j - minNonBlank) {
      let bestI = -1;
      let bestM = 0;
      let checked = 0;
      for (const i of earlier) {
        if (i > j - minNonBlank) break;
        let m = minNonBlank;
        const lim = Math.min(j - i, n - j);
        while (m < lim && texts[i + m] === texts[j + m]) m++;
        if (m > bestM) {
          bestM = m;
          bestI = i;
        }
        checked++;
        if (checked >= 8) break;
      }
      if (bestM >= minNonBlank) {
        dups.push({
          firstStart: nb[bestI].lineNo,
          firstEnd: nb[bestI + bestM - 1].lineNo,
          dupStart: nb[j].lineNo,
          dupEnd: nb[j + bestM - 1].lineNo,
          count: bestM,
        });
        skipUntil = j + bestM;
      }
    }
    if (earlier.length < 16) earlier.push(j);
  }
  return dups;
}

function baseCacheDir(cfg) {
  return path.join(path.dirname(cfg.statePath), "memory-cloud-base");
}

function baseCachePath(cfg, relPosix, sha) {
  return path.join(baseCacheDir(cfg), `${relPosix.replace(/\//g, "__")}.${sha}`);
}

/** The last-synced bytes of relPosix, or null unless the cached copy hashes to `sha`. */
function readBaseCopy(cfg, relPosix, sha) {
  if (!sha) return null;
  try {
    const buf = fs.readFileSync(baseCachePath(cfg, relPosix, sha));
    return sha256Hex(buf) === sha ? buf : null;
  } catch (_) {
    return null;
  }
}

/** Keep exactly one cached copy per merge path: the bytes whose hash the sync state records. */
function writeBaseCopy(cfg, relPosix, buf) {
  try {
    const sha = sha256Hex(buf);
    const dest = baseCachePath(cfg, relPosix, sha);
    if (!fs.existsSync(dest)) atomicWriteFile(dest, buf);
    const prefix = `${relPosix.replace(/\//g, "__")}.`;
    for (const name of fs.readdirSync(baseCacheDir(cfg))) {
      if (name.startsWith(prefix) && name !== path.basename(dest) && /^[0-9a-f]{64}$/.test(name.slice(prefix.length))) {
        try { fs.unlinkSync(path.join(baseCacheDir(cfg), name)); } catch (_) {}
      }
    }
  } catch (_) {}
}

function decodeUtf8Strict(buf) {
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(buf);
  } catch (_) {
    return null;
  }
}

/** Patience diff: matched index pairs [ai, bi] (increasing in both) between line arrays a and b. */
function patienceMatches(a, b) {
  const out = [];
  function rec(aLo, aHi, bLo, bHi) {
    while (aLo < aHi && bLo < bHi && a[aLo] === b[bLo]) out.push([aLo++, bLo++]);
    const tail = [];
    while (aLo < aHi && bLo < bHi && a[aHi - 1] === b[bHi - 1]) tail.push([--aHi, --bHi]);
    if (aLo < aHi && bLo < bHi) {
      const ca = new Map();
      for (let i = aLo; i < aHi; i++) {
        const e = ca.get(a[i]);
        if (e) e.n++;
        else ca.set(a[i], { n: 1, i });
      }
      const cb = new Map();
      for (let j = bLo; j < bHi; j++) {
        const e = cb.get(b[j]);
        if (e) e.n++;
        else cb.set(b[j], { n: 1, j });
      }
      const pairs = [];
      for (let i = aLo; i < aHi; i++) {
        const ea = ca.get(a[i]);
        const eb = cb.get(a[i]);
        if (ea.n === 1 && eb && eb.n === 1) pairs.push([i, eb.j]);
      }
      // Longest increasing subsequence of pairs by b index (pairs are already sorted by a index).
      const tails = [];
      const prev = new Array(pairs.length).fill(-1);
      for (let k = 0; k < pairs.length; k++) {
        let lo = 0;
        let hi = tails.length;
        while (lo < hi) {
          const mid = (lo + hi) >> 1;
          if (pairs[tails[mid]][1] < pairs[k][1]) lo = mid + 1;
          else hi = mid;
        }
        if (lo > 0) prev[k] = tails[lo - 1];
        tails[lo] = k;
      }
      const anchors = [];
      for (let k = tails.length ? tails[tails.length - 1] : -1; k >= 0; k = prev[k]) anchors.push(pairs[k]);
      anchors.reverse();
      if (anchors.length) {
        let pa = aLo;
        let pb = bLo;
        for (const [ai, bi] of anchors) {
          rec(pa, ai, pb, bi);
          out.push([ai, bi]);
          pa = ai + 1;
          pb = bi + 1;
        }
        rec(pa, aHi, pb, bHi);
      }
    }
    for (let k = tail.length - 1; k >= 0; k--) out.push(tail[k]);
  }
  rec(0, a.length, 0, b.length);
  return out;
}

function sameLines(x, y) {
  if (x.length !== y.length) return false;
  for (let i = 0; i < x.length; i++) if (x[i] !== y[i]) return false;
  return true;
}

/**
 * Both sides changed the same stretch of lines. A base line survives only if neither side dropped
 * it; a line either side added survives (once, if both added it). Counted per distinct line so
 * repeated blank lines behave. Order: the local stretch, then what only the cloud added.
 */
function resolveOverlap(B, L, C) {
  const count = (arr) => {
    const m = new Map();
    for (const s of arr) m.set(s, (m.get(s) || 0) + 1);
    return m;
  };
  const cB = count(B);
  const cL = count(L);
  const cC = count(C);
  const target = new Map();
  for (const s of new Set([...L, ...C])) {
    const b = cB.get(s) || 0;
    const dL = (cL.get(s) || 0) - b;
    const dC = (cC.get(s) || 0) - b;
    let t;
    if (dL === 0) t = b + dC;
    else if (dC === 0) t = b + dL;
    // Both added copies next to different lines (blank lines, code fences, "- DONE" status
    // lines of two separate entries): keep every copy. An identical change on both sides never
    // gets here (sameLines(ls, cs) in mergeLines3), so this duplicates rather than drops.
    else if (dL > 0 && dC > 0) t = b + dL + dC;
    else if (dL < 0 && dC < 0) t = b + Math.min(dL, dC);
    else t = b + dL + dC;
    target.set(s, Math.max(0, t));
  }
  const emitted = new Map();
  const out = [];
  for (const s of [...L, ...C]) {
    const n = emitted.get(s) || 0;
    if (n < target.get(s)) {
      out.push(s);
      emitted.set(s, n + 1);
    }
  }
  return out;
}

/**
 * True when the cloud copy already holds every change the local copy made against the base:
 * each line local added is in the cloud at least as often, and each line local removed is in the
 * cloud no more often (multiset counts). The base can be stale (a merged push that landed, or
 * whose reply was lost, before the run aborted), and merging again against it would count this
 * PC's lines as added on both sides and duplicate them; pulling the cloud copy is then right.
 * A local edit with no count change (pure reorder) returns false so it still merges.
 */
function cloudHoldsLocalChanges(baseBuf, localBuf, cloudBuf) {
  const texts = [baseBuf, localBuf, cloudBuf].map(decodeUtf8Strict);
  if (texts.some((t) => t === null)) return false;
  const count = (t) => {
    const m = new Map();
    for (let s of t.split("\n")) {
      if (s.endsWith("\r")) s = s.slice(0, -1);
      m.set(s, (m.get(s) || 0) + 1);
    }
    return m;
  };
  const [cB, cL, cC] = texts.map(count);
  const lines = (t) => t.split("\n").map((s) => (s.endsWith("\r") ? s.slice(0, -1) : s));
  // The cloud must also hold the local lines in the same order (the cloud only added to this
  // copy): counts alone miss a moved idea or a "  - DONE" added under a different entry when
  // the same text appears elsewhere (red-team 2026-11-13). Known residual: if another PC also
  // removed lines from the merged copy before this run, this check fails and the run merges
  // against the stale base, which can duplicate that PC's section (never drops a line).
  const isSubseq = (a, b) => {
    let j = 0;
    for (const s of a) {
      while (j < b.length && b[j] !== s) j++;
      if (j === b.length) return false;
      j++;
    }
    return true;
  };
  let changed = false;
  for (const s of new Set([...cB.keys(), ...cL.keys()])) {
    const b = cB.get(s) || 0;
    const l = cL.get(s) || 0;
    const c = cC.get(s) || 0;
    if (l > b) {
      changed = true;
      if (c < l) return false;
    } else if (l < b) {
      changed = true;
      if (c > l) return false;
    }
  }
  if (!changed) return false;
  const L = lines(texts[1]);
  const C = lines(texts[2]);
  if (!isSubseq(L, C)) return false;
  // Each non-blank line local added must keep its local predecessor right above it in the cloud,
  // or a "  - DONE" appended under one entry could pass as the cloud's own line under another
  // entry inserted in the same gap. Blank lines are left out (a failure only means merging).
  const cloudPairs = new Set();
  for (let i = 1; i < C.length; i++) cloudPairs.add(`${C[i - 1]}\n${C[i]}`);
  for (let i = 1; i < L.length; i++) {
    const s = L[i];
    if (s.trim() === "" || (cL.get(s) || 0) <= (cB.get(s) || 0)) continue;
    if (!cloudPairs.has(`${L[i - 1]}\n${s}`)) return false;
  }
  return true;
}

/**
 * 3-way line merge. Returns { buf, overlaps } or null when any side is not valid UTF-8.
 * `overlaps` counts stretches both sides changed (resolved by resolveOverlap, nothing dropped
 * that either side added).
 */
function mergeLines3(baseBuf, localBuf, cloudBuf) {
  const bt = decodeUtf8Strict(baseBuf);
  const lt = decodeUtf8Strict(localBuf);
  const ct = decodeUtf8Strict(cloudBuf);
  if (bt === null || lt === null || ct === null) return null;
  const crlf = (lt.match(/\r\n/g) || []).length;
  const nl = crlf > (lt.match(/\n/g) || []).length - crlf ? "\r\n" : "\n";
  const split = (t) => t.split("\n").map((s) => (s.endsWith("\r") ? s.slice(0, -1) : s));
  const B = split(bt);
  const L = split(lt);
  const C = split(ct);
  const mL = new Array(B.length).fill(-1);
  for (const [bi, li] of patienceMatches(B, L)) mL[bi] = li;
  const mC = new Array(B.length).fill(-1);
  for (const [bi, ci] of patienceMatches(B, C)) mC[bi] = ci;
  const out = [];
  let overlaps = 0;
  let pb = -1;
  let pl = -1;
  let pc = -1;
  const flush = (nb, nl2, nc) => {
    const bs = B.slice(pb + 1, nb);
    const ls = L.slice(pl + 1, nl2);
    const cs = C.slice(pc + 1, nc);
    if (sameLines(ls, bs)) out.push(...cs);
    else if (sameLines(cs, bs) || sameLines(ls, cs)) out.push(...ls);
    else {
      overlaps++;
      out.push(...resolveOverlap(bs, ls, cs));
    }
  };
  for (let i = 0; i < B.length; i++) {
    if (mL[i] < 0 || mC[i] < 0) continue;
    flush(i, mL[i], mC[i]);
    out.push(B[i]);
    pb = i;
    pl = mL[i];
    pc = mC[i];
  }
  flush(B.length, L.length, C.length);
  return { buf: Buffer.from(out.join(nl), "utf8"), overlaps };
}

function isProcessAlive(pid) {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return err && err.code === "EPERM";
  }
}

function acquireSyncLock(lockPath) {
  fs.mkdirSync(path.dirname(lockPath), { recursive: true });
  const payload = JSON.stringify({ pid: process.pid, startedAt: Date.now() });
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      fs.writeFileSync(lockPath, payload, { flag: "wx", mode: 0o600 });
      return () => {
        try { fs.unlinkSync(lockPath); } catch (_) {}
      };
    } catch (err) {
      if (!err || err.code !== "EEXIST") throw err;
      try {
        const raw = JSON.parse(fs.readFileSync(lockPath, "utf8"));
        const age = Date.now() - (Number(raw.startedAt) || 0);
        if (!isProcessAlive(Number(raw.pid)) || age > LOCK_STALE_MS) {
          fs.unlinkSync(lockPath);
          continue;
        }
      } catch (_) {
        try { fs.unlinkSync(lockPath); continue; } catch (_2) {}
      }
      return null;
    }
  }
  return null;
}

function loadSyncState(statePath, cloudUrl) {
  try {
    if (fs.existsSync(statePath)) {
      const parsed = JSON.parse(fs.readFileSync(statePath, "utf8"));
      if (parsed && typeof parsed === "object" && parsed.cloudUrl === cloudUrl) {
        return {
          cloudUrl,
          lastRev: Number(parsed.lastRev) || 0,
          files: parsed.files && typeof parsed.files === "object" ? parsed.files : {},
          deleted: parsed.deleted && typeof parsed.deleted === "object" ? parsed.deleted : {},
          gitTips: parsed.gitTips && typeof parsed.gitTips === "object" ? parsed.gitTips : {},
        };
      }
    }
  } catch (_) {}
  return { cloudUrl, lastRev: 0, files: {}, deleted: {}, gitTips: {} };
}

function saveSyncState(statePath, stateObj) {
  atomicWriteFile(statePath, Buffer.from(JSON.stringify(stateObj, null, 2) + "\n", "utf8"));
}

async function vaultRequest(cfg, apiPath, options = {}) {
  if (!cfg.authToken) {
    throw new Error("Missing THEO Edge Access Key in ~/.theo/credentials.json");
  }
  const ctrl = new AbortController();
  const timeoutMs = options.timeoutMs || 30000;
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const headers = {
      Authorization: `Bearer ${cfg.authToken}`,
      ...(options.headers || {}),
    };
    let body = options.body;
    if (options.rawBody !== undefined) {
      headers["Content-Type"] = options.contentType || "application/octet-stream";
      body = options.rawBody;
    } else if (options.json !== undefined) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(options.json);
    }
    const res = await fetch(`${cfg.cloudUrl}${apiPath}`, {
      method: options.method || "GET",
      headers,
      body,
      signal: ctrl.signal,
    });
    if (options.responseType === "buffer" && res.ok) {
      const buf = Buffer.from(await res.arrayBuffer());
      return { ok: true, status: res.status, headers: res.headers, data: buf };
    }
    const text = await res.text();
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch (_) {
      data = { raw: text };
    }
    return { ok: res.ok, status: res.status, headers: res.headers, data };
  } finally {
    clearTimeout(timer);
  }
}

async function fetchRawCloudFile(cfg, relPosix, timeoutMs = 120000) {
  const fRes = await vaultRequest(cfg, `/api/file/raw?path=${encodeURIComponent(relPosix)}`, {
    timeoutMs,
    responseType: "buffer",
  });
  if (!fRes.ok || !Buffer.isBuffer(fRes.data)) {
    throw new Error(`Large file pull failed for ${relPosix} (${fRes.status})`);
  }
  const metaHdr = fRes.headers && typeof fRes.headers.get === "function" ? fRes.headers.get("x-vault-file-meta") : "";
  let meta = null;
  try {
    meta = metaHdr ? JSON.parse(decodeURIComponent(metaHdr)) : null;
  } catch (_) {
    meta = null;
  }
  if (!meta || !meta.path) {
    throw new Error(`Missing X-Vault-File-Meta header for ${relPosix}`);
  }
  const buf = meta.encrypted
    ? decryptPrivateBuffer(meta.path, meta.encIv, fRes.data, cfg.privKey)
    : fRes.data;
  return { meta, buf };
}

function buildRawPutPayload(relPosix, buf, cfg, ifMatchSha256) {
  let uploadMeta;
  let rawBody;
  if (isPrivateRelPath(relPosix)) {
    const encSpec = encryptPrivateRaw(relPosix, buf, cfg.privKey);
    rawBody = encSpec.ciphertextBuf;
    uploadMeta = {
      path: relPosix,
      source: "pc-sync",
      updatedBy: cfg.hostLabel,
      encrypted: true,
      encAlg: encSpec.encAlg,
      encIv: encSpec.encIv,
      plainSha256: encSpec.plainSha256,
      plainSize: encSpec.plainSize,
    };
  } else {
    rawBody = buf;
    uploadMeta = {
      path: relPosix,
      source: "pc-sync",
      updatedBy: cfg.hostLabel,
      encrypted: false,
    };
  }
  if (ifMatchSha256 !== undefined) {
    uploadMeta.ifMatchSha256 = ifMatchSha256;
  }
  return { uploadMeta, rawBody };
}

function buildPutPayload(relPosix, buf, cfg, ifMatchSha256) {
  let payload;
  if (isPrivateRelPath(relPosix)) {
    const encSpec = encryptPrivateBuffer(relPosix, buf, cfg.privKey);
    payload = {
      path: relPosix,
      source: "pc-sync",
      updatedBy: cfg.hostLabel,
      ...encSpec,
    };
  } else {
    payload = {
      path: relPosix,
      contentBase64: buf.toString("base64"),
      source: "pc-sync",
      updatedBy: cfg.hostLabel,
    };
  }
  if (ifMatchSha256 !== undefined) {
    payload.ifMatchSha256 = ifMatchSha256;
  }
  return payload;
}

function decodeDownloadedFile(fileObj, cfg) {
  if (fileObj.encrypted) {
    return decryptPrivateBuffer(fileObj.path, fileObj.encIv, fileObj.ciphertextBase64, cfg.privKey);
  }
  if (typeof fileObj.contentBase64 === "string") {
    return Buffer.from(fileObj.contentBase64, "base64");
  }
  if (typeof fileObj.content === "string") {
    return Buffer.from(fileObj.content, "utf8");
  }
  throw new Error(`Invalid file payload for ${fileObj.path}`);
}

async function runCloudSync(options = {}) {
  const mode = options.mode || "sync"; // "sync" | "pull" | "push" | "bootstrap" | "status" | "pull-if-changed"
  const prefer = options.prefer || "newest"; // "newest" | "local" | "cloud"
  const cfg = resolveSyncConfig(options);

  if (cfg.sandboxMissingCloudUrl) {
    return { ok: false, skipped: true, reason: "sandbox-missing-cloud-url" };
  }

  if (!cfg.authToken) {
    return { ok: false, skipped: true, reason: "no-credentials" };
  }

  if (mode === "status") {
    const headRes = await vaultRequest(cfg, "/api/head");
    if (!headRes.ok) {
      return { ok: false, error: (headRes.data && headRes.data.error) || `HTTP ${headRes.status}` };
    }
    const localMap = scanLocalTree(cfg.memoryRoot);
    const state = loadSyncState(cfg.statePath, cfg.cloudUrl);
    return {
      ok: true,
      cloudUrl: cfg.cloudUrl,
      memoryRoot: cfg.memoryRoot,
      cloudRev: headRes.data.rev,
      cloudFileCount: headRes.data.fileCount,
      localFileCount: localMap.size,
      lastSyncedRev: state.lastRev,
    };
  }

  const releaseLock = acquireSyncLock(cfg.lockPath);
  if (!releaseLock) {
    return { ok: true, skipped: true, reason: "locked" };
  }

  try {
    const state = loadSyncState(cfg.statePath, cfg.cloudUrl);
    const hasLocalTheo = fs.existsSync(path.join(cfg.memoryRoot, "THEO.md"));

    if (mode === "pull-if-changed" && hasLocalTheo) {
      const headRes = await vaultRequest(cfg, "/api/head", { timeoutMs: 10000 });
      if (!headRes.ok) {
        return { ok: false, error: (headRes.data && headRes.data.error) || `HTTP ${headRes.status}` };
      }
      if (Number(headRes.data.rev) === state.lastRev && Number(headRes.data.fileCount) > 0) {
        return { ok: true, unchanged: true, rev: state.lastRev };
      }
    }

    const manRes = await vaultRequest(cfg, "/api/manifest?includeDeleted=1");
    if (!manRes.ok || !manRes.data || !manRes.data.ok) {
      return {
        ok: false,
        error: (manRes.data && manRes.data.error) || `Manifest failed (${manRes.status})`,
      };
    }

    const startManifestRev = Number(manRes.data.rev) || 0;
    const cloudMap = new Map();
    let activeCloudCount = 0;
    for (const f of manRes.data.files || []) {
      cloudMap.set(f.path, f);
      if (!f.deleted) activeCloudCount++;
    }

    // Safety rail: if local THEO.md is missing and cloud has files, treat as bootstrap pull (never delete cloud!).
    const effectiveMode = !hasLocalTheo && activeCloudCount > 0 && mode !== "push" ? "bootstrap" : mode;
    const localMap = scanLocalTree(cfg.memoryRoot);

    const allPaths = new Set([
      ...Object.keys(state.files),
      ...localMap.keys(),
      ...cloudMap.keys(),
    ]);

    const toPull = [];
    const toPush = [];
    const toDeleteLocal = [];
    const toDeleteCloud = [];
    const toMerge = [];
    const conflicts = [];
    const skippedGuard = [];
    const skippedGuardPaths = [];
    const nextStateFiles = { ...state.files };
    const nextDeletedFiles = {};

    let sawDeferredDirty = false;

    for (const p of Array.from(allPaths).sort()) {
      if (!isEligibleRelPath(p)) {
        delete nextStateFiles[p];
        continue;
      }
      // Mirrors are never pushed/pulled independently; server mirrors THEO.md -> CLAUDE.md/AGENTS.md atomically
      // and we align local CLAUDE.md/AGENTS.md from the winning local THEO.md after sync.
      if (MIRROR_TARGETS.includes(p)) continue;
      const local = localMap.get(p) || null;
      const cloud = cloudMap.get(p) || null;
      const cloudActive = cloud && !cloud.deleted ? cloud : null;
      const base = state.files[p] || null;
      const cloudUpdatedMs = cloud ? Number(cloud.updatedAt) || 0 : 0;
      const cloudRevNum = cloud ? Number(cloud.rev) || 0 : 0;

      if (effectiveMode === "bootstrap" || effectiveMode === "pull") {
        if (local && local.oversized) {
          const g = checkLocalPushCandidate(p, local);
          skippedGuard.push(g.error);
          skippedGuardPaths.push(p);
          continue;
        }
        if (cloudActive) {
          if (!local || local.sha256 !== cloudActive.sha256) {
            if (local && local.buf && base && local.sha256 !== base.sha256 && effectiveMode === "pull") {
              archiveConflictFile(cfg.memoryRoot, p, "local-pre-pull", local.buf);
            }
            toPull.push(p);
          } else {
            nextStateFiles[p] = { sha256: local.sha256, size: local.size, updatedAt: cloudUpdatedMs, rev: cloudRevNum };
          }
        } else if (cloud && cloud.deleted && local && !PROTECTED_DELETE_PATHS.has(p)) {
          if (!base || local.sha256 === base.sha256 || local.sha256 === cloud.sha256) {
            toDeleteLocal.push(p);
          }
        }
        continue;
      }

      if (effectiveMode === "pull-if-changed") {
        // Strictly pull-only: apply incoming cloud updates/deletes on clean local files without pushing mid-edit local files.
        if (local && local.oversized) {
          const g = checkLocalPushCandidate(p, local);
          skippedGuard.push(g.error);
          skippedGuardPaths.push(p);
          continue;
        }
        if (cloudActive) {
          if (local && local.sha256 === cloudActive.sha256) {
            nextStateFiles[p] = { sha256: local.sha256, size: local.size, updatedAt: cloudUpdatedMs, rev: cloudRevNum };
          } else if (!local) {
            if (base && base.sha256 === cloudActive.sha256 && hasLocalTheo) {
              // Dirty local deletion waiting for quiet window -> do not resurrect or push yet
            } else {
              toPull.push(p);
            }
          } else if (!base || local.sha256 === base.sha256) {
            // Clean local file, cloud updated -> pull immediately
            toPull.push(p);
          } else if (cloudActive.sha256 === base.sha256) {
            // Dirty local edit while cloud is unchanged -> leave untouched for quiet-window sync
          } else if (local.mtimeMs <= cloudUpdatedMs + 1000 && isLineMergePath(p) && readBaseCopy(cfg, p, base.sha256)) {
            // Both diverged, cloud newer, line-merge file: merge both into the local file without pushing
            toMerge.push({ path: p, local, cloudSha: cloudActive.sha256, cloudUpdatedMs, baseSha: base.sha256, pullOnly: true });
          } else if (local.mtimeMs <= cloudUpdatedMs + 1000) {
            // Both diverged from base and cloud is newer -> archive stale local copy and pull cloud winner
            conflicts.push({ path: p, winner: "cloud" });
            archiveConflictFile(cfg.memoryRoot, p, "local", local.buf);
            toPull.push(p);
          } else {
            // Both diverged and local edit is fresh -> defer reconciliation until quiet-window sync
            sawDeferredDirty = true;
          }
        } else if (cloud && cloud.deleted && local && !PROTECTED_DELETE_PATHS.has(p)) {
          if ((base && local.sha256 === base.sha256) || (!base && local.sha256 === cloud.sha256)) {
            toDeleteLocal.push(p);
          }
        }
        continue;
      }

      if (effectiveMode === "push") {
        if (local) {
          const g = checkLocalPushCandidate(p, local);
          if (!g.ok) {
            skippedGuard.push(g.error);
            skippedGuardPaths.push(p);
            continue;
          }
          if (!cloudActive || cloudActive.sha256 !== local.sha256) {
            toPush.push({ path: p, buf: local.buf, ifMatchSha256: undefined });
          } else {
            nextStateFiles[p] = { sha256: local.sha256, size: local.size, updatedAt: cloudUpdatedMs, rev: cloudRevNum };
          }
        }
        continue;
      }

      // Standard 3-way `sync` mode (`hasLocalTheo` is true or initial vault seed)
      if (local && local.oversized) {
        const g = checkLocalPushCandidate(p, local);
        skippedGuard.push(g.error);
        skippedGuardPaths.push(p);
        continue;
      }
      if (local && cloudActive) {
        if (local.sha256 === cloudActive.sha256) {
          nextStateFiles[p] = { sha256: local.sha256, size: local.size, updatedAt: cloudUpdatedMs, rev: cloudRevNum };
          continue;
        }
        const localUnchangedFromBase = Boolean(base && local.sha256 === base.sha256);
        const cloudUnchangedFromBase = Boolean(base && cloudActive.sha256 === base.sha256);

        if (localUnchangedFromBase && !cloudUnchangedFromBase) {
          toPull.push(p);
        } else if (!localUnchangedFromBase && cloudUnchangedFromBase) {
          const g = checkLocalPushCandidate(p, local);
          if (!g.ok) {
            skippedGuard.push(g.error);
            skippedGuardPaths.push(p);
            continue;
          }
          toPush.push({ path: p, buf: local.buf, ifMatchSha256: cloudActive.sha256 });
        } else if (prefer === "newest" && base && isLineMergePath(p) && readBaseCopy(cfg, p, base.sha256)) {
          // Concurrent edit on both sides of a line-merge file: merge line by line (resolved below)
          toMerge.push({ path: p, local, cloudSha: cloudActive.sha256, cloudUpdatedMs, baseSha: base.sha256, pullOnly: false });
        } else {
          // Concurrent edit on both sides (or first sync with divergent copies)
          const takeLocal =
            prefer === "local" ||
            (prefer === "newest" && local.mtimeMs > Number(cloudActive.updatedAt || 0) + 1000);
          if (takeLocal) {
            const g = checkLocalPushCandidate(p, local);
            if (!g.ok) {
              skippedGuard.push(g.error);
              skippedGuardPaths.push(p);
              continue;
            }
            conflicts.push({ path: p, winner: "local" });
            // Pull cloud copy first just to archive it before overwriting cloud!
            toPush.push({
              path: p,
              buf: local.buf,
              ifMatchSha256: cloudActive.sha256,
              archiveCloudBeforePush: true,
            });
          } else {
            conflicts.push({ path: p, winner: "cloud" });
            archiveConflictFile(cfg.memoryRoot, p, "local", local.buf);
            toPull.push(p);
          }
        }
      } else if (local && !cloudActive) {
        if (cloud && cloud.deleted) {
          // Cloud intentionally deleted this file
          if ((base && local.sha256 === base.sha256) || (!base && local.sha256 === cloud.sha256)) {
            if (!PROTECTED_DELETE_PATHS.has(p)) {
              toDeleteLocal.push(p);
            }
          } else {
            // Edited locally after cloud delete -> re-push local
            const g = checkLocalPushCandidate(p, local);
            if (!g.ok) {
              skippedGuard.push(g.error);
              skippedGuardPaths.push(p);
              continue;
            }
            toPush.push({ path: p, buf: local.buf, ifMatchSha256: null });
          }
        } else {
          // Brand-new file on disk (not yet on cloud)
          const g = checkLocalPushCandidate(p, local);
          if (!g.ok) {
            skippedGuard.push(g.error);
            skippedGuardPaths.push(p);
            continue;
          }
          toPush.push({ path: p, buf: local.buf, ifMatchSha256: null });
        }
      } else if (!local && cloudActive) {
        if (base && base.sha256 === cloudActive.sha256 && hasLocalTheo && !PROTECTED_DELETE_PATHS.has(p)) {
          // Existed in base, disappeared locally while THEO.md is intact -> propagate delete to cloud
          toDeleteCloud.push({ path: p, ifMatchSha256: base.sha256 });
        } else {
          // Created on cloud (or modified on cloud after local delete) -> pull to disk
          toPull.push(p);
        }
      } else {
        delete nextStateFiles[p];
      }
    }

    // 1. Archive cloud copies for any local-winning conflicts before pushing
    for (const item of toPush) {
      if (item.archiveCloudBeforePush) {
        const cm = cloudMap.get(item.path);
        if ((cm && cm.storedSize > SINGLE_FILE_THRESHOLD_BYTES) || isBinaryDocPath(item.path)) {
          try {
            const { buf: cBuf } = await fetchRawCloudFile(cfg, item.path);
            archiveConflictFile(cfg.memoryRoot, item.path, "cloud", cBuf);
          } catch (_) {}
        } else {
          const cRes = await vaultRequest(cfg, `/api/file?path=${encodeURIComponent(item.path)}`);
          if (cRes.ok && cRes.data && cRes.data.file) {
            const cBuf = decodeDownloadedFile(cRes.data.file, cfg);
            archiveConflictFile(cfg.memoryRoot, item.path, "cloud", cBuf);
          }
        }
      }
    }

    // 1b. Line-merge files both sides changed: fetch the cloud copy, merge against the cached base,
    // write the result locally and push it (pull-only modes leave the push to the next quiet sync).
    const baseBufs = new Map(); // path -> bytes matching nextStateFiles[path] (for the base cache)
    const mergeCheckpointFiles = {}; // merged paths -> state entry, saved before anything can abort
    let mergedCount = 0;
    for (const m of toMerge) {
      const full = path.join(cfg.memoryRoot, ...m.path.split("/"));
      const cm = cloudMap.get(m.path);
      let cFile = null;
      let cBuf = null;
      if (cm && cm.storedSize > SINGLE_FILE_THRESHOLD_BYTES) {
        try {
          const fetched = await fetchRawCloudFile(cfg, m.path);
          cFile = fetched.meta;
          cBuf = fetched.buf;
        } catch (_) {}
      } else {
        const cRes = await vaultRequest(cfg, `/api/file?path=${encodeURIComponent(m.path)}`, { timeoutMs: 60000 });
        cFile = cRes.ok && cRes.data && cRes.data.file;
        cBuf = cFile ? decodeDownloadedFile(cFile, cfg) : null;
      }
      const baseBuf = readBaseCopy(cfg, m.path, m.baseSha);
      let nowLocal = null;
      try { nowLocal = fs.readFileSync(full); } catch (_) {}
      if (!cBuf || sha256Hex(cBuf) !== m.cloudSha || !baseBuf || !nowLocal || sha256Hex(nowLocal) !== m.local.sha256) {
        // Cloud or local changed since the manifest/scan (or the base copy vanished): next pass.
        sawDeferredDirty = true;
        continue;
      }
      if (cloudHoldsLocalChanges(baseBuf, m.local.buf, cBuf)) {
        // This PC's changes already reached the cloud (stale base): take the cloud copy, no merge.
        archiveConflictFile(cfg.memoryRoot, m.path, "local-premerge", m.local.buf);
        conflicts.push({ path: m.path, winner: "cloud", alreadyMerged: true });
        toPull.push(m.path);
        continue;
      }
      const merged = mergeLines3(baseBuf, m.local.buf, cBuf);
      const mergedGuard = merged ? checkLocalMarkdownGuard(m.path, merged.buf) : null;
      if (!merged || (!mergedGuard.ok && mergedGuard.kind !== "dup")) {
        // Cannot merge (not UTF-8, or the result breaks a size/line limit): the old newest-wins rule.
        const takeLocal = !m.pullOnly && m.local.mtimeMs > m.cloudUpdatedMs + 1000;
        if (takeLocal) {
          const localGuard = checkLocalMarkdownGuard(m.path, m.local.buf);
          if (!localGuard.ok) {
            skippedGuard.push(localGuard.error);
            skippedGuardPaths.push(m.path);
            continue;
          }
          conflicts.push({ path: m.path, winner: "local", mergeFallback: merged ? "size-or-line-limit" : "not-utf8" });
          archiveConflictFile(cfg.memoryRoot, m.path, "cloud", cBuf);
          toPush.push({ path: m.path, buf: m.local.buf, ifMatchSha256: m.cloudSha });
        } else {
          conflicts.push({ path: m.path, winner: "cloud", mergeFallback: merged ? "size-or-line-limit" : "not-utf8" });
          archiveConflictFile(cfg.memoryRoot, m.path, "local", m.local.buf);
          toPull.push(m.path);
        }
        continue;
      }
      const mergedSha = sha256Hex(merged.buf);
      const heldBackDup = !mergedGuard.ok && mergedSha !== m.cloudSha;
      archiveConflictFile(cfg.memoryRoot, m.path, "local-premerge", m.local.buf);
      mergedCount++;
      conflicts.push({
        path: m.path,
        winner: "merged",
        overlaps: merged.overlaps,
        ...(heldBackDup ? { heldBackGuard: true } : {}),
      });
      if (mergedSha === m.cloudSha) {
        toPull.push(m.path); // the cloud copy already holds everything
        continue;
      }
      if (mergedSha !== m.local.sha256) atomicWriteFile(full, merged.buf);
      // The local file now holds both sides, so its base becomes the cloud copy just merged. A
      // pull-only run leaves the push to the next quiet sync ("local changed, cloud unchanged");
      // if a full sync's push hits a 409, the next merge is taken against this copy, so a line
      // another PC moved out in between is not brought back. A successful push overwrites it.
      nextStateFiles[m.path] = {
        sha256: m.cloudSha,
        size: cBuf.length,
        updatedAt: Number(cFile.updatedAt) || Date.now(),
        rev: Number(cFile.rev) || 0,
      };
      baseBufs.set(m.path, cBuf);
      // Checkpoint now, after the local write (red-team 2026-11-13): if this run dies before the
      // final state save (network error, failed push batch), the next run must merge against the
      // cloud copy just merged, not the old base, or every line the cloud added would count as
      // added on both sides and land twice. lastRev is lowered so the next run cannot skip.
      writeBaseCopy(cfg, m.path, cBuf);
      mergeCheckpointFiles[m.path] = nextStateFiles[m.path];
      try {
        saveSyncState(cfg.statePath, {
          ...state,
          lastRev: Math.min(state.lastRev || 0, Math.max(0, startManifestRev - 1)),
          updatedAt: Date.now(),
          files: { ...state.files, ...mergeCheckpointFiles },
        });
      } catch (_) {}
      if (heldBackDup) {
        skippedGuard.push(mergedGuard.error);
        skippedGuardPaths.push(m.path);
      } else if (!m.pullOnly) {
        toPush.push({ path: m.path, buf: merged.buf, ifMatchSha256: m.cloudSha });
      }
    }

    // 2. Execute Pulls (batch small non-doc files, raw stream for >512 KB or PDF/Office binaries)
    let pulledCount = 0;
    const smallPulls = [];
    const largePulls = [];
    for (const p of toPull) {
      const meta = cloudMap.get(p);
      if ((meta && meta.storedSize > SINGLE_FILE_THRESHOLD_BYTES) || isBinaryDocPath(p)) {
        largePulls.push(p);
      } else {
        smallPulls.push(p);
      }
    }

    for (let i = 0; i < smallPulls.length; i += 40) {
      const slice = smallPulls.slice(i, i + 40);
      const bRes = await vaultRequest(cfg, "/api/files/get-batch", {
        method: "POST",
        json: { paths: slice },
      });
      if (!bRes.ok || !bRes.data || !Array.isArray(bRes.data.files)) {
        throw new Error(`Batch pull failed (${bRes.status})`);
      }
      for (const f of bRes.data.files) {
        const buf = decodeDownloadedFile(f, cfg);
        atomicWriteFile(path.join(cfg.memoryRoot, ...f.path.split("/")), buf);
        nextStateFiles[f.path] = {
          sha256: f.sha256,
          size: buf.length,
          updatedAt: Number(f.updatedAt) || Date.now(),
          rev: Number(f.rev) || 0,
        };
        pulledCount++;
      }
    }

    for (const p of largePulls) {
      const { meta, buf } = await fetchRawCloudFile(cfg, p);
      atomicWriteFile(path.join(cfg.memoryRoot, ...meta.path.split("/")), buf);
      nextStateFiles[meta.path] = {
        sha256: meta.sha256,
        size: buf.length,
        updatedAt: Number(meta.updatedAt) || Date.now(),
        rev: Number(meta.rev) || 0,
      };
      pulledCount++;
    }

    // Keep local CLAUDE.md / AGENTS.md mirrored if THEO.md was pulled
    if (toPull.includes("THEO.md")) {
      const theoPath = path.join(cfg.memoryRoot, "THEO.md");
      if (fs.existsSync(theoPath)) {
        const theoBuf = fs.readFileSync(theoPath);
        const theoSha = sha256Hex(theoBuf);
        const theoTs = (nextStateFiles["THEO.md"] && nextStateFiles["THEO.md"].updatedAt) || Date.now();
        const theoRev = (nextStateFiles["THEO.md"] && Number(nextStateFiles["THEO.md"].rev)) || 0;
        for (const mName of MIRROR_TARGETS) {
          atomicWriteFile(path.join(cfg.memoryRoot, mName), theoBuf);
          const mCloud = cloudMap.get(mName);
          const mRev = (mCloud && !mCloud.deleted && Number(mCloud.rev)) || theoRev;
          nextStateFiles[mName] = { sha256: theoSha, size: theoBuf.length, updatedAt: theoTs, rev: mRev };
        }
      }
    }

    // 3. Execute Local Deletions (archiving a safety copy in `_archive/deleted/` first!)
    let deletedLocalCount = 0;
    for (const p of toDeleteLocal) {
      const full = path.join(cfg.memoryRoot, ...p.split("/"));
      if (fs.existsSync(full)) {
        try {
          const oldBuf = fs.readFileSync(full);
          archiveConflictFile(cfg.memoryRoot, p, "cloud-deleted", oldBuf);
          fs.unlinkSync(full);
          deletedLocalCount++;
        } catch (_) {}
      }
      delete nextStateFiles[p];
    }

    // 4. Execute Pushes (MIRROR_TARGETS are already excluded above; server mirrors THEO.md atomically)
    const filteredPushes = toPush.filter((x) => !MIRROR_TARGETS.includes(x.path));

    let pushedCount = 0;
    let ownRevBumps = 0;
    let sawConflict409 = false;
    let currentBatch = [];
    let currentBatchBytes = 0;

    async function flushPushBatch() {
      if (!currentBatch.length) return;
      const bRes = await vaultRequest(cfg, "/api/sync-batch", {
        method: "POST",
        json: {
          source: "pc-sync",
          updatedBy: cfg.hostLabel,
          puts: currentBatch,
          deletes: [],
        },
        timeoutMs: 60000,
      });
      if (!bRes.data || !Array.isArray(bRes.data.results)) {
        throw new Error(`Push batch failed (${bRes.status}): ${JSON.stringify(bRes.data)}`);
      }
      for (const r of bRes.data.results) {
        if (r.ok && r.file) {
          const rTs = Number(r.file.updatedAt) || Date.now();
          const fRev = Number(r.file.rev) || Number(r.rev) || 0;
          nextStateFiles[r.file.path] = { sha256: r.file.sha256, size: r.file.size, updatedAt: rTs, rev: fRev };
          if (r.file.path === "THEO.md") {
            const mRev = Number(r.rev) || fRev;
            for (const mName of MIRROR_TARGETS) {
              nextStateFiles[mName] = { sha256: r.file.sha256, size: r.file.size, updatedAt: rTs, rev: mRev };
            }
          }
          if (!r.unchanged) {
            pushedCount++;
            ownRevBumps += 1 + (Array.isArray(r.mirrored) ? r.mirrored.length : 0);
          }
        } else if (r.status === 409) {
          // Concurrent update arrived mid-flight; pull the newer cloud copy on next pass
          sawConflict409 = true;
          conflicts.push({ path: r.path, winner: "cloud-409" });
        } else if (r.status === 413) {
          skippedGuard.push(r.error || `${r.path} exceeds 25 MB limit`);
          skippedGuardPaths.push(r.path);
        } else if (!r.ok) {
          throw new Error(`Failed uploading ${r.path}: ${r.error}`);
        }
      }
      currentBatch = [];
      currentBatchBytes = 0;
    }

    for (const item of filteredPushes) {
      const approxBytes = item.buf.length * 1.38 + 256;
      if (item.buf.length > SINGLE_FILE_THRESHOLD_BYTES || isBinaryDocPath(item.path)) {
        await flushPushBatch();
        const { uploadMeta, rawBody } = buildRawPutPayload(item.path, item.buf, cfg, item.ifMatchSha256);
        const pRes = await vaultRequest(cfg, "/api/files/put-raw", {
          method: "POST",
          headers: { "X-Vault-Upload": encodeURIComponent(JSON.stringify(uploadMeta)) },
          rawBody,
          timeoutMs: 120000,
        });
        if (pRes.ok && pRes.data && pRes.data.file) {
          nextStateFiles[item.path] = {
            sha256: pRes.data.file.sha256,
            size: pRes.data.file.size,
            updatedAt: Number(pRes.data.file.updatedAt) || Date.now(),
            rev: Number(pRes.data.file.rev) || Number(pRes.data.rev) || 0,
          };
          if (!pRes.data.unchanged) {
            pushedCount++;
            ownRevBumps += 1 + (Array.isArray(pRes.data.mirrored) ? pRes.data.mirrored.length : 0);
          }
        } else if (pRes.status === 409) {
          sawConflict409 = true;
          conflicts.push({ path: item.path, winner: "cloud-409" });
        } else if (pRes.status === 413) {
          skippedGuard.push((pRes.data && pRes.data.error) || `${item.path} exceeds 25 MB limit`);
          skippedGuardPaths.push(item.path);
        } else {
          throw new Error(`Large file upload failed for ${item.path}: ${(pRes.data && pRes.data.error) || pRes.status}`);
        }
      } else {
        const payload = buildPutPayload(item.path, item.buf, cfg, item.ifMatchSha256);
        if (
          currentBatch.length >= MAX_BATCH_COUNT ||
          currentBatchBytes + approxBytes > MAX_BATCH_BYTES
        ) {
          await flushPushBatch();
        }
        currentBatch.push(payload);
        currentBatchBytes += approxBytes;
      }
    }
    await flushPushBatch();

    // 5. Execute Cloud Deletions
    let deletedCloudCount = 0;
    if (toDeleteCloud.length > 0) {
      for (let i = 0; i < toDeleteCloud.length; i += MAX_BATCH_COUNT) {
        const slice = toDeleteCloud.slice(i, i + MAX_BATCH_COUNT);
        const dRes = await vaultRequest(cfg, "/api/sync-batch", {
          method: "POST",
          json: {
            source: "pc-sync",
            updatedBy: cfg.hostLabel,
            puts: [],
            deletes: slice,
          },
        });
        if (!dRes.data || !Array.isArray(dRes.data.results)) {
          throw new Error(`Delete batch failed (${dRes.status}): ${JSON.stringify(dRes.data)}`);
        }
        for (const r of dRes.data.results) {
          if (r.ok) {
            delete nextStateFiles[r.path];
            const priorCloud = cloudMap.get(r.path);
            nextDeletedFiles[r.path] = {
              sha256: (priorCloud && priorCloud.sha256) || "",
              rev: Number(r.rev) || 0,
              updatedAt: Number(r.updatedAt) || Date.now(),
            };
            if (!r.unchanged) {
              deletedCloudCount++;
              ownRevBumps += 1;
            }
          } else if (r.status === 409) {
            sawConflict409 = true;
            conflicts.push({ path: r.path, winner: "cloud-409" });
          } else {
            throw new Error(`Failed deleting ${r.path}: ${r.error}`);
          }
        }
      }
    }

    // Align local CLAUDE.md and AGENTS.md from the winning local THEO.md after full sync/bootstrap/pull/push
    const finalTheoPath = path.join(cfg.memoryRoot, "THEO.md");
    if (effectiveMode !== "pull-if-changed" && fs.existsSync(finalTheoPath)) {
      try {
        const theoBuf = fs.readFileSync(finalTheoPath);
        const theoSha = sha256Hex(theoBuf);
        const theoTs = (nextStateFiles["THEO.md"] && nextStateFiles["THEO.md"].updatedAt) || Date.now();
        const theoRev = (nextStateFiles["THEO.md"] && Number(nextStateFiles["THEO.md"].rev)) || 0;
        for (const mName of MIRROR_TARGETS) {
          const mPath = path.join(cfg.memoryRoot, mName);
          if (!fs.existsSync(mPath) || !fs.readFileSync(mPath).equals(theoBuf)) {
            atomicWriteFile(mPath, theoBuf);
          }
          const existingM = nextStateFiles[mName];
          const mCloud = cloudMap.get(mName);
          const mRev = Math.max(
            Number(existingM && existingM.sha256 === theoSha ? existingM.rev : 0) || 0,
            Number(mCloud && !mCloud.deleted && mCloud.sha256 === theoSha ? mCloud.rev : 0) || 0,
            theoRev
          );
          nextStateFiles[mName] = { sha256: theoSha, size: theoBuf.length, updatedAt: theoTs, rev: mRev };
        }
      } catch (_) {}
    }

    for (const [cPath, cMeta] of cloudMap.entries()) {
      if (cMeta && cMeta.deleted && !nextStateFiles[cPath]) {
        nextDeletedFiles[cPath] = {
          sha256: cMeta.sha256 || "",
          rev: Number(cMeta.rev) || 0,
          updatedAt: Number(cMeta.updatedAt) || 0,
        };
      }
    }

    const finalHead = await vaultRequest(cfg, "/api/head");
    const headRev =
      finalHead.ok && finalHead.data && Number.isFinite(Number(finalHead.data.rev))
        ? Number(finalHead.data.rev)
        : startManifestRev + ownRevBumps;
    const expectedHeadRev = startManifestRev + ownRevBumps;
    const savedLastRev =
      sawConflict409 || sawDeferredDirty
        ? Math.min(state.lastRev || 0, Math.max(0, startManifestRev - 1))
        : headRev === expectedHeadRev
          ? headRev
          : startManifestRev;

    const mergedGitTips = {
      ...(state.gitTips || {}),
      ...((manRes.data && manRes.data.gitTips) || {}),
    };
    const tipKeys = Object.keys(mergedGitTips);
    if (tipKeys.length > 350) {
      for (const dropKey of tipKeys.slice(0, tipKeys.length - 300)) {
        delete mergedGitTips[dropKey];
      }
    }

    // Keep the base copy of each line-merge file equal to the version the sync state now records
    // (skipping the read when that copy is already cached), and drop copies of files gone from it.
    const baseKeep = new Set();
    for (const p of Object.keys(nextStateFiles)) {
      if (!isLineMergePath(p)) continue;
      baseKeep.add(`${p.replace(/\//g, "__")}.`);
      const st = nextStateFiles[p];
      if (!st || !st.sha256) continue;
      if (!baseBufs.has(p) && fs.existsSync(baseCachePath(cfg, p, st.sha256))) continue;
      let buf = baseBufs.get(p) || null;
      if (!buf || sha256Hex(buf) !== st.sha256) {
        try {
          const disk = fs.readFileSync(path.join(cfg.memoryRoot, ...p.split("/")));
          buf = sha256Hex(disk) === st.sha256 ? disk : null;
        } catch (_) {
          buf = null;
        }
      }
      if (buf) writeBaseCopy(cfg, p, buf);
    }
    try {
      for (const name of fs.readdirSync(baseCacheDir(cfg))) {
        if (/\.[0-9a-f]{64}$/.test(name) && !baseKeep.has(name.slice(0, -64))) {
          try { fs.unlinkSync(path.join(baseCacheDir(cfg), name)); } catch (_) {}
        }
      }
    } catch (_) {}

    saveSyncState(cfg.statePath, {
      cloudUrl: cfg.cloudUrl,
      lastRev: savedLastRev,
      updatedAt: Date.now(),
      files: nextStateFiles,
      deleted: nextDeletedFiles,
      gitTips: mergedGitTips,
    });

    return {
      ok: true,
      mode: effectiveMode,
      rev: headRev,
      savedLastRev,
      pulledCount,
      pushedCount,
      deletedLocalCount,
      deletedCloudCount,
      mergedCount,
      conflicts,
      skippedGuard,
      skippedGuardPaths,
    };
  } finally {
    releaseLock();
  }
}

async function recordGitTip(commitOid, options = {}) {
  const cleanOid = String(commitOid || "").trim().toLowerCase();
  if (!/^[0-9a-f]{40}$/.test(cleanOid)) {
    return { ok: false, error: "Invalid 40-hex commitOid" };
  }
  const cfg = resolveSyncConfig(options);
  if (cfg.sandboxMissingCloudUrl || !cfg.authToken) {
    return { ok: false, skipped: true, reason: "no-cloud-config" };
  }
  const payload = { commitOid: cleanOid };
  if (options.vaultRev !== undefined && options.vaultRev !== null && Number.isFinite(Number(options.vaultRev))) {
    payload.vaultRev = Math.max(0, Math.floor(Number(options.vaultRev)));
  }
  const res = await vaultRequest(cfg, "/api/git-tip", {
    method: "POST",
    json: payload,
    timeoutMs: 15000,
  });
  if (!res.ok || !res.data || !res.data.ok) {
    return { ok: false, error: (res.data && res.data.error) || `HTTP ${res.status}` };
  }
  const vaultRev = Number(res.data.vaultRev) || 0;
  const releaseLock = acquireSyncLock(cfg.lockPath);
  try {
    const state = loadSyncState(cfg.statePath, cfg.cloudUrl);
    state.gitTips = { ...(state.gitTips || {}), [cleanOid]: vaultRev };
    saveSyncState(cfg.statePath, {
      cloudUrl: cfg.cloudUrl,
      lastRev: state.lastRev,
      updatedAt: Date.now(),
      files: state.files,
      deleted: state.deleted,
      gitTips: state.gitTips,
    });
  } catch (_) {
  } finally {
    if (releaseLock) releaseLock();
  }
  return { ok: true, commitOid: cleanOid, vaultRev };
}

async function fetchVaultHistory(options = {}) {
  const cfg = resolveSyncConfig(options);
  if (cfg.sandboxMissingCloudUrl || !cfg.authToken) {
    return { ok: false, skipped: true, reason: "no-cloud-config" };
  }
  const params = new URLSearchParams();
  params.set("limit", String(Math.max(1, Math.min(200, Number(options.limit) || 40))));
  if (options.path) params.set("path", String(options.path));
  if (options.beforeRev) params.set("beforeRev", String(options.beforeRev));
  const res = await vaultRequest(cfg, `/api/history?${params.toString()}`, { timeoutMs: 20000 });
  if (!res.ok || !res.data || !res.data.ok) {
    return { ok: false, error: (res.data && res.data.error) || `HTTP ${res.status}` };
  }
  return { ok: true, rev: res.data.rev, items: res.data.items || [] };
}

async function restoreVaultRevision(relPath, targetRev, options = {}) {
  const cfg = resolveSyncConfig(options);
  if (cfg.sandboxMissingCloudUrl || !cfg.authToken) {
    return { ok: false, skipped: true, reason: "no-cloud-config" };
  }
  const res = await vaultRequest(cfg, "/api/files/restore", {
    method: "POST",
    json: {
      path: relPath,
      rev: Number(targetRev),
      ifMatchSha256: options.ifMatchSha256,
      source: options.source || "pc-cli",
      updatedBy: options.updatedBy || `pc:${cfg.hostLabel}`,
    },
    timeoutMs: 30000,
  });
  if (!res.ok || !res.data || !res.data.ok) {
    return { ok: false, status: res.status, error: (res.data && res.data.error) || `HTTP ${res.status}` };
  }
  const syncRes = await runCloudSync({ ...options, mode: "pull", prefer: "cloud" });
  return { ok: true, restored: res.data, pull: syncRes };
}

function writeCloudAutoLog(cfg, line) {
  try {
    atomicWriteFile(path.join(cfg.theoStateDir, "last-memory-cloud-sync.log"), Buffer.from(line + "\n", "utf8"));
  } catch (_) {}
}

async function mainCli() {
  const args = process.argv.slice(2);
  let mode = "sync";
  let prefer = "newest";
  let jsonOut = false;
  let quiet = false;
  let autoMode = false;
  let tipOidArg = "";
  let explicitRevArg;
  let targetPathArg = "";
  let limitArg = 40;

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "sync" || a === "pull" || a === "push" || a === "bootstrap" || a === "status") {
      mode = a;
    } else if (a === "history") {
      mode = "history";
      if (i + 1 < args.length && !args[i + 1].startsWith("-")) {
        targetPathArg = args[++i];
      }
    } else if (a === "restore") {
      mode = "restore";
      if (i + 1 < args.length && !args[i + 1].startsWith("-")) {
        targetPathArg = args[++i];
      }
    } else if (a === "record-git-tip") {
      mode = "record-git-tip";
      if (i + 1 < args.length && !args[i + 1].startsWith("-")) {
        tipOidArg = args[++i];
      }
    } else if (a === "--rev" && i + 1 < args.length) {
      explicitRevArg = Number(args[++i]);
    } else if (a === "--limit" && i + 1 < args.length) {
      limitArg = Number(args[++i]);
    } else if (a === "--path" && i + 1 < args.length) {
      targetPathArg = args[++i];
    } else if (a === "--pull-if-changed") {
      mode = "pull-if-changed";
    } else if (a === "--prefer-local") {
      prefer = "local";
    } else if (a === "--prefer-cloud") {
      prefer = "cloud";
    } else if (a === "--auto") {
      autoMode = true;
      quiet = true;
    } else if (a === "--json") {
      jsonOut = true;
    } else if (a === "--quiet" || a === "-q") {
      quiet = true;
    }
  }

  try {
    if (mode === "record-git-tip") {
      const tipRes = await recordGitTip(tipOidArg, { vaultRev: explicitRevArg });
      if (jsonOut) {
        process.stdout.write(JSON.stringify(tipRes) + "\n");
      }
      process.exit(tipRes.ok || tipRes.skipped ? 0 : 1);
    }
    if (mode === "history") {
      const hRes = await fetchVaultHistory({ path: targetPathArg, limit: limitArg });
      if (jsonOut) {
        process.stdout.write(JSON.stringify(hRes) + "\n");
      } else if (!hRes.ok) {
        process.stderr.write(`THEO memory cloud history error: ${hRes.error || hRes.reason}\n`);
      } else if (!quiet) {
        process.stdout.write(`Vault history (head rev ${hRes.rev}, ${hRes.items.length} item(s)):\n`);
        for (const it of hRes.items) {
          const ts = new Date(it.updatedAt || 0).toISOString().replace("T", " ").slice(0, 19);
          process.stdout.write(
            `  rev ${String(it.rev).padStart(4)}  ${ts}  ${String(it.action).padEnd(7)}  ${it.restorable ? "restorable" : "legacy    "}  ${it.path}  (${it.updatedBy || "sync"})\n`
          );
        }
      }
      process.exit(hRes.ok ? 0 : 1);
    }
    if (mode === "restore") {
      if (!targetPathArg || !Number.isInteger(explicitRevArg) || explicitRevArg <= 0) {
        process.stderr.write("Usage: theo-memory-cloud.cjs restore <relPath> --rev <N>\n");
        process.exit(2);
      }
      const rRes = await restoreVaultRevision(targetPathArg, explicitRevArg);
      if (jsonOut) {
        process.stdout.write(JSON.stringify(rRes) + "\n");
      } else if (!rRes.ok) {
        process.stderr.write(`THEO memory cloud restore error: ${rRes.error || rRes.reason}\n`);
      } else if (!quiet) {
        process.stdout.write(`Restored ${targetPathArg} from rev ${explicitRevArg} -> rev ${rRes.restored.rev}\n`);
      }
      process.exit(rRes.ok ? 0 : 1);
    }
    const res = await runCloudSync({ mode, prefer });
    if (autoMode || (res.ok && (mode === "sync" || mode === "push" || mode === "pull" || mode === "bootstrap"))) {
      const cfg = resolveSyncConfig();
      const rc = res.ok || res.skipped ? 0 : 1;
      const summary = res.ok
        ? `ts=${new Date().toISOString()} mode=${mode} exit=${rc} rev=${res.rev || 0} pulled=${res.pulledCount || 0} pushed=${res.pushedCount || 0} merged=${res.mergedCount || 0}`
        : `ts=${new Date().toISOString()} mode=${mode} exit=${rc} error=${res.error || res.reason || "failed"}`;
      writeCloudAutoLog(cfg, summary);
    }
    if (jsonOut) {
      process.stdout.write(JSON.stringify(res) + "\n");
    } else if (!quiet) {
      if (res.skipped) {
        process.stdout.write(`THEO memory cloud sync skipped (${res.reason}).\n`);
      } else if (!res.ok) {
        process.stderr.write(`THEO memory cloud sync error: ${res.error}\n`);
      } else if (mode === "status") {
        process.stdout.write(
          `Cloud (${res.cloudUrl}): rev ${res.cloudRev}, ${res.cloudFileCount} files | Local (${res.memoryRoot}): ${res.localFileCount} files (lastSyncedRev=${res.lastSyncedRev})\n`
        );
      } else if (res.unchanged) {
        process.stdout.write(`THEO memory cloud up to date (rev ${res.rev}).\n`);
      } else {
        process.stdout.write(
          `THEO memory cloud ${res.mode} ok (rev ${res.rev}): pulled=${res.pulledCount}, pushed=${res.pushedCount}, delLocal=${res.deletedLocalCount}, delCloud=${res.deletedCloudCount}` +
            (res.conflicts && res.conflicts.length ? `, conflicts=${res.conflicts.length}` : "") +
            "\n"
        );
        if (res.skippedGuard && res.skippedGuard.length) {
          for (const g of res.skippedGuard) {
            process.stderr.write(`  guard skipped: ${g}\n`);
          }
        }
      }
    }
    process.exit(res.ok || res.skipped ? 0 : 1);
  } catch (err) {
    if (autoMode) {
      try {
        const cfg = resolveSyncConfig();
        writeCloudAutoLog(cfg, `ts=${new Date().toISOString()} mode=${mode} exit=1 error=${err.message || err}`);
      } catch (_) {}
    }
    if (jsonOut) {
      process.stdout.write(JSON.stringify({ ok: false, error: err.message || String(err) }) + "\n");
    } else if (!quiet) {
      process.stderr.write(`THEO memory cloud fatal: ${err.message || err}\n`);
    }
    process.exit(1);
  }
}

function detectLocalVaultDrift(options = {}) {
  const quietMs = Number.isFinite(Number(options.quietMs)) ? Number(options.quietMs) : 90_000;
  const nowMs = Number.isFinite(Number(options.nowMs)) ? Number(options.nowMs) : Date.now();
  const deletionSeenMap = options.deletionSeenMap instanceof Map ? options.deletionSeenMap : null;
  const cfg = resolveSyncConfig(options);
  if (cfg.sandboxMissingCloudUrl || !cfg.authToken) {
    return { hasDrift: false, settled: false, latestChangeMs: 0 };
  }
  if (!fs.existsSync(path.join(cfg.memoryRoot, "THEO.md"))) {
    return { hasDrift: false, settled: false, latestChangeMs: 0, needsBootstrap: true };
  }
  const state = loadSyncState(cfg.statePath, cfg.cloudUrl);
  const localMap = scanLocalTree(cfg.memoryRoot);
  let hasDrift = false;
  let latestChangeMs = 0;

  for (const [p, loc] of localMap.entries()) {
    if (MIRROR_TARGETS.includes(p)) continue;
    if (loc.oversized) continue;
    if (deletionSeenMap) deletionSeenMap.delete(p);
    const base = state.files[p];
    if (!base || base.sha256 !== loc.sha256) {
      hasDrift = true;
      if (loc.mtimeMs > latestChangeMs) latestChangeMs = loc.mtimeMs;
    }
  }

  for (const p of Object.keys(state.files)) {
    if (MIRROR_TARGETS.includes(p) || PROTECTED_DELETE_PATHS.has(p) || !isEligibleRelPath(p)) continue;
    if (!localMap.has(p)) {
      hasDrift = true;
      let delMs = nowMs;
      if (deletionSeenMap) {
        if (!deletionSeenMap.has(p)) deletionSeenMap.set(p, nowMs);
        delMs = deletionSeenMap.get(p);
      }
      if (delMs > latestChangeMs) latestChangeMs = delMs;
    }
  }

  if (deletionSeenMap) {
    for (const trackedDel of Array.from(deletionSeenMap.keys())) {
      if (!state.files[trackedDel] || localMap.has(trackedDel)) {
        deletionSeenMap.delete(trackedDel);
      }
    }
  }

  const settled = hasDrift && nowMs - latestChangeMs >= quietMs;
  return { hasDrift, settled, latestChangeMs };
}

if (require.main === module) {
  mainCli();
}

module.exports = {
  DEFAULT_CLOUD_URL,
  MAX_FILE_BYTES,
  PRIVATE_STEMS,
  PRIVATE_DIR_PREFIX,
  MIRROR_TARGETS,
  deriveVaultKeys,
  resolveSyncConfig,
  isPrivateRelPath,
  isEligibleRelPath,
  checkLocalMarkdownGuard,
  encryptPrivateBuffer,
  decryptPrivateBuffer,
  scanLocalTree,
  detectLocalVaultDrift,
  runCloudSync,
  mergeLines3,
  cloudHoldsLocalChanges,
  isLineMergePath,
  findDuplicateBlocks,
  recordGitTip,
  fetchVaultHistory,
  restoreVaultRevision,
};
