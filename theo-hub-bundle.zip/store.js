const fs = require('fs');
const http = require('http');
const https = require('https');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
let vscode = null;
try {
  vscode = require('vscode');
} catch {}
const {
  getDefaultAntigravityHome,
  getDefaultClaudeHome,
  getDefaultClaudeConfigPath,
  cleanText,
  parseIsoToEpochSeconds,
  fileUriToPath,
  formatWorkspaceLabel,
  parseAntigravityQuotaSummary,
  parseAntigravityAccountStatus,
  parseClaudeAccountStatus,
  parseClaudeQuotaSummary,
  formatClaudeModelLabel
} = require('./data');

const execFileAsync = promisify(execFile);
const PARSE_CACHE_VERSION = 5;
const TRANSCRIPT_CHECKPOINT_MIN_BYTES = 131072;
const TRANSCRIPT_CHECKPOINT_TAIL_BYTES = 98304;
const TRANSCRIPT_CHECKPOINT_SIG_BYTES = 64;

function yieldEventLoop() {
  return new Promise((resolve) => setImmediate(resolve));
}

function cloneTranscriptCheckpoint(cp) {
  return {
    byteOffset: cp.byteOffset,
    sigBuf: cp.sigBuf,
    turns: cp.turns.slice(),
    lastStatus: cp.lastStatus,
    lastType: cp.lastType,
    lastStepAt: cp.lastStepAt,
    maxStepIndex: cp.maxStepIndex,
    lastAssistantText: cp.lastAssistantText,
    pendingQuestion: cp.pendingQuestion ? { ...cp.pendingQuestion } : null,
    lastRunCmdIsDaemon: cp.lastRunCmdIsDaemon,
    lastStepIsMidTurn: cp.lastStepIsMidTurn,
    pendingTasks: new Map(
      Array.from(cp.pendingTasks.entries(), ([k, v]) => [k, { ...v }])
    ),
    pendingSubagents: new Map(
      Array.from(cp.pendingSubagents.entries(), ([k, v]) => [k, { ...v }])
    ),
    allTasksById: new Map(
      Array.from(cp.allTasksById.entries(), ([k, v]) => [k, { ...v }])
    ),
    recentBgCandidates: cp.recentBgCandidates.map((x) => ({ ...x })),
    pendingSubagentSpecs: cp.pendingSubagentSpecs.map((x) => ({ ...x }))
  };
}

function stripOuterQuotes(val) {
  let s = String(val ?? '').trim();
  if (
    (s.startsWith('"') && s.endsWith('"') && s.length >= 2) ||
    (s.startsWith("'") && s.endsWith("'") && s.length >= 2)
  ) {
    s = s.slice(1, -1).trim();
  }
  return s.replace(/\\"/g, '"').replace(/\\\\/g, '\\').trim();
}

function summarizeTaskExplanation(rawSummary, rawCommand, kind = 'task') {
  const cleanSum = cleanText(stripOuterQuotes(rawSummary), 140);
  if (cleanSum) {
    return cleanSum;
  }
  const cmd = stripOuterQuotes(rawCommand).replace(/\s+/g, ' ').trim();
  if (!cmd) {
    return kind === 'subagent'
      ? 'Delegated subagent task'
      : kind === 'timer'
        ? 'Scheduled timer'
        : 'Background terminal command';
  }
  if (kind === 'subagent') {
    return cleanText(cmd, 120);
  }
  const mTimer = cmd.match(/^Timer:\s*([^,]+),\s*Prompt:\s*(.+)$/i);
  if (mTimer) {
    return cleanText(`Timer (${mTimer[1].trim()}): ${mTimer[2].trim()}`, 130);
  }
  const mScript = cmd.match(
    /(?:node|python(?:\.exe)?|C:\\Python\d+\\python\.exe|powershell(?:\.exe)?|pwsh|bash|sh)\s+(?:-[A-Za-z0-9-]+\s+)*["']?([^\s"';|&]+\.(?:cjs|mjs|js|ts|py|ps1|sh))["']?/i
  );
  if (mScript) {
    const base = mScript[1].replace(/\\/g, '/').split('/').slice(-2).join('/');
    return cleanText(`Run ${base}`, 120);
  }
  if (/^git\s+/i.test(cmd)) {
    const gitSub = cmd.replace(/^git\s+(?:-C\s+["']?[^"'\s]+["']?\s+)?/i, '');
    return cleanText(`Git ${gitSub}`, 110);
  }
  if (/^(?:npm|pnpm|yarn|npx)\s+/i.test(cmd)) {
    return cleanText(`Run ${cmd}`, 110);
  }
  return cleanText(cmd, 110);
}

function extractXmlTagText(xml, tag) {
  const m = String(xml || '').match(new RegExp(`<${tag}>([\\s\\S]*?)<\\/${tag}>`, 'i'));
  return m ? m[1].trim() : '';
}

function parseClaudeTaskNotifications(rawText) {
  const results = [];
  const src = String(rawText || '');
  if (!src.includes('<task-notification>')) {
    return results;
  }
  const blockRe = /<task-notification>([\s\S]*?)<\/task-notification>/gi;
  let m;
  while ((m = blockRe.exec(src)) !== null) {
    const body = m[1];
    const taskId = extractXmlTagText(body, 'task-id');
    const toolUseId = extractXmlTagText(body, 'tool-use-id');
    const outputFile = extractXmlTagText(body, 'output-file');
    const status = extractXmlTagText(body, 'status').toLowerCase();
    const summary = extractXmlTagText(body, 'summary');
    const result = extractXmlTagText(body, 'result');
    const durationMs = Number(extractXmlTagText(body, 'duration_ms') || 0);
    if (taskId || toolUseId) {
      results.push({
        taskId,
        toolUseId,
        outputFile,
        status,
        summary,
        result,
        durationMs
      });
    }
  }
  return results;
}

function cleanClaudeUserPromptText(rawContent) {
  let text = '';
  if (typeof rawContent === 'string') {
    text = rawContent;
  } else if (Array.isArray(rawContent)) {
    for (const part of rawContent) {
      if (typeof part === 'string') {
        text += ` ${part}`;
      } else if (part && part.type === 'text' && typeof part.text === 'string') {
        text += ` ${part.text}`;
      }
    }
  }
  if (!text) {
    return '';
  }
  const stripped = text
    .replace(/<local-command-caveat>[\s\S]*?<\/local-command-caveat>/gi, ' ')
    .replace(/<system-reminder>[\s\S]*?<\/system-reminder>/gi, ' ')
    .replace(/<task-notification>[\s\S]*?<\/task-notification>/gi, ' ')
    .replace(/<agent-message\b[^>]*>[\s\S]*?<\/agent-message>/gi, ' ')
    .replace(/<command-name>[\s\S]*?<\/command-name>/gi, ' ')
    .replace(/<command-message>[\s\S]*?<\/command-message>/gi, ' ')
    .replace(/<command-args>[\s\S]*?<\/command-args>/gi, ' ')
    .replace(/<local-command-stdout>[\s\S]*?<\/local-command-stdout>/gi, ' ')
    .replace(/<ide_opened_file>[\s\S]*?<\/ide_opened_file>/gi, ' ')
    .replace(/<ide_selection>[\s\S]*?<\/ide_selection>/gi, ' ')
    .replace(/\[Request interrupted[^\]]*\]/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return cleanText(stripped, 120);
}

function parseAskQuestionsArg(rawQuestions) {
  if (!rawQuestions) return [];
  if (Array.isArray(rawQuestions)) return rawQuestions;
  if (typeof rawQuestions === 'string') {
    const trimmed = rawQuestions.trim();
    if (trimmed.startsWith('[')) {
      try {
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
  }
  return [];
}

function normalizeAskQuestionsList(rawQuestions) {
  const qs = parseAskQuestionsArg(rawQuestions);
  if (!qs.length) return [];
  return qs
    .map((q) => {
      if (!q || typeof q !== 'object') return null;
      const question = String(q.question || q.Question || q.header || '').trim();
      const header = String(q.header || '').trim();
      const isMultiSelect = Boolean(
        q.isMultiSelect || q.is_multi_select || q.IsMultiSelect || q.multiSelect
      );
      const rawOpts = Array.isArray(q.options || q.Options) ? q.options || q.Options : [];
      const options = rawOpts
        .map((o, idx) => {
          const text =
            typeof o === 'string'
              ? o.trim()
              : String(o?.label || o?.text || o?.Text || o?.id || '').trim();
          const description =
            typeof o === 'object' && o ? String(o.description || '').trim() : '';
          const id =
            typeof o === 'object' && o && (o.id || o.Id)
              ? String(o.id || o.Id)
              : String(idx + 1);
          return text ? { id, text, description } : null;
        })
        .filter(Boolean);
      if (!question && !options.length) return null;
      return {
        question: question || 'Select an option',
        header,
        isMultiSelect,
        options
      };
    })
    .filter(Boolean);
}

function extractQuestionSummary(rawQuestions) {
  const normalized = normalizeAskQuestionsList(rawQuestions);
  if (!normalized.length) return null;
  const qTexts = normalized.map((q) => q.question).filter(Boolean);
  const firstOpts = normalized[0].options.map((o) => o.text).filter(Boolean);
  return {
    questionText: cleanText(qTexts.join(' | '), 220),
    isMultiSelect: Boolean(normalized[0].isMultiSelect),
    options: firstOpts.slice(0, 8),
    questions: normalized.slice(0, 6)
  };
}

function buildClaudeToolPermissionQuestion(toolUse, suggestions = []) {
  if (!toolUse || typeof toolUse !== 'object') return null;
  const toolName = String(toolUse.toolName || toolUse.name || 'Tool').trim() || 'Tool';
  const inputs = toolUse.inputs || toolUse.input || {};
  const stepIndex = Number(toolUse.stepIndex || 0);
  const toolUseId = String(toolUse.toolUseId || toolUse.id || '');
  const at = Number(toolUse.at || Math.floor(Date.now() / 1000));

  if (toolName === 'AskUserQuestion' || toolName === 'ask_question') {
    const qSummary = extractQuestionSummary(inputs.questions);
    const qText =
      qSummary?.questionText ||
      cleanText(String(inputs.question || 'Claude is asking a question'), 220);
    return {
      stepIndex,
      toolUseId,
      toolName,
      questionText: qText,
      isMultiSelect: Boolean(qSummary?.isMultiSelect),
      options: qSummary?.options || [],
      questions: qSummary?.questions || [],
      at
    };
  }

  const low = toolName.toLowerCase();
  const baseFile = inputs.file_path
    ? String(inputs.file_path).split(/[/\\]/).pop() || String(inputs.file_path)
    : '';
  let promptHeader = `Do you want to proceed with ${toolName}?`;
  let codePreview = '';
  let description = String(inputs.description || '').trim();

  if (low === 'bash' || low === 'powershell') {
    promptHeader = `Allow this ${low} command?`;
    codePreview = String(inputs.command || '').trim();
  } else if (low === 'edit' || low === 'multiedit') {
    promptHeader = `Make this edit to ${baseFile || 'file'}?`;
    codePreview = String(inputs.file_path || '');
  } else if (low === 'write') {
    promptHeader = `Write to ${baseFile || 'file'}?`;
    codePreview = String(inputs.file_path || '');
  } else if (low === 'read') {
    promptHeader = `Allow reading from ${baseFile || 'file'}?`;
    codePreview = String(inputs.file_path || '');
  } else if (low === 'webfetch') {
    promptHeader = 'Allow fetching this url?';
    codePreview = String(inputs.url || '');
  } else if (low === 'websearch') {
    promptHeader = 'Allow searching for this query?';
    codePreview = String(inputs.query || '');
  } else if (low === 'exitplanmode') {
    promptHeader = 'Proceed with Claude’s plan?';
    codePreview = String(inputs.plan || '').slice(0, 400);
  } else {
    codePreview =
      String(inputs.command || inputs.file_path || inputs.url || inputs.query || '').trim() ||
      (Object.keys(inputs).length > 0 ? JSON.stringify(inputs).slice(0, 220) : '');
  }

  let allowAlwaysText = `Yes, allow ${toolName} for all projects`;
  if (low === 'exitplanmode') {
    allowAlwaysText = 'Yes, and manually approve edits';
  } else if (Array.isArray(suggestions) && suggestions.length > 0) {
    const firstRule = suggestions.find((s) => s && s.type === 'addRules' && s.rules?.[0])?.rules?.[0];
    if (firstRule) {
      const rc = String(firstRule.ruleContent || '')
        .replace(/:\*$/, '')
        .trim();
      const shortRule = rc
        ? rc.length > 26
          ? `${rc.slice(0, 23)}…`
          : rc
        : firstRule.toolName || toolName;
      allowAlwaysText = `Yes, allow ${shortRule} for all projects`;
    }
  } else if ((low === 'bash' || low === 'powershell') && codePreview) {
    const tokens = codePreview.split(/\s+/).filter(Boolean);
    const prefix = tokens.slice(0, 2).join(' ');
    const shortPrefix =
      prefix.length > 26 ? `${prefix.slice(0, 23)}…` : prefix || 'this command';
    allowAlwaysText = `Yes, allow ${shortPrefix} for all projects`;
  }

  const structuredOptions =
    low === 'exitplanmode'
      ? [
          {
            id: 'allow',
            text: 'Yes, and auto-accept',
            description: 'Approve plan and continue coding',
            isRecommended: true
          },
          {
            id: 'allow_always',
            text: 'Yes, and manually approve edits',
            description: 'Exit plan mode and review each edit',
            isRecommended: false
          },
          {
            id: 'deny',
            text: 'No, keep planning',
            description: 'Stay in plan mode',
            isRecommended: false
          }
        ]
      : [
          {
            id: 'allow',
            text: 'Yes',
            description: description || (codePreview ? 'Run this step once' : ''),
            isRecommended: true
          },
          {
            id: 'allow_always',
            text: allowAlwaysText,
            description: 'Save permission rule so Claude won’t ask again',
            isRecommended: false
          },
          {
            id: 'deny',
            text: 'No',
            description: 'Reject this tool use',
            isRecommended: false
          }
        ];

  const summaryDetail = codePreview
    ? `${promptHeader} — ${codePreview}${description ? ` (${description})` : ''}`
    : promptHeader;

  return {
    stepIndex,
    toolUseId,
    toolName,
    isToolPermission: true,
    codePreview,
    description,
    writeInPlaceholder: 'Tell Claude what to do instead',
    questionText: cleanText(summaryDetail, 240),
    isMultiSelect: false,
    options: structuredOptions.map((o) => o.text),
    questions: [
      {
        question: promptHeader,
        header: toolName,
        codePreview,
        description,
        isToolPermission: true,
        writeInPlaceholder: 'Tell Claude what to do instead',
        isMultiSelect: false,
        options: structuredOptions
      }
    ],
    at
  };
}

class AntigravityDataStore {
  constructor(options = {}) {
    this.getConfiguredHome =
      options.getConfiguredHome ||
      (() => {
        const cfg = vscode?.workspace
          ? vscode.workspace
              .getConfiguration('antigravityHub')
              .get('antigravityDataDir', '')
              .trim()
          : '';
        return cfg || getDefaultAntigravityHome();
      });
    this.getClaudeHome =
      options.getClaudeHome ||
      (() => {
        const cfg = vscode?.workspace
          ? vscode.workspace
              .getConfiguration('antigravityHub')
              .get('claudeDataDir', '')
              .trim()
          : '';
        return cfg || getDefaultClaudeHome();
      });
    this.getClaudeConfigPath = options.getClaudeConfigPath || getDefaultClaudeConfigPath;

    this.cachedQuota = null;
    this.cachedQuotaAt = 0;
    this.cachedAccount = null;
    this.lastQuotaWindowExpiryResetAt = 0;
    this.lastAgyStepSum = 0;
    this.pendingAgyQuotaRefreshOnStep = false;

    this.cachedClaudeQuota = null;
    this.cachedClaudeQuotaAt = 0;
    this.claudeQuotaBackoffUntil = 0;
    this.lastClaudeQuotaAttemptAt = 0;
    this.lastClaudeWindowExpiryResetAt = 0;
    this.lastClaudeTurnEpoch = 0;
    this.pendingClaudeTurnQuotaRefresh = false;
    this.cachedClaudeAccount = null;
    this.cachedClaudeVscState = null;
    this.cachedClaudeVscMtimeMs = 0;

    this.transcriptCache = new Map();
    this.claudeSessionCache = new Map();
    this.claudeFileById = new Map();
    this.reapedStalledTasks = new Set();
    this.deadPorts = new Map();
    this.parseCacheVersion = PARSE_CACHE_VERSION;
    this.parseCacheDirty = false;
    this.lastParseCacheSavedAt = 0;
    this._pendingParseCacheTimer = null;
    const persistedHub = this.readPersistentHubState();
    this.serverStartedAtSec =
      persistedHub?.startedAt > 0 ? persistedHub.startedAt : Math.floor(Date.now() / 1000);
    this.lastCredsPort = persistedHub?.port || 0;

    this.readPersistedClaudeQuotaCache();
    this.readPersistedParseCache();
  }

  getHomeDir() {
    return this.getConfiguredHome();
  }

  readPersistentHubState() {
    try {
      const filePath = path.join(this.getHomeDir(), 'bhf-persistent-hub.json');
      if (!fs.existsSync(filePath)) {
        return null;
      }
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      const port = Number(parsed?.port || 0);
      const csrfToken = String(parsed?.csrfToken || '').trim();
      const startedAt = Number(parsed?.startedAt || 0);
      const retiringHubs = Array.isArray(parsed?.retiringHubs)
        ? parsed.retiringHubs
            .filter(
              (h) =>
                h &&
                Number(h.port) > 0 &&
                typeof h.csrfToken === 'string' &&
                h.csrfToken.trim() &&
                Array.isArray(h.cascadeIds) &&
                h.cascadeIds.length > 0
            )
            .map((h) => ({
              pid: Number(h.pid || 0),
              port: Number(h.port),
              csrfToken: h.csrfToken.trim(),
              startedAt: Number(h.startedAt || 0),
              cascadeIds: h.cascadeIds.map((id) => String(id || '').trim()).filter(Boolean)
            }))
        : [];
      if (port > 0 && csrfToken) {
        return { port, csrfToken, startedAt, retiringHubs };
      }
    } catch {}
    return null;
  }

  getRetiringHubs() {
    const bridgeState = globalThis[Symbol.for('bhfirms.antigravityHub.bridgeState')];
    if (Array.isArray(bridgeState?.__bhfRetiringHubs) && bridgeState.__bhfRetiringHubs.length > 0) {
      return bridgeState.__bhfRetiringHubs
        .filter(
          (h) =>
            h &&
            Number(h.port) > 0 &&
            typeof h.csrfToken === 'string' &&
            h.csrfToken.trim() &&
            Array.isArray(h.cascadeIds) &&
            h.cascadeIds.length > 0
        )
        .map((h) => ({
          pid: Number(h.pid || 0),
          port: Number(h.port),
          csrfToken: String(h.csrfToken).trim(),
          startedAt: Number(h.startedAt || 0),
          cascadeIds: h.cascadeIds.map((id) => String(id || '').trim()).filter(Boolean)
        }));
    }
    const persisted = this.readPersistentHubState();
    return Array.isArray(persisted?.retiringHubs) ? persisted.retiringHubs : [];
  }

  async getServerCredentialsForCascade(cascadeId) {
    const cleanId = String(cascadeId || '').trim();
    if (cleanId) {
      for (const h of this.getRetiringHubs()) {
        if (Array.isArray(h.cascadeIds) && h.cascadeIds.includes(cleanId) && h.port > 0 && h.csrfToken) {
          return { port: h.port, csrfToken: h.csrfToken, startedAt: h.startedAt || 0 };
        }
      }
    }
    return this.getServerCredentials();
  }

  getClaudeHomeDir() {
    return this.getClaudeHome();
  }

  getClaudeQuotaCacheFilePath() {
    return path.join(this.getClaudeHomeDir(), '.theo-claude-quota-cache.json');
  }

  readPersistedClaudeQuotaCache(expectedEmail = '') {
    try {
      const cachePath = this.getClaudeQuotaCacheFilePath();
      if (!fs.existsSync(cachePath)) {
        return null;
      }
      const parsed = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
      const cleanExpected = String(expectedEmail || '').trim().toLowerCase();
      if (cleanExpected && parsed?.byEmail && parsed.byEmail[cleanExpected]?.quota) {
        const entry = parsed.byEmail[cleanExpected];
        this.cachedClaudeQuota = entry.quota;
        this.cachedClaudeQuotaAt = Number(entry.savedAt || 0);
        this.cachedClaudeQuotaEmail = cleanExpected;
        return entry.quota;
      }
      const cachedEmail = String(parsed?.email || '').trim().toLowerCase();
      if (cleanExpected && cachedEmail && cachedEmail !== cleanExpected) {
        return null;
      }
      const quota = parsed?.quota && typeof parsed.quota === 'object' ? parsed.quota : null;
      if (quota) {
        this.cachedClaudeQuota = quota;
        this.cachedClaudeQuotaAt = Number(parsed.savedAt || 0);
        this.cachedClaudeQuotaEmail = cachedEmail || cleanExpected;
      }
      return quota;
    } catch {
      return null;
    }
  }

  writePersistedClaudeQuotaCache(quotaObj, savedAtMs = Date.now(), email = '') {
    try {
      if (!quotaObj || typeof quotaObj !== 'object') {
        return;
      }
      const cachePath = this.getClaudeQuotaCacheFilePath();
      const cleanEmail = String(email || this.cachedClaudeQuotaEmail || '')
        .trim()
        .toLowerCase();
      let existing = {};
      try {
        if (fs.existsSync(cachePath)) {
          existing = JSON.parse(fs.readFileSync(cachePath, 'utf8')) || {};
        }
      } catch {}
      const byEmail =
        existing.byEmail && typeof existing.byEmail === 'object' ? { ...existing.byEmail } : {};
      if (cleanEmail) {
        byEmail[cleanEmail] = { savedAt: savedAtMs, quota: quotaObj };
        this.cachedClaudeQuotaEmail = cleanEmail;
      }
      fs.writeFileSync(
        cachePath,
        JSON.stringify({
          email: cleanEmail || existing.email || '',
          savedAt: savedAtMs,
          quota: quotaObj,
          byEmail
        }),
        'utf8'
      );
    } catch {}
  }

  getStoreParseCacheFilePath() {
    return path.join(this.getClaudeHomeDir(), '.theo-store-parse-cache.json');
  }

  readPersistedParseCache() {
    try {
      const cachePath = this.getStoreParseCacheFilePath();
      if (!fs.existsSync(cachePath)) {
        return;
      }
      const parsed = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
      if (!parsed || parsed.version !== PARSE_CACHE_VERSION) {
        return;
      }
      if (Array.isArray(parsed.transcripts)) {
        for (const [k, v] of parsed.transcripts) {
          if (k && v && typeof v === 'object' && v.data) {
            this.transcriptCache.set(k, v);
          }
        }
      }
      if (Array.isArray(parsed.claudeSessions)) {
        for (const [k, v] of parsed.claudeSessions) {
          if (k && v && typeof v === 'object' && v.data) {
            this.claudeSessionCache.set(k, v);
            if (v.data.id) {
              this.claudeFileById.set(v.data.id, k);
            }
          }
        }
      }
      if (Array.isArray(parsed.sqliteRows) && parsed.sqliteMtimeMs > 0) {
        this.cachedSqliteRows = parsed.sqliteRows;
        this.cachedSqliteMtimeMs = parsed.sqliteMtimeMs;
      }
      if (parsed.claudeVscState && parsed.claudeVscMtimeMs > 0) {
        this.cachedClaudeVscState = parsed.claudeVscState;
        this.cachedClaudeVscMtimeMs = parsed.claudeVscMtimeMs;
      }
    } catch {}
  }

  writePersistedParseCache(nowMs = Date.now()) {
    if (!this.parseCacheDirty || nowMs - (this.lastParseCacheSavedAt || 0) < 12000) {
      return;
    }
    if (this._pendingParseCacheTimer) {
      return;
    }
    this.parseCacheDirty = false;
    this.lastParseCacheSavedAt = nowMs;
    const timer = setTimeout(() => {
      this._pendingParseCacheTimer = null;
      try {
        const savedAtMs = Date.now();
        const cutoffSec = Math.floor(savedAtMs / 1000) - 32 * 86400;
        const transcripts = [];
        for (const [k, v] of this.transcriptCache.entries()) {
          if (!v || !v.data) continue;
          const prunedTurns = Array.isArray(v.data.turns)
            ? v.data.turns.filter((t) => Number(t?.at || 0) >= cutoffSec)
            : [];
          transcripts.push([
            k,
            {
              mtimeMs: v.mtimeMs,
              size: v.size,
              data: { ...v.data, turns: prunedTurns }
            }
          ]);
        }
        const claudeSessions = [];
        for (const [k, v] of this.claudeSessionCache.entries()) {
          if (!v || !v.data) continue;
          const prunedTurns = Array.isArray(v.data.turns)
            ? v.data.turns.filter((t) => Number(t?.at || 0) >= cutoffSec)
            : [];
          claudeSessions.push([
            k,
            {
              mtimeMs: v.mtimeMs,
              size: v.size,
              fullParse: v.fullParse,
              data: { ...v.data, turns: prunedTurns }
            }
          ]);
        }
        const payload = JSON.stringify({
          version: PARSE_CACHE_VERSION,
          savedAt: savedAtMs,
          sqliteMtimeMs: this.cachedSqliteMtimeMs || 0,
          sqliteRows: this.cachedSqliteRows || null,
          claudeVscMtimeMs: this.cachedClaudeVscMtimeMs || 0,
          claudeVscState: this.cachedClaudeVscState || null,
          transcripts,
          claudeSessions
        });
        const cachePath = this.getStoreParseCacheFilePath();
        fs.promises.writeFile(cachePath, payload, 'utf8').catch(() => {});
      } catch {}
    }, 30);
    if (typeof timer?.unref === 'function') {
      timer.unref();
    }
    this._pendingParseCacheTimer = timer;
  }

  hasQuotaWindowJustExpired(nowMs) {
    if (!this.cachedQuota || typeof this.cachedQuota !== 'object') {
      return false;
    }
    const nowSec = Math.floor(nowMs / 1000);
    let maxPassedReset = this.lastQuotaWindowExpiryResetAt;
    const groups = Array.isArray(this.cachedQuota.groups) ? this.cachedQuota.groups : [];
    for (const group of groups) {
      const buckets = Array.isArray(group?.buckets) ? group.buckets : [];
      for (const b of buckets) {
        const resetSec = parseIsoToEpochSeconds(b?.resetTime);
        if (resetSec > 0 && resetSec <= nowSec && resetSec > maxPassedReset) {
          maxPassedReset = resetSec;
        }
      }
    }
    if (maxPassedReset > this.lastQuotaWindowExpiryResetAt) {
      this.lastQuotaWindowExpiryResetAt = maxPassedReset;
      return true;
    }
    return false;
  }

  hasClaudeWindowJustExpired(nowMs) {
    if (!this.cachedClaudeQuota || typeof this.cachedClaudeQuota !== 'object') {
      return false;
    }
    const nowSec = Math.floor(nowMs / 1000);
    let maxPassedReset = this.lastClaudeWindowExpiryResetAt;
    const checkResetVal = (rawVal) => {
      if (!rawVal) return;
      const resetSec =
        typeof rawVal === 'number'
          ? rawVal > 1e11
            ? Math.floor(rawVal / 1000)
            : Math.floor(rawVal)
          : parseIsoToEpochSeconds(rawVal);
      if (resetSec > 0 && resetSec <= nowSec && resetSec > maxPassedReset) {
        maxPassedReset = resetSec;
      }
    };
    for (const key of [
      'five_hour',
      'seven_day',
      'seven_day_sonnet',
      'seven_day_opus',
      'seven_day_fable',
      'seven_day_overage_included'
    ]) {
      const w = this.cachedClaudeQuota[key];
      if (w && typeof w === 'object') {
        checkResetVal(w.resets_at ?? w.reset_at ?? w.resetsAt);
      }
    }
    if (Array.isArray(this.cachedClaudeQuota.limits)) {
      for (const lim of this.cachedClaudeQuota.limits) {
        if (lim && typeof lim === 'object') {
          checkResetVal(lim.resets_at ?? lim.reset_at ?? lim.resetsAt);
        }
      }
    }
    if (maxPassedReset > this.lastClaudeWindowExpiryResetAt) {
      this.lastClaudeWindowExpiryResetAt = maxPassedReset;
      return true;
    }
    return false;
  }

  getTranscriptLogPath(threadId, provider = '') {
    const cleanId = String(threadId || '').trim();
    if (!cleanId) {
      return '';
    }
    if (provider === 'claude' || this.claudeFileById.has(cleanId)) {
      const claudeFile = this.claudeFileById.get(cleanId);
      if (claudeFile && fs.existsSync(claudeFile)) {
        return claudeFile;
      }
    }
    const logsDir = path.join(this.getHomeDir(), 'brain', cleanId, '.system_generated', 'logs');
    const agyFullLog = path.join(logsDir, 'transcript_full.jsonl');
    if (fs.existsSync(agyFullLog)) {
      return agyFullLog;
    }
    const agyLog = path.join(logsDir, 'transcript.jsonl');
    if (fs.existsSync(agyLog)) {
      return agyLog;
    }
    const fallbackClaude = this.claudeFileById.get(cleanId);
    return fallbackClaude && fs.existsSync(fallbackClaude) ? fallbackClaude : agyFullLog;
  }

  markPortDead(port) {
    const cleanPort = Number(port || 0);
    if (cleanPort <= 0) {
      return;
    }
    if (!(this.deadPorts instanceof Map)) {
      this.deadPorts = new Map();
    }
    this.deadPorts.set(cleanPort, Date.now());
    if (this.cachedStandaloneCreds && Number(this.cachedStandaloneCreds.port) === cleanPort) {
      this.cachedStandaloneCreds = null;
      this.cachedStandaloneCredsAt = 0;
    }
  }

  isPortMarkedDead(port, ttlMs = 20000) {
    const cleanPort = Number(port || 0);
    if (cleanPort <= 0 || !(this.deadPorts instanceof Map)) {
      return false;
    }
    const failedAt = Number(this.deadPorts.get(cleanPort) || 0);
    if (!failedAt) {
      return false;
    }
    if (Date.now() - failedAt > ttlMs) {
      this.deadPorts.delete(cleanPort);
      return false;
    }
    return true;
  }

  async getServerCredentials() {
    const ext = vscode?.extensions
      ? vscode.extensions.getExtension('google.google-antigravity')
      : null;
    const bridgeState = globalThis[Symbol.for('bhfirms.antigravityHub.bridgeState')];
    try {
      if (ext && ext.isActive) {
        const api = ext.exports;
        let persistedHub = this.readPersistentHubState();
        const liveMgrPort = Number(bridgeState?.serverManager?.port || 0);
        const liveMgrCsrf = String(bridgeState?.serverManager?.csrfToken || '').trim();
        if (
          bridgeState?.attached &&
          liveMgrPort <= 0 &&
          (!persistedHub || this.isPortMarkedDead(persistedHub.port)) &&
          typeof bridgeState.ensureUpstreamAlive === 'function'
        ) {
          try {
            await bridgeState.ensureUpstreamAlive(persistedHub?.port || 0);
            persistedHub = this.readPersistentHubState();
          } catch {}
        }
        const refreshedMgrPort = Number(bridgeState?.serverManager?.port || liveMgrPort || 0);
        const refreshedMgrCsrf = String(
          bridgeState?.serverManager?.csrfToken || liveMgrCsrf || ''
        ).trim();
        const candidates = [
          persistedHub?.port && persistedHub?.csrfToken
            ? {
                port: Number(persistedHub.port),
                csrfToken: String(persistedHub.csrfToken).trim(),
                startedAt: Number(persistedHub.startedAt || 0)
              }
            : null,
          refreshedMgrPort > 0 && refreshedMgrCsrf
            ? { port: refreshedMgrPort, csrfToken: refreshedMgrCsrf, startedAt: 0 }
            : null,
          !bridgeState?.attached && Number(api?.port || 0) > 0 && String(api?.csrfToken || '').trim()
            ? {
                port: Number(api.port),
                csrfToken: String(api.csrfToken).trim(),
                startedAt: 0
              }
            : null
        ].filter(Boolean);
        for (const candidate of candidates) {
          if (candidate.port > 0 && candidate.csrfToken && !this.isPortMarkedDead(candidate.port)) {
            if (this.lastCredsPort && this.lastCredsPort !== candidate.port) {
              this.cachedAccount = null;
              this.cachedQuota = null;
              this.cachedQuotaAt = 0;
            }
            if (candidate.startedAt > 0) {
              this.serverStartedAtSec = candidate.startedAt;
            } else if (this.lastCredsPort && this.lastCredsPort !== candidate.port) {
              this.serverStartedAtSec = Math.floor(Date.now() / 1000);
            }
            this.lastCredsPort = candidate.port;
            return { port: candidate.port, csrfToken: candidate.csrfToken };
          }
        }
      }
    } catch {}

    if (
      this.cachedStandaloneCreds &&
      Date.now() - (this.cachedStandaloneCredsAt || 0) < 30000
    ) {
      return this.cachedStandaloneCreds;
    }

    const persistedHub = this.readPersistentHubState();
    if (persistedHub && persistedHub.port > 0 && persistedHub.csrfToken) {
      try {
        await this.callRpc(persistedHub.port, persistedHub.csrfToken, 'GetUserStatus', {}, 3500);
        if (this.lastCredsPort && this.lastCredsPort !== persistedHub.port) {
          this.cachedAccount = null;
          this.cachedQuota = null;
          this.cachedQuotaAt = 0;
        }
        if (persistedHub.startedAt > 0) {
          this.serverStartedAtSec = persistedHub.startedAt;
        }
        this.cachedStandaloneCreds = {
          port: persistedHub.port,
          csrfToken: persistedHub.csrfToken
        };
        this.cachedStandaloneCredsAt = Date.now();
        this.lastCredsPort = persistedHub.port;
        return this.cachedStandaloneCreds;
      } catch {}
    }

    try {
      if (ext && !ext.isActive) {
        const api = await ext.activate();
        const port = Number(api?.port || 0);
        const csrfToken = String(api?.csrfToken || '').trim();
        if (port > 0 && csrfToken) {
          this.lastCredsPort = port;
          return { port, csrfToken };
        }
      }
    } catch {}

    if (process.platform === 'win32') {
      try {
        const psCmd =
          "Get-CimInstance Win32_Process -Filter \"Name LIKE 'agy%' OR Name LIKE 'language_server%'\" | ForEach-Object { $p=$_.ProcessId; $n=$_.Name; $c=$_.CommandLine; $ports=(Get-NetTCPConnection -OwningProcess $p -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalPort) -join ','; Write-Output \"$n|$p|$ports|$c\" }";
        const { stdout } = await execFileAsync(
          'powershell.exe',
          ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psCmd],
          { timeout: 3500, windowsHide: true }
        );
        const lines = String(stdout || '')
          .split(/\r?\n/)
          .filter(Boolean)
          .sort((a, b) => (a.toLowerCase().startsWith('agy') ? -1 : 1) - (b.toLowerCase().startsWith('agy') ? -1 : 1));
        for (const line of lines) {
          const [, , portsStr, cmdLine] = line.split('|');
          const m = String(cmdLine || '').match(/--csrf_token(?:=|\s+)([^\s"]+)/i);
          if (!m) continue;
          const csrfToken = m[1].trim();
          const hubPortMatch = String(cmdLine || '').match(/--hub-port(?:=|\s+)(\d+)/i);
          const preferredPort = hubPortMatch ? Number(hubPortMatch[1]) : 0;
          const candidatePorts = String(portsStr || '')
            .split(',')
            .map((x) => Number(x.trim()))
            .filter((n) => n > 0)
            .sort((a, b) => (a === preferredPort ? -1 : b === preferredPort ? 1 : a - b));
          for (const port of candidatePorts) {
            try {
              await this.callRpc(port, csrfToken, 'GetUserStatus', {}, 3500);
              this.cachedStandaloneCreds = { port, csrfToken };
              this.cachedStandaloneCredsAt = Date.now();
              this.lastCredsPort = port;
              return this.cachedStandaloneCreds;
            } catch {}
          }
        }
      } catch {}
    }
    return null;
  }

  callRpc(port, csrfToken, method, bodyObj = {}, timeoutMs = 4500) {
    return new Promise((resolve, reject) => {
      const payload = JSON.stringify(bodyObj || {});
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port,
          path: `/exa.language_server_pb.LanguageServerService/${method}`,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Connect-Protocol-Version': '1',
            'x-codeium-csrf-token': csrfToken,
            'Content-Length': Buffer.byteLength(payload)
          },
          timeout: timeoutMs
        },
        (res) => {
          const chunks = [];
          res.on('data', (chunk) => chunks.push(chunk));
          res.on('end', () => {
            const text = Buffer.concat(chunks).toString('utf8');
            if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
              try {
                resolve(text ? JSON.parse(text) : {});
              } catch (err) {
                reject(err);
              }
            } else {
              reject(new Error(`RPC ${method} HTTP ${res.statusCode}: ${text.slice(0, 200)}`));
            }
          });
        }
      );
      req.on('timeout', () => {
        req.destroy(new Error(`RPC ${method} timed out`));
      });
      req.on('error', reject);
      req.write(payload);
      req.end();
    });
  }

  readClaudeLocalCredentials() {
    const claudeHome = this.getClaudeHomeDir();
    const configPath = this.getClaudeConfigPath();
    const credsPath = path.join(claudeHome, '.credentials.json');
    let claudeConfig = {};
    let credentials = {};
    try {
      if (fs.existsSync(configPath)) {
        claudeConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      }
    } catch {}
    try {
      if (fs.existsSync(credsPath)) {
        credentials = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
      }
    } catch {}
    return { claudeConfig, credentials };
  }

  fetchClaudeOauthUsage(accessToken, timeoutMs = 4500) {
    return new Promise((resolve, reject) => {
      if (!accessToken) {
        reject(new Error('Missing Claude OAuth accessToken'));
        return;
      }
      this.lastClaudeQuotaAttemptAt = Date.now();
      const req = https.request(
        {
          hostname: 'api.anthropic.com',
          path: '/api/oauth/usage',
          method: 'GET',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'anthropic-beta': 'oauth-2025-04-20',
            'Content-Type': 'application/json',
            'User-Agent': 'claude-code/2.1.301'
          },
          timeout: timeoutMs
        },
        (res) => {
          const chunks = [];
          res.on('data', (chunk) => chunks.push(chunk));
          res.on('end', () => {
            const text = Buffer.concat(chunks).toString('utf8');
            if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
              try {
                this.claudeQuotaBackoffUntil = 0;
                resolve(text ? JSON.parse(text) : {});
              } catch (err) {
                this.claudeQuotaBackoffUntil = Date.now() + 30000;
                reject(err);
              }
            } else {
              if (res.statusCode === 429) {
                const retryAfterSec = Math.max(
                  60,
                  Math.min(3600, Number(res.headers?.['retry-after']) || 300)
                );
                this.claudeQuotaBackoffUntil = Date.now() + retryAfterSec * 1000;
              } else {
                this.claudeQuotaBackoffUntil = Date.now() + 60000;
              }
              reject(new Error(`Claude OAuth usage HTTP ${res.statusCode}`));
            }
          });
        }
      );
      req.on('timeout', () => {
        this.claudeQuotaBackoffUntil = Date.now() + 30000;
        req.destroy(new Error('Claude OAuth usage timed out'));
      });
      req.on('error', (err) => {
        this.claudeQuotaBackoffUntil = Date.now() + 30000;
        reject(err);
      });
      req.end();
    });
  }

  async renameSessionOnServer(threadId, title, provider = '') {
    const cleanId = String(threadId || '').trim();
    const cleanTitle = String(title || '').trim();
    if (!cleanId || !cleanTitle) {
      return false;
    }

    if (provider === 'claude' || this.claudeFileById.has(cleanId)) {
      let ok = false;
      const filePath = this.claudeFileById.get(cleanId);
      if (filePath && fs.existsSync(filePath)) {
        try {
          const record = JSON.stringify({
            type: 'custom-title',
            sessionId: cleanId,
            customTitle: cleanTitle
          });
          fs.appendFileSync(filePath, `${record}\n`, 'utf8');
          ok = true;
        } catch {}
        try {
          const sidecarDir = path.join(path.dirname(filePath), cleanId);
          if (fs.existsSync(sidecarDir)) {
            fs.writeFileSync(
              path.join(sidecarDir, 'custom-title.json'),
              JSON.stringify({ customTitle: cleanTitle }),
              'utf8'
            );
          }
        } catch {}
      }
      try {
        if (vscode?.commands) {
          await vscode.commands.executeCommand('antigravityHub.claudeRenameSession', {
            id: cleanId,
            title: cleanTitle,
            skipCli: ok
          });
          ok = true;
        }
      } catch {}
      return ok;
    }

    const creds = await this.getServerCredentialsForCascade(cleanId);
    if (!creds) {
      return false;
    }
    try {
      await this.callRpc(creds.port, creds.csrfToken, 'UpdateConversationAnnotations', {
        cascadeIds: [cleanId],
        annotations: {
          title: cleanTitle
        },
        mergeAnnotations: true
      });
      return true;
    } catch {
      return false;
    }
  }

  async answerAntigravityQuestion(cascadeId, payload = {}) {
    const cleanId = String(cascadeId || '').trim();
    if (!cleanId) {
      return { ok: false, error: 'Missing cascadeId' };
    }
    const creds = await this.getServerCredentialsForCascade(cleanId);
    if (!creds) {
      return { ok: false, error: 'No language server credentials' };
    }
    try {
      const trajRes = await this.callRpc(creds.port, creds.csrfToken, 'GetCascadeTrajectory', {
        cascadeId: cleanId
      });
      const traj = trajRes?.trajectory;
      const steps = Array.isArray(traj?.steps) ? traj.steps : [];
      let targetStep = null;
      let targetIdx = -1;

      for (let i = steps.length - 1; i >= 0; i -= 1) {
        const st = steps[i];
        if (!st) continue;
        const isAskStep =
          st.type === 'CORTEX_STEP_TYPE_ASK_QUESTION' ||
          st.metadata?.toolCall?.name === 'ask_question' ||
          st.metadata?.toolCall?.name === 'default_api:ask_question' ||
          Boolean(st.askQuestion || st.requestedInteraction?.askQuestion);
        if (!isAskStep) continue;
        const completed =
          Array.isArray(st.completedInteractions) && st.completedInteractions.length > 0;
        const hasLaterTurnSteps =
          i < steps.length - 1 &&
          steps
            .slice(i + 1)
            .some(
              (s) =>
                s &&
                (s.type === 'CORTEX_STEP_TYPE_USER_INPUT' ||
                  s.type === 'CORTEX_STEP_TYPE_PLANNER_RESPONSE')
            );
        const isWaiting =
          !completed &&
          !hasLaterTurnSteps &&
          st.status !== 'CORTEX_STEP_STATUS_DONE' &&
          st.status !== 'CORTEX_STEP_STATUS_CANCELED';
        if (isWaiting) {
          targetStep = st;
          targetIdx = i;
          break;
        }
      }

      if (!targetStep) {
        return { ok: false, error: 'No ask_question step found in trajectory' };
      }

      const trajectoryId = String(
        targetStep?.metadata?.sourceTrajectoryStepInfo?.trajectoryId ||
          traj?.trajectoryId ||
          payload.trajectoryId ||
          ''
      ).trim();
      const stepIndex = Number(
        targetStep?.metadata?.sourceTrajectoryStepInfo?.stepIndex ??
          (targetIdx >= 0 ? targetIdx : payload.stepIndex ?? -1)
      );

      if (!trajectoryId || stepIndex < 0) {
        return { ok: false, error: 'Missing trajectoryId or stepIndex' };
      }

      let rawSpecQuestions =
        targetStep?.requestedInteraction?.askQuestion?.questions ||
        targetStep?.askQuestion?.questions ||
        [];
      if (
        (!Array.isArray(rawSpecQuestions) || rawSpecQuestions.length === 0) &&
        targetStep?.metadata?.toolCall?.argumentsJson
      ) {
        try {
          const parsedArgs = JSON.parse(targetStep.metadata.toolCall.argumentsJson);
          rawSpecQuestions = parseAskQuestionsArg(parsedArgs?.questions);
        } catch {}
      }
      const specQuestions = normalizeAskQuestionsList(
        rawSpecQuestions.length ? rawSpecQuestions : payload.questions || []
      );
      if (!specQuestions.length) {
        return { ok: false, error: 'No structured questions on ask_question step' };
      }

      const incomingResponses = Array.isArray(payload.responses) ? payload.responses : [];
      const fallbackSelectedIds = Array.isArray(payload.selectedOptionIds)
        ? payload.selectedOptionIds.map((x) => String(x))
        : [];
      const fallbackSelectedTexts = Array.isArray(payload.selectedTexts)
        ? payload.selectedTexts.map((x) => String(x).trim().toLowerCase())
        : [];
      const fallbackWriteIn = String(payload.writeInResponse ?? payload.writeIn ?? '').trim();
      const globalSkip = Boolean(payload.skipped);

      const responses = specQuestions.map((q, qIdx) => {
        const r = incomingResponses[qIdx] || {};
        const qOpts = Array.isArray(q.options)
          ? q.options.map((o, idx) => ({
              id: String(o.id || idx + 1),
              text: String(o.text || o.label || '')
            }))
          : [];
        if (globalSkip || r.skipped) {
          return {
            question: q.question,
            options: qOpts,
            isMultiSelect: Boolean(q.isMultiSelect),
            selectedOptionIds: [],
            writeInResponse: '',
            skipped: true
          };
        }
        let selIds = Array.isArray(r.selectedOptionIds)
          ? r.selectedOptionIds.map((x) => String(x))
          : qIdx === 0 && fallbackSelectedIds.length
            ? [...fallbackSelectedIds]
            : [];
        if (selIds.length === 0 && fallbackSelectedTexts.length > 0) {
          for (const opt of qOpts) {
            const lowTxt = opt.text.trim().toLowerCase();
            if (
              fallbackSelectedTexts.includes(lowTxt) ||
              fallbackSelectedTexts.includes(opt.id.toLowerCase())
            ) {
              selIds.push(opt.id);
            }
          }
        }
        const writeInVal = String(
          r.writeInResponse ?? (qIdx === 0 ? fallbackWriteIn : '') ?? ''
        ).trim();
        return {
          question: q.question,
          options: qOpts,
          isMultiSelect: Boolean(q.isMultiSelect),
          selectedOptionIds: selIds,
          writeInResponse: writeInVal,
          skipped: selIds.length === 0 && !writeInVal
        };
      });

      const rpcRes = await this.callRpc(
        creds.port,
        creds.csrfToken,
        'HandleCascadeUserInteraction',
        {
          cascadeId: cleanId,
          interaction: {
            trajectoryId,
            stepIndex,
            askQuestion: {
              responses,
              cancelled: false
            }
          }
        }
      );

      return {
        ok: true,
        method: 'HandleCascadeUserInteraction',
        trajectoryId,
        stepIndex,
        responses,
        rpcRes
      };
    } catch (err) {
      return { ok: false, error: err?.message || String(err) };
    }
  }

  readUserCancelledCascades() {
    const filePath = path.join(this.getHomeDir(), 'bhf-resumed-cascades.json');
    try {
      if (!fs.existsSync(filePath)) {
        return {};
      }
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch {
      return {};
    }
  }

  markCascadeUserCancelled(cascadeId, cancelled = true) {
    const cleanId = String(cascadeId || '').trim();
    if (!cleanId) {
      return false;
    }
    const homeDir = this.getHomeDir();
    const filePath = path.join(homeDir, 'bhf-resumed-cascades.json');
    try {
      if (!fs.existsSync(homeDir)) {
        fs.mkdirSync(homeDir, { recursive: true });
      }
      const map = this.readUserCancelledCascades();
      if (cancelled) {
        map[cleanId] = {
          stepIndex: 999999,
          reason: 'user_cancelled',
          resumedAt: Math.floor(Date.now() / 1000)
        };
      } else if (map[cleanId]?.reason === 'user_cancelled') {
        delete map[cleanId];
      }
      fs.writeFileSync(filePath, JSON.stringify(map, null, 2), 'utf8');
      return true;
    } catch {
      return false;
    }
  }

  async cancelSessionOnServer(threadId, provider = '') {
    const cleanId = String(threadId || '').trim();
    if (!cleanId) {
      return false;
    }
    this.markCascadeUserCancelled(cleanId, true);
    if (provider === 'claude' || this.claudeFileById.has(cleanId)) {
      try {
        if (vscode?.commands) {
          await vscode.commands.executeCommand('antigravityHub.claudeInterrupt', {
            id: cleanId
          });
          return true;
        }
      } catch {}
      return true;
    }

    const creds = await this.getServerCredentialsForCascade(cleanId);
    if (!creds) {
      return false;
    }
    let ok = false;
    try {
      await this.callRpc(
        creds.port,
        creds.csrfToken,
        'CancelCascadeInvocation',
        { cascadeId: cleanId, killBackgroundTasks: true },
        2500
      );
      ok = true;
    } catch {}
    try {
      await this.callRpc(
        creds.port,
        creds.csrfToken,
        'ForceStopCascadeTree',
        { conversationId: cleanId },
        2500
      );
      ok = true;
    } catch {}
    try {
      const transcriptPath = path.join(
        this.getHomeDir(),
        'brain',
        cleanId,
        '.system_generated',
        'logs',
        'transcript.jsonl'
      );
      if (fs.existsSync(transcriptPath)) {
        const runningStepIndices = [];
        const lines = fs.readFileSync(transcriptPath, 'utf8').split(/\r?\n/);
        for (const line of lines) {
          if (!line) continue;
          try {
            const obj = JSON.parse(line);
            if (obj.status === 'RUNNING' && typeof obj.step_index === 'number') {
              runningStepIndices.push(obj.step_index);
            }
          } catch {}
        }
        if (runningStepIndices.length > 0) {
          await this.callRpc(
            creds.port,
            creds.csrfToken,
            'CancelCascadeSteps',
            { cascadeId: cleanId, stepIndices: runningStepIndices },
            2500
          );
          ok = true;
        }
      }
    } catch {}
    return ok;
  }

  readCancelledBackgroundTasks() {
    const map = this.readUserCancelledCascades();
    const bucket = map?._cancelledTasks;
    return bucket && typeof bucket === 'object' ? bucket : {};
  }

  markBackgroundTaskCancelled(sessionId, taskId) {
    const cleanSid = String(sessionId || '').trim();
    const cleanTid = String(taskId || '').trim();
    if (!cleanSid || !cleanTid) {
      return false;
    }
    const homeDir = this.getHomeDir();
    const filePath = path.join(homeDir, 'bhf-resumed-cascades.json');
    try {
      if (!fs.existsSync(homeDir)) {
        fs.mkdirSync(homeDir, { recursive: true });
      }
      const map = this.readUserCancelledCascades();
      if (!map._cancelledTasks || typeof map._cancelledTasks !== 'object') {
        map._cancelledTasks = {};
      }
      const nowSec = Math.floor(Date.now() / 1000);
      map._cancelledTasks[`${cleanSid}:${cleanTid}`] = nowSec;
      const shortTid = cleanTid.split('/').pop();
      if (shortTid && shortTid !== cleanTid) {
        map._cancelledTasks[`${cleanSid}:${shortTid}`] = nowSec;
      }
      const keys = Object.keys(map._cancelledTasks);
      if (keys.length > 250) {
        for (const k of keys.slice(0, keys.length - 200)) {
          delete map._cancelledTasks[k];
        }
      }
      fs.writeFileSync(filePath, JSON.stringify(map, null, 2), 'utf8');
      return true;
    } catch {
      return false;
    }
  }

  readBackgroundTaskOutput(sessionId, provider = '', taskInfo = {}, maxChars = 6000) {
    const cleanSid = String(sessionId || '').trim();
    const tid = String(taskInfo?.id || '').trim();
    const kind = String(taskInfo?.kind || 'task');
    const stripAnsi = (txt) =>
      String(txt || '')
        .replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '')
        .replace(/\r\n/g, '\n');
    const readTailText = (targetPath, maxBytes = Math.max(8192, maxChars * 2)) => {
      try {
        if (!targetPath || !fs.existsSync(targetPath)) return '';
        const st = fs.statSync(targetPath);
        if (!st.isFile() || st.size <= 0) return '';
        if (st.size <= maxBytes) {
          return stripAnsi(fs.readFileSync(targetPath, 'utf8'));
        }
        const fd = fs.openSync(targetPath, 'r');
        try {
          const buf = Buffer.allocUnsafe(maxBytes);
          const n = fs.readSync(fd, buf, 0, maxBytes, st.size - maxBytes);
          return stripAnsi(buf.subarray(0, n).toString('utf8'));
        } finally {
          fs.closeSync(fd);
        }
      } catch {
        return '';
      }
    };
    const formatJsonlSubagentTrace = (rawJsonl, isAntigravity) => {
      const lines = String(rawJsonl || '')
        .split(/\n/)
        .filter((l) => l.trim().startsWith('{'));
      if (lines.length === 0) return '';
      const out = [];
      for (const line of lines.slice(-60)) {
        try {
          const obj = JSON.parse(line);
          if (isAntigravity) {
            if (obj.type === 'PLANNER_RESPONSE') {
              if (typeof obj.content === 'string' && obj.content.trim()) {
                out.push(obj.content.trim());
              }
              if (Array.isArray(obj.tool_calls)) {
                for (const tc of obj.tool_calls) {
                  const name = String(tc?.name || '').replace(/^default_api:/, '');
                  const sum = stripOuterQuotes(tc?.arguments?.toolSummary || tc?.arguments?.Path || '');
                  out.push(`> [${name}]${sum ? ` ${sum}` : ''}`);
                }
              }
            }
          } else if (obj.type === 'assistant' && Array.isArray(obj.message?.content)) {
            for (const b of obj.message.content) {
              if (b?.type === 'text' && b.text?.trim()) {
                out.push(b.text.trim());
              } else if (b?.type === 'tool_use') {
                const desc = b.input?.description || b.input?.file_path || b.input?.command || '';
                out.push(`> [${b.name || 'Tool'}]${desc ? ` ${String(desc).slice(0, 120)}` : ''}`);
              }
            }
          }
        } catch {}
      }
      return out.join('\n\n').slice(-maxChars);
    };

    const candidatePaths = [];
    if (taskInfo?.logPath) {
      candidatePaths.push(String(taskInfo.logPath));
    }
    if (provider !== 'claude' && cleanSid) {
      if (kind === 'subagent') {
        const subCid = String(taskInfo?.subagentConversationId || tid || '').trim();
        if (subCid) {
          candidatePaths.push(
            path.join(this.getHomeDir(), 'brain', subCid, '.system_generated', 'logs', 'transcript.jsonl')
          );
        }
      } else if (tid) {
        const shortId = tid.split('/').pop();
        candidatePaths.push(
          path.join(this.getHomeDir(), 'brain', cleanSid, '.system_generated', 'tasks', `${shortId}.log`)
        );
        if (typeof taskInfo?.stepIndex === 'number') {
          candidatePaths.push(
            path.join(
              this.getHomeDir(),
              'brain',
              cleanSid,
              '.system_generated',
              'steps',
              String(taskInfo.stepIndex),
              'output.txt'
            )
          );
        }
      }
    } else if (provider === 'claude' && cleanSid && tid) {
      const mainJsonl = this.claudeFileById.get(cleanSid);
      if (mainJsonl) {
        candidatePaths.push(
          path.join(path.dirname(mainJsonl), cleanSid, 'subagents', `agent-${tid}.jsonl`)
        );
      }
    }

    for (const p of candidatePaths) {
      const raw = readTailText(p, Math.max(16384, maxChars * 3));
      if (!raw.trim()) continue;
      const firstLine = raw.trim().split('\n').find((l) => l.trim().length > 0) || '';
      if (p.endsWith('.jsonl') || (kind === 'subagent' && firstLine.trim().startsWith('{'))) {
        const formatted = formatJsonlSubagentTrace(raw, provider !== 'claude');
        if (formatted.trim()) {
          return formatted;
        }
      }
      return raw.trim().slice(-maxChars);
    }

    return stripAnsi(taskInfo?.outputPreview || '').trim().slice(-maxChars);
  }

  async cancelBackgroundTaskOnServer(sessionId, provider = '', taskInfo = {}) {
    const cleanSid = String(sessionId || '').trim();
    const tid = String(taskInfo?.fullId || taskInfo?.id || '').trim();
    if (!cleanSid) {
      return { ok: false, error: 'Missing sessionId' };
    }
    if (tid) {
      this.markBackgroundTaskCancelled(cleanSid, tid);
    }

    if (provider === 'claude' || this.claudeFileById.has(cleanSid)) {
      let stopped = false;
      if (process.platform === 'win32' && taskInfo?.kind !== 'subagent' && taskInfo?.command) {
        const mScript = String(taskInfo.command).match(/([A-Za-z0-9_.-]+\.(?:cjs|mjs|js|py|ps1|sh))/i);
        const token = mScript ? mScript[1].replace(/'/g, '') : '';
        if (token.length >= 6) {
          try {
            const ps = `$procs = Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('node.exe','python.exe','powershell.exe','pwsh.exe','bash.exe') -and $_.CommandLine -like '*${token}*' }; foreach ($p in $procs) { & taskkill.exe /F /T /PID $p.ProcessId 2>$null | Out-Null }`;
            await execFileAsync(
              'powershell.exe',
              ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', ps],
              { timeout: 3500, windowsHide: true }
            );
            stopped = true;
          } catch {}
        }
      }
      try {
        if (vscode?.commands) {
          await vscode.commands.executeCommand('antigravityHub.claudeInterrupt', { id: cleanSid });
          stopped = true;
        }
      } catch {}
      return { ok: true, stopped };
    }

    const creds = await this.getServerCredentialsForCascade(cleanSid);
    if (!creds) {
      return { ok: false, error: 'Antigravity hub server not reachable' };
    }

    let ok = false;
    const subCid = String(
      taskInfo?.subagentConversationId || (taskInfo?.kind === 'subagent' ? taskInfo?.id : '') || ''
    ).trim();
    if (subCid) {
      try {
        await this.callRpc(
          creds.port,
          creds.csrfToken,
          'CancelCascadeInvocation',
          { cascadeId: subCid, killBackgroundTasks: true },
          2500
        );
        ok = true;
      } catch {}
      try {
        await this.callRpc(
          creds.port,
          creds.csrfToken,
          'ForceStopCascadeTree',
          { conversationId: subCid },
          2500
        );
        ok = true;
      } catch {}
    }

    const stepSet = new Set();
    if (typeof taskInfo?.stepIndex === 'number' && taskInfo.stepIndex >= 0) {
      stepSet.add(taskInfo.stepIndex);
    }
    try {
      const transcriptPath = path.join(
        this.getHomeDir(),
        'brain',
        cleanSid,
        '.system_generated',
        'logs',
        'transcript.jsonl'
      );
      if (fs.existsSync(transcriptPath)) {
        const shortId = tid.split('/').pop();
        const lines = fs.readFileSync(transcriptPath, 'utf8').split(/\r?\n/);
        for (const line of lines) {
          if (!line) continue;
          try {
            const obj = JSON.parse(line);
            if (typeof obj.step_index !== 'number') continue;
            if (
              obj.status === 'RUNNING' &&
              (!shortId ||
                (typeof obj.content === 'string' &&
                  (obj.content.includes(shortId) || (subCid && obj.content.includes(subCid)))))
            ) {
              stepSet.add(obj.step_index);
            }
          } catch {}
        }
      }
    } catch {}

    if (stepSet.size > 0) {
      try {
        await this.callRpc(
          creds.port,
          creds.csrfToken,
          'CancelCascadeSteps',
          { cascadeId: cleanSid, stepIndices: Array.from(stepSet) },
          2500
        );
        ok = true;
      } catch {}
    }
    return { ok: ok || Boolean(tid) };
  }

  async readSqliteFallbackSummaries(homeDir) {
    const dbPath = path.join(homeDir, 'conversation_summaries.db');
    if (!fs.existsSync(dbPath)) {
      return [];
    }
    try {
      const stat = fs.statSync(dbPath);
      const walPath = `${dbPath}-wal`;
      const walMtimeMs = fs.existsSync(walPath) ? fs.statSync(walPath).mtimeMs : 0;
      const effectiveMtimeMs = Math.max(stat.mtimeMs, walMtimeMs);
      if (this.cachedSqliteRows && this.cachedSqliteMtimeMs === effectiveMtimeMs) {
        return this.cachedSqliteRows;
      }
      const pyScript = [
        'import json, sqlite3, sys',
        'conn = sqlite3.connect(sys.argv[1])',
        'conn.row_factory = sqlite3.Row',
        'cur = conn.cursor()',
        'rows = cur.execute("SELECT conversation_id, title, preview, step_count, last_modified_time, workspace_uris, status, not_fully_idle, last_user_input_time FROM conversation_summaries WHERE COALESCE(nesting_depth, 0) = 0 AND COALESCE(parent_conversation_id, \'\') = \'\' ORDER BY last_modified_time DESC LIMIT 250").fetchall()',
        'print(json.dumps([dict(r) for r in rows]))'
      ].join('; ');
      const { stdout } = await execFileAsync('python', ['-c', pyScript, dbPath], {
        timeout: 3500,
        windowsHide: true
      });
      const parsed = JSON.parse(stdout || '[]');
      const rows = Array.isArray(parsed) ? parsed : [];
      this.cachedSqliteRows = rows;
      this.cachedSqliteMtimeMs = effectiveMtimeMs;
      this.parseCacheDirty = true;
      return rows;
    } catch {
      return this.cachedSqliteRows || [];
    }
  }

  noteRemovedClaudeGroupSessions(ids = []) {
    const clean = (Array.isArray(ids) ? ids : [ids])
      .map((x) => String(x || '').trim())
      .filter(Boolean);
    if (!clean.length) {
      return;
    }
    if (!(this.removedClaudeGroupSessionIds instanceof Set)) {
      this.removedClaudeGroupSessionIds = new Set();
    }
    for (const id of clean) {
      this.removedClaudeGroupSessionIds.add(id);
    }
    if (this.cachedClaudeVscState && Array.isArray(this.cachedClaudeVscState.sessionGroups)) {
      const rmSet = this.removedClaudeGroupSessionIds;
      this.cachedClaudeVscState.sessionGroups = this.cachedClaudeVscState.sessionGroups.map((g) =>
        g && Array.isArray(g.sessionIds)
          ? {
              ...g,
              sessionIds: g.sessionIds.filter((sid) => !rmSet.has(String(sid || '').trim()))
            }
          : g
      );
      this.parseCacheDirty = true;
    }
    this.cachedClaudeVscMtimeMs = 0;
  }

  async readClaudeVscStateFallback() {
    const appData =
      process.env.APPDATA ||
      (process.platform === 'darwin'
        ? path.join(os.homedir(), 'Library', 'Application Support')
        : path.join(os.homedir(), '.config'));
    const dbPath = path.join(appData, 'Code', 'User', 'globalStorage', 'state.vscdb');
    if (!fs.existsSync(dbPath)) {
      return { archivedIds: [], unarchivedAt: {}, sessionGroups: [], unreadIds: [] };
    }
    try {
      const stat = fs.statSync(dbPath);
      if (this.cachedClaudeVscState && this.cachedClaudeVscMtimeMs === stat.mtimeMs) {
        return this.cachedClaudeVscState;
      }
      const pyScript = [
        'import json, sqlite3, sys',
        'conn = sqlite3.connect(sys.argv[1])',
        'row = conn.execute("SELECT value FROM ItemTable WHERE key = \'Anthropic.claude-code\'").fetchone()',
        'print(row[0] if row else "{}")'
      ].join('; ');
      const { stdout } = await execFileAsync('python', ['-c', pyScript, dbPath], {
        timeout: 2500,
        windowsHide: true
      });
      const parsed = JSON.parse(stdout || '{}');
      const archivedIds = Array.isArray(parsed.hiddenSessionIds)
        ? parsed.hiddenSessionIds.filter(Boolean)
        : [];
      const unarchivedAt =
        parsed.sessionUnarchivedAt && typeof parsed.sessionUnarchivedAt === 'object'
          ? { ...parsed.sessionUnarchivedAt }
          : {};
      const rmSet =
        this.removedClaudeGroupSessionIds instanceof Set
          ? this.removedClaudeGroupSessionIds
          : new Set();
      const sessionGroups = [];
      const seenGroupIds = new Set();
      const unreadSet = new Set();
      for (const [k, v] of Object.entries(parsed)) {
        if (k.startsWith('sessionGroups:') && Array.isArray(v)) {
          for (const g of v) {
            if (g && g.id && !seenGroupIds.has(g.id)) {
              seenGroupIds.add(g.id);
              sessionGroups.push(
                Array.isArray(g.sessionIds) && rmSet.size > 0
                  ? {
                      ...g,
                      sessionIds: g.sessionIds.filter((sid) => !rmSet.has(String(sid || '').trim()))
                    }
                  : g
              );
            }
          }
        } else if (k.startsWith('sessionUnread:') && Array.isArray(v)) {
          for (const uid of v) {
            if (uid) {
              unreadSet.add(uid);
            }
          }
        }
      }
      const res = {
        archivedIds,
        unarchivedAt,
        sessionGroups,
        unreadIds: Array.from(unreadSet)
      };
      this.cachedClaudeVscState = res;
      this.cachedClaudeVscMtimeMs = stat.mtimeMs;
      this.parseCacheDirty = true;
      return res;
    } catch {
      return (
        this.cachedClaudeVscState || {
          archivedIds: [],
          unarchivedAt: {},
          sessionGroups: [],
          unreadIds: []
        }
      );
    }
  }

  parseTranscriptFile(transcriptPath) {
    try {
      const stat = fs.statSync(transcriptPath);
      const cached = this.transcriptCache.get(transcriptPath);
      if (cached && cached.mtimeMs === stat.mtimeMs && cached.size === stat.size) {
        return cached.data;
      }

      const TAIL_SLICE = 65536;
      const isOldTranscript = Date.now() - stat.mtimeMs > 31 * 86400 * 1000;
      let rawBuf = null;
      let scanStartOffset = 0;
      let restoredCp = null;

      if (
        !isOldTranscript &&
        cached?.checkpoint &&
        stat.size >= cached.checkpoint.byteOffset + 64 &&
        Buffer.isBuffer(cached.checkpoint.sigBuf)
      ) {
        const cpOffset = cached.checkpoint.byteOffset;
        const sigLen = cached.checkpoint.sigBuf.length;
        const readStart = cpOffset - sigLen;
        if (readStart >= 0) {
          const fd = fs.openSync(transcriptPath, 'r');
          try {
            const readLen = stat.size - readStart;
            const sliceBuf = Buffer.allocUnsafe(readLen);
            const bytesRead = fs.readSync(fd, sliceBuf, 0, readLen, readStart);
            if (
              bytesRead >= sigLen &&
              sliceBuf.subarray(0, sigLen).equals(cached.checkpoint.sigBuf)
            ) {
              rawBuf = sliceBuf.subarray(sigLen, bytesRead);
              scanStartOffset = cpOffset;
              restoredCp = cloneTranscriptCheckpoint(cached.checkpoint);
            }
          } finally {
            fs.closeSync(fd);
          }
        }
      }

      if (!rawBuf) {
        if (isOldTranscript && stat.size > TAIL_SLICE) {
          const fd = fs.openSync(transcriptPath, 'r');
          try {
            const tailBuf = Buffer.allocUnsafe(TAIL_SLICE);
            const tailOffset = Math.max(0, stat.size - TAIL_SLICE);
            const tailRead = fs.readSync(fd, tailBuf, 0, TAIL_SLICE, tailOffset);
            const firstNl = tailBuf.subarray(0, tailRead).indexOf(0x0a);
            rawBuf =
              firstNl >= 0 && firstNl + 1 < tailRead
                ? tailBuf.subarray(firstNl + 1, tailRead)
                : tailBuf.subarray(0, tailRead);
            scanStartOffset = tailOffset + (firstNl >= 0 ? firstNl + 1 : 0);
          } finally {
            fs.closeSync(fd);
          }
        } else {
          rawBuf = fs.readFileSync(transcriptPath);
          scanStartOffset = 0;
        }
      }

      const turns = restoredCp ? restoredCp.turns : [];
      let lastStatus = restoredCp ? restoredCp.lastStatus : '';
      let lastType = restoredCp ? restoredCp.lastType : '';
      let lastStepAt = restoredCp ? restoredCp.lastStepAt : 0;
      let maxStepIndex = restoredCp ? restoredCp.maxStepIndex : -1;
      let lastAssistantText = restoredCp ? restoredCp.lastAssistantText : '';
      let pendingQuestion = restoredCp ? restoredCp.pendingQuestion : null;
      let lastRunCmdIsDaemon = restoredCp ? restoredCp.lastRunCmdIsDaemon : false;
      let lastStepIsMidTurn = restoredCp ? restoredCp.lastStepIsMidTurn : false;
      const pendingTasks = restoredCp ? restoredCp.pendingTasks : new Map();
      const pendingSubagents = restoredCp ? restoredCp.pendingSubagents : new Map();
      const allTasksById = restoredCp ? restoredCp.allTasksById : new Map();
      let recentBgCandidates = restoredCp ? restoredCp.recentBgCandidates : [];
      let pendingSubagentSpecs = restoredCp ? restoredCp.pendingSubagentSpecs : [];

      const bufLen = rawBuf.length;
      const targetCpOffset =
        !isOldTranscript &&
        stat.size >= TRANSCRIPT_CHECKPOINT_MIN_BYTES &&
        (scanStartOffset === 0 || stat.size - scanStartOffset >= TRANSCRIPT_CHECKPOINT_TAIL_BYTES * 2)
          ? stat.size - TRANSCRIPT_CHECKPOINT_TAIL_BYTES
          : -1;
      let nextCheckpoint = restoredCp ? cached.checkpoint : null;
      let checkpointCapturedThisPass = false;
      let pos = 0;

      while (pos < bufLen) {
        const absPos = scanStartOffset + pos;
        if (
          !checkpointCapturedThisPass &&
          targetCpOffset > 0 &&
          absPos >= targetCpOffset &&
          absPos < stat.size &&
          pos >= TRANSCRIPT_CHECKPOINT_SIG_BYTES
        ) {
          checkpointCapturedThisPass = true;
          nextCheckpoint = cloneTranscriptCheckpoint({
            byteOffset: absPos,
            sigBuf: Buffer.from(rawBuf.subarray(pos - TRANSCRIPT_CHECKPOINT_SIG_BYTES, pos)),
            turns,
            lastStatus,
            lastType,
            lastStepAt,
            maxStepIndex,
            lastAssistantText,
            pendingQuestion,
            lastRunCmdIsDaemon,
            lastStepIsMidTurn,
            pendingTasks,
            pendingSubagents,
            allTasksById,
            recentBgCandidates,
            pendingSubagentSpecs
          });
        }
        const lineStart = pos;
        const nlIdx = rawBuf.indexOf(0x0a, pos);
        pos = nlIdx === -1 ? bufLen : nlIdx + 1;
        let lineEnd = nlIdx === -1 ? bufLen : nlIdx;
        if (lineEnd > lineStart && rawBuf[lineEnd - 1] === 0x0d) {
          lineEnd -= 1;
        }
        if (lineEnd <= lineStart || rawBuf[lineStart] !== 0x7b) {
          continue;
        }
        let step;
        try {
          step = JSON.parse(rawBuf.toString('utf8', lineStart, lineEnd));
        } catch {
          continue;
        }
        const stepIdx = Number(step.step_index || 0);
        if (stepIdx > maxStepIndex) {
          maxStepIndex = stepIdx;
        }
        const createdAt = parseIsoToEpochSeconds(step.created_at);
        if (createdAt > lastStepAt) {
          lastStepAt = createdAt;
        }
        if (step.type) {
          lastType = step.type;
        }
        if (step.status) {
          lastStatus = step.status;
        }
        const c = typeof step.content === 'string' ? step.content : '';
        if (step.type === 'USER_INPUT') {
          if (step.source !== 'SYSTEM' && !c.includes('<SYSTEM_MESSAGE')) {
            for (const [k, t] of pendingTasks.entries()) {
              if (stepIdx - (t.stepIndex || 0) > 25) {
                pendingTasks.delete(k);
              }
            }
            pendingQuestion = null;
            lastAssistantText = '';
            lastRunCmdIsDaemon = false;
            lastStepIsMidTurn = true;
            recentBgCandidates = [];
            pendingSubagentSpecs = [];
          }
        } else if (step.type === 'PLANNER_RESPONSE') {
          pendingQuestion = null;
          lastRunCmdIsDaemon = false;
          recentBgCandidates = [];
          pendingSubagentSpecs = [];
          if (typeof step.content === 'string' && step.content.trim()) {
            lastAssistantText = cleanText(step.content, 220);
          }
          const hasTools = Array.isArray(step.tool_calls) && step.tool_calls.length > 0;
          if (hasTools) {
            for (const tc of step.tool_calls) {
              const tcName = String(tc?.name || '');
              const args = tc.arguments || tc.args || {};
              if (tcName === 'run_command' || tcName.endsWith(':run_command')) {
                const rawDaemon = String(args.IsDaemon ?? '').replace(/^"|"$/g, '').trim().toLowerCase();
                const isDaemonArg = rawDaemon === 'true' || args.IsDaemon === true;
                if (isDaemonArg) {
                  lastRunCmdIsDaemon = true;
                }
                recentBgCandidates.push({
                  kind: 'task',
                  summary: stripOuterQuotes(args.toolSummary || ''),
                  command: stripOuterQuotes(args.CommandLine || ''),
                  isDaemon: isDaemonArg,
                  stepIndex: stepIdx
                });
              } else if (tcName === 'schedule' || tcName.endsWith(':schedule')) {
                const rawDaemon = String(args.IsDaemon ?? '').replace(/^"|"$/g, '').trim().toLowerCase();
                const isDaemonArg = rawDaemon === 'true' || args.IsDaemon === true;
                const cronExpr = stripOuterQuotes(args.CronExpression || '');
                const durSec = stripOuterQuotes(args.DurationSeconds || '');
                const schedLabel = cronExpr
                  ? `Scheduled cron (${cronExpr})`
                  : durSec
                    ? `Scheduled timer (${durSec}s)`
                    : 'Scheduled background timer';
                recentBgCandidates.push({
                  kind: 'timer',
                  summary: stripOuterQuotes(args.toolSummary || '') || schedLabel,
                  command: stripOuterQuotes(args.Prompt || ''),
                  isDaemon: isDaemonArg,
                  durationSec: Number(durSec) || 0,
                  timerCondition: stripOuterQuotes(args.TimerCondition || '').toLowerCase(),
                  stepIndex: stepIdx
                });
              } else if (tcName === 'invoke_subagent' || tcName.endsWith(':invoke_subagent')) {
                const topToolSummary = stripOuterQuotes(args.toolSummary || '');
                let rawSubs = [];
                if (Array.isArray(args.Subagents)) {
                  rawSubs = args.Subagents;
                } else if (typeof args.Subagents === 'string' && args.Subagents.trim().startsWith('[')) {
                  try {
                    rawSubs = JSON.parse(args.Subagents);
                  } catch {}
                } else if (args.Role || args.Prompt || args.TypeName) {
                  rawSubs = [args];
                }
                for (const sItem of rawSubs) {
                  if (!sItem || typeof sItem !== 'object') continue;
                  const role = stripOuterQuotes(sItem.Role || '');
                  const typeName = stripOuterQuotes(sItem.TypeName || 'subagent');
                  const promptTxt = stripOuterQuotes(sItem.Prompt || '');
                  pendingSubagentSpecs.push({
                    summary: role || topToolSummary || `Subagent (${typeName})`,
                    subagentType: typeName,
                    command: promptTxt,
                    stepIndex: stepIdx,
                    startedAt: createdAt || Math.floor(stat.mtimeMs / 1000)
                  });
                }
              } else if (tcName === 'manage_task' || tcName.endsWith(':manage_task')) {
                const act = stripOuterQuotes(args.Action || '').toLowerCase();
                const targetTask = stripOuterQuotes(args.TaskId || '');
                if (act === 'kill' && targetTask) {
                  for (const [k, item] of allTasksById.entries()) {
                    if (k === targetTask || item.id === targetTask || k.endsWith(`/${targetTask}`)) {
                      item.state = 'cancelled';
                      item.completedAt = createdAt || lastStepAt;
                      pendingTasks.delete(k);
                    }
                  }
                }
              } else if (tcName === 'manage_subagents' || tcName.endsWith(':manage_subagents')) {
                const act = stripOuterQuotes(args.Action || '').toLowerCase();
                if (act === 'kill_all') {
                  for (const [subId, item] of pendingSubagents.entries()) {
                    item.state = 'cancelled';
                    item.completedAt = createdAt || lastStepAt;
                    pendingSubagents.delete(subId);
                  }
                } else if (act === 'kill') {
                  const rawCids = Array.isArray(args.ConversationIds) ? args.ConversationIds : [];
                  for (const rawCid of rawCids) {
                    const cid = stripOuterQuotes(rawCid);
                    const sub = pendingSubagents.get(cid);
                    if (sub) {
                      sub.state = 'cancelled';
                      sub.completedAt = createdAt || lastStepAt;
                      pendingSubagents.delete(cid);
                    }
                  }
                }
              }
              if (tcName === 'ask_question' || tcName.endsWith(':ask_question')) {
                const qSummary = extractQuestionSummary(args.questions);
                const qText =
                  qSummary?.questionText ||
                  cleanText(String(args.question || step.content || 'Waiting for your answer'), 220);
                pendingQuestion = {
                  stepIndex: stepIdx,
                  questionText: qText,
                  isMultiSelect: Boolean(qSummary?.isMultiSelect),
                  options: qSummary?.options || [],
                  questions: qSummary?.questions || [],
                  at: createdAt || Math.floor(stat.mtimeMs / 1000)
                };
                if (!lastAssistantText && qText) {
                  lastAssistantText = qText;
                }
              }
            }
          }
          lastStepIsMidTurn = Boolean(hasTools && !pendingQuestion);
        } else if (step.type === 'ERROR_MESSAGE') {
          if (pendingQuestion && stepIdx >= pendingQuestion.stepIndex) {
            pendingQuestion = null;
          }
          lastStepIsMidTurn = false;
        } else if (step.type === 'GENERIC') {
          if (
            pendingQuestion &&
            stepIdx > pendingQuestion.stepIndex &&
            step.status !== 'RUNNING'
          ) {
            pendingQuestion = null;
          }
          lastStepIsMidTurn = !pendingQuestion;
        }
        if (
          step.type === 'GENERIC' &&
          !c.includes('\nShowing lines ') &&
          !c.includes('\nCommand output:\n') &&
          (c.includes('background task with task id:') || c.includes('Task ID:'))
        ) {
          const mId = c.match(
            /^(?:Tool is running as a background task with task id:|Command is running as a background task with task id:|Task ID:)\s*([0-9a-fA-F-]{8,}\/task-\d+)\s*$/im
          );
          if (mId) {
            const fullId = mId[1].trim();
            const shortId = fullId.split('/').pop() || fullId;
            const mDesc = c.match(/Task Description:\s*([^\r\n]+)/);
            const rawDesc = mDesc ? stripOuterQuotes(mDesc[1].trim()) : '';
            const mLog = c.match(
              /(?:Task logs are available at:|Task Log File:)\s*(file:\/\/\/[^\s\r\n]+)/i
            );
            const resolvedLogPath = mLog ? fileUriToPath(mLog[1].trim()) : '';
            let matchedCand = null;
            if (recentBgCandidates.length > 0) {
              const idxMatch = recentBgCandidates.findIndex(
                (cand) =>
                  cand.command &&
                  rawDesc &&
                  (rawDesc.includes(cand.command.slice(0, 32)) ||
                    cand.command.includes(rawDesc.slice(0, 32)))
              );
              matchedCand =
                idxMatch >= 0 ? recentBgCandidates.splice(idxMatch, 1)[0] : recentBgCandidates.shift();
            }
            const kind =
              matchedCand?.kind || (/^Timer:\s*/i.test(rawDesc) ? 'timer' : 'task');
            const summary = summarizeTaskExplanation(
              matchedCand?.summary || '',
              rawDesc || matchedCand?.command || '',
              kind
            );
            const commandText = (rawDesc || matchedCand?.command || '').slice(0, 500);
            const isDaemon =
              Boolean(matchedCand?.isDaemon) ||
              lastRunCmdIsDaemon ||
              /--watch|http\.server|server\.py|serve\.py|vite|next\s+dev|npm\s+run\s+dev|IsDaemon/i.test(
                rawDesc
              );
            const initialStatus =
              step.status === 'CANCELED' || step.status === 'CANCELLED'
                ? 'cancelled'
                : step.status && step.status !== 'RUNNING'
                  ? 'completed'
                  : 'running';
            const startedEpoch = createdAt || Math.floor(stat.mtimeMs / 1000);
            const mInlineLog = c.match(/Log output:\s*\r?\n([\s\S]*)$/i);
            const inlinePreview = mInlineLog
              ? mInlineLog[1]
                  .replace(/\r?\n?YOU MUST TAKE ONE OF THE FOLLOWING TWO ACTIONS[\s\S]*$/i, '')
                  .trim()
                  .slice(-700)
              : '';
            const durationSec = Number(matchedCand?.durationSec) || 0;
            const timerCondition = String(matchedCand?.timerCondition || '');
            const taskEntry = {
              id: shortId,
              fullId,
              kind,
              summary,
              command: commandText,
              stepIndex: stepIdx,
              startedAt: startedEpoch,
              completedAt: initialStatus === 'running' ? 0 : startedEpoch,
              state: initialStatus,
              isDaemon,
              durationSec,
              timerCondition,
              logPath: resolvedLogPath,
              outputPreview: inlinePreview
            };
            allTasksById.set(fullId, taskEntry);
            if (initialStatus === 'running') {
              pendingTasks.set(fullId, {
                taskId: fullId,
                shortId,
                kind,
                durationSec,
                timerCondition,
                startedAt: startedEpoch,
                stepIndex: stepIdx,
                rawDesc,
                summary,
                desc: summary || cleanText(rawDesc, 90),
                isDaemon,
                logPath: resolvedLogPath
              });
            }
          }
        } else if (
          step.type === 'GENERIC' &&
          pendingSubagentSpecs.length > 0 &&
          !c.includes('\nShowing lines ') &&
          !c.includes('\nCommand output:\n') &&
          c.includes('"conversationId"')
        ) {
          const cidMatches = [...c.matchAll(/"conversationId"\s*:\s*"([0-9a-fA-F-]{20,})"/g)];
          const logMatches = [...c.matchAll(/"logAbsoluteUri"\s*:\s*"(file:\/\/\/[^"]+)"/g)];
          cidMatches.forEach((mCid, idx) => {
            const subCid = mCid[1].trim();
            const spec = pendingSubagentSpecs[idx] || pendingSubagentSpecs[0];
            const logUri = logMatches[idx]?.[1] || '';
            const subItem = {
              id: subCid,
              fullId: subCid,
              subagentConversationId: subCid,
              kind: 'subagent',
              subagentType: spec?.subagentType || 'subagent',
              summary: summarizeTaskExplanation(spec?.summary || '', spec?.command || '', 'subagent'),
              command: String(spec?.command || '').slice(0, 500),
              stepIndex: spec?.stepIndex ?? stepIdx,
              startedAt: createdAt || spec?.startedAt || Math.floor(stat.mtimeMs / 1000),
              completedAt: 0,
              state: 'running',
              isDaemon: false,
              logPath: logUri ? fileUriToPath(logUri) : '',
              outputPreview: ''
            };
            allTasksById.set(subCid, subItem);
            pendingSubagents.set(subCid, subItem);
          });
          pendingSubagentSpecs = [];
        } else if (c) {
          if (c.includes('<SYSTEM_MESSAGE') && c.includes('sender=') && pendingTasks.size > 0) {
            const msgSenders = [...c.matchAll(/sender=([^\s>]+)/g)].map((x) => x[1]);
            if (msgSenders.length > 0) {
              for (const [tFullId, pItem] of [...pendingTasks.entries()]) {
                if (
                  pItem.kind === 'timer' &&
                  pItem.timerCondition &&
                  pItem.timerCondition !== 'never' &&
                  !msgSenders.includes(tFullId)
                ) {
                  const cond = pItem.timerCondition;
                  const matchedEarly =
                    cond === 'any' ||
                    msgSenders.some((s) => s.toLowerCase() === cond || s.toLowerCase().endsWith(`/${cond}`));
                  if (matchedEarly) {
                    pendingTasks.delete(tFullId);
                    const trackedTimer = allTasksById.get(tFullId);
                    if (trackedTimer) {
                      trackedTimer.state = 'completed';
                      trackedTimer.completedAt = createdAt || lastStepAt || trackedTimer.startedAt;
                    }
                  }
                }
              }
            }
          }
          if (c.includes('/task-')) {
            const senderRe = /sender=(\S+\/task-\d+)/g;
            let m;
            while ((m = senderRe.exec(c)) !== null) {
              const fullId = m[1];
              pendingTasks.delete(fullId);
              const tracked = allTasksById.get(fullId);
              if (tracked) {
                const failedExit = /Command exited with code [1-9]\d*/i.test(c);
                tracked.state = failedExit ? 'failed' : 'completed';
                tracked.completedAt = createdAt || lastStepAt || tracked.startedAt;
                const mRes = c.match(/finished with result:\s*\r?\n?([\s\S]*?)(?:<\/SYSTEM_MESSAGE>|$)/i);
                if (mRes && mRes[1].trim()) {
                  tracked.outputPreview = mRes[1].trim().slice(-900);
                }
              }
            }
            const cancelRe = /Task "(\S+\/task-\d+)" cancel/g;
            while ((m = cancelRe.exec(c)) !== null) {
              const fullId = m[1];
              pendingTasks.delete(fullId);
              const tracked = allTasksById.get(fullId);
              if (tracked) {
                tracked.state = 'cancelled';
                tracked.completedAt = createdAt || lastStepAt || tracked.startedAt;
              }
            }
          }
          if (pendingSubagents.size > 0 && c.includes('You have 0 active subagent(s)')) {
            for (const [subCid, subTracked] of pendingSubagents.entries()) {
              pendingSubagents.delete(subCid);
              subTracked.state = 'completed';
              subTracked.completedAt = createdAt || lastStepAt || subTracked.startedAt;
            }
          }
          if (pendingSubagents.size > 0 && c.includes('sender=')) {
            const subSenderRe = /sender=([0-9a-fA-F-]{20,})(?!\/task-)\b/g;
            let mSub;
            while ((mSub = subSenderRe.exec(c)) !== null) {
              const subCid = mSub[1];
              const subTracked = pendingSubagents.get(subCid);
              if (subTracked) {
                pendingSubagents.delete(subCid);
                subTracked.state = 'completed';
                subTracked.completedAt = createdAt || lastStepAt || subTracked.startedAt;
                const mBody = c.match(/content=([\s\S]*?)(?:<\/SYSTEM_MESSAGE>|$)/i);
                if (mBody && mBody[1].trim()) {
                  subTracked.outputPreview = mBody[1].trim().slice(0, 900);
                }
              }
            }
          }
        }
        const inputTokens = Number(step.input_tokens || 0);
        const cachedTokens = Number(step.cache_read_tokens || 0);
        const outputTokens = Number(step.output_tokens || 0);
        if (inputTokens > 0 || cachedTokens > 0 || outputTokens > 0 || step.type === 'USER_INPUT') {
          turns.push({
            at: createdAt || Math.floor(stat.mtimeMs / 1000),
            isUserTurn: step.type === 'USER_INPUT',
            inputTokens,
            cachedTokens,
            outputTokens,
            totalTokens: inputTokens + cachedTokens + outputTokens,
            provider: 'antigravity'
          });
        }
      }

      let pendingBgTask = null;
      let hasDaemonTaskOnly = false;
      for (const task of pendingTasks.values()) {
        if (task.isDaemon && maxStepIndex > task.stepIndex) {
          hasDaemonTaskOnly = true;
          continue;
        }
        if (maxStepIndex - task.stepIndex <= 25) {
          pendingBgTask = task;
        }
      }
      if (!pendingBgTask && pendingSubagents.size > 0) {
        for (const sub of pendingSubagents.values()) {
          if (maxStepIndex - sub.stepIndex <= 35) {
            pendingBgTask = {
              taskId: sub.id,
              shortId: 'subagent',
              kind: 'subagent',
              startedAt: sub.startedAt,
              stepIndex: sub.stepIndex,
              rawDesc: sub.command,
              summary: sub.summary,
              desc: sub.summary,
              isDaemon: false
            };
          }
        }
      }
      if (pendingBgTask) {
        hasDaemonTaskOnly = false;
      }

      // Settle any older running tasks from prior turns that were cleared by USER_INPUT
      for (const item of allTasksById.values()) {
        if (
          item.state === 'running' &&
          !pendingTasks.has(item.fullId) &&
          !pendingSubagents.has(item.fullId)
        ) {
          item.state = item.isDaemon ? 'completed' : 'completed';
          if (!item.completedAt) {
            item.completedAt = lastStepAt || item.startedAt;
          }
        }
      }
      const backgroundTasks = Array.from(allTasksById.values()).slice(-20);

      const stepCount = maxStepIndex >= 0 ? maxStepIndex + 1 : 0;
      const turnComplete = Boolean(
        lastType === 'PLANNER_RESPONSE' &&
          lastStatus === 'DONE' &&
          !lastStepIsMidTurn &&
          !pendingQuestion &&
          lastAssistantText
      );

      const data = {
        turns,
        lastStatus,
        lastType,
        lastStepAt: lastStepAt || Math.floor(stat.mtimeMs / 1000),
        maxStepIndex: Math.max(0, maxStepIndex),
        stepCount,
        turnComplete,
        lastAssistantText,
        pendingQuestion,
        pendingBgTask,
        backgroundTasks,
        hasDaemonTaskOnly,
        lastStepIsMidTurn
      };
      this.transcriptCache.set(transcriptPath, {
        mtimeMs: stat.mtimeMs,
        size: stat.size,
        checkpoint: nextCheckpoint || null,
        data
      });
      this.parseCacheDirty = true;
      return data;
    } catch {
      return null;
    }
  }

  parseClaudeSessionFile(filePath, sessionId, nowMs = Date.now(), isArchived = false) {
    try {
      const stat = fs.statSync(filePath);
      const isRecent = !isArchived && nowMs - stat.mtimeMs <= 8 * 86400 * 1000;
      const cached = this.claudeSessionCache.get(filePath);
      if (
        cached &&
        cached.mtimeMs === stat.mtimeMs &&
        cached.size === stat.size &&
        (cached.fullParse || !isRecent)
      ) {
        return cached.data;
      }

      const SLICE_BYTES = 32768;
      let lines = [];
      let fullParse = true;

      if (!isRecent && stat.size > SLICE_BYTES * 2) {
        fullParse = false;
        const fd = fs.openSync(filePath, 'r');
        try {
          const headBuf = Buffer.allocUnsafe(SLICE_BYTES);
          const headRead = fs.readSync(fd, headBuf, 0, SLICE_BYTES, 0);
          const headText = headBuf.subarray(0, headRead).toString('utf8');
          const headLines = headText.split(/\r?\n/);
          headLines.pop(); // drop potentially truncated last line of head

          const tailBuf = Buffer.allocUnsafe(SLICE_BYTES);
          const tailOffset = Math.max(SLICE_BYTES, stat.size - SLICE_BYTES);
          const tailRead = fs.readSync(fd, tailBuf, 0, SLICE_BYTES, tailOffset);
          const tailText = tailBuf.subarray(0, tailRead).toString('utf8');
          const tailLines = tailText.split(/\r?\n/);
          tailLines.shift(); // drop potentially truncated first line of tail

          lines = [...headLines, ...tailLines];
        } finally {
          fs.closeSync(fd);
        }
      } else {
        const content = fs.readFileSync(filePath, 'utf8');
        lines = content.split(/\r?\n/);
      }
      const fallbackEpoch = Math.floor(stat.mtimeMs / 1000);

      let customTitle = '';
      let aiTitle = '';
      let summaryTitle = '';
      let firstUserPrompt = '';
      let lastPrompt = '';
      let cwd = '';
      let branch = '';
      let rawModel = '';
      let createdAt = 0;
      let updatedAt = 0;
      let lastUserInputAt = 0;
      let stepCount = 0;
      let isProgrammatic = false;
      let continuedInSessionId = '';

      const userTurnTimestamps = [];
      const assistantUsageByMsgId = new Map();
      const claudeToolCandidatesByUseId = new Map();
      const claudeTasksList = [];
      const claudeTaskByRef = new Map();
      let lastAssistantText = '';
      let lastAssistantMsgId = '';
      let lastAssistantHadToolUse = false;
      let pendingQuestion = null;
      let pendingToolUse = null;
      let lastNonMetaType = '';
      let lastStopReason = '';

      const extractRawContentString = (rawContent) => {
        if (typeof rawContent === 'string') return rawContent;
        if (Array.isArray(rawContent)) {
          return rawContent
            .map((p) => {
              if (typeof p === 'string') return p;
              if (p && typeof p.text === 'string') return p.text;
              if (p && typeof p.content === 'string') return p.content;
              return '';
            })
            .filter(Boolean)
            .join('\n');
        }
        return '';
      };

      const applyTaskNotificationsFromText = (rawTxt, eventAtSec) => {
        if (!rawTxt) return;
        const notifs = parseClaudeTaskNotifications(rawTxt);
        for (const notif of notifs) {
          let target =
            (notif.taskId && claudeTaskByRef.get(notif.taskId)) ||
            (notif.toolUseId && claudeTaskByRef.get(notif.toolUseId)) ||
            null;
          if (!target && notif.taskId) {
            target = {
              id: notif.taskId,
              fullId: notif.taskId,
              kind: 'task',
              summary: summarizeTaskExplanation(notif.summary || '', '', 'task'),
              command: '',
              stepIndex: stepCount,
              startedAt: eventAtSec,
              completedAt: eventAtSec,
              state: 'completed',
              isDaemon: false,
              logPath: notif.outputFile || '',
              outputPreview: ''
            };
            claudeTasksList.push(target);
            claudeTaskByRef.set(notif.taskId, target);
          }
          if (target) {
            if (notif.status === 'failed' || notif.status === 'error') {
              target.state = 'failed';
            } else if (
              notif.status === 'killed' ||
              notif.status === 'cancelled' ||
              notif.status === 'canceled' ||
              notif.status === 'stopped'
            ) {
              target.state = 'cancelled';
            } else {
              target.state = 'completed';
            }
            target.completedAt = eventAtSec || target.startedAt;
            if (notif.outputFile && !target.logPath) {
              target.logPath = notif.outputFile;
            }
            if (notif.summary && (!target.summary || target.summary === 'Background terminal command')) {
              target.summary = summarizeTaskExplanation(notif.summary, target.command, target.kind);
            }
            if (notif.result) {
              target.outputPreview = notif.result.trim().slice(-900);
            }
          }
        }
        if (rawTxt.includes('<agent-message')) {
          const agentMsgRe = /<agent-message\s+from=["']([^"']+)["'][^>]*>([\s\S]*?)<\/agent-message>/gi;
          let mAgent;
          while ((mAgent = agentMsgRe.exec(rawTxt)) !== null) {
            const agentId = mAgent[1].trim();
            const bodyTxt = mAgent[2].trim();
            const target = claudeTaskByRef.get(agentId);
            if (target) {
              target.state = 'completed';
              target.completedAt = eventAtSec || target.startedAt;
              if (bodyTxt) {
                target.outputPreview = bodyTxt.slice(0, 900);
              }
            }
          }
        }
      };

      for (let i = 0; i < lines.length; i += 1) {
        const line = lines[i];
        if (!line || line[0] !== '{') {
          continue;
        }
        let rec;
        try {
          rec = JSON.parse(line);
        } catch {
          continue;
        }
        if (i === 0 && rec.isSidechain === true) {
          isProgrammatic = true;
        }
        if (
          rec.entrypoint === 'sdk-cli' ||
          rec.entrypoint === 'sdk-ts' ||
          rec.entrypoint === 'sdk-py' ||
          rec.sessionKind === 'daemon' ||
          rec.sessionKind === 'daemon-worker'
        ) {
          isProgrammatic = true;
        }

        const ts = parseIsoToEpochSeconds(rec.timestamp);
        if (ts > 0) {
          if (!createdAt || ts < createdAt) {
            createdAt = ts;
          }
          if (ts > updatedAt) {
            updatedAt = ts;
          }
        }
        if (rec.cwd && !cwd) {
          cwd = String(rec.cwd);
        }
        if (rec.gitBranch && rec.gitBranch !== 'HEAD') {
          branch = cleanText(rec.gitBranch, 60);
        }

        const type = rec.type;
        const eventSec = ts || fallbackEpoch;
        if (type === 'queue-operation' || type === 'attachment') {
          const rawQ =
            extractRawContentString(rec.content) ||
            extractRawContentString(rec.attachment?.prompt) ||
            '';
          applyTaskNotificationsFromText(rawQ, eventSec);
        }
        if (type === 'continued-in' && rec.continuedInSessionId) {
          continuedInSessionId = String(rec.continuedInSessionId).trim();
        } else if (type === 'custom-title' && rec.customTitle) {
          customTitle = cleanText(rec.customTitle, 120);
        } else if (type === 'ai-title' && rec.aiTitle) {
          aiTitle = cleanText(rec.aiTitle, 120);
        } else if (type === 'summary' && rec.summary) {
          summaryTitle = cleanText(rec.summary, 120);
        } else if (type === 'last-prompt' && rec.lastPrompt) {
          const cleaned = cleanClaudeUserPromptText(rec.lastPrompt);
          if (cleaned) {
            lastPrompt = cleaned;
          }
        } else if (type === 'user') {
          if (continuedInSessionId) {
            continuedInSessionId = '';
          }
          pendingQuestion = null;
          pendingToolUse = null;
          const rawUserContent = rec.message?.content ?? rec.content;
          applyTaskNotificationsFromText(extractRawContentString(rawUserContent), eventSec);
          if (Array.isArray(rawUserContent)) {
            for (const part of rawUserContent) {
              if (!part || typeof part !== 'object' || part.type !== 'tool_result') continue;
              const tuid = String(part.tool_use_id || '').trim();
              if (!tuid) continue;
              const resText = extractRawContentString(part.content);
              const cand = claudeToolCandidatesByUseId.get(tuid);
              const tur = rec.toolUseResult && typeof rec.toolUseResult === 'object' ? rec.toolUseResult : null;
              if (cand?.isBash) {
                const mBg = resText.match(/Command running in background with ID:\s*([A-Za-z0-9_-]+)/i);
                const bgId = (mBg ? mBg[1].trim() : '') || String(tur?.backgroundTaskId || '').trim();
                if (bgId || cand.explicitBg) {
                  const mOut = resText.match(/Output is being written to:\s*([^\r\n]+?)(?:\.\s*$|$)/i);
                  const outPath =
                    (mOut ? mOut[1].trim().replace(/\.\s*$/, '') : '') ||
                    String(tur?.outputFile || '').trim();
                  const effectiveId = bgId || tuid;
                  const isRunningAsync = Boolean(bgId);
                  const isDaemon = /--watch|http\.server|server\.py|serve\.py|vite|next\s+dev|npm\s+run\s+dev/i.test(
                    cand.command
                  );
                  let taskEntry = claudeTaskByRef.get(tuid) || claudeTaskByRef.get(effectiveId);
                  if (!taskEntry) {
                    taskEntry = {
                      id: effectiveId,
                      fullId: effectiveId,
                      toolUseId: tuid,
                      kind: 'task',
                      summary: summarizeTaskExplanation(cand.description, cand.command, 'task'),
                      command: cand.command,
                      stepIndex: cand.stepIndex,
                      startedAt: cand.startedAt || eventSec,
                      completedAt: isRunningAsync ? 0 : eventSec,
                      state: part.is_error ? 'failed' : isRunningAsync ? 'running' : 'completed',
                      isDaemon,
                      logPath: outPath,
                      outputPreview: isRunningAsync ? '' : resText.trim().slice(-900)
                    };
                    claudeTasksList.push(taskEntry);
                  } else {
                    taskEntry.id = effectiveId;
                    taskEntry.fullId = effectiveId;
                    if (outPath) taskEntry.logPath = outPath;
                    if (!isRunningAsync) {
                      taskEntry.state = part.is_error ? 'failed' : 'completed';
                      taskEntry.completedAt = eventSec;
                      taskEntry.outputPreview = resText.trim().slice(-900);
                    }
                  }
                  claudeTaskByRef.set(tuid, taskEntry);
                  claudeTaskByRef.set(effectiveId, taskEntry);
                }
              } else if (cand?.isSubagent) {
                const subEntry = claudeTaskByRef.get(tuid);
                if (subEntry) {
                  const isAsync =
                    /Async agent launched successfully/i.test(resText) ||
                    tur?.isAsync === true ||
                    tur?.status === 'async_launched';
                  const mAgent = resText.match(/agentId:\s*([A-Za-z0-9_-]+)/i);
                  const agentId = (mAgent ? mAgent[1].trim() : '') || String(tur?.agentId || '').trim();
                  const mOut = resText.match(/output_file:\s*([^\r\n]+)/i);
                  const outPath = (mOut ? mOut[1].trim() : '') || String(tur?.outputFile || '').trim();
                  if (agentId) {
                    subEntry.id = agentId;
                    subEntry.fullId = agentId;
                    subEntry.agentId = agentId;
                    claudeTaskByRef.set(agentId, subEntry);
                  }
                  if (outPath) {
                    subEntry.logPath = outPath;
                  }
                  if (!isAsync) {
                    subEntry.state = part.is_error ? 'failed' : 'completed';
                    subEntry.completedAt = eventSec;
                    subEntry.outputPreview = resText
                      .replace(/\s*<usage>[\s\S]*?<\/usage>\s*/gi, '')
                      .trim()
                      .slice(0, 900);
                  }
                }
              }
            }
          }
          if (!rec.isMeta) {
            lastNonMetaType = 'user';
            stepCount += 1;
            const turnAt = ts || fallbackEpoch;
            if (turnAt > lastUserInputAt) {
              lastUserInputAt = turnAt;
            }
            userTurnTimestamps.push(turnAt);
            const cleaned = cleanClaudeUserPromptText(rawUserContent);
            if (cleaned) {
              lastAssistantText = '';
              if (!firstUserPrompt) {
                firstUserPrompt = cleaned;
              }
            }
          }
        } else if (type === 'assistant') {
          if (continuedInSessionId && !rec.isApiErrorMessage && rec.message?.stop_reason) {
            continuedInSessionId = '';
          }
          lastNonMetaType = 'assistant';
          stepCount += 1;
          const msg = rec.message || {};
          const msgId = String(msg.id || rec.requestId || rec.uuid || `${stepCount}`);
          if (msgId !== lastAssistantMsgId) {
            pendingQuestion = null;
            pendingToolUse = null;
            lastAssistantHadToolUse = false;
            lastAssistantMsgId = msgId;
          }
          if (msg.stop_reason) {
            lastStopReason = String(msg.stop_reason);
          }
          if (Array.isArray(msg.content)) {
            for (const block of msg.content) {
              if (!block || typeof block !== 'object') continue;
              if (block.type === 'text' && typeof block.text === 'string' && block.text.trim()) {
                lastAssistantText = cleanText(block.text, 220);
              } else if (block.type === 'tool_use') {
                lastAssistantHadToolUse = true;
                const inp = block.input || {};
                const toolUseId = String(block.id || '');
                const toolName = String(block.name || 'Tool');
                pendingToolUse = {
                  stepIndex: stepCount,
                  toolUseId,
                  toolName,
                  inputs: inp,
                  at: ts || fallbackEpoch
                };
                if ((toolName === 'Bash' || toolName === 'bash') && toolUseId) {
                  claudeToolCandidatesByUseId.set(toolUseId, {
                    isBash: true,
                    explicitBg: Boolean(inp.run_in_background),
                    description: String(inp.description || ''),
                    command: String(inp.command || '').slice(0, 500),
                    stepIndex: stepCount,
                    startedAt: ts || fallbackEpoch
                  });
                  if (inp.run_in_background) {
                    const isDaemon = /--watch|http\.server|server\.py|serve\.py|vite|next\s+dev|npm\s+run\s+dev/i.test(
                      String(inp.command || '')
                    );
                    const bgEntry = {
                      id: toolUseId,
                      fullId: toolUseId,
                      toolUseId,
                      kind: 'task',
                      summary: summarizeTaskExplanation(inp.description || '', inp.command || '', 'task'),
                      command: String(inp.command || '').slice(0, 500),
                      stepIndex: stepCount,
                      startedAt: ts || fallbackEpoch,
                      completedAt: 0,
                      state: 'running',
                      isDaemon,
                      logPath: '',
                      outputPreview: ''
                    };
                    claudeTasksList.push(bgEntry);
                    claudeTaskByRef.set(toolUseId, bgEntry);
                  }
                } else if ((toolName === 'Agent' || toolName === 'Task') && toolUseId) {
                  const subType = String(inp.subagent_type || 'general-purpose');
                  const subSummary = summarizeTaskExplanation(
                    inp.description || `Subagent (${subType})`,
                    inp.prompt || '',
                    'subagent'
                  );
                  claudeToolCandidatesByUseId.set(toolUseId, {
                    isSubagent: true,
                    subagentType: subType,
                    description: String(inp.description || ''),
                    command: String(inp.prompt || '').slice(0, 500),
                    stepIndex: stepCount,
                    startedAt: ts || fallbackEpoch
                  });
                  const subEntry = {
                    id: toolUseId,
                    fullId: toolUseId,
                    toolUseId,
                    kind: 'subagent',
                    subagentType: subType,
                    summary: subSummary,
                    command: String(inp.prompt || '').slice(0, 500),
                    stepIndex: stepCount,
                    startedAt: ts || fallbackEpoch,
                    completedAt: 0,
                    state: 'running',
                    isDaemon: false,
                    logPath: '',
                    outputPreview: ''
                  };
                  claudeTasksList.push(subEntry);
                  claudeTaskByRef.set(toolUseId, subEntry);
                } else if (toolName === 'TaskStop' || toolName === 'KillShell') {
                  const stopId = String(inp.task_id || inp.shell_id || '').trim();
                  const target = stopId ? claudeTaskByRef.get(stopId) : null;
                  if (target) {
                    target.state = 'cancelled';
                    target.completedAt = ts || fallbackEpoch;
                  }
                }
                if (block.name === 'AskUserQuestion' || block.name === 'ask_question') {
                  const qSummary = extractQuestionSummary(inp.questions);
                  const qText =
                    qSummary?.questionText ||
                    cleanText(
                      String(inp.question || lastAssistantText || 'Claude is asking a question'),
                      220
                    );
                  pendingQuestion = {
                    stepIndex: stepCount,
                    toolUseId: String(block.id || ''),
                    questionText: qText,
                    isMultiSelect: Boolean(qSummary?.isMultiSelect),
                    options: qSummary?.options || [],
                    questions: qSummary?.questions || [],
                    at: ts || fallbackEpoch
                  };
                  if (!lastAssistantText && qText) {
                    lastAssistantText = qText;
                  }
                }
              }
            }
          }
          if (msg.model && typeof msg.model === 'string' && !msg.model.startsWith('<')) {
            rawModel = msg.model;
          }
          const u = msg.usage;
          if (u && typeof u === 'object') {
            const freshIn = Number(u.input_tokens || 0);
            const cachedIn =
              Number(u.cache_read_input_tokens || 0) +
              Number(u.cache_creation_input_tokens || 0);
            const outTokens = Number(u.output_tokens || 0);
            const total = freshIn + cachedIn + outTokens;
            if (total > 0) {
              const msgKey = String(msg.id || rec.requestId || rec.uuid || `${stepCount}`);
              const prev = assistantUsageByMsgId.get(msgKey);
              if (!prev || total >= prev.totalTokens) {
                assistantUsageByMsgId.set(msgKey, {
                  at: ts || fallbackEpoch,
                  isUserTurn: false,
                  inputTokens: freshIn + cachedIn,
                  cachedTokens: cachedIn,
                  outputTokens: outTokens,
                  totalTokens: total,
                  provider: 'claude'
                });
              }
            }
          }
        }
      }

      if (!customTitle) {
        try {
          const sidecarPath = path.join(path.dirname(filePath), sessionId, 'custom-title.json');
          if (fs.existsSync(sidecarPath)) {
            const sidecar = JSON.parse(fs.readFileSync(sidecarPath, 'utf8'));
            if (sidecar && typeof sidecar.customTitle === 'string') {
              customTitle = cleanText(sidecar.customTitle, 120);
            }
          }
        } catch {}
      }

      const turns = [];
      for (const userAt of userTurnTimestamps) {
        turns.push({
          at: userAt,
          isUserTurn: true,
          inputTokens: 0,
          cachedTokens: 0,
          outputTokens: 0,
          totalTokens: 0,
          provider: 'claude'
        });
      }
      for (const usageTurn of assistantUsageByMsgId.values()) {
        turns.push(usageTurn);
      }

      const derivedTitle =
        customTitle || aiTitle || summaryTitle || firstUserPrompt || lastPrompt || '';

      const turnComplete = Boolean(
        lastNonMetaType === 'assistant' &&
          (lastStopReason === 'end_turn' || lastStopReason === 'stop_sequence') &&
          !lastAssistantHadToolUse &&
          !pendingQuestion &&
          lastAssistantText
      );

      const backgroundTasks = claudeTasksList.slice(-20);
      let pendingBgTask = null;
      for (const t of backgroundTasks) {
        if (t.state === 'running' && !t.isDaemon) {
          pendingBgTask = {
            taskId: t.fullId || t.id,
            shortId: t.id,
            kind: t.kind,
            startedAt: t.startedAt,
            stepIndex: t.stepIndex,
            rawDesc: t.command,
            summary: t.summary,
            desc: t.summary,
            isDaemon: false,
            logPath: t.logPath || ''
          };
        }
      }

      const data = {
        id: sessionId,
        filePath,
        isProgrammatic,
        continuedInSessionId,
        hasContent: Boolean(stepCount > 0 || customTitle || aiTitle || summaryTitle),
        title: derivedTitle || 'Claude session',
        customTitle,
        rawTitle: derivedTitle || 'Claude session',
        summary: summaryTitle || firstUserPrompt || derivedTitle || 'Claude session',
        cwd,
        workspaceLabel: formatWorkspaceLabel(cwd),
        branch,
        model: formatClaudeModelLabel(rawModel),
        rawModel,
        createdAt: createdAt || fallbackEpoch,
        updatedAt: updatedAt || fallbackEpoch,
        lastUserInputAt: lastUserInputAt || updatedAt || fallbackEpoch,
        stepCount,
        turnComplete,
        lastAssistantHadToolUse,
        lastAssistantText,
        pendingQuestion,
        pendingToolUse,
        pendingBgTask,
        backgroundTasks,
        lastNonMetaType,
        lastStopReason,
        turns
      };

      this.claudeSessionCache.set(filePath, {
        mtimeMs: stat.mtimeMs,
        size: stat.size,
        fullParse,
        data
      });
      this.parseCacheDirty = true;
      return data;
    } catch {
      return null;
    }
  }

  _buildClaudeScanContext(claudeHomeDir, options = {}) {
    const projectsDir = path.join(claudeHomeDir, 'projects');
    const customTitles = options.customTitles || {};
    const archivedSet = options.archivedSet || new Set();
    const threadGroups = options.threadGroups || {};
    const liveSnap = options.claudeLive || {};
    const nowMs = options.nowMs || Date.now();
    const nowSec = Math.floor(nowMs / 1000);
    const cancelledByUserMap = this.readUserCancelledCascades();
    const cancelledTasksMap = cancelledByUserMap?._cancelledTasks || {};

    const liveStateById = new Map();
    if (Array.isArray(liveSnap.sessionStates)) {
      for (const item of liveSnap.sessionStates) {
        if (item?.sessionId) {
          liveStateById.set(item.sessionId, item);
        }
      }
    }
    const elsewhereIds = new Set(
      Array.isArray(liveSnap.liveElsewhere)
        ? liveSnap.liveElsewhere.map((item) => item?.sessionId).filter(Boolean)
        : []
    );
    const openTabIds = new Set(
      Array.isArray(liveSnap.openTabs)
        ? liveSnap.openTabs.map((item) => item?.id).filter(Boolean)
        : []
    );
    const claudeUnreadSet = new Set(
      Array.isArray(liveSnap.unreadIds) ? liveSnap.unreadIds.filter(Boolean) : []
    );
    const pendingPermBySessionId = new Map();
    if (Array.isArray(liveSnap.pendingPermissions)) {
      for (const perm of liveSnap.pendingPermissions) {
        if (perm?.sessionId) {
          pendingPermBySessionId.set(perm.sessionId, perm);
        }
      }
    }

    return {
      projectsDir,
      customTitles,
      archivedSet,
      threadGroups,
      nowMs,
      nowSec,
      cancelledByUserMap,
      cancelledTasksMap,
      liveStateById,
      elsewhereIds,
      openTabIds,
      claudeUnreadSet,
      pendingPermBySessionId,
      threadsMap: new Map(),
      turnsBySessionId: new Map()
    };
  }

  _ingestSingleClaudeFile(ctx, projPath, fileEntry, fileNamesSet) {
    if (!fileEntry.isFile() || !fileEntry.name.endsWith('.jsonl') || fileEntry.name.startsWith('agent-')) {
      return;
    }
    const sessionId = fileEntry.name.slice(0, -'.jsonl'.length);
    if (!sessionId) {
      return;
    }
    const {
      customTitles,
      archivedSet,
      threadGroups,
      nowMs,
      nowSec,
      cancelledByUserMap,
      cancelledTasksMap,
      liveStateById,
      elsewhereIds,
      openTabIds,
      claudeUnreadSet,
      pendingPermBySessionId,
      threadsMap,
      turnsBySessionId
    } = ctx;

    const fullPath = path.join(projPath, fileEntry.name);
    this.claudeFileById.set(sessionId, fullPath);

    const isArchived = archivedSet.has(sessionId);
    const parsed = this.parseClaudeSessionFile(fullPath, sessionId, nowMs, isArchived);
    if (!parsed) {
      return;
    }
    if (Array.isArray(parsed.turns) && parsed.turns.length > 0) {
      turnsBySessionId.set(sessionId, parsed.turns);
    }

    if (parsed.isProgrammatic && !openTabIds.has(sessionId) && !liveStateById.has(sessionId)) {
      return;
    }
    if (
      parsed.continuedInSessionId &&
      fileNamesSet.has(`${parsed.continuedInSessionId}.jsonl`) &&
      !openTabIds.has(sessionId)
    ) {
      return;
    }
    if (!parsed.hasContent && !openTabIds.has(sessionId) && !liveStateById.has(sessionId)) {
      return;
    }

    const liveInfo = liveStateById.get(sessionId);
    const hasLivePanelState = Boolean(liveInfo);
    const isRunningElsewhere = elsewhereIds.has(sessionId);
    const cancelEntry = cancelledByUserMap[sessionId];
    const isClaudeCancelled =
      cancelEntry?.reason === 'user_cancelled' &&
      Number(cancelEntry.resumedAt || 0) >= Number(parsed.lastUserInputAt || 0) - 2 &&
      nowSec - Number(cancelEntry.resumedAt || 0) < 300;
    const livePerm = pendingPermBySessionId.get(sessionId) || null;
    const isWaitingInput = Boolean(
      !isClaudeCancelled &&
        (liveInfo?.state === 'waiting_input' ||
          liveInfo?.state === 'waiting' ||
          liveInfo?.hasOutstandingRequest ||
          livePerm)
    );
    const hasFreshPendingQuestion = Boolean(
      !isClaudeCancelled &&
        parsed.pendingQuestion &&
        nowSec - Number(parsed.pendingQuestion.at || 0) < 86400 &&
        (hasLivePanelState ? isWaitingInput : !parsed.turnComplete)
    );
    let effectivePendingQuestion = hasFreshPendingQuestion ? parsed.pendingQuestion : null;
    if (!effectivePendingQuestion && isWaitingInput) {
      const sourceTool = livePerm
        ? {
            stepIndex: parsed.stepCount,
            toolUseId: livePerm.toolUseId || parsed.pendingToolUse?.toolUseId || '',
            toolName: livePerm.toolName || parsed.pendingToolUse?.toolName || 'Tool',
            inputs:
              livePerm.inputs && Object.keys(livePerm.inputs).length > 0
                ? livePerm.inputs
                : parsed.pendingToolUse?.inputs || {},
            at: Math.floor((livePerm.createdAt || nowMs) / 1000)
          }
        : parsed.pendingToolUse;
      if (sourceTool) {
        effectivePendingQuestion = buildClaudeToolPermissionQuestion(
          sourceTool,
          livePerm?.suggestions || []
        );
        if (livePerm?.id && effectivePendingQuestion) {
          effectivePendingQuestion.approvalId = livePerm.id;
        }
      }
    }
    let status = 'CASCADE_RUN_STATUS_IDLE';
    let notFullyIdle = false;
    if (isClaudeCancelled) {
      status = 'CASCADE_RUN_STATUS_IDLE';
      notFullyIdle = false;
    } else if (isWaitingInput || Boolean(effectivePendingQuestion)) {
      status = 'WAITING_FOR_USER';
    } else if (
      liveInfo?.state === 'working' ||
      liveInfo?.state === 'running' ||
      liveInfo?.state === 'thinking' ||
      isRunningElsewhere ||
      (!parsed.turnComplete &&
        (parsed.lastNonMetaType === 'user' ||
          parsed.lastStopReason === 'tool_use' ||
          parsed.lastAssistantHadToolUse) &&
        nowSec - Number(parsed.updatedAt || 0) <= 90)
    ) {
      status = 'CASCADE_RUN_STATUS_RUNNING';
      notFullyIdle = true;
    }

    const userCustomTitle = cleanText(customTitles[sessionId] || '', 120);
    const liveTitle = cleanText(liveInfo?.title || '', 120);
    const effectiveTitle =
      userCustomTitle || parsed.customTitle || liveTitle || parsed.title || 'Claude session';

    const claudeBgTasks = Array.isArray(parsed.backgroundTasks)
      ? parsed.backgroundTasks.map((t) => {
          const copy = { ...t };
          const cKey1 = `${sessionId}:${copy.id}`;
          const cKey2 = `${sessionId}:${copy.fullId || ''}`;
          if (
            copy.state === 'running' &&
            (isClaudeCancelled ||
              Number(cancelledTasksMap[cKey1] || 0) >= Number(copy.startedAt || 0) - 2 ||
              (copy.fullId && Number(cancelledTasksMap[cKey2] || 0) >= Number(copy.startedAt || 0) - 2))
          ) {
            copy.state = 'cancelled';
            copy.completedAt = copy.completedAt || nowSec;
          } else if (copy.state === 'running') {
            let lastTouchSec = Math.max(Number(copy.startedAt || 0), Number(parsed.updatedAt || 0));
            if (copy.logPath) {
              try {
                if (fs.existsSync(copy.logPath)) {
                  const lStat = fs.statSync(copy.logPath);
                  lastTouchSec = Math.max(lastTouchSec, Math.floor(lStat.mtimeMs / 1000));
                }
              } catch {}
            }
            const idleSec = Math.max(0, nowSec - lastTouchSec);
            const isSessionOpenOrLive = openTabIds.has(sessionId) || isRunningElsewhere;
            if (status !== 'CASCADE_RUN_STATUS_RUNNING') {
              if (!copy.isDaemon && idleSec > 600) {
                copy.state = 'completed';
                copy.completedAt = lastTouchSec;
              } else if (
                copy.isDaemon &&
                ((!isSessionOpenOrLive && idleSec > 180) || idleSec > 1800)
              ) {
                copy.state = 'completed';
                copy.completedAt = lastTouchSec;
              } else if (!copy.isDaemon && idleSec >= 240) {
                copy.state = 'stalled';
              }
            }
          }
          return copy;
        })
      : [];
    const activeClaudeBg = [...claudeBgTasks]
      .reverse()
      .find((t) => t.state === 'running' && !t.isDaemon);
    let claudeBgTaskSummary = null;
    if (activeClaudeBg && !isClaudeCancelled) {
      claudeBgTaskSummary = {
        state: 'running',
        stalled: false,
        id: activeClaudeBg.id,
        kind: activeClaudeBg.kind,
        summary: activeClaudeBg.summary,
        desc: activeClaudeBg.summary,
        startedAt: activeClaudeBg.startedAt
      };
      if (status === 'CASCADE_RUN_STATUS_IDLE' && nowSec - Number(activeClaudeBg.startedAt || 0) < 1800) {
        status = 'CASCADE_RUN_STATUS_RUNNING';
        notFullyIdle = true;
      }
    }

    const existing = threadsMap.get(sessionId);
    if (!existing || parsed.updatedAt >= existing.updatedAt) {
      threadsMap.set(sessionId, {
        id: sessionId,
        provider: 'claude',
        title: effectiveTitle,
        customTitle: userCustomTitle || parsed.customTitle,
        rawTitle: parsed.rawTitle,
        summary: parsed.summary,
        cwd: parsed.cwd,
        workspaceLabel: parsed.workspaceLabel,
        branch: parsed.branch,
        model: parsed.model || 'Claude',
        createdAt: parsed.createdAt,
        updatedAt: parsed.updatedAt,
        lastUserInputAt: parsed.lastUserInputAt,
        lastUserViewAt: 0,
        stepCount: Math.max(1, parsed.stepCount),
        turnComplete: Boolean(parsed.turnComplete && !isClaudeCancelled && status === 'CASCADE_RUN_STATUS_IDLE'),
        lastAssistantText: parsed.lastAssistantText || '',
        pendingQuestion: effectivePendingQuestion,
        pendingToolUse: parsed.pendingToolUse || null,
        bgTask: claudeBgTaskSummary,
        backgroundTasks: claudeBgTasks,
        status,
        notFullyIdle,
        elsewhere: isRunningElsewhere && !openTabIds.has(sessionId),
        claudeUnread: claudeUnreadSet.has(sessionId),
        terminationReason: '',
        archived: isArchived,
        groupId: threadGroups[sessionId] || '',
        source: 'claude-jsonl'
      });
    }
  }

  scanClaudeSessions(claudeHomeDir, options = {}) {
    const ctx = this._buildClaudeScanContext(claudeHomeDir, options);
    if (fs.existsSync(ctx.projectsDir)) {
      let projDirs = [];
      try {
        projDirs = fs.readdirSync(ctx.projectsDir, { withFileTypes: true });
      } catch {
        projDirs = [];
      }
      for (const projEntry of projDirs) {
        if (!projEntry.isDirectory()) continue;
        const projPath = path.join(ctx.projectsDir, projEntry.name);
        let files = [];
        try {
          files = fs.readdirSync(projPath, { withFileTypes: true });
        } catch {
          files = [];
        }
        const fileNamesSet = new Set(
          files.filter((f) => f.isFile() && f.name.endsWith('.jsonl')).map((f) => f.name)
        );
        for (const fileEntry of files) {
          this._ingestSingleClaudeFile(ctx, projPath, fileEntry, fileNamesSet);
        }
      }
    }
    return { threadsMap: ctx.threadsMap, turnsBySessionId: ctx.turnsBySessionId };
  }

  async scanClaudeSessionsAsync(claudeHomeDir, options = {}) {
    const ctx = this._buildClaudeScanContext(claudeHomeDir, options);
    let projDirs = [];
    try {
      projDirs = await fs.promises.readdir(ctx.projectsDir, { withFileTypes: true });
    } catch {
      projDirs = [];
    }
    let sliceStart = performance.now();
    for (const projEntry of projDirs) {
      if (!projEntry.isDirectory()) continue;
      const projPath = path.join(ctx.projectsDir, projEntry.name);
      let files = [];
      try {
        files = await fs.promises.readdir(projPath, { withFileTypes: true });
      } catch {
        files = [];
      }
      const fileNamesSet = new Set(
        files.filter((f) => f.isFile() && f.name.endsWith('.jsonl')).map((f) => f.name)
      );
      for (const fileEntry of files) {
        this._ingestSingleClaudeFile(ctx, projPath, fileEntry, fileNamesSet);
        if (performance.now() - sliceStart >= 10) {
          await yieldEventLoop();
          sliceStart = performance.now();
        }
      }
    }
    return { threadsMap: ctx.threadsMap, turnsBySessionId: ctx.turnsBySessionId };
  }

  _createTokenAnalyticsContext(homeDir, agyThreadsById, claudeTurnsBySessionId, claudeThreadsById, nowMs = Date.now()) {
    const brainDir = path.join(homeDir, 'brain');
    const nowSec = Math.floor(nowMs / 1000);
    const cutoffs = {
      '5h': nowSec - 5 * 3600,
      '7d': nowSec - 7 * 86400,
      '30d': nowSec - 30 * 86400
    };

    const dayKeys = [];
    for (let i = 6; i >= 0; i -= 1) {
      const d = new Date(nowMs - i * 86400 * 1000);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const key = `${yyyy}-${mm}-${dd}`;
      const label = d.toLocaleDateString('en-US', { weekday: 'short' });
      dayKeys.push({ key, label });
    }

    const createScopeBuckets = () => {
      const windows = {};
      for (const key of ['5h', '7d', '30d']) {
        windows[key] = {
          key,
          totalTokens: 0,
          inputTokens: 0,
          cachedInputTokens: 0,
          outputTokens: 0,
          turns: 0,
          sessions: 0,
          sessionSet: new Set(),
          bySession: new Map(),
          byDay: new Map()
        };
      }
      return windows;
    };

    const scopes = {
      all: createScopeBuckets(),
      antigravity: createScopeBuckets(),
      claude: createScopeBuckets()
    };

    const ingestTurns = (provider, sessionId, turns) => {
      if (!Array.isArray(turns)) {
        return;
      }
      for (const turn of turns) {
        const at = Number(turn.at || 0);
        if (!at) {
          continue;
        }
        const turnDate = new Date(at * 1000);
        const dayKey = `${turnDate.getFullYear()}-${String(turnDate.getMonth() + 1).padStart(2, '0')}-${String(turnDate.getDate()).padStart(2, '0')}`;

        for (const [wKey, cutoff] of Object.entries(cutoffs)) {
          if (at < cutoff) {
            continue;
          }
          for (const targetScope of [scopes.all, scopes[provider]]) {
            const bucket = targetScope[wKey];
            bucket.totalTokens += turn.totalTokens;
            bucket.inputTokens += turn.inputTokens;
            bucket.cachedInputTokens += turn.cachedTokens;
            bucket.outputTokens += turn.outputTokens;
            if (turn.isUserTurn) {
              bucket.turns += 1;
            }
            bucket.sessionSet.add(`${provider}:${sessionId}`);

            const prevSession = bucket.bySession.get(sessionId) || {
              id: sessionId,
              provider,
              totalTokens: 0,
              inputTokens: 0,
              cachedInputTokens: 0,
              outputTokens: 0,
              turns: 0,
              updatedAt: 0
            };
            prevSession.totalTokens += turn.totalTokens;
            prevSession.inputTokens += turn.inputTokens;
            prevSession.cachedInputTokens += turn.cachedTokens;
            prevSession.outputTokens += turn.outputTokens;
            if (turn.isUserTurn) {
              prevSession.turns += 1;
            }
            if (at > prevSession.updatedAt) {
              prevSession.updatedAt = at;
            }
            bucket.bySession.set(sessionId, prevSession);

            const prevDay = bucket.byDay.get(dayKey) || { totalTokens: 0, turns: 0 };
            prevDay.totalTokens += turn.totalTokens;
            if (turn.isUserTurn) {
              prevDay.turns += 1;
            }
            bucket.byDay.set(dayKey, prevDay);
          }
        }
      }
    };

    const cancelledByUserMap = this.readUserCancelledCascades();
    const cancelledTasksMap = cancelledByUserMap?._cancelledTasks || {};

    const finalize = () => {
      for (const [sessionId, turns] of claudeTurnsBySessionId.entries()) {
        ingestTurns('claude', sessionId, turns);
      }

      const finalizeScope = (scopeWindows) => {
        const formattedWindows = {};
        for (const [wKey, bucket] of Object.entries(scopeWindows)) {
          const topSessions = Array.from(bucket.bySession.values())
            .sort((a, b) => b.totalTokens - a.totalTokens)
            .slice(0, 8)
            .map((s) => {
              const thread =
                agyThreadsById.get(s.id) || claudeThreadsById.get(s.id);
              return {
                ...s,
                title: thread?.title || s.id.slice(0, 8),
                workspaceLabel: thread?.workspaceLabel || 'Workspace'
              };
            });

          const daily = dayKeys.map((d) => {
            const stat = bucket.byDay.get(d.key) || { totalTokens: 0, turns: 0 };
            return {
              date: d.key,
              label: d.label,
              totalTokens: stat.totalTokens,
              turns: stat.turns
            };
          });

          formattedWindows[wKey] = {
            key: wKey,
            totalTokens: bucket.totalTokens,
            inputTokens: bucket.inputTokens,
            cachedInputTokens: bucket.cachedInputTokens,
            outputTokens: bucket.outputTokens,
            turns: bucket.turns,
            sessions: bucket.sessionSet.size,
            topSessions,
            daily
          };
        }
        return { windows: formattedWindows };
      };

      const allUsage = finalizeScope(scopes.all);
      return {
        windows: allUsage.windows,
        byProvider: {
          all: allUsage.windows,
          antigravity: finalizeScope(scopes.antigravity).windows,
          claude: finalizeScope(scopes.claude).windows
        }
      };
    };

    return {
      brainDir,
      nowSec,
      agyThreadsById,
      cancelledByUserMap,
      cancelledTasksMap,
      ingestTurns,
      finalize
    };
  }

  _ingestSingleBrainEntry(entry, ctx) {
    if (!entry.isDirectory()) {
      return;
    }
    const { brainDir, nowSec, agyThreadsById, cancelledByUserMap, cancelledTasksMap, ingestTurns } = ctx;
    const sessionId = entry.name;
    const transcriptPath = path.join(
      brainDir,
      sessionId,
      '.system_generated',
      'logs',
      'transcript.jsonl'
    );
    if (!fs.existsSync(transcriptPath)) {
      return;
    }
    const parsed = this.parseTranscriptFile(transcriptPath);
    if (!parsed) {
      return;
    }
    if (Array.isArray(parsed.turns)) {
      ingestTurns('antigravity', sessionId, parsed.turns);
    }
    const agyThread = agyThreadsById.get(sessionId);
    if (agyThread) {
      if (parsed.lastAssistantText) {
        agyThread.lastAssistantText = parsed.lastAssistantText;
      }
      if (Number(parsed.stepCount || 0) > Number(agyThread.stepCount || 0)) {
        agyThread.stepCount = Number(parsed.stepCount);
      }
      agyThread.turnComplete = Boolean(parsed.turnComplete);
      const cancelEntry = cancelledByUserMap[sessionId];
      const cancelAtSec = Number(cancelEntry?.resumedAt || 0);
      const latestTurnActivitySec = Math.max(
        Number(parsed.lastStepAt || 0),
        Number(agyThread.lastUserInputAt || 0)
      );
      const isUserCancelled =
        cancelEntry?.reason === 'user_cancelled' &&
        (cancelAtSec > 0
          ? cancelAtSec >= latestTurnActivitySec - 5
          : Number(cancelEntry.stepIndex || 0) >= Number(parsed.maxStepIndex || 0));
      if (isUserCancelled) {
        agyThread.userCancelled = true;
        agyThread.status = 'CASCADE_RUN_STATUS_IDLE';
        agyThread.notFullyIdle = false;
        agyThread.turnComplete = false;
        agyThread.bgTask = null;
      } else if (
        parsed.lastStepIsMidTurn &&
        !parsed.pendingQuestion &&
        nowSec - Number(parsed.lastStepAt || 0) <= 90
      ) {
        agyThread.status = 'CASCADE_RUN_STATUS_RUNNING';
        agyThread.notFullyIdle = true;
        agyThread.turnComplete = false;
      } else if (
        agyThread.status === 'CASCADE_RUN_STATUS_RUNNING' &&
        !parsed.pendingBgTask &&
        parsed.lastStepAt > 0 &&
        nowSec - Number(parsed.lastStepAt || 0) > 180
      ) {
        agyThread.status = 'CASCADE_RUN_STATUS_IDLE';
        agyThread.notFullyIdle = false;
      }
      if (parsed.hasDaemonTaskOnly && agyThread.status !== 'CASCADE_RUN_STATUS_RUNNING') {
        agyThread.hasDaemonTaskOnly = true;
        agyThread.notFullyIdle = false;
      }
      const allowTranscriptPendingQuestion =
        !agyThread.userCancelled &&
        parsed.pendingQuestion &&
        nowSec - Number(parsed.pendingQuestion.at || 0) < 86400 &&
        (Number(agyThread.rpcWaitingCount || 0) > 0 ||
          (agyThread.status !== 'CASCADE_RUN_STATUS_RUNNING' &&
            Number(agyThread.stepCount || 0) <= Number(parsed.pendingQuestion.stepIndex || 0) + 2 &&
            Number(agyThread.lastUserInputAt || 0) <= Number(parsed.pendingQuestion.at || 0)));
      if (allowTranscriptPendingQuestion) {
        agyThread.pendingQuestion = {
          ...parsed.pendingQuestion,
          ...(agyThread.pendingQuestion || {}),
          trajectoryId:
            agyThread.trajectoryId ||
            agyThread.pendingQuestion?.trajectoryId ||
            parsed.pendingQuestion.trajectoryId ||
            '',
          questions:
            (Array.isArray(agyThread.pendingQuestion?.questions) &&
            agyThread.pendingQuestion.questions.length
              ? agyThread.pendingQuestion.questions
              : parsed.pendingQuestion.questions) || [],
          options:
            (Array.isArray(agyThread.pendingQuestion?.options) &&
            agyThread.pendingQuestion.options.length
              ? agyThread.pendingQuestion.options
              : parsed.pendingQuestion.options) || []
        };
        agyThread.status = 'WAITING_FOR_USER';
        agyThread.notFullyIdle = false;
      }
    }
    if (agyThread) {
      agyThread.backgroundTasks = Array.isArray(parsed.backgroundTasks)
        ? parsed.backgroundTasks.map((t) => {
            const copy = { ...t };
            const cKey1 = `${sessionId}:${copy.id}`;
            const cKey2 = `${sessionId}:${copy.fullId || ''}`;
            if (
              copy.state === 'running' &&
              (agyThread.userCancelled ||
                Number(cancelledTasksMap[cKey1] || 0) >= Number(copy.startedAt || 0) - 2 ||
                (copy.fullId &&
                  Number(cancelledTasksMap[cKey2] || 0) >= Number(copy.startedAt || 0) - 2))
            ) {
              copy.state = 'cancelled';
              copy.completedAt = copy.completedAt || nowSec;
            } else if (
              copy.state === 'running' &&
              agyThread.status !== 'CASCADE_RUN_STATUS_RUNNING' &&
              ((copy.kind === 'timer' &&
                !copy.isDaemon &&
                Number(copy.durationSec) > 0 &&
                nowSec - Number(copy.startedAt || 0) > Number(copy.durationSec) + 30) ||
                nowSec - Math.max(Number(copy.startedAt || 0), Number(parsed.lastStepAt || 0)) >
                  (copy.isDaemon ? 1800 : 900))
            ) {
              copy.state = 'completed';
              copy.completedAt = parsed.lastStepAt || copy.startedAt;
            }
            return copy;
          })
        : [];
    }
    const taskCancelledIndividually =
      parsed.pendingBgTask &&
      (Number(cancelledTasksMap[`${sessionId}:${parsed.pendingBgTask.shortId}`] || 0) >=
        Number(parsed.pendingBgTask.startedAt || 0) - 2 ||
        Number(cancelledTasksMap[`${sessionId}:${parsed.pendingBgTask.taskId}`] || 0) >=
          Number(parsed.pendingBgTask.startedAt || 0) - 2);
    if (agyThread && parsed.pendingBgTask && !agyThread.userCancelled && !taskCancelledIndividually) {
      const task = parsed.pendingBgTask;
      const taskSummary = task.summary || task.desc || '';
      const taskLogPath =
        task.logPath ||
        path.join(
          brainDir,
          sessionId,
          '.system_generated',
          'tasks',
          `${task.shortId}.log`
        );
      let lastLogAtSec = task.startedAt;
      try {
        if (fs.existsSync(taskLogPath)) {
          const lStat = fs.statSync(taskLogPath);
          lastLogAtSec = Math.max(task.startedAt, Math.floor(lStat.mtimeMs / 1000));
        }
      } catch {}
      const idleSec = Math.max(0, nowSec - lastLogAtSec);
      const isDaemonCmd =
        Boolean(task.isDaemon) ||
        /--watch|http\.server|server\.py|serve\.py|vite|next\s+dev|npm\s+run\s+dev|IsDaemon/i.test(
          task.rawDesc || task.desc || ''
        );
      const stallThresholdSec =
        task.kind === 'timer' ? Math.max(900, (Number(task.durationSec) || 0) + 60) : 900;
      const timerExpiredIdle =
        task.kind === 'timer' &&
        !isDaemonCmd &&
        agyThread.status !== 'CASCADE_RUN_STATUS_RUNNING' &&
        Number(task.durationSec) > 0 &&
        nowSec - Number(task.startedAt || 0) > Number(task.durationSec) + 30;
      const stalled = !isDaemonCmd && !timerExpiredIdle && idleSec >= stallThresholdSec;
      let effectiveHubStartedAtSec = this.serverStartedAtSec;
      for (const h of this.getRetiringHubs()) {
        if (Array.isArray(h.cascadeIds) && h.cascadeIds.includes(sessionId)) {
          effectiveHubStartedAtSec = Number(h.startedAt || 0);
          break;
        }
      }
      const startedBeforeServerRestart =
        effectiveHubStartedAtSec > 0 && task.startedAt < effectiveHubStartedAtSec - 5;

      const syncTaskItemState = (newState) => {
        if (!Array.isArray(agyThread.backgroundTasks)) return;
        const match = agyThread.backgroundTasks.find(
          (item) => item.fullId === task.taskId || item.id === task.shortId
        );
        if (match) {
          match.state = newState;
        }
      };

      if (timerExpiredIdle) {
        syncTaskItemState('completed');
      } else if (isDaemonCmd && agyThread.status !== 'CASCADE_RUN_STATUS_RUNNING') {
        // Daemon dev server left running after turn completed: do not mark thread as working
      } else if (startedBeforeServerRestart) {
        if (!stalled && nowSec - lastLogAtSec < 900) {
          agyThread.bgTask = {
            state: 'interrupted',
            id: task.shortId,
            kind: task.kind || 'task',
            summary: taskSummary,
            desc: taskSummary,
            startedAt: task.startedAt
          };
          syncTaskItemState('interrupted');
        } else {
          agyThread.bgTask = null;
          agyThread.notFullyIdle = false;
          if (agyThread.status === 'CASCADE_RUN_STATUS_RUNNING') {
            agyThread.status = 'CASCADE_RUN_STATUS_IDLE';
          }
          syncTaskItemState('completed');
        }
      } else if (!isDaemonCmd && stalled) {
        this.reapStalledTaskProcess(sessionId, task);
        if (idleSec < stallThresholdSec + 60 && agyThread.status === 'CASCADE_RUN_STATUS_RUNNING') {
          agyThread.bgTask = {
            state: 'running',
            stalled: true,
            idleSec,
            id: task.shortId,
            kind: task.kind || 'task',
            summary: taskSummary,
            desc: taskSummary,
            startedAt: task.startedAt
          };
          agyThread.notFullyIdle = true;
          syncTaskItemState('stalled');
        } else {
          agyThread.bgTask = null;
          agyThread.notFullyIdle = false;
          if (agyThread.status === 'CASCADE_RUN_STATUS_RUNNING') {
            agyThread.status = 'CASCADE_RUN_STATUS_IDLE';
          }
          syncTaskItemState('stalled');
        }
      } else if (nowSec - task.startedAt < 86400) {
        agyThread.bgTask = {
          state: 'running',
          stalled: false,
          idleSec,
          id: task.shortId,
          kind: task.kind || 'task',
          summary: taskSummary,
          desc: taskSummary,
          startedAt: task.startedAt
        };
        agyThread.notFullyIdle = true;
        agyThread.status = 'CASCADE_RUN_STATUS_RUNNING';
        syncTaskItemState('running');
      }
    }
  }

  computeTokenAnalytics(homeDir, agyThreadsById, claudeTurnsBySessionId, claudeThreadsById, nowMs = Date.now()) {
    const ctx = this._createTokenAnalyticsContext(
      homeDir,
      agyThreadsById,
      claudeTurnsBySessionId,
      claudeThreadsById,
      nowMs
    );
    if (fs.existsSync(ctx.brainDir)) {
      let entries = [];
      try {
        entries = fs.readdirSync(ctx.brainDir, { withFileTypes: true });
      } catch {
        entries = [];
      }
      for (const entry of entries) {
        this._ingestSingleBrainEntry(entry, ctx);
      }
    }
    return ctx.finalize();
  }

  async computeTokenAnalyticsAsync(homeDir, agyThreadsById, claudeTurnsBySessionId, claudeThreadsById, nowMs = Date.now()) {
    const ctx = this._createTokenAnalyticsContext(
      homeDir,
      agyThreadsById,
      claudeTurnsBySessionId,
      claudeThreadsById,
      nowMs
    );
    if (fs.existsSync(ctx.brainDir)) {
      let entries = [];
      try {
        entries = await fs.promises.readdir(ctx.brainDir, { withFileTypes: true });
      } catch {
        entries = [];
      }
      let sliceStart = performance.now();
      for (const entry of entries) {
        this._ingestSingleBrainEntry(entry, ctx);
        if (performance.now() - sliceStart >= 10) {
          await yieldEventLoop();
          sliceStart = performance.now();
        }
      }
    }
    return ctx.finalize();
  }

  async loadSnapshot(options = {}) {
    const nowMs = Date.now();
    const homeDir = this.getHomeDir();
    const claudeHomeDir = this.getClaudeHomeDir();
    const customTitles = options.customTitles || {};
    const archivedSet = new Set(Array.isArray(options.archivedIds) ? options.archivedIds : []);
    const threadGroups = options.threadGroups || {};

    const { claudeConfig, credentials: claudeCreds } = this.readClaudeLocalCredentials();
    const activeClaudeEmail = String(claudeConfig?.oauthAccount?.emailAddress || '')
      .trim()
      .toLowerCase();
    const hasClaudeAuthOnDisk = Boolean(
      claudeCreds?.claudeAiOauth?.accessToken || activeClaudeEmail
    );
    if (!hasClaudeAuthOnDisk) {
      this.cachedClaudeQuota = null;
      this.cachedClaudeQuotaAt = 0;
      this.cachedClaudeQuotaEmail = '';
    } else {
      if (
        activeClaudeEmail &&
        this.cachedClaudeQuotaEmail &&
        activeClaudeEmail !== this.cachedClaudeQuotaEmail
      ) {
        this.cachedClaudeQuota = null;
        this.cachedClaudeQuotaAt = 0;
        this.cachedClaudeQuotaEmail = activeClaudeEmail;
      }
      if (!this.cachedClaudeQuota) {
        this.readPersistedClaudeQuotaCache(activeClaudeEmail);
      }
    }

    const cliCachedQuota =
      hasClaudeAuthOnDisk &&
      claudeConfig?.cachedUsageUtilization?.utilization &&
      typeof claudeConfig.cachedUsageUtilization.utilization === 'object'
        ? claudeConfig.cachedUsageUtilization.utilization
        : null;
    const cliCachedAt = Number(claudeConfig?.cachedUsageUtilization?.fetchedAtMs || 0);
    if (cliCachedQuota && (!this.cachedClaudeQuota || cliCachedAt > this.cachedClaudeQuotaAt)) {
      this.cachedClaudeQuota = {
        ...cliCachedQuota,
        ...(this.cachedClaudeQuota && this.cachedClaudeQuotaAt >= cliCachedAt
          ? this.cachedClaudeQuota
          : {})
      };
      this.cachedClaudeQuotaAt = Math.max(this.cachedClaudeQuotaAt || 0, cliCachedAt || nowMs);
      this.writePersistedClaudeQuotaCache(
        this.cachedClaudeQuota,
        this.cachedClaudeQuotaAt,
        activeClaudeEmail
      );
    }

    const agyWindowJustExpired = this.hasQuotaWindowJustExpired(nowMs);
    const agyStepsAdvanced = Boolean(
      this.pendingAgyQuotaRefreshOnStep && nowMs - this.cachedQuotaAt > 8000
    );
    const forceAgyQuota =
      Boolean(options.forceRefreshQuota) || agyWindowJustExpired || agyStepsAdvanced;
    const needFreshQuota =
      forceAgyQuota ||
      !this.cachedQuota ||
      nowMs - this.cachedQuotaAt > 25000;

    const claudeWindowJustExpired = this.hasClaudeWindowJustExpired(nowMs);
    const wantFreshClaudeQuota =
      Boolean(options.forceRefreshQuota) ||
      claudeWindowJustExpired ||
      this.pendingClaudeTurnQuotaRefresh ||
      !this.cachedClaudeQuota ||
      nowMs - this.cachedClaudeQuotaAt > 300000;
    const claudeAccessToken = claudeCreds?.claudeAiOauth?.accessToken || '';
    const claudeTokenExpiresAt = Number(claudeCreds?.claudeAiOauth?.expiresAt || 0);
    const claudeTokenValid =
      Boolean(claudeAccessToken) &&
      (!claudeTokenExpiresAt || claudeTokenExpiresAt > nowMs + 15000);
    const canAttemptClaudeQuota =
      claudeTokenValid &&
      nowMs >= this.claudeQuotaBackoffUntil &&
      nowMs - this.lastClaudeQuotaAttemptAt >= 15000;
    const needFreshClaudeQuota = wantFreshClaudeQuota && canAttemptClaudeQuota;

    let claudeQuotaFetched = false;
    const [creds, rawClaudeLiveRes, claudeVscState, claudeQuotaRes] = await Promise.all([
      this.getServerCredentials(),
      (() => {
        try {
          const directBridge = require('./compat/claude-hub-bridge.cjs');
          if (directBridge?.getBridgeState?.()?.attached && typeof directBridge.getLiveSnapshot === 'function') {
            directBridge.hotUpgradeLiveState?.();
            return Promise.resolve(directBridge.getLiveSnapshot());
          }
        } catch {}
        return vscode?.commands
          ? vscode.commands.executeCommand('antigravityHub.claudeGetSnapshot').then(
              (res) => res || { active: false },
              () => ({ active: false })
            )
          : Promise.resolve({ active: false });
      })(),
      this.readClaudeVscStateFallback(),
      needFreshClaudeQuota
        ? this.fetchClaudeOauthUsage(claudeAccessToken).then(
            (val) => {
              claudeQuotaFetched = Boolean(val && typeof val === 'object');
              return val;
            },
            () => this.cachedClaudeQuota
          )
        : Promise.resolve(this.cachedClaudeQuota)
    ]);

    const mergedClaudeArchivedIds = Array.from(
      new Set([
        ...(Array.isArray(rawClaudeLiveRes?.archivedIds) ? rawClaudeLiveRes.archivedIds : []),
        ...(rawClaudeLiveRes?.active ? [] : claudeVscState.archivedIds || [])
      ])
    );
    const mergedClaudeUnarchivedAt = {
      ...(claudeVscState.unarchivedAt || {}),
      ...(rawClaudeLiveRes?.unarchivedAt || {})
    };
    const mergedClaudeGroups = [];
    const seenClaudeGroupIds = new Set();
    for (const g of [
      ...(Array.isArray(rawClaudeLiveRes?.sessionGroups) ? rawClaudeLiveRes.sessionGroups : []),
      ...(claudeVscState.sessionGroups || [])
    ]) {
      if (g && g.id && !seenClaudeGroupIds.has(g.id)) {
        seenClaudeGroupIds.add(g.id);
        mergedClaudeGroups.push(g);
      }
    }
    const mergedClaudeUnreadIds = Array.from(
      new Set([
        ...(Array.isArray(rawClaudeLiveRes?.unreadIds) ? rawClaudeLiveRes.unreadIds : []),
        ...(rawClaudeLiveRes?.active ? [] : claudeVscState.unreadIds || [])
      ])
    );

    const claudeLiveRes = {
      ...rawClaudeLiveRes,
      archivedIds: mergedClaudeArchivedIds,
      unarchivedAt: mergedClaudeUnarchivedAt,
      sessionGroups: mergedClaudeGroups,
      unreadIds: mergedClaudeUnreadIds
    };

    const unarchivedAtMap = options.unarchivedAt || {};
    for (const cid of mergedClaudeArchivedIds) {
      if (!unarchivedAtMap[cid]) {
        archivedSet.add(cid);
      }
    }

    if (hasClaudeAuthOnDisk && claudeQuotaFetched && claudeQuotaRes) {
      this.cachedClaudeQuota = claudeQuotaRes;
      this.cachedClaudeQuotaAt = nowMs;
      this.pendingClaudeTurnQuotaRefresh = false;
      this.writePersistedClaudeQuotaCache(claudeQuotaRes, nowMs, activeClaudeEmail);
    } else if (
      hasClaudeAuthOnDisk &&
      rawClaudeLiveRes?.fullRateLimits &&
      typeof rawClaudeLiveRes.fullRateLimits === 'object'
    ) {
      this.cachedClaudeQuota = {
        ...(this.cachedClaudeQuota || {}),
        ...rawClaudeLiveRes.fullRateLimits
      };
      this.cachedClaudeQuotaAt = Number(rawClaudeLiveRes.fullRateLimitsAt || nowMs);
      this.writePersistedClaudeQuotaCache(
        this.cachedClaudeQuota,
        this.cachedClaudeQuotaAt,
        activeClaudeEmail
      );
    }

    let userStatusRaw = null;
    let quotaRaw = null;
    let trajectoriesRaw = null;
    let rpcConnected = false;

    if (creds) {
      const retiringHubs = this.getRetiringHubs().filter((h) => h.port !== creds.port);
      const [userRes, quotaRes, trajRes, ...retiringTrajRes] = await Promise.allSettled([
        this.callRpc(creds.port, creds.csrfToken, 'GetUserStatus', {}),
        needFreshQuota
          ? this.callRpc(creds.port, creds.csrfToken, 'RetrieveUserQuotaSummary', {
              forceRefresh: true
            })
          : Promise.resolve(this.cachedQuota),
        this.callRpc(creds.port, creds.csrfToken, 'GetAllCascadeTrajectories', {}),
        ...retiringHubs.map((h) =>
          this.callRpc(h.port, h.csrfToken, 'GetAllCascadeTrajectories', {}, 1500)
        )
      ]);

      rpcConnected =
        userRes.status === 'fulfilled' ||
        (needFreshQuota && quotaRes.status === 'fulfilled') ||
        trajRes.status === 'fulfilled';

      if (!rpcConnected) {
        const errTexts = [userRes, quotaRes, trajRes]
          .filter((r) => r.status === 'rejected')
          .map((r) => String(r.reason?.message || r.reason || ''));
        if (errTexts.some((m) => /ECONNREFUSED/i.test(m))) {
          this.markPortDead(creds.port);
          try {
            globalThis[Symbol.for('bhfirms.antigravityHub.bridgeState')]
              ?.ensureUpstreamAlive?.(creds.port)
              ?.catch?.(() => {});
          } catch {}
        }
      }

      let accountSwitched = false;
      if (userRes.status === 'fulfilled' && userRes.value) {
        userStatusRaw = userRes.value;
        const nextAccount = parseAntigravityAccountStatus(userStatusRaw);
        const prevEmail = String(this.cachedAccount?.email || '').trim().toLowerCase();
        const nextEmail = String(nextAccount?.email || '').trim().toLowerCase();
        if (prevEmail && nextEmail && prevEmail !== nextEmail) {
          accountSwitched = true;
          this.cachedQuota = null;
          this.cachedQuotaAt = 0;
        }
        this.cachedAccount = nextAccount;
      }
      if (quotaRes.status === 'fulfilled' && quotaRes.value && (!accountSwitched || needFreshQuota)) {
        quotaRaw = quotaRes.value;
        if (needFreshQuota) {
          this.cachedQuota = quotaRaw;
          this.cachedQuotaAt = nowMs;
          this.pendingAgyQuotaRefreshOnStep = false;
        }
      } else if (accountSwitched) {
        try {
          const freshAfterSwitch = await this.callRpc(
            creds.port,
            creds.csrfToken,
            'RetrieveUserQuotaSummary',
            { forceRefresh: true }
          );
          if (freshAfterSwitch) {
            quotaRaw = freshAfterSwitch;
            this.cachedQuota = freshAfterSwitch;
            this.cachedQuotaAt = nowMs;
            this.pendingAgyQuotaRefreshOnStep = false;
          }
        } catch {}
      }
      if (trajRes.status === 'fulfilled' && trajRes.value) {
        trajectoriesRaw = trajRes.value;
      }
      if (retiringTrajRes.length > 0) {
        const mergedSummaries = {
          ...(trajectoriesRaw?.trajectorySummaries || {})
        };
        for (let i = 0; i < retiringHubs.length; i += 1) {
          const rHub = retiringHubs[i];
          const rRes = retiringTrajRes[i];
          if (rRes?.status !== 'fulfilled' || !rRes.value?.trajectorySummaries) {
            continue;
          }
          const rSummaries = rRes.value.trajectorySummaries;
          const pinnedSet = new Set(rHub.cascadeIds || []);
          for (const [cid, rItem] of Object.entries(rSummaries)) {
            if (!rItem || typeof rItem !== 'object') continue;
            if (
              pinnedSet.has(cid) ||
              rItem.status === 'CASCADE_RUN_STATUS_RUNNING' ||
              !mergedSummaries[cid]
            ) {
              mergedSummaries[cid] = rItem;
            }
          }
        }
        trajectoriesRaw = {
          ...(trajectoriesRaw || {}),
          trajectorySummaries: mergedSummaries
        };
      }
    }

    const account = this.cachedAccount || parseAntigravityAccountStatus(userStatusRaw);
    const rateLimits = parseAntigravityQuotaSummary(quotaRaw || this.cachedQuota, nowMs);

    const claudeAccount = parseClaudeAccountStatus(claudeConfig, claudeCreds);
    this.cachedClaudeAccount = claudeAccount;
    let claudeRateLimits =
      claudeAccount?.signedOut || !hasClaudeAuthOnDisk
        ? { available: false, primaryBars: [], allBuckets: [], error: 'Not signed in.' }
        : parseClaudeQuotaSummary(
            claudeQuotaRes || this.cachedClaudeQuota,
            claudeLiveRes?.rateLimitWindows,
            nowMs
          );

    const agyThreadsMap = new Map();
    const summariesMap = trajectoriesRaw?.trajectorySummaries || {};
    let currentAgyStepSum = 0;
    for (const sVal of Object.values(summariesMap)) {
      if (sVal && typeof sVal === 'object') {
        currentAgyStepSum += Number(sVal.stepCount || 0);
      }
    }
    if (this.lastAgyStepSum > 0 && currentAgyStepSum > this.lastAgyStepSum) {
      this.pendingAgyQuotaRefreshOnStep = true;
    }
    if (currentAgyStepSum > 0) {
      this.lastAgyStepSum = currentAgyStepSum;
    }

    for (const [id, item] of Object.entries(summariesMap)) {
      if (!id || !item || typeof item !== 'object') {
        continue;
      }
      const rootId = item?.trajectoryMetadata?.rootConversationId || '';
      if (rootId && rootId !== id) {
        continue;
      }

      const ws0 = Array.isArray(item.workspaces) && item.workspaces[0] ? item.workspaces[0] : {};
      const cwd = fileUriToPath(
        ws0.workspaceFolderAbsoluteUri || ws0.gitRootAbsoluteUri || ''
      );
      const branch = cleanText(ws0.branchName || '', 60);
      const nativeTitle = cleanText(item?.annotations?.title || '', 120);
      const summaryTitle = cleanText(item?.summary || '', 120);
      const customTitle = cleanText(customTitles[id] || '', 120);
      const title = customTitle || nativeTitle || summaryTitle || 'Untitled session';

      const createdAt = parseIsoToEpochSeconds(item.createdTime);
      const updatedAt =
        parseIsoToEpochSeconds(item.lastModifiedTime) ||
        parseIsoToEpochSeconds(item.lastUserInputTime) ||
        createdAt;
      const lastUserInputAt = parseIsoToEpochSeconds(item.lastUserInputTime);
      const lastUserViewAt = parseIsoToEpochSeconds(item?.annotations?.lastUserViewTime);

      const trajectoryId = String(item.trajectoryId || '').trim();
      const rpcWaitingCount = Array.isArray(item.waitingSteps) ? item.waitingSteps.length : 0;
      const rpcFetchedAtSec = Math.floor(nowMs / 1000);
      let rpcPendingQuestion = null;
      if (rpcWaitingCount > 0) {
        const ws = item.waitingSteps[0];
        const reqInt = ws?.step?.requestedInteraction;
        const askQ =
          reqInt?.askQuestion ||
          (reqInt?.interaction?.case === 'askQuestion' ? reqInt.interaction.value : null) ||
          ws?.step?.askQuestion;
        let rawWaitQuestions = Array.isArray(askQ?.questions) ? askQ.questions : [];
        if (rawWaitQuestions.length === 0 && ws?.step?.metadata?.toolCall?.argumentsJson) {
          try {
            const parsedArgs = JSON.parse(ws.step.metadata.toolCall.argumentsJson);
            rawWaitQuestions = parseAskQuestionsArg(parsedArgs?.questions);
          } catch {}
        }
        if (rawWaitQuestions.length > 0) {
          const qSummary = extractQuestionSummary(rawWaitQuestions);
          if (qSummary) {
            rpcPendingQuestion = {
              stepIndex: Number(ws.stepIndex || item.stepCount || 0),
              trajectoryId,
              questionText: qSummary.questionText,
              isMultiSelect: Boolean(qSummary.isMultiSelect),
              options: qSummary.options,
              questions: qSummary.questions,
              at: updatedAt || rpcFetchedAtSec
            };
          }
        }
      }

      agyThreadsMap.set(id, {
        id,
        trajectoryId,
        provider: 'antigravity',
        title,
        customTitle,
        rawTitle: nativeTitle || summaryTitle || title,
        summary: summaryTitle || title,
        cwd,
        workspaceLabel: formatWorkspaceLabel(cwd),
        branch,
        model: 'Gemini',
        createdAt,
        updatedAt,
        lastUserInputAt,
        lastUserViewAt,
        stepCount: Number(item.stepCount || 0),
        status:
          rpcWaitingCount > 0 || rpcPendingQuestion
            ? 'WAITING_FOR_USER'
            : String(item.status || 'CASCADE_RUN_STATUS_IDLE'),
        notFullyIdle:
          rpcWaitingCount === 0 &&
          !rpcPendingQuestion &&
          item.status === 'CASCADE_RUN_STATUS_RUNNING',
        pendingQuestion: rpcPendingQuestion,
        rpcWaitingCount,
        rpcFetchedAtSec,
        terminationReason: String(item.latestExecutorTerminationReason || ''),
        archived: archivedSet.has(id),
        groupId: threadGroups[id] || '',
        source: 'rpc'
      });
    }

    const sqliteRows = await this.readSqliteFallbackSummaries(homeDir);
    const nowSec = Math.floor(nowMs / 1000);
    const hasLiveRpcTrajectories = Boolean(trajectoriesRaw && Object.keys(summariesMap).length > 0);
    for (const row of sqliteRows) {
      const id = String(row.conversation_id || '').trim();
      if (!id) {
        continue;
      }
      let cwd = '';
      try {
        const uris = JSON.parse(row.workspace_uris || '[]');
        if (Array.isArray(uris) && uris[0]) {
          cwd = fileUriToPath(uris[0]);
        }
      } catch {}
      const customTitle = cleanText(customTitles[id] || '', 120);
      const rawTitle = cleanText(row.title || row.preview || '', 120);
      const title = customTitle || rawTitle || 'Untitled session';
      const updatedAt = parseIsoToEpochSeconds(row.last_modified_time);
      const lastUserInputAt = parseIsoToEpochSeconds(row.last_user_input_time);

      if (agyThreadsMap.has(id)) {
        const existing = agyThreadsMap.get(id);
        if (existing.title === 'Untitled session' && title !== 'Untitled session') {
          existing.title = title;
          existing.rawTitle = rawTitle || title;
        }
        if (!existing.cwd && cwd) {
          existing.cwd = cwd;
          existing.workspaceLabel = formatWorkspaceLabel(cwd);
        }
        if (updatedAt > (existing.updatedAt || 0)) {
          existing.updatedAt = updatedAt;
        }
        if (Number(row.step_count || 0) > (existing.stepCount || 0)) {
          existing.stepCount = Number(row.step_count || 0);
        }
        continue;
      }

      const isFreshSqliteRun = !hasLiveRpcTrajectories && nowSec - updatedAt < 120;
      const rawStatus = String(row.status || 'CASCADE_RUN_STATUS_IDLE');
      const status =
        rawStatus === 'CASCADE_RUN_STATUS_RUNNING' && !isFreshSqliteRun
          ? 'CASCADE_RUN_STATUS_IDLE'
          : rawStatus;
      const notFullyIdle = Boolean(row.not_fully_idle) && isFreshSqliteRun;

      agyThreadsMap.set(id, {
        id,
        provider: 'antigravity',
        title,
        customTitle,
        rawTitle: rawTitle || title,
        summary: cleanText(row.preview || rowTitle(rawTitle), 140),
        cwd,
        workspaceLabel: formatWorkspaceLabel(cwd),
        branch: '',
        model: 'Gemini',
        createdAt: updatedAt,
        updatedAt,
        lastUserInputAt,
        lastUserViewAt: 0,
        stepCount: Number(row.step_count || 0),
        status,
        notFullyIdle,
        terminationReason: '',
        archived: archivedSet.has(id),
        groupId: threadGroups[id] || '',
        source: 'sqlite'
      });
    }

    const { threadsMap: claudeThreadsMap, turnsBySessionId: claudeTurnsBySessionId } =
      await this.scanClaudeSessionsAsync(claudeHomeDir, {
        customTitles,
        archivedSet,
        threadGroups,
        claudeLive: claudeLiveRes,
        nowMs
      });

    let maxClaudeTurnEpoch = 0;
    for (const turns of claudeTurnsBySessionId.values()) {
      for (const turn of turns) {
        if (turn?.tsSec > maxClaudeTurnEpoch) {
          maxClaudeTurnEpoch = turn.tsSec;
        }
      }
    }
    if (this.lastClaudeTurnEpoch > 0 && maxClaudeTurnEpoch > this.lastClaudeTurnEpoch) {
      this.pendingClaudeTurnQuotaRefresh = true;
    }
    if (maxClaudeTurnEpoch > this.lastClaudeTurnEpoch) {
      this.lastClaudeTurnEpoch = maxClaudeTurnEpoch;
    }

    const threads = [
      ...Array.from(agyThreadsMap.values()),
      ...Array.from(claudeThreadsMap.values())
    ].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

    const usage = await this.computeTokenAnalyticsAsync(
      homeDir,
      agyThreadsMap,
      claudeTurnsBySessionId,
      claudeThreadsMap,
      nowMs
    );

    if (
      !claudeRateLimits.available &&
      claudeAccount.available &&
      Number(usage?.byProvider?.claude?.['5h']?.turns || 0) === 0
    ) {
      claudeRateLimits = parseClaudeQuotaSummary(
        {
          five_hour: { utilization: 0, resets_at: null },
          seven_day: { utilization: 0, resets_at: null },
          limits: [
            {
              kind: 'weekly_scoped',
              percent: 0,
              resets_at: null,
              scope: { model: { id: 'fable', display_name: 'Fable' } }
            }
          ]
        },
        claudeLiveRes?.rateLimitWindows,
        nowMs
      );
    }

    this.writePersistedParseCache(nowMs);

    return {
      loadedAt: nowMs,
      serverConnected: Boolean(creds && rpcConnected),
      claudeConnected: Boolean(claudeLiveRes?.active || claudeAccount.available),
      account,
      rateLimits,
      rawAntigravityQuota: quotaRaw || this.cachedQuota || null,
      claudeAccount,
      claudeRateLimits,
      rawClaudeQuota: claudeQuotaRes || this.cachedClaudeQuota || null,
      claudeConfigObj: claudeConfig || null,
      claudeCredsObj: claudeCreds || null,
      claudeLive: claudeLiveRes,
      threads,
      usage
    };
  }

  reapStalledTaskProcess(sessionId, task) {
    try {
      const cleanSid = String(sessionId || '').trim().replace(/'/g, '');
      const key = `${cleanSid}/${task.shortId}`;
      if (!cleanSid || this.reapedStalledTasks.has(key) || process.platform !== 'win32') {
        return;
      }
      this.reapedStalledTasks.add(key);
      // Never call CancelCascadeSteps here: in agy.exe, CancelCascadeSteps downgrades the background task
      // completion event to MESSAGE_PRIORITY_LOW ("Tool execution was canceled"), which suppresses the
      // automatic cascade wakeup and strands the session in CASCADE_RUN_STATUS_IDLE. Also never kill global
      // headless browsers or shared repo scripts (like verify_mfg.mjs) across sibling sessions; only reap
      // child processes >900s old whose command line is explicitly scoped to this sessionId.
      if (!/^[0-9a-f-]{8,}$/i.test(cleanSid)) {
        return;
      }
      const psScript = `$cutoff = (Get-Date).AddSeconds(-900); $procs = Get-CimInstance Win32_Process | Where-Object { $_.CreationDate -lt $cutoff -and $_.Name -in @('node.exe','python.exe','powershell.exe','pwsh.exe') -and $_.CommandLine -like '*${cleanSid}*' }; foreach ($p in $procs) { & taskkill.exe /F /T /PID $p.ProcessId 2>$null | Out-Null }`;
      execFileAsync(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', psScript],
        {
          timeout: 4500,
          windowsHide: true
        }
      ).catch(() => {});
    } catch {}
  }
}

function rowTitle(val) {
  return String(val || 'Untitled session');
}

AntigravityDataStore.PARSE_CACHE_VERSION = PARSE_CACHE_VERSION;

module.exports = {
  AntigravityDataStore,
  normalizeAskQuestionsList,
  extractQuestionSummary,
  buildClaudeToolPermissionQuestion,
  summarizeTaskExplanation,
  parseClaudeTaskNotifications
};
