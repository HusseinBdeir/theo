class SessionActivityTracker {
  constructor() {
    this.liveByThreadId = new Map();
    this.previousStatusByThreadId = new Map();
    this.lastCompletedNotificationById = new Map();
    this.lastConversationEventAt = 0;
  }

  ingestBridgeEvent(payload = {}) {
    const conversations = Array.isArray(payload?.conversations) ? payload.conversations : [];
    if (conversations.length > 0 || String(payload?.type || '').includes('permission')) {
      this.lastConversationEventAt = Date.now();
    }
    const nowSec = Math.floor(Date.now() / 1000);
    for (const item of conversations) {
      const id = String(item?.id || item?.cascadeId || item?.conversationId || '').trim();
      if (!id) {
        continue;
      }
      const summary = item?.summary || {};
      const waitingSteps = Array.isArray(summary.waitingSteps) ? summary.waitingSteps : [];
      const waitingCount = waitingSteps.length;
      const notFullyIdle = Boolean(summary.notFullyIdle);
      const stepCount = Number(summary.stepCount || 0);
      const prev = this.liveByThreadId.get(id);
      const waitingChanged = Boolean(prev && Number(prev.waitingCount || 0) !== waitingCount);
      if (prev && nowSec - prev.updatedAt < 45 && !waitingChanged) {
        if (stepCount > 0 && Number(prev.stepCount || 0) > stepCount) {
          continue;
        }
        if (
          stepCount > 0 &&
          Number(prev.stepCount || 0) === stepCount &&
          Number(prev.waitingCount || 0) === 0 &&
          prev.notFullyIdle === false &&
          notFullyIdle === true &&
          nowSec - Number(prev.idleSince || prev.updatedAt) < 30
        ) {
          continue;
        }
      }
      this.liveByThreadId.set(id, {
        notFullyIdle,
        waitingCount,
        stepCount: Math.max(stepCount, Number(prev?.stepCount || 0)),
        idleSince: !notFullyIdle
          ? prev && !prev.notFullyIdle && prev.idleSince
            ? prev.idleSince
            : nowSec
          : 0,
        updatedAt: nowSec
      });
    }
  }

  reconcileSnapshot(threads = [], nowMs = Date.now()) {
    if (!Array.isArray(threads) || !(this.liveByThreadId instanceof Map)) {
      return;
    }
    const nowSec = Math.floor((nowMs || Date.now()) / 1000);
    for (const thread of threads) {
      if (!thread?.id || thread.source !== 'rpc' || typeof thread.rpcWaitingCount !== 'number') {
        continue;
      }
      const live = this.liveByThreadId.get(thread.id);
      const rpcSec = Number(thread.rpcFetchedAtSec || nowSec);
      if (live && live.waitingCount > 0 && thread.rpcWaitingCount === 0 && live.updatedAt <= rpcSec) {
        live.waitingCount = 0;
        live.notFullyIdle = Boolean(thread.notFullyIdle);
        live.updatedAt = rpcSec;
      }
    }
  }

  classifyThread(thread, options = {}) {
    const id = thread.id;
    const nowSec = Math.floor((options.nowMs || Date.now()) / 1000);
    const live = this.liveByThreadId.get(id);
    const liveFresh = Boolean(live && nowSec - live.updatedAt < 120);
    const rpcClearedWaiting = Boolean(
      thread.source === 'rpc' &&
        typeof thread.rpcWaitingCount === 'number' &&
        thread.rpcWaitingCount === 0 &&
        (!live || live.updatedAt <= Number(thread.rpcFetchedAtSec || nowSec))
    );

    const bgRunning = thread.bgTask?.state === 'running';
    const bgInterrupted = thread.bgTask?.state === 'interrupted';
    const hasPendingQuestion = Boolean(thread.pendingQuestion);
    const isWaiting = Boolean(
      hasPendingQuestion ||
        (liveFresh && live.waitingCount > 0 && !rpcClearedWaiting) ||
        /WAITING|PENDING_USER/i.test(thread.status || '')
    );
    const isRunning = Boolean(
      !isWaiting &&
        !thread.userCancelled &&
        (bgRunning ||
          thread.status === 'CASCADE_RUN_STATUS_RUNNING' ||
          thread.notFullyIdle ||
          (liveFresh && live.notFullyIdle && !thread.hasDaemonTaskOnly))
    );
    const isErrored = Boolean(
      !isRunning &&
        !isWaiting &&
        (bgInterrupted ||
          /ERROR|FAILED/i.test(thread.terminationReason || '') ||
          /ERROR/i.test(thread.status || ''))
    );

    let state = 'idle';
    let label = 'Idle';
    let reason = '';
    if (isWaiting) {
      state = 'waiting';
      label = hasPendingQuestion ? 'Asking a question' : 'Waiting for input';
      if (hasPendingQuestion && thread.pendingQuestion?.questionText) {
        reason = thread.pendingQuestion.questionText;
      }
    } else if (isRunning) {
      state = 'thinking';
      const stalledMins = thread.bgTask?.stalled
        ? Math.max(3, Math.round(Number(thread.bgTask.idleSec || 180) / 60))
        : 0;
      const runningBgItems = Array.isArray(thread.backgroundTasks)
        ? thread.backgroundTasks.filter((t) => t && t.state === 'running')
        : [];
      const bgSummary = String(thread.bgTask?.summary || thread.bgTask?.desc || '').trim();
      const shortSummary =
        bgSummary.length > 46 ? `${bgSummary.slice(0, 45).trimEnd()}…` : bgSummary;
      if (bgRunning) {
        if (thread.bgTask.stalled) {
          label = `Stalled task (${thread.bgTask.id} · ${stalledMins}m idle)`;
        } else if (runningBgItems.length > 1) {
          label = shortSummary
            ? `${runningBgItems.length} tasks · ${shortSummary}`
            : `${runningBgItems.length} background tasks`;
        } else if (thread.bgTask.kind === 'subagent') {
          label = shortSummary ? `Subagent · ${shortSummary}` : 'Subagent running';
        } else {
          label = shortSummary || `Background task (${thread.bgTask.id})`;
        }
        reason =
          runningBgItems.length > 1
            ? runningBgItems
                .slice(-3)
                .map((t) => t.summary || t.id)
                .join(' · ')
            : bgSummary
              ? `${bgSummary} (${thread.bgTask.id})`
              : `Background ${thread.bgTask.id}`;
      } else {
        label = 'Working…';
      }
    } else if (isErrored) {
      state = 'errored';
      label = bgInterrupted ? `Interrupted (${thread.bgTask.id})` : 'Error';
      if (bgInterrupted) {
        reason = `${thread.bgTask.id} interrupted by window reload${thread.bgTask.desc ? ` (${thread.bgTask.desc})` : ''}`;
      }
    } else if (
      thread.stepCount > 0 &&
      thread.updatedAt > 0 &&
      nowSec - thread.updatedAt < 7200
    ) {
      state = 'completed';
      label = 'Completed';
    }

    const prevState = this.previousStatusByThreadId.get(id);
    if (options.recordTransition !== false) {
      this.previousStatusByThreadId.set(id, state);
    }

    let transitionedFromWorking =
      prevState === 'thinking' && (state === 'completed' || state === 'waiting' || state === 'errored');

    if (transitionedFromWorking && state === 'completed') {
      if (!(this.lastCompletedNotificationById instanceof Map)) {
        this.lastCompletedNotificationById = new Map();
      }
      const curStep = Number(thread.stepCount || 0);
      const prevDone = this.lastCompletedNotificationById.get(id);
      if (
        prevDone &&
        nowSec - prevDone.atSec < 90 &&
        (curStep === 0 || curStep <= prevDone.stepCount)
      ) {
        transitionedFromWorking = false;
      } else if (options.recordTransition !== false) {
        this.lastCompletedNotificationById.set(id, {
          stepCount: curStep,
          atSec: nowSec
        });
      }
    }

    return {
      state,
      label,
      reason,
      isWorking: state === 'thinking' || state === 'waiting',
      transitionedFromWorking,
      previousState: prevState || ''
    };
  }
}

module.exports = {
  SessionActivityTracker
};

