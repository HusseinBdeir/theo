'use strict';

// Hands-free window reload (owner idea 2026-11-11, built 2026-11-20 with six guards).
//
// Most THEO modules hot-swap in place, but two kinds of update still need Developer: Reload Window:
//   - THEO's own extension.js or package.json changed in the installed folder (bundle updater, install_local.py);
//   - bridge.js rewrote the loaded Claude Code or Antigravity extension bundle (bridge report `needsReload`).
// A PC nobody sits at kept running the old code until someone reloaded it. This module reloads the window by
// itself, but only when nothing can be lost:
//   1. no turn is running or waiting for an answer, and no background task is running, on this PC;
//   2. THEO Remote has not been used from the phone for REMOTE_QUIET_MS (the PC is idle exactly while the owner
//      drives sessions from the phone);
//   3. no Claude Code or Antigravity chat box holds unsent text (each chat box reports it; see
//      compat/claude-webview-patches.cjs and compat/antigravity-context-window.cjs), and no unsaved editor would
//      be lost (only checked when hot exit is off: VS Code keeps unsaved editors across a reload otherwise);
//   4. only when the loaded code is older than the installed code (or the bridge says so), never on a timer;
//   5. a canary rule: the first window on the PC to reload into a given update records it; the update counts as
//      good once a window running it finishes activation. No other window auto-reloads into it before then, and
//      a canary that never comes back (VERIFY_AFTER_MS) stops auto-reload for that update and says so in the
//      sidebar and the evening digest. One auto-reload per update per window, never a loop;
//   6. one window reloads at a time (PC-wide lock file), after every guard has held for HOLD_STEADY_MS plus a
//      per-window random delay.
// Everything is also gated on the OS being idle for OS_IDLE_MIN_MS and the `antigravityHub.autoReloadWhenIdle`
// setting (default on).
//
// State that must outlive a hot swap of this module lives on a globalThis symbol. Files live under
// ~/.claude/theo-auto-reload/ (THEO_AUTO_RELOAD_DIR overrides it for tests).

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const vm = require('vm');
const Module = require('module');

const OS_IDLE_MIN_MS = 5 * 60 * 1000;
const REMOTE_QUIET_MS = 10 * 60 * 1000;
const FILE_QUIET_MS = 60 * 1000;
const HOLD_STEADY_MS = 60 * 1000;
const JITTER_MAX_MS = 60 * 1000;
const ROWS_MAX_AGE_MS = 2 * 60 * 1000;
const LOCK_STALE_MS = 3 * 60 * 1000;
const VERIFY_AFTER_MS = 5 * 60 * 1000;
const VERIFY_DELAY_MS = 20 * 1000;
const DRAFT_TTL_MS = 5 * 60 * 1000;
const TARGET_KEEP_MS = 14 * 24 * 60 * 60 * 1000;
const REMOTE_ACTIVITY_WRITE_EVERY_MS = 30 * 1000;
const MAX_FUTURE_SKEW_MS = 10 * 60 * 1000;
const MAIN_FILES = ['extension.js', 'package.json'];

// remote.js writes the phone's last command time here (no require of this module there).
const REMOTE_ACTIVITY_KEY = Symbol.for('theo-hub.remoteUserActivityAt');
const STATE_KEY = Symbol.for('theo-hub.auto-reload');
const st = (globalThis[STATE_KEY] = globalThis[STATE_KEY] || {
  extRoot: '',
  windowKey: '',
  loadedFingerprint: '',
  loadedAt: 0,
  jitterMs: Math.floor(Math.random() * JITTER_MAX_MS),
  eligibleSince: 0,
  fpMemo: null,
  inFlight: false,
  reloading: false,
  verified: false,
  lastView: null,
  lastRemoteFileWriteAt: 0
});

const BLOCKER_LABELS = {
  disabled: 'Auto-reload is off in settings',
  'recent-change': 'The update is still being written',
  syntax: 'The installed extension.js does not compile',
  'already-tried': 'This window already auto-reloaded once for this update',
  'canary-pending': 'Another window is trying the update first',
  'canary-failed': 'THEO did not start after the last auto-reload into this update',
  'other-window': 'Another window is reloading first',
  'idle-unknown': 'Cannot read how long this PC has been idle',
  'in-use': 'Someone is using this PC',
  phone: 'THEO Remote was used in the last 10 min',
  turn: 'A session is running or waiting for an answer',
  'bg-task': 'A background task is running',
  scheduled: 'A chat tab has a /loop wakeup, cron job or monitor pending',
  'vscode-task': 'A VS Code task or debug session is running',
  'direct-run': 'A run started from THEO Remote is still going',
  'retry-wait': 'The last reload did not happen; trying again later',
  'no-key': 'The bridge did not say what the reload is for',
  'claude-detached': 'Claude Code chat tabs cannot report unsent text until this window reloads',
  'sessions-unknown': 'The session list has not loaded yet',
  draft: 'A chat box has unsent text',
  'draft-unknown':
    'Could not check every chat box for unsent text (a tab opened before this update cannot report: close it or reload by hand)',
  'unsaved-file': 'An editor has unsaved changes and hot exit is off',
  settling: 'Reloading in about a minute'
};
// Blockers that do not clear by waiting: the card says "Reload by hand" instead of "Reloads when idle".
const MANUAL_BLOCKERS = new Set(['disabled', 'syntax', 'already-tried', 'canary-failed', 'no-key', 'claude-detached']);
// Two reloads for the same update that VS Code never performed: something keeps vetoing it, so stop asking.
const MAX_NOT_RELOADED = 2;
// After a reload that did not happen (cancelled by VS Code, or the call hung), wait this long before trying again.
const NOT_RELOADED_RETRY_MS = 30 * 60 * 1000;
const RELOAD_CONFIRM_MS = 30 * 1000;

function resolveDir(opts = {}) {
  if (opts.dir) return String(opts.dir);
  const env = opts.env || process.env;
  if (env.THEO_AUTO_RELOAD_DIR) return String(env.THEO_AUTO_RELOAD_DIR);
  return path.join(opts.homeDir || os.homedir(), '.claude', 'theo-auto-reload');
}

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function writeJsonAtomic(file, value) {
  const tmp = `${file}.tmp-${process.pid}-${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
    fs.renameSync(tmp, file);
    return true;
  } catch {
    try {
      fs.unlinkSync(tmp);
    } catch {}
    return false;
  }
}

function sha16(text) {
  return crypto.createHash('sha256').update(String(text)).digest('hex').slice(0, 16);
}

// A stable key for this window: the installed folder plus the workspace. Two windows with no folder open share
// a key, so only one of them auto-reloads per update (the other keeps the manual toast): safe, never a loop.
function computeWindowKey(extRoot, workspaceId) {
  return sha16(`${path.resolve(String(extRoot || '')).toLowerCase()}|${String(workspaceId || 'empty-window')}`);
}

// Hash of the installed extension.js + package.json, re-hashed only when a stat changes.
// Returns { fp, newestMtimeMs } or null when a file cannot be read.
function fingerprintMainFiles(extRoot, memo = null) {
  try {
    const stats = MAIN_FILES.map((rel) => fs.statSync(path.join(extRoot, rel)));
    const statSig = stats.map((s) => `${Math.floor(s.mtimeMs)}:${s.size}`).join('|');
    const newestMtimeMs = Math.max(...stats.map((s) => Math.floor(s.mtimeMs)));
    if (memo && memo.extRoot === extRoot && memo.statSig === statSig) {
      return { fp: memo.fp, newestMtimeMs };
    }
    const h = crypto.createHash('sha256');
    for (const rel of MAIN_FILES) {
      h.update(rel);
      h.update('\0');
      h.update(fs.readFileSync(path.join(extRoot, rel)));
      h.update('\0');
    }
    const fp = h.digest('hex').slice(0, 16);
    if (memo) {
      memo.extRoot = extRoot;
      memo.statSig = statSig;
      memo.fp = fp;
      memo.compiles = null;
    }
    return { fp, newestMtimeMs };
  } catch {
    return null;
  }
}

// Never reload into an extension.js that would not even compile (a half-written or broken edit). Compiled as a
// CommonJS module body, the way require() will. Cached per fingerprint.
function installedMainCompiles(extRoot, memo = null) {
  if (memo && memo.compiles !== null && memo.compiles !== undefined && memo.extRoot === extRoot) {
    return memo.compiles;
  }
  let ok = false;
  try {
    const code = fs
      .readFileSync(path.join(extRoot, 'extension.js'), 'utf8')
      .replace(/^﻿/, '')
      .replace(/^#!.*/, '');
    new vm.Script(Module.wrap(code), { filename: 'extension.js' });
    JSON.parse(fs.readFileSync(path.join(extRoot, 'package.json'), 'utf8'));
    ok = true;
  } catch {
    ok = false;
  }
  if (memo && memo.extRoot === extRoot) memo.compiles = ok;
  return ok;
}

// ---- files: window records, canary ledger, lock, phone activity --------------------------------------------

function windowRecordPath(windowKey, opts = {}) {
  return path.join(resolveDir(opts), `w-${String(windowKey).replace(/[^0-9a-f]/gi, '')}.json`);
}
function ledgerPath(opts = {}) {
  return path.join(resolveDir(opts), 'ledger.json');
}
function lockPath(opts = {}) {
  return path.join(resolveDir(opts), 'reload.lock');
}
function remoteActivityPath(opts = {}) {
  return path.join(resolveDir(opts), 'remote-activity.json');
}

function readLedger(opts = {}) {
  const raw = readJson(ledgerPath(opts));
  const targets = raw && raw.targets && typeof raw.targets === 'object' ? raw.targets : {};
  return { targets };
}

function updateLedgerTarget(targetKey, patch, opts = {}) {
  if (!targetKey) return false;
  const now = Number(opts.now || Date.now());
  const ledger = readLedger(opts);
  // Only settled targets age out. A failed one stays, so an update that never started is not tried again.
  for (const [k, v] of Object.entries(ledger.targets)) {
    const at = Number(v?.verifiedAt || v?.supersededAt || 0);
    if (at && now - at > TARGET_KEEP_MS) delete ledger.targets[k];
    else if (!Number(v?.firstAt || 0) && !at) delete ledger.targets[k];
  }
  ledger.targets[targetKey] = { ...(ledger.targets[targetKey] || {}), ...patch };
  return writeJsonAtomic(ledgerPath(opts), ledger);
}

// What the ledger says about one update: 'new' (nobody tried it), 'verified', 'pending' (a canary is reloading
// into it) or 'failed' (the canary never came back).
function canaryStatus(ledger, targetKey, now) {
  const t = targetKey ? ledger?.targets?.[targetKey] : null;
  if (!t || !Number(t.firstAt)) return { status: 'new' };
  if (Number(t.verifiedAt)) return { status: 'verified', verifiedAt: Number(t.verifiedAt) };
  // A newer update landed while the canary reloaded: this one was never the point, so it is not a failure.
  if (Number(t.supersededAt)) return { status: 'superseded' };
  if (now - Number(t.firstAt) >= VERIFY_AFTER_MS) return { status: 'failed', firstAt: Number(t.firstAt) };
  return { status: 'pending', firstAt: Number(t.firstAt) };
}

// PC-wide lock: one window reloads at a time. Created with 'wx'; a lock older than LOCK_STALE_MS (its window
// never came back) is taken over.
function tryAcquireLock(info, opts = {}) {
  const p = lockPath(opts);
  const now = Number(opts.now || Date.now());
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
  } catch {}
  const body = JSON.stringify({ ...info, pid: process.pid, at: now });
  try {
    fs.writeFileSync(p, body, { encoding: 'utf8', flag: 'wx' });
    return true;
  } catch {}
  const cur = readJson(p);
  const age = now - Number(cur?.at || 0);
  if (cur && cur.windowKey === info.windowKey) {
    try {
      fs.writeFileSync(p, body, 'utf8');
      return true;
    } catch {
      return false;
    }
  }
  if (!cur || !(age >= 0 && age < LOCK_STALE_MS)) {
    // Take over a stale lock by atomic replace, then read it back: when two windows race, only the one whose
    // body is on disk afterwards holds the lock (never unlink, which could delete the other's fresh lock).
    const tmp = `${p}.tmp-${process.pid}-${Math.floor(Math.random() * 1e9)}`;
    try {
      fs.writeFileSync(tmp, body, 'utf8');
      fs.renameSync(tmp, p);
    } catch {
      try {
        fs.unlinkSync(tmp);
      } catch {}
      return false;
    }
    try {
      return fs.readFileSync(p, 'utf8') === body;
    } catch {
      return false;
    }
  }
  return false;
}

function readLock(opts = {}) {
  const cur = readJson(lockPath(opts));
  const now = Number(opts.now || Date.now());
  if (!cur) return null;
  const age = now - Number(cur.at || 0);
  return age >= 0 && age < LOCK_STALE_MS ? cur : null;
}

function releaseLockIfMine(windowKey, opts = {}) {
  const p = lockPath(opts);
  const cur = readJson(p);
  if (cur && cur.windowKey === windowKey) {
    try {
      fs.unlinkSync(p);
    } catch {}
  }
}

// Called by remote.js for every command from THEO Remote (phone, LAN or relay). In-process slot always; the
// file at most every 30 s, so other windows on the PC see it too.
function noteRemoteUserActivity(atMs = Date.now(), opts = {}) {
  const at = Number(atMs) || Date.now();
  if (!(Number(globalThis[REMOTE_ACTIVITY_KEY] || 0) >= at)) globalThis[REMOTE_ACTIVITY_KEY] = at;
  if (at - st.lastRemoteFileWriteAt < REMOTE_ACTIVITY_WRITE_EVERY_MS && !opts.forceWrite) return;
  st.lastRemoteFileWriteAt = at;
  writeJsonAtomic(remoteActivityPath(opts), { at });
}

function readRemoteActivityAt(opts = {}) {
  const inProc = Number(globalThis[REMOTE_ACTIVITY_KEY] || 0) || 0;
  const onDisk = Number(readJson(remoteActivityPath(opts))?.at || 0) || 0;
  return Math.max(inProc, onDisk);
}

// ---- the decision -------------------------------------------------------------------------------------------

// Pure. Returns { action: 'idle' | 'wait' | 'reload', pending: { main, bridge }, targetKey, blockers: [code],
// manual }.
function evaluateAutoReload(input = {}) {
  const now = Number(input.now || Date.now());
  const loaded = String(input.loadedFingerprint || '');
  const installed = input.installed || null; // { fp, newestMtimeMs, compiles }
  const mainPending = Boolean(loaded && installed && installed.fp && installed.fp !== loaded);
  const bridgePending = Boolean(input.bridgeNeedsReload);
  const pending = { main: mainPending, bridge: bridgePending };
  if (!mainPending && !bridgePending) {
    return { action: 'idle', pending, targetKey: '', blockers: [], manual: false };
  }
  const targetKey = mainPending
    ? `main:${installed.fp}`
    : `bridge:${sha16(String(input.bridgeKey || 'bridge'))}`;
  const blockers = [];
  const add = (code) => {
    if (!blockers.includes(code)) blockers.push(code);
  };

  if (input.enabled === false) add('disabled');
  if (mainPending) {
    if (now - Number(installed.newestMtimeMs || 0) < FILE_QUIET_MS) add('recent-change');
    else if (installed.compiles === false) add('syntax');
  }
  // An old bridge report without a reload key cannot be told apart from the next one: never auto-reload on it.
  if (!mainPending && !String(input.bridgeKey || '')) add('no-key');
  const rec = input.windowRecord || null;
  if (rec && rec.targetKey === targetKey && Number(rec.reloadedAt)) add('already-tried');
  if (rec && rec.targetKey === targetKey && Number(rec.notReloadedCount || 0) >= MAX_NOT_RELOADED) add('already-tried');
  if (rec && Number(rec.notReloadedAt) && now - Number(rec.notReloadedAt) < NOT_RELOADED_RETRY_MS) add('retry-wait');

  const canary = canaryStatus(input.ledger, targetKey, now);
  if (canary.status === 'failed') add('canary-failed');
  else if (canary.status === 'pending') add('canary-pending');

  const lock = input.lock || null;
  if (lock && lock.windowKey && lock.windowKey !== input.windowKey) add('other-window');

  const osIdle = input.osIdleMs;
  if (typeof osIdle !== 'number' || !Number.isFinite(osIdle)) add('idle-unknown');
  else if (osIdle < OS_IDLE_MIN_MS) add('in-use');

  const remoteAt = Number(input.remoteActivityAt || 0);
  // A stamp far in the future (a clock that jumped) would block forever: ignore it.
  if (remoteAt > 0 && now - remoteAt < REMOTE_QUIET_MS && remoteAt - now <= MAX_FUTURE_SKEW_MS) add('phone');

  const rowsAt = Number(input.rowsAt || 0);
  if (!Array.isArray(input.rows) || !rowsAt || now - rowsAt > ROWS_MAX_AGE_MS) {
    add('sessions-unknown');
  } else {
    for (const r of input.rows) {
      if (!r || r.remotePeer) continue;
      if (r.status === 'working' || r.status === 'waiting' || r.pendingQuestion) add('turn');
      if (Number(r.bgRunningCount || 0) > 0) add('bg-task');
      // A /loop wakeup, cron job or monitor lives in a Claude process. Not limited to tabs open here: the Claude
      // sidebar chat is not in the tab list, so any local Claude session whose scheduled work may still be alive
      // (store.js scheduledWorkUntil: 24 h for a wakeup or monitor, 7 days for a cron) holds the reload.
      if (r.provider !== 'antigravity' && Number(r.scheduledWorkUntil || 0) > now) add('scheduled');
    }
  }
  if (input.claudeDrafts && input.claudeDrafts.detached) add('claude-detached');
  if (Number(input.vscodeTasks || 0) > 0) add('vscode-task');
  if (Number(input.directRuns || 0) > 0) add('direct-run');

  for (const d of [input.claudeDrafts, input.agyDrafts]) {
    if (!d || d.ok === false) add('draft-unknown');
    else if (Number(d.drafts || 0) > 0) add('draft');
  }
  if (input.unsavedBlocks) add('unsaved-file');

  const manual = blockers.some((b) => MANUAL_BLOCKERS.has(b));
  if (blockers.length > 0) return { action: 'wait', pending, targetKey, blockers, manual };

  const eligibleSince = Number(input.eligibleSince || 0);
  const needMs = HOLD_STEADY_MS + Math.max(0, Number(input.jitterMs || 0));
  if (!eligibleSince || now - eligibleSince < needMs) {
    return { action: 'wait', pending, targetKey, blockers: ['settling'], manual: false };
  }
  return { action: 'reload', pending, targetKey, blockers: [], manual: false };
}

// ---- sidebar / digest view --------------------------------------------------------------------------------

function buildView(decision, extra = {}) {
  if (!decision || decision.action === 'idle') return extra.failure ? { pending: false, failure: extra.failure } : null;
  const reasons = [];
  if (decision.pending.main) reasons.push('THEO update');
  if (decision.pending.bridge) reasons.push('Claude Code / Antigravity patch');
  return {
    pending: true,
    reasons,
    state: extra.reloading ? 'reloading' : decision.manual ? 'manual' : 'waiting',
    blockers: (decision.blockers || []).map((code) => ({ code, label: BLOCKER_LABELS[code] || code })),
    since: Number(extra.pendingSince || 0),
    failure: extra.failure || null
  };
}

// A canary that never came back, on this PC, for the sidebar and the digest: newest failed target or null.
function readCanaryFailure(opts = {}) {
  const now = Number(opts.now || Date.now());
  const ledger = readLedger(opts);
  let worst = null;
  for (const [key, t] of Object.entries(ledger.targets)) {
    const c = canaryStatus(ledger, key, now);
    if (c.status !== 'failed') continue;
    if (Number(t.dismissedAt || 0) >= Number(t.firstAt || 0)) continue;
    if (!worst || c.firstAt > worst.firstAt) worst = { targetKey: key, firstAt: c.firstAt };
  }
  return worst;
}

// The sidebar's Dismiss button: hide every failed canary on this PC (a later failure shows again).
function dismissCanaryFailures(opts = {}) {
  const now = Number(opts.now || Date.now());
  const ledger = readLedger(opts);
  let changed = false;
  for (const [key, t] of Object.entries(ledger.targets)) {
    if (canaryStatus(ledger, key, now).status === 'failed') {
      ledger.targets[key] = { ...t, dismissedAt: now };
      changed = true;
    }
  }
  if (changed) writeJsonAtomic(ledgerPath(opts), ledger);
  if (st.lastView && st.lastView.failure) {
    st.lastView = st.lastView.pending ? { ...st.lastView, failure: null } : null;
  }
  return changed;
}

function getAutoReloadView() {
  return st.lastView || null;
}

function formatAutoReloadDigestLine(failure, nowMs = Date.now()) {
  if (!failure || !Number(failure.firstAt)) return '';
  const hours = Math.max(0, (nowMs - Number(failure.firstAt)) / 3600000);
  const age = hours < 1 ? 'under 1 h ago' : hours < 48 ? `${Math.floor(hours)} h ago` : `${Math.floor(hours / 24)} d ago`;
  return `THEO auto-reload did not come back (${age}): reload one window by hand to see the error`;
}

// ---- host wiring (extension.js) -----------------------------------------------------------------------------

// At activation, before anything can change the installed files: what this window actually loaded.
function initAutoReload({ extRoot, workspaceId, now = Date.now() } = {}) {
  if (!extRoot) return null;
  st.extRoot = extRoot;
  st.windowKey = computeWindowKey(extRoot, workspaceId);
  st.fpMemo = {};
  const fp = fingerprintMainFiles(extRoot, st.fpMemo);
  st.loadedFingerprint = fp ? fp.fp : '';
  st.loadedAt = now;
  st.eligibleSince = 0;
  st.reloading = false;
  st.verified = false;
  return { windowKey: st.windowKey, loadedFingerprint: st.loadedFingerprint };
}

// Once activation has finished: this window runs its code, so the update it runs is good. Clears its own pending
// record and lock. Any window may verify a target it runs, so a canary closed by hand is not reported as failed
// once another window has loaded the same update.
function verifyAfterActivation(opts = {}) {
  if (!st.windowKey) return null;
  const now = Number(opts.now || Date.now());
  const recPath = windowRecordPath(st.windowKey, opts);
  const rec = readJson(recPath);
  const ledger = readLedger(opts);
  const mainKey = st.loadedFingerprint ? `main:${st.loadedFingerprint}` : '';
  if (mainKey && ledger.targets[mainKey] && !Number(ledger.targets[mainKey].verifiedAt)) {
    updateLedgerTarget(mainKey, { verifiedAt: now }, opts);
  }
  let outcome = null;
  if (rec && rec.pendingVerify) {
    outcome = rec.targetKey === mainKey || String(rec.targetKey || '').startsWith('bridge:') ? 'ok' : 'changed-again';
    if (rec.targetKey && rec.targetKey !== mainKey) {
      const t = readLedger(opts).targets[rec.targetKey];
      if (t && !Number(t.verifiedAt) && String(rec.targetKey).startsWith('bridge:')) {
        updateLedgerTarget(rec.targetKey, { verifiedAt: now }, opts);
      } else if (t && !Number(t.verifiedAt) && outcome === 'changed-again') {
        // THEO started, on a newer update that landed during the reload: the older one is superseded, not failed.
        updateLedgerTarget(rec.targetKey, { supersededAt: now }, opts);
      }
    }
    writeJsonAtomic(recPath, { ...rec, pendingVerify: false, verifiedAt: now, outcome });
  }
  releaseLockIfMine(st.windowKey, opts);
  st.verified = true;
  return outcome;
}

// Unsent text in the chat boxes. Claude Code: the bridge collects each chat box's report in-process.
// The bridge only sees chat tabs once it is attached to Claude Code. When it is not (Claude Code loaded an
// unpatched bundle: exactly the bridge-reload case) while Claude Code runs or Claude chat tabs are open here, or
// fewer chat boxes report than Claude tabs are open, the answer is unknown.
function readClaudeDrafts({ vscode, hub } = {}) {
  let snap;
  try {
    const bridge = require('./compat/claude-hub-bridge.cjs');
    snap =
      typeof bridge.getClaudeDraftSnapshot === 'function'
        ? bridge.getClaudeDraftSnapshot({ ttlMs: DRAFT_TTL_MS })
        : { ok: false, drafts: 0, reporting: 0, attached: false };
  } catch {
    return { ok: false, drafts: 0 };
  }
  let openClaudeTabs = 0;
  try {
    openClaudeTabs = (Array.isArray(hub?.openTabsList) ? hub.openTabsList : []).filter(
      (t) => t && t.provider === 'claude'
    ).length;
  } catch {}
  let claudeActive = false;
  try {
    claudeActive = Boolean(vscode?.extensions?.getExtension?.('anthropic.claude-code')?.isActive);
  } catch {}
  if (snap.attached === false && (claudeActive || openClaudeTabs > 0)) return { ...snap, ok: false, detached: true };
  if (snap.ok && openClaudeTabs > Number(snap.reporting || 0)) return { ...snap, ok: false };
  return snap;
}

// Antigravity: chat boxes report to the UI proxy (worker thread); ask it over loopback.
function readAntigravityDrafts(opts = {}) {
  let port = Number(opts.proxyPort || 0);
  if (!port) {
    try {
      port = Number(require('./compat/antigravity-context-window.cjs').getProxyState()?.proxyPort || 0);
    } catch {
      port = 0;
    }
  }
  // No proxy: no Antigravity chat box can be on screen in this window.
  if (!port) return Promise.resolve({ ok: true, drafts: 0, reporting: 0 });
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => {
      if (done) return;
      done = true;
      resolve(v);
    };
    try {
      const req = http.request(
        {
          hostname: '127.0.0.1',
          port,
          path: '/__bhf_draft_state?stats=1',
          method: 'GET',
          timeout: Number(opts.timeoutMs || 1500)
        },
        (res) => {
          let body = '';
          res.setEncoding('utf8');
          res.on('data', (c) => {
            if (body.length < 4096) body += c;
          });
          res.on('end', () => {
            try {
              const j = JSON.parse(body);
              if (res.statusCode === 200 && j && j.ok === true) {
                finish({ ok: true, drafts: Number(j.drafts || 0), reporting: Number(j.reporting || 0) });
                return;
              }
            } catch {}
            // An older proxy without the endpoint answers 404: it cannot report, so the check is unknown.
            finish({ ok: false, drafts: 0 });
          });
        }
      );
      req.on('error', () => finish({ ok: false, drafts: 0 }));
      req.on('timeout', () => {
        try {
          req.destroy();
        } catch {}
        finish({ ok: false, drafts: 0 });
      });
      req.end();
    } catch {
      finish({ ok: false, drafts: 0 });
    }
  });
}

function readHostIdleMs() {
  try {
    const v = require('./device-identity').getHostIdleMs();
    return typeof v === 'number' ? v : null;
  } catch {
    return null;
  }
}

function unsavedEditorsBlock(vscode) {
  try {
    const hotExit = String(vscode.workspace.getConfiguration('files').get('hotExit', 'onExit') || 'onExit');
    if (hotExit !== 'off') return false;
    return vscode.workspace.textDocuments.some((d) => d && d.isDirty);
  } catch {
    return true;
  }
}

// Run Task executions and debug sessions die with the window (a dev server started with Run Task, a debugger).
// Unknown (API missing) counts as none: these APIs exist in every VS Code this extension supports.
function countVsCodeTasks(vscode) {
  let n = 0;
  try {
    n += Array.isArray(vscode?.tasks?.taskExecutions) ? vscode.tasks.taskExecutions.length : 0;
  } catch {}
  try {
    if (vscode?.debug?.activeDebugSession) n += 1;
  } catch {}
  return n;
}

// Runs THEO started for the phone (direct-runner.js) are child processes of this window's extension host.
function countDirectRuns(hub) {
  try {
    const runs = hub?.remote?.directRunner?.getActiveRuns?.();
    return Array.isArray(runs) ? runs.length : 0;
  } catch {
    return 0;
  }
}

// One pass, called from the extension's poll timer. Never throws. deps: { vscode, hub, bridgeReport }.
async function tickAutoReload(deps = {}) {
  if (st.inFlight || st.reloading || !st.extRoot || !st.windowKey) return getAutoReloadView();
  st.inFlight = true;
  try {
    const { vscode, hub } = deps;
    const now = Date.now();
    const enabled = (() => {
      try {
        return vscode.workspace.getConfiguration('antigravityHub').get('autoReloadWhenIdle', true) !== false;
      } catch {
        return true;
      }
    })();
    const fp = fingerprintMainFiles(st.extRoot, st.fpMemo);
    const installed = fp
      ? {
          ...fp,
          compiles:
            st.loadedFingerprint && fp.fp !== st.loadedFingerprint
              ? installedMainCompiles(st.extRoot, st.fpMemo)
              : true
        }
      : null;
    const report = deps.bridgeReport !== undefined ? deps.bridgeReport : hub?.bridgeInstallReport || null;
    const bridgeNeedsReload = Boolean(report && report.needsReload);
    const failure = readCanaryFailure({ now });
    if (!(st.loadedFingerprint && installed && installed.fp !== st.loadedFingerprint) && !bridgeNeedsReload) {
      st.eligibleSince = 0;
      st.pendingSince = 0;
      st.lastView = buildView({ action: 'idle' }, { failure });
      return st.lastView;
    }
    if (!st.pendingSince) st.pendingSince = now;
    const claudeDrafts = readClaudeDrafts({ vscode, hub });
    let agyDrafts = await readAntigravityDrafts();
    // Fewer pages reporting than Antigravity chat tabs open here: a page loaded before the reporter existed
    // cannot speak for its chat box, so the answer is unknown.
    try {
      const openAgyTabs = (Array.isArray(hub?.openTabsList) ? hub.openTabsList : []).filter(
        (t) => t && t.provider === 'antigravity'
      ).length;
      if (agyDrafts.ok && openAgyTabs > 0 && Number(agyDrafts.reporting || 0) < openAgyTabs) {
        agyDrafts = { ...agyDrafts, ok: false };
      }
    } catch {}
    const decision = evaluateAutoReload({
      now,
      enabled,
      loadedFingerprint: st.loadedFingerprint,
      installed,
      bridgeNeedsReload,
      bridgeKey: report?.reloadKey || '',
      windowKey: st.windowKey,
      windowRecord: readJson(windowRecordPath(st.windowKey)),
      ledger: readLedger({ now }),
      lock: readLock({ now }),
      osIdleMs: readHostIdleMs(),
      remoteActivityAt: readRemoteActivityAt(),
      rows: hub?._autoReloadRows,
      rowsAt: hub?._autoReloadRowsAt,
      claudeDrafts,
      agyDrafts,
      unsavedBlocks: unsavedEditorsBlock(vscode),
      vscodeTasks: countVsCodeTasks(vscode),
      directRuns: countDirectRuns(hub),
      eligibleSince: st.eligibleSince,
      jitterMs: st.jitterMs
    });
    if (decision.blockers.length === 1 && decision.blockers[0] === 'settling') {
      if (!st.eligibleSince) st.eligibleSince = now;
    } else if (decision.action !== 'reload') {
      st.eligibleSince = 0;
    }
    if (decision.action === 'reload') {
      const reloaded = await performReload(decision, { vscode, now });
      st.lastView = buildView(decision, { pendingSince: st.pendingSince, failure, reloading: reloaded });
      return st.lastView;
    }
    st.lastView = buildView(decision, { pendingSince: st.pendingSince, failure });
    return st.lastView;
  } catch {
    return getAutoReloadView();
  } finally {
    st.inFlight = false;
  }
}

async function performReload(decision, { vscode, now = Date.now(), ...opts } = {}) {
  if (!tryAcquireLock({ windowKey: st.windowKey, targetKey: decision.targetKey }, { now })) {
    st.eligibleSince = 0;
    return false;
  }
  // Re-read the canary state under the lock: another window may have started on this update meanwhile.
  const canary = canaryStatus(readLedger({ now }), decision.targetKey, now);
  if (canary.status === 'pending' || canary.status === 'failed') {
    releaseLockIfMine(st.windowKey);
    st.eligibleSince = 0;
    return false;
  }
  const wroteCanary = canary.status === 'new';
  if (wroteCanary) {
    updateLedgerTarget(decision.targetKey, { firstAt: now, by: st.windowKey }, { now });
  }
  const recPath = windowRecordPath(st.windowKey);
  const prevRec = readJson(recPath) || {};
  const prevNotReloaded = prevRec.targetKey === decision.targetKey ? Number(prevRec.notReloadedCount || 0) : 0;
  const recOk = writeJsonAtomic(recPath, {
    notReloadedCount: prevNotReloaded,
    targetKey: decision.targetKey,
    reloadedAt: now,
    fromFingerprint: st.loadedFingerprint,
    reasons: decision.pending,
    pendingVerify: true
  });
  if (!recOk) {
    // Without the record the once-per-update rule cannot hold: do not reload.
    if (wroteCanary) undoCanary(decision.targetKey);
    releaseLockIfMine(st.windowKey);
    st.eligibleSince = 0;
    return false;
  }
  st.reloading = true;
  try {
    console.log(`[theo-hub] Auto-reload: ${decision.targetKey} (window ${st.windowKey})`);
  } catch {}
  // This process ends when the reload happens. Still here RELOAD_CONFIRM_MS after asking (VS Code cancelled
  // it, e.g. a "task is running" dialog, or the call hung): the reload did not happen. Undo the canary so no
  // window reports a failed update, free the lock, and let this window try again after NOT_RELOADED_RETRY_MS.
  const notReloaded = () => {
    if (!st.reloading) return;
    st.reloading = false;
    st.eligibleSince = 0;
    if (wroteCanary) undoCanary(decision.targetKey);
    const rec = readJson(recPath) || {};
    writeJsonAtomic(recPath, {
      ...rec,
      reloadedAt: 0,
      pendingVerify: false,
      notReloadedAt: Date.now(),
      notReloadedCount: Number(rec.notReloadedCount || 0) + 1,
      outcome: 'not-reloaded'
    });
    releaseLockIfMine(st.windowKey);
  };
  const confirmTimer = setTimeout(notReloaded, Number(opts.confirmMs || RELOAD_CONFIRM_MS));
  if (typeof confirmTimer?.unref === 'function') confirmTimer.unref();
  try {
    // Never await a hung command forever: the tick that called us holds st.inFlight until we return.
    await Promise.race([
      vscode.commands.executeCommand('workbench.action.reloadWindow'),
      new Promise((resolve) => {
        const t = setTimeout(resolve, Number(opts.confirmMs || RELOAD_CONFIRM_MS));
        if (typeof t?.unref === 'function') t.unref();
      })
    ]);
    return true;
  } catch {
    clearTimeout(confirmTimer);
    notReloaded();
    return false;
  }
}

// Remove a canary start this window wrote for a reload that never happened (never one another window verified).
function undoCanary(targetKey, opts = {}) {
  const ledger = readLedger(opts);
  const t = ledger.targets[targetKey];
  if (!t || Number(t.verifiedAt) || t.by !== st.windowKey) return;
  delete ledger.targets[targetKey];
  writeJsonAtomic(ledgerPath(opts), ledger);
}

function resetAutoReloadStateForTest() {
  Object.assign(st, {
    extRoot: '',
    windowKey: '',
    loadedFingerprint: '',
    loadedAt: 0,
    eligibleSince: 0,
    pendingSince: 0,
    fpMemo: null,
    inFlight: false,
    reloading: false,
    verified: false,
    lastView: null,
    lastRemoteFileWriteAt: 0
  });
  delete globalThis[REMOTE_ACTIVITY_KEY];
}

module.exports = {
  OS_IDLE_MIN_MS,
  REMOTE_QUIET_MS,
  FILE_QUIET_MS,
  HOLD_STEADY_MS,
  JITTER_MAX_MS,
  ROWS_MAX_AGE_MS,
  LOCK_STALE_MS,
  VERIFY_AFTER_MS,
  VERIFY_DELAY_MS,
  DRAFT_TTL_MS,
  REMOTE_ACTIVITY_KEY,
  BLOCKER_LABELS,
  computeWindowKey,
  fingerprintMainFiles,
  installedMainCompiles,
  evaluateAutoReload,
  canaryStatus,
  tryAcquireLock,
  readLock,
  releaseLockIfMine,
  readLedger,
  updateLedgerTarget,
  noteRemoteUserActivity,
  readRemoteActivityAt,
  readCanaryFailure,
  dismissCanaryFailures,
  buildView,
  getAutoReloadView,
  formatAutoReloadDigestLine,
  initAutoReload,
  verifyAfterActivation,
  readAntigravityDrafts,
  readClaudeDrafts,
  countVsCodeTasks,
  countDirectRuns,
  tickAutoReload,
  performReload,
  resetAutoReloadStateForTest,
  windowRecordPath
};
